#include <cstdio>
#include <iostream>
#include <cstring>
#define travel(x, i) for (int i = fir[x]; i; i = e[i].nxt)
using namespace std;

typedef long long LL;
const int N = 6e5 + 50;
  
struct edge {
  int nxt, to;
} e[N << 1];
int fir[N], cntEdge = 1;
int n, fa[N], jmp[N][20], dep[N];
  
inline void addedge(int x, int y) {
  e[++ cntEdge] = (edge) { fir[x], y }; fir[x] = cntEdge;
}

inline void Dfs(int x, int f) {
  dep[x] = dep[f] + 1;
  fa[x] = jmp[x][0] = f;
  for (int i = 1, j = f; i < 20; i ++)
    j = jmp[x][i] = jmp[j][i - 1];
  travel(x, i)
    if (e[i].to != f) Dfs(e[i].to, x);
}

inline int LCA(int x, int y) {
  if (dep[x] < dep[y]) swap(x, y);
  for (int i = 19; dep[x] != dep[y]; i --)
    if (dep[jmp[x][i]] >= dep[y]) x = jmp[x][i];
  if (x == y) return x;
  for (int i = 19; fa[x] != fa[y]; i --)
    if (jmp[x][i] != jmp[y][i]) {
      x = jmp[x][i]; y = jmp[y][i];
    }
  return fa[x];
}

int sta[N], cnt[N], top = 0;

int main() {
  scanf("%d", &n);
  for (int i = 1, x, y; i < n; i ++) {
    scanf("%d%d", &x, &y);
    addedge(x, y); addedge(y, x);
  }
  Dfs(1, 0);
  int x;
  scanf("%d", &x);
  LL ans = dep[x], cur = dep[x];
  sta[++ top] = x; cnt[top] = 1;
  for (int i = 2, l; i <= n; i ++) {
    scanf("%d", &x);
    l = LCA(x, sta[top]);
    int tmp = 0;
    while (top && dep[sta[top]] >= dep[l]) {
      cur -= 1ll * dep[sta[top]] * cnt[top];
      tmp += cnt[top]; top --;
    }
    cur += 1ll * dep[l] * tmp + dep[x];
    ans += cur;
    sta[++ top] = l;
    cnt[top] = tmp;
    if (l == x) cnt[top] ++;
    else {
      sta[++ top] = x; cnt[top] = 1;
    }
  }
  printf("%lld\n", ans);
  return 0;
}
