#include <bits/stdc++.h>
using namespace std;

int main() {
  system("g++ std.cpp -o std -O2");
  system("./std < easy1.in > easy1.ans");
  system("./std < easy2.in > easy2.ans");
  system("./std < easy3.in > easy3.ans");
  system("./std < easy4.in > easy4.ans");
  system("./std < easy5.in > easy5.ans");
  system("./std < easy6.in > easy6.ans");
  system("./std < easy7.in > easy7.ans");
  system("./std < easy8.in > easy8.ans");
  system("./std < easy9.in > easy9.ans");
  system("./std < easy10.in > easy10.ans");
  system("./std < easy11.in > easy11.ans");
  system("./std < easy12.in > easy12.ans");
  system("./std < easy13.in > easy13.ans");
  system("./std < easy14.in > easy14.ans");
  system("./std < easy15.in > easy15.ans");
  system("./std < easy16.in > easy16.ans");
  system("./std < easy17.in > easy17.ans");
  system("./std < easy18.in > easy18.ans");
  system("./std < easy19.in > easy19.ans");
  system("./std < easy20.in > easy20.ans");
  return 0;
}
