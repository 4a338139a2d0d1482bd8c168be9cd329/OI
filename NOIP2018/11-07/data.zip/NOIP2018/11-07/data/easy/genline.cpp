#include <bits/stdc++.h>
using namespace std;

const int n = 200000;

int p[n + 100];

int main() {
  srand((unsigned)time(0));
  printf("%d\n", n);
  for (int i = 1; i <= n; i ++) p[i] = i;
  // random_shuffle(p + 1, p + n + 1);
  for (int i = 1; i < n; i ++)
    printf("%d %d\n", p[i], p[i + 1]);
  random_shuffle(p + 1, p + n + 1);
  for (int i = 1; i <= n; i ++)
    printf("%d%c", p[i], i == n ? '\n' : ' ');
  return 0;
}
