#include <bits/stdc++.h>
using namespace std;

const int n = 4e5;

int p[n + 100];

int main() {
  srand((unsigned)time(0));
  printf("%d\n", n);
  for (int i = 1; i < n / 2; i ++)
    printf("%d %d\n", i, i + 1);
  for (int i = 1; i <= n / 2; i ++)
    printf("%d %d\n", i, i + n / 2);
  for (int i = n / 2; i > n / 4; i --)
    printf("%d %d ", i, i + n / 2);
  int m = 0;
  for (int i = n / 4; i; i --)
    p[++ m] = i, p[++ m] = i + n / 2;
  random_shuffle(p + 1, p + m + 1);
  for (int i = 1; i <= m; i ++) printf("%d ", p[i]);
  puts("");
  return 0;
}
