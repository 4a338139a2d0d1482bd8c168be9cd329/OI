#include <bits/stdc++.h>
using namespace std;
#define N 600010
int i,j,k,n,m,x,y,h,t,num;
long long ans,tot;
int fi[N*2],ne[N*2],la[N*2],a[N*2],p[N],diyi[N],dier[N],w[N*2],ch[N*2],f[N*2][22],d[N],lg[N*2];
int s[N],r[N];
inline int read(){
  int x=0,f=1;
  char ch=getchar();
  while (ch<'0'||ch>'9'){f=ch=='-'?-f:f;ch=getchar();}
  while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
  return x*f;
}
inline void add(int x,int y){k++;a[k]=y;if (fi[x]==0)fi[x]=k;else ne[la[x]]=k;la[x]=k;}
inline void dfs(int x,int de){d[x]=de;for (int i=1;i<22;i++)f[x][i]=f[f[x][i-1]][i-1];for (int i=fi[x];i;i=ne[i])if (!d[a[i]]){f[a[i]][0]=x;dfs(a[i],de+1);}}
inline int lca(int x,int y){
  if (d[x]<d[y])swap(x,y);
  int delta=d[x]-d[y];
  for (int i=21;i>=0;i--)if (delta>=(1<<i))x=f[x][i],delta-=1<<i;
  if (x==y)return x;
  for (int i=21;i>=0;i--)if (f[x][i]!=f[y][i])x=f[x][i],y=f[y][i];
  return f[x][0];
}
int main(){
  n=read();
  for (i=1;i<n;i++){x=read();y=read();add(x,y);add(y,x);}
  for (i=1;i<=n;i++)p[i]=read();
  dfs(1,1);
  ans=tot=d[p[1]];r[++r[0]]=1;s[++s[0]]=p[1];
  for (i=2;i<=n;i++){
    int l=lca(p[i],s[s[0]]),lalala=0;
    while (s[0]&&d[l]<d[s[s[0]]])tot-=1ll*d[s[s[0]]]*r[r[0]],lalala+=r[r[0]],s[0]--,r[0]--;
    if (l!=s[s[0]])tot+=1ll*d[l]*lalala,s[++s[0]]=l,r[++r[0]]=lalala;
    else r[r[0]]+=lalala,tot+=1ll*lalala*d[s[s[0]]];
    tot+=d[p[i]];
    if (l!=p[i]){s[++s[0]]=p[i];r[++r[0]]=1;}else r[r[0]]++;ans+=tot;
    // cerr << tot << endl;
  }
  printf("%lld\n",ans);
  return 0;
}
