#include <cstdio>
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

const int N = 1e5 + 50;

int main() {
  system("./genbig > easy11.in");
  system("./std < easy11.in > easy11.ans");
  system("./std_yjc < easy11.in > out");
  system("diff out easy11.ans");
  return 0;
}
