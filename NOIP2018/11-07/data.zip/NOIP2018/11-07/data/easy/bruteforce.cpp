#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 1e5 + 50;

struct edge {
  int nxt, to;
} e[N << 1];
int fir[N], cnt = 1;
int dep[N], le[N], ri[N], clo, fa[N];
int n, p[N];

inline void addedge(int x, int y) {
  e[++ cnt] = (edge) { fir[x], y }; fir[x] = cnt;
}

inline void Dfs(int x, int f) {
  fa[x] = f;
  dep[x] = dep[f] + 1;
  le[x] = ++ clo;
  for (int i = fir[x]; i; i = e[i].nxt)
    if (e[i].to != f) Dfs(e[i].to, x);
  ri[x] = clo;
}

int main() {
  scanf("%d", &n);
  for (int i = 1, x, y; i < n; i ++) {
    scanf("%d%d", &x, &y);
    addedge(x, y); addedge(y, x);
  }
  Dfs(1, 0);
  for (int i = 1; i <= n; i ++) scanf("%d", &p[i]);
  long long ans = 0;
  for (int i = 1; i <= n; i ++) {
    int lca = p[i], cur;
    ans += dep[lca];
    for (int j = i + 1; j <= n; j ++) {
      cur = le[p[j]];
      while (!(le[lca] <= cur && cur <= ri[lca])) lca = fa[lca];
      ans += dep[lca];
    }
  }
  printf("%lld\n", ans);
  return 0;
}
