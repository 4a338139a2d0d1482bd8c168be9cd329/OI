#include <bits/stdc++.h>
using namespace std;
static const int N=4010;
typedef long long ll;
int i,j,k,n,m,x,y,t,a[N],b[N];
ll f[14][N],ans[N];
int read(){
  int x=0,f=1;
  char ch=getchar();
  while (ch<'0'||ch>'9'){f=ch=='-'?-f:f;ch=getchar();}
  while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
  return x*f;
}
void solve(int id,int l,int r,int len){
  memcpy(f[id],f[id-1],sizeof f[id-1]);
  if (l==r) {
    ans[l]=f[id][0];
    for (int i=1;i<=m;i++) ans[l]=min(ans[l],f[id][i]);
    return;
  }
  int mid=(l+r)>>1;
  for (int i=mid+1;i<=r;i++) {
    for (int j=len+(i-mid-1);j>=0;j--)
      f[id][j+1]=min(f[id][j+1]+b[i],f[id][j]+a[i]);
    f[id][0]+=b[i];
  }
  solve(id+1,l,mid,len+(r-mid));
  memcpy(f[id],f[id-1],sizeof f[id-1]);
  for (int i=l;i<=mid;i++){
    for (int j=len+(i-l);j>=0;j--)
      f[id][j+1]=min(f[id][j+1]+b[i],f[id][j]+a[i]);
    f[id][0]+=b[i];
  }
  solve(id+1,mid+1,r,len+(mid-l+1));
}
int main(){
  n=read();m=read();
  for (i=1;i<=n;i++)a[i]=read(),b[i]=read();
  memset(f[0],0x3f3f3f,sizeof f[0]);f[0][0]=0;
  solve(1,1,n,0);
  for (i=1;i<=n;i++)printf("%lld ",ans[i]);printf("\n");
  return 0;
}
