#include <bits/stdc++.h>
using namespace std;

int main() {
  srand((unsigned long long) new char);
  cout << 500 << " " << 250 << endl;
  for (int i = 1; i <= 500; i ++)
    cout << rand() % 1000000000 << " " << rand() % 1000000000 << endl;
  return 0;
}
