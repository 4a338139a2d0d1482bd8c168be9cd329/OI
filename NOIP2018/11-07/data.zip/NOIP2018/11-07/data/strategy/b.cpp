#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 4040;

int n, k;
int a[N], d[N];
long long p[N];

inline void solve(int cur) {
  for (int i = 1; i <= k; i ++) p[i] = 4e18;
  p[0] = 0;
  for (int i = 1; i <= n; i ++) {
    if (i == cur) continue;
    for (int j = min(i, k); j; j --)
      p[j] = min(p[j] + d[i], p[j - 1] + a[i]);
    p[0] += d[i];
  }
  long long ans = 8e18;
  for (int i = 0; i <= k; i ++) ans = min(ans, p[i]);
  printf("%lld ", ans);
}

int main() {
  scanf("%d%d", &n, &k);
  for (int i = 1; i <= n; i ++) scanf("%d%d", &a[i], &d[i]);
  for (int i = 1; i <= n; i ++) solve(i);
  puts("");
  return 0;
}
