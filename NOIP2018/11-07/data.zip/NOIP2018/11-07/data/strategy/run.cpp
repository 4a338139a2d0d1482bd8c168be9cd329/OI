#include <bits/stdc++.h>
using namespace std;

int main() {
  system("g++ std.cpp -o std -O2");
  system("./std < strategy1.in > strategy1.ans");
  system("./std < strategy2.in > strategy2.ans");
  system("./std < strategy3.in > strategy3.ans");
  system("./std < strategy4.in > strategy4.ans");
  system("./std < strategy5.in > strategy5.ans");
  system("./std < strategy6.in > strategy6.ans");
  system("./std < strategy7.in > strategy7.ans");
  system("./std < strategy8.in > strategy8.ans");
  system("./std < strategy9.in > strategy9.ans");
  system("./std < strategy10.in > strategy10.ans");
  return 0;
}
