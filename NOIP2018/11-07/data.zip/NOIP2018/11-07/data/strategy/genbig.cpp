#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 4000;
const int B = 1e9;

int x[N + 10], y[N + 10];

int main() {
  srand((unsigned long long) new char);
  printf("%d %d\n", N, N / 2 + rand() % 50);
  for (int i = 1; i <= N; i ++)
    x[i] = rand() % B, y[i] = rand() % B;
  sort(x + 1, x + N + 1);
  sort(y + 1, y + N + 1);
  reverse(y + 1, y + N + 1);
  for (int i = 1; i <= N; i ++)
    printf("%d %d\n", x[i], y[i]);
  return 0;
}
