#include <bits/stdc++.h>
using namespace std;

const int N = 4010;
typedef long long LL;

int i, j, k, n, m, x, y, t, a[N], b[N];
LL f[14][N], ans[N];

void solve(int id, int l, int r, int len) {
  if (l == r) {
    id --;
    ans[l] = f[id][0];
    for (int i = 1; i <= m; i ++)
      ans[l] = min(ans[l], f[id][i]);
    return;
  }
  memcpy(f[id], f[id - 1], sizeof f[id - 1]);
  int mid = (l + r) >> 1;
  for (int i = mid + 1; i <= r; i ++) {
    for (int j = min(m, len + (i - mid - 1)); j >= 0; j --)
      f[id][j + 1] = min(f[id][j + 1] + b[i], f[id][j] + a[i]);
    f[id][0] += b[i];
  }
  solve(id + 1, l, mid, len + (r - mid));
  memcpy(f[id], f[id - 1], sizeof f[id - 1]);
  for (int i = l; i <= mid; i ++) {
    for (int j = min(m, len + (i - l)); j >= 0; j --)
      f[id][j + 1] = min(f[id][j + 1] + b[i], f[id][j] + a[i]);
    f[id][0] += b[i];
  }
  solve(id + 1, mid + 1, r, len + (mid - l + 1));
}
int main() {
  scanf("%d%d", &n, &m);
  for (i = 1; i <= n; i ++)
    scanf("%d%d", &a[i], &b[i]);
  memset(f[0], 0x3f, sizeof f[0]);
  f[0][0] = 0;
  solve(1, 1, n, 0);
  for (i = 1; i <= n; i ++)
    printf("%lld ", ans[i]);
  printf("\n");
  return 0;
}
