#include <bits/stdc++.h>
using namespace std;

int main() {
  system("g++ std.cpp -o std -O2");
  system("./std < fair1.in > fair1.ans");
  system("./std < fair2.in > fair2.ans");
  system("./std < fair3.in > fair3.ans");
  system("./std < fair4.in > fair4.ans");
  system("./std < fair5.in > fair5.ans");
  system("./std < fair6.in > fair6.ans");
  system("./std < fair7.in > fair7.ans");
  system("./std < fair8.in > fair8.ans");
  system("./std < fair9.in > fair9.ans");
  system("./std < fair10.in > fair10.ans");
  system("./std < fair11.in > fair11.ans");
  system("./std < fair12.in > fair12.ans");
  system("./std < fair13.in > fair13.ans");
  system("./std < fair14.in > fair14.ans");
  system("./std < fair15.in > fair15.ans");
  system("./std < fair16.in > fair16.ans");
  system("./std < fair17.in > fair17.ans");
  system("./std < fair18.in > fair18.ans");
  system("./std < fair19.in > fair19.ans");
  system("./std < fair20.in > fair20.ans");
  return 0;
}
