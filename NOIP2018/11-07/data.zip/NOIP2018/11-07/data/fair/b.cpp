#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

typedef long long LL;
const int N = 50;
const LL mod = 998244353;

int n, m, G[N][N], u[N * N], v[N * N], w[N * N];

namespace Set {
  int fa[N], sz;
  inline void Init() {
    memset(fa, 0, sizeof fa);
    sz = n;
  }
  inline int getf(int x) {
    return fa[x] ? fa[x] = getf(fa[x]) : x;
  }
  inline void U(int x, int y) {
    x = getf(x + 1); y = getf(y + 1);
    if (x == y) return;
    sz --; fa[x] = y;
  }
}

inline LL Pow(LL x, LL exp = mod - 2) {
  LL res = 1;
  for (; exp; exp >>= 1, x = x * x % mod)
    if (exp & 1) res = res * x % mod;
  return res;
}

inline LL check(int msk) {
  Set :: Init();
  LL pos = 1;
  for (int i = 0; i < m; i ++)
    if (((msk) >> i) & 1) {
      pos = pos * (mod + 1 - w[i]) % mod;
      Set :: U(u[i], v[i]);
    }
    else pos = pos * w[i] % mod;
  return Set :: sz * pos % mod;
}

int main() {
  scanf("%d%d", &n, &m);
  for (int i = 0; i < m; i ++)
    scanf("%d%d%d", &u[i], &v[i], &w[i]);
  if (m > 25) throw;
  LL ans = 0;
  for (int i = 0; i < (1 << m); i ++) (ans += check(i)) %= mod;
  printf("%lld\n", ans);
  return 0;
}
