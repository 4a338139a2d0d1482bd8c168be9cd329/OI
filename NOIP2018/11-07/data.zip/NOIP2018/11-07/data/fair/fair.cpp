#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#define lb(x) (x & (- x))
using namespace std;

typedef long long LL;
const int N = 17;
const int M = 1 << N | 5;
const LL mod = 998244353;
const LL sqr = mod * mod;

int n, m, G[N][N], chg[M];
LL dis[N][M], bet[M], inv[M], f[M];

inline LL Pow(LL x, LL exp = mod - 2) {
  LL res = 1;
  for (; exp; exp >>= 1, x = x * x % mod)
    if (exp & 1) res = res * x % mod;
  return res;
}

inline void Init() {
  for (int i = 0; i < n; i ++) chg[1 << i] = i;
  for (int i = 0; i < n; i ++) {
    dis[i][0] = 1;
    for (int j = 0; j < n; j ++)
      dis[i][1 << j] = G[i][j];
    for (int j = 1; j < (1 << n); j ++)
      dis[i][j] = dis[i][j ^ lb(j)] * dis[i][lb(j)] % mod;
  }
  bet[0] = 1;
  for (int i = 1; i < (1 << n); i ++)
    bet[i] = bet[i ^ lb(i)] * dis[chg[lb(i)]][i ^ lb(i)] % mod;
  for (int i = 0; i < (1 << n); i ++) inv[i] = Pow(bet[i]);
}

inline LL calc(int x, int y) {
  return bet[x + y] * inv[x] % mod * inv[y] % mod;
}

inline void DP() {
  f[0] = 1;
  for (int i = 0; i < n; i ++) f[1 << i] = 1;
  for (int i = 0; i < (1 << n); i ++) {
    if (f[i]) continue;
    int s = i ^ lb(i);
    LL &pos = f[i];
    for (int j = s; j; j = s & (j - 1)) {
      pos += f[i ^ j] * calc(i ^ j, j);
      if (pos >= sqr) pos -= sqr;
    }
    pos = mod + 1 - pos % mod;
  }
}

int main() {
  memset(G, -1, sizeof G);
  scanf("%d%d", &n, &m);
  for (int i = 1, u, v, w; i <= m; i ++) {
    scanf("%d%d%d", &u, &v, &w);
    u --; v --;
    G[u][v] = G[v][u] = w;
  }
  for (int i = 0; i < n; i ++)
    for (int j = 0; j < n; j ++)
      if (G[i][j] == -1) G[i][j] = 1;
  Init(); DP();
  LL ans = 0;
  int U = (1 << n) - 1;
  for (int i = 1; i < (1 << n); i ++) {
    ans += calc(i, U ^ i) * f[i];
    if (ans >= sqr) ans -= sqr;
  }
  printf("%lld\n", ans % mod);
  return 0;
}
