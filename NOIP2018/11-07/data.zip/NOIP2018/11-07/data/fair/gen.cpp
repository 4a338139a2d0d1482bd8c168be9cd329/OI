#include <bits/stdc++.h>
using namespace std;

const int mod = 998244353;

int G[50][50];

int main() {
  srand((unsigned long long) new char);
  int n = 14;
  int cnt = 21, x, y;
  cout << n << " " << cnt << endl;
  while (cnt) {
    x = rand() % n + 1;
    if (x == 1) continue;
    y = rand() % x + 1;
    if (G[x][y]) continue;
    G[x][y] = 1;
    printf("%d %d %d\n", x, y, max(1, rand() % mod));
    cnt --;
  }
  return 0;
}
