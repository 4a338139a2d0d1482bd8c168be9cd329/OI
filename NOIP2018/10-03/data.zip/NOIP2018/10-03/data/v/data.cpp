#include<bits/stdc++.h>
using namespace std;

int f(int x,int y){
	return rand()%(y-x+1)+x;
}
int n,k,type;

int main(int argc,char*argv[]){
	freopen("v.in","w",stdout);
	n=strtol(argv[1],NULL,10);
	type=strtol(argv[2],NULL,10);
	srand(time(0)%clock()^time(0)*clock());
	if(f(0,7))
		n=f(n-n/8,n);
	else
		n=f(1,n);
	if(type==1)
		k=f(0,1)?n:0;
	else
		k=f(0,n);
	printf("%d %d\n",n,k);
	static char s[100];
	if(type==2){
		s[1]=f(0,1)?'W':'B';
		for(int i=2;i<=n;++i)
			s[i]=s[i-1];
	}
	else if(type==3){
		for(int i=1;i<=n;++i)
			s[i]='B';
		s[f(1,n)]='W';
	}
	else if(type==4){
		for(int i=1;i<=n;++i)
			s[i]='W';
		s[f(1,n)]='B';
	}
	else
		for(int i=1;i<=n;++i)
			s[i]=f(0,1)?'W':'B';
	puts(s+1);
	return 0;
}
