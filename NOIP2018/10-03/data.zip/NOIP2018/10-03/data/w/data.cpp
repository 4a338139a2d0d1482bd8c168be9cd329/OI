#include<bits/stdc++.h>
using namespace std;

int f(int x,int y){
	return rand()%(y-x+1)+x;
}
const int maxn=1e5+10;
int fa[maxn],d[maxn];
int n,type;

int main(int argc,char*argv[]){
	freopen("w.in","w",stdout);
	n=strtol(argv[1],NULL,10);
	type=strtol(argv[2],NULL,10);
	srand(time(0)%clock()^time(0)*clock());
	n=f(n-n/20,n);
	printf("%d\n",n);
	if(type==2)
		for(int i=2;i<=n;++i)fa[i]=i-1;
	else
		for(int i=2;i<=n;++i)fa[i]=f(1,i-1);
	if(type==1){
		for(int i=2;i<=n;++i)
			d[i]=f(0,1);
		int x=10;
		while(x--)
			d[f(2,n)]=2;
	}
	else if(type==3){
		for(int i=2;i<=n;++i)
			d[i]=2;
	}
	else if(type==4){
		for(int i=2;i<=n;++i)
			d[i]=f(0,1);
	}
	else
		for(int i=2;i<=n;++i)
			d[i]=f(0,2);
	for(int i=2;i<=n;++i)
		printf("%d %d %d %d\n",fa[i],i,f(0,1),d[i]);
	return 0;
}
