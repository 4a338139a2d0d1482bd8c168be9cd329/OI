#include<bits/stdc++.h>
using namespace std;

#define work(...) {sprintf(s,__VA_ARGS__);system(s);}
char s[1000];

inline int e(int x,int y){
	return x*pow(10,y);
}
const int test[]={1,4,4,2,2,3};
const int n[]={e(1,3),e(3,2),e(1,3),e(1,3),e(1,3),e(1,3)};
const int q[]={0,e(4,2),e(2,3),e(3,5),e(3,5),e(3,5)};
const int type[]={0,0,0,1,2,0};

int main(){
	for(int i=1,cnt=0;i<=6;++i)
		for(int j=1;j<=test[i-1];++j){
			work("./data %d %d %d",n[i-1],q[i-1],type[i-1]);
			work("./u");
			++cnt;
			work("rm %d_%d.in",i,cnt);
			work("mv u.in %d_%d.in",i,cnt);
			work("rm %d_%d.ans",i,cnt);
			work("mv u.out %d_%d.ans",i,cnt);
		}
	return 0;
}
