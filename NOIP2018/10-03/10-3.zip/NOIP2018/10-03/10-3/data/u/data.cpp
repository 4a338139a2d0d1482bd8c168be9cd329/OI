#include<bits/stdc++.h>
using namespace std;

int f(int x,int y){
	return rand()%(y-x+1)+x;
}
int n,q,type;

int main(int argc,char*argv[]){
	freopen("u.in","w",stdout);
	n=strtol(argv[1],NULL,10);
	q=strtol(argv[2],NULL,10);
	type=strtol(argv[3],NULL,10);
	srand(time(0)%clock()^time(0)*clock());
	n=f(n-n/20,n);q=f(q-q/20,q);
	printf("%d %d\n",n,q);
	while(q--){
		int r,c,l,s=f(1,1e9);
		if(type==1){
			c=1;r=f(1,n);
			l=n+1-r;
		}
		else if(type==2){
			c=f(1,n);r=f(1,n);
			l=n+1-r;
		}
		else{
			r=f(1,n);c=f(1,n);
			l=min(f(1,n),f(1,n));
		}
		printf("%d %d %d %d\n",r,c,l,s);
	}
	return 0;
}
