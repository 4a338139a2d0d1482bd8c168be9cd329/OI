#include<bits/stdc++.h>
using namespace std;

#define work(...) {sprintf(s,__VA_ARGS__);system(s);}
char s[1000];

inline int e(int x,int y){
	return x*pow(10,y);
}
const int test[]={5,5,3,1,3,5};
const int n[]={20,e(1,3),e(1,5),e(1,5),e(1,5),e(1,5)};
const int type[]={0,1,2,3,4,0};

int main(){
	for(int i=1,cnt=0;i<=6;++i)
		for(int j=1;j<=test[i-1];++j){
			work("./data %d %d",n[i-1],type[i-1]);
			work("./w");
			++cnt;
			work("rm %d_%d.in",i,cnt);
			work("mv w.in %d_%d.in",i,cnt);
			work("rm %d_%d.ans",i,cnt);
			work("mv w.out %d_%d.ans",i,cnt);
		}
	return 0;
}
