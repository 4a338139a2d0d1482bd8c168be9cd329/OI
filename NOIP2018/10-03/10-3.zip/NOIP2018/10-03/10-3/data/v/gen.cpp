#include<bits/stdc++.h>
using namespace std;

#define work(...) {sprintf(s,__VA_ARGS__);system(s);}
char s[1000];

inline int e(int x,int y){
	return x*pow(10,y);
}
const int test[]={4,8,3,3,3,3,7};
const int n[]={5,20,30,30,30,30,30};
const int type[]={0,0,1,2,3,4,0};

int main(){
	for(int i=1,cnt=0;i<=7;++i)
		for(int j=1;j<=test[i-1];++j){
			work("./data %d %d",n[i-1],type[i-1]);
			work("./v");
			++cnt;
			work("rm %d_%d.in",i,cnt);
			work("mv v.in %d_%d.in",i,cnt);
			work("rm %d_%d.ans",i,cnt);
			work("mv v.out %d_%d.ans",i,cnt);
		}
	return 0;
}
