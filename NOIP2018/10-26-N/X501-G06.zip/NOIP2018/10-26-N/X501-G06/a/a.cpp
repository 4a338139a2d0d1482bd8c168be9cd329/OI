#include<bits/stdc++.h>
using namespace std;
const long long maxn = 1e6;
string n;
long long lenn,fn,ans,a[maxn];
void Check(long long l)
{
	long long now;
	now = l;
	long long tmp = l;
	while(l)
	{
		now += l % 10;
		l /= 10;
	}
	if(now == fn)
		a[++ans] = tmp;
}
int main()
{
	//ios::sycn_with_stdio(0);
//	cout<<"lala"<<endl;
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	//cout<<"lala"<<endl;
	if(n == "0"){
		cout<<1<<endl;
		return 0;
	}
	lenn = n.length();
//	cout<<"lala"<<endl;
	for(int i = 0 ; i < lenn ; ++ i)
		fn = (fn << 3) + (fn << 1) + n[i] - '0';
	//cout<<"lala"<<endl;
	long long low = fn - lenn * 9;
	if(low < 0)low = 0;
	//cout<<low<<"  "<<fn<<endl;
	for(long long i = low ; i <= fn ; ++ i)
		Check(i);
	cout<<ans<<endl;
	for(int i = 1 ; i <= ans ; ++ i)
		cout<<a[i]<<endl;
	return 0;
}
