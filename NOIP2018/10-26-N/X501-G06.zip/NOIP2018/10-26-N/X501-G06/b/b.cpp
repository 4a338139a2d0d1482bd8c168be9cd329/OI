#include<bits/stdc++.h>
using namespace std;
const int maxn = 1024;
const int maxm = 1024;
const int maxk = 20;
int n,m,k,dp[2][maxn][maxm][maxk];
char s[maxn],t[maxm];
#define dp(i,j,k) max(dp[i][j][k][0],dp[i][j][k][1])
int main()
{
	//ios::sync_with_stdio(0);
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>n>>m>>k;
	scanf("%s", s+1);
	scanf("%s", t+1);
	for(int i = 1 ; i <= n ; ++ i)
		for(int j = 1 ; j <= m ; ++ j)
			for(int l = 1 ; l <= k ; ++ l)
			{
				if(s[i] == t[j]){
					dp[i][j][l][1] = max(dp[i][j][l][1],max(dp[i - 1][j - 1][l - 1][0] , dp[i - 1][j - 1][l][1]) + 1);
				}
				dp[i][j][l][0] = max(dp[i][j][l][0],max(dp(i - 1,j,l),max(dp(i,j - 1,l),dp(i - 1,j - 1,l))));
				
			}
	int ans = max(dp[n][m][k][0],dp[n][m][k][1]);
	cout<<ans<<endl;
	return 0;
}
