#include<bits/stdc++.h>
using namespace std;
const int maxn = 5e5 + 10;
int n,a[maxn],q;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int T;
	cin>>T;
	while(T--)
	{
		cin>>n>>q;
		for(int i = 1 ; i <= n ; ++ i)
			cin>>a[i];
		while(q--)
		{
			int ans = 0;
			int l;int r;
			int res;
			cin>>l>>r;
			for(int i = l ; i <= r ; ++ i)
				for(int j = i ; j <= r ; ++ j)
				{
					res = a[i];
					for(int k = i + 1 ; k <= j ; ++ k)
						res &= a[k];
					if(sqrt(res) * sqrt(res) == res)ans++;
				}
			cout<<ans<<endl;
		}
	}
	return 0;
}
