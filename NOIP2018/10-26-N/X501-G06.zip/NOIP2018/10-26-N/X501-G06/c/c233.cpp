#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e3 + 10;
int n,a[maxn],sum[maxn * 4],q,ans;
int res[maxn][maxn];
void build(int k,int l,int r)
{
	if(l == r){
		sum[k] = a[l];
		return;
	}
	int mid = l + r >> 1;
	build(k << 1,l,mid);
	build(k << 1 | 1,mid + 1,r);
	sum[k] = sum[k << 1] & sum[k << 1|1];
}
int query(int k,int l,int r,int x,int y)
{
	int res = 1 << 30 - 1;
	if(l >= x and r <= y)return sum[k];
	int mid = l + r >> 1;
	if(mid >= x)res &= query(k << 1 , l , mid , x , y);
	if(mid < y)res &= query(k << 1|1,mid+1 ,r, x , y);
	//cout<<"lala"<<endl;
	return res;
}
bool Check(int now)
{
	cout<<now<<endl;
	int sq = sqrt(now);
	if(sq * sq == now)return 1;
	return 0;
}
int main()
{
	freopen("c.in","r",stdin);
	//freopen("c.out","w",stdout);
	ios::sync_with_stdio(0);
	int T;
	cin>>T;
	while(T--)
	{
		cin>>n>>q;
		for(int i = 1 ; i <= n ; ++ i)
			cin>>a[i];
		build(1,1,n);
		//cout<<"lala"<<endl;
		for(int i = 1 ; i <= n ; ++ i)
			for(int j = i ; j <= n ; ++ j)
				if(Check(query(1,1,n,i,j)))res[i][j] = 1;
		while(q--)
		{
			ans = 0;
			int l,r;
			cin>>l>>r;
			for(int i = l ; i <= r ; ++ i)
				for(int j = i ; j <= r ; ++ j)
					ans += res[i][j];
			cout<<ans<<endl;
		}
	}
	return 0;
}
