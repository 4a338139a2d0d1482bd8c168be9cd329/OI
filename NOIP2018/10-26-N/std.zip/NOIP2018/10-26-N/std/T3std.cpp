#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
bool Finish_read;
template<class T>inline void read(T &x){Finish_read=0;x=0;int f=1;char ch=getchar();while(!isdigit(ch)){if(ch=='-')f=-1;if(ch==EOF)return;ch=getchar();}while(isdigit(ch))x=x*10+ch-'0',ch=getchar();x*=f;Finish_read=1;}
template<class T>inline void print(T x){if(x/10!=0)print(x/10);putchar(x%10+'0');}
template<class T>inline void writeln(T x){if(x<0)putchar('-');x=abs(x);print(x);putchar('\n');}
template<class T>inline void write(T x){if(x<0)putchar('-');x=abs(x);print(x);}
/*================Header Template==============*/
const int maxn=400010,maxm=10000010;
int n,m,a[maxn],data_cnt,val[maxn],len,fa[maxn][21],w[maxn],id[maxn],node_cnt,bgn[maxn],nxt[maxn],to[maxn],E,Base2[maxn],Max2,ans,root[maxn],lc[maxm],rc[maxm],sum[maxm],tot;
struct data {
	int x,id;
	data(int A=0,int B=0):x(A),id(B){}
	inline bool operator < (const data &rhs) const {
		return x<rhs.x;
	}
}da[maxn];
struct Query {
	int type,x,y,z;
	Query(int A=0,int B=0,int C=0,int D=0):type(A),x(B),y(C),z(D){}
}q[maxn];
inline int lowbit(int x) {
	return x&(-x);
}
inline void add_edge(int u,int v) {
	nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;
}
inline void add_tree(int now,int pre,int x) {
	int l=1,r=len;
	sum[now]=sum[pre]+1;
	while(l<r) {
		int mid=(l+r)/2;
		if(x<=mid)
			lc[now]=++tot,rc[now]=rc[pre],pre=lc[pre],r=mid;
		else
			lc[now]=lc[pre],rc[now]=++tot,pre=rc[pre],l=mid+1;
		sum[now=tot]=sum[pre]+1;
	}
}
inline void dfs(int u) {
	for(int i=1;i<=Max2;++i)
		fa[u][i]=fa[fa[u][i-1]][i-1];
	for(int v,i=bgn[u];i;i=nxt[i]) {
		v=to[i];
		add_tree(root[v]=++tot,root[u],w[v]);
		dfs(v);
	}
}
inline int find_fa(int x,int k) {
	for(;k;k-=lowbit(k))
		x=fa[x][Base2[lowbit(k)]];
	return x;
}
inline void Query_tree(int x,int y,int k) {
	x=root[x],y=root[y];
	int l=1,r=len;
	while(l<r) {
		int mid=(l+r)>>1;
		int h=sum[lc[x]]-sum[lc[y]];
		if(k<=h)
			r=mid,x=lc[x],y=lc[y];
		else
			l=mid+1,x=rc[x],y=rc[y],k-=h;
	}
	printf("%d\n",val[l]);
}
int main() {
//	freopen("in","r",stdin);
//	freopen("ans","w",stdout);
	read(n),read(m);
	for(Max2=Base2[1]=0;(1<<Max2)<n+m;++Max2)
		Base2[1<<Max2]=Max2;
	for(int i=1;i<=n;++i)
		read(a[i]),da[++data_cnt]=data(a[i],i);
	for(int i=1,type,x,y,z;i<=m;++i) {
		read(type);
		if(type==2)
			read(x),da[++data_cnt]=data(x,n+i);
		else if(type==3)
			read(x),read(y),read(z);
		q[i]=Query(type,x,y,z);
	}
	sort(da+1,da+data_cnt+1);
	for(int i=1;i<=data_cnt;++i) {
		if(da[i].x!=da[i-1].x)
			val[++len]=da[i].x;
		if(da[i].id>n)
			q[da[i].id-n].x=len;
		else
			a[da[i].id]=len;
	}
	w[node_cnt=1]=0;
	for(int i=n;i;--i) {
		w[++node_cnt]=a[i];
		add_edge(node_cnt-1,node_cnt);
		fa[node_cnt][0]=node_cnt-1;
	}
	int now=node_cnt;
	for(int i=1;i<=m;++i) {
		int type=q[i].type;
		if(type==1)
			now=fa[now][0];
		else if(type==2) {
			add_edge(now,++node_cnt);
			fa[node_cnt][0]=now;
			w[node_cnt]=q[i].x;
			now=node_cnt;
		}
		else
			id[i]=now;
	}
	dfs(1);
	for(int i=1;i<=m;++i)
		if(q[i].type==3)
			Query_tree(find_fa(id[i],q[i].x-1),find_fa(id[i],q[i].y),q[i].z);
//	cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
