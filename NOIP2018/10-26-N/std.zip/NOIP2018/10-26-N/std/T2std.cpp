#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
bool Finish_read;
template<class T>inline void read(T &x){Finish_read=0;x=0;int f=1;char ch=getchar();while(!isdigit(ch)){if(ch=='-')f=-1;if(ch==EOF)return;ch=getchar();}while(isdigit(ch))x=x*10+ch-'0',ch=getchar();x*=f;Finish_read=1;}
template<class T>inline void print(T x){if(x/10!=0)print(x/10);putchar(x%10+'0');}
template<class T>inline void writeln(T x){if(x<0)putchar('-');x=abs(x);print(x);putchar('\n');}
template<class T>inline void write(T x){if(x<0)putchar('-');x=abs(x);print(x);}
/*================Header Template==============*/
typedef pair<int,int> pii;
#define Mk make_pair
#define X first
#define Y second
const int maxn=1010;
int n,m,q,k,ans,x,y;
char vis[maxn],C[65536];
queue<pii>Q;
vector<int>G[maxn];
struct Bitset {
	unsigned int a[32];
	inline void add(unsigned short x) {
		a[x>>5]|=1<<(x&31);
	}
	inline int count() {
		unsigned short ans=0;
		for(int i=0;i<32;i++)
			ans+=C[a[i]>>16]+C[a[i]&65535];
		return ans;
	}
}f[maxn][maxn],res;
inline void operator | (Bitset &k,const Bitset &b) {
	for(int i=0;i<32;i++)
		k.a[i]|=b.a[i];
}
inline void add(int x,int y,int z) {
	if(!vis[x])
		vis[x]=1,Q.push(Mk(x,z)),f[y][z].add(x);
}
int main() {
	read(n),read(m),read(q);
	while(m--)
		read(x),read(y),G[x].push_back(y),G[y].push_back(x);
	for(int i=0;i<65536;i++)
		for(int j=0;j<16;j++)
			if((i>>j)&1)
				C[i]++;
	for(int i=1;i<=n;i++) {
		int nd=0;
		memset(vis,0,sizeof vis);
		add(i,i,0);
		while(!Q.empty()) {
			pii now=Q.front();
			Q.pop();
			if(now.Y!=nd)
				f[i][now.Y]|f[i][nd],nd=now.Y;
			for(int j=0;j<(int)G[now.X].size();j++)
				add(G[now.X][j],i,now.Y+1);
		}
		for(int j=nd+1;j<=n;j++)
			f[i][j]=f[i][j-1];
	}
	while(q--) {
		int k;
		read(k);
		for(int i=0;i<32;i++)
			res.a[i]=0;
		while(k--)
			read(x),read(y),res|f[x][min(y,n)];
		printf("%d\n",(int)res.count());
	}
//	cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
