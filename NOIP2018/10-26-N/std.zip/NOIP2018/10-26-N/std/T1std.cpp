#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
bool Finish_read;
template<class T>inline void read(T &x){Finish_read=0;x=0;int f=1;char ch=getchar();while(!isdigit(ch)){if(ch=='-')f=-1;if(ch==EOF)return;ch=getchar();}while(isdigit(ch))x=x*10+ch-'0',ch=getchar();x*=f;Finish_read=1;}
template<class T>inline void print(T x){if(x/10!=0)print(x/10);putchar(x%10+'0');}
template<class T>inline void writeln(T x){if(x<0)putchar('-');x=abs(x);print(x);putchar('\n');}
template<class T>inline void write(T x){if(x<0)putchar('-');x=abs(x);print(x);}
/*================Header Template==============*/
const ll mod=998244353;
namespace {
    inline ll Pow(ll a,ll b) {
        ll res=1;
        while(b) {
            if(b&1)
                res=res*a%mod;
            a=a*a%mod;
            b>>=1;
        }
        return res;
    }
    inline ll Inv(const ll &x) {
        return Pow(x,mod-2);
    }
    inline ll Add(const ll &x,const ll &y) {
        ll res=x+y;
        if(res>=mod)
            res-=mod;
        return res;
    }
    inline ll Sub(const ll &x,const ll &y) {
        ll res=x-y;
        if(res<0)
            res+=mod;
        return res;
    }
    inline ll Mul(const ll &x,const ll &y) {
        ll res=x*y;
        if(res>=mod)
            res%=mod;
        return res;
    }
    inline ll Div(const ll &x,const ll &y) {
        ll res=x*Inv(y);
        if(res>=mod)
            res%=mod;
        return res;
    }
}
const int maxn=10000001;
ll inv[maxn],sum[maxn],n;
int T;
int main() {
	inv[0]=inv[1]=1;
	for(int i=2;i<maxn;++i)
		inv[i]=Mul(inv[mod%i],(mod-mod/i));
	for(int i=2;i<maxn;++i)
		inv[i]=Add(inv[i],inv[i-1]);
	read(T);
	while(T--)
		read(n),printf("%lld\n",Sub(n,inv[n]));
}
