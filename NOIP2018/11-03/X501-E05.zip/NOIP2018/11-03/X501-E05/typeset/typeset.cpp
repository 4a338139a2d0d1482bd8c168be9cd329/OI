#include<bits/stdc++.h>
using namespace std;

const int MAXN=1e6+10;
int t,n,m;
int a[MAXN],b[MAXN];
bool vis[MAXN],pd;


bool check()
{
	for(int i=1;i<=n;i++)
	{
		if(b[i]*b[i-1]%m!=0) return 0;
	}
	for(int i=1;i<=n;i++)
	{
		if(b[i]*b[i+1]%m!=0) return 0;
	}
	return 1;
}

void dfs(int now)
{
	if(pd==1) return;
	if(now==n+1)
	{
		if(check())
			pd=1;
		return;
	}
	
	for(int i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			vis[i]=1;
			b[now]=a[i];
			dfs(now+1);
			vis[i]=0;
		}
	}
}

int main()
{
	//freopen("typeset.in", "r", stdin);
	cin>>t;
	while(t--)
	{
		memset(vis,0,sizeof(vis));
		pd=0;
		cin>>n>>m;
		for(int i=1;i<=n;i++)
			cin>>a[i];
		m=pow(2,m);
		dfs(1);
		if(pd==1) cout<<"Yes"<<endl;
			else cout<<"No"<<endl;
	}	
	return 0;
}
