#include <bits/stdc++.h>

#define y1 GKK
#define Set(a, b) memset(a, b, sizeof (a))
#define For(i, j, k) for (register int i = j; i <= k; ++ i)
#define Forr(i, j, k) for (register int i = j; i >= k; -- i)

using namespace std;

template <typename T> inline bool chkmin(T &a, T b) { return a > b ? a = b, 1 : 0; }
template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }

inline void File() {
	freopen("haner.in", "r", stdin);
	freopen("haner.out", "w", stdout);
}

const int N = 40 + 2, inf = 0x3f3f3f3f;
char str[N][N];

int n, m, sx, sy, s[N][N], f[N][N][N][N];

inline int sum(int a, int b, int c, int d) {
	if (a > c || b > d) return 0;
	return s[c][d] - s[a - 1][d] - s[c][b - 1] + s[a - 1][b - 1];
}

int main() {
	File();

	cin >> n >> m;
	For(i, 1, n) scanf("%s", str[i] + 1);

	For(i, 1, n) For(j, 1, m) {
		if (str[i][j] == 'H') sx = i, sy = j;
		s[i][j] = s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1] + (str[i][j] == '#');
	}

	Set(f, inf), f[1][1][n][m] = 0;
	
	int ans = inf;

	For(x1, 1, sx) For(y1, 1, sy) Forr(x2, n, sx) Forr(y2, m, sy) {

		int t = min(min(sum(x1, y1, sx, sy), sum(sx, sy, x2, y2)), min(sum(sx, y1, x2, sy), sum(x1, sy, sx, y2)));
		ans = min(ans, f[x1][y1][x2][y2] + t);

		For(mx, x1, x2) For(my, y1, y2) {
			if (mx >= sx && my >= sy)
				chkmin(f[x1][y1][mx][my], f[x1][y1][x2][y2] + sum(x1, my + 1, mx, y2) + sum(mx + 1, y1, x2, my));

			if (mx >= sx && my <= sy)
				chkmin(f[x1][my][mx][y2], f[x1][y1][x2][y2] + sum(x1, y1, mx, my - 1) + sum(mx + 1, my, x2, y2));

			if (mx <= sx && my <= sy)
				chkmin(f[mx][my][x2][y2], f[x1][y1][x2][y2] + sum(x1, my, mx - 1, y2) + sum(mx, y1, x2, my - 1));

			if (mx <= sx && my >= sy)
				chkmin(f[mx][y1][x2][my], f[x1][y1][x2][y2] + sum(x1, y1, mx - 1, my) + sum(mx, my + 1, x2, y2));
		}
	}

	cout << ans << endl;

	return 0;
}

