#include <bits/stdc++.h>
#define For(i, j, k) for(int i = j; i <= k; ++ i)
using namespace std;

inline int read() {
	int x = 0, p = 1; char c = getchar();
	while (!isdigit(c)) { if(c == '-') p = -1; c = getchar(); }
	while (isdigit(c)) x = (x << 1) + (x << 3) + (c ^ 48), c = getchar();
	return x *= p;
}

inline void File() {
	freopen("typeset.in", "r", stdin);
	freopen("typeset.out", "w", stdout);
}

const int N = 1e5 + 10, M = 30 + 10;
int n, A[N], tmp[N], m;

int main() {
	File();
	int Case = read();
	while (Case --) {
		memset(A, 0, sizeof A);
		n = read(), m = read();
		For(i, 1, n) {
			int x = read();
			while (x % 2 == 0) x /= 2, ++ A[i];
		}
		sort(A + 1, A + 1 + n);

		int cnt = 0;
		For(i, 1, n + 1 >> 1) {
			tmp[++cnt] = A[i], tmp[++cnt] = A[n + 1 - i];
			if(i == n + 1 - i) -- cnt;
		}

		int flag = 1;
		For(i, 1, n - 1) if (tmp[i] + tmp[i + 1] < m) flag = 0;
		printf("%s\n", flag ? "Yes" : "No");
	}
	return 0;
}

