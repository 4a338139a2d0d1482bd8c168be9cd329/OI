#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (r);i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (l);i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
const int N = 2e3 + 10,mod = 998244353;

int F[N],G[N],fac[N],inv[N];

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

inline int fpm(int a,int b) {
	int res = 1;
	while(b) {
		if(b & 1) res = 1ll * res * a % mod;
		a = 1ll * a * a % mod,b /= 2;
	}
	return res;
}

inline int Mod(int val) {
	if(val >= mod) val -= mod;
	if(val < 0) val += mod;
	return val;
}

inline int C(int n,int m) {
	return 1ll * fac[n] * inv[m] % mod * inv[n - m] % mod;
}

inline void init(int n) {
	fac[0] = 1;
	For(i,1,n) fac[i] = 1ll * fac[i - 1] * i % mod;
	inv[n] = fpm(fac[n],mod - 2);
	Fordown(i,n,1) inv[i - 1] = 1ll * inv[i] * i % mod;
}

inline int Calc(int n,int k) {
	memset(G,0,sizeof(G));
	G[0] = 1;
	For(i,1,n) For(j,1,min(i,k))
		G[i] = (G[i] + 1ll * G[i - j] * C(n - i + j - 1,j - 1) % mod * F[j]) % mod;
	return G[n];
}

int main() {
#ifndef ONLINE_JUDGE
//	freopen("bomb.in","r",stdin);
//	freopen("bomb.out","w",stdout);
#endif

	int n = read(),k = read();
	init(n);
	For(i,1,k) {
		F[i] = fpm(2,i * (i - 1) / 2);
		For(j,1,i - 1)
			F[i] = Mod(F[i] - 1ll * C(i - 1,j - 1) * fpm(2,(i - j) * (i - j - 1) / 2) % mod * F[j] % mod);
	}

	printf("%d\n",(Calc(n,k) - Calc(n,k - 1) + mod) % mod);
	return 0;
}
