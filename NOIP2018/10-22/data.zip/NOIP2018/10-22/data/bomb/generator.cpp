#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (int)r;i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (int)l;i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
int MaxN[] = {0,4,5,5,190,200,2000,2000,1900,1999,2000};
int MinN[] = {0,4,5,5,180,190,1990,1990,1800,1900,2000};
int MinK[] = {0,2,3,4,100,100,0,0,1000,1000,1900};

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

random_device rd;

inline ll randll(ll l,ll r) {
	return (((1ll * rd()) << 31ll) | rd()) % (r - l + 1) + l;
}

inline int randint(int l,int r) {
	return rd()%(r - l + 1) + l;
}

inline double randdb(double l,double r) {
	return (1.0 * rd() / (1ll << 31ll)) * (r - l) + l;
}

string name = "bomb",in = ".in",out = ".out",ans = ".ans";

string Trans(int sum) {
	string str;
	for(;sum;sum /= 10)str += (char)(sum%10+48);
	reverse(str.begin(),str.end());
	return str;
}

int main() {
	For(Case,1,10) {
		freopen((name + Trans(Case) + in).c_str(),"w",stdout);
		int n = randint(MinN[Case],MaxN[Case]),k = randint(MinK[Case],n);
		if(Case == 6) k = 1;
		if(Case == 7) k = n;
		printf("%d %d\n",n,k);
	}
	return 0;
}
