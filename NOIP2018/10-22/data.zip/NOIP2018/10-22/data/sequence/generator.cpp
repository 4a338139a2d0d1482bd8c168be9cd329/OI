#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (int)r;i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (int)l;i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
int MaxN[] = {0,900,950,990,1000,90000,99000,100000,490000,499900,500000};
int MinN[] = {0,800,900,950,990,80000,90000,99000,480000,490000,500000};
int MaxM[] = {0,900,950,990,1000,90000,99000,100000,490000,499900,500000};
int MinM[] = {0,800,900,950,990,80000,90000,99000,480000,490000,500000};
int MaxK[] = {0,10,10,10,10,1,10,10,20,20,20};
int MinK[] = {0,0,0,0,0,1,0,0,0,0,0};

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

random_device rd;

inline ll randll(ll l,ll r) {
	return (((1ll * rd()) << 31ll) | rd()) % (r - l + 1) + l;
}

inline int randint(int l,int r) {
	return rd()%(r - l + 1) + l;
}

inline double randdb(double l,double r) {
	return (1.0 * rd() / (1ll << 31ll)) * (r - l) + l;
}

string name = "sequence",in = ".in",out = ".out",ans = ".ans";

string Trans(int sum) {
	string str;
	for(;sum;sum /= 10)str += (char)(sum%10+48);
	reverse(str.begin(),str.end());
	return str;
}

int main() {
	For(Case,1,10) {
		freopen((name + Trans(Case) + in).c_str(),"w",stdout);
		int n = randint(MinN[Case],MaxN[Case]),m = randint(MinM[Case],MaxM[Case]);
		printf("%d %d\n",n,m);
		For(i,1,m) {
			int l = randint(1,n),r = randint(1,n),k = randint(MinK[Case],MaxK[Case]);
			if(Case >= 8 && Case <= 10) {
				int val = randint(1,10);
				if(val <= 9) k = randint(18,20);
				else k = randint(0,20);
			}
			if(l > r) swap(l,r);
			printf("%d %d %d\n",l,r,k);
		}
	}
	return 0;
}
