#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (r);i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (l);i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
const int N = 5e5 + 20 + 5,K = 20 + 5,mod = 1e9 + 7;

int Delta[N][K],C[N][K],fac[N],inv[N];

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

inline int Mod(int val) {
	if(val >= mod) val -= mod;
	return val;
}

inline void Init(int n,int m) {
	For(i,0,n) C[i][0] = 1;
	For(i,0,m) C[i][i] = 1;
	For(i,1,n) For(j,1,m - 1) C[i][j] = Mod(C[i - 1][j] + C[i - 1][j - 1]);
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
#endif

	int n = read(),m = read(),Lim = 20;
	Init(n + Lim + 1,Lim + 1);
	For(i,1,m) {
		int l = read(),r = read(),k = read(),Len = r - l + 1,step = 1;
		Delta[l][Lim - k]++;
		Delta[r + 1][Lim - k]--;
		For(j,Lim - k + 1,Lim)
			Delta[r + 1][j] = Mod(Delta[r + 1][j] + mod - C[Len + step - 1][step]),step++;
	}

	For(i,1,n) For(j,0,Lim) {
		Delta[i][j] = Mod(Delta[i][j] + Delta[i - 1][j]);
		if(j) Delta[i][j] = Mod(Delta[i][j] + Delta[i][j - 1]);
	}
	For(i,1,n) printf("%d\n",(Delta[i][Lim] + mod) % mod);
	return 0;
}
