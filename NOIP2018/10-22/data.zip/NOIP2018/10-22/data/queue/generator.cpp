#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (int)r;i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (int)l;i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
const int N = 1e5 + 10;

int MaxN[] = {0,0,1800,1900,1950,1990,2000,59000,60000,58000,59000,59900,60000,59000,60000,90000,95000,98000,99000,99900,100000};
int MinN[] = {0,0,1500,1800,1900,1950,1990,58000,59000,55000,58000,59000,59900,59000,60000,80000,90000,95000,98000,99000,100000};
int MaxQ[] = {0,0,1800,1900,1950,1990,2000,59000,60000,58000,59000,59900,60000,59000,60000,90000,95000,98000,99000,99900,100000};
int MinQ[] = {0,0,1500,1800,1900,1950,1990,58000,59000,55000,58000,59000,59900,59000,60000,80000,90000,95000,98000,99000,100000};
int type[] = {0,0,0,0,0,0,0,1,1,2,2,2,2,0,0,0,0,0,0,0,0};

int a[N],cur[N];

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

random_device rd;

inline ll randll(ll l,ll r) {
	return (((1ll * rd()) << 31ll) | rd()) % (r - l + 1) + l;
}

inline int randint(int l,int r) {
	return rd()%(r - l + 1) + l;
}

inline double randdb(double l,double r) {
	return (1.0 * rd() / (1ll << 31ll)) * (r - l) + l;
}

string name = "queue",in = ".in",out = ".out",ans = ".ans";

string Trans(int sum) {
	string str;
	for(;sum;sum /= 10) str += (char)(sum % 10 + 48);
	reverse(str.begin(),str.end());
	return str;
}

int main() {
	srand(rd());
	For(Case,1,20) {
		freopen((name + Trans(Case) + in).c_str(),"w",stdout);
		int n = randint(MinN[Case],MaxN[Case]),q = randint(MinQ[Case],MaxQ[Case]);
		printf("%d %d\n",n,q);
		For(i,1,n) cur[i] = i;
		random_shuffle(cur + 1,cur + n + 1);
		For(i,n + 1,100000) cur[i] = cur[i - n];
		if(type[Case] == 2) {
			For(i,1,n) a[i] = i;
			random_shuffle(a + 1,a + n + 1);
			For(i,1,n) printf("%d%c",a[i],i == iend ? '\n' : ' ');
		} else {
			For(i,1,n) {
				int val = randint(1,100);
				if(val <= 50) a[i] = cur[1];
				else if(val <= 75) a[i] = cur[randint(2,100)];
				else if(val <= 90) a[i] = cur[randint(101,10000)];
				else a[i] = cur[randint(10001,100000)];
				printf("%d%c",a[i],i == iend ? '\n' : ' ');
			}
		}
		For(i,1,q) {
			int opt = randint(1,2);
			if(opt == 1) {
				if(type[Case] == 1) printf("1 1 %d\n",n);
				else {
					int l,r;
					if(randint(1,10) == 1) {
						l = randint(1,n),r = randint(1,n);
						if(l > r) swap(l,r);
					} else l = randint(1,n / 4),r = randint(n - n / 4,n);
					printf("1 %d %d\n",l,r);
				}
			}
			if(opt == 2) {
				int l,r,val = randint(1,100),k;
				if(randint(1,10) == 1) {
					l = randint(1,n),r = randint(1,n);
					if(l > r) swap(l,r);
				} else l = randint(1,n / 4),r = randint(n - n / 4,n);
				if(type[Case] == 2) k = randint(1,n);
				else {
					if(val <= 50) k = cur[1];
					else if(val <= 75) k = cur[randint(2,100)];
					else if(val <= 90) k = cur[randint(101,10000)];
					else k = cur[randint(10001,100000)];
				}
				printf("2 %d %d %d\n",l,r,k);
			}
		}
	}
	return 0;
}
