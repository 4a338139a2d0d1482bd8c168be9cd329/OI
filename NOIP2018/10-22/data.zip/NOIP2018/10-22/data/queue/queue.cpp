#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (r);i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (l);i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
const int N = 1e5 + 10,Blk = 500;

int Sum[Blk][N],St[Blk],Ed[Blk],tot[N],a[N],id[N];
deque <int> Q[Blk];

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

int main() {
#ifndef ONLINE_JUDGE
//	freopen("queue.in","r",stdin);
//	freopen("queue.out","w",stdout);
#endif

	int n = read(),m = read(),cnt = 0;
	For(i,1,n) a[i] = read();

	For(i,1,n) {
		if(i % Blk == 1) St[++cnt] = i;
		if(i % Blk == 0 || i == n) Ed[cnt] = i;
		id[i] = cnt;
	}
	For(i,1,cnt) {
		memset(tot,0,sizeof(tot));
		For(j,St[i],Ed[i]) Sum[i][a[j]]++,Q[i].push_back(a[j]);
	}
	For(i,1,m) {
		int type = read();
		if(type == 1) {
			int l = read(),r = read();
			int L = id[l],R = id[r],Las = Q[L].back(),val = Q[R][r - St[R]];
			Sum[R][Q[R][r - St[R]]]--;
			Q[R].erase(Q[R].begin() + (r - St[R]));
			For(j,L + 1,R) {
				Sum[j - 1][Las]--,Q[j - 1].pop_back();
				Sum[j][Las]++,Q[j].push_front(Las);
				Las = Q[j].back();
			}
			Sum[L][val]++,Q[L].insert(Q[L].begin() + (l - St[L]),val);
		} else {
			int l = read(),r = read(),k = read();
			int L = id[l],R = id[r],ans = 0;
			if(L == R) {
				For(j,l - St[L],r - St[R]) ans += (Q[L][j] == k);
			} else {
				For(j,L + 1,R - 1) ans += Sum[j][k];
				For(j,l - St[L],Q[L].size() - 1) ans += (Q[L][j] == k);
				For(j,0,r - St[R]) ans += (Q[R][j] == k);
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
