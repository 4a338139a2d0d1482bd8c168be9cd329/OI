#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cctype>

using namespace std;
typedef long long LL;
int n, q;

inline int read() {
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}

inline void subtask1() {
	int a, b;
	for (int i=1; i<=n-1; i++)
	    a=read(), b=read();
	return;
}

inline void subtask2() {
	int f, w, a, b, s, cz;
	f=read(), w=read();
    if (f==1) {
    	for (int i=1; i<=q; i++) {
    	    cz=read();
			if (cz==2) a=read(), w=read();	
			if (cz==1) {
				a=read(), b=read(), s=read();
				if (a!=b) {
					if (s==w) cout << "inf" << endl;
					else cout << "none" << endl;
				}
				else {
					if (a==1) {
						if (s % 2!=0) cout << "none" << endl;
						else cout << s/2 << endl; 
					}
					else {
						if (s % 2!=0) cout << "none" << endl;
						else {
							int co=s/2;
							co=w-co;
							cout << co << endl;
						}
					}
				}
			}
		}
	} else 
	for (int i=1; i<=q; i++){
		cz=read();
		if (cz==2) a=read(), w=read(); 
		else {
		a=read(), b=read(), s=read();
		if (w % 2!=0) cout << "none" << endl; else{    
		    {
				if (a!=b) {
					int co=s-w/2;
					cout << co << endl;
				}
				if (a==b) {
					if (a==2) if (s==w) cout << "inf" << endl; else cout << "none" << endl;
					if (a==1) if (s % 2==0) cout << s/2 << endl; else cout << "none" << endl;
				}
			}	
		}
	    }
	}
	return;
}

int main() {
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	n=read(); q=read();
	if (q==0) {subtask1(); return 0;}
	if (n==2) {subtask2(); return 0;}
	fclose(stdin);
	fclose(stdout);
	return 0;
}




