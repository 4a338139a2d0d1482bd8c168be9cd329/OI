#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cctype>

using namespace std;
typedef long long LL;
const LL mod=1000000007;
LL n, ans, now=0;
struct jyh_orz {
    LL x, y;
} a[10011];

struct lxt_orz {
    LL le, dw, ri, up;
} used[100011]; 

inline LL read() {
    LL X=0,w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}

void get_ans(LL i, LL f, LL l, LL d, LL r, LL u, LL m) {
	if (i>n+1) return; 
	if (f==0) {
		get_ans(i+1, 0, l, d, r, u, m);
		get_ans(i+1, 1, l, d, r, u, m);
		return;
	} else
	if (m==0) {
		get_ans(i+1, 0, a[i].x, a[i].y, a[i].x, a[i].y, m+1);
		get_ans(i+1, 1, a[i].x, a[i].y, a[i].x, a[i].y, m+1);
	    return;
	} else
	if (m==1) {
		LL ll=l, dd=d, rr=r, uu=u;
		if (a[i].x<ll) ll=a[i].x;
		if (a[i].x>rr) rr=a[i].x;
		if (a[i].y>uu) uu=a[i].y;
		if (a[i].y<dd) dd=a[i].y;
		get_ans(i+1, 0, ll, dd, rr, uu, m+1);
		get_ans(i+1, 1, ll, dd, rr, uu, m+1);
		return;
	}  else
	if (m>=2) {
		LL ll=l, dd=d, rr=r, uu=u;
		bool ff=false;
		for (int ii=0; ii<now; ii++) 
		    if (ll==used[ii].le && rr==used[ii].ri && uu==used[ii].up && dd==used[ii].dw)
		       {ff=true; break;}
		if (ff==false) {
			used[now].le=ll, used[now].ri=rr, used[now].up=uu, used[now].dw=dd;
		    now++;
            ans=(ans+(rr-ll)*(uu-dd)) % mod;	
		}
		if (a[i].x<ll) ll=a[i].x;
		if (a[i].x>rr) rr=a[i].x;
		if (a[i].y>uu) uu=a[i].y;
		if (a[i].y<dd) dd=a[i].y;
		get_ans(i+1, 0, ll, dd, rr, uu, m+1);
		get_ans(i+1, 1, ll, dd, rr, uu, m+1);
		return;
	}   else
	return;
}

int main() {
	freopen("rectangle.in", "r", stdin);
	freopen("rectangle.out", "w", stdout);
	n=read(); ans=0;
	for (int ii=1; ii<=n; ii++) a[ii].x=read(), a[ii].y=read();	
    get_ans(1, 0, -1, -1, -1, -1, 0);
	get_ans(1, 1, -1, -1, -1, -1, 0);
	cout << ans << endl;
	return 0;
}



