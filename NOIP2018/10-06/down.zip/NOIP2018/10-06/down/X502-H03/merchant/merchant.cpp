#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cctype>

using namespace std;
typedef long long LL;
const LL max_ans=9999999999;
LL n, m, S, k[1000011], b[1000011], ans;

inline LL read() {
    LL X=0,w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}

inline LL div_up(int u, int v) {
//	cout << u << " " << v << " up!!" << endl;
	if (u==0) return 0; LL res=0;
	if (abs(u) % abs(v)==0) res=u/v; else
	if ((u<0 && v>0) || (u>0 && v<0)) res=u/v; else
	if ((u<0 && v<0) || (u>0 && v>0)) res=u/v, res++;
	return res;
}

inline LL div_down(int u, int v) {
//	cout << u << " " << v << " down!!" << endl;
	if (u==0) return 0; LL res=0;
	if (abs(u) % abs(v)==0) res=u/v; else
	if ((u<0 && v>0) || (u>0 && v<0)) res=u/v, res--;else
	if ((u<0 && v<0) || (u>0 && v>0)) res=u/v;
	return res;
}

void get_ans(LL i, LL f, LL k0, LL b0, LL m0){
	if (m0==m) return; if (i==n+1) return;
	if (f==0) {
		get_ans(i+1, 1, k0, b0, m0);
		get_ans(i+1, 0, k0, b0, m0);
		return;
	}
	if (f==1) {
		LL k1=k0+k[i];
		LL b1=b0+b[i];
		if (k1==0) {
			get_ans(i+1, 1, k1, b1, m0+1);
			get_ans(i+1, 0, k1, b1, m0+1);
			return;
		}
		LL x; LL bj=S-b1;
		if (k1>0) x=div_up(bj, k1);
		else x=div_down(bj, k1); 
		if (x>=0 && x<ans) ans=x;
        get_ans(i+1, 1, k1, b1, m0+1);
		get_ans(i+1, 0, k1, b1, m0+1);
		return;	
 	}
    return;	
}

inline void subtask1() {
	ans=max_ans;
	get_ans(1, 1, 0, 0, 0);
	get_ans(1, 0, 0, 0, 0);
	cout << ans << endl;
//   first line,get or not,know,bnow
	return;
}

inline void subtask2() {
	
	return;
}

inline void subtask_luan_gao() {
	
	
	return;
}

int main() {
	freopen("merchant.in", "r", stdin);
	freopen("merchant.out", "w", stdout);
    memset(k, 0, sizeof(k));
    memset(b, 0, sizeof(b));
	n=read(), m=read(), S=read();
	if (S==0) {cout << 0 << endl; return 0;}
  	bool f2=true, f3=true; 
	for (int i=1; i<=n; i++) {
	    k[i]=read(), b[i]=read();
	    if (0>k[i] || k[i]>100000) f2=false;
		if (k[i]>0) f3=false;  
    }
    if (n<=20) {subtask1(); return 0;}
    else if (f2==true && n<=100000) {subtask2(); return 0;}
    else if (f3==true) {cout << 0 << endl; return 0;}
    else subtask_luan_gao();
    fclose(stdin);
    fclose(stdout);
	return 0;
}





