#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int Read() {
	char c = getchar(); int x = 0;
	int sig = 1;
	while (c < '0' || c > '9') { if (c == '-') sig = -1; c = getchar(); }
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x * sig;
}

const int N = 1e6 + 10;

typedef long long LL;

int n, m;
LL S;

int k[N], b[N];
LL val[N];

bool check(int x) {
	For(i, 1, n) val[i] = 1ll * k[i] * x + b[i];
	nth_element(val + 1, val + m, val + n + 1, greater<LL>());
	LL sum = 0;
	For(i, 1, m) if (val[i] > 0 && (sum += val[i]) >= S) return true;
	return false;
}

int main() {

	freopen("merchant.in", "r", stdin);
	freopen("merchant.out", "w", stdout);

	n = Read(), m = Read(); scanf("%lld", &S);
	For(i, 1, n) k[i] = Read(), b[i] = Read();

	if (check(0)) { puts("0"); return 0; }

	int L = 1, R = 1e9;
	while (L < R) {
		int mid = (L + R) / 2;
		if (check(mid)) R = mid;
		else L = mid + 1;
	}
	printf("%d\n", L);

	return 0;
}
