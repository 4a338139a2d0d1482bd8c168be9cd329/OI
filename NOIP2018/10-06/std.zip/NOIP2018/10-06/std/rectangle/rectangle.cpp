#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 2510;
const int Mod = 1e9 + 7;

int n, m = 2500;

struct Binary_Indexed_Tree {

	int c[N];

	void init() {
		For(i, 1, m) c[i] = 0;
	}

	int lowbit(int x) { return x & (-x); }

	void add(int x, int w) {
		for (; x <= m; x += lowbit(x)) c[x] += w;
	}

	int sum(int x) {
		int ret = 0;
		for (; x; x -= lowbit(x)) ret += c[x];
		return ret;
	}

}T, S;

int pos[N][N];
int c[N];
bool vis[N];

void upd(int x) {
	if (vis[x]) return;
	vis[x] = true;
	T.add(x, 1), S.add(x, x);
}

int main() {

	freopen("rectangle.in", "r", stdin);
	freopen("rectangle.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) {
		int x, y;
		scanf("%d%d", &x, &y);
		pos[x][++c[x]] = y;
	}

	For(i, 1, m) sort(pos[i] + 1, pos[i] + c[i] + 1), pos[i][c[i] + 1] = m + 1;

	int ans = 0;
	For(i, 1, m) if (c[i]) {
		T.init(), S.init();
		For(j, 1, m) vis[j] = false;
		For(j, 1, c[i]) upd(pos[i][j]);
		Forr(j, i - 1, 1) if (c[j]) {
			int pa = 1, pb = 1, cur = max(pos[i][1], pos[j][1]);
			For(k, 1, c[j]) upd(pos[j][k]);
			while (pos[i][pa + 1] <= cur) ++pa;
			while (pos[j][pb + 1] <= cur) ++pb;

			while (pa <= c[i] && pb <= c[j]) {
				int nxt = min(pos[i][pa + 1], pos[j][pb + 1]), L = min(pos[i][pa], pos[j][pb]);
				ans = (ans + (1ll * (S.sum(nxt - 1) - S.sum(cur - 1)) * T.sum(L) 
							- 1ll * (T.sum(nxt - 1) - T.sum(cur - 1)) * S.sum(L)) * (i - j)) % Mod;
				cur = nxt;
				if (pos[i][pa + 1] <= cur) ++pa;
				if (pos[j][pb + 1] <= cur) ++pb;
			}
		}
	}

	printf("%d\n", ans);

	return 0;
}
