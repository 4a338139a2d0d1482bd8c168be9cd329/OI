#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int P[10010];

int main() {

	freopen("rectangle.in", "w", stdout);

	int n = 10000, m = 2500;

	printf("%d\n", n);
	For(i, 1, n) printf("%d %d\n", rand() % m + 1, rand() % m + 1);

	return 0;
}
