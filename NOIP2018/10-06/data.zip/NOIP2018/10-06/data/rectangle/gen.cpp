#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int TASK = 6, mx = 2500;
const int N[TASK] = {18, 50, 300, 2500, 2500, 10000};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

const int M = 1e4 + 10;

typedef pair<int, int> PII;

int n, m;
PII P[M];
int px[M], py[M];

int main() {

	char cmd[200];
	srand(time(0));

	For(idt, 0, TASK - 1) {
		
		sprintf(cmd, "mkdir subtask%d", idt + 1);
		system(cmd);
		cerr << "Subtask " << idt + 1 << ":\n";

		For(idc, 0, 4) {

			if (idt == 3 && idc) continue;
			if (idt < 3 && idc > 2) continue;

			sprintf(cmd, "subtask%d/rectangle%d.in", idt + 1, idc + 1);
			freopen(cmd, "w", stdout);

			n = N[idt];
			m = min(n, mx);

			if (!idc) {
				n = m; 
				For(i, 1, n) P[i] = PII(i, i), swap(P[i].second, P[randint(1, i)].second);
			}
			else if (idc == 1) For(i, 1, n) P[i] = PII(randint(1, m), randint(1, m));
			else if (idc == 2) For(i, 1, n) P[i] = PII(randint(1, m / 2), randint(1, m / 2));
			else if (idc == 3) For(i, 1, n)	P[i] = PII(randint(1, 200), randint(1, 200));
			else {
				For(i, 1, n) {
					int x = rand() % 3 == 0 ? randint(1, 20) : randint(1, m);
					int y = x > 20 && rand() % 2 ? randint(1, 20) : randint(1, m);
					P[i] = PII(x, y);
				}
			}

			For(i, 1, mx) px[i] = i, py[i] = i;
			random_shuffle(px + 1, px + mx + 1);
			random_shuffle(py + 1, py + mx + 1);
			sort(P + 1, P + n + 1);
			n = unique(P + 1, P + n + 1) - P - 1;
			random_shuffle(P + 1, P + n + 1);

			printf("%d\n", n);
			For(i, 1, n) printf("%d %d\n", px[P[i].first], py[P[i].second]);

			freopen("CON", "w", stdout);
			cerr << "Case " << idc + 1 << ":\n";
			sprintf(cmd, "time ./rectangle < subtask%d/rectangle%d.in > subtask%d/rectangle%d.out", idt + 1, idc + 1, idt + 1, idc + 1);
			system(cmd);
		}
		

	}

	return 0;
}
