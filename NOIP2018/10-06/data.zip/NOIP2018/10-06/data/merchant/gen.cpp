#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int TASK = 5, mxk = 1e6, mxb = 1e9;
const LL mxs = 1e18;
const int N[TASK] = {20, 100000, 100000, 100000, 1000000};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

const int M = 1e6 + 10;

int k[M], b[M];
long long val[M], S;
int n, m;

LL calc(int x) {
	For(i, 1, n) val[i] = 1ll * k[i] * x + b[i];
	nth_element(val + 1, val + m, val + n + 1, greater<LL>());
	LL sum = 0;
	For(i, 1, m) if (val[i] > 0) {
		sum += val[i];
		if (sum > (1ll << 61)) sum = 1ll << 61;
	}
	return sum;
}

int main() {

	char cmd[200];
	srand(time(0));

	For(idt, 0, TASK - 1) {
		
		sprintf(cmd, "mkdir subtask%d", idt + 1);
		system(cmd);
		cerr << "Subtask " << idt + 1 << ":\n";

		For(idc, 0, 3) {

			if (idt == 1 && idc > 2) continue;
			if (idt == 2 && idc > 1) continue;

			sprintf(cmd, "subtask%d/merchant%d.in", idt + 1, idc + 1);
			freopen(cmd, "w", stdout);


			n = N[idt];
			n -= randint(0, min(100, n / 20));
			m = randint(n / 4, n * 3 / 4);
			S = -1;

			if (!idc) {
				For(i, 1, n) k[i] = idt < 2 ? randint(-1e4, 1e4) : randint(-mxk, mxk);
				For(i, 1, n) b[i] = randint(-mxb, mxb);
			} else if (idc == 1 || idc == 3) {
				For(i, 1, n) k[i] = randint(-1e3, 1e3);
				For(i, 1, n) b[i] = randint(-1e6, 1e6);
				if (idc == 3) S = calc(0);
			} else if (idc == 2) {
				int mx = idt < 2 ? 1e4 : mxk;
				For(i, 1, n) k[i] = 1ll * i * mx / n, b[i] = -mxb + (2ll * mxb * i / n);
			}

			if (idt == 1) For(i, 1, n) k[i] = abs(k[i]);
			if (idt == 2) For(i, 1, n) k[i] = -abs(k[i]);

			while (S == -1) {
				int x = randint(0, int(1e9));
				if ((S = calc(x)) <= mxs || rand() % 10 == 0) S = min(S, mxs);
				else S = -1;
			}

			printf("%d %d %lld\n", n, m, S);
			For(i, 1, n) printf("%d %d\n", k[i], b[i]);

			freopen("CON", "w", stdout);
			cerr << "Case " << idc + 1 << ":\n";
			sprintf(cmd, "time ./merchant < subtask%d/merchant%d.in > subtask%d/merchant%d.out", idt + 1, idc + 1, idt + 1, idc + 1);
			system(cmd);
		}
		

	}

	return 0;
}
