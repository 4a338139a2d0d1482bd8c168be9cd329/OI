#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e6 + 10;

typedef long long LL;

int n, m;
LL S;

int k[N], b[N];
LL val[N];

bool check(int x) {
	For(i, 1, n) val[i] = 1ll * k[i] * x + b[i];
	nth_element(val + 1, val + m, val + n + 1, greater<LL>());
	LL sum = 0;
	For(i, 1, m) if (val[i] > 0 && (sum += val[i]) >= S) return true;
	return sum >= S;
}

int main() {

	scanf("%d%d%lld", &n, &m, &S);
	For(i, 1, n) scanf("%d%d", &k[i], &b[i]);

	if (check(0)) { puts("0"); return 0; }

	int L = 1, R = 1e9;
	while (L < R) {
		int mid = (L + R) / 2;
		if (check(mid)) R = mid;
		else L = mid + 1;
	}
	printf("%d\n", L);

	return 0;
}
