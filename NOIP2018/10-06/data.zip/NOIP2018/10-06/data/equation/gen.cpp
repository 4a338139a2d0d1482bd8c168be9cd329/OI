#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int TASK = 5, mxk = 1e6, mxb = 1e9;
const LL mxs = 1e18;
const int C[TASK] = {10, 2, 1000, 100000, 1000000};
const int Q[TASK] = {0, 1000000, 1000, 100000, 1000000};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

const int N = 1e6 + 10;

int n, q;

struct Binary_Indexed_Tree {

	int c[N];

	inline int lowbit(int x) {
		return x & (-x);
	}

	void add(int x, int w) {
		while (x <= n) {
			c[x] += w;
			x += lowbit(x);
		}
	}

	int sum(int x) {
		int ret = 0;
		while (x) {
			ret += c[x];
			x -= lowbit(x);
		}
		return ret;
	}

}T;

int dfn[N], rdfn[N], dep[N];
int fa[N], w[N];
vector<int> G[N];
int clk;

void DFS_init(int o) {
	dfn[o] = ++clk;
	for (int v : G[o]) dep[v] = dep[o] ^ 1, DFS_init(v);
	rdfn[o] = clk;
}

int main() {

	char cmd[200];
	srand(time(0));

	For(idt, 0, TASK - 1) {
		
		sprintf(cmd, "mkdir subtask%d", idt + 1);
		system(cmd);
		cerr << "Subtask " << idt + 1 << ":\n";

		For(idc, 0, 4) {

			if (idt < 3 && idc) continue;
			if (idt == 3 && idc >= 3) continue;

			sprintf(cmd, "subtask%d/equation%d.in", idt + 1, idc + 1);
			freopen(cmd, "w", stdout);

			n = C[idt];
			n -= randint(0, min(100, n / 20));
			q = Q[idt];

			printf("%d %d\n", n, q);
			clk = 0;
			For(i, 1, n) G[i].clear(), dep[i] = 0, T.c[i] = 0;

			if (idc == 1 || idc == 4) For(i, 2, n) fa[i] = i - 1;
			else if (idc == 2) For(i, 2, n) fa[i] = randint(max(1, i - 5), i - 1);
			else For(i, 2, n) fa[i] = randint(1, i - 1);

			For(i, 2, n) w[i] = idc == 4 ? (i & 1 ? -1000 : 1000) : randint(-1000, 1000);
			For(i, 2, n) printf("%d %d\n", fa[i], w[i]);

			For(i, 2, n) G[fa[i]].push_back(i);
			DFS_init(1);
			For(i, 2, n) if (!dep[i]) w[i] = -w[i];
			For(i, 2, n) T.add(dfn[i], w[i]), T.add(rdfn[i] + 1, -w[i]);

			while (q--) {
				int op = (idt == 3 && idc == 1) || idc == 3 ? 1 : randint(1, 2);
				if (op == 1) {
					int u = randint(1, n), v = randint(1, n), s = randint(-1e9, 1e9);
					int x = T.sum(dfn[u]), y = T.sum(dfn[v]);

					if (dep[u] != dep[v]) {
						if (dep[v]) swap(u, v), swap(x, y);
						s = rand() % 2 ? x - y : (rand() % 2 ? s : x - y + randint(-10, 10));
					}
					printf("1 %d %d %d\n", u, v, s);

				} else {
					int u = randint(2, n), nw = randint(-1000, 1000);

					printf("2 %d %d\n", u, nw);
					if (!dep[u]) nw = -nw;
					T.add(dfn[u], nw - w[u]), T.add(rdfn[u] + 1, w[u] - nw);
					w[u] = nw;
				}
			}

			freopen("CON", "w", stdout);
			cerr << "Case " << idc + 1 << ":\n";
			sprintf(cmd, "time ./equation < subtask%d/equation%d.in > subtask%d/equation%d.out", idt + 1, idc + 1, idt + 1, idc + 1);
			system(cmd);
		}
		

	}

	return 0;
}
