#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int Read() {
	char c = getchar(); int x = 0;
	int sig = 1;
	while (c < '0' || c > '9') { if (c == '-') sig = -1; c = getchar(); }
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x * sig;
}

const int N = 1e6 + 10;

int n, q;

struct Binary_Indexed_Tree {

	int c[N];

	inline int lowbit(int x) {
		return x & (-x);
	}

	void add(int x, int w) {
		while (x <= n) {
			c[x] += w;
			x += lowbit(x);
		}
	}

	int sum(int x) {
		int ret = 0;
		while (x) {
			ret += c[x];
			x -= lowbit(x);
		}
		return ret;
	}

}T;

int dfn[N], rdfn[N], dep[N];
int fa[N], w[N];
vector<int> G[N];

void DFS_init(int o) {
	static int clk = 0;
	dfn[o] = ++clk;
	for (int v : G[o]) dep[v] = dep[o] ^ 1, DFS_init(v);
	rdfn[o] = clk;
}

int main() {

	n = Read(), q = Read();
	For(i, 2, n) fa[i] = Read(), w[i] = Read(), G[fa[i]].push_back(i);
	DFS_init(1);
	For(i, 2, n) if (!dep[i]) w[i] = -w[i];
	For(i, 2, n) T.add(dfn[i], w[i]), T.add(rdfn[i] + 1, -w[i]);

	while (q--) {
		int op = Read();
		if (op == 1) {
			int u = Read(), v = Read(), s = Read();
			int x = T.sum(dfn[u]), y = T.sum(dfn[v]);

			if (dep[u] && dep[v]) {
				long long rt = 1ll * x + y - s;
				if (rt % 2) puts("none");
				else printf("%lld\n", rt / 2);
			} else if (!dep[u] && !dep[v]) {
				long long rt = 1ll * x + y + s;
				if (rt % 2) puts("none");
				else printf("%lld\n", rt / 2);
			} else {
				if (dep[v]) swap(u, v), swap(x, y);
				if (x - y == s) puts("inf");
				else puts("none");
			}

		} else {
			int u = Read(), nw = Read();
			if (!dep[u]) nw = -nw;
			T.add(dfn[u], nw - w[u]), T.add(rdfn[u] + 1, w[u] - nw);
			w[u] = nw;
		}
	}

	return 0;
}
