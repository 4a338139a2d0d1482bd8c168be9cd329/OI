#include <bits/stdc++.h>

#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)

using namespace std;

inline int read() {
    int x(0), sgn(1); char ch(getchar());
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') sgn = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * sgn;
}

void File() {
	freopen ("sequence.in", "r", stdin);
	freopen ("sequence.out", "w", stdout);
}

int dp[5];

int main () {

	File();

	int n = read();

	For (i, 1, n) {
		int val = read();
		For (j, 1, 4)
			dp[j] = max(dp[j - 1], dp[j] + ((j & 1) == (val & 1)));
	}
	printf ("%d\n", dp[4]);

    return 0;

}
