#include <bits/stdc++.h>

#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)

using namespace std;

inline int read() {
	int x = 0, fh = 1; char ch = getchar();
	for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
	for (; isdigit(ch); ch = getchar()) x = (x << 1) + (x << 3) + (ch ^ 48);
	return x * fh;
}

void File() {
	freopen ("squares.in", "r", stdin);
	freopen ("squares.out", "w", stdout);
}

int n, m;

const int Mod = 1e9 + 7;

inline int Calc(int len) { return 1ll * (n - len + 1) * (m - len + 1) % Mod; }

int main () {

	File();

	n = read(), m = read();
	if (n > m) swap(n, m);

	int ans = 0;
	For (i, 1, n)
		ans = (ans + 1ll * i * Calc(i)) % Mod;

	printf ("%d\n", ans);

	return 0;
}
