#include <bits/stdc++.h>

#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)

using namespace std;

template<typename T> inline bool chkmin(T &a, T b) {return b < a ? a = b, 1 : 0;}
template<typename T> inline bool chkmax(T &a, T b) {return b > a ? a = b, 1 : 0;}

inline int read() {
	int x(0), sgn(1); char ch(getchar());
	for (; !isdigit(ch); ch = getchar()) if (ch == '-') sgn = -1;
	for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
	return x * sgn;
}

void File() {
	freopen ("complexity.in", "r", stdin);
	freopen ("complexity.out", "w", stdout);
}

map<string, int> M;
int ans = 0; string str;

int main () {

	File();

	M["i"] = 0;
	int ans = 0;

	while (cin >> str) {
		int maxv = 0;
		string name; cin >> name;
		while (cin >> str) {
			if (str[0] == 'E') break;
			int cur = M[str];
			cin >> str;
			For (j, 0, str.size() - 1)
				if (str[j] == 'n') ++ cur;
			chkmax(maxv, cur);
		}
		chkmax(ans, maxv);
		M[name] = maxv;
	}

	if (ans == 0) return puts("O(1)"), 0;
	if (ans == 1) return puts("O(n)"), 0;
	printf ("O(n^%d)\n", ans);

	return 0;

}
