#include <bits/stdc++.h>

#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define debug(x) cout << #x << ": " << (x) << endl
#define DEBUG(...) fprintf(stderr, __VA_ARGS__)

using namespace std;

template<typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, T b) { return b > a ? a = b, 1 : 0; }

inline int read() {
    int x(0), sgn(1); char ch(getchar());
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') sgn = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * sgn;
}

string trans(int dig) {
	string str;
	for (; dig; dig /= 10)
		str += (char)(dig % 10 + 48);
	reverse(str.begin(), str.end());
	return str;
}

random_device rnd;
inline int Rand_Int(int l, int r) {
	return rnd() % (r - l + 1) + l;
}

void Generate(int id) {
	freopen (("sequence" + trans(id) + ".in").c_str(), "w", stdout);
	int n;

	if (id <= 3)
		n = Rand_Int(20, 50);
	else if (id <= 7)
		n = Rand_Int(1500, 2000);
	else
		n = Rand_Int(5e5, 1e6);
	printf ("%d\n", n);
	For (i, 1, n)
		printf ("%d%c", id == 1 ? 1 : rnd() & 1 ? 1 : 2, i == iend ? '\n' : ' ');

	cerr << "./sequence < sequence" + trans(id) + ".in > sequence" + trans(id) + ".out" << endl;
	system(("./sequence < sequence" + trans(id) + ".in > sequence" + trans(id) + ".out").c_str());
}

int main () {

	For (i, 1, 10)
		Generate(i);

	return 0;

}
