#include <bits/stdc++.h>

#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define debug(x) cout << #x << ": " << (x) << endl
#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back

using namespace std;

template<typename T> inline bool chkmin(T &a, T b) {return b < a ? a = b, 1 : 0;}
template<typename T> inline bool chkmax(T &a, T b) {return b > a ? a = b, 1 : 0;}

inline int read() {
	int x(0), sgn(1); char ch(getchar());
	for (; !isdigit(ch); ch = getchar()) if (ch == '-') sgn = -1;
	for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
	return x * sgn;
}

vector<string> dict, cur;

random_device Rand;
inline int Rand_Int(int l, int r) {
	return Rand() % (r - l + 1) + l;
}

int Cases;
map<int, bool> M;

inline int get() {
	int lim;
	if (Cases <= 3) lim = 25; else lim = dict.size() - 1;
	int cur = Rand_Int(0, lim);
	while (M[cur])
		cur = Rand_Int(0, lim);
	return cur;
}

inline string Get() {
	vector<int> V;
	for (auto cur : M) if(cur.second) V.pb(cur.first);
	return dict[V[Rand_Int(0, (int)V.size() - 1)]];
}

void Generate(int id) {
	Cases = id;
	M.clear(); M[8] = true;
	int L = Cases <= 3 ? Rand_Int(5, 10) : Rand_Int(50, 100);
	For (i, 1, L) {
		int cur = get();
		printf ("S %s\n", dict[cur].c_str());
		For (cur, 1, Cases <= 6 ? 1 : Rand_Int(1, 10)) {
			printf ("	%s ", Get().c_str());
			For (j, 1, Rand_Int(1, 20)) {
				if (Rand() & 1)
					printf ("[%d]", Rand_Int(1, 1e9));
				else 
					printf ("[n]");
			}
			putchar ('\n');
		}
		M[cur] = true; puts("E");
	}
}

string todig(int dig) {
	string cur;
	for (; dig; dig /= 10)
		cur += (char) ('0' + dig % 10);
	reverse(cur.begin(), cur.end());
	return cur;
}

int main () {

	For (i, 0, 25) {
		string cur; cur += (char)('a' + i);
		dict.pb(cur);
	}

	dict.pb("xscakioi");
	dict.pb("chuyuakioi");
	dict.pb("cyhakioi");
	dict.pb("doeakioi");
	dict.pb("dyxakioi");
	dict.pb("ymyakioi");
	dict.pb("sxyakioi");
	dict.pb("ssytsl");
	dict.pb("chuyutaichule");
	dict.pb("gaylovesgkk");

	For (i, 0, 80) {
		string str;
		int len = Rand_Int(3, 20);
		For (j, 1, len)
			str += (char)('a' + Rand_Int(0, 25));
		dict.pb(str);
	}

	For (i, 3, 10) {
		freopen (("complexity" + todig(i) + ".in").c_str(), "w", stdout);
		Generate(i);
	}

	return 0;

}
