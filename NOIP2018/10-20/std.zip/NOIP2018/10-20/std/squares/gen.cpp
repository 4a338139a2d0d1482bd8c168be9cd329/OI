#include <bits/stdc++.h>

#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define debug(x) cout << #x << ": " << x << endl
#define DEBUG(...) fprintf(stderr, __VA_ARGS__)

using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x << 1) + (x << 3) + (ch ^ 48);
    return x * fh;
}

string trans(int dig) {
	string str;
	for (; dig; dig /= 10)
		str += (char)(dig % 10 + 48);
	reverse(str.begin(), str.end());
	return str;
}

inline int Rand_Int(int l, int r) {
	return rand() % (r - l + 1) + l;
}

void Generate(int id) {
	freopen (("squares" + trans(id) + ".in").c_str(), "w", stdout);
	int n, m;
	if (id <= 3)
		n = Rand_Int(20, 50), m = Rand_Int(20, 50);
	else if (id <= 6)
		n = Rand_Int(200, 300), m = Rand_Int(200, 300);
	else if (id <= 7)
		n = 1, m = Rand_Int(5e5, 1e6);
	else if (id <= 8)
		n = 2, m = Rand_Int(5e5, 1e6);
	else
		n = Rand_Int(5e5, 1e6), m = Rand_Int(5e5, 1e6);
	printf ("%d %d\n", n, m);
	cerr << "squares < squares" + trans(id) + ".in > squares" + trans(id) + ".out" << endl;
	system(("squares < squares" + trans(id) + ".in > squares" + trans(id) + ".out").c_str());
}

int main() {

	srand(time(0));

	For (i, 1, 10) Generate(i);

	return 0;

}
