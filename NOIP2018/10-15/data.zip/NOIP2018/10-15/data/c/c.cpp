#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
template<typename T>inline bool chkmin(T &x,T y){return (y<x)?(x=y,1):0;}
template<typename T>inline bool chkmax(T &x,T y){return (y>x)?(x=y,1):0;}
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=100+5,mod=1e9+7;
string pre = "c", sufin = ".in", sufout = ".ans";
string to_digit(int x) {
	string a;
	while (x) a += (char)(x % 10 + 48), x /= 10;
	//cerr << a << endl;
	reverse(a.begin(), a.end());
	return a;
}
int id[2][2][maxn],n,tmp,a[4*maxn][4*maxn],c[4*maxn],Ans[4*maxn];
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=(ll)res*x%mod;
		x=(ll)x*x%mod;
		y>>=1;
	}
	return res;
}
void init(){
	tmp=0;
	memset(Ans,0,sizeof(Ans));
	memset(id,0,sizeof(id));
	memset(a,0,sizeof(a));
	memset(c,0,sizeof(c));
	REP(i,0,1) REP(j,0,1) REP(k,0,n-2) id[i][j][k]=++tmp;
	REP(i,0,1) REP(j,0,1) REP(k,0,n-2){
		int u=id[i][j][k];
		add(a[u][u],mod-1);
		int p=ksm(n,mod-2);
		if(j==0){
			add(a[u][id[i^1][j][k]],p);
			add(a[u][id[i^1][j^1][n-2-k]],p);
			if(k) add(a[u][id[i][j][k-1]],(ll)k*p%mod);
			if(k<n-2) add(a[u][id[i][j][k+1]],(ll)(n-2-k)*p%mod);
		}
		else{
			add(a[u][id[i^1][j^1][k]],p);
			add(a[u][id[i^1][j][n-2-k]],p);
			add(c[u],mod-p);
			if(k) add(a[u][id[i][j^1][k-1]],(ll)p*k%mod);
			if(k<n-2) add(a[u][id[i][j^1][k+1]],(ll)(n-2-k)*p%mod);
		}
		if(i==0 && k==n-2){
			REP(l,1,tmp) a[u][l]=0;
			c[u]=0;
			a[u][u]=1;
		}
	}
	REP(i,1,tmp){
		if(a[i][i]==0) REP(j,i+1,tmp) if(a[j][i]){
			swap(a[i],a[j]),swap(c[i],c[j]);
			break;
		}
		REP(j,i+1,tmp){
			int u=(ll)a[j][i]*ksm(a[i][i],mod-2)%mod;
			REP(k,i,tmp) a[j][k]=(a[j][k]-(ll)u*a[i][k]%mod+mod)%mod;
			c[j]=(c[j]-(ll)u*c[i]%mod+mod)%mod;
		}
	}
	DREP(i,tmp,1){
		Ans[i]=(ll)c[i]*ksm(a[i][i],mod-2)%mod;
		DREP(j,i-1,1) c[j]=(c[j]-(ll)Ans[i]*a[j][i]%mod+mod)%mod;
	}
}
char s[maxn];
int main(){
	REP (_, 1, 20) {
		freopen ((pre + to_digit(_) + sufin).c_str(), "r", stdin);
		freopen ((pre + to_digit(_) + sufout).c_str(), "w", stdout);
		n=read();
		init();
		int T=read();
		while(T--){
			int k=read(),num=0,ans=0;
			scanf("%s",s+1);
			REP(i,1,n) num+=(s[i]=='1');
			REP(i,1,n)
				REP(j,1,n) if(i!=j){
					ans=(ans+(ll)Ans[id[s[i]!=s[j]][i==k][s[i]=='1'?(num-1-(s[j]-'0')):(n-num-1-(s[j]=='0'))]]*abs(i-j))%mod;
				}
			printf("%d\n",ans);
		}
	}
	return 0;
}
