#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
random_device rd;
#define rand rd
string pre = "c", sufin = ".in", sufout = ".ans";
string to_digit(int x) {
	string a;
	while (x) a += (char)(x % 10 + 48), x /= 10;
	//cerr << a << endl;
	reverse(a.begin(), a.end());
	return a;
}
ll randll(ll L,ll R){
	assert(R>=L);
	return ((ll)rand()<<31ll|rand())%(R-L+1)+L;
}
const int maxn=30;
int lim[maxn];
void dfs(int step){
	if(step==0){putchar('\n');return;}
	putchar((rand()&1)+'0');
	dfs(step-1);
}
int main(){
	REP(i,1,6) lim[i]=i;
	REP(i,7,10) lim[i]=i%3+18;
	REP(i,11,14) lim[i]=50-((i-1)%3);
	REP(i,15,20)lim[i]=100-((i+1)%3);
	REP (_, 1, 20) {
		freopen ((pre + to_digit(_) + sufin).c_str(), "w", stdout);
		int T,n=lim[_];
		if(_<=6) T=(1<<n)*n*2;
		else if(_<=12) T=50;
		else T=10000;
		cout<<n<<' '<<T<<endl;
		if(_<=6){
			REP(i,0,(1<<n)-1) REP(j,1,n){
				printf("%d\n",j);
				REP(k,0,n-1) putchar(((i&(1<<k))>0)+'0');
				putchar('\n');
			}
			REP(i,0,(1<<n)-1) REP(j,1,n){
				printf("%d\n",j);
				REP(k,0,n-1) putchar(((i&(1<<k))>0)+'0');
				putchar('\n');
			}
		}
		else{
			cerr<<n<<endl;
			while(T--){
				printf("%lld\n",randll(1,n));
				dfs(n);
			}
		}
	}
	return 0;
}
