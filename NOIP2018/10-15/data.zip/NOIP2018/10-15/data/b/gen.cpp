#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
random_device rd;
#define rand rd
string pre = "b", sufin = ".in", sufout = ".ans";

string to_digit(int x) {
	string a;
	while (x) a += (char)(x % 10 + 48), x /= 10;
	//cerr << a << endl;
	reverse(a.begin(), a.end());
	return a;
}
ll randll(ll L,ll R){
	assert(R>=L);
	return rand()%(R-L+1)+L;
}
int main(){
	int n;
	REP (_, 1, 20) {
		cerr<<_<<endl;
		freopen ((pre + to_digit(_) + sufin).c_str(), "w", stdout);
		int u=randll(1,1e5);
		if(_==4) u=1e5;
		if(_<=3) n=randll(10,15);
		else if(_<=5) n=randll(740,750);
		else if(_<=10) n=randll(90,100);
		else if(_<=14) n=randll(390,400);
		else if(_<=16) n=randll(740,750);
		else n=randll(990,1000);
		if(_==20) n=1000;
		cout<<n<<endl;
		REP(i,1,n){
			int x=randll(1,1e5);
			if(_==4 || _==5) x=u;
			printf("%d%c",x,i==iend?'\n':' ');
		}
	}
	return 0;
}
