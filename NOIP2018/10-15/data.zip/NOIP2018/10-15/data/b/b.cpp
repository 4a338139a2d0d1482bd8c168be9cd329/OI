#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
template<typename T>inline bool chkmin(T &x,T y){return (y<x)?(x=y,1):0;}
template<typename T>inline bool chkmax(T &x,T y){return (y>x)?(x=y,1):0;}
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1000+10,inf=0x3f3f3f3f;
string pre = "b", sufin = ".in", sufout = ".ans";
string to_digit(int x) {
	string a;
	while (x) a += (char)(x % 10 + 48), x /= 10;
	//cerr << a << endl;
	reverse(a.begin(), a.end());
	return a;
}
int dp[2][maxn][maxn],a[maxn];
int main(){
	double t1,t2;
	REP(_,1,20){
		t1=clock()*1.0/CLOCKS_PER_SEC;
		freopen ((pre + to_digit(_) + sufin).c_str(), "r", stdin);
		freopen ((pre + to_digit(_) + sufout).c_str(), "w", stdout);
		int n=read();
		REP(i,1,n) a[i]=read();
		sort(a+1,a+n+1);
		REP(i,1,n) a[i]+=a[i-1];
		REP(i,0,n) REP(j,0,n-i) dp[0][i][j]=inf;
		dp[0][1][0]=0;
		REP(S,0,n-1){
			int x=(S&1),y=(x^1);
			REP(i,0,n-S-1) REP(j,0,n-S-i-1) dp[y][i][j]=inf;
			REP(i,0,n-S) REP(j,0,n-S-i) if(dp[x][i][j]!=inf){
				if(i) chkmin(dp[y][i-1][j],dp[x][i][j]);
				if(i+j) chkmin(dp[x][j+i][i],dp[x][i][j]+a[n-S]);
			}
		}
		printf("%d\n",dp[n&1][0][0]);
		t2=clock()*1.0/CLOCKS_PER_SEC;
		cerr<<t2-t1<<endl;
	}
	return 0;
}
