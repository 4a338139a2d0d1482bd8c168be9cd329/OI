#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
template<typename T>inline bool chkmin(T &x,T y){return (y<x)?(x=y,1):0;}
template<typename T>inline bool chkmax(T &x,T y){return (y>x)?(x=y,1):0;}
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
random_device rd;
#define rand rd
string pre = "a", sufin = ".in", sufout = ".ans";

string to_digit(int x) {
	string a;
	while (x) a += (char)(x % 10 + 48), x /= 10;
	//cerr << a << endl;
	reverse(a.begin(), a.end());
	return a;
}
ll randll(ll L,ll R){
	assert(R>=L);
	return ((ll)rand()<<31ll|rand())%(R-L+1)+L;
}
const int maxn=1e6+10;
int n,m;
struct point{
	ll x,y;
}q[maxn];
int lim[21];
long double pi;
void work(ll x,ll y,long double p,int dep){
	if(m>=2*n-(n!=1)) return;
	chkmax(p,(long double)0.02);
	if(x+y>1e18 || !dep){
//		if(!dep) cerr<<"@#%%#"<<endl;
		q[++m]=(point){x,y};
		return;
	}
	long double GI=(long double)randll(1,1e18)/1e18;
	if(GI>p){
		if(randll(1,100)>=10){
			if(x<y) work(x,x+y,p*pi,dep-1);
			else work(x+y,y,p*pi,dep-1);
		}
		else{
			if(x>y) work(x,x+y,p*pi,dep-1);
			else work(x+y,y,p*pi,dep-1);
		}
	}
	else work(x+y,y,p*pi,dep-1),work(x,x+y,p*pi,dep-1);
}
int main(){
	srand(time(0));
	REP (_, 1, 20) {
		freopen ((pre + to_digit(_) + sufin).c_str(), "w", stdout);
		if(_<=6) n=1,pi=0.8;
		else if(_<=10) n=randll(200-10,200),pi=0.9;
		else if(_<=14) n=randll(10000-100,10000),pi=0.99;
		else n=randll(5e4-100,5e4);
		m=0;
		if(_<=2) work(randll(1,50),randll(1,50),1,7);
		else if(_<=14){
			int u;
			if(_==9 || _==13) u=randll(2,10),work(u,u,1,250);
			else work(1,randll(50000,1e7),1,250);
		}
		else{
			ll x=randll(1,1e9-1),y;
			q[++m]=(point){x,x*randll(1e8,1e9)+1};
			q[++m]=(point){1,1};
			while(m<2*n-1){
				int u=(rand()%3);
				if(u==0) x=randll(1,1e6),y=randll(1,1e18);
				else if(u==1) x=randll(1,1e12),y=randll(1,1e18);
				else x=randll(1,1e18),y=randll(1,1e18);
				if(__gcd(x,y)!=1) continue;
				if(rand()&1) swap(x,y);
				q[++m]=(point){x,y};
			}
		}
		if(_==2) q[2]=q[1];
		if(_>6) ++m,q[m]=q[randll(1,m-1)];
		cerr<<_<<' '<<m<<' '<<2*n<<endl;
		assert(m==2*n);
		random_shuffle(q+1,q+m+1);
		printf("%d\n",n);
		REP(i,1,m) printf("%lld %lld\n",q[i].x,q[i].y);
	}
	return 0;
}
