#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}

string pre = "a", sufin = ".in", sufout = ".ans";

string to_digit(int x) {
	string a;
	while (x) a += (char)(x % 10 + 48), x /= 10;
	//cerr << a << endl;
	reverse(a.begin(), a.end());
	return a;
}

int main(){
	REP (i, 1, 10) {
		freopen ((pre + to_digit(i) + sufout).c_str(), "w", stdout);
		printf ("%d\n", i);
	}
	return 0;
}
