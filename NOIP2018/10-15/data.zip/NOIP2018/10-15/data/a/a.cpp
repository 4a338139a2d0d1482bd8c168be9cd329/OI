#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
template<typename T>inline bool chkmin(T &x,T y){return (y<x)?(x=y,1):0;}
template<typename T>inline bool chkmax(T &x,T y){return (y>x)?(x=y,1):0;}
string pre = "a", sufin = ".in", sufout = ".ans";
string to_digit(int x) {
	string a;
	while (x) a += (char)(x % 10 + 48), x /= 10;
	//cerr << a << endl;
	reverse(a.begin(), a.end());
	return a;
}
inline int read(){
    int x;
    char c;
    int f=1;
    while((c=getchar())!='-' && (c>'9' || c<'0'));
    if(c=='-') f=-1,c=getchar();
    x=c^'0';
    while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
    return x*f;
}
inline ll readll(){
    ll x;
    char c;
    int f=1;
    while((c=getchar())!='-' && (c>'9' || c<'0'));
    if(c=='-') f=-1,c=getchar();
    x=c^'0';
    while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
    return x*f;
}
struct point{
    ll x,y;
    int val;
    bool operator <(const point &rhs) const{
    	if(x+y!=rhs.x+rhs.y) return x+y<rhs.x+rhs.y;
    	if(x!=rhs.x) return x<rhs.x;
    	return y<rhs.y;
	}
    inline void up(){
        if(x>y) x-=y;
        else y-=x;
    }
};
priority_queue<point> q;
int main(){
	REP(_,1,14){
		freopen ((pre + to_digit(_) + sufin).c_str(), "r", stdin);
		freopen ((pre + to_digit(_) + sufout).c_str(), "w", stdout);
		cerr<<_<<endl;
		int n=read();
		REP(i,1,n){
			ll x=readll(),y=readll();
			q.push((point){x,y,1});
		}
		REP(i,1,n){
			ll x=readll(),y=readll();
			q.push((point){x,y,-1});
		}
		int ans=0;
		while(!q.empty()){
			point t=q.top();
			q.pop();
			while(!q.empty()){
				point u=q.top();
				if(u<t) break;
				q.pop();
				t.val+=u.val;
			}
			if (t.val==0) continue;
			t.up();
			ans+=abs(t.val);
			q.push(t);
		}
		printf("%d\n",ans);
	}
	return 0;
}
