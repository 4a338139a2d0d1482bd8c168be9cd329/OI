#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
template<typename T>inline bool chkmin(T &x,T y){return (y<x)?(x=y,1):0;}
template<typename T>inline bool chkmax(T &x,T y){return (y>x)?(x=y,1):0;}
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=5e4+10;
ll ans;
struct point{
	ll x,y,dep,numx[65],numy[65];
	int tmp,v;
	void getdep(){
		tmp=dep=0;
		ll U=x,V=y;
		while(U!=V){
			numx[++tmp]=U,numy[tmp]=V;
			if(U>V){
				ll nu=(U-1)%V+1;
				dep+=(U-nu)/V;
				U=nu;
			}
			else{
				ll nv=(V-1)%U+1;
				dep+=(V-nv)/U;
				V=nv;
			}
		}
		numx[++tmp]=U,numy[tmp]=V;
		reverse(numx+1,numx+tmp+1);
		reverse(numy+1,numy+tmp+1);
	}
	bool operator ==(const point &rhs) const{
		return x==rhs.x && y==rhs.y;
	}
	bool operator !=(const point &rhs) const{
		return !(*this==rhs);
	}
};
point a1[maxn<<2],a[maxn<<2];
int id[maxn<<2];
inline bool cmp(const int A,const int B){
	int u=0;
	REP(i,1,min(a[A].tmp,a[B].tmp)) if(a[A].numx[i]!=a[B].numx[i] || a[A].numy[i]!=a[B].numy[i]){u=i;break;}
	if(u==0) return a[A].tmp<a[B].tmp;
	if(a[A].numx[u]==a[B].numx[u]) return a[A].numy[u]<a[B].numy[u];
	if(a[A].numy[u]==a[B].numy[u]){
		if(a[A].numx[u]<a[B].numx[u]){
			if(u==a[A].tmp) return 1;
			return 0;
		}
		else{
			if(u==a[B].tmp) return 0;
			return 1;
		}
	}
	return a[A].numy[u]<a[B].numy[u];
}
int Begin[maxn<<2],Next[maxn<<2],to[maxn<<2],e;
ll w[maxn<<2];
inline void add_edge(int x,int y,ll z){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
	w[e]=z;
}
int dfs(int x){
	int sum=a[x].v;
	for(int i=Begin[x];i;i=Next[i]){
		int v=dfs(to[i]);
		ans+=abs(v)*w[i];
		sum+=v;
	}
	return sum;
}
inline point find_lca(point A,point B){
	int u=0;
	if(A.tmp>B.tmp) swap(A,B);
	REP(i,1,A.tmp) if(A.numx[i]!=B.numx[i] || A.numy[i]!=B.numy[i]){u=i;break;}
	if(u==0) return A;
	point C;
	C.x=min(A.numx[u],B.numx[u]),C.y=min(A.numy[u],B.numy[u]),C.v=0;
	C.getdep();
	return C;
}
int stk[maxn<<2],top;
int main(){
#ifndef ONLINE_JUDGE
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
#endif
	int n=read();
	REP(i,1,n) a[i].x=readll(),a[i].y=readll(),a[i].v=1;
	REP(i,n+1,2*n) a[i].x=readll(),a[i].y=readll(),a[i].v=-1;
	n*=2;
	REP(i,1,n) a[i].getdep();
	REP(i,1,n) id[i]=i;
	sort(id+1,id+n+1,cmp);
	REP(i,1,n) a1[i]=a[i];
	REP(i,1,n) a[i]=a1[id[i]];
	int tmp=n;
	REP(i,2,n) a[++tmp]=find_lca(a[i],a[i-1]),a[tmp].v=0;
	REP(i,1,tmp) id[i]=i;
	sort(id+1,id+tmp+1,cmp);
	REP(i,1,tmp) a1[i]=a[i];
	REP(i,1,tmp) a[i]=a1[id[i]];
	n=0;
	for(int i=1,j;i<=tmp;i=j+1){
		int res=a[i].v;
		j=i;
		while(j<tmp && a[j+1]==a[i]) ++j,res+=a[j].v;
		a1[++n]=a[i];
		a1[n].v=res;
	}
	REP(i,1,n) a[i]=a1[i];
	REP(i,1,n){
		while(top && find_lca(a[stk[top]],a[i])!=a[stk[top]]) --top;
		assert(top>0 || i==1);
		if(top) add_edge(stk[top],i,a[i].dep-a[stk[top]].dep);
		stk[++top]=i;
	}
	dfs(1);
	printf("%lld\n",ans);
	return 0;
}
