#include <bits/stdc++.h>
int f[25005];
int a[105];
int main() {


	int T; scanf("%d", &T);
	int V; scanf("%d", &V);
	int NL; scanf("%d", &NL);
	int NR; scanf("%d", &NR);

	int *seed = new int;
	srand(time(0) + clock() + (size_t) &seed);
	delete seed;
	printf("%d\n", T);

	while(T--) {
		int N = rand() % (NR - NL + 1) + NL;
		
		int S = ceil(sqrt(V)) + 1;
		if(S == 0) S = 1;
		if(S > N) S = N;

		memset(f, 0, sizeof f);
		f[0] = 1;

		for(int i = 1; i <= N; ++i) {
			if(i == 1) a[i] = rand() % (S) + S;
			else {
				std::vector<int> num[2];
				for(int j = 1; j <= V; ++j) if(f[j] != -1) if(f[j] || j >= a[i - 1]) num[f[j]].push_back(j);
				bool k = (rand() % 10 > 8);
				if(num[k].empty()) k = !k;

				if(!num[k].size()) {
					for(int j = 1; j <= V; ++j) if(f[j] != -1) num[f[j]].push_back(j);
					if(num[k].empty()) k = !k;
				}


				if(!num[k].size()) fprintf(stderr, "%d %d %d\n", i, V, num[k].size());
				assert(num[k].size());


				a[i] = num[k][rand() % num[k].size()];
			}
			int x = a[i];
			assert(1 <= x && x <= V);
			assert(f[x] != -1);
			for(int j = x; j <= V; ++j) f[j] |= bool(f[j - x]);
			f[x] = -1;

			int count = 0;


		}

		std::sort(a + 1, a + N + 1);
		assert(N == std::unique(a + 1, a + N + 1) - a - 1);

		std::random_shuffle(a + 1, a + N + 1);

		printf("%d\n", N);
		for(int i = 1; i <= N; ++i) printf("%d%c", a[i], " \n"[i == N]);
	}
}