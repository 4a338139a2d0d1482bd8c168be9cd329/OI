#include <cstdio>
#include <cstring>
#include <algorithm>
bool f[25005];
int a[105];
int main() {
	int T; scanf("%d", &T);
	while(T--) {
		int n; scanf("%d", &n);
		for(int i = 0; i < n; ++i) scanf("%d", a + i);
		std::sort(a, a + n);
		int m = a[n - 1];
		memset(f + 1, 0, m);
		f[0] = 1;
		int ans = 0;
		for(int i = 0; i < n; ++i) if(!f[a[i]]) {
			++ans; int x = a[i];
			for(int j = x; j <= m; ++j) f[j] |= f[j - x];
		}
		printf("%d\n", ans);
	}
}