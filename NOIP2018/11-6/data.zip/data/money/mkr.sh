echo 20 1000 2 2 | ./mkr > money1.in
echo 20 1000 2 2 | ./mkr > money2.in
echo 20 1000 2 2 | ./mkr > money3.in
echo 20 1000 3 3 | ./mkr > money4.in
echo 20 1000 3 3 | ./mkr > money5.in
echo 20 1000 3 3 | ./mkr > money6.in
echo 20 1000 4 4 | ./mkr > money7.in
echo 20 1000 4 4 | ./mkr > money8.in
echo 20 1000 5 5 | ./mkr > money9.in
echo 20 1000 5 5 | ./mkr > money10.in
echo 20 16 10 13 | ./mkr > money11.in
echo 20 16 12 13 | ./mkr > money12.in
echo 20 16 13 13 | ./mkr > money13.in
echo 20 40 20 25 | ./mkr > money14.in
echo 20 40 23 25 | ./mkr > money15.in
echo 20 40 25 25 | ./mkr > money16.in
echo 20 25000 90 100 | ./mkr > money17.in
echo 20 25000 95 100 | ./mkr > money18.in
echo 20 25000 97 100 | ./mkr > money19.in
echo 20 25000 100 100 | ./mkr > money20.in


g++ std.cpp -o std
for((i=1;i<=20;++i));do
	./std < money$i.in > money$i.ans
done