#include <cstring>
#include <cstdio>
#include <cassert>
#include <ctime>
typedef long long ll;
#define RG //register
#define IL __inline__ __attribute__((always_inline))
#define For(i, a, b) for(RG int i = a, __##i##_e__ = b; i <= __##i##_e__; ++i)
#define Rep(i, a, b) for(RG int i = a, __##i##_e__ = b; i != __##i##_e__; ++i)
#define Dor(i, a, b) for(RG int i = b, __##i##_e__ = a; i >= __##i##_e__; --i)
#define dmax(a, b) ((a) > (b) ? (a) : (b))
namespace pb_ds
{

	namespace io
	{
		const int MaxBuff = 1 << 15;
		const int Output = 1 << 24;
		char B[MaxBuff], *S = B, *T = B;
		#define getc() ((S == T) && (T = (S = B) + fread(B, 1, MaxBuff, stdin), S == T) ? 0 : *S++)
		char Out[Output], *iter = Out;
		IL void flush() {fwrite(Out, 1, iter - Out, stdout); iter = Out;}
	}
	
	template<class Type> IL Type read()
	{
		using namespace io;
		RG char ch; RG Type ans = 0; RG bool neg = 0;
		while(ch = getc(), (ch < '0' || ch > '9') && ch != '-')	 ;
		ch == '-' ? neg = 1 : ans = ch - '0';
		while(ch = getc(), '0' <= ch && ch <= '9') ans = ans * 10 + ch - '0';
		return neg ? -ans : ans;
	}
	template<class Type> IL void print(RG Type x, RG char ch = '\n')
	{
		using namespace io;
		if(!x) *iter++ = '0';
		else
		{
			if(x < 0) *iter++ = '-', x = -x;
			static int S2[100]; RG int t = 0;
			while(x) S2[++t] = x % 10, x /= 10;
			while(t) *iter++ = '0' + S2[t--];
		}
		*iter++ = ch;
	}

	const int MaxN = 100010;
	const ll inf = 1ll << 55;
	struct Pointer{int to; Pointer *next;} *fir[MaxN], mem[MaxN << 1];
	int cnt[MaxN], cho[MaxN];
	void dfs_init(RG int i)
	{
		cnt[i] = 1; cho[i] = -1;
		for(RG Pointer *k = fir[i]; k; k = k->next)
			if(!cnt[k->to])
			{
				dfs_init(k->to); cnt[i] += cnt[k->to];
				(cho[i] == -1 || cnt[cho[i]] < cnt[k->to]) ? cho[i] = k->to : 0;
			}
	}
	struct BData; struct CData;
	struct BData
	{
		ll a, b;
		IL BData operator + (RG const BData& B) const {return (BData) {a + B.a, b + B.b};}
		IL CData convert() const;
		IL void null() {a = b = 0;}
	}	bdmem[MaxN * 10], *bdtot;
	struct CData
	{
		ll a, b, c, d;
		IL CData operator + (RG const CData& C) const {return (CData) {dmax(a + C.a, b + C.c), dmax(a + C.b, b + C.d), dmax(c + C.a, d + C.c), dmax(c + C.b, d + C.d)};}
		IL BData convert() const;
		IL void null() {a = d = 0; b = c = -inf;}
		IL ll sum() const {return dmax(a, b);}
	}	cdmem[MaxN * 10], *cdtot;
	IL CData BData::convert() const {return (CData) {a, b, a};}
	IL BData CData::convert() const {return (BData) {dmax(a, b), a};}
	
	template<class Data> struct Tree
	{
		Data *T; int D;
		IL void init(RG int N, RG Data* &tot) {D = 1; while(D <= N) D <<= 1; T = tot; tot += D << 1 | 1; For(i, N + 1, D + 1) T[i + D].null();}
		IL Data& at(RG int x) {return T[D + x];}
		IL const Data& save() {Dor(i, 1, D) T[i] = T[i << 1 | 1] + T[i << 1]; return T[1];}
		IL const Data& modify(RG int i) {for(i += D; i >>= 1; ) T[i] = T[i << 1 | 1] + T[i << 1]; return T[1];}
		IL const Data& modify(RG int i, RG const Data& d) {at(i) = d; return modify(i);}
	};
	
	struct Chain
	{
		Chain *pre; int cpos, bpos;
		Tree<CData>  all; Tree<BData>* bra;
	}	cmem[MaxN], *ctot;
	
	Chain *cbel[MaxN]; int cpos[MaxN];
	Tree<BData> tbdmem[MaxN], *tbdtot;

	ll val[MaxN];
	
	void dfs_make(RG int i)
	{
		RG Chain *const C = ctot++;
		RG int L = 0;
		for(RG int p = i; p != -1; p = cho[p])
			{cbel[p] = C; cpos[p] = ++L;}
		
		C->all.init(L, cdtot);
		C->bra = tbdtot; tbdtot += L;
		for(RG int p = i; p != -1; p = cho[p])
		{
			RG int D = 1;
			for(RG Pointer *k = fir[p]; k; k = k->next)
				if(!cbel[k->to])
				{
					dfs_make(k->to);
					cbel[k->to]->pre = C;
					cbel[k->to]->cpos = cpos[p];
					cbel[k->to]->bpos = ++D;
				}
			RG Tree<BData> *B = C->bra + cpos[p];
			B->init(D, bdtot);
			B->at(1) = (BData) {0ll, val[p]};
			for(RG Pointer *k = fir[p]; k; k = k->next) if(cbel[k->to]->pre == C)
				B->at(cbel[k->to]->bpos) = cbel[k->to]->all.T[1].convert();
			C->all.at(cpos[p]) = B->save().convert();	
		}
		C->all.save();
	}
	IL void modify(RG int p, RG ll v)
	{
		RG Chain* C = cbel[p];
		// val[p] = v;
		C->all.modify(cpos[p], C->bra[cpos[p]].modify(1, (BData) {0ll, v}).convert());
		for(; C->pre; C = C->pre)
			C->pre->all.modify(C->cpos,  C->pre->bra[C->cpos].modify(C->bpos, C->all.T[1].convert()).convert());
	}
	
	IL void main()
	{
		RG int (*F)() = read<int>;
		RG int N = F(), Q = F(); F();
		RG ll sum = 0;
		For(i, 1, N) {val[i] = F(); sum += val[i];}
		RG Pointer *tot = mem;
		For(i, 2, N) {
			RG int x = F(), y = F();
			*++tot = (Pointer) {y, fir[x]}; fir[x] = tot;
			*++tot = (Pointer) {x, fir[y]}; fir[y] = tot;
		}

		ctot = cmem;
		cdtot = cdmem;
		bdtot = bdmem;
		tbdtot = tbdmem;
		dfs_init(1); dfs_make(1);


		while(Q--) {
			RG int a = F(), x = F(), b = F(), y = F();
			modify(a, x ? -inf : inf); 
			modify(b, y ? -inf : inf);

			ll ans = cbel[1]->all.T[1].sum() + (x ? 0 : val[a] - inf) + (y ? 0 : val[b] - inf);
			if(ans < 0) ans = -1; else ans = sum - ans;
			print(ans);

			modify(a, val[a]);
			modify(b, val[b]);
		}

		io::flush();
		
	}
}
int main()
{
	pb_ds::main();
}