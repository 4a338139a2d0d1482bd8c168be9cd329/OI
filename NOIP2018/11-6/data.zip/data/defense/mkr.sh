for((i=1;i<=2;++i));do python mkr.py 10 10 A3 > $i.in; done
for((i=3;i<=4;++i));do python mkr.py 10 10 C3 > $i.in; done
for((i=5;i<=6;++i));do python mkr.py 100 100 A3 > $i.in; done
for((i=7;i<=7;++i));do python mkr.py 100 100 C3 > $i.in; done
for((i=8;i<=9;++i));do python mkr.py 2000 2000 A3 > $i.in; done
for((i=10;i<=11;++i));do python mkr.py 2000 2000 C3 > $i.in; done
for((i=12;i<=13;++i));do python mkr.py 100000 100000 A1 > $i.in; done
for((i=14;i<=16;++i));do python mkr.py 100000 100000 A2 > $i.in; done
for((i=17;i<=17;++i));do python mkr.py 100000 100000 A3 > $i.in; done
for((i=18;i<=19;++i));do python mkr.py 100000 100000 B1 > $i.in; done
for((i=20;i<=21;++i));do python mkr.py 100000 100000 C1 > $i.in; done
for((i=22;i<=22;++i));do python mkr.py 100000 100000 C2 > $i.in; done
for((i=23;i<=24;++i));do python mkr.py 100000 100000 C3 > $i.in; done
python mkr.py 100000 100000 C3k > 25.in

for((i=1;i<=25;++i));do head -n1 $i.in; done
