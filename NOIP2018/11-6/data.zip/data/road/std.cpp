#include <cstdio>
int main() {
	int n, h1 = 0, h, ans = 0;
	scanf("%d", &n);
	while(n--) {
		scanf("%d", &h);
		h > h1 ? ans += h - h1 : 0;
		h1 = h;
	}
	printf("%d", ans);
	return 0;
}