python mkr.py N=5	M=1 V=10000 T=2 > track1.in
python mkr.py N=10	M=0 V=10000 T=1 > track2.in
python mkr.py N=15	M=0	V=1		T=3 > track3.in
python mkr.py N=1000	M=1	V=10000		T=2 > track4.in
python mkr.py N=30000	M=1	V=1			T=3 > track5.in
python mkr.py N=30000	M=1	V=10000		T=3 > track6.in
python mkr.py N=30000	M=0	V=1			T=3 > track7.in
python mkr.py N=50000	M=0	V=1			T=3 > track8.in
python mkr.py N=1000	M=0	V=10000		T=1 > track9.in
python mkr.py N=30000	M=0	V=10000		T=1 > track10.in
python mkr.py N=50000	M=0	V=10000		T=1 > track11.in
python mkr.py N=50		M=0	V=10000		T=2 > track12.in
python mkr.py N=50		M=0	V=10000		T=2 > track13.in
python mkr.py N=200		M=0	V=10000		T=2 > track14.in
python mkr.py N=200		M=0	V=10000		T=2 > track15.in
python mkr.py N=1000	M=0	V=10000		T=2 > track16.in
python mkr.py N=1000	M=0	V=10000		T=3 > track17.in
python mkr.py N=30000	M=0	V=10000		T=3 > track18.in
python mkr.py N=30000	M=0	V=10000		T=3 > track19.in
python mkr.py N=50000	M=0	V=10000		T=3 > track20.in

g++ std.cpp -o std

for((i=1;i<=20;++i));do
	echo $i
	/usr/bin/time ./std < track$i.in > track$i.ans
	cat track$i.ans
	echo fuck maosiansian
done