#include <cstdio>
#include <algorithm>

const int MAX_N = 50005;
const long long inf = 1ll << 60;
struct Adj {int to, len; Adj *next;} *fir[MAX_N], mem[MAX_N << 1], *tot = mem;

int n, m, cur, D;
long long lim, f[MAX_N], a[MAX_N];
bool v[MAX_N];

int work() {
	int l = 0, ans = 0;
	for(int r = D - 1; l < r; --r) if(a[r] >= 0) {
		while(l < r && a[l] + a[r] < lim) ++l;
		if(l >= r) break;
		++l; ++ans;
	}
	return ans;
}

void dfs(int i) {
	v[i] = 1;
	for(Adj *k = fir[i]; k; k = k->next) if(!v[k->to]) dfs(k->to);
	D = 0;
	for(Adj *k = fir[i]; k; k = k->next) if(!v[k->to]) {
		a[D] = f[k->to] + k->len;
		++(a[D] >= lim ? cur : D);
	}
	std::sort(a, a + D);
	
	int res = work();
	cur += res;
	if(D == (res << 1)) f[i] = 0;
	else {
		int l = 0, r = D - 1;
		while(l < r) {
			int m = (l + r + 1) >> 1;
			long long tmp = a[m];
			a[m] = -inf;
			work() == res ? l = m : r = m - 1;
			a[m] = tmp;
		}
		f[i] = a[l];
	}
	v[i] = 0;
}

int main() {
	scanf("%d%d", &n, &m);
	long long l = 0, r = 0;
	for(int i = 1; i < n; ++i) {
		int a, b, l; scanf("%d%d%d", &a, &b, &l);
		*++tot = (Adj) {b, l, fir[a]}; fir[a] = tot;
		*++tot = (Adj) {a, l, fir[b]}; fir[b] = tot;
		r += l;
	}
	while(l != r) {
		lim = (l + r + 1) >> 1;
		cur = 0;
		dfs(1);
		(cur >= m) ? l = lim : r = lim - 1;
	}
	printf("%lld\n", l);
}