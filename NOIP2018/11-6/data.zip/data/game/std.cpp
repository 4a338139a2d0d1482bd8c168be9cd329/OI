#include <bits/stdc++.h>

#define rep(i, x, y) for (int i = (x), _ = (y); i < _; ++i)
#define down(i, x, y) for (int i = (x) - 1, _ = (y); i >= _; --i)
#define fi first
#define se second
#define mp(x, y) make_pair(x, y)
#define pb(x) push_back(x)
#define bin(x) (1 << (x))
#define SZ(x) int((x).size())
//#define LX_JUDGE

using namespace std;
typedef pair<int, int> pii;
typedef vector<int> Vi;
typedef long long ll;

template<typename T> inline bool upmax(T &x, T y) { return x < y ? (x = y, 1) : 0; }
template<typename T> inline bool upmin(T &x, T y) { return x > y ? (x = y, 1) : 0; }

namespace MATH_CAL {
	const int mod = 1e9 + 7;
	inline int add(int a, int b) { return a + b >= mod ? a + b - mod : a + b; }
	inline int sub(int a, int b) { return a - b < 0 ? a - b + mod : a - b; }
	inline int mul(int a, int b) { return (ll) a * b % mod; }
	inline void Add(int &a, int b) { (a += b) >= mod ? a -= mod : 0; }
	inline void Sub(int &a, int b) { (a -= b) < 0 ? a += mod : 0; }
	inline int qpow(int x, int n) { int r = 1; for ( ; n; n /= 2, x = mul(x, x)) if (n & 1) r = mul(r, x); return r; }
	inline int mod_inv(int x) { return qpow(x, mod - 2); }
} using namespace MATH_CAL;

const int MAX_N = 53;
const int inf = 0x3f3f3f3f;

int main() {
#ifdef LX_JUDGE
	freopen(".in", "r", stdin);
#endif
	int n, m;
	cin >> n >> m;

	if (n > m) swap(n, m);

	int ans = 0;

	if (n == 1) {
		cout << qpow(2, m) << endl;
		return 0;
	} else if (n == 2) {
		cout << mul(qpow(3, m - 1), 4) << endl;
		return 0;
	}

	// 第 2 个对角线相同

	int tmp = 4;

	for (int i = 3; i <= n + m - 1; ++i) {
		int w = 2 + (i <= n) + (i <= m);
		tmp = mul(tmp, w);
	}

//	printf("Class 0: %d\n", tmp);

	Add(ans, tmp);

	// 第 3 个对角线相同

	// 000 or 111
	tmp = 4;
	for (int i = 4; i <= n + m - 1; ++i) {
		int w = 2 + (i <= n) + (i <= m) + (i == 4);
		tmp = mul(tmp, w);
	}

	Add(ans, tmp);

//	printf("Class 1: %d\n", tmp);

	// 001

	int last = 0;
	int tmp2 = 0, tmp1 = 2;

	for (int i = 4; i <= n + m - 1; ++i) {
		int w = 2 + (i <= n) + (i <= m);
		tmp2 = mul(add(tmp1, tmp2), w);
		if (i > 4 and i - 1 <= n) Add(tmp2, mul(last, 2));
		if (i == n + 1) {
			tmp2 = add(tmp1, tmp2);
			tmp1 = 0;
		}
		last = w;
	}

	Add(ans, tmp2);

//	printf("Class 2: %d\n", tmp2);
	// 011

	tmp2 = 0, tmp1 = 2;

	for (int i = 4; i <= n + m - 1; ++i) {
		int w = 2 + (i <= n) + (i <= m);
		tmp2 = mul(add(tmp1, tmp2), w);
		if (i > 4 and i - 1 <= m) Add(tmp2, mul(last, 2));
		if (i == m + 1) {
			tmp2 = add(tmp1, tmp2);
			tmp1 = 0;
		}
		last = w;
	}

	Add(ans, tmp2);

//	printf("Class 3: %d\n", tmp2);

	printf("%d\n", ans);

	return 0;
}