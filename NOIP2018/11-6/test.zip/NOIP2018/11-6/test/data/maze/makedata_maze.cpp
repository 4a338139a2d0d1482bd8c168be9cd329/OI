
#include <set>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
using namespace std;

#define fir first
#define sec second

typedef long long LL;
typedef pair<int, int> PP;

#define readi(x) fscanf (In, "%d", &x)
#define print(x) fprintf (Out, "%d", (x))
#define readl(x) fscanf (In, "%lld", &x)
#define printl(x) fprintf (Out, "%lld", (x))
#define readc(x) fscanf (In, "%c", &x)
#define putcc(x) fprintf (Out, "%c", (x))
#define reads(x) fscanf (In, "%s", x + 1)
#define prints(x) fprintf (Out, "%s", x)

FILE *In, *Out;

int NAME_LEN;
char FILE_NAME[100] = {"maze"};
char FILE_NAME_In[100], FILE_NAME_Out[100];

int irand () {
	return (rand () << 15 | rand ());
}

namespace MAKEDATA {
	const int Maxn = 5005;
	const int INF = 0x3f3f3f3f;
	
	int N, M, Q;
	
	struct NO {
		bool t;
		int x1, y1, x2, y2;
		NO () {}
		NO (bool t, int x1, int y1, int x2, int y2)
			: t(t), x1(x1), y1(y1), x2(x2), y2(y2) {}
	} a[100005];
	
	PP Calc (PP x, PP y) {
		return PP (max (x.fir, y.fir), min (x.sec, y.sec));
	}
	
	struct SSEG {
		#define cl i << 1
		#define cr i << 1 | 1
		
		set<int> Set[Maxn << 2];
		set<int>::iterator Sit;
		
		void Clear () {
			for (int i = 1; i <= Maxn * 3; ++i)
				Set[i].clear ();
		}
		
		void Insert (int i, int L, int R, int l, int r, int A, bool t) {
			if (L >= l && R <= r) {
				if (t) Set[i].insert (A);
				else Set[i].erase (A);
				return ;
			}
			int mid = L + R >> 1;
			if (r <= mid) Insert (cl, L, mid, l, r, A, t);
			else if (l > mid) Insert (cr, mid + 1, R, l, r, A, t);
			else Insert (cl, L, mid, l, mid, A, t), Insert (cr, mid + 1, R, mid + 1, r, A, t);
		}
		
		PP Query (int i, int L, int R, int T, int X) {
			PP Val = PP (0, INF);
			Sit = Set[i].lower_bound (X);
			if (Sit != Set[i].end()) Val.sec = min (Val.sec, *Sit);
			if (Sit != Set[i].begin()) --Sit, Val.fir = max (Val.fir, *Sit);
			if (L == R) return Val;
			int mid = L + R >> 1;
			if (T <= mid) return Calc (Val, Query (cl, L, mid, T, X));
			else return Calc (Val, Query (cr, mid + 1, R, T, X));
		}
		
		PP query (int i, int L, int R, int l, int r, int X) {
			PP Val = PP (0, INF);
			Sit = Set[i].lower_bound (X);
			if (Sit != Set[i].end()) Val.sec = min (Val.sec, *Sit);
			if (Sit != Set[i].begin()) --Sit, Val.fir = max (Val.fir, *Sit);
			if (L == R) return Val;
			int mid = L + R >> 1;
			if (r <= mid) return Calc (Val, query (cl, L, mid, l, r, X));
			else if (l > mid) return Calc (Val, query (cr, mid + 1, R, l, r, X));
			else return Calc (Val, Calc (query (cl, L, mid, l, mid, X), query (cr, mid + 1, R, mid + 1, r, X)));
		}
	}SEGx, SEGy;
	
	void main1 () {
		N = 90 + rand() % 11, M = 90 + rand() % 11, Q = 100;
		print (N), putcc (' '), print (M), putcc (' '), print (Q), putcc ('\n');
		SEGx.Clear (), SEGy.Clear ();
		memset (a, 0, sizeof (a));
		for (int i = 1, j; i <= Q; ++i) {
			int rr = rand () % 1000;
//			int tt; if (i <= Q * 0.6) tt = 800; else tt = 100;
			int tt = 600;
//			cerr << i << ' ' << rr << endl;
			if (rr <= tt) {
				int x = rand () % (N - 1) + 2;
				int y = rand () % (M - 1) + 2;
				int l, r, x1, y1, x2, y2;
				PP Val = Calc (PP (2, M), SEGx.Query (1, 1, N + 1, x, y));
//				cerr << 'a' << endl;
				l = Val.fir + 1, r = Val.sec - 1;
				if (r <= l) {--i; continue ;}
				y1 = l + rand () % (r - l), y2 = y1 + rand () % (r - y1) + 1;
				Val = Calc (PP (2, N), SEGy.query (1, 1, M + 1, y1, y2, x));
				l = Val.fir + 1, r = Val.sec - 1;
				if (r <= l) {--i; continue ;}
				x1 = l + rand () % (r - l), x2 = x1 + rand () % (r - x1) + 1;
				putcc ('1'), putcc(' '), print (x1), putcc (' '), print (y1),
				putcc (' '), print (x2 - 1), putcc (' '), print (y2 - 1), putcc ('\n');
				SEGx.Insert (1, 1, N + 1, x1, x2, y1, 1), SEGx.Insert (1, 1, N + 1, x1, x2, y2, 1);
				SEGy.Insert (1, 1, M + 1, y1, y2, x1, 1), SEGy.Insert (1, 1, M + 1, y1, y2, x2, 1);
				a[i] = NO (true, x1, y1, x2, y2);
				continue ;
			}
			if (rr > tt && rr <= 900) {
				int x1 = rand () % N + 1, x2 = x1 + rand () % (N - x1 + 1);
				int y1 = rand () % M + 1, y2 = y1 + rand () % (M - y1 + 1);
//				cerr << x1 << ' ' << x2 << ' ' << y1 << ' ' << y2 << endl;
				putcc ('3'), putcc(' '), print (x1), putcc (' '), print (y1),
				putcc (' '), print (x2), putcc (' '), print (y2), putcc ('\n');
				continue ;
			}
			if (rr > 900) {
				for (j = 1; j < i; ++j)
					if (a[j].t && (rand () % 100 < 30)) {
						a[j].t = false;
						int x1 = a[j].x1, y1 = a[j].y1, x2 = a[j].x2, y2 = a[j].y2;
						putcc ('2'), putcc(' '), print (x1), putcc (' '), print (y1),
						putcc (' '), print (x2 - 1), putcc (' '), print (y2 - 1), putcc ('\n');
						SEGx.Insert (1, 1, N + 1, x1, x2, y1, 0), SEGx.Insert (1, 1, N + 1, x1, x2, y2, 0);
						SEGy.Insert (1, 1, M + 1, y1, y2, x1, 0), SEGy.Insert (1, 1, M + 1, y1, y2, x2, 0);
						break ;
					}
				if (j == i) --i;
			}
		}
	}
}

namespace CODE {
	const int Maxn=2505;
	
	int N,M,Q;
	int b[10];
	int a[Maxn][Maxn], an;
	
	void Work_Add (int x1, int y1, int x2, int y2) {
		++x2, ++y2; ++an;
		for (int i = x1; i <= x2; ++i) {
			if (a[i][y1] || a[i][y2])
				cerr << "NO" << endl;
			++a[i][y1], ++a[i][y2];
		}
		for (int j = y1 + 1; j < y2; ++j) {
			if (a[x1][j] || a[x2][j])
				cerr << "NO" << endl;
			++a[x1][j], ++a[x1][j];
		}
	}
	
	void Work_Del (int x1, int y1, int x2, int y2) {
		++x2, ++y2; --an;
		for (int i = x1; i <= x2; ++i) {
			--a[i][y1], --a[i][y2];
		}
		for (int j = y1 + 1; j < y2; ++j) {
			--a[x1][j], --a[x1][j];
		}
	}
	
	struct BIT{
		int Mod;
		int Bit[Maxn][Maxn];
		
		void Clear () {
			memset (Bit, 0, sizeof (Bit));
		}
		
		void Insert(int X,int Y,int A){
			int tx=X;
			while(tx<=N){
				int ty=Y;
				while(ty<=M){
					Bit[tx][ty]=(Bit[tx][ty]+(LL)A)%Mod;
					if(Bit[tx][ty]<0) Bit[tx][ty]+=Mod;
					ty+=ty&(-ty);
				}
				tx+=tx&(-tx);
			}
		}
		
		int Query(int X,int Y){
			int tx=X,Val=0;
			while(tx>0){
				int ty=Y;
				while(ty>0)
					Val=((LL)Val+Bit[tx][ty])%Mod,
					ty-=ty&(-ty);
				tx-=tx&(-tx);
			}
			return Val;
		}
	}B[4];
	
	void main(){
		readi(N),readi(M),readi(Q),++N,++M;
		memset (a, 0, sizeof (a));
		for (int i = 0; i < 4; ++i)
			B[i].Clear ();
		B[0].Mod=1E9+7,B[1].Mod=998244353,
		B[2].Mod=666623333,B[3].Mod=2147483647;
		for(int i=0;i<4;++i) b[i]=1;
		for(int i=1;i<=Q;++i){
			int op,r1,c1,r2,c2;
			readi(op),readi(r1),readi(c1),readi(r2),readi(c2);
			if(op==1){
				Work_Add (r1, c1, r2, c2);
				for(int k=0;k<4;++k){
					B[k].Insert(r1,c1,b[k]),
					B[k].Insert(r1,c2+1,-b[k]),
					B[k].Insert(r2+1,c1,-b[k]),
					B[k].Insert(r2+1,c2+1,b[k]);
				}
				for(int k=0;k<4;++k)
					b[k]=(b[k]*2ll)%B[k].Mod;
			}
			if(op==2){
				Work_Del (r1, c1, r2, c2);
				for(int k=0;k<4;++k){
					int tmp=((LL)B[k].Query(r1,c1)-(LL)B[k].Query(r1-1,c1-1)+(LL)B[k].Mod)%B[k].Mod;
					B[k].Insert(r1,c1,-tmp),
					B[k].Insert(r1,c2+1,tmp),
					B[k].Insert(r2+1,c1,tmp),
					B[k].Insert(r2+1,c2+1,-tmp);
				}
			}
			if(op==3){
				bool flag=true;
				for(int k=0;k<4;++k)
					flag&=(B[k].Query(r1,c1)==B[k].Query(r2,c2));
				if(flag) prints("Yes"), putcc ('\n'); else prints("No"), putcc ('\n');
			}
		}
	}
}

int main () {
	int LID = 2, RID = 6;
	
	NAME_LEN = strlen (FILE_NAME);
	strcpy (FILE_NAME_In, FILE_NAME), strcpy (FILE_NAME_Out, FILE_NAME);
	FILE_NAME_In[NAME_LEN + 2] = '.', FILE_NAME_In[NAME_LEN + 3] = 'i', FILE_NAME_In[NAME_LEN + 4] = 'n', 
	FILE_NAME_Out[NAME_LEN + 2] = '.', FILE_NAME_Out[NAME_LEN + 3] = 'a', FILE_NAME_Out[NAME_LEN + 4] = 'n', FILE_NAME_Out[NAME_LEN + 5] = 's';
	
	for (int ID = LID; ID <= RID; ++ID) {
		srand ((unsigned long long)(new char) * time (0));
		FILE_NAME_In[NAME_LEN] = '0' + ID / 10,
		FILE_NAME_In[NAME_LEN + 1] = '0' + ID % 10;
		FILE_NAME_Out[NAME_LEN] = '0' + ID / 10,
		FILE_NAME_Out[NAME_LEN + 1] = '0' + ID % 10;
		Out = fopen (FILE_NAME_In, "w");
		MAKEDATA :: main1 ();
		fclose (Out);
		In = fopen (FILE_NAME_In, "r");
		Out = fopen (FILE_NAME_Out, "w");
		CODE :: main ();
		fclose (In), fclose (Out);
	}
	return 0;
}

