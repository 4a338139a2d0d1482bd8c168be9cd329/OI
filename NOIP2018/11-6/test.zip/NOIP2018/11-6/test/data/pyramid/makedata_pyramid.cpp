
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
using namespace std;

typedef long long LL;

#define readi(x) fscanf (In, "%d", &x)
#define print(x) fprintf (Out, "%d", (x))
#define readl(x) fscanf (In, "%lld", &x)
#define printl(x) fprintf (Out, "%lld", (x))
#define readc(x) fscanf (In, "%c", &x)
#define printc(x) fprintf (Out, "%c", (x))
#define reads(x) fscanf (In, "%s", x + 1)
#define prints(x) fprintf (Out, "%s", x + 1)

FILE *In, *Out;

int NAME_LEN;
char FILE_NAME[100] = {"pyramid"};
char FILE_NAME_In[100], FILE_NAME_Out[100];

int irand () {
	return (rand () << 15 | rand ());
}

namespace MAKEDATA {
	const int Maxn = 2E6 + 5;
	
	int N, n;
	int p[Maxn];
	int a[Maxn], nxt[Maxn];
	int Ans;
	
	int Abs (int x) {return (x < 0 ? (-x) : x);}
	
	bool cmp (int x, int y) {return Abs (x - Ans) < Abs (y - Ans);}
	
	int query () {
		while (1) {
			int x = 0;
			while (nxt[x] <= N) {
				if (irand () % 10000 < 100) {
					int val = a[nxt[x]];
					nxt[x] = nxt[nxt[x]];
					return val;
				}
				x = nxt[x];
			}
		}
	}
	
	void main1 () {
		n = N = 8400 + rand () % 101;
		print (N), printc ('\n'), N = N * 2 - 1;
		Ans = irand () % N + 1;
		while (Abs (Ans - n) < n / 10)
			Ans = irand () % N + 1;
		cerr << Ans << ' ';
		for (int i = 1; i <= N; ++i) a[i] = i;
		sort (a + 1, a + N + 1, cmp);
		for (int i = 0; i <= N; ++i)
			nxt[i] = i + 1;
		p[n] = query ();
		for (int i = 1; i < n; ++i)
			p[n - i] = query (), p[n + i] = query ();
		for (int i = 1; i <= N; ++i)
			print (p[i]), printc (' ');
	}
	
	void main0 () {
		N = 999000 + rand () % 1001;
		print (N), printc ('\n'), N = N * 2 - 1;
		for (int i = 1; i <= N; ++i) p[i] = i;
		random_shuffle (p + 1, p + N + 1);
		for (int i = 1; i <= N; ++i)
			print (p[i]), printc (' ');
	}
}

namespace CODE {
	const int Maxn = 2E6 + 5;
	
	int N;
	int a[Maxn];
	bool b[Maxn];
	
	bool Check (int X) {
		bool FLAG = true;
		for (int i = 1; i <= N; ++i)
			b[i] = (a[i] >= X);
		for (int i = 2; i <= N; ++i)
			FLAG &= (b[i] != b[i - 1]);
		if (FLAG) return b[N / 2 + 1] ^ ((N / 2) & 1);
		int l = 0, r = N + 1;
		for (int i = N / 2; i >= 1; --i)
			if (b[i] == b[i + 1]) {l = i; break ;}
		for (int i = N / 2 + 2; i <= N; ++i)
			if (b[i] == b[i - 1]) {r = i; break ;}
		if ((N / 2 + 1 - l) < (r - N / 2 - 1)) return b[l];
		return b[r];
	}
	
	int main () {
		readi (N), N = N * 2 - 1;
		for (int i = 1; i <= N; ++i) readi (a[i]);
		int lb = 0, rb = N + 1;
		while (lb + 1 < rb) {
			int mid = lb + rb >> 1;
			if (Check (mid)) lb = mid;
			else rb = mid;
		}
		print (lb);
		cerr << lb << endl;
		return 0;
	}
}

int main () {
	int LID = 9, RID = 10;
	
	NAME_LEN = strlen (FILE_NAME);
	strcpy (FILE_NAME_In, FILE_NAME), strcpy (FILE_NAME_Out, FILE_NAME);
	FILE_NAME_In[NAME_LEN + 2] = '.', FILE_NAME_In[NAME_LEN + 3] = 'i', FILE_NAME_In[NAME_LEN + 4] = 'n', 
	FILE_NAME_Out[NAME_LEN + 2] = '.', FILE_NAME_Out[NAME_LEN + 3] = 'a', FILE_NAME_Out[NAME_LEN + 4] = 'n', FILE_NAME_Out[NAME_LEN + 5] = 's';
	
	for (int ID = LID; ID <= RID; ++ID) {
		srand ((unsigned long long)(new char) * time (0));
		FILE_NAME_In[NAME_LEN] = '0' + ID / 10,
		FILE_NAME_In[NAME_LEN + 1] = '0' + ID % 10;
		FILE_NAME_Out[NAME_LEN] = '0' + ID / 10,
		FILE_NAME_Out[NAME_LEN + 1] = '0' + ID % 10;
		Out = fopen (FILE_NAME_In, "w");
		MAKEDATA :: main1 ();
		fclose (Out);
		In = fopen (FILE_NAME_In, "r");
		Out = fopen (FILE_NAME_Out, "w");
		CODE :: main ();
		fclose (In), fclose (Out);
	}
	return 0;
}

