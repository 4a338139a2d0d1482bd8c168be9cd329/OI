/**************************************************************
	File name: std.cpp
	Author: huhao
	Email: 826538400@qq.com
	Create time: 10/27/2018, 11:16:21 AM
**************************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 1000010
char s[10][N];
int n,f[10][N],a[N];
int main()
{
    freopen("block.in", "r", stdin);
    freopen("block.out", "w", stdout);
	fr(i,0,2)scanf("%s",s[i]+1);
	n=strlen(s[0]+1);
	fr(i,1,n)a[i]=((s[0][i]=='O')<<2)|((s[1][i]=='O')<<1)|(s[2][i]=='O');
//	fr(i,1,n)printf("%d%c",a[i],i==n?'\n':' ');
	fr(i,1,n)fr(j,0,7)
		if((j&a[i-1])==j)
		{
			int o=a[i];
			if(j==0)//XXX
				f[o][i]=max(f[o][i],f[0][i-1]);
			if(j==1)//XXO
			{
				if(o==3)//XOO
					f[0][i]=max(f[0][i],f[1][i-1]+1);
				if(o==7)//OOO
					f[4][i]=max(f[4][i],f[1][i-1]+1);
				f[o][i]=max(f[o][i],f[1][i-1]);
			}
			if(j==2)//XOX
			{
				if(o==3)//XOO
					f[0][i]=max(f[0][i],f[2][i-1]+1);
				if(o==6)//OOX
					f[0][i]=max(f[0][i],f[2][i-1]+1);
				if(o==7)//OOO
					f[1][i]=max(f[1][i],f[2][i-1]+1),
					f[4][i]=max(f[4][i],f[2][i-1]+1);
				f[o][i]=max(f[o][i],f[2][i-1]);
			}
			if(j==3)//XOO
			{
				if(o==1||o==2)//XXO|XOX
					f[0][i]=max(f[0][i],f[3][i-1]+1);
				if(o==3)//XOO
					f[0][i]=max(f[0][i],f[3][i-1]+1),
					f[1][i]=max(f[1][i],f[3][i-1]+1),
					f[2][i]=max(f[2][i],f[3][i-1]+1);
				if(o==5)//OXO
					f[4][i]=max(f[4][i],f[3][i-1]+1);
				if(o==6)//OOX
					f[4][i]=max(f[4][i],f[3][i-1]+1),
					f[0][i]=max(f[0][i],f[3][i-1]+1);
				if(o==7)//OOO
					f[1][i]=max(f[1][i],f[3][i-1]+1),
					f[4][i]=max(f[4][i],f[3][i-1]+1),
					f[5][i]=max(f[5][i],f[3][i-1]+1),
					f[6][i]=max(f[6][i],f[3][i-1]+1);
				f[o][i]=max(f[o][i],f[3][i-1]);
			}
			if(j==4)//OXX
			{
				if(o==6)//OOX
					f[0][i]=max(f[0][i],f[4][i-1]+1);
				if(o==7)//OOO
					f[1][i]=max(f[1][i],f[4][i-1]+1);
				f[o][i]=max(f[o][i],f[4][i-1]);
			}
			if(j==5)//OXO
			{
				if(o==3||o==6)//XOO|OOX
					f[0][i]=max(f[0][i],f[5][i-1]+1);
				if(o==7)//OOO
					f[1][i]=max(f[1][i],f[5][i-1]+1),
					f[4][i]=max(f[4][i],f[5][i-1]+1);
				f[o][i]=max(f[o][i],f[5][i-1]);
			}
			if(j==6)//OOX
			{
				if(o==2||o==4)//XOX|OXX
					f[0][i]=max(f[0][i],f[6][i-1]+1);
				if(o==3)//XOO
					f[0][i]=max(f[0][i],f[6][i-1]+1),
					f[1][i]=max(f[1][i],f[6][i-1]+1);
				if(o==5)//OXO
					f[1][i]=max(f[1][i],f[6][i-1]+1);
				if(o==6)//OOX
					f[0][i]=max(f[0][i],f[6][i-1]+1),
					f[2][i]=max(f[2][i],f[6][i-1]+1),
					f[4][i]=max(f[4][i],f[6][i-1]+1);
				if(o==7)//OOO
					f[3][i]=max(f[3][i],f[6][i-1]+1),
					f[5][i]=max(f[5][i],f[6][i-1]+1),
					f[1][i]=max(f[1][i],f[6][i-1]+1),
					f[4][i]=max(f[4][i],f[6][i-1]+1);
				f[o][i]=max(f[o][i],f[6][i-1]);
			}
			if(j==7)//OOO
			{
				if(o==1||o==2||o==4)//XXO|XOX|OXX
					f[0][i]=max(f[0][i],f[7][i-1]+1);
				if(o==3)//XOO
					f[0][i]=max(f[0][i],f[7][i-1]+1),
					f[1][i]=max(f[1][i],f[7][i-1]+1),
					f[2][i]=max(f[2][i],f[7][i-1]+1);
				if(o==5)//OXO
					f[1][i]=max(f[1][i],f[7][i-1]+1),
					f[4][i]=max(f[4][i],f[7][i-1]+1);
				if(o==6)//OOX
					f[0][i]=max(f[0][i],f[7][i-1]+1),
					f[2][i]=max(f[2][i],f[7][i-1]+1),
					f[4][i]=max(f[4][i],f[7][i-1]+1);
				if(o==7)//OOO
					f[0][i]=max(f[0][i],f[7][i-1]+2),
					f[6][i]=max(f[6][i],f[7][i-1]+1),
					f[5][i]=max(f[5][i],f[7][i-1]+1),
					f[3][i]=max(f[3][i],f[7][i-1]+1),
					f[1][i]=max(f[1][i],f[7][i-1]+1),
					f[4][i]=max(f[4][i],f[7][i-1]+1);
				f[o][i]=max(f[o][i],f[7][i-1]);
			}
		}
	printf("%d\n",max(max(max(f[0][n],f[1][n]),max(f[2][n],f[3][n])),max(max(f[4][n],f[5][n]),max(f[6][n],f[7][n]))));
	return 0;
}
