#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i )
#define mem(a) memset ( (a), 0, sizeof ( a ) )
#define str(a) strlen ( a )
typedef long long LL;
template<class T> int maxx(T a, T b) { return a > b ? a : b; }
template<class T> int minn(T a, T b) { return a < b ? a : b; }
template<class T> int abss(T a) { return a > 0 ? a : -a; }
#define max maxx
#define min minn
#define abs abss

const int maxn = 1000010;

struct node
{
    int l, r;
} a[maxn];
int n;
bool vis[maxn];

inline bool cmp(node a, node b)
{
    return a.r < b.r || (a.r == b.r && a.l > b.l);
}

inline bool solve(int x)
{
    mem(vis);
    if ( x == 0 ) return true;
    REP(i, 1, n)
    {
        int sum = 0;
        REP(j, a[i].l, a[i].r - 1)
        {
            if ( vis[j] ) continue ;
            sum ++ ;
            vis[j] = true;
            if ( sum == x ) break ;
        }
        if ( sum != x ) return false;
    }
    return true;
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
#endif
    scanf("%d", &n);
    REP(i, 1, n) scanf("%d%d", &a[i].l, &a[i].r);
    sort ( a + 1, a + n + 1, cmp ) ;
    int l = 0, r = 1000000, ans = 0;
    while ( l <= r ) 
    {
        int Mid = (l + r) / 2;
        if ( solve(Mid) ) 
        {
            ans = max(ans, Mid);
            l = Mid + 1;
        }
        else r = Mid - 1;
    }
    printf("%d\n", ans * n);
    return 0;
}
