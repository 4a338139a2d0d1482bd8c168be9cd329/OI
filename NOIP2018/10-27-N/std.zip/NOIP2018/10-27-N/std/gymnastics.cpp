#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i )
#define mem(a) memset ( (a), 0, sizeof ( a ) )
#define str(a) strlen ( a )
typedef long long LL;
template<class T> int maxx(T a, T b) { return a > b ? a : b; }
template<class T> int minn(T a, T b) { return a < b ? a : b; }
template<class T> int abss(T a) { return a > 0 ? a : -a; }
#define max maxx
#define min minn
#define abs abss

int n, a[11], ans;

int main()
{
#ifndef ONLINE_JUDGE
    freopen("gymnastics.in", "r", stdin);
    freopen("gymnastics.out", "w", stdout);
#endif
    n = 10;
    REP(i, 1, n) scanf("%d", &a[i]);
    REP(i, 2, n) ans += max(a[i], a[i - 1]);
    printf("%d\n", ans);
    return 0;
}
