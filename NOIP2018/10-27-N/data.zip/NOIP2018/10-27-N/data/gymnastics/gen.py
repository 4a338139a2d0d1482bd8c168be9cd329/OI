from cyaron import *
n = 10
for i in range(1, 21):
    test_data = IO(file_prefix="gymnastics", data_id=i)
    
    for j in range(1, n + 1):
        s = randint(1, n) 
        test_data.input_write(s)

    test_data.output_gen("~/test/PJ-1/source/gymnastics/gymnastics");
