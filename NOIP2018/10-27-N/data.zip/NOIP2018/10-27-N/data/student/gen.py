from cyaron import *

# 1 -> 5
_n = ati([0, 3, 5, 6, 10, 10])

for i in range(1, 6):
    test_data = IO(file_prefix="student", data_id=i)
    
    n = _n[i]
    Max = 10
    test_data.input_writeln(n)

    for j in range(1, n + 1):
        a = randint(1, Max)
        test_data.input_write(a)

    test_data.output_gen("~/test/PJ-1/data/student/student")

# 6 -> 8
_n = ati([35, 49, 50])
_a = ati([3, 765, 1000])

for i in range(6, 9):
    test_data = IO(file_prefix="student", data_id=i)
    
    n = _n[i - 6]
    test_data.input_writeln(n)

    for j in range(1, n + 1):
        a = _a[i - 6]
        test_data.input_write(a)
    
    test_data.output_gen("~/test/PJ-1/data/student/student")

# 9 -> 10
_n = ati([26, 30])

for i in range(9, 11):
    test_data = IO(file_prefix="student", data_id=i)
    
    n = _n[i - 9]
    Max = 40
    test_data.input_writeln(n)

    for j in range(1, n + 1):
        a = randint(1, Max)
        test_data.input_write(a)
    
    test_data.output_gen("~/test/PJ-1/data/student/student")

# 11 -> 15
_n = ati([1E3, 1E3 - 67, 1E3 - 68, 1E3 - 79, 1E3 - 28])

for i in range(11, 16):
    test_data = IO(file_prefix="student", data_id=i)
    
    n = _n[i - 11]
    Max = 10000
    test_data.input_writeln(n)

    for j in range(1, n + 1):
        a = randint(1, Max)
        test_data.input_write(a)
    
    test_data.output_gen("~/test/PJ-1/data/student/student")

# 16 -> 25
_n = ati([1E6, 1E6 - 67, 1E6 - 68, 1E6 - 79, 1E6 - 28, 1E6 - 7, 1E6, 1E6 - 12, 1E6 - 10, 1E6 - 1223])

for i in range(16, 26):
    test_data = IO(file_prefix="student", data_id=i)
    
    n = _n[i - 16]
    Max = 10000000
    test_data.input_writeln(n)

    for j in range(1, n + 1):
        a = randint(1, Max) + 1000000
        test_data.input_write(a)
    
    test_data.output_gen("~/test/PJ-1/data/student/student")
