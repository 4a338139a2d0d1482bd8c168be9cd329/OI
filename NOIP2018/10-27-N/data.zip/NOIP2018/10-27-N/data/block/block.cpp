#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i )
#define mem(a) memset ( (a), 0, sizeof ( a ) )
#define str(a) strlen ( a )
typedef long long LL;
template<class T> int maxx(T a, T b) { return a > b ? a : b; }
template<class T> int minn(T a, T b) { return a < b ? a : b; }
template<class T> int abss(T a) { return a > 0 ? a : -a; }
#define max maxx
#define min minn
#define abs abss

const int maxn = 1000010;

int dp[maxn][3][3], n, ans, up[maxn], down[maxn];
char a[2][maxn];

int main()
{
    scanf("%s", a[0]);
    getchar();
    scanf("%s", a[1]);
    n = str(a[1]);
    REP(i, 0, n - 1) up[i + 1] = a[0][i] == 'X' ? 1 : 0;        
    REP(i, 0, n - 1) down[i + 1] = a[1][i] == 'X' ? 1 : 0;
    REP(i, 2, n)
    {
        dp[i][0][0] = max(max(dp[i - 1][0][0], dp[i - 1][0][1]), max(dp[i - 1][1][0], dp[i - 1][1][1]));
        if ( up[i - 1] == 0 && down[i - 1] == 0 && down[i] == 0 )
            dp[i][0][1] = dp[i - 1][0][0] + 1;
        if ( up[i - 1] == 0 && up[i] == 0 && down[i - 1] == 0 )
            dp[i][1][0] = dp[i - 1][0][0] + 1;
        if ( up[i - 1] == 0 && up[i] == 0 && down[i] == 0 ) 
            dp[i][1][1] = max(dp[i - 1][0][0], dp[i - 1][0][1]) + 1;
        if ( up[i] == 0 && down[i - 1] == 0 && down[i] == 0 )
            dp[i][1][1] = max(dp[i][1][1], max(dp[i - 1][0][0] + 1, dp[i - 1][1][0] + 1));
    }
    REP(i, 0, 1) REP(j, 0, 1) ans = max(ans, dp[n][i][j]);
    printf("%d\n", ans);
    return 0;
}
