from cyaron import *

for i in range(15, 16):
    test_data = IO(file_prefix="block", data_id=i)
    str1 = String.random(1000000 - i, charset="XXXXXXOOOO")
    str2 = String.random(1000000 - i, charset="XXXXXXOOOO")
    test_data.input_writeln(str1)
    test_data.input_writeln(str2)
    test_data.output_gen("~/test/PJ-1/data/block/block")
