/**************************************************************
	File name: gen.cpp
	Author: huhao
	Email: 826538400@qq.com
	Create time: 10/27/2018, 11:10:33 AM
**************************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#include<stdlib.h>
int n,m;
int main()
{
	srand((unsigned long long)new char);
	n=1000000;m=200;
	fr(j,1,3)
	{
		fr(i,1,n)
		{
			int k=rand()%5==0;
			if(k&&m)
			{
				putchar('O');
//				m--;
			}
			else putchar('X');
		}
		putchar(10);
	}
	return 0;
}