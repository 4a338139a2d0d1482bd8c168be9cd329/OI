cd /home/huhao/Documents/data/1/
g++ gen.cpp -o gen -O2 -lm
g++ std.cpp -o std -O2 -lm
for i in {91..100}; do
	./gen>block$i.in
	./std<block$i.in>block$i.out
done 