from cyaron import *

for i in range(19, 20):
    test_data = IO(file_prefix="game", data_id=i)
    n = 5000 - i
    Max = 500000
    test_data.input_writeln(n)
    for j in range(1, n + 1):
        l = randint(1, Max)
        r = randint(1, Max) + l
        test_data.input_writeln(l, r)
    test_data.output_gen("~/test/PJ-1/data/game/game")
