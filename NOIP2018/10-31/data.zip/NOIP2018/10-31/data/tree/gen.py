import sys, os
from random import *

cs = [6, 6, 5, 5, 5]
nr = [20, 50, 200, 2000, 2000]
nl = [10, 40, 150, 1500, 1500]

def gen(n, ty, lim):
    outp = ""
    val = [randint(1, lim) for i in range(n + 1)]
    son = [[] for i in range(n + 1)]
    for x in range(2, n + 1):
        fa = randint(max(1, x - 10), x - 1)
        son[fa].append(x)

    for x in range(1, n + 1):
        if(ty == True):
            val[x] = val[1]

        outp += "%d %d " % (val[x], len(son[x]))
        for y in son[x]:
            outp += "%d " % y
        outp += "\n"
    return outp

for i in range(5):
    print ("case %d:" % i)

    for j in range(cs[i]):
        fname = "tree%d-%d" % (i + 1, j + 1)

        n1 = randint(nl[i], nr[i])
        n2 = randint(nl[i], nr[i])
        a = randint(1, 10000)
        b = randint(1, 10000)

        outp = "%d %d %d %d\n" % (n1, n2, a, b)
        outp = outp + gen(n1, (i == 3), 10000)
        outp = outp + gen(n2, (i == 3), 10000)

        print (outp, file = open("%s.in" % fname, "w"))
        os.system("./tree < %s.in > %s.out" % (fname, fname))

#for i in range(3):
#    fname = "tree%d" % (i + 1)
#    n1 = randint(nl[i], nr[i])
#    n2 = randint(nl[i], nr[i])
#    a = randint(1, 10 ** (i + 1))
#    b = randint(1, 10 ** (i + 1))
#
#    outp = "%d %d %d %d\n" % (n1, n2, a, b)
#    outp = outp + gen(n1, (i == 2), 10 ** (i + 1))
#    outp = outp + gen(n2, (i == 2), 10 ** (i + 1))
#
#    print (outp, file = open("%s.in" % fname, "w"))
#    os.system("./tree < %s.in > %s.out" % (fname, fname))
