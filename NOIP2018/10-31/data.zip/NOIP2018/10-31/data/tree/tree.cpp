#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 4000;

struct tree {

    int n;
    vector<int> G[N + 5];
    int val[N + 5], seq[N + 5];
    int sub[N + 5], w[N + 5], dfn[N + 5], efn[N + 5], dfs_clk;

    void dfs(int u) {
        dfn[u] = ++ dfs_clk;
        w[dfn[u]] = val[u];
        seq[dfs_clk] = 0;
        
        for(auto v : G[u]) {
            dfs(v);
            val[u] += val[v];
        }

        sub[dfn[u]] = val[u];
        efn[dfn[u]] = ++ dfs_clk;
        seq[dfs_clk] = 1;
    }

    void init(int _n) {
        n = _n;
        for(int i = 1; i <= n; ++i) {
            static int k, v;
            read(val[i]); read(k);
            while(k--) {
                read(v);
                G[i].pb(v);
            }
        }
        dfs(1);
    }
};

tree t[2];
int n, m, a, b;
ll dp[N + 5][N + 5];

int main() {
    //freopen("tree.in", "r", stdin);
    //freopen("tree.out", "w", stdout);

    read(n), read(m);
    read(a), read(b);
    t[0].init(n), t[1].init(m);

    memset(dp, 0x3f, sizeof dp);
    const ll OO = dp[0][0];

    dp[1][1] = 0;
    for(int i = 1; i <= 2*n + 1; ++i) {
        for(int j = 1; j <= 2*m + 1; ++j) if(dp[i][j] < OO) {
            if(i <= 2*n && t[0].seq[i] == 0) chkmin(dp[t[0].efn[i] + 1][j], dp[i][j] + (ll) a * t[0].sub[i]);
            if(j <= 2*m && t[1].seq[j] == 0) chkmin(dp[i][t[1].efn[j] + 1], dp[i][j] + (ll) a * t[1].sub[j]);

            if(i <= 2*n && j <= 2*m && t[0].seq[i] == t[1].seq[j]) {
                if(t[0].seq[i] == 0) {
                    chkmin(dp[i + 1][j + 1], dp[i][j] + (ll) b * std::abs(t[0].w[i] - t[1].w[j]));
                } else {
                    chkmin(dp[i + 1][j + 1], dp[i][j]);
                }
            }
        }
    }
    printf("%lld\n", dp[2*n + 1][2*m + 1]);

    return 0;
}
