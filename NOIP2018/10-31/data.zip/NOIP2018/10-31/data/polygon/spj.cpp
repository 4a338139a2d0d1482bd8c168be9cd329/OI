#include "testlib.h"
#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

int n;
pii p[1000];

pii operator - (pii a, pii b) {
    return mp(a.fst - b.fst, a.snd - b.snd);
}

int cross(pii a, pii b) {
    return a.fst * b.snd - a.snd * b.fst;
}
int dot(pii a, pii b) {
    return a.fst * b.fst + a.snd * b.snd;
}

bool onseg(pii a, pii b, pii c) {
    return cross(b - a, c - a) == 0 && dot(b - a, c - a) <= 0;
}

bool inter(pii a, pii b, pii c, pii d) {
    if((cross(a - c, d - c) * cross(b - c, d - c) < 0 && cross(d - a, b - a) * cross(c - a, b - a) < 0) 
        || onseg(a, c, d) 
        || onseg(b, c, d) 
        || onseg(c, a, b) 
        || onseg(d, a, b)) {

        return true;
    }
    return false;
}

int main(int argc, char* argv[]) {

    registerLemonChecker(argc, argv);

    n = inf.readInt();
    int t = ans.readInt();

    for(int i = 0; i < n; ++i) {
        p[i].fst = ouf.readInt(1, 25);
        p[i].snd = ouf.readInt(1, 25);
    }

    for(int i = 0; i < n; ++i)
        for(int j = i + 1; j < n; ++j) {
            if(p[i].fst == p[j].fst && p[i].snd == p[j].snd) {
                quitf(_wa, "Point %d and %d are on the same Position.", i + 1, j + 1);
            }
        }

    for(int i = 1; i <= n; ++i) {
        for(int j = i + 2; j <= n; ++j) {
            if(j % n == i - 1) continue;
            if(inter(p[i % n], p[i - 1], p[j % n], p[j - 1])) {
                quitf(_wa, "Edge (%d,%d)-(%d,%d) and (%d,%d)-(%d,%d) intersect.", 
                        p[i%n].fst, p[i%n].snd, p[i-1].fst, p[i-1].snd, p[j%n].fst, p[j%n].snd, p[j-1].fst, p[j-1].snd);
            }
        }
        if(cross(p[i % n] - p[i - 1], p[(i + 1) % n] - p[i % n]) == 0) {
            quitf(_wa, "Adjacent edges are parralle.");
        }
    }

    int area = 0;
    for(int i = 1; i <= n; ++i) {
        area += cross(p[i - 1], p[i % n]);
    }

    if(area < 0) {
        area = -area;
    }

    if(area != t) {
        quitf(_wa, "Area %lf isn't the minimum %lf.", .5 * area, .5 * t);
    } else {
        quitf(_ok, "Correct answer!");
    }

    return 0;
}

