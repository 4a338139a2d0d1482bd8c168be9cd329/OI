#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

int n;
vector<int> ans, l, r;

int main() {
    freopen("polygon.in", "r", stdin);
    freopen("polygon.out", "w", stdout);

    read(n);
    if(n == 3) ans = { 101, 201, 202 };
    else if(n == 4) ans = { 101, 201, 202, 102 };
    else if(n == 5) ans = { 101, 201, 303, 202, 102 };
    else {
        for(int i = 1; i <= 12; ++i) {
            l.pb(200 + 2 * i - 1), l.pb(100 + 2 * i);
            l.pb(100 + 2 * i + 1), l.pb(200 + 2 * i);
            for(int j = 3; j <= 25; ++j) { r.pb(j * 100 + 2 * i - 1 + (j % 2 == 0)); }
            for(int j = 25; j >= 3; --j) { r.pb(j * 100 + 2 * i + (j % 2 == 0)); }

            if((int) l.size() + (int) r.size() + 1 >= n) { l.pb(200 + 2 * i + 1); break; }
        }

        std::reverse(l.begin(), l.end());
        for(auto x : l) ans.pb(x);
        for(auto y : r) ans.pb(y);

        while((int) ans.size() > n) {
            ans.erase(max_element(ans.begin(), ans.end()));
        }
    }

    for(auto p : ans) {
        printf("%d %d\n", p / 100, p % 100);
    }

    return 0;
}
