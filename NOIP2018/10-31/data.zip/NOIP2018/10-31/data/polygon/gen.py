import math

for i in range(1, 51):
    print (int(math.exp(i / 7.5 + 1) / 3.8 + min(i + 2, 30)))
