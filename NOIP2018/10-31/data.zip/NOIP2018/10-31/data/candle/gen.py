import sys, os
from random import *

cs = [8, 6, 6, 8]
nl = [10, 40, 200, 200]
nr = [20, 50, 250, 250]

# for i in range(3):
#     fname = "candle%d" % (i + 1)
# 
#     n = randint(nl[i], nr[i])
#     fa = [0 for i in range(n + 1)]
#     ed = [1 for i in range(n + 1)]
# 
#     outp = "%d\n" % n
#     m0 = n // 4
#     m1 = int(pow(n, 0.5))
# 
#     for x in range(2, n + 1):
# 
#         if(i == 0): 
#             fa[x] = x // 2
# 
#         if(i == 1):
#             fa[x] = randint(max(x - 50, 1), x - 1)
# 
#         if(i == 2):
#             if(x <= m0):
#                 fa[x] = x - 1
#             else:
#                 fa[x] = randint(1, m0)
# 
#     val = randint(1, 100000)
# 
#     for x in range(2, n + 1):
#         if(i == 2):
#             outp += "%d %d %d\n" % (x, fa[x], val)
#         else:
#             outp += "%d %d %d\n" % (x, fa[x], randint(1, 100000))
# 
#     print (outp, file = open("%s.in" % (fname), "w"))
#     os.system("./candle < %s.in > %s.out" % (fname, fname))

for i in range(4):
    print ("Case %d:" % (i + 1))

    for j in range(cs[i]):
        fname = "candle%d-%d" % (i + 1, j + 1)

        n = randint(nl[i], nr[i])
        fa = [0 for i in range(n + 1)]
        ed = [1 for i in range(n + 1)]

        outp = "%d\n" % n
        m0 = n // 4
        m1 = int(pow(n, 0.5))

        for x in range(2, n + 1):

            if(j % 4 == 0): 
                fa[x] = x // 2

            if(j % 4 == 1):
                fa[x] = randint(max(x - 50, 1), x - 1)

            if(j % 4 == 2):
                if(x <= m0):
                    fa[x] = x - 1
                else:
                    fa[x] = randint(1, m0)

            if(j % 4 == 3):
                if(x <= m1):
                    fa[x] = 1
                    ed[x] = x
                else:
                    if(randint(1, 5) > 1):
                        fa[x] = ed[1]
                        ed[1] = x
                    else:
                        y = randint(2, m1)
                        fa[x] = ed[y]
                        ed[y] = x

        val = randint(1, 100000)

        for x in range(2, n + 1):
            if(i == 2):
                outp += "%d %d %d\n" % (x, fa[x], val)
            else:
                outp += "%d %d %d\n" % (x, fa[x], randint(1, 100000))

        print (outp, file = open("%s.in" % (fname), "w"))
        os.system("./candle < %s.in > %s.out" % (fname, fname))
