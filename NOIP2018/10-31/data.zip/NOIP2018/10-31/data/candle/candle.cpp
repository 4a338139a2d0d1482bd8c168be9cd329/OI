#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 500;

struct edge {
    int a, b, c;
};

int n;
edge e[N + 5];
std::set <int> s;

int mn[N + 5];
int dis[N + 5][N + 5];
vector<pii> G[N + 5];
vector<int> leaf, st;

bool vis[N + 5];
void dfs(int u, int f = 0) {
    if(vis[u]) 
        mn[u] = 0;
    else 
        mn[u] = oo;

    for(auto v : G[u]) {
        if(v.fst == f) continue;

        dfs(v.fst, u);
        chkmin(mn[u], mn[v.fst] + v.snd);
    }
}

void dfs1(int u, int f = 0) {
    for(auto v : G[u]) {
        if(v.fst == f) continue;

        chkmin(mn[v.fst], mn[u] + v.snd);
        dfs1(v.fst, u);
    }
}

void get_dis() {
    for(int i = 1; i <= n; ++i) vis[i] = false;
    for(auto z : st) vis[z] = true;

    dfs(1);
    dfs1(1);
}

int main() {
    //freopen("candle.in", "r", stdin);
    //freopen("candle.out", "w", stdout);

    memset(dis, oo, sizeof dis);

    read(n);
    for(int i = 1; i <= n; ++i) dis[i][i] = 0;
    for(int i = 1; i < n; ++i) {
        static int a, b, c;
        read(a), read(b), read(c);

        G[a].pb(mp(b, c));
        G[b].pb(mp(a, c));
        dis[a][b] = dis[b][a] = c;
        e[i] = (edge) { a, b, c };
    }

    for(int k = 1; k <= n; ++k) {
        if(G[k].size() == 1) leaf.pb(k);
        for(int i = 1; i <= n; ++i) {
            for(int j = 1; j <= n; ++j) {
                chkmin(dis[i][j], dis[i][k] + dis[k][j]);
            }
        }
    }

    for(auto x : leaf) {
        int mx = 0;
        for(auto y : leaf) chkmax(mx, dis[x][y]);
        s.insert(mx << 1);

        for(auto y : leaf) {
            mx = 0; 
            st.clear();
            for(auto z : leaf) 
                if(dis[z][y] >= dis[x][y]) st.pb(z);
            get_dis();

            for(int i = 1; i <= n; ++i) { chkmax(mx, mn[i] << 1); }
            for(int i = 1; i < n; ++i) {
                if(std::abs(mn[e[i].a] - mn[e[i].b]) != e[i].c) {
                    chkmax(mx, mn[e[i].a] + mn[e[i].b] + e[i].c);
                }
            }

            s.insert(mx);
        }

        for(auto y : leaf) {
            for(int id = 1; id < n; ++id) {
                int a = e[id].a, b = e[id].b, c = e[id].c; 
                if(dis[x][a] >= dis[x][b]) std::swap(a, b);

                if(dis[x][a] + c + dis[y][b] == dis[x][y] 
                         && (dis[x][a] << 1) <= dis[x][y]
                         && (dis[x][b] << 1) >= dis[x][y]) {

                    mx = 0;
                    st.clear();
                    for(auto z : leaf) {
                        if(dis[z][a] < dis[z][b] && dis[z][a] >= dis[x][a]) st.pb(z);
                        if(dis[z][a] > dis[z][b] && dis[z][b] >= dis[y][b]) st.pb(z);
                    }

                    get_dis();
                    for(int i = 1; i <= n; ++i) { chkmax(mx, mn[i] << 1); }
                    for(int i = 1; i < n; ++i) {
                        if(std::abs(mn[e[i].a] - mn[e[i].b]) != e[i].c) {
                            chkmax(mx, mn[e[i].a] + mn[e[i].b] + e[i].c);
                        }
                    }

                    s.insert(mx);
                    break;
                }
            }
        }
    }

    printf("%d\n", (int) s.size());
    return 0;
}
