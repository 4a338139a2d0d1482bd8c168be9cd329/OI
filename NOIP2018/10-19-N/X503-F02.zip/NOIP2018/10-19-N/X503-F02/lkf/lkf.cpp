#include<bits/stdc++.h>
using namespace std;
int n,k;
const int N=334;
int a[N];
int ans,Max;
bool Map[N][N];
int father[N];
int sum[N];
int r;
void found(int x)
{
	if(x==r) return;
	else
	{
		int s=0;
		for(int i=1;i<=n;i++)
		{
			if(Map[x][i])
			{ans++;Max=max(Max,ans);Map[x][i]=0;found(i);Map[x][i]=1;ans--;}
			else s++;
		}
		if(s==n) return;
	}
}
void dfs(int x)
{
	int r=x+k;
	bool b=0;
	for(int i=1;i<=n;i++)
		if(a[i]==k) b=1;
	if(b==0) return;
	else
	{
		for(int i=1;i<=n;i++)
		{
			if(Map[i][x])
			{
				ans=0;
				Max=max(Max,ans);
				Map[i][x]=0;
				found(i);
				Map[i][x]=1;
				ans--;
			}
		}
	}
}
int main()
{
	freopen("lkf.in","r",stdin);
	freopen("lkf.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	int x,y;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		Map[x][y]=1;
		Map[y][x]=1;
	}
	sort(a+1,a+1+n);
	int maxn=a[n];
	int maxnn=a[n]-k;
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]<=maxnn)
		{
			dfs(a[i]);
		}
	}
	printf("%d",Max);
	return 0;
}
