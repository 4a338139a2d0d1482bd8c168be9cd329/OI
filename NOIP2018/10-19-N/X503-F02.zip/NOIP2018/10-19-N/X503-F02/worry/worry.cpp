#include<bits/stdc++.h>
using namespace std;
int n,m;
const int N=5005;
int v[N][N],a[N],b[N];
int Map[N][N];
int ans;
int q,minl;
const int M=1e9;
void dfs(int x)
{

	//printf("%d\n",q);
	if(x!=q)
	{
		int s=0;
		for(int i=1;i<=n&&i!=x;i++)
		{
			if(Map[i][x])
			{
				ans+=v[i][x];
				//printf("%d\n",i);
				dfs(i);
				ans-=v[i][x];
			}
			else
			{s++;continue;}
		}
		if(s==n-1) return;
	}
	else
	{
		if(ans>=minl) minl=ans;
		else return;
	}
}
int main()
{
	freopen("worry.in","r",stdin);
	freopen("worry.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&a[i],&b[i]);
		Map[a[i]][b[i]]=1;
		v[a[i]][b[i]]=1;
		Map[b[i]][a[i]]=1;
		v[a[i]][b[i]]=1;
	}
	int A,B,C;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&A,&B,&C);
		v[A][B]=C;
		Map[A][B]=1;
		Map[B][A]=1;
		v[B][A]=C;
	}
	for(int i=1;i<=n;i++)
	{
		Map[a[i]][b[i]]=0;
		Map[b[i]][a[i]]=0;
		q=b[i];
		int minl=M;
		ans=0;
		dfs(a[i]);
		if(ans==M) printf("-1\n");
		else printf("%d\n",minl);
		Map[a[i]][b[i]]=1;	
		Map[b[i]][a[i]]=1;
	}
	return 0;
}
