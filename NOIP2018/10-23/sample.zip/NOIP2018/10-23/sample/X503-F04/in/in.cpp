#include<bits/stdc++.h>
using namespace std;
#define rep(i, a, b) for(int i = (a), i##_end_ = (b); i <= i##_end_; ++i)
#define drep(i, a, b) for(int i = (a), i##_end_ = (b); i >= i##_end_; --i)
#define clar(a, b) memset((a), (b), sizeof(a))
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define Debug(s) debug("The massage in line %d, Function %s: %s\n", __LINE__, __FUNCTION__, s)
typedef long long LL;
typedef long double LD;
const int BUF_SIZE = (int)1e6 + 10;
struct fastIO {
    char buf[BUF_SIZE], buf1[BUF_SIZE];
    int cur, cur1;
    FILE *in, *out;
    fastIO() {
        cur = BUF_SIZE, in = stdin, out = stdout;
        cur1 = 0;
    }
    inline char getchar() {
        if(cur == BUF_SIZE) fread(buf, BUF_SIZE, 1, in), cur = 0;
        return *(buf + (cur++));
    }
    inline void putchar(char ch) {
        *(buf1 + (cur1++)) = ch;
        if (cur1 == BUF_SIZE) fwrite(buf1, BUF_SIZE, 1, out), cur1 = 0;
    }
    inline int flush() {
        if (cur1 > 0) fwrite(buf1, cur1, 1, out);
        return cur1 = 0;
    }
}IO;
#define getchar IO.getchar
#define putchar IO.putchar
int read() {
    char ch = getchar();
    int x = 0, flag = 1;
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') flag *= -1;
    for(;isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x * flag;
}
void write(int x) {
    if(x < 0) putchar('-'), x = -x;
    if(x >= 10) write(x / 10);
    putchar(x % 10 + 48);
}
void putString(char s[], char EndChar = '\n') {
    rep(i, 0, strlen(s) - 1) putchar(*(s + i));
    if(~EndChar) putchar(EndChar);
}

const int Maxn = 400009;
int n, a[Maxn];
namespace SGMT_tree {
	int tree[Maxn << 3], pos[Maxn << 3];
#define lc(x) ((x) << 1)
#define rc(x) ((x) << 1 | 1)
#define ls rt << 1, l, mid
#define rs rt << 1 | 1, mid + 1, r
	void pushup(int rt) {
		if(tree[lc(rt)] > tree[rc(rt)]) {
			tree[rt] = tree[lc(rt)];
			pos[rt] = pos[lc(rt)];
		} else {
			tree[rt] = tree[rc(rt)];
			pos[rt] = pos[rc(rt)];
		}
	}
	void build(int rt, int l, int r) {
		if(l == r) {
			tree[rt] = a[l], pos[rt] = l;
			return ;
		}
		int mid = (l + r) >> 1;
		build(ls), build(rs);
		pushup(rt);
	}
	void modify(int rt, int l, int r, int p, int v) {
		if(l == r) {
			tree[rt] = v, pos[rt] = l;
			return ;
		}
		int mid = (l + r) >> 1;
		(p <= mid) ? modify(ls, p, v) : modify(rs, p, v);
		pushup(rt);
	}
}

struct Opt {
	int l, r, v;
}quer[Maxn];
int FLAG = 1, m;

namespace INIT {
    void Main() {
		n = read(), m = read();

		rep(i, 1, n) a[i] = read();
		
		rep(i, 1, m) {
			int l = read(), r = read(), v = read();
			quer[i] = (Opt){l, r, v};

			if(!(l == 1 && r == n)) FLAG = 0;
		}
    }
}
namespace PTS15 {
	void Main() {
		SGMT_tree :: build(1, 1, n);
		rep(i, 1, m) {
			int l = quer[i].l, r = quer[i].r, v = quer[i].v;
			write(SGMT_tree :: tree[1]), putchar('\n');
			SGMT_tree :: modify(1, 1, n, SGMT_tree :: pos[1], v);
		}
	}
}
namespace BF { 
	int Query(int l, int r, int v) {
		if (l <= r) {
			rep(i, l, r) if (a[i] > v) swap(a[i], v);
		} else {
			rep(j, l, n) if (a[j] > v) swap(a[j], v);
			rep(j, 1, r) if (a[j] > v) swap(a[j], v);
		}
		return v;
	}
	void Main() {
		rep(i, 1, m) write(Query(quer[i].l, quer[i].r, quer[i].v)), putchar('\n');
	}
}
namespace SOLVE {
    void Main() {
	}
}
int main() {
	freopen("in.in", "r", stdin);
	freopen("in.out", "w", stdout);

    INIT :: Main();
	if(FLAG) PTS15 :: Main();
	else BF :: Main();
//	SOLVE :: Main();
#ifdef Qrsikno
    debug("\nRunning time: %.3lf(s)\n", clock() * 1.0 / CLOCKS_PER_SEC);
#endif
    return IO.flush();
}

