#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
#include<queue>
using namespace std;
int read(){
	int res=0,fl=1;
	char r=getchar();
	for(;!isdigit(r);r=getchar()) if(r=='-') fl=-1;
	for(;isdigit(r);r=getchar()) res=(res<<1)+(res<<3)+r-'0';
	return res*fl;
}
const int Maxn=5e5+10;
int f[Maxn],g[Maxn];
vector <int> Mapf[Maxn];
vector <int> Mapg[Maxn];
int x[Maxn];
int solve(int now){
	if(Mapf[now].size()==0){
		x[now]=1;
		return x[now];
	}
	int sum=0;
	for(int i=0;i<Mapf[now].size();++i){
		sum+=solve(Mapf[now][i]);
	}
	x[now]=1-sum;
	return 1;
}
int main(){
	freopen("cpp.in","r",stdin);
	freopen("cpp.out","w",stdout);
	int n=read();
	int rootf,rootg;
	bool fl=1;
	for(int i=1;i<=n;++i){
		f[i]=read();
		if(f[i]==-1)rootf=i;
		Mapf[f[i]].push_back(i);
	}
	for(int i=1;i<=n;++i){
		g[i]=read();
		if(f[i]!=g[i])fl=0;
		if(g[i]==-1)rootg=i;
		Mapg[g[i]].push_back(i);
	}
	if(fl) {
		int a = solve(rootf);
		printf("POSSIBLE\n");
		for(int i = 1; i <= n; ++i) printf("%d ", x[i]);
		puts("");
		return 0;
	}
	printf("IMPOSSIBLE\n");
	return 0;
}


