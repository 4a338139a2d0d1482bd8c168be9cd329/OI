#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (r);i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (l);i >= i##end;i--)
using namespace std;
typedef long long ll;

FILE *fin,*fout,*fans,*fsco,*msg;
int score,n,root;
int a[101010];
ll v[101010];
vector<int> son[101010];
void dfs(int x)
{
	v[x]=a[x];
	int len=son[x].size();
	for (int i=0;i<len;++i)
	{
		int y=son[x][i];
		dfs(y);
		v[x]+=v[y];
	}
}
int main(int argc,char **argv){
	long double a1,a2;
	fin = fopen(argv[1],"r");
	fout = fopen(argv[2],"r");
	fans = fopen(argv[3],"r");
	fsco = fopen(argv[5],"w");
	msg = fopen(argv[6],"w");

	if(fout == NULL){
		fprintf(fsco,"0\n");
		fprintf(msg,"Wrong Answer. Unexpected Output Format.\n");
		return 0;
	}

	char s1[1010],s2[1010];
	fscanf(fout,"%s",s1+1);
	fscanf(fans,"%s",s2+1);
	int len=strlen(s2+1);
	for (int i=1;i<=len;++i) if (s1[i]!=s2[i])
	{
		fprintf(fsco,"0\n");
		fprintf(msg,"WA on the first line,so you got zero.\n");
		return 0;
	}
	if (s2[1]=='I')
	{
		fprintf(fsco,"10\n");
		fprintf(msg,"AC!!!\n");
		return 0;
	}

	score=3;
	fscanf(fin,"%d",&n);
	for (int i=1;i<=n;++i)
	{
		fscanf(fout,"%d",&a[i]);
		if (abs(a[i])>n) 
		{
			fprintf(fsco,"%d\n",score);
			fprintf(msg,"WA : |a[%d]|>n\n",i);
			return 0;
		}
	}

	int x;
	for (int i=1;i<=n;++i)
	{
		fscanf(fin,"%d",&x);
		if (x==-1) root=i;
		else son[x].push_back(i);
	}
	dfs(root);
	for (int i=1;i<=n;++i) if (abs(v[i])!=1)
	{
		fprintf(fsco,"%d\n",score);
		fprintf(msg,"sum of %d isn't -1 or 1\n",i);
		return 0;
	}

	for (int i=1;i<=n;++i) son[i].clear();

	for (int i=1;i<=n;++i)
	{
		fscanf(fin,"%d",&x);
		if (x==-1) root=i;
		else son[x].push_back(i);
	}
	dfs(root);
	for (int i=1;i<=n;++i) if (abs(v[i])!=1)
	{
		fprintf(fsco,"%d\n",score);
		fprintf(msg,"sum of %d isn't -1 or 1\n",i);
		return 0;
	}

	fprintf(fsco,"10\n");
	fprintf(msg,"AC!!!\n");
	return 0;
}













