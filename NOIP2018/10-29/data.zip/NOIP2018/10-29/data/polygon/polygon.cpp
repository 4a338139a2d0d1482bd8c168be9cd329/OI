#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

typedef unsigned uint;

const int N = 5010, M = 410;

uint A[N][N], B[N][N];
int px[M], py[M], val[M];
int n, k, q;

int main() {

	scanf("%d%d%d", &n, &k, &q);
	For(i, 1, k) scanf("%d%d", &px[i], &py[i]);
	For(i, 1, k) val[i] = py[i % k + 1] - py[i] ? -1 : 1;
	
	while (q--) {
		int ty, a, b, u, v;
		scanf("%d%d%d", &ty, &a, &b);
		if (ty == 1) {
			For(i, 1, k) {
				u = px[i] + a, v = py[i] + b;
				if (u <= n && v <= n) A[u][v] += (a + b) * val[i];
			}
		} else {
			For(i, 1, k) {
				u = px[i] + a, v = py[i] + b;
				if (u <= n && v <= n) B[u][v] += (a + b) * val[i];
			}
		}
	}

	For(i, 1, n) For(j, 1, n) B[i][j] += B[i][j - 1];
	For(i, 1, n) For(j, 1, n) B[i][j] += B[i - 1][j], A[i][j] += B[i][j];
	For(i, 1, n) For(j, 1, n) A[i][j] += A[i][j - 1];

	uint ans = 0;
	For(i, 1, n) For(j, 1, n) A[i][j] += A[i - 1][j], ans ^= A[i][j];
	printf("%u\n", ans);

	return 0;
}
