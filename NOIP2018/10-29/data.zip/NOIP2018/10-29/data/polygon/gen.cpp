#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int mxq = 2e5;
const int Q[20] = {0, 100, 100, 5000, 5000, mxq, mxq, mxq, 1000, 1000, 1000, mxq, mxq, mxq, mxq, mxq, mxq, mxq, mxq, mxq};
const int Ty[20] = {1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 2};

int px[510], py[510];

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main(){

	int T = 20;
	srand(time(0));

	For(Case, 1, T){
		char s[50];
		sprintf(s, "polygon%d.in", Case);
		freopen(s, "w", stdout);

		int n = (Case >= 1 && Case <= 3) || (Case >= 9 && Case <= 11) ? 100 : 5000;
		int k = Case <= 8 ? 4 : (Case <= 17 ? 40 : 200), q = Q[Case - 1], tlim = Ty[Case - 1];

		if (n > 10 && Case % 2 == 0) n -= rand() % 10; 
		if (k > 12 && Case % 4 == 0) k -= (rand() % 3) * 4;
		if (q > 10 && Case % 2 == 0) q -= rand() % 10;

		assert(k % 4 == 0);
		printf("%d %d %d\n", n, k, q);

		int a = n - randint(0, n / 10), b = n - randint(0, n / 10);

		int m = (k - 4) / 2, c1 = randint(0, m), c2 = m - c1;
		int cur = 0;

		static int pos[510];
		set<int> S;
		while (int(S.size()) < c1) S.insert(randint(1, a - 1));
		int it = 0;
		for (int x : S) pos[++it] = x;

		pos[0] = 0, pos[++it] = a;
		int ry = b / 4, ly = b - b / 4;
		assert(ry < ly);

		int lst = -1;
		For(i, 0, c1) {
			int y = lst;
			while (y == lst) y = randint(0, ry);
			lst = y;
			px[++cur] = pos[i], py[cur] = y;
			px[++cur] = pos[i + 1], py[cur] = y;
		}

		S.clear();
		while (int(S.size()) < c2) S.insert(randint(1, a - 1));
		it = 0;
		for (int x : S) pos[++it] = x;

		pos[0] = 0, pos[++it] = a;

		lst = -1;
		Forr(i, c2, 0) {
			int y = lst;
			while (y == lst) y = randint(ly, b);
			lst = y;
			px[++cur] = pos[i + 1], py[cur] = y;
			px[++cur] = pos[i], py[cur] = y;
		}
		assert(cur == k);	

		if (Case % 2) {
			For(i, 1, k) swap(px[i], py[i]);
			reverse(px + 1, px + k + 1), reverse(py + 1, py + k + 1);
		}

		int st = randint(1, k);
		For(i, st, k) printf("%d %d\n", px[i], py[i]);
		For(i, 1, st - 1) printf("%d %d\n", px[i], py[i]);

		while (q--) {
			int ty = tlim == 2 && rand() % 5 ? 2 : 1;
			int x = rand() % 5 ? randint(1, n / 5) : randint(1, n),
				y = rand() % 5 ? randint(1, n / 5) : randint(1, n);
			printf("%d %d %d\n", ty, x, y);
		}
		
		freopen("tmp", "w", stdout);
		cerr << "Case " << Case << endl;
		sprintf(s, "time ./polygon < polygon%d.in > polygon%d.out", Case, Case);
		system(s);
	}

	return 0;
}
