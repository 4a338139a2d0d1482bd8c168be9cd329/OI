#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 2e5 + 10;

int n;

struct Point {
	int x, y;
}P[N];

bool operator < (Point a, Point b) {
	int u = max(a.x, a.y), v = max(b.x, b.y);
	if (u != v) return u < v;
	else if (a.x != b.x) return a.x < b.x;
	else return a.y > b.y;
}

int dis(int u, int v) {
	return abs(P[u].x - P[v].x) + abs(P[u].y - P[v].y);
}

int main() {

	scanf("%d", &n);
	For(i, 1, n) scanf("%d%d", &P[i].x, &P[i].y);
	sort(P + 1, P + n + 1);

	long long dp[2] = {0};
	int id[2] = {0};
	For(i, 1, n) {
		int r = i;
		while (r < n && max(P[r + 1].x, P[r + 1].y) == max(P[i].x, P[i].y)) ++r;
		long long f[2] = {0};
		f[1] = min(dis(i, id[0]) + dp[0], dis(i, id[1]) + dp[1]) + dis(i, r);
		f[0] = min(dis(r, id[0]) + dp[0], dis(r, id[1]) + dp[1]) + dis(i, r);
		id[0] = i, id[1] = r;
		dp[0] = f[0], dp[1] = f[1];
		i = r;
	}
	printf("%lld\n", min(dp[0], dp[1]));

	return 0;
}
