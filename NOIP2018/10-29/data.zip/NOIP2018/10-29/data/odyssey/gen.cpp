#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int TASK = 5;
const int N[TASK] = {8, 18, 5000, 200000, 200000};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

int pos[200010];

int main() {

	char cmd[200];
	srand(time(0));

	For(idt, 0, TASK - 1) {
		
		sprintf(cmd, "mkdir subtask%d", idt + 1);
		system(cmd);
		cerr << "Subtask " << idt + 1 << ":\n";

		For(idc, 0, 2) {

			if (idt == 3 && idc) continue;
			if ((idt == 0 || idt == 2) && idc) continue;

			sprintf(cmd, "subtask%d/odyssey%d.in", idt + 1, idc + 1);
			freopen(cmd, "w", stdout);

			int n = N[idt];
			printf("%d\n", n);
			
			if (idt == 3) {
				For(i, 1, n) printf("%d %d\n", randint(1, n), randint(1, n));
			} else if (idc <= 2) {
				int p = idc == 1 ? 1 : (idc == 2 ? 2 : n / 2);
				For(i, 1, p) pos[i] = randint(1, 1e9);
				sort(pos + 1, pos + p + 1);
				int l = max(1, p / 2), r = min(l + 5, p);
				For(i, 1, n) {
					int x = rand() % 2 ? randint(l, r) : randint(1, p);
					x = pos[x];
					assert(x >= 1 && x <= 1e9);
					if (rand() % 2) printf("%d %d\n", x, randint(1, x));
					else printf("%d %d\n", randint(1, x), x);
				}
			} 

			freopen("CON", "w", stdout);
			cerr << "Case " << idc + 1 << ":\n";
			sprintf(cmd, "time ./odyssey < subtask%d/odyssey%d.in > subtask%d/odyssey%d.out", idt + 1, idc + 1, idt + 1, idc + 1);
			system(cmd);
		}
		

	}

	return 0;
}
