#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

typedef long long LL;

const int TASK = 4;
const int N[TASK] = {15, 1000, 50000, 1000000};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

LL randll(LL L, LL R) {
	return ((LL(rand()) << 31) ^ rand()) % (R - L + 1) + L;
}

int w[1000010], pos[1000010];
int n, q;

void generate(int l, int r, LL S) {
	assert(S < 1e9);
	For(i, l, r - 1) w[i] = randint(0, S);
	w[r] = S;
	sort(w + l, w + r + 1);
	Forr(i, r, l + 1) w[i] -= w[i - 1];
}

void shuffle() {
	int s = randint(1, n);
	For(i, s + 1, n) printf("%d ", w[i]);
	For(i, 1, s) printf("%d%c", w[i], i == s ? '\n' : ' ');
}

int main() {

	char cmd[200];
	srand(time(0));

	For(idt, 0, TASK - 1) {
		
		sprintf(cmd, "mkdir subtask%d", idt + 1);
		system(cmd);
		cerr << "Subtask " << idt + 1 << ":\n";

		For(idc, 0, 7) {

			if (!idt && idc) continue;
			if (idt < 2 && idc > 3) continue;
			if (idt < 3 && idc > 5) continue;

			sprintf(cmd, "subtask%d/necklace%d.in", idt + 1, idc + 1);
			freopen(cmd, "w", stdout);

			n = N[idt] - randint(0, n / 100), q = 50;
			printf("%d %d\n", n, q);

			if (!idc) {
				LL sum = 0, mx = 0;
				For(i, 1, n) w[i] = randint(0, 1e9), mx = max(mx, LL(w[i])), sum += w[i];
				For(i, 1, n) printf("%d%c", w[i], i == n ? '\n' : ' ');
				For(i, 1, q) {
					int t = rand() % 2;
					if (i == 1) printf("%lld\n", mx);
					else if (i == 2) printf("%lld\n", sum);
					else if (!t) printf("%lld\n", randll(mx, sum));
					else if (t == 1) printf("%lld\n", sum / randint(1, sum / mx) + randint(0, 100));
				}
			} else if (idc == 1) {
				LL sum = 0, mx = 0;
				int val = randint(40, 60);
				For(i, 1, n) w[i] = randint(val, val * 2), mx = max(mx, LL(w[i])), sum += w[i];
				For(i, 1, n) printf("%d%c", w[i], i == n ? '\n' : ' ');
				For(i, 1, q) printf("%lld\n", mx + i - 1);
			} else if (idc == 2) {
				LL S = randint(5e8, 1e9);
				int m = 20;
				For(i, 1, m - 1) pos[i] = randint(0, n - m);
				pos[m] = n - m;
				sort(pos + 1, pos + m + 1);
				For(i, 1, m) pos[i] += i, generate(pos[i - 1] + 1, pos[i], S);

				LL mx = 0;
				For(i, 1, n) mx = max(mx, LL(w[i]));
				shuffle();

				LL num[6] = {1, 2, 4, 5, 10, 20};
				For(i, 1, q) {
					if (i >= 1 && i <= 6) printf("%lld\n", S * num[i - 1]);
					else if (i >= 7 && i <= 12) printf("%lld\n", max(mx, S * num[i - 7] - 1));
					else {
						if (rand() % 5) printf("%lld\n", 2 * S + randint(-100, 100));
						else printf("%lld\n", max(mx, S / 2 + randint(-50, 100)));
					}
				}
			} else {
				LL S = randint(5e8, 1e9);
				int m = n / 4, r = n / 2 + randint(-100, 100);
				For(i, 1, m - 1) pos[i] = randint(0, r - (m - 1));
				pos[m] = r - m;
				sort(pos + 1, pos + m + 1);
				For(i, 1, m) pos[i] += i;
				pos[++m] = n;
				For(i, 1, m) generate(pos[i - 1] + 1, pos[i], S - randint(0, 100));

				LL mx = 0;
				For(i, 1, n) mx = max(mx, LL(w[i]));
				shuffle();
				LL num[6] = {1, 2, 4, 5, 10, 20};

				For(i, 1, q) {
					if (i >= 1 && i <= 6) printf("%lld\n", S * num[i - 1]);
					else if (i >= 7 && i <= 12) printf("%lld\n", max(mx, S * num[i - 7] - 1));
					else {
						if (rand() % 2) printf("%lld\n", S + randint(1, 100));
						else printf("%lld\n", S * 2 + randint(-200, 50));
					}
				}
			}

			freopen("CON", "w", stdout);
			cerr << "Case " << idc + 1 << ":\n";
			sprintf(cmd, "time ./necklace < subtask%d/necklace%d.in > subtask%d/necklace%d.out", idt + 1, idc + 1, idt + 1, idc + 1);
			system(cmd);
		}
		

	}

	return 0;
}
