#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

int Read() {
	char c = getchar(); int x = 0;
	while (c > '9' || c < '0') c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

using namespace std;

const int N = 2e6 + 10;

typedef long long LL;

int n, q;
int A[N], to[N];
LL sum[N];

int main() {

	n = Read(), q = Read();
	For(i, 1, n) A[i] = Read(), sum[i] = sum[i - 1] + A[i];
	For(i, 1, n) sum[i + n] = sum[i] + sum[n];
	
	while (q--) {
		LL m;
		scanf("%lld", &m);
		if (sum[n] <= m) {
			puts("1");
			continue;
		}

		int r = 1, p = 1;
		For(i, 1, n) {
			while (sum[r] - sum[i - 1] <= m) ++r;
			to[i] = r;
			if (to[i] - i < to[p] - p) p = i;
		}
		For(i, 1, n) to[i + n] = to[i] + n;

		int ans = n;
		For(i, p, to[p]) {
			int x = i > n ? i - n : i, o = x, c = 0;
			while (o < x + n) o = to[o], ++c;
			ans = min(ans, c);
		}
		printf("%d\n", ans);
	}

	return 0;
}
