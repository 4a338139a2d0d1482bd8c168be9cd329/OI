#include<bits/stdc++.h>
using namespace std;
#define ll long long
struct card{
	int typ;int a,b;int id;
}c[20];
bool operator <(card a,card b)
{
	return a.id<b.id;
}
vector<int> board[2][4];int weather[4];
int w,n;int ans=0;int mi=-1e8;int totx,toty;
void getdouble(vector<int> &v) {for(int i=0;i<v.size();i++) v[i]*=2;}
void dfs(int who,int id)
{
	if(id>=n)
	{
		totx=toty=0;
		for(int j=0;j<3;j++)
		{
			if(weather[j]==1) totx+=board[0][j].size(),toty+=board[1][j].size(); 
			else 
			{
				for(int k=0;k<board[0][j].size();k++) totx+=board[0][j][k];
				for(int k=0;k<board[1][j].size();k++) toty+=board[1][j][k];
			}
		}
		if(totx-toty>mi)
			ans=0,mi=totx-toty;
		if(totx-toty==mi)
			ans++;
		return ;
	}
	int cid=id+who*n;
	if(c[cid].typ==1)
	{
		int t=c[cid].b;
		vector<int> bef=board[who][t];
		board[who][t].push_back(c[cid].a);
		if(who==w) dfs(!who,id);else dfs(!who,id+1); 
		board[who][t]=bef;
	}
	if(c[cid].typ==2)
	{
		int bef=weather[c[cid].a];
		weather[c[cid].a]=1; 
		if(who==w) dfs(!who,id);else dfs(!who,id+1); 
		weather[c[cid].a]=bef;
	}
	if(c[cid].typ==3)
	{
		int bef[4];for(int i=0;i<3;i++) bef[i]=weather[i];
		for(int i=0;i<3;i++) weather[i]=0;
		if(who==w) dfs(!who,id);else dfs(!who,id+1); 
		for(int i=0;i<3;i++) weather[i]=bef[i];
	}
	if(c[cid].typ==4)
	{
		int maxi=0;
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(weather[j]) continue;
				for(int k=0;k<board[i][j].size();k++) maxi=max(maxi,board[i][j][k]);
			}
		}
		int bef[2][4];memset(bef,0,sizeof(bef));
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(weather[j]) continue;
				for(int k=0;k<board[i][j].size();k++) 
					if(maxi==board[i][j][k])
						board[i][j][k]=0,bef[i][j]++;
			}
		}
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(weather[j]) continue;
				sort(board[i][j].begin(),board[i][j].end());
				reverse(board[i][j].begin(),board[i][j].end());
				while(board[i][j].size())
				{
					int cc=board[i][j][board[i][j].size()-1];
					if(cc==0) board[i][j].resize(board[i][j].size()-1);
					else break;
				}
			}
		}
		if(who==w) dfs(!who,id);else dfs(!who,id+1); 
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(weather[j]) continue;
				for(int k=0;k<bef[i][j];k++) 
					board[i][j].push_back(maxi);
			}
		}
	}
	
	if(c[cid].typ==5)
	{
		int flag=0; 
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(weather[j]==1) continue;
				flag=1;
				vector<int> bef=board[i][j];
				getdouble(board[i][j]);
				if(who==w) dfs(!who,id);else dfs(!who,id+1); 
				board[i][j]=bef;	
			}
		}
		if(!flag) 
		{
			if(who==w) dfs(!who,id);else dfs(!who,id+1);
		}
	}
}
int main()
{
	freopen("gwent.in","r",stdin);
	freopen("gwent.out","w",stdout);
	cin>>w>>n;
	for(int i=n;i<n+n;i++)
	{
		cin>>c[i].typ;
		if(c[i].typ==1) cin>>c[i].a>>c[i].b;
		if(c[i].typ==2) cin>>c[i].a;
	}
	for(int i=0;i<n;i++)
	{
		cin>>c[i].typ;
		if(c[i].typ==1) cin>>c[i].a>>c[i].b;
		if(c[i].typ==2) cin>>c[i].a;
		c[i].id=i;
	}
	sort(c,c+n);
	dfs(w,0);
	while(next_permutation(c,c+n) )
	{
		dfs(w,0);
	}
	cout<<mi<<" "<<ans<<"\n";
	return 0;
}
