#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int nn=65536*8;
struct sumsegtree{
	ll tree[nn*2+10];
	void update(int x,int y)
	{
		x=x+nn-1;
		tree[x]=y;x=x>>1;
		while(x) tree[x]=(tree[x<<1]+tree[x<<1|1]),x>>=1;
	}
	int ask(int l,int r,int id,ll lef)//not including lef
	{
		if(l==r) return l;
		if(tree[id<<1]>lef)
			return ask(l,(l+r)>>1,id<<1,lef);
		else
			return ask(((l+r)>>1)+1,r,id<<1|1,lef-tree[id<<1]);
	}
}len;
struct maxsegtree{
	ll tree[nn*2+10];
	void update(int x,int y)
	{
		x=x+nn-1;
		tree[x]=y;x=x>>1;
		while(x) tree[x]=max(tree[x<<1],tree[x<<1|1]),x>>=1;
	}
	ll query(int a,int b,int l,int r,int id)
	{
		if(l>=a and r<=b) return tree[id];
		int mid=(l+r)>>1;ll sum=0;
		if(a<=mid) sum=max(sum,query(a,b,l,mid,id<<1));
		if(b>mid) sum=max(sum,query(a,b,mid+1,r,id<<1|1) );
		return sum;
	}
}height;
int lastans;int n,C;
int real(int x)
{
	if(C)return ((ll)x*2333ll+(ll)lastans*666ll)%(100000007ll)+1ll;
	else return x;
}
const int maxr=1e7; 
char str[maxr], prt[maxr]; int rpos, ppos, mmx;
char readc(){
	if(!rpos) mmx = fread(str, 1, maxr, stdin);
	if(!mmx) return 0;
	char c = str[rpos++];
	if(rpos == mmx) rpos = 0;
	return c;
}
ll read(){
	ll x; char c;
	while((c = readc()) < '0' || c > '9');
	x = c - '0';
	while((c = readc()) >= '0' && c <= '9') x = x * 10 + c - '0';
	return x;
}
void print(int x){
	if(x > 0){
		char sta[10]; int tp = 0;
		for(; x; x /= 10) sta[tp++] = x % 10 + '0';
		while(tp > 0) prt[ppos++] = sta[--tp];
	} else prt[ppos++] = '0';
	prt[ppos++] = '\n';
}
int main()
{
	freopen("play.in","r",stdin);
	freopen("play.out","w",stdout);
	n=read(),C=read();int now=0;
	while(n--)
	{
		int typ=read();
		if(typ==1)
		{
			now++;
			int l=read(),h=read();
			l=real(l);h=real(h);
			height.update(now,h);
			len.update(now,l);
		}
		if(typ==2)
		{
			int x=read();
			height.update(x,0);
			len.update(x,0);
		}
		if(typ==3)
		{
			ll l=read(),r=read();l--;
			l=len.ask(1,nn,1,l);r=len.ask(1,nn,1,r);
			lastans=height.query(l,r,1,nn,1);
			print(lastans);
		}
	}
	fwrite(prt, 1, ppos, stdout);
	return 0;
}
 
