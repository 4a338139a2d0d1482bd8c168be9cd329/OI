#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	freopen("lift.in","r",stdin);
	freopen("lift.out","w",stdout); 
	int T;cin>>T;
	while(T--)
	{
		ll n,m;scanf("%lld%lld",&n,&m);
		int a,b,c;scanf("%d%d%d",&a,&b,&c);
		if(c==2 and m==1)
		{
			puts("-1");continue;
		}
		n--; 
		printf("%lld\n",n+(m+1)/2); 
	}
}
