% OI中的数学方法
% Wearry
% Oct 2nd, 2018

---

# Table of Contents

## 数论相关

- 数论基础
- 同余方程
- 积性函数

. . .

## 组合数学

- 组合数及其性质
- 差分序列与$\mathrm{Stirling}$数
- 容斥与反演

. . .

## 题目选讲

---

# gcd 的一些性质

1. $$\gcd(x^a-1, x^b-1) = x^{\gcd(a, b)} - 1$$

2. $$\gcd(fib_a, fib_b) = fib_{\gcd(a, b)}$$

---

# 欧拉定理及其拓展

如果有 $\gcd(a, p) = 1$:

$$ a^{\varphi(p)} \equiv 1 \pmod p$$

一般情况:

$$ a^{t} \equiv a^{\min(t,\, t \bmod \varphi(p) + \varphi(p))} \pmod p$$

---

# 同余方程

形如:

$$x \equiv a_i \pmod{p_i}$$

. . .

## 中国剩余定理

若 $p_i$ 两两互质, 存在通解:

$$
\begin{aligned}
P &= \prod_{i} p_i \\ 
P_i &= \frac{P}{p_i} \\
T_i &= P_i^{-1} \bmod p_i \\
x &\equiv \sum_{i} a_iT_iP_i \pmod P
\end{aligned}
$$

---

# 拓展形式

考虑合并两个方程:

$$
\begin{aligned}
x &\equiv a_1 \pmod{p_1} \\
x &\equiv a_2 \pmod{p_2} \\
x &= a_1 + k_1p_1 = a_2 + k_2p_2 \\
\end{aligned}
$$

. . .

令 $t = \gcd(p_1, p_2)$, 则:

$$
\begin{aligned}
k_1\frac{p_1}{t}&\equiv \frac{a_2 - a_1}{t} \pmod{\frac{p_2}{t}}\\
k_1 &\equiv \frac{a_2 - a_1}{t} \times (\frac{p_1}{t})^{-1} \pmod{\frac{p_2}{t}} \\
x &\equiv a_1 + p_1 \left(\frac{a_2 - a_1}{t} \times (\frac{p_1}{t})^{-1} \bmod \frac{p_2}{t} \right) \pmod{\frac{p_1p_2}{t}}
\end{aligned}
$$

---

# 积性函数

令 $n = p_1^{e_1}p_2^{e_2} \cdots p_k^{e_k}$:

. . .

- $\epsilon(n) = [n = 1]$

- $\mathrm{1}(n) = 1$

- $\mathrm{Id}(n) = n$ \pause

- $\mu(n) = [\max(e_1, e_2, \cdots, e_k) \le 1] (-1)^k$

- $\varphi(n) = n\prod_{i=1}^{k} (1 - \frac{1}{p_i})$ \pause

- $\mathrm{d}(n) = \sum_{d|n} 1$

- $\sigma(n) = \sum_{d|n} d$

- $\lambda(n) = (-1)^k$

---

# Dirichlet卷积

$$(f*g)(n) = \sum_{d|n} f(d) g(\frac{n}{d})$$

. . .

- $\mu * 1 = \epsilon$

- $\mathrm{Id} = \varphi * 1 \Rightarrow \varphi = \mathrm{Id} * \mu$

- $\mathrm{d} = 1 * 1 \Rightarrow 1 = \mu * \mathrm{d}$

- $\sigma = \mathrm{Id} * 1 \Rightarrow \mathrm{Id} = \mu * \sigma \Rightarrow \sigma = \varphi * \mathrm{d}$ \pause

- $d(ij) = \sum_{x|i}\sum_{y|j} [\gcd(x, y) = 1]$

- $\sigma(ij) = \sum_{x|i}\sum_{y|j} [\gcd(x, y) = 1] \frac{iy}{x}$

满足交换律, 结合律, 两个积性函数的卷积也是积性的:

---

# 组合数的计算

计算:

$${n \choose m} \bmod p$$

. . .

- $n, m \le 5000$

. . .

- $n, m \le 10^6, p$ 是质数

. . .

- $n, m \le 10^{18}, p \le 10^6, p$ 是质数

. . .

- $n, m \le 10^{18}, p \le 10^6$.

---

# 基本组合恒等式

$$
\begin{aligned}
& \sum_{i=0}^{n} {n \choose i} = 2 ^ n \\
& \sum_{i=0}^{n} {i \choose x} = {n+1 \choose x+1} \\
& \sum_{i=0}^{n} {k+i \choose i} = {k+n+1 \choose n} \\
& \sum_{i=0}^{m} {m \choose i} {n-m \choose m-i} = {n \choose m}
\end{aligned}
$$

---

# 第一类Stirling数

1. 定义: $\begin{bmatrix} n \\ m \end{bmatrix}$ 表示将
$n$ 个物品分为 $m$ 个无序非空环的方案数.

. . .

2. 递推式: 

$$\begin{bmatrix} n \\ m \end{bmatrix} = \begin{bmatrix} n-1 \\ m-1 \end{bmatrix} + (n-1)\begin{bmatrix} n-1 \\ m \end{bmatrix}$$

. . .

3. 生成函数:

$$
\begin{aligned}
& x^{\overline{n}} = \sum_{i=0}^{n} \begin{bmatrix} n \\ i \end{bmatrix} x^i \\
& x^{\underline{n}}= \sum_{i=0}^{n} (-1)^{n-i} \begin{bmatrix} n \\ i \end{bmatrix} x^i 
\end{aligned}
$$

---

# 第二类Stirling数

1. 定义: $n \brace m$ 表示将 $n$ 个物品
分成 $m$ 个无序非空集合的方案数.

. . .

2. 递推式: 

$${n \brace m} = {n-1 \brace m-1} + m{n-1 \brace m}$$

. . . 

3. 生成函数:

$$
\begin{aligned}
& x^n = \sum_{i=0}^{n} {n \brace i} x^{\underline{i}} \\
& m!{n \brace m} = \sum_{i=0}^{m} (-1)^{m-i} {m \choose i} i^n
\end{aligned}
$$

---

# 多项式的差分序列

定义 $\Delta^{k} f(n)$ 为 $f(n)$ 的 $k$ 阶差分序列, 并且:

$$\Delta^{k} f(n) = 
\begin{cases}
f(n), & \mathrm{k = 0} \\
\Delta^{k-1} f(n+1) - \Delta^{k-1} f(n), & \mathrm{otherwise}
\end{cases}
$$

. . .

容易发现差分序列的具有线性性, 特别地, 多项式:

$$f(x) = \{0, 0, 0, \cdots, 1\} \mid x \in [0, n]$$

差分序列的第一列是 $\{0, 0, 0, \cdots, 1\}$ , 事实上这个多项式就是 

$$\frac{1}{n!} \prod_{i=0}^{n-1} (x - i) = {x \choose n}$$.

---

# 多项式插值

已知一个 $n$ 次多项式的 $n+1$ 个点值, 求这个多项式的系数表示.

## 牛顿插值

求出多项式的 $n$ 阶差分序列第一列 $\{c_i\}$, 可以将多项式表示成: 
$$f(x) = \sum_{i=0}^{n} c_i {x \choose i}$$

. . .

## 拉格朗日插值

考虑构造一个经过所有给定点的多项式:
$$
\begin{aligned}
    g_i(x) = \prod_{j=0, j \neq i}^{n} \frac{x - x_j}{x_i - x_j} \\
    f(x) = \sum_{i=0}^{n} y_ig_i(x)
\end{aligned}
$$

---

# 自然数幂和

求:

$$f_k(n) = \sum_{i=0}^{n} i^k$$

. . .

## Stirling数

直接用第二类斯特林数展开:

$$
\begin{aligned}
f_k(n) &= \sum_{i=0}^{n} \sum_{j=0}^{k} {k \brace j} i^{\underline{j}} \\
&= \sum_{j=0}^{k} {k \brace j} j! \sum_{i=0}^{n} {i \choose j} \\
&= \sum_{j=0}^{k} {k \brace j} j! {n + 1 \choose j + 1}
\end{aligned}
$$

---

# 自然数幂和

## 拉格朗日插值

&emsp;&emsp;
通过上一个方法我们知道 $f_k(n)$ 是一个关于 $n$ 的 $k+1$ 次多项式, 
于是直接拉格朗日插值即可, 并且由于系数的特殊性质, 可以做到 $O(k)$.

. . .

## Bernoulli数

定义 $B_i$ 为伯努利数, 满足:

$$\sum_{i=0}^{m} B_i {m+1 \choose i} = [m = 0]$$

那么有:

$$f_k(n-1) = \frac{1}{k+1} \sum_{i=0}^{k} B_i n^{k + 1 - i} {k + 1 \choose i}$$

---

# 容斥与反演

1. $\mathrm{Min-Max}$ 容斥:

$$\max(S) = \sum_{T \subseteq S, T \neq \varnothing} \min(T) ^ {(-1) ^ {|T|-1}}$$

. . .

2. 拓展形式:

$$\mathrm{lcm}(S) = \prod_{T \subseteq S, T \neq \varnothing} \gcd(T) ^ {(-1) ^ {|T|-1}}$$

---

# 容斥与反演

3. 二项式反演:

$$
\begin{aligned}
                f(n) &= \sum_{i=0}^{n} {n \choose i} g(i)\\
\Leftrightarrow g(n) &= \sum_{i=0}^{n} (-1)^{n-i} {n \choose i} f(i)
\end{aligned}
$$

. . .

4. Stirling反演

$$
\begin{aligned}
                f(n) &= \sum_{i=0}^{n} {n \brace i} g(i) \\
\Leftrightarrow g(n) &= \sum_{i=0}^{n} (-1)^{n-i} \begin{bmatrix} n \\ i \end{bmatrix} f(i) 
\end{aligned}
$$

---

# BZOJ4833 

&emsp;&emsp;
已知:

$$
\begin{aligned}
f(n) &= 
\begin{cases}     
0, & \textrm{n = 0} \\     
1, & \textrm{n = 1} \\     
2f(n-1) + f(n-2), & \textrm{otherwise} \\ 
\end{cases} \\
g(n) &= \mathrm{lcm}(f(1), f(2), \cdots, f(n)) 
\end{aligned}
$$

&emsp;&emsp;
求:

$$\sum_{i=1}^{n} g(i) \times i$$

&emsp;&emsp;
$n \le 10^6$

---

首先有 $\gcd(f(i), f(j)) = f(\gcd(i, j))$

根据 $\mathrm{Min-Max}$ 容斥有:

$$
\begin{aligned}
g(n) &= \prod_{T \subseteq S, T \neq \varnothing} \gcd(T)^{(-1)^{|T|+1}} \\
&= \prod_{T \subseteq S, T \neq \varnothing} f(\gcd(T))^{(-1)^{|T|+1}} 
\end{aligned}
$$

$$
\begin{aligned}
f(n) &= \prod_{d|n} h(d) \\
\Rightarrow g(n) &= \prod_{d=1}^{n} h(d)^{\sum_{T \subseteq S, T \neq \varnothing} [d \mid gcd(T)] (-1)^{|T|+1}} \\
&= \prod_{d=1}^{n} h(d)
\end{aligned}
$$

---

# Square

&emsp;&emsp;
给出一个 $n \times m$ 大小的矩形, 
每个位置可以填上 $[1,c]$ 中的任意一个数, 
要求填好后任意两行互不等价且任意两列互不等价, 
两行或两列等价当且仅当对应位置完全相同, 求方案数.

\vspace {2ex}

&emsp;&emsp;
$n, m \le 5000$

---

# Square

&emsp;&emsp;
首先我们有一个很简单的方式使得列之间互不等价, 对于任意一列, 
总方案数是 $c^n$, 那么使得列与列之间互不相同的方案数为 $(c^n)^{\underline{m}}$.

. . .

&emsp;&emsp;
接下来的问题只与行数有关, 
定义 $g(n)$ 表示 $n$ 行不保证每行互不等价的方案数,
$f(n)$ 表示 $n$ 行保证任意两行互不等价的方案数, 有:

. . .

$$
\begin{aligned}
g(n) &= (c^n)^{\underline{m}} \\
&= \sum_{i=0}^{n} {n \brace i} f(i) \\
f(n) &= \sum_{i=0}^{n} (-1)^{n-i} \begin{bmatrix} n \\ i \end{bmatrix} g(i) 
\end{aligned}
$$

---

# Sequence

&emsp;&emsp;
给出一个长度为 $n$ 的序列 $\{a_i\}$ 以及一个数 $p$, 现在有 $m$ 次操作, 
每次操作将 $[l, r]$ 区间内的 $a_i$ 变成 $c^{a_i}$, 
或者询问 $[l, r]$ 之间所有 $a_i$ 的和对 $p$ 取模的结果.

\vspace {2ex}
&emsp;&emsp;
$n, m \le 5 \times 10^4, p \le 2^{14}$

---

#Sequence

&emsp;&emsp;
对于修改操作可以利用拓展欧拉定理, 
维护一个 $\log(p)$ 层的结构表示每一个 $a_i$ 的值.

. . .

&emsp;&emsp;
由于经过只有最后的 $\log(p)$ 次操作是有效的, 
所以任意的两个相邻位置在经过 $\log(p)$ 次操作后会变得等价, 
在最外层维护一个 `std::set` 记录等价的区间, 然后用线段树做询问.

. . .

&emsp;&emsp;
复杂度的正确性可以通过势能函数简单地分析.

