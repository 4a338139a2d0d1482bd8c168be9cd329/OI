import os
from random import *

cs = [4, 3, 5, 4, 3]
nl = [200, 700, 700, 40000, 500000]
nr = [300, 1000, 1000, 100000, 1000000]
hr = [300, 1000, 1000000, 1000000, 1000000]

for i in range(5):
    os.system("mkdir subtask%d" % (i + 1))
    for j in range(cs[i]):
        n = randint(nl[i], nr[i])
        c = randint(1, 1000000)
        p = [randint(1, hr[i]) for x in range(n)]

        outp = "%d %d\n" % (n, c)
        if(j == 0):
            p.sort()
            for x in range((n+1)//2, 0, -1):
                outp += "%d " % p[2 * x - 2]
            for x in range(1, n//2+1):
                outp += "%d " % p[2 * x - 1]
        else:
            shuffle(p)
            for x in range(n):
                outp += "%d " % p[x]
        outp += "\n"

        fname = "./subtask%d/construct%d" % (i + 1, j + 1)
        print (outp, file = open("%s.in" % fname, "w"))
        os.system("./construct < %s.in > %s.out" % (fname, fname))

