#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

#define pb push_back

int len0, len1;
const int N = 400000;

int n, m;
int dp[N + 5];
int sx, sy, tx, ty;
vector<int> G[N + 5];
vector<pair<int, int> > stk;

int Ans = 0;
int flag = 0;

void dfs(int rt) {
    stk.pb(make_pair(rt, 0));

    while(!stk.empty()) {
        int u = stk.back().first, f = stk.back().second;

        if(G[u].size()) {
            int v = G[u].back(); 
            G[u].pop_back();
            if(v != f) stk.pb(make_pair(v, u));
        } else {
            if(++ m > n) flag |= 4;
            stk.pop_back();

            if(f) {
                Ans = max(Ans, dp[u] + dp[f] + 1);
                dp[f] = max(dp[f], dp[u] + 1);
            }
        }
    }
}

int main(int argc, char *argv[]){

    registerLemonChecker(argc, argv);

    len0 = ouf.readInt();
    len1 = ans.readInt();

    if(len0 != len1) flag |= 1; 

    int k0, k1, x, y;

    n = inf.readInt();
    k0 = ans.readInt();
    k1 = ouf.readInt();

    if(k1 != k0) {
        flag |= 2;
        while(k0--) x = ans.readInt();
        while(k1--) y = ouf.readInt();
    } else {
        while(k0--) {
            x = ans.readInt();
            y = ouf.readInt();
            if(x != y) flag |= 2;
        }
    }

    sx = ouf.readInt(1, n);
    sy = ouf.readInt(1, n);
    tx = ouf.readInt(1, n);
    ty = ouf.readInt(1, n);

    for(int i = 1; i < n; ++i) {
        static int u, v;
        u = inf.readInt();
        v = inf.readInt();
        if((u == sx && v == sy) || (u == sy && v == sx)) 
            continue;
        G[u].pb(v), G[v].pb(u);
    }
    G[tx].pb(ty), G[ty].pb(tx);

    if(!flag) {
        dfs(1);
        if(m != n || Ans != len0) flag |= 4;
    }

    if(flag & 1) 
        quitf(_wa, "Wrong Answer on Line1");
    else if(flag & 2) 
        quitp(perfectScore * 0.25, "Wrong Answer on Line2");
    else if(flag & 4) 
        quitp(perfectScore * 0.5, "Invalid Plan");
    else 
        quitf(_ok, "Correct Answer!");

    return 0;
}

