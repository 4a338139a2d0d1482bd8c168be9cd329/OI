import os, sys, math
from random import *

cs = [4, 4, 4, 8]
nl = [15, 150, 1500, 150000]
nr = [30, 300, 3000, 300000]

tot = 0
for i in range(4):
    for j in range(cs[i]):

        n = randint(nl[i], nr[i])
        fa = [0 for i in range(n + 1)]
        ed = [1 for i in range(n + 1)]

        outp = "%d\n" % n
        m0 = n // 4
        m1 = int(pow(n, 0.5))

        for x in range(2, n + 1):

            if(j % 4 == 0): 
                fa[x] = x // 2

            if(j % 4 == 1):
                fa[x] = randint(max(x - 50, 1), x - 1)

            if(j % 4 == 2):
                if(x <= m0):
                    fa[x] = x - 1
                else:
                    fa[x] = randint(1, m0)

            if(j % 4 == 3):
                if(x <= m1):
                    fa[x] = 1
                    ed[x] = x
                else:
                    if(randint(1, 10) > 1):
                        fa[x] = ed[1]
                        ed[1] = x
                    else:
                        y = randint(2, m1)
                        fa[x] = ed[y]
                        ed[y] = x

        fname = "league%d" % tot
        tot = tot + 1

        for x in range(2, n + 1):
            outp += "%d %d\n" % (x, fa[x])
        print (outp, file = open("%s.in" % fname, "w"))
        print (tot)
        os.system("ulimit -s unlimited && ./league < %s.in > %s.out" % (fname, fname))
