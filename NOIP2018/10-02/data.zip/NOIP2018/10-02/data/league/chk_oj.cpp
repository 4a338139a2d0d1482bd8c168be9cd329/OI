#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

#define pb push_back

double pts;
int len0, len1;
FILE *fsco, *frep, *fstd, *fdat, *fout;

void show(string info, double sco = 0) {
    quitp(sco, info);
    exit(0);
}

const int N = 400000;

int n, m;
int dp[N + 5];
int sx, sy, tx, ty;
vector<int> G[N + 5];
vector<pair<int, int> > stk;

int Ans = 0;
void dfs(int rt) {
    stk.pb(make_pair(rt, 0));

    while(!stk.empty()) {
        int u = stk.back().first, f = stk.back().second;

        if(G[u].size()) {
            int v = G[u].back(); 
            G[u].pop_back();
            if(v != f) stk.pb(make_pair(v, u));
        } else {
            if(++ m > n) show("Invalid Plan", 0.5);
            stk.pop_back();

            if(f) {
                Ans = max(Ans, dp[u] + dp[f] + 1);
                dp[f] = max(dp[f], dp[u] + 1);
            }
        }
    }
}

int main(int argc, char *argv[]){

    registerTestlibCmd(argc, argv);

    double pts = 5.0;
    len0 = ouf.readInt();
    len1 = ans.readInt();

    if(len0 != len1) 
        show("Wrong Answer on Line1", 0);

    n = inf.readInt();

    int k0, k1;
    k0 = ans.readInt();
    k1 = ouf.readInt();

    if(k1 != k0) 
        show("Wrong Answer on Line2", 0.25);

    while(k0--) {
        static int x, y;
        x = ans.readInt();
        y = ouf.readInt();

        if(x != y) 
            show("Wrong Answer on Line2", 0.25);
    }

    sx = ouf.readInt(1, n);
    sy = ouf.readInt(1, n);
    tx = ouf.readInt(1, n);
    ty = ouf.readInt(1, n);

    for(int i = 1; i < n; ++i) {
        static int u, v;
        u = inf.readInt();
        v = inf.readInt();
        if((u == sx && v == sy) || (u == sy && v == sx)) continue;

        G[u].pb(v), G[v].pb(u);
    }
    G[tx].pb(ty), G[ty].pb(tx);

    dfs(1);

    if(m != n || Ans != len0)
        show("Invalid Plan", 0.5);
    else 
        quitf(_ok, "Correct Answer!");

    return 0;
}

