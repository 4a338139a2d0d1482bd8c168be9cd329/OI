import sys, os
from random import *

cs = [7, 3, 4, 4, 5]
nl = [75, 75, 150, 150, 150]
nr = [100, 100, 200, 200, 200]
ql = [700, 7000, 45000, 80000, 80000]
qr = [1000, 10000, 50000, 100000, 100000]

for i in range(5):
    os.system("mkdir subtask%d" % (i + 1))
    for j in range(cs[i]):
        n = randint(nl[i], nr[i]);
        m = randint(nl[i], nr[i]);
        q = randint(ql[i], qr[i]);

        tl = 0
        outp = "%d %d %d\n" % (n, m, q)
        
        if(i == 3):
            tl = randint(100, 200)
        else:
            tl = n * m // (j+1) // 10

        a = [randint(1, 1000000000) for i in range(tl)]

        for x in range(n):
            for y in range(m):
                outp += "%d " % (a[randint(0, tl-1)])
            outp += "\n"

        if(j <= 2):
            for l in range(n):
                for r in range(l):
                    x0 = r + 1
                    x1 = n - l + r
                    y0 = 1
                    y1 = m

                    if(x0 > x1):
                        break

                    if(q > 0):
                        q = q - 1
                        outp += "%d %d %d %d\n" % (x0, y0, x1, y1)
                    else:
                        break
                if(q == 0): 
                    break

        for x in range(q):
            if(randint(0, 2) == 2):
                x0 = randint(1, n)
                y0 = randint(1, m)
                x1 = randint(x0, n)
                y1 = randint(y0, m)
                outp += "%d %d %d %d\n" % (x0, y0, x1, y1)
            else:
                outp += "%d %d %d %d\n" % (1, 1, n, m)

        fname = "./subtask%d/vegetable%d" % (i + 1, j + 1)
        print (outp, file = open("%s.in" % fname, "w"))
        os.system("./vegetable < %s.in > %s.out" % (fname, fname))

