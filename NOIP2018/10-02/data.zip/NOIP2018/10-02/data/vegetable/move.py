import sys, os
from random import *

cs = [7, 3, 4, 4, 5]

tot = 0
for i in range(5):
    for j in range(cs[i]):
        fa = "./subtask%d/vegetable%d" % (i + 1, j + 1)
        fb = "./upload/vegetable%d" % (tot + 1)
        tot = tot + 1
        os.system("cp %s.in %s.in" % (fa, fb))
        os.system("cp %s.out %s.out" % (fa, fb))

