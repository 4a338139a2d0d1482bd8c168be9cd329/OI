#include<bits/stdc++.h>
using namespace std;
const int maxn=1e3+10,lim=1e6,mod=998244353;
int fac[maxn*maxn],ifac[maxn*maxn],a[maxn],n,k;
inline int read(){
	int x=0;char ch=getchar();
	for(;!isdigit(ch);ch=getchar());
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x;
}
inline int qpow(int x,int y){
	int ret=1;
	for(;y;y>>=1){
		if(y&1)ret=1ll*ret*x%mod;
		x=1ll*x*x%mod;
	}return ret;
}
inline int C(int x,int y){
	return 1ll*fac[x]*ifac[y]%mod*ifac[x-y]%mod;
}
int main(){
	freopen("gwent.in","r",stdin);
	freopen("gwent.out","w",stdout);
	int T=read();
	fac[0]=ifac[0]=1;
	for(register int i=1;i<=lim;++i)fac[i]=1ll*fac[i-1]*i%mod;
	ifac[lim]=qpow(fac[lim],mod-2);
	for(register int i=lim;i>1;--i)ifac[i-1]=1ll*ifac[i]*i%mod;
	while(T--){
		n=read(),k=0;
		for(register int i=1;i<=n;++i)a[i]=read(),k+=a[i];
		k/=n;
		int res=1;
		for(register int i=1;i<n;++i){
			if(a[i]<k)res=1ll*res*C(max(k+a[i],a[i+1]),k-a[i])%mod;
			if(a[i]>k)res=1ll*res*C(a[i],a[i]-k)%mod;
			a[i+1]+=a[i]-k;
		}printf("%d\n",res);
	}return 0;
}
