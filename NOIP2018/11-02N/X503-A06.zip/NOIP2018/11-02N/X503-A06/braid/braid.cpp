#include<bits/stdc++.h>
using namespace std;
int n,m,x,k;
inline int read(){
	int x=0;char ch=getchar();
	for(;!isdigit(ch);ch=getchar());
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x;
}
namespace SUB1{
const int maxn=6e6+10,N=998244353;
	set<int>s;
	map<int,int>mp;
	int fa[maxn],cnt,vis[maxn];
	int S[maxn],T[maxn];
	inline int find(int x){
		return x==fa[x]?x:fa[x]=find(fa[x]);	
	}
	inline void Merge(int x,int y){
		x=find(x),y=find(y);
		if(x^y)fa[y]=x;
	}
	inline void solve(){
		int now=x;
		cnt=0;
		mp.clear();
		for(register int i=1;i<=m;++i){
			if(!mp[now])mp[now]=++cnt;
			S[i]=mp[now];
			now=1ll*now*k%N;
			if(!mp[now])mp[now]=++cnt;
			T[i]=mp[now];
			now=1ll*now*k%N;
		}for(register int i=1;i<=cnt;++i)fa[i]=i,vis[i]=0;
		for(register int i=1;i<=m;++i)Merge(S[i],T[i]);
		int tot=0;
		for(register int i=1;i<=cnt;++i){
			int x=find(i);
			if(vis[x])++tot;
			vis[x]=1;
		}printf("%d\n",N-tot);
	}
}
namespace SUB2{
	inline void solve(){
		if(k==1)printf("%d\n",n);
		else if(k==n)printf("%d\n",n-1);
		else if(k==n-1)printf("%d\n",n-(x!=n));
		else printf("%d\n",n-m);
	}
}
int main(){
	freopen("braid.in","r",stdin);
	freopen("braid.out","w",stdout);
	int T=read();
	while(T--){
		n=read(),m=read(),x=read(),k=read();
		if(m<=10000)SUB1::solve();
		else SUB2::solve();
	}return 0;
}
