#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0;char ch=getchar();
	for(;!isdigit(ch);ch=getchar());
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x;
}
const int maxn=2e3+10,maxm=1e6+10;
int a[maxn],n,m,Lx,Rx;
namespace SUB1{
	inline void solve(){
		while(m--){
			int l=read(),r=read();
			sort(a+l,a+r+1);
		}for(register int i=Lx;i<=Rx;++i)printf("%d ",a[i]);
	}
}
namespace SUB2{
#define lson (rt<<1)
#define rson (lson|1)
#define mid ((l+r)>>1)
	int lx[maxm],rx[maxm];
	int f[maxn<<2],tg[maxn<<2];
	inline void pushup(int rt){
		f[rt]=f[lson]+f[rson];
	}
	inline void pushdown(int rt,int l,int r){
		if(~tg[rt]){
			f[lson]=(mid-l+1)*tg[rt];
			f[rson]=(r-mid)*tg[rt];
			tg[lson]=tg[rson]=tg[rt];
			tg[rt]=-1;
		}
	}
	inline void build(int rt,int l,int r,int k){
		tg[rt]=-1;
		if(l==r)f[rt]=a[l]>k;
		else build(lson,l,mid,k),build(rson,mid+1,r,k),pushup(rt);
	}
	inline void update(int rt,int l,int r,int L,int R,int k){
		if(L<=l&&r<=R){
			tg[rt]=k;
			f[rt]=k*(r-l+1);
			return;
		}pushdown(rt,l,r);
		if(L<=mid)update(lson,l,mid,L,R,k);
		if(R>mid)update(rson,mid+1,r,L,R,k);
		pushup(rt);
	}
	inline int query(int rt,int l,int r,int L,int R){
		if(L<=l&&r<=R)return f[rt];
		pushdown(rt,l,r);
		int ret=0;
		if(L<=mid)ret=query(lson,l,mid,L,R);
		if(R>mid)ret+=query(rson,mid+1,r,L,R);
		return ret;
	}
	inline void init(){
		for(register int i=1;i<=m;++i)lx[i]=read(),rx[i]=read();
	}
	inline int judge(int k){
		build(1,1,n,k);
		for(register int i=1;i<=m;++i){
			int num=query(1,1,n,lx[i],rx[i]),len=rx[i]-lx[i]+1;
			if(len>num)update(1,1,n,lx[i],rx[i]-num,0);
			if(num)update(1,1,n,rx[i]-num+1,rx[i],1);
		}return query(1,1,n,Lx,Lx);
	}
	inline void solve(){
		init();
		int l=1,r=n;
		while(l<r){
			if(judge(mid))l=mid+1;
			else r=mid;
		}printf("%d\n",l);
	}
}
int main(){
	freopen("miku.in","r",stdin);
	freopen("miku.out","w",stdout);
	n=read(),m=read(),Lx=read(),Rx=read();
	for(register int i=1;i<=n;++i)a[i]=read();
	if(Lx==Rx)SUB2::solve();
	else SUB1::solve();
	return 0;
}
