#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10,inf=0x3f3f3f3f;
typedef long long ll;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch-48);
	return x*f;
}
int fst[maxn],lst[maxn<<1],to[maxn<<1],e;
inline void add(int x,int y){
	to[++e]=y,lst[e]=fst[x],fst[x]=e;
}
int son[maxn],sz[maxn],dep[maxn],fa[maxn];
inline void dfs1(int x,int f){
	fa[x]=f,sz[x]=1;
	int mx=0;
	for(register int i=fst[x];i;i=lst[i]){
		int v=to[i];
		if(v^f){
			dep[v]=dep[x]+1;
			dfs1(v,x);
			sz[x]+=sz[v];
			if(sz[v]>mx)son[x]=v,mx=sz[v];
		}
	}
}
int vl[maxn],val[maxn],dfn[maxn],top[maxn],cnt,n,m,q;
inline void dfs2(int x,int tp){
	top[x]=tp,dfn[x]=++cnt,val[cnt]=vl[x];
	if(son[x])dfs2(son[x],tp);
	else return;
	for(register int i=fst[x];i;i=lst[i]){
		int v=to[i];
		if((v^fa[x])&&(v^son[x]))dfs2(v,v);
	}
}
struct segtree{
#define lson (rt<<1)
#define rson (lson|1)
#define mid ((l+r)>>1)
	int f[maxn<<2];
	inline void pushup(int rt){
		f[rt]=min(f[lson],f[rson]);
	}
	inline void build(int rt,int l,int r){
		if(l==r)f[rt]=val[l];
		else build(lson,l,mid),build(rson,mid+1,r),pushup(rt);
	}
	inline void update(int rt,int l,int r,int x,int k){
		if(l==r){
			if(x==l)f[rt]=k;
			return;
		}x<=mid?update(lson,l,mid,x,k):update(rson,mid+1,r,x,k);
		pushup(rt);
	}
	inline int query(int rt,int l,int r,int L,int R){
		if(L<=l&&r<=R)return f[rt];
		int ret=inf;
		if(L<=mid)ret=query(lson,l,mid,L,R);
		if(R>mid)ret=min(ret,query(rson,mid+1,r,L,R));
		return ret;
	}
}T;
inline void update(int x,int k){
	x=dfn[x];
	T.update(1,1,n,x,k);
}
inline int query(int x,int y){
	int ret=inf;int tmp;
	while(top[x]^top[y]){
		if(dep[top[x]]>=dep[top[y]])tmp=x,x=fa[top[x]];
		else tmp=y,y=fa[top[y]];
		ret=min(ret,T.query(1,1,n,dfn[top[tmp]],dfn[tmp]));
	}if(dfn[x]>=dfn[y])ret=min(ret,T.query(1,1,n,dfn[y],dfn[x]));
	else ret=min(ret,T.query(1,1,n,dfn[x],dfn[y]));
	return ret;
}
inline void sub2(){
	dfs1(1,0),dfs2(1,1);
	T.build(1,1,n);
	q=read();
	while(q--){
		char opt;int x,y;
		cin>>opt;
		if(opt=='C'){
			x=read(),y=read();
			update(x,y);
		}else{
			x=read(),y=read();
			int z=query(x,x);
			printf("%d\n",z-query(x,y));
		}
	}
}
struct edge{
	int u,v,w;
	bool operator <(const edge &rhs)const{
		return w>rhs.w;
	}
}ed[maxn];
int ffa[maxn];
inline int find(int x){
	return x==ffa[x]?x:ffa[x]=find(ffa[x]);
}
inline void Merge(int x,int y){
	x=find(x),y=find(y);
	if(x^y)ffa[x]=y;
}
inline bool judge(int x,int y){
	x=find(x),y=find(y);
	return x==y;
}
inline void gao(){
	for(register int i=1;i<=n;++i)ffa[i]=i;
	for(register int i=1;i<=m;++i)ed[i].u=read(),ed[i].v=read(),ed[i].w=max(vl[ed[i].u],vl[ed[i].v]);
	sort(ed+1,ed+m+1);
	for(register int i=1;i<=m;++i){
		if(judge(ed[i].u,ed[i].v))continue;
		add(ed[i].u,ed[i].v),add(ed[i].v,ed[i].u);
		Merge(ed[i].u,ed[i].v);
	}sub2();
}
int main(){
	freopen("paoshang.in","r",stdin);
	freopen("paoshang.out","w",stdout);
	n=read();m=read();
	for(register int i=1;i<=n;++i)vl[i]=read();
	if(n<=m){
		gao();
		return 0;
	}
	for(register int i=1,x,y;i<=m;++i)x=read(),y=read(),add(x,y),add(y,x);
	sub2();
	return 0;
}
