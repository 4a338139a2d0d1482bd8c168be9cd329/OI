#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
typedef long long ll;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch-48);
	return x*f;
}
int fst[maxn],lst[maxn<<1],to[maxn<<1],e;
inline void add(int x,int y){
	to[++e]=y,lst[e]=fst[x],fst[x]=e;
}
int son[maxn],sz[maxn],dep[maxn],fa[maxn];
inline void dfs1(int x,int f){
	fa[x]=f,sz[x]=1;
	int mx=0;
	for(register int i=fst[x];i;i=lst[i]){
		int v=to[i];
		if(v^f){
			dep[v]=dep[x]+1;
			dfs1(v,x);
			sz[x]+=sz[v];
			if(sz[v]>mx)son[x]=v,mx=sz[v];
		}
	}
}
int vl[maxn],val[maxn],dfn[maxn],top[maxn],cnt,n,m,q;
inline void dfs2(int x,int tp){
	top[x]=tp,dfn[x]=++cnt,val[cnt]=vl[x];
	if(son[x])dfs2(son[x],tp);
	else return;
	for(register int i=fst[x];i;i=lst[i]){
		int v=to[i];
		if((v^fa[x])&&(v^son[x]))dfs2(v,v);
	}
}
struct szsz{
	ll f[maxn];
	inline void add(int x,int k){
		for(;x<=n;x+=x&(-x))f[x]+=k;			
	}
	inline ll sum(int x){
		ll ret=0;
		for(;x;x-=x&(-x))ret+=f[x];
		return ret;
	}
	inline ll query(int l,int r){
		return sum(r)-sum(l-1);
	}
	inline void update(int x,int k){
		int tmp=query(x,x);
		add(x,-tmp),add(x,k);
	}
}T;
inline void update(int x,int k){
	x=dfn[x];
	T.update(x,k);
}
inline ll query(int x,int y){
	ll ret=0;int tmp;
	while(top[x]^top[y]){
		if(dep[top[x]]>=dep[top[y]])tmp=x,x=fa[top[x]];
		else tmp=y,y=fa[top[y]];
		ret+=T.query(dfn[top[tmp]],dfn[tmp]);
	}if(dfn[x]>=dfn[y])ret+=T.query(dfn[y],dfn[x]);
	else ret+=T.query(dfn[x],dfn[y]);
	return ret;
}
inline void sub2(){
	dfs1(1,0),dfs2(1,1);
	for(register int i=1;i<=n;++i)T.add(i,vl[i]);
	while(q--){
		char opt;int x,y,z;
		cin>>opt;
		if(opt=='C'){
			x=read(),y=read();
			update(x,y);
		}else{
			x=read(),y=read();
			if(y)z=read();
			if(!y)printf("%lld\n",query(x,x));
			else printf("%lld\n",query(x,y));
		}
	}
}
int main(){
	freopen("kaihuang.in","r",stdin);
	freopen("kaihuang.out","w",stdout);
	n=read();q=read();
	for(register int i=1;i<=n;++i)vl[i]=read();
	for(register int i=1,x,y;i<n;++i)x=read(),y=read(),add(x,y),add(y,x);
	sub2();
	return 0;
}
