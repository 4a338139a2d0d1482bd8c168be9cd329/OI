#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=5e2+10,maxm=1e2+10,size=1e6+10;
const ll INF=1e18;
#define PII pair<int,int>
#define PLP pair<ll,PII>
#define mp make_pair
#define X first
#define Y second
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
int fst[maxn][maxm],lst[size],w[size],e;
PII to[size];
inline void add(PII x,PII y,int z){
	to[++e]=y,lst[e]=fst[x.X][x.Y],fst[x.X][x.Y]=e,w[e]=z;
}
int ncan[maxm][maxn][maxn],len[maxm],tim[maxm],n,k,W;
ll dis[maxn][maxm];
inline ll dijkstra(){
	for(register int i=0;i<=n;++i)for(register int j=1;j<=k;++j)dis[i][j]=INF;
	priority_queue<PLP,vector<PLP>,greater<PLP> >q;
	for(register int i=1;i<=k;++i){
		if(ncan[i][0][0]==1)continue;
		q.push(mp(0,mp(0,i)));
		dis[0][i]=0;
	}while(!q.empty()){
		PII u=q.top().Y;ll d=q.top().X;q.pop();
		for(register int i=fst[u.X][u.Y];i;i=lst[i]){
			PII v=to[i];
			if(ncan[v.Y][v.X][v.X])continue;
			if(dis[v.X][v.Y]>dis[u.X][u.Y]+w[i]){
				dis[v.X][v.Y]=dis[u.X][u.Y]+w[i];
				q.push(mp(dis[v.X][v.Y],mp(v.X,v.Y)));
			}
		}
	}ll ret=INF;
	for(register int i=1;i<=k;++i)ret=min(ret,dis[n][i]);
	return ret;
}
inline void init(){
	int q=read();
	while(q--){
		int x=read(),y=read();
		ncan[y][x][x]=1;
	}
	for(register int I=1;I<=k;++I){
		for(register int i=0;i<=n;++i){
			for(register int j=i+1;j<=n;++j){
				if(ncan[I][j][j])ncan[I][i][j]=1;
				else ncan[I][i][j]=ncan[I][i][j-1];
			}
		}
	}
}
inline void build(){
	for(register int I=1;I<=k;++I){
		for(register int i=0;i+len[I]<=n;++i){
			if(ncan[I][i][i+len[I]])continue;
			PII st=mp(i,I),fi=mp(i+len[I],I);
			add(st,fi,tim[I]);
		}
	}
	for(register int i=0;i<=n;++i){
		for(register int j=1;j<=k;++j){
			if(ncan[j][i][i])continue;
			for(register int l=j+1;l<=k;++l){
				if(ncan[l][i][i])continue;
				PII st=mp(i,j),fi=mp(i,l);
				add(st,fi,W),add(fi,st,W);
			}
		}
	}
}
int main(){
	freopen("qinggong.in","r",stdin);
	freopen("qinggong.out","w",stdout);
	n=read(),k=read(),W=read();
	for(register int i=1;i<=k;++i)len[i]=read(),tim[i]=read();
	init(),build();
	printf("%lld\n",dijkstra());
	return 0;
}
