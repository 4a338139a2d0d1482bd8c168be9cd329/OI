#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

typedef long long LL;

const int N = 400005;

int n, m, nq, nl, clk;
int lc[N], rc[N], val[N], li[N], dfn[N], ed[N], c[N], si[N];
LL ans;

struct Edg {
    int u, v, w;
    inline friend bool operator < (const Edg &a, const Edg &b) {
        return a.w < b.w;
    }
} e[N * 2];
struct Que {
    int l, r, nd, co, ty;
    inline friend bool operator < (const Que &a, const Que &b) {
        return a.co != b.co? a.co < b.co : a.ty < b.ty;
    }
} q[N * 53];

namespace DS {
    int f[N], tot;
    void Init(int _n) {
        tot = n;
        for (int i = 1; i <= _n; ++i) f[i] = i;
    }
    int Sk(int x) {
        return f[x] == x? x : f[x] = Sk(f[x]);
    }
    void Mr(int x, int y, int _v) {
        f[x] = f[y] = ++tot;
        lc[tot] = x, rc[tot] = y, val[tot] = _v;
    }
}

namespace BT {
    int t[N];
    void Ad(int x) {
        for (; x <= clk; x += x & -x) ++t[x];
    }
    int Qr(int x) {
        int re = 0;
        for (; x; x -= x & -x) re += t[x];
        return re;
    }
}

void Dfs(int x) {
    int l = lc[x], r = rc[x];
    if (x > n) dfn[x] = clk + 1;
    else li[dfn[x] = ++clk] = x;
    if (x > n) Dfs(l), Dfs(r);
    si[x] = si[l] + si[r] + (x <= n);
    ed[x] = clk;
    if (x > n) {
        ans += (LL)val[x] * si[l] * si[r];
        if (si[l] > si[r]) swap(l, r);
        for (int i = dfn[l]; i <= ed[l]; ++i) {
            q[++nq] = (Que){ dfn[r], ed[r], x, c[li[i]] - nl, 1 };
            q[++nq] = (Que){ dfn[r], ed[r], x, c[li[i]] + nl - 1, -1 };
        }
    }
}

int main() {
    freopen("graph.in", "r", stdin);
    freopen("graph.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &nl);
    DS::Init(n + n);
    for (int i = 1; i <= n; ++i)
        scanf("%d", &c[i]);
    for (int i = 1; i <= m; ++i)
        scanf("%d%d%d", &e[i].u, &e[i].v, &e[i].w);
    sort(e + 1, e + 1 + m);
    for (int i = 1; i <= m; ++i) {
        int x = DS::Sk(e[i].u);
        int y = DS::Sk(e[i].v);
        if (x != y) DS::Mr(x, y, e[i].w);
    }
    Dfs(DS::tot);
    if (nl == 0) {
        printf("%lld\n", ans);
        return 0;
    }
    for (int i = 1; i <= n; ++i)
        q[++nq] = (Que){ dfn[i], 0, 0, c[i], -2 };
  
    sort(q + 1, q + 1 + nq);
    for (int i = 1, s; i <= nq; ++i) {
        if (q[i].ty == -2) {
            BT::Ad(q[i].l);
        } else {
            s = BT::Qr(q[i].r) - BT::Qr(q[i].l - 1);
            ans += (LL)val[q[i].nd] * s * q[i].ty;
        }
    }
    printf("%lld\n", ans);
    return 0;
}
