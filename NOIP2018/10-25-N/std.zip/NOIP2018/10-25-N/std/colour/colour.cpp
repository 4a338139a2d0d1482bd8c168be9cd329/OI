#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long LL;

const int N = 305;
const LL INF = ~0ul >> 1;

inline bool Cmin(LL &a, LL b) {
    return (a > b) ? (a = b, 1) : 0;
}

int n;
LL c[N];
LL f[N], g[N];

void Solve() {
    scanf("%d", &n);
    for (int i = 1; i <= n; ++i)
        scanf("%lld", &c[i]);
    LL res = INF;
    for (int l = 1; l <= n; ++l) {
        LL sc = c[l];
        memset(f, 0x7f, sizeof(f));
        memset(g, 0x7f, sizeof(g));
        f[0] = 0;
        for (int i = 0; i < n; ++i) {
            LL sum = 0, mc = INF;
            for (int j = i + 1; j <= n; ++j) {
                sum += c[j];
                Cmin(mc, c[j]);
                Cmin(f[j], f[i] + (sum - mc) * mc + ((mc != sc) ? (mc * (j - i) * sc) : 0));
            }
        }
        g[n + 1] = 0;
        for (int i = n + 1; i > 1; --i) {
            LL sum = 0, mc = INF;
            for (int j = i - 1; j; --j) {
                sum += c[j];
                Cmin(mc, c[j]);
                Cmin(g[j], g[i] + (sum - mc) * mc + ((mc != sc) ? (mc * (i - j) * sc) : 0));
            }
        }
        Cmin(res, f[n]);
        for (int i = 1; i <= n; ++i)
            if (c[i] == sc) Cmin(res, f[i - 1] + g[i + 1]);
    }
    printf("%lld\n", res);
    return;
}

int main() {
    freopen("colour.in", "r", stdin);
    freopen("colour.out", "w", stdout);
    int t;
    scanf("%d", &t);
    while (t--) Solve();
    return 0;
}
