#include<bits/stdc++.h>
#define Rep(i,a,b) for(register int i=(a);i<=(b);++i)
#define Repe(i,a,b) for(register int i=(a);i>=(b);--i)
#define pb push_back
#define mp make_pair
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
#define mx(a,b) (a>b?a:b)
#define mn(a,b) (a<b?a:b)
typedef unsigned long long uint64;
typedef unsigned int uint32;
typedef long long ll;
using namespace std;

namespace IO
{
    const uint32 Buffsize=1<<15,Output=1<<23;
    static char Ch[Buffsize],*S=Ch,*T=Ch;
    inline char getc()
	{
		return((S==T)&&(T=(S=Ch)+fread(Ch,1,Buffsize,stdin),S==T)?0:*S++);
	}
    static char Out[Output],*nowps=Out;
    
    inline void flush(){fwrite(Out,1,nowps-Out,stdout);nowps=Out;}

    template<typename T>inline void read(T&x)
	{
		x=0;static char ch;T f=1;
		for(ch=getc();!isdigit(ch);ch=getc())if(ch=='-')f=-1;
		for(;isdigit(ch);ch=getc())x=x*10+(ch^48);
		x*=f;
	}

	template<typename T>inline void write(T x,char ch='\n')
	{
		if(!x)*nowps++='0';
		if(x<0)*nowps++='-',x=-x;
		static uint32 sta[111],tp;
		for(tp=0;x;x/=10)sta[++tp]=x%10;
		for(;tp;*nowps++=sta[tp--]^48);
		*nowps++=ch;
	}
}
using namespace IO;

inline void file()
{
#ifndef ONLINE_JUDGE
	FILE*AS=freopen("nyarlathotep-3.in","r",stdin);
	FILE*BS=freopen("nyarlathotep-3.out","w",stdout);
#endif
}

const int MAXN=1011;

namespace  AC_Automaton
{
	static int endps[MAXN],son[MAXN][27],fail[MAXN],e;

	inline void insert(char*q)
	{
		register int ps;
		for(ps=0;*q!='\0';++q)
		{
			if(endps[ps])return;
			if(!son[ps][*q-'a'])son[ps][*q-'a']=++e;
			ps=son[ps][*q-'a'];
		}
		endps[ps]=1;
	}

	queue<int>G;

	inline void build()
	{
		Rep(i,0,25)if(son[0][i])G.push(son[0][i]);
		static int u;
		while(!G.empty())
		{
			u=G.front();G.pop();
			Rep(i,0,25)
			{
				if(son[u][i])fail[son[u][i]]=son[fail[u]][i],G.push(son[u][i]);
				else son[u][i]=son[fail[u]][i];
			}
		}
		Rep(i,1,e)
		{
			u=i;
			while(u)
			{
				if(endps[u]){endps[i]=1;break;}
				u=fail[u];
			}
			if(endps[i])Rep(j,0,25)son[i][j]=son[0][j];
		}
	}
}
using namespace AC_Automaton;

static char q[MAXN];

static int n,m,lim;

static int lent;

inline void getstr(char*q)
{
	char *fp=q;
	register char ch;
	for(ch=getc();!islower(ch);ch=getc());
	for(;islower(ch);ch=getc())*q++=ch;
	*q='\0';lent+=q-fp;
	if(lent>200)cerr<<"OVERLOAD!!!"<<endl;
}

inline void init()
{
	read(n);read(m);read(lim);
	Rep(i,1,m)getstr(q),insert(q);
}

const int mod=1e9+7;

inline int ad(int u,int v)
{return(u+=v)>=mod?u-mod:u;}

static int ans,dp[2][MAXN*MAXN][4];

#define tops(x,y) x*1000+y

static queue<int>Q[2];

static int vis[MAXN*MAXN],tt;

inline void gothrough(int fp)
{
	Q[0].push(fp);
	dp[0][fp][0]=1;
	dp[0][fp][1]=dp[0][fp][2]=dp[0][fp][3]=0;
	static int u,x,y,v;
	Rep(i,0,n-1)
	{
		++tt;
		while(!Q[i&1].empty())
		{
			u=Q[i&1].front();Q[i&1].pop();
			x=u/1000;y=u%1000;
			Rep(k,0,3)if(dp[i&1][u][k])
			{
				Rep(j,0,25)if(k+endps[son[x][j]]+endps[son[y][j]]<=lim)
				{
					v=tops(son[x][j],son[y][j]);
					if(vis[v]^tt)
					{
						Rep(l,0,lim)dp[~i&1][v][l]=0;
						vis[v]=tt;
						Q[~i&1].push(v);
					}
					(dp[~i&1][v][k+endps[son[x][j]]+endps[son[y][j]]]
						+=dp[i&1][u][k])%=mod;
				}
			}
		}
	}
	while(!Q[n&1].empty())
	{
		u=Q[n&1].front();Q[n&1].pop();
		if(u/1000==fp)ans=ad(ans,dp[n&1][u][lim]);
	}
}

inline void solve()
{
	build();
	Rep(i,0,e)gothrough(i);
	printf("%d\n",ans);
}

inline void procStatus()
{
	ifstream t("/proc/self/status");
	cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

int main()
{
    file();
    init();
    solve();
    //procStatus();
    return 0;
}

