#include <cstdio>
#include <cmath>
#include "testlib.h"

int main(int argc, char ** argv){
	registerTestlib(3, argv[1], argv[2], argv[3]);
	FILE * _fScore = fopen(argv[5], "w");
	FILE * _fMsg = fopen(argv[6], "w");
	int aL, oL;
	int score = 0;
	aL = ans.readInt();
	oL = ouf.readInt();
	if(aL==oL)score+=7;
	aL = ans.readInt();
	oL = ouf.readInt();
	if(aL==oL)score+=3;
	fprintf(_fScore, "%d", atoi(argv[4])*score/10);
	fclose(_fMsg);
	fclose(_fScore);
	quit(_ok, "");
	return 0;
}
