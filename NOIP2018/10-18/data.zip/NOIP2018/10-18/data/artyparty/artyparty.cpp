#include<bits/stdc++.h>
#define Rep(i,a,b) for(register int i=(a);i<=(b);++i)
#define Repe(i,a,b) for(register int i=(a);i>=(b);--i)
#define pb push_back
#define mp make_pair
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
#define mx(a,b) (a>b?a:b)
#define mn(a,b) (a<b?a:b)
typedef unsigned long long uint64;
typedef unsigned int uint32;
typedef long long ll;
using namespace std;

namespace IO
{
    const uint32 Buffsize=1<<15,Output=1<<23;
    static char Ch[Buffsize],*S=Ch,*T=Ch;
    inline char getc()
	{
		return((S==T)&&(T=(S=Ch)+fread(Ch,1,Buffsize,stdin),S==T)?0:*S++);
	}
    static char Out[Output],*nowps=Out;
    
    inline void flush(){fwrite(Out,1,nowps-Out,stdout);nowps=Out;}

    template<typename T>inline void read(T&x)
	{
		x=0;static char ch;T f=1;
		for(ch=getc();!isdigit(ch);ch=getc())if(ch=='-')f=-1;
		for(;isdigit(ch);ch=getc())x=x*10+(ch^48);
		x*=f;
	}

	template<typename T>inline void write(T x,char ch='\n')
	{
		if(!x)*nowps++='0';
		if(x<0)*nowps++='-',x=-x;
		static uint32 sta[111],tp;
		for(tp=0;x;x/=10)sta[++tp]=x%10;
		for(;tp;*nowps++=sta[tp--]^48);
		*nowps++=ch;
	}
}
using namespace IO;

inline void file()
{
#ifndef ONLINE_JUDGE
	FILE*ASD=freopen("artyparty-1.in","r",stdin);
	FILE*DS=freopen("artyparty-1.out","w",stdout);
#endif
}

const int MAXN=107;

static int N,M,K,dis[MAXN];

inline void init()
{
	read(K);read(M);read(N);
	Rep(i,1,K)read(dis[i]);
	Rep(i,1,K)if(dis[i]-dis[i-1]>M){K=i-1;break;}
	dis[K+1]=dis[K]+M+1;
}

const int mod=998244353;

inline int ad(int u,int v)
{return(u+=v)>=mod?u-mod:u;}

static struct nod
{
	int x,y;

	friend nod operator+(nod a,nod b)
	{return(nod){ad(a.x,b.x),ad(a.y,b.y)};}

	friend nod operator*(nod a,nod b)
	{return(nod){(int)((ll)a.x*b.x%mod)
		,(int)(((ll)a.x*b.y+(ll)a.y*b.x)%mod)};}

	void operator=(const nod a){x=a.x,y=a.y;}
}Ans[MAXN][MAXN],W[MAXN][MAXN];

static int fail[MAXN];

unordered_set<int>got;

inline void mul(nod A[][MAXN],nod B[][MAXN])
{
	static nod C[MAXN][MAXN];
	memset(C,0,sizeof C);
	Rep(i,0,K)Rep(j,0,K)Rep(k,0,K)
		C[i][j]=C[i][j]+A[i][k]*B[k][j];
	Rep(i,0,K)Rep(j,0,K)A[i][j]=C[i][j];
}

inline void solve()
{
	W[0][1].x=M-dis[1]+1;
	W[0][1].y=(ll)(M+dis[1])*(M-dis[1]+1)/2%mod;
	static int ps,boud,cnt,cns;
	Rep(i,1,K)
	{
		boud=M;
		cns=boud-dis[1]+1;
		cnt=(ll)(boud-dis[1]+1)*(boud+dis[1])/2%mod;
		got.clear();
		if(i<K)
		{
			W[i][i+1].y=dis[i+1]-dis[i];
			W[i][i+1].x=1;
			got.insert(dis[i+1]-dis[i]);
			if(dis[i+1]-dis[i]>=dis[1]
					&&dis[i+1]-dis[i]<=boud)
				cnt-=dis[i+1]-dis[i],--cns;
		}
		ps=fail[i];
		while(ps)
		{
			if(dis[ps+1]-dis[ps]==dis[i+1]-dis[i])
			{if(!fail[i+1])fail[i+1]=ps+1;}
			else if(!got.count(dis[ps+1]-dis[ps]))
			{
				got.insert(dis[ps+1]-dis[ps]);
				W[i][ps+1].x=1;
				W[i][ps+1].y=dis[ps+1]-dis[ps];
				if(dis[ps+1]-dis[ps]>=dis[1]
					&&dis[ps+1]-dis[ps]<=boud)
				{
					cnt=ad(cnt,mod-(dis[ps+1]-dis[ps]));
					--cns;
				}
			}
			ps=fail[ps];
		}
		if(i+1<=K&&!ps&&!fail[i+1]&&dis[i+1]-dis[i]>=dis[1])
			fail[i+1]=1;
		W[i][1]=(nod){cns,ad(W[i][1].y,cnt)};
	}
	Rep(i,0,K)Ans[i][i]=(nod){1,0};
	for(;N;N>>=1,mul(W,W))
		if(N&1)mul(Ans,W);
	static int ans=0;
	Rep(i,0,K)ans=ad(ans,Ans[0][i].x);
	printf("%d\n",ans);
	ans=0;
	Rep(i,0,K)ans=ad(ans,Ans[0][i].y);
	printf("%d\n",ans);
}
std::string procStatus()
{
    std::ifstream t("/proc/self/status");
    return std::string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}
int main()
{
    file();
    init();
    solve();
    //cerr<<procStatus()<<endl;
    return 0;
}

