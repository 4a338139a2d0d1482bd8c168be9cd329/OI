#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/hash_policy.hpp>
#define Rep(i,a,b) for(register int i=(a);i<=(b);++i)
#define Repe(i,a,b) for(register int i=(a);i>=(b);--i)
#define pb push_back
#define mp make_pair
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
#define mx(a,b) (a>b?a:b)
#define mn(a,b) (a<b?a:b)
typedef unsigned long long uint64;
typedef unsigned int uint32;
typedef long long ll;
using namespace std;

namespace IO
{
    const uint32 Buffsize=1<<15,Output=1<<23;
    static char Ch[Buffsize],*S=Ch,*T=Ch;
    inline char getc()
	{
		return((S==T)&&(T=(S=Ch)+fread(Ch,1,Buffsize,stdin),S==T)?0:*S++);
	}
    static char Out[Output],*nowps=Out;
    
    inline void flush(){fwrite(Out,1,nowps-Out,stdout);nowps=Out;}

    template<typename T>inline void read(T&x)
	{
		x=0;static char ch;T f=1;
		for(ch=getc();!isdigit(ch);ch=getc())if(ch=='-')f=-1;
		for(;isdigit(ch);ch=getc())x=x*10+(ch^48);
		x*=f;
	}

	template<typename T>inline void write(T x,char ch='\n')
	{
		if(!x)*nowps++='0';
		if(x<0)*nowps++='-',x=-x;
		static uint32 sta[111],tp;
		for(tp=0;x;x/=10)sta[++tp]=x%10;
		for(;tp;*nowps++=sta[tp--]^48);
		*nowps++=ch;
	}
}
using namespace IO;

inline void file()
{
#ifndef ONLINE_JUDGE
	freopen("chrysanthemum-1.in","r",stdin);
	freopen("chrysanthemum-1.out","w",stdout);
#endif
}

const int MAXN=5e5+7;

static int f[MAXN];

static struct quer
{
	ll x,y;
}q[MAXN];

static int e,tt,Q,n,m;

static ll sta[MAXN],stp[MAXN],ops[MAXN],np;

priority_queue<ll>G;

inline void init()
{
	read(n);read(m);
	Rep(i,2,n)read(f[i]);
	static int opt;
	static ll x,y;
	np=n;
	Rep(i,1,m)
	{
		read(opt);read(x);
		if(opt==1)sta[++e]=x;
		else if(opt==2)stp[++tt]=np,np+=x*e,ops[tt]=x;
		else read(y),q[++Q].x=x,q[Q].y=y
			,G.push(x),G.push(y),G.push(x),G.push(y);
	}
}

vector<int>ed[MAXN<<1];

static int t;

__gnu_pbds::cc_hash_table<ll,int>W;
__gnu_pbds::cc_hash_table<ll,ll>Fa;

inline ll getfa(ll u)
{
	if(!tt)return f[u];
	else return (u-stp[tt]-1)%ops[tt]?
		stp[tt]+(u-stp[tt]-1)/ops[tt]*ops[tt]+1:
		sta[(u-stp[tt]-1)/ops[tt]+1];
}

static ll pois[MAXN<<1],ans[MAXN];

static vector<int>ask[MAXN<<1];

namespace DSU
{
	int FFF[MAXN<<2];
	
	void init(){Rep(i,1,t)FFF[i]=i;}

	inline int FD(int u){return FFF[u]==u?u:FFF[u]=FD(FFF[u]);}
}

static int vis[MAXN<<1];

void tarjan(int u)
{
	vis[u]=1;
	if(!ask[u].empty())for(register int v:ask[u])
		if(q[v].x==pois[u]&&vis[W[q[v].y]])
			ans[v]=pois[DSU::FD(W[q[v].y])];
		else if(q[v].y==pois[u]&&vis[W[q[v].x]])
			ans[v]=pois[DSU::FD(W[q[v].x])];

	for(register int v:ed[u])tarjan(v),DSU::FFF[DSU::FD(v)]=u;
}

inline void solve()
{
	static ll u;
	while(!G.empty())
	{
		u=G.top();G.pop();
		while(stp[tt]>=u)--tt;
		Fa[u]=getfa(u);
		if(!G.empty()&&G.top()==u)
			W[u]=++t,pois[t]=u;
		while(!G.empty()&&G.top()==u)G.pop();
		if(u^1)G.push(Fa[u]);
	}

	Rep(i,1,t-1)
	{
		u=Fa[pois[i]];
		while(u&&!W[u])u=Fa[u];
		ed[W[u]].pb(i);
	}

	Rep(i,1,Q)ask[W[q[i].x]].pb(i),ask[W[q[i].y]].pb(i);

	DSU::init();
	tarjan(t);

	Rep(i,1,Q)
	{
		write(ans[i]);
		if(i%100000==0)flush();
	}
	flush();
}

int main()
{
    file();
    init();
    solve();
    return 0;
}

