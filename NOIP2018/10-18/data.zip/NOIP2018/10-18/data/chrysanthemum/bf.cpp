#include<bits/stdc++.h>
#define Rep(i,a,b) for(register int i=(a);i<=(b);++i)
#define Repe(i,a,b) for(register int i=(a);i>=(b);--i)
#define pb push_back
#define mp make_pair
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
#define mx(a,b) (a>b?a:b)
#define mn(a,b) (a<b?a:b)
typedef unsigned long long uint64;
typedef unsigned int uint32;
typedef long long ll;
using namespace std;

namespace IO
{
    const uint32 Buffsize=1<<15,Output=1<<23;
    static char Ch[Buffsize],*S=Ch,*T=Ch;
    inline char getc()
	{
		return((S==T)&&(T=(S=Ch)+fread(Ch,1,Buffsize,stdin),S==T)?0:*S++);
	}
    static char Out[Output],*nowps=Out;
    
    inline void flush(){fwrite(Out,1,nowps-Out,stdout);nowps=Out;}

    template<typename T>inline void read(T&x)
	{
		x=0;static char ch;T f=1;
		for(ch=getc();!isdigit(ch);ch=getc())if(ch=='-')f=-1;
		for(;isdigit(ch);ch=getc())x=x*10+(ch^48);
		x*=f;
	}

	template<typename T>inline void write(T x,char ch='\n')
	{
		if(!x)*nowps++='0';
		if(x<0)*nowps++='-',x=-x;
		static uint32 sta[111],tp;
		for(tp=0;x;x/=10)sta[++tp]=x%10;
		for(;tp;*nowps++=sta[tp--]^48);
		*nowps++=ch;
	}
}
using namespace IO;

inline void file()
{
#ifndef ONLINE_JUDGE
	freopen("chrysanthemum.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
}

const int MAXN=1e7+7;

static int n,m;

vector<int>ed[MAXN];

inline void init()
{
	read(n);read(m);
	static int f;
	Rep(i,2,n)read(f),ed[f].pb(i);
}

static int sta[MAXN],e,tt,Q,fa[MAXN];

static pair<int,int>q[MAXN];

static vector<int>ask[MAXN];

inline int Find(int u)
{return fa[u]==u?u:fa[u]=Find(fa[u]);}

static int ans[MAXN];

void tarjan(int u)
{
	for(register int v:ask[u])if(!ans[v])
		ans[v]=(q[v].first==u)?
			Find(q[v].second):Find(q[v].first);
	fa[u]=u;
	for(register int v:ed[u])tarjan(v),fa[v]=u;
}

inline void solve()
{
	static int opt,x,y;
	tt=n;
	Rep(i,1,m)
	{
		read(opt);read(x);
		if(opt==1)sta[++e]=x;
		else if(opt==2)Rep(j,1,e)
		{
			ed[sta[j]].pb(y=++tt);
			Rep(k,1,x-1)ed[y].pb(++tt);
		}
		else read(y),q[++Q]=mp(x,y);
	}
	Rep(i,1,Q)ask[q[i].first].pb(i)
		,ask[q[i].second].pb(i);

	tarjan(1);

	Rep(i,1,Q)write(ans[i]?ans[i]:q[i].first);
	flush();
}

int main()
{
    file();
    init();
    solve();
    return 0;
}

