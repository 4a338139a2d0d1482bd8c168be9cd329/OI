#include <bits/stdc++.h>

using namespace std;

#define fst first
#define snd second
#define squ(x) ((LL)(x) * (x))
#define debug(...) fprintf(stderr, __VA_ARGS__)

typedef long long LL;
typedef pair<int, int> pii;

inline int read() {
	int sum = 0, fg = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') fg = -1;
	for (; isdigit(c); c = getchar()) sum = (sum << 3) + (sum << 1) + (c ^ 0x30);
	return fg * sum;
}

inline void proc_status() {
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

const int maxn = 5e5 + 10;
const int maxm = 1e7 + 10;

int n, m, ans[maxn];

int Begin[maxm], Next[maxm], To[maxm], e;

void add(int x, int y) { To[++e] = y, Next[e] = Begin[x], Begin[x] = e; }

vector<pii> q[maxm];

namespace Tree {

	int fa[maxm]; bool v[maxm];

	int find(int x) { return x == fa[x] ? x : fa[x] = find(fa[x]); }

	void init() {
		e = -1, memset(Begin, -1, sizeof Begin);
		for (int i = 2; i <= n; i++) add(read(), i);
	}

	void dfs(int now, int f) {
		fa[now] = now;
		for (int i = Begin[now]; i + 1; i = Next[i]) dfs(To[i], now);
		for (int i = 0; i < q[now].size(); i++) {
			int x = q[now][i].fst, y = q[now][i].snd;
			if (v[x]) ans[y] = find(x);
		}
		v[now] = 1;
		fa[now] = f;
	}

}

int S[maxn], top, cnt;

int main() {
	freopen("chrysanthemum.in", "r", stdin);
	freopen("chrysanthemum.out", "w", stdout);

	n = read(), m = read();
	Tree::init();

	while (m--) {
		int op = read();
		if (op == 1) S[++top] = read();
		if (op == 2) {
			int x = read();
			for (int i = 1; i <= top; i++) {
				add(S[i], ++n);
				for (int j = 1; j < x; j++) add(n, n + j);
				n = n + x - 1;
			}
		}
		if (op == 3) {
			int x = read(), y = read();
			q[x].push_back((pii){y, ++cnt});
			q[y].push_back((pii){x, cnt});
		}
	}

	Tree::dfs(1, 0);
	for (int i = 1; i <= cnt; i++) printf("%d\n", ans[i]);

//	proc_status();

	return 0;
}
