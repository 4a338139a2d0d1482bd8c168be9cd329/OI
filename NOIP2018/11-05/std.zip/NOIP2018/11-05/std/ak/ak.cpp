#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
 
#define fo(i,j,l) for(int i=j;i<=l;++i)
#define fd(i,j,l) for(int i=j;i>=l;--i)
 
using namespace std;
typedef long long ll;
const ll N=47e4,M=1<<21,K=M>>1;
 
int a[N],f[M],n;
 
inline int min(int a,int b)
{return a<b?a:b;}
 
 inline int read()
 {
 	int o=0; char ch=' ';
 	for(;ch<'0'||ch>'9';ch=getchar());
 	for(;ch>='0'&&ch<='9';ch=getchar())o=o*10+(ch^48);
 	return o;
 }
 
inline void pri(int o)
{(o)?(pri(o/10),putchar(o%10+48)):0;} 

int main()
{
	freopen("ak.in","r",stdin);
	freopen("ak.out","w",stdout); 
    scanf("%d",&n);
    fo(i,0,M-1)f[i]=n+1;
    fo(i,1,n){
        a[i]=read();
        a[i]=a[i]^a[i-1];
        f[a[i]]=min(f[a[i]],i);
    }
    fd(i,K,0)
    fo(l,0,19)if(!((i>>l)&1))f[i]=min(f[i],f[i^(1<<l)]);
    int ans=0;
    fo(i,1,n){
        int nn=0;
        fd(l,19,0)if(!((a[i]>>l)&1)&&f[nn^(1<<l)]<=i)nn=nn^(1<<l);
        ans=nn+nn+a[i];
        if(!ans)puts("0");else pri(ans),putchar('\n');
    }
}
