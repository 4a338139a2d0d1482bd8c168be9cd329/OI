#include <cstdio>
#include <cstdlib>
#include <algorithm>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fod(i,a,b) for(int i=a;i>=b;i--)
#define efo(i,q) for(int i=A[q];i;i=B[i][0])
#define max(q,w) ((q)>(w)?(q):(w))
using namespace std;
typedef long long LL;
const int N=500500,mo=998244353;
int read(int &n)
{
    char ch=' ';int q=0,w=1;
    for(;(ch!='-')&&((ch<'0')||(ch>'9'));ch=getchar());
    if(ch=='-')w=-1,ch=getchar();
    for(;ch>='0' && ch<='9';ch=getchar())q=q*10+ch-48;n=q*w;return n;
}
int m,n;
LL ans;
int B[2*N][2],A[N],Bv[N],B0;
int dp[N];
int root,zx1,root1;
LL jc[N],jcn[N],sum[N];
int d[N],lf;
void link(int q,int w)
{
    ++Bv[q],++Bv[w];
    B[++B0][0]=A[q],A[q]=B0,B[B0][1]=w;
    B[++B0][0]=A[w],A[w]=B0,B[B0][1]=q;
}
void dfsf(int q,int fa)
{
    dp[q]=0;
    efo(i,q)if(B[i][1]!=fa)dfsf(B[i][1],q),dp[q]=max(dp[q],dp[B[i][1]]+1);
    if(1==Bv[q])++lf;
}
void dfs(int q,int mx,int fa)
{
    int mx1=0,t=0;
    efo(i,q)if(B[i][1]!=fa)
    {
        if(dp[B[i][1]]+1>mx)t=mx,mx=dp[B[i][1]]+1,mx1=B[i][1];
        else if(dp[B[i][1]]+1>t)t=dp[B[i][1]]+1;
    }
    ans=max(ans,mx+t);
    if(zx1>mx)zx1=mx,root=q;
    else if(zx1==mx)root1=q;
    efo(i,q)if(B[i][1]!=fa)dfs(B[i][1],(mx1==B[i][1]?t:mx)+1,q);
}
int dfss(int q,int c,int fa)
{
    int ans=(!c);
    efo(i,q)if(B[i][1]!=fa)ans+=dfss(B[i][1],c-1,q);
    return ans;
}
LL ksm(LL q,int w)
{
    LL ans=1;
    for(;w;w>>=1,q=q*q%mo)if(w&1)ans=ans*q%mo;
    return ans;
}
LL C(int m,int n){return jc[m]*jcn[m-n]%mo*jcn[n]%mo;}
LL Gans(LL m,LL m1)
{
    fod(i,m,0)sum[i]=(sum[i+1]+m1*ksm(i,mo-2))%mo;
    LL ans=0,ans1=0;
    fo(I,1,d[0])
    {
        fo(i,0,d[I]-1)
        {
            LL t=C(d[I],i)*jc[m-d[I]+i-1]%mo*(m-d[I])%mo;
            ans=(ans+t*sum[d[I]-i+1]%mo*jc[d[I]-i])%mo;
            ans1=(ans1+t)%mo;
        }
    }
    return ans*jcn[m]%mo;
}
int main()
{
    freopen("winer.in","r",stdin);
    freopen("winer.out","w",stdout);
    int q,w;
    read(n);
    fo(i,1,n-1)read(q),read(w),link(q,w);
    jc[0]=1;fo(i,1,n)jc[i]=jc[i-1]*(LL)i%mo;
    jcn[n]=ksm(jc[n],mo-2);fod(i,n-1,0)jcn[i]=jcn[i+1]*(i+1LL)%mo;
    dfsf(1,0);
    zx1=1e9;dfs(1,0,0);
    if(ans&1)
    {
        d[0]=2;
        d[1]=dfss(root,ans/2,root1);
        d[2]=dfss(root1,ans/2,root);
        ans=Gans(d[1]+d[2],lf);
    }else
    {
        q=0;d[0]=0;
        efo(i,root)q+=(d[++d[0]]=dfss(B[i][1],ans/2-1,root));
        ans=Gans(q,lf);
    }
    printf("%lld\n",ans);
    return 0;
}