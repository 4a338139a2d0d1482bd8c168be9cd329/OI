/************************************************
 * Au: Hany01
 * Date: 
 * Prob: 
 * Email: hany01dxx@gmail.com & hany01@foxmail.com
 * Inst: Yali High School
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef long double LD;
typedef pair<int, int> PII;
#define Rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define X first
#define Y second
#define PB(a) push_back(a)
#define MP(a, b) make_pair(a, b)
#define SZ(a) ((int)(a).size())
#define ALL(a) a.begin(), a.end()
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read() {
	static int _, __; static char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}
//EOT

const int maxn = 5e5 + 5, MAX = 1e9;

int N[11], M[11], n, m, a[maxn];
char file[23];

int main()
{
	N[1] = 1e2, M[1] = 1e2;
	N[2] = 1e3, M[2] = 1;
	N[3] = 5e5, M[3] = 1;
	N[4] = 1e3, M[4] = 1e3;
	N[5] = 4e5, M[5] = 4e5;
	N[6] = 4e5, M[6] = 4e5;
	N[7] = 4e5, M[7] = 4e5;
	N[8] = 4e5, M[8] = 4e5;
	N[9] = 4e5, M[9] = 4e5;
	N[10] = 4e5, M[10] = 4e5;

	For(Case, 1, 10) {
		sprintf(file, "kite%d.in", Case);
		freopen(file, "w", stdout);
		printf("%d %d\n", n = N[Case], m = M[Case]);
		if (Case == 5) For(i, 1, n) a[i] = n - i + 1;
		else if (Case == 6) For(i, 1, n) a[i] = i;
		else For(i, 1, n) a[i] = rand() % MAX + 1;
		For(i, 1, n) printf("%d ", a[i]);
		putchar('\n');
		while (m --)
			printf("%d %d\n", Case == 7 ? ((rand() & 1) * (n - 1) + 1) : rand() % n + 1, rand() % MAX + 1);
		debug("Finished Case #%d\n", Case);
	}

	return 0;
}
