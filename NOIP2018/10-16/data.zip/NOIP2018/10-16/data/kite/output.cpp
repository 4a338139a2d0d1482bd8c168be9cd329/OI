/************************************************
 * Au: Hany01
 * Prob: cf650d
 * Email: hany01dxx@gmail.com & hany01@foxmail.com
 * Inst: Yali High School
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef long double LD;
typedef pair<int, int> PII;
#define Rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define X first
#define Y second
#define PB(a) push_back(a)
#define MP(a, b) make_pair(a, b)
#define SZ(a) ((int)(a).size())
#define ALL(a) a.begin(), a.end()
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read() {
	static int _, __; static char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}
//EOT


const int maxn = 5e5 + 5;

int n, m, N, a[maxn], predp[maxn], sufdp[maxn], mx1, mx2, cnt[maxn], ls[maxn << 1], clk;

struct Query {
    int a, b;
}qry[maxn];

struct PresidentTree {
	struct Node {
		int lc, rc, val;
	}tr[maxn * 23];
	int tot;
#define mid ((l + r) >> 1)
	void update(int &t, int las, int l, int r, int x, int dt) {
		tr[t = ++ tot] = tr[las], chkmax(tr[t].val, dt);
		if (l == r) return;
		if (x <= mid) update(tr[t].lc, tr[las].lc, l, mid, x, dt);
		else update(tr[t].rc, tr[las].rc, mid + 1, r, x, dt);
	}
	int query(int t, int l, int r, int x, int y) {
        if (x > y) return 0;
		if (x <= l && r <= y) return tr[t].val;
		if (y <= mid) return query(tr[t].lc, l, mid, x, y);
		if (x >  mid) return query(tr[t].rc, mid + 1, r, x, y);
		return max(query(tr[t].lc, l, mid, x, y), query(tr[t].rc, mid + 1, r, x, y));
	}
#undef mid
}T1, T2;
int rt1[maxn], rt2[maxn];

inline void Init() {
	n = read(), m = read(), T1.tot = T2.tot = mx1 = mx2 = 0;
	For(i, 1, n) a[i] = ls[i] = read();
    For(i, 1, m) qry[i].a = read(), ls[i + n] = qry[i].b = read();
    sort(ls + 1, ls + 1 + n + m), N = unique(ls + 1, ls + 1 + n + m) - ls - 1;
    For(i, 1, n) a[i] = lower_bound(ls + 1, ls + 1 + N, a[i]) - ls;
    For(i, 1, m) qry[i].b = lower_bound(ls + 1, ls + 1 + N, qry[i].b) - ls;

	rt1[0] = rt2[n + 1] = 0;
	For(i, 1, n)
		T1.update(rt1[i], rt1[i - 1], 1, N, a[i], predp[i] = T1.query(rt1[i - 1], 1, N, 1, a[i] - 1) + 1),
		chkmax(mx1, predp[i]);
	Fordown(i, n, 1)
		T2.update(rt2[i], rt2[i + 1], 1, N, a[i], sufdp[i] = T2.query(rt2[i + 1], 1, N, a[i] + 1, N) + 1),
		chkmax(mx2, sufdp[i]);
	assert(mx1 == mx2);

	Set(cnt, 0);
	For(i, 1, n) if (predp[i] + sufdp[i] == mx1 + 1) ++ cnt[predp[i]];
}

inline void Solve() {
    For(i, 1, m)
		printf("%d\n", max(T1.query(rt1[qry[i].a - 1], 1, N, 1, qry[i].b - 1) + T2.query(rt2[qry[i].a + 1], 1, N, qry[i].b + 1, N) + 1, mx1 - (cnt[predp[qry[i].a]] < 2 && predp[qry[i].a] + sufdp[qry[i].a] == mx1 + 1)));
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("kite.in", "r", stdin);
	freopen("kite.out", "w", stdout);
#endif

	static char inputfile[33], outputfile[33];

	For(Case, 1, 10) {
		clk = clock();
		sprintf(inputfile, "kite%d.in", Case), sprintf(outputfile, "kite%d.out", Case);
		freopen(inputfile, "r", stdin), freopen(outputfile, "w", stdout);
		Init();
		Solve();
		debug("Finished Case #%d in %.3lf second(s)\n", Case, (clock() - clk) * 1. / CLOCKS_PER_SEC);
	}

	return 0;
}
