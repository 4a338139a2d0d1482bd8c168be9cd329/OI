/**************************************
 * Au: Hany01
 * Prob: graph
 * Date: Oct 2nd, 2018
 * Email: hany01@foxmail.com
**************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef long double LD;
typedef pair<int, int> PII;
typedef vector<int> VI;
#define File(a) freopen(a".in", "r", stdin), freopen(a".out", "w", stdout)
#define Rep(i, j) for (register int i = 0, i##_end_ = j; i < i##_end_; ++ i)
#define For(i, j ,k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define ALL(a) a.begin(), a.end()
#define PB(a) push_back(a)
#define MP(a, b) make_pair(a, b)
#define x first
#define y second
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define y1 wozenmezhemecaia 
#ifdef hany01
#define debug(...) fprintf(stderr, __VA_ARGS__)
#else
#define debug(...)
#endif

template<typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read() {
    register char c_; register int _, __;
    for (_ = 0, __ = 1, c_ = getchar(); !isdigit(c_); c_ = getchar()) if (c_ == '-')  __ = -1;
    for ( ; isdigit(c_); c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}
//EOT


const int maxn = 3e5 + 5;

int n;

int beg[maxn], nex[maxn << 1], v[maxn << 1], e = 1;

inline void add(int uu, int vv) { v[++ e] = vv, nex[e] = beg[uu], beg[uu] = e; }

inline void Init() {
    n = read();
    for (register int m = read(), u, v; m --; )
        u = read(), v = read(), add(u, v), add(v, u);
}

int dfn[maxn], low[maxn], clk, mx, mn, R[maxn], fa[maxn];

inline void getCircle(int u, int anc) {
	mx = 0, mn = INF;
	do chkmin(mn, u), chkmax(mx, u), u = fa[u]; while (u != fa[anc]);
	chkmin(mn, anc), chkmax(mx, anc);
	chkmin(R[mn], mx - 1);
}

void DFS(int u, int pa) {
    dfn[u] = low[u] = ++ clk, fa[u] = pa;
    for (register int i = beg[u]; i; i = nex[i]) if (v[i] != pa)
        if (!dfn[v[i]]) DFS(v[i], u), chkmin(low[u], low[v[i]]);
        else if (dfn[v[i]] < dfn[u]) chkmin(low[u], dfn[v[i]]);
	for (register int i = beg[u]; i; i = nex[i])
		if (low[v[i]] == dfn[u] && fa[v[i]] != u) getCircle(v[i], u);
}

inline void Work() {
    For(i, 1, n) R[i] = n;
    For(i, 1, n) if (!dfn[i]) DFS(i, 0);
    Fordown(i, n, 2) chkmin(R[i - 1], R[i]);
}

inline void Query() {
    static LL sum[maxn];
    For(i, 1, n) sum[i] = sum[i - 1] + R[i];
    //For(i, 1, n) cout << R[i] << ' ';
    //cout << endl;
    for (register int q = read(), l, r, t; q --; ) {
        l = read(), r = read(), t = upper_bound(R + l, R + r + 1, r) - R - 1,
        cout << sum[t] - sum[l - 1] - (LL)(l + t - 2) * (t - l + 1) / 2 + (LL)(r - t + 1) * (r - t) / 2 << endl;
    }
}

int main()
{
#ifndef ONLINE_JUDGE
    File("graph");
#endif

    Init();

    Work();

    Query();

    cerr << clock() * 1. / CLOCKS_PER_SEC << endl;

    return 0;
}
