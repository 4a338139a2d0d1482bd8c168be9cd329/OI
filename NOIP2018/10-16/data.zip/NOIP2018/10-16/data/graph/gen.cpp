/************************************************
 * Au: Hany01
 * Prob: graph-gen
 * Email: hany01dxx@gmail.com & hany01@foxmail.com
 * Inst: Yali High School
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef long double LD;
typedef pair<int, int> PII;
#define Rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define X first
#define Y second
#define PB(a) push_back(a)
#define MP(a, b) make_pair(a, b)
#define SZ(a) ((int)(a).size())
#define ALL(a) a.begin(), a.end()
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read() {
	static int _, __; static char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}
//EOT


const int maxn = 3e5 + 5;

int N[11] = {0, 100, 100, 100, (int)3e5, (int)3e5, (int)3e5, (int)3e5, (int)3e5, (int)3e5, (int)3e5};
char file[33];

int beg[maxn], v[maxn << 1], nex[maxn << 1], e = 1, issq[maxn], lst[maxn], tot, ls[maxn], lss, deg[maxn];
int n;

inline void add(int uu, int vv) { v[++ e] = vv, nex[e] = beg[uu], beg[uu] = e, ++ deg[vv]; }

inline bool check(int u) {
    for (register int i = beg[u]; i; i = nex[i])
        if (issq[v[i]]) return 0;
    return 1;
}

inline int id(int x) { return lower_bound(ls + 1, ls + 1 + lss, x) - ls; }

inline void getGraph(int Case) {
	static int fa[maxn];
	if (Case == 4) {
		n = N[Case] - rand() % 5;
		printf("%d %d\n", n, n - 1);
		For(i, 2, n) printf("%d %d\n", i, rand() % (i - 1) + 1);
		return;
	}
	if (Case == 5) {
		n = N[Case] - rand() % 5;
		printf("%d %d\n", n, n);
		For(i, 2, n) printf("%d %d\n", i, rand() % (i - 1) + 1);
		int l, r;
		do l = rand() % n + 1, r = rand() % n + 1; while (l == r && fa[r] != l && fa[l] != r);
		printf("%d %d\n", l, r);
		return;
	}
	int ns = N[Case] - rand() % 5, cnt = 0;
    Set(beg, 0), Set(deg, 0), Set(issq, 0), lss = 0, e = 1;
	For(i, 2, ns) fa[i] = rand() % (i - 1) + 1, add(fa[i], i), add(i, fa[i]);
	for (int tms = ns * (.3 - 1. / (Case + 5)); tms --; ) {
        int t = rand() % ns + 1;
        if (deg[t] > 2 && !issq[t] && check(t)) issq[t] = 1, ++ cnt;
    }
    printf("%d %d\n", n = ns - cnt, ns - 1);
    For(u, 1, ns) if (!issq[u]) ls[++ lss] = u;
    For(u, 1, ns) if (issq[u]) {
        tot = 0;
        for (register int i = beg[u]; i; i = nex[i]) lst[tot ++] = v[i];
        Rep(i, tot) printf("%d %d\n", id(lst[i]), id(lst[(i + 1) % tot]));
    }
    For(u, 1, ns) if (!issq[u]) {
        for (register int i = beg[u]; i; i = nex[i])
            if (!issq[v[i]] && v[i] > u) printf("%d %d\n", id(u), id(v[i]));
    }
}

int main()
{
	srand(time(0));

	For(T, 1, 10) {
		sprintf(file, "graph%d.in", T), freopen(file, "w", stdout);
		getGraph(T);
		register int q, l, r;
		printf("%d\n", q = N[T] - rand() % 5);
		while (q --) {
			l = rand() % n + 1, r = rand() % n + 1;
			if (l > r) swap(l, r);
			printf("%d %d\n", l, r);
		}
        debug("Finished Case #%d\n", T);
	}

	return 0;
}
