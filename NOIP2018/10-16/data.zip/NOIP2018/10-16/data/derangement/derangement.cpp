/************************************************
 * Au: Hany01
 * Prob: derangement
 * Email: hany01dxx@gmail.com & hany01@foxmail.com
 * Inst: Yali High School
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef long double LD;
typedef pair<int, int> PII;
#define Rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define X first
#define Y second
#define PB(a) push_back(a)
#define MP(a, b) make_pair(a, b)
#define SZ(a) ((int)(a).size())
#define ALL(a) a.begin(), a.end()
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

template <typename T> inline T read() {
	static T _, __; static char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}
//EOT


const int maxn = 5005, MOD = 1e9 + 9;

int n, p[maxn];
int f[maxn][maxn], sum1[maxn], sum2[maxn], ans;

inline int inc(int x, int y) { return (x += y) >= MOD ? x - MOD : x; }

int main()
{
#ifndef ONLINE_JUDGE
	freopen("derangement.in", "r", stdin);
	freopen("derangement.out", "w", stdout);
#endif

	n = read<int>();
	For(i, 1, n) p[i] = read<int>();

	f[0][0] = f[0][1] = 1, f[0][2] = 2;
	For(i, 1, n)  {
		if (i) f[i][0] = (LL)(i - 1) * inc(f[i - 1][0], f[i - 2][0]) % MOD;
		For(j, 1, 2) f[i][j] = inc((LL)f[i][j - 1] * j % MOD, (LL)i * f[i - 1][j] % MOD);
		sum1[i] = inc(sum1[i - 1], i), sum2[i] = inc(sum2[i - 1], sum1[i]);
	}

	For(i, 1, n - 1) For(j, i + 1, n) {
		int a1 = max(0, p[j] - p[i]);
		int a2 = inc(inc(sum1[p[j] - 1], sum1[n - p[i]]), inc(MOD - a1, MOD - a1));
		int a3 = inc(inc(sum2[n - 1], inc(inc(MOD - a1, MOD - a2), inc(MOD - sum1[p[i] - 1],
							MOD - sum1[n - p[j]]))), max(0, p[i] - p[j]));
		if (n > 1) ans = inc(ans, (LL)a1 * f[n - 2][0] % MOD * (j - i) % MOD);
		if (n > 2) ans = inc(ans, (LL)a2 * f[n - 3][1] % MOD * (j - i) % MOD);
		if (n > 3) ans = inc(ans, (LL)a3 * f[n - 4][2] % MOD * (j - i) % MOD);
	}
	(ans += MOD) %= MOD;
	printf("%d\n", ans);

#ifdef hany01
	cerr << clock() * 1. / CLOCKS_PER_SEC << endl;
#endif

	return 0;
}
