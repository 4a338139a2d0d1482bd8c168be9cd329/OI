/************************************************
 * Au: Hany01
 * Prob: derangement-gen
 * Email: hany01dxx@gmail.com & hany01@foxmail.com
 * Inst: Yali High School
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef long double LD;
typedef pair<int, int> PII;
#define Rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define X first
#define Y second
#define PB(a) push_back(a)
#define MP(a, b) make_pair(a, b)
#define SZ(a) ((int)(a).size())
#define ALL(a) a.begin(), a.end()
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

template <typename T> inline T read() {
	static T _, __; static char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}
//EOT


random_device rd;
#define rand rd


const int maxn = 5005;

int n, p[maxn], N[11] = {0, 16, 16, 16, 100, 100, 100, 5000, 5000, 5000, 5000};
char file[33];

int main()
{

	For(Case, 1, 10) {
		sprintf(file, "derangement%d.in", Case);
		freopen(file, "w", stdout);

		printf("%d\n", n = N[Case] - rand() % 5);
		For(i, 1, n) p[i] = i;
		random_shuffle(p + 1, p + 1 + n);
		For(i, 1, n) printf("%d ", p[i]);

		debug("Finished Case #%d\n", Case);
	}

	return 0;
}
