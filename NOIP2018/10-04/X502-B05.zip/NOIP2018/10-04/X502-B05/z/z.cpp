#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int a[101010];
int main()
{
	int n,q,i,x,ll,rr,j;
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	long long ans=0;
	scanf("%d%d",&n,&q);
	for(i=1;i<=n;i++)
		scanf("%d",&a[i]);
	if(n<=1000&&q<=1000)
	{
		for(i=1;i<=q;i++)
		{
			scanf("%d",&x);
			ll=0,rr=x;
			ans=0;
			for(j=1;j<=n;j++)
			{
				if(a[j]>rr)
				{
					ans+=a[j]-rr;
					rr=a[j],ll=a[j]-x;
				}
				else if(a[j]<ll)
				{
					ans+=ll-a[j];
					ll=a[j],rr=a[j]+x;
				}
			}
			printf("%lld\n",ans);
		}
		return 0;
	}
	while(q--)
	{
		scanf("%d",&x);
		ll=0,rr=x,ans=0;
		if(a[1]>rr)
		{
			ans+=a[1]-rr;
			rr=a[1],ll=a[1]-x;
		}
		else if(a[1]<ll)
		{
			ans+=ll-a[1];
			ll=a[j],rr=a[1]+x;
		}
		if(a[n]>rr)
		{
			ans+=a[n]-rr;
			rr=a[n],ll=a[n]-x;
		}
		else if(a[n]<ll)
		{
			ans+=ll-a[n];
			ll=a[j],rr=a[n]+x;
		}
		printf("%lld\n",ans);
	}
	return 0;
}

