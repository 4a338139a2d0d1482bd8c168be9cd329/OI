#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int f[22][99][2222],dp[22][99][2222],vis[2222][2222];
vector<int>s[99],s1,s2,w[99];
int n,m,d;
void dfs(int x,int S,int num)
{
	int c,i,y;
	if(f[num][x][S]==1)
		return;
	f[num][x][S]=1;
	if(num==d/2)
		return;
	c=s[x].size();
	for(i=0;i<c;i++)
	{
		y=s[x][i];
		dfs(y,S*2+w[x][i],num+1);
	}
}
int main()
{
	freopen("y.in","r",stdin);
	freopen("y.out","w",stdout);
	int x,y,l,ans=0,now,tmp1,tmp2,i,j,k,c;
	scanf("%d%d%d",&n,&m,&d);
	for(i=1;i<=m;i++)
	{
		scanf("%d%d%d",&x,&y,&l);
		s[x].push_back(y);
		s[y].push_back(x);
		w[x].push_back(l);
		w[y].push_back(l);
	}
	dfs(1,0,0);
	for(i=1;i<=n;i++)
		dp[d+1][i][0]=1;
	now=1;
	for(i=d+1;i>d/2+1;i--)
	{
		for(j=1;j<=n;j++)
		{
			for(k=0;k<(1<<d+1-i);k++)
			{
				if(dp[i][j][k]==0)
					continue;
				tmp1=k;
				tmp2=k+now;
				c=s[j].size();
				for(l=0;l<c;l++)
				{
					y=s[j][l];
					if(w[j][l]==0)
						dp[i-1][y][tmp1]=1;
					else
						dp[i-1][y][tmp2]=1;
				}
			}
		}
		now*=2;
	}
	for(i=1;i<=n;i++)
	{
		s1.clear(),s2.clear();
		for(j=0;j<(1<<d/2);j++)
			if(f[d/2][i][j]==1)
				s1.push_back(j);
		for(j=0;j<(1<<d-d/2);j++)
			if(dp[d/2+1][i][j]==1)
				s2.push_back(j);
		for(j=0;j<s1.size();j++)
			for(k=0;k<s2.size();k++)
				if(vis[s1[j]][s2[k]]==0)
					vis[s1[j]][s2[k]]=1,ans++;
	}
	printf("%d\n",ans);
	return 0;
}

