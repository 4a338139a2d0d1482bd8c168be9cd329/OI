#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int notprime[1010101],pri[1010101],fa[101010],a[101010];
vector<int>s[1010101];
int sum;
const int INF=1000000007;
int find_set(int x)
{
	if(fa[x]==x)
		return x;
	return fa[x]=find_set(fa[x]);
}
void union_set(int x,int y)
{
	int xx=find_set(x),yy=find_set(yy);
	if(xx!=yy)
		fa[xx]==yy,sum--;
}
void init(int n)
{
	for(int i=1;i<=n;i++)
		fa[i]=i;
}
int main()
{
	freopen("x.in","r",stdin);
	freopen("x.out","w",stdout);
	int i,j,k,T,ans,cnt=0,n,x,now;
	for(i=2;i<=1000000;i++)
	{
		if(notprime[i]==0)
			pri[++cnt]=i;
		for(j=1;j<=cnt;j++)
		{
			if(i*pri[j]>1000000)
				break;
			notprime[i*pri[j]]=1;
			if(i%pri[j]==0)
				break;
		}
	}
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		init(n);
		for(i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			s[a[i]].push_back(i);
		}
		sum=n;
		for(i=1;i<=cnt;i++)
		{
			x=pri[i];
			now=0;
			for(j=x;j<=1000000;j+=x)
				for(k=0;k<s[j].size();k++)
				{
					if(now==0)
						now=s[j][k];
					else
						union_set(now,s[j][k]);
				}
		}
		ans=1;
		for(i=1;i<=sum;i++)
			ans=ans*2%INF;
		ans=(ans-2+INF)%INF;
		printf("%d\n",ans);
		for(i=1;i<=n;i++)
			s[a[i]].clear();
	}
	return 0;
}

