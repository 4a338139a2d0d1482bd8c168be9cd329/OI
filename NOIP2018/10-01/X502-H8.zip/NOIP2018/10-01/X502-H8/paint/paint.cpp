#include<cstdio>
#include<algorithm>
#include<cctype>
#define REP(i, a, b) for(int i = (a); i < (b); i++)
#define _for(i, a, b) for(int i = (a); i <= (b); i++)
using namespace std;

const int MAXN = 60;
int map[MAXN][MAXN], n, m;
int dir[4][2] = {0, 1, 0, -1, 1, 0, -1, 0};            

void draw(int x, int y, int id)
{
	map[x][y] = id;
	REP(i, 0, 4)
	{
		int xx = x + dir[i][0], yy = y + dir[i][1];
		if(1 <= xx && xx <= n && 1 <= yy && yy <= m && map[xx][yy] == 1)
			draw(xx, yy, id);
	}
}                                                                                       

int main()
{
	freopen("paint.in", "r", stdin);
	freopen("paint.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	_for(i, 1, n)
		_for(j, 1, m)
			scanf("%1d", &map[i][j]);
	
	int cnt = 1;
	_for(i, 1, n)
		_for(j, 1, m)
			if(map[i][j] == 1)
				draw(i, j, ++cnt);
				
	if(n == 1) { printf("%d\n", cnt-1); return 0; }
	printf("%d\n", (cnt-1)/4 + 1);

	return 0;
}
