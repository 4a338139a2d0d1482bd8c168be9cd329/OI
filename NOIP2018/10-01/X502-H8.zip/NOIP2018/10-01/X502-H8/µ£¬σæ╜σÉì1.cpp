#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
template<typename T>inline bool chkmin(T &x,T y){return (y<x)?(x=y,1):0;}
template<typename T>inline bool chkmax(T &x,T y){return (y>x)?(x=y,1):0;}
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c>'9' || c<'0'));
	if(c=='-') f=-1,c=getchar();
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=6000+10,mod=1e9+7;
struct point{
	int x,y;
	bool operator <(const point &rhs) const{
		return x<rhs.x;
	}
}a[maxn];
int f[maxn],g[maxn];
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("refract.in","r",stdin);
	freopen("refract.out","w",stdout);
#endif
	int n=read();
	REP(i,1,n) a[i].x=read(),a[i].y=read();
	sort(a+1,a+n+1);
	REP(i,1,n){
		f[i]=g[i]=1;
		DREP(j,i-1,1)
			if(a[i].y<a[j].y) add(g[j],f[i]);
			else add(f[i],g[j]);
	}
	int ans=mod-n;
	REP(i,1,n) add(ans,g[i]),add(ans,f[i]);
	printf("%d\n",ans);
	return 0;
}
