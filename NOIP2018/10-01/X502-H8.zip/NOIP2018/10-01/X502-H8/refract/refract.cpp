#include<cstdio>
#include<algorithm>
#include<cctype>
#define REP(i, a, b) for(int i = (a); i < (b); i++)
#define _for(i, a, b) for(int i = (a); i <= (b); i++)
#define add(a, b) a = (a + b) % MOD
using namespace std;

const int MAXN = 6000 + 10;
const int MOD = 1e9 + 7;
int dp[MAXN][2], n;
struct node 
{ 
	int x, y; 
	bool operator < (const node& rhs) const
	{
		return y > rhs.y;
	}
}a[MAXN];

inline void read(int& x)
{
	int f = 1; x = 0; char ch = getchar();
	while(!isdigit(ch)) { if(ch == '-') f = -1; ch = getchar(); }
	while(isdigit(ch)) { x = x * 10 + ch - '0'; ch = getchar(); }
	x *= f;
}                                                                                                          

int main()
{
	//freopen("refract.in", "r", stdin);
	//freopen("refract.out", "w", stdout);
	
	read(n);
	REP(i, 0, n) read(a[i].x), read(a[i].y);
	sort(a, a + n);
	
	int ans = MOD - n;
	REP(i, 0, n) dp[i][0] = dp[i][1] = 1;
	REP(i, 0, n)
	{
		REP(j, 0, i)
		{
			if(a[j].x < a[i].x) add(dp[i][0], dp[j][1]);
			else add(dp[i][1], dp[j][0]);
		}
		add(ans, dp[i][0] + dp[i][1]);
	}
	printf("%d\n", ans);

	return 0;
}
