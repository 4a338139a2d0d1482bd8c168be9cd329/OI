#include<cstdio>
#include<algorithm>
#include<cctype>
#define REP(i, a, b) for(int i = (a); i < (b); i++)
#define _for(i, a, b) for(int i = (a); i <= (b); i++)
using namespace std;

const int MAXN = 1e5;
int a[MAXN], n, m, maxa;
int d[MAXN][20];

void read(int& x)
{
	int f = 1; x = 0; char ch = getchar();
	while(!isdigit(ch)) { if(ch == '-') f = -1; ch = getchar(); }
	while(isdigit(ch)) { x = x * 10 + ch - '0'; ch = getchar(); }
	x *= f;
}

int ans(int l, int r, int k)
{
	int res = 0;
	_for(i, l, r) res = max(res, a[i] % k);
	return res;
}

void RMQ_init()
{
	_for(i, 1, n) d[i][0] = a[i];
	for(int j = 1; (1 << j) <= n; j++)
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
			d[i][j] = max(d[i][j-1], d[i + (1 << (j-1))][j-1]);
}

int RMQ_ans(int l, int r)
{
	int k = 0;
	while((1 << (k + 1)) <= r - l + 1) k++;
	return max(d[l][k], d[r - (1 << k) + 1][k]);
}

int main()
{
	freopen("flower.in", "r", stdin);
	freopen("flower.out", "w", stdout);	
	
	read(n); read(m);
	_for(i, 1, n) read(a[i]), maxa = max(maxa, a[i]);
	RMQ_init();
	while(m--)
	{
		int l, r, k;
		read(l); read(r); read(k);
		if(k > maxa) printf("%d\n", RMQ_ans(l, r));
		else printf("%d\n", ans(l, r, k));
	}
	return 0;
}
