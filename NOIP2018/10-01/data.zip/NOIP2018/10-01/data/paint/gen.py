import os
from random import *

cs = [9, 12, 9, 18]
nl = [3, 1, 20, 30]
nr = [3, 1, 30, 50]
ml = [4, 30, 20, 30]
mr = [5, 50, 30, 50]

tot = 0
for i in range(4):
    os.system("mkdir subtask%d" % (i + 1))

    for j in range(cs[i]):
        n = randint(nl[i], nr[i]);
        m = randint(ml[i], mr[i]);

        outp = "%d %d\n" % (n, m)
        for x in range(n):
            for y in range(m):
                if(j % 3 == 0):
                    outp += "%d" % (randint(0, 1))
                if(j % 3 == 1):
                    outp += "%d" % ((y+x) % 2)
                if(j % 3 == 2):
                    if(x % 2 == 0):
                        outp += "%d" % (randint(0, 1))
                    if(x % 2 == 1):
                        outp += "%d" % ((y+x) % 2)

            outp += "\n"

        fname = "./subtask%d/paint%d" % (i + 1, j + 1) 

        print(outp, file = open("%s.in" % (fname), "w"))
        os.system("./paint < %s.in > %s.out" % (fname, fname))

