import os
from random import *

cs = [2, 2, 2, 4]
nl = [2500, 40000, 80000, 80000]
nr = [4000, 50000, 100000, 100000]
ar = [40000, 100000, 200, 100000]

tot = 0
for i in range(4):
    for j in range(cs[i]):
        n = randint(nl[i], nr[i]);
        q = randint(nl[i], nr[i]);

        outp = "%d %d\n" % (n, q)
        for x in range(n): 
            outp += "%d " % (randint(1, ar[i]))
        outp += "\n"

        for x in range(q):
            l = randint(1, n)
            r = randint(l, n)
            outp += "%d %d %d\n" % (l, r, randint(1, ar[i] + 1))

        fname = "flower%d" % (tot)
        tot = tot + 1

        print(outp, file = open("%s.in" % (fname), "w"))
        os.system("./flower < %s.in > %s.out" % (fname, fname))
