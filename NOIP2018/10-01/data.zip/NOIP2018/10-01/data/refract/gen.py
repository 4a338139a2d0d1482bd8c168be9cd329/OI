import sys, os
from random import *

cs = [1, 1, 3, 5]
nl = [500, 800, 3200, 5000]
nr = [700, 1000, 4000, 6000]

tot = 0
for i in range(4):
    for j in range(0, cs[i]):
        n = randint(nl[i], nr[i])

        a = []
        b = []
        suma = 0
        sumb = 0
        outp = "%d\n" % n

        if(i <= 1):
            a = [k for k in range(1, n+1)]
            b = [k for k in range(1, n+1)]
        else:
            step = 2000000000 // n
            a = [0 for k in range(n)]
            b = [0 for k in range(n)]

            for k in range(1, n):
                a[k] = a[k-1] + randint(1, step)
                b[k] = b[k-1] + randint(1, step)

            suma = a[n-1]
            sumb = b[n-1]

        shuffle(a)
        shuffle(b)

        for k in range(n): 
            outp += "%d %d\n" % (a[k] - suma//2, b[k] - sumb//2)

        fname = "./refract%d" % (tot)
        print (outp, file = open("%s.in" % (fname), "w"))
        os.system("./refract < %s.in > %s.out" % (fname, fname)) 

        tot = tot + 1
