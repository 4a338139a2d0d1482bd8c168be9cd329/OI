#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 100000 + 10;
const int M = 1000000007;
const double PI = atan(1) * 4;
const int oo = 1000000000;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
#define pb push_back 
#define all(c) (c).begin(),(c).end()
int n,m,k,v[2*N],is[2*N];
vector<ii> both;
multiset<int> st1, st2;
int main(){
	#ifndef ONLINE_JUDGE
		freopen("input.txt", "r", stdin);
	#endif
	cin>>n>>m>>k;
	for(int i=0; i<n; ++i)
		scanf("%d",&v[i]);
	int a,b;
	cin>>a;
	for(int x,i=0; i<a; ++i){
		scanf("%d",&x);
		--x;
		st1.insert(v[x]);
		is[x]=true;
	}
	cin>>b;
	for(int x,i=0; i<b; ++i){
		scanf("%d",&x);
		--x;
		st2.insert(v[x]);
		if(is[x])
			both.pb(ii(v[x],x));
	}
	ll ans=0;
	int sz=0;
	sort(all(both));
	int dd=max(0,2*k-m);
	for(int i=0; dd && i<both.size(); ++i){
		ans+=both[i].first;
		st1.erase(st1.find(both[i].first));
		st2.erase(st2.find(both[i].first));
		--dd;
		--k;
		++sz;
	}
	if(dd || st1.size()<k || st2.size()<k)return cout<<-1,0;
	multiset<int>::iterator it;
	int k1=k;
	for(it=st1.begin(); k1; ){
		ans+=*it;
		++it;
		st1.erase(st1.begin());
		--k1;
		++sz;
	}
	for(it=st2.begin(); k;){
		ans+=*it;
		++it;
		st2.erase(st2.begin());
		--k;
		++sz;
	}
	while(sz<m && (!st1.empty() || !st2.empty())){
		int mn=2*oo;
		++sz;
		if(st1.empty()){
			ans+=*st2.begin();
			st2.erase(st2.begin());
			continue;
		}
		if(st2.empty()){
			ans+=*st1.begin();
			st1.erase(st1.begin());
			continue;
		}
		if(*st1.begin()<*st2.begin()){
			ans+=*st1.begin();
			st1.erase(st1.begin());
		}else{
			ans+=*st2.begin();
			st2.erase(st2.begin());

		}
	}
	if(sz<m)cout<<-1;
	else cout<<ans<<endl;
}
