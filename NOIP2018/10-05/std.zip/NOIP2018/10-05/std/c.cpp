#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <cmath>
#include <ctime>
#include <string>
#include <cstring>
#include <complex>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
#define mp make_pair

const int N = 402;
const int M = 100010;
int ed[M][2];
bool used[N][N];
bool bad[N];
int n, m;

int main()
{
	//    freopen("input.txt", "r", stdin);
	//    freopen("output.txt", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i = 0; i < m; i++) {
		scanf("%d%d", &ed[i][0], &ed[i][1]);
		ed[i][0]--;
		ed[i][1]--;
	}
	for (int i = 0; i < n; i++)
		used[i][i] = 1;
	for (int id = m - 1; id >= 0; id--) {
		for (int v = 0; v < n; v++) {
			bad[v] |= used[v][ed[id][0]] && used[v][ed[id][1]];
			used[v][ed[id][0]] |= used[v][ed[id][1]];
			used[v][ed[id][1]] |= used[v][ed[id][0]];
		}
	}
	int ans = 0;
	for (int v = 0; v < n; v++)
		for (int u = v + 1; u < n; u++) {
			bool ok = !bad[v] && !bad[u];
			for (int i = 0; i < n; i++)
				ok &= !(used[v][i] && used[u][i]);
			ans += (int)ok;
		}
	printf("%d\n", ans);

	return 0;
}
