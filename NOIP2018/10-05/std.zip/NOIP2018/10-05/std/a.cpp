#include<cstdio>
#include<algorithm>
#define N 600010
#define ll long long
#define inf (mxd+1)
using namespace std;

struct Node{
  int l,r;
  int t1,t2,t3;
  int l0,l1;
}t[N<<2];

struct Inter{
  int q;
  ll l,r;
  void print(){
    printf("%lld %lld\n",l,r);
  }
}a[N];

int n,mxd;
ll tmp[N];

void pushup(int rt){
  t[rt].l0=min(t[rt<<1].l0,t[rt<<1|1].l0);
  t[rt].l1=min(t[rt<<1].l1,t[rt<<1|1].l1);
}

void cover0(int rt){
  t[rt].t1=t[rt].t2=t[rt].t3=0;
  t[rt].t1=1;
  t[rt].l0=t[rt].l;t[rt].l1=inf;
}

void cover1(int rt){
  t[rt].t1=t[rt].t2=t[rt].t3=0;
  t[rt].t2=1;
  t[rt].l1=t[rt].l;t[rt].l0=inf;
}

void rever(int rt){
  t[rt].t1=t[rt].t2=t[rt].t3=0;
  t[rt].t3=1;
  swap(t[rt].l0,t[rt].l1);
}

void pushdown(int rt){
  if(t[rt].t1){
    t[rt].t1=0;
    cover0(rt<<1);
    cover0(rt<<1|1);
  }
  if(t[rt].t2){
    t[rt].t2=0;
    cover1(rt<<1);
    cover1(rt<<1|1);
  }
  if(t[rt].t3){
    t[rt].t3=0;
    rever(rt<<1);
    rever(rt<<1|1);
  }
}

void build(int rt,int l,int r){
  t[rt].l=l;t[rt].r=r;
  t[rt].l0=l;t[rt].l1=inf;
  if(l==r) return;
  int mid=(l+r)>>1;
  build(rt<<1,l,mid);
  build(rt<<1|1,mid+1,r);
  pushup(rt);
}

void cover0(int rt,int l,int r){
  if(t[rt].l!=t[rt].r) pushdown(rt);
  if(l<=t[rt].l&&t[rt].r<=r){
    cover0(rt);
    return;
  }
  int mid=(t[rt].l+t[rt].r)>>1;
  if(l<=mid) cover0(rt<<1,l,r);
  if(mid<r) cover0(rt<<1|1,l,r);
  pushup(rt);
}

void cover1(int rt,int l,int r){
  if(t[rt].l!=t[rt].r) pushdown(rt);
  if(l<=t[rt].l&&t[rt].r<=r){
    cover1(rt);
    return;
  }
  int mid=(t[rt].l+t[rt].r)>>1;
  if(l<=mid) cover1(rt<<1,l,r);
  if(mid<r) cover1(rt<<1|1,l,r);
  pushup(rt);
}

void rever(int rt,int l,int r){
  if(t[rt].l!=t[rt].r) pushdown(rt);
  if(l<=t[rt].l&&t[rt].r<=r){
    rever(rt);
    return;
  }
  int mid=(t[rt].l+t[rt].r)>>1;
  if(l<=mid) rever(rt<<1,l,r);
  if(mid<r) rever(rt<<1|1,l,r);
  pushup(rt);
}

int main(){
  scanf("%d",&n);
  for(int i=1;i<=n;i++) scanf("%d%I64d%I64d",&a[i].q,&a[i].l,&a[i].r);
  for(int i=1;i<=n;i++){
    tmp[++mxd]=a[i].l;
    tmp[++mxd]=a[i].l+1;
    tmp[++mxd]=a[i].r;
    tmp[++mxd]=a[i].r+1;
  }
  tmp[++mxd]=1;
  sort(tmp+1,tmp+1+mxd);
  mxd=unique(tmp+1,tmp+1+mxd)-tmp-1;
  for(int i=1;i<=n;i++){
    a[i].l=lower_bound(tmp+1,tmp+1+mxd,a[i].l)-tmp;
    a[i].r=lower_bound(tmp+1,tmp+1+mxd,a[i].r)-tmp;
  }
  build(1,1,mxd);
  for(int i=1;i<=n;i++){
    if(a[i].q==1){
      cover1(1,a[i].l,a[i].r);
    }
    if(a[i].q==2){
      cover0(1,a[i].l,a[i].r);
    }
    if(a[i].q==3){
      rever(1,a[i].l,a[i].r);
    }
    ll l=tmp[t[1].l0];
    printf("%I64d\n",l);
  }
  return 0;
}
