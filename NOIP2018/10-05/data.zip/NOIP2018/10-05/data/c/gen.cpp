#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

int rd(int l,int r)
{
	return rand()%(r-l+1)+l;
}

FILE* seed;

const int N=404;

struct dus
{
	int q[N];
	void init(int n){for(int i=1;i<=n;i++)q[i]=i;}
	int ask(int p){return p==q[p]?p:q[p]=ask(q[p]);}
	bool link(int u,int v)
	{
		u=ask(u),v=ask(v);
		if(u==v)return 0;
		q[u]=v;
		return 1;
	}
}d;

int n,m;

int main()
{
	if(!fopen("seed","r"))
	{
		seed=fopen("seed","w");
		fprintf(seed,"2333\n");
		fclose(seed);
	}
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("c.in","w",stdout);//look at here

	n=400,m=n-1;

	printf("%d %d\n",n,m);
	d.init(n);
	while(m--)
	{
		int u,v;
		while(!d.link(u=rd(1,n),v=rd(1,n)));
		printf("%d %d\n",u,v);
	}
	return 0;



	n=400,m=50000;

//	n=m=400;

	printf("%d %d\n",n,m);

	int div=n/2,lim=std::max(0,m-100);

	for(int i=1;i<=lim;i++)
	{
		int u=rd(1,div),v=rd(1,div-1);
		v+=(v>=u);
		printf("%d %d\n",u,v);
	}
	for(int i=lim+1;i<=m;i++)
	{
		int u=rd(1,n),v=rd(1,n-1);
		v+=(v>=u);
		printf("%d %d\n",u,v);
	}

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
