#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

typedef long long ll;

const int N=201000;

struct node
{
	bool a,b;
	int val;
	bool operator < (const node &A)const {return val<A.val;}
};

node s[N];
int n,m,k;

int cnta[N],cntb[N],cntab[N];

void initialize()
{
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&s[i].val);
	int tmp;
	scanf("%d",&tmp);
	for(int i=1,x;i<=tmp;i++)
		scanf("%d",&x),s[x].a=1;
	scanf("%d",&tmp);
	for(int i=1,x;i<=tmp;i++)
		scanf("%d",&x),s[x].b=1;
	std::sort(s+1,s+n+1);

	for(int i=n;i;i--)
	{
		cnta[i]=cnta[i+1]+(s[i].a==1 && s[i].b==0);
		cntb[i]=cntb[i+1]+(s[i].a==0 && s[i].b==1);
		cntab[i]=cntab[i+1]+(s[i].a==1 && s[i].b==1);
	}
}

bool check(int pos,int res,int a,int b)
{
	int tmp=std::min(cntab[pos],res),fa=tmp,fb=tmp;
	res-=tmp;

	if(a>fa)
	{
		int d=a-fa;
		if(d>cnta[pos])return 0;
		res-=d;
	}
	if(b>fb)
	{
		int d=b-fa;
		if(d>cntb[pos])return 0;
		res-=d;
	}
	return res>=0;
}

ll getans()
{
	ll ret=0;
	int a=k,b=k,res=m;

	if(!check(1,res,a,b))return -1;

	for(int i=1;i<=n && res>0;i++)
	{
		a-=s[i].a,b-=s[i].b,res--;
		if(check(i+1,res,a,b))
		{
			ret+=s[i].val;
			continue;
		}
		a+=s[i].a,b+=s[i].b,res++;
	}

	return ret;
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.err","w",stdout);

	initialize();
	std::cout<<getans()<<'\n';
	return 0;
}
