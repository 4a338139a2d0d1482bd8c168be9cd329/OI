#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>

char cmd[300];

int main(int argc,char* argv[])
{
	if(argc!=4){printf("error\n");return 0;}

	int l,r;
	sscanf(argv[2],"%d",&l);
	sscanf(argv[3],"%d",&r);

	for(int i=l;i<=r;i++)
	{
		printf("work on %d\n",i);

//		sprintf(cmd,"./gen"),system(cmd);
//		sprintf(cmd,"./%s",argv[1]),system(cmd);

		sprintf(cmd,"./work.sh"),system(cmd);

		sprintf(cmd,"mv ./%s.in ./%s%d.in",argv[1],argv[1],i),system(cmd);
		sprintf(cmd,"mv ./%s.out ./%s%d.ans",argv[1],argv[1],i),system(cmd);
	}

	return 0;
}
