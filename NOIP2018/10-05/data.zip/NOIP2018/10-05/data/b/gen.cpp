#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<algorithm>

int rd(int l,int r)
{
	return rand()%(r-l+1)+l;
}

FILE* seed;

const int N=101000;

bool fucked[N];

int n,m,k;

void proc()
{
	static int s[N];
	int tot=rd(n/4,n*3/4);

	for(int i=1;i<=tot;i++)s[i]=rd(1,n);

	std::sort(s+1,s+tot+1);
	tot=std::unique(s+1,s+tot+1)-s-1;

	printf("%d\n",tot);
	for(int i=1;i<=tot;i++)
		printf("%d ",s[i]);
	printf("\n");
}

int main()
{
	if(!fopen("seed","r"))
	{
		seed=fopen("seed","w");
		fprintf(seed,"2333\n");
		fclose(seed);
	}
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("b.in","w",stdout);//look at here

	n=100000,m=rd(1,n),k=rd(1,m);

	printf("%d %d %d\n",n,m,k);

	for(int i=1;i<=n;i++)
		printf("%d ",rd(1,1e9));
	printf("\n");

	proc(),proc();

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
