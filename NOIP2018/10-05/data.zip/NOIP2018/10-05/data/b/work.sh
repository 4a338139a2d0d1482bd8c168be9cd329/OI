while $ture ; do 
	./gen
	./fake
	./b
	if diff ./b.out ./b.err ; then echo fuck;
	else echo find ; exit 1 ; fi
done
