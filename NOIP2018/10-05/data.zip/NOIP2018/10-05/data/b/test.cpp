#include<bits/stdc++.h>

int main()
{
	system("./work.sh");

	return 0;
}
