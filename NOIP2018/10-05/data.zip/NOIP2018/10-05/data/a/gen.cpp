#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

typedef long long ll;

int rd(int l,int r)
{
	return rand()%(r-l+1)+l;
}
ll rdll(ll l,ll r)
{
	ll tmp=(ll)rd(0,1e9-1)*1e9+rd(0,1e9-1);
	return tmp%(r-l+1)+l;
}

FILE* seed;

int main()
{
	if(!fopen("seed","r"))
	{
		seed=fopen("seed","w");
		fprintf(seed,"2333\n");
		fclose(seed);
	}
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("a.in","w",stdout);//look at here

	ll n;
	int m;

	n=1000,m=1000;

	n=1e18,m=1e5;

//	n=1e5;

	printf("%d\n",m);

	while(m--)
	{
		int ty;
		ll l,r;

		if(rand()%10==0)l=1;
		else l=rdll(1,n);
		r=rdll(l,n),ty=rdll(1,3);

//		l=rdll(1,n),r=rdll(l,r),ty=1;

		printf("%d %lld %lld\n",ty,l,r);
	}

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
