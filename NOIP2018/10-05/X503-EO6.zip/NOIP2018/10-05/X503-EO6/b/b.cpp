#include<bits/stdc++.h>
#define neko 200010
#define orz return printf("-1\n"),0
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
using namespace std;
int a[neko],b[neko],s[neko],opt[neko],book[neko],n,m,k,A,B;
typedef long long ll;
ll ans=1e18;
bool cmp(const int &x,const int &y)
{return s[x]>s[y];}
struct node
{
	int x,id;
	bool operator <(const node &a)const
	{return x>a.x;}
};
priority_queue<node>q[4];
ll cmin(ll a,ll b){return a<b?a:b;}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	int x,y,z,nowx=0,nowy=0,now=0;
	scanf("%d%d%d",&n,&m,&k);
	if(n>20)
	{
		node u;
		f(i,1,n)scanf("%d",&s[i]);s[0]=0x3f3f3f3f;
		scanf("%d",&A);
		f(i,1,A)scanf("%d",&x),opt[x]|=1;
		scanf("%d",&B);
		f(i,1,B)scanf("%d",&x),opt[x]|=2;
		if(k+k>m)orz;
		f(i,1,n)if(opt[i])q[opt[i]].push((node){s[i],i});
		f(i,1,k){if(q[1].empty())orz;ans+=(u=q[1].top()).x,book[u.id]=1,q[1].pop();}
		f(i,1,k){if(q[2].empty())orz;ans+=(u=q[2].top()).x,book[u.id]=1,q[2].pop();}
		if(k+k<m)
		{
			f(i,1,n)q[0].push((node){s[i],i});
			while(!q[0].empty())
			{
				u=q[0].top(),q[0].pop();
				if(!book[u.id])ans+=u.x,--m;
				if(k+k==m)break;
			}
		}
		if(k+k<m)orz;
		return printf("%lld\n",ans),0;
	}
	else
	{
		int maxbit=(1<<n)-1;
		long long res=0;
		f(i,1,n)scanf("%d",&s[i]);s[0]=0x3f3f3f3f;
		scanf("%d",&A);
		f(i,1,A)scanf("%d",&x),opt[x]|=1;
		scanf("%d",&B);
		f(i,1,B)scanf("%d",&x),opt[x]|=2;
		f(S,0,maxbit)
		{
			now=nowx=nowy=0,res=0;
			f(i,0,n-1)if(S&(1<<i))
			{
				++now;
				if(opt[i+1]&1)++nowx;
				if(opt[i+1]&2)++nowy;
				res+=s[i+1];
			}
			if(now^m)continue;
			if(nowx<k||nowy<k)continue;
			ans=cmin(ans,res);
		}return printf("%lld\n",ans),0;
	}
}
