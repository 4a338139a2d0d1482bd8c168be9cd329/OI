#include<bits/stdc++.h>
#define neko 100010
#define feko 400010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
using std::bitset;
int m,L[neko*140],R[neko*140],rt[11];
typedef bitset<neko*140> arr;
arr One,Zro,Xor,Czo,Czz;
typedef long long ll;
namespace IO
{
	const unsigned int bufsize=1<<16,outsize=1<<22;
	static char ch[bufsize],*S=ch,*T=ch;
	inline char getc()
	{return ((S==T)&&(T=(S=ch)+fread(ch,1,bufsize,stdin),S==T)?0:*S++);}
	static char Out[outsize],*nowp=Out;
	inline void flush(){fwrite(Out,1,nowp-Out,stdout);nowp=Out;}
	template<typename T>
		void read(T &x)
		{
			char c=getc();x=0;
			for(;!isdigit(c);c=getc());
			for(;isdigit(c);x=(x<<1)+(x<<3)+(c^'0'),c=getc());
		}
	template<typename T>
		void write(T x,char c='\n')
		{
			if(!x)*nowp++='0';
			static unsigned int stk[50],tp=0;
			for(;x;x/=10)stk[++tp]=x%10;
			for(;tp;*nowp++=stk[tp--]^'0');*nowp++=c;
		}
}
namespace Seg_Tree
{
	#define ori tagl,tagr
	#define lson L[root],l,mid
	#define rson R[root],mid+1,r
	int cnt=0;
	void pushup(int root)
	{
		Czo[root]=Czo[L[root]]|Czo[R[root]];
		Czz[root]=Czz[L[root]]|Czz[R[root]];
	}
	void pushdown(int root)
	{
		if(!L[root])L[root]=++cnt;
		if(!R[root])R[root]=++cnt;
		//std::cerr<<cnt<<std::endl;
		int l=L[root],r=R[root];
		if(One[root])
		{
			One[l]=One[r]=1;
			Czo[l]=Czo[r]=1;
			Xor[l]=Xor[r]=Zro[l]=Zro[r]=Czz[l]=Czz[r]=0;
			One[root]=0;
		}
		if(Zro[root])
		{
			Zro[l]=Zro[r]=1;
			Czz[l]=Czz[r]=1;
			Xor[l]=Xor[r]=One[l]=One[r]=Czo[l]=Czo[r]=0;
			Zro[root]=0;
		}
		if(Xor[root])
		{
			if(!Czo[l])Czo[l]=1,Czz[l]=0;
			else if(!Czz[l])Czo[l]=0,Czz[l]=1;
			if(!Czo[r])Czo[r]=1,Czz[r]=0;
			else if(!Czz[r])Czo[r]=0,Czz[r]=1;
			Xor.flip(l),Xor.flip(r);
			Xor[root]=0;
		}
	}
	void real(int &root,ll l,ll r,ll tagl,ll tagr)
	{
		//printf("real: %d %d %d %d %d\n",root,l,r,tagl,tagr);
		if(!root)root=++cnt;
		if(l>=tagl&&r<=tagr){One[root]=1,Xor[root]=Zro[root]=0,Czo[root]=1,Czz[root]=0;return;}
		pushdown(root);
		ll mid=(l+r)>>1;
		if(tagl<=mid)real(lson,ori);
		if(tagr>mid)real(rson,ori);
		pushup(root);
	}
	void virt(int &root,ll l,ll r,ll tagl,ll tagr)
	{
		//printf("virt: %d %d %d %d %d %d\n",root,l,r,tagl,tagr,One[root]);
		if(!root)root=++cnt;
		if(l>=tagl&&r<=tagr){Zro[root]=1,Xor[root]=One[root]=0,Czo[root]=0,Czz[root]=1;return;}
		pushdown(root);
		ll mid=(l+r)>>1;
		if(tagl<=mid)virt(lson,ori);
		if(tagr>mid)virt(rson,ori);
		pushup(root);
	}
	void update(int &root,ll l,ll r,ll tagl,ll tagr)
	{
		if(!root)root=++cnt;
		if(l>=tagl&&r<=tagr)
		{
			Xor.flip(root);
			if(!Czo[root])Czo[root]=1,Czz[root]=0;
			else if(!Czz[root])Czo[root]=0,Czz[root]=1;
			return;
		}
		pushdown(root);
		ll mid=(l+r)>>1;
		if(tagl<=mid)update(lson,ori);
		if(tagr>mid)update(rson,ori);
		pushup(root);
	}
	int query(int &root,ll l,ll r)
	{
		//printf("%d %d %d %d %d %d\n",root,l,r,Czo[root],Czz[root],One[root]);
		if(!root)root=++cnt;
		if(l==r)return l;
		pushdown(root);
		ll mid=(l+r)>>1;
		if(Czz[L[root]])return query(lson);
		else return query(rson);
	}
}
int main()
{
	using namespace Seg_Tree;
	using namespace IO;
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int opt,x,y;
	read(m);
	ll n=(ll)1e18+5;
	Czz.set();
	f(i,1,m)
	{
		read(opt),read(x),read(y);
		if(opt==1)real(rt[1],1,n,x,y);
		if(opt==2)virt(rt[1],1,n,x,y);
		if(opt==3)update(rt[1],1,n,x,y);
		if(Czz[1])write(query(rt[1],1,n));
		else write(n+1);
		if(i%30000==0)flush();
	}std::cerr<<clock()*1.0/CLOCKS_PER_SEC<<std::endl;
	flush();return 0;
}
