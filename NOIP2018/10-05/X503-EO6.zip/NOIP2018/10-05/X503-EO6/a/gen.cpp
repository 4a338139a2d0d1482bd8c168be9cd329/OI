#include<bits/stdc++.h>
#define feko 400010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
using namespace std;
random_device rd;
int m=100000;
int main()
{
	freopen("a.in","w",stdout);
	long long x,y;
	printf("%d\n",m);
	f(i,1,m)
	{
		x=rd()%10+1,y=(long long)1e18;
		if(x>y)swap(x,y);
		printf("%d %lld %lld\n",rd()%3+1,x,y);
	}return 0;
}
