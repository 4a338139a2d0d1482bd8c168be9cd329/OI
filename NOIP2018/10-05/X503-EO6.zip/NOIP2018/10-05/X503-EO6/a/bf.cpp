#include<bits/stdc++.h>
#define feko 400010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
int a[100010],m;
int main()
{
	freopen("a.in","r",stdin);
	freopen("bf.out","w",stdout);
	int x,y,z;
	scanf("%d",&m);
	f(i,1,m)
	{
		scanf("%d%d%d",&x,&y,&z);
		if(x==1)f(j,y,z)a[j]=1;
		else if(x==2)f(j,y,z)a[j]=0;
		else f(j,y,z)a[j]^=1;
		f(j,1,100001)if(!a[j]){printf("%d\n",j);break;}
	}return 0;
}
