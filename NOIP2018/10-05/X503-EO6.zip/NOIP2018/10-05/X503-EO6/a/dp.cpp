#include<bits/stdc++.h>
#define	N 100010 
#define M 1000010
#define pb push_back
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
#define rf(i,a,b) for(register int i=(a);i>=(b);i=~(-i))
using namespace std;
int main()
{
	f(i,1,100)
	{
		system("./gen");
		system("./bf");
		system("./a");
		if(system("diff bf.out a.out"))return cerr<<"WA"<<endl,0;
	}return cerr<<"AC"<<endl,0;	
}
