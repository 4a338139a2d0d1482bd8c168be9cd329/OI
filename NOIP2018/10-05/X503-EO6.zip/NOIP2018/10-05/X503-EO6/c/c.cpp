#include<cstdio>
#define neko 510
#define meko 100010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
#define rf(i,a,b) for(register int i=(a);i>=(b);i=~(-i))
int n,m,x[meko],y[meko],book[neko],now,ans;
int Must[neko][neko];
bool kill(int u)
{
	Must[u][u]=1;
	rf(i,m,1)
	{
		if(Must[u][x[i]]&&Must[u][y[i]])return 0;
		if(Must[u][x[i]]||Must[u][y[i]])Must[u][x[i]]=Must[u][y[i]]=1;
	}
	return 1;
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%d%d",&n,&m);
	f(i,1,m)scanf("%d%d",&x[i],&y[i]);
	f(i,1,n)book[i]=kill(i);
	f(i,1,n)if(book[i])
		f(j,i+1,n)if(book[j])
		{
			now=1;
			f(k,1,n)if(Must[i][k]&&Must[j][k]){now=0;break;}
			ans+=now;
		}return printf("%d\n",ans),0;
}
