#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=1e9+7;
int gcd(int x,int y){return x==0?y:gcd(y%x,x);}
int a[7005]; long long b[100005];
int main(){
	freopen("gcd.in","r",stdin); freopen("gcd.out","w",stdout);
	int n=read(),x,y,X,Y; long long ans=0;
	if (n>7000){
		For(i,1,n) b[i]=(long long)(n/i)*(n/i);
		for(int i=n;i>=1;--i)
			for(int j=i*2;j<=n;j+=i) b[i]-=b[j];
		For(i,1,n) ans+=b[i]%mo*i%mo*i%mo;
		printf("%d\n",ans%mo); exit(0);
	}
	For(i,1,n) a[i]=read();
	For(i,1,n)
		For(j,1,n){
			x=a[i],y=a[j]; if (x>y) swap(x,y);
			X=i,Y=j; if (X>Y) swap(X,Y);
			ans+=gcd(x,y)*gcd(X,Y);
		}
	printf("%d\n",ans%mo);
	return 0;
}
