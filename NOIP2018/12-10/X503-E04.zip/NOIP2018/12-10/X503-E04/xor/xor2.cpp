#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
typedef unsigned int ui;
ui read(){
	ui x=0; char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x;
}
const int N=3e5+5;
ui a[N],an[N],q[N]; int pr[N],ne[N];
struct node{
	int l,r,bl,id;
}b[N];
bool cmd(node n,node m){
	return (n.bl^m.bl)?n.bl<m.bl:((n.bl^2)?n.r<m.r:n.r>m.r);
}
unordered_map<ui,int> mp;
int main(){
	freopen("xor.in","r",stdin); freopen("xor.out","w",stdout);
	int n=3e5,m,sqn=sqrt(n),x,y; ui ans=0; srand(time(0));
	For(i,1,n) a[i]=rand();
	m=3e5;
	For(i,1,m) x=rand()%n+1,y=rand()%(n-x+1)+x,b[i]=(node){x,y,(x-1)/sqn+1,i};
	sort(b+1,b+1+m,cmd); x=1,y=1,ans=a[1];
	For(i,1,n) pr[i]=mp[a[i]],mp[a[i]]=i; mp.clear();
	for(int i=n;i>=1;--i){
		ne[i]=mp[a[i]],mp[a[i]]=i;
		if (!ne[i]) ne[i]=n+1;
	}
	For(i,1,n) q[i]=q[i-1]^a[i]; cerr<<clock()<<endl;
	For(i,1,m){
		if (b[i].l<x) {for(int j=x-1;j>=b[i].l;--j) if (ne[j]>y) ans^=a[j];}
		else For(j,x,b[i].l-1) if (ne[j]>y) ans^=a[j]; x=b[i].l;
		if (b[i].r<y) {for(int j=y;j>=b[i].r+1;--j) if (pr[j]<x) ans^=a[j];}
		else For(j,y+1,b[i].r) if (pr[j]<x) ans^=a[j]; y=b[i].r;
		an[b[i].id]=q[x-1]^q[y]^ans;
	}
	For(i,1,m) printf("%d\n",an[i]);
	return 0;
}
