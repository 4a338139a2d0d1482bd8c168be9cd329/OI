#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cctype>

using namespace std;
const int maxnum=9999999, maxn=100011;
bool used[maxn]; int a[maxn];
int beg=1, ed=1, found[4*maxn], times[4*maxn];
int n, m, k, s;

inline int read() {
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}

inline void subtask3() {
	int x; for (int i=1; i<=m; i++) 
	    {x=read(); used[x]=true; a[x]=-1;} 
	int qp=-1, pq=0;
	for (int i=1; i<=n; i++)
	    if (i==s) printf("%d ", pq); else printf("%d ", qp);  
	return;
}

inline void subtask4() {
	int lef=0, rig=n+1;
	int x; for (int i=1; i<=m; i++) 
	    {x=read(); used[x]=true; a[x]=-1;} 
	for (int i=1; i<=n; i++) 
		if (a[i]==-1) 
	        if (i<s) lef=i;
			else {rig=i; break;} 
	int qp=-1, pq=0;
	for (int i=1; i<=lef; i++) printf("%d ", qp);
	for (int i=lef+1; i<=rig-1; i++) printf("%d ", abs(s-i));
	for (int i=rig; i<=n; i++) printf("%d ", qp);
	return;
}

void search(int x, int tim) {
    int t=tim+1, now;
	if (k%2==0) {
		now=x-1; int kkl=k/2;
    	while (kkl>0 && now>=1) {
    		if (used[now]==false || t<a[now]) {
    		    a[now]=t; 
				used[now]=true;
				ed++;
				found[ed]=now;
				times[ed]=t;
			}
    		now-=2;
            kkl--;
		}
	    now=x+1; int kkr=k/2;
	    while (kkr>0 && now<=n) {
	    	if (used[now]==false) {
	    	    a[now]=t; 
				used[now]=true;
				ed++;
				found[ed]=now;
				times[ed]=t;
			}
			now+=2;
			kkr--;	
		}  
	}
    else {
    	now=x-2; int kkl=(k-k%2)/2;
    	while (kkl>0 && now>=1) {
    		if (used[now]==false) {
    		    a[now]=t; 
				used[now]=true;
				ed++;
				found[ed]=now;
				times[ed]=t;
			}
    		now-=2;
            kkl--;
		}
	    now=x+2; int kkr=(k-k%2)/2;
	    while (kkr>0 && now<=n) {
	    	if (used[now]==false) {
	    	    a[now]=t; 
				used[now]=true;
				ed++;
				found[ed]=now;
				times[ed]=t;
			}
			now+=2;
			kkr--;	 
		} 
	}
	return;	
} 

int main() {
	freopen("reverse.in", "r", stdin);
	freopen("reverse.out", "w", stdout);
	for (int i=0; i<=maxn-5; i++) a[i]=maxnum;
	memset(used, 0, sizeof(used));
	n=read(), k=read(), m=read(), s=read();
	if (k==1) {subtask3(); return 0;}
	if (k==2) {subtask4(); return 0;}
	int x; for (int i=1; i<=m; i++) 
	    {x=read(); used[x]=true; a[x]=-1;} 
	a[s]=0; used[s]=true; 
	found[1]=s; times[1]=0;
    while (beg<=ed) {search(found[beg], times[beg]); beg++;}
	int p=-1;
	for (int i=1; i<=n; i++) 
	    if (a[i]==maxnum) printf("%d ", p); 
//		else if (a[i]==0 && i!=s) printf("%d ", p);
		else printf("%d ", a[i]); 
	return 0;
}







