#include <iostream>
#include <cstdio>
using namespace std;
typedef long long ll;
inline int read()
{
    int t=0, f=0; char c;
    while(!isdigit(c=getchar())) f|=(c=='-');
    do t=(t<<3)+(t<<1)+c-'0';
    while(isdigit(c=getchar()));
    return f? -t:t;
}
int main()
{
	freopen("seat.in", "r", stdin);
	freopen("seat.out", "w", stdout);
	
	int n=read(), p=read();
	int inv[10]={0, 1};
	inv[2]=(ll)(p-p/2)*inv[p%2]%p;
	if(n==1) printf("0 1 0");
	else if(n==2) printf("0 %d %d 0", inv[2], inv[2]);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
