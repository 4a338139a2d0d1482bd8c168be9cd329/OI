#include <iostream>
#include <cstdio>
using namespace std;
inline int read()
{
    int t=0, f=0; char c;
    while(!isdigit(c=getchar())) f|=(c=='-');
    do t=(t<<3)+(t<<1)+c-'0';
    while(isdigit(c=getchar()));
    return f? -t:t;
}
const int N=1e5;
int a[N+3], b[N+3];
int main()
{
	freopen("silhouette.in", "r", stdin);
	freopen("silhouette.out", "w", stdout);
	
	int n=read();
	for(int i=1; i<=n; i++) a[i]=read();
	for(int i=1; i<=n; i++) b[i]=read();
	if(n==1)
	{
		if(a[1]==b[1])	printf("1");
		else printf("0");
	} 
	else printf("0");
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
