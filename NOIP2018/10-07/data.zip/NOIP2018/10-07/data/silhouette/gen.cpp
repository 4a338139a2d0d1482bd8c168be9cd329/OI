#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int TASK = 7;
const int mx = 1e9;
const int N[TASK] = {1, 3, 16, 100, 3000, 100000, 100000};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

int A[100010], B[100010];

int main() {

	char cmd[200];
	srand(time(0));

	For(idt, 0, TASK - 1) {

		sprintf(cmd, "mkdir subtask%d", idt + 1);
		system(cmd);
		cerr << "Subtask " << idt + 1 << ":\n";

		For(idc, 0, 3) {

			if (idt == 5 && idc != 2) continue;
			if (idt <= 1 && idc > 1) continue;
			if (idt < 4 && idc > 2) continue;

			sprintf(cmd, "subtask%d/silhouette%d.in", idt + 1, idc + 1);
			freopen(cmd, "w", stdout);

			int n = N[idt];
			if (idc) n -= randint(0, min(10, n / 10));

			if (!idc) {
				int y = idt == 1 ? 3 : randint(mx / 2, mx);
				For(i, 1, n) A[i] = y, B[i] = y;
			} else if (idc == 1 || idc == 3) {
				int pa = 0, pb = 0;
				while (pa < n || pb < n) {
					int ta = randint(0, n - pa), tb = randint(0, n - pb), y = idt == 1 ? randint(1, 4) : randint(1, mx);
					For(i, pa + 1, pa + ta) A[i] = y;
					For(i, pb + 1, pb + tb) B[i] = y;
					pa += ta, pb += tb;
				}
			} else {
				For(i, 1, n) A[i] = i, B[i] = i;
			}

			printf("%d\n", n);

			sort(A + 1, A + n + 1), sort(B + 1, B + n + 1);
			if (idt) A[n] = B[n] = max(A[n], B[n]);

			random_shuffle(A + 1, A + n + 1);
			random_shuffle(B + 1, B + n + 1);
			For(i, 1, n) printf("%d%c", A[i], i == n ? '\n' : ' ');
			For(i, 1, n) printf("%d%c", B[i], i == n ? '\n' : ' ');

			freopen("CON", "w", stdout);
			cerr << "Case " << idc + 1 << ":\n";
			sprintf(cmd, "time ./silhouette < subtask%d/silhouette%d.in > subtask%d/silhouette%d.out", idt + 1, idc + 1, idt + 1, idc + 1);
			system(cmd);
		}
		

	}

	return 0;
}
