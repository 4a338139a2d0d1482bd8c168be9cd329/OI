#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N[25] = {1, 2, 9, 10, 16, 20, 29, 32, 46, 48, 58, 62, 78, 99, 127, 204, 233, 256, 296, 300, 511, 1023, 914, 1007, 995};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

int A[100010], B[100010];
bool vis[100010];
int prm[100010], c;

int main() {

	char cmd[200];
	srand(time(0));

	For(i, 2, 30000) if (!vis[i]) {
		if (i > 2000) prm[++c] = i;
		for (int j = i; j <= 30000; j += i) vis[j] = true;
	}

	For(idc, 0, 24) {

		sprintf(cmd, "seat%d.in", idc + 1);
		freopen(cmd, "w", stdout);

		printf("%d %d\n", N[idc], prm[randint(1, c)]);

		freopen("CON", "w", stdout);
		cerr << "Case " << idc + 1 << ":\n";
		sprintf(cmd, "time ./seat < seat%d.in > seat%d.out", idc + 1, idc + 1);
		system(cmd);

	}

	return 0;
}
