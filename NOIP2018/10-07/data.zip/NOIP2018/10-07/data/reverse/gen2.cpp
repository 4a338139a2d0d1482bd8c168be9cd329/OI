#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int TASK = 5;
const int N[TASK] = {10, 1000, 100000, 100000, 100000};

int randint(int L, int R) {
	return rand() % (R - L + 1) + L;
}

int main() {

	char cmd[200];
	srand(time(0));
	int id = 0;

	For(idt, 0, TASK - 1) {
		
		sprintf(cmd, "mkdir subtask%d", idt + 1);
		system(cmd);
		cerr << "Subtask " << idt + 1 << ":\n";

		For(idc, 0, 5) {

			if ((idt == 0 || idt == 2 || idt == 3) && idc % 3) continue;
			if (idt == 1 && idc % 3 == 2) continue;

			sprintf(cmd, "reverse%d.in", ++id);
			freopen(cmd, "w", stdout);

			int n = N[idt];
			if (idc) n -= randint(0, min(10, n / 10));
			int K = idt == 2 || idt == 3 ? idt - 1 : -1;
			if (K == -1) {
				if (idc % 3 == 0) K = randint(n - 9, n - 2);
				else if (idc % 3 == 1) K = randint(5, 10);
				else K = randint(n / 5, n / 3);
			}

			int S = idc > 2 ? randint(1, n / 5) : randint(1, n), m = idc > 2 ? randint(0, n / 40) : randint(0, n / 3);

			printf("%d %d %d %d\n", n, K, m, S);
			For(i, 1, m) {
				int x = randint(1, n - 1);
				if (x >= S) ++x;
				printf("%d%c", x, i == m ? '\n' : ' ');
			}

			freopen("CON", "w", stdout);
			cerr << "Case " << idc + 1 << ":\n";
			sprintf(cmd, "time ./reverse < reverse%d.in > reverse%d.out", id, id);
			system(cmd);
		}
		

	}

	return 0;
}
