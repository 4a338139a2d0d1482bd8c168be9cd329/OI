#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
template<class T>
inline void read(T &a)
{
	int s = 0,w = 1;
	char c = getchar();
	while(c < '0' || c > '9')
    {
		if(c == '-') w = -1;
		c = getchar();
    }
	while(c >= '0' && c <= '9')
	{
		s = (s << 1) +  (s << 3) + (c ^ 48);
		c = getchar();
    }
	a = s*w;
}
template<class T>
inline void write(T a)
{
	if(a < 0)
	{
		putchar('-');
		a = -a;
	}
	if(a >= 10)
	{
		write(a / 10);
	}
	putchar(a % 10 + '0');
}
int n,m,k;
int dis[maxn];
int vis[maxn];
int pd[maxn];
int S;
inline void init()
{
//	memset(dis,0x3f,sizeof(dis));
	read(n); read(k);  read(m); read(S);
	for (int i = 1; i <= m; i++)
	{
		int x;
		read(x);
		vis[x] = 1;
    }
	if(k == 1)
	{
		for (int i = 1; i <= n; i++)
		{
			if(S != i) printf("-1 ");
			  else printf("%d ",0);
		}
		exit(0);
	}
}
#define pi pair<int,int> 
#define mp make_pair
inline void dijiskra()
{
	memset(dis,0x3f,sizeof(dis));
	dis[S] = 0;
//	priority_queue<pi ,vector<pi> ,greater<pi> > q;
    queue<int> q;
	q.push(S);
	vis[S] = 1;
	while(!q.empty())
	{
		int u = q.front();
	//    pi u = q.top();
		q.pop();
//		vis[u.second] = 1;
		for (int i = max(1, u-k+1); i <= min(n-k+1, u) ; i++)	
		{
			int d = i + k - 1 - u;
			int v = i + d;
			if (vis[v] == 0) 
			{
				vis[v]  = 1;
				dis[v] = dis[u]+1;
				q.push(v);
			}
		}
	}
}
inline void out()
{
	for (int i = 1; i <= n; i++)
    {
		if(dis[i] == 0x3f3f3f3f) write(-1);
		else write(dis[i]);
		putchar(' ');
	}
}
int main()
{ 
	freopen("reverse.in","r",stdin);
	freopen("reverse.out","w",stdout);
	init();

	dijiskra();
   
	out();
	return 0;
}
