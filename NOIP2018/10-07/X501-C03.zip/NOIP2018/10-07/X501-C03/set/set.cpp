#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("set.in","r",stdin);
	freopen("set.out","w",stdout);
	printf("1");
	return 0;
}
