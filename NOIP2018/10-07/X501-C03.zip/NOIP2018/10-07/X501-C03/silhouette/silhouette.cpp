#include <bits/stdc++.h>
using namespace std;
template<class T>
inline void read(T &a)
{
	T s = 0, w = 1;
	char c = getchar();
	while(c < '0' || c > '9')
	{
		if(c == '-') w = -1;
		c = getchar();
	}
    while(c >= '0' && c <= '9')
	{
		s = (s << 1) +(s << 3) + (c ^ 48);
		c = getchar();
	}
	a = s*w;
}
int n;
int maxx = 0;
int zhen[1001], le[10011];
int s[101011];
int ans = 0;
int pd()
{
	for (int i = 1; i <= n; i++)
	{
		if(zhen[i] != s[i]) return 0;
	}
	for (int i = 1; i <= n; i++)
	{
		if(le[i] != s[(i - 1) * n + i]) return 0;
	}
	return 1;
}
void dfs(int x)
{
	if(x == n*n + 1)
	{
	   ans += pd();
	   return;
	}
	for (int i = 0; i <= maxx; i++)
	{
		s[x] = i;
		dfs(x);
	}
}
int main()
{
	freopen("silhouette.in","r",stdin);
	freopen("silhouette.out","w",stdout);
	read(n);
	for (int i =1; i <= n; i++)
	{
        read(zhen[i]);
		maxx = max(zhen[i],maxx);
	}
	for (int j = 1; j <= n; j++)
	{
		read(le[j]);
		maxx = max(le[j],maxx);
	}
	if(n == 1)
	{
		if(zhen[1] == 1 && le[1] == 1) printf("1");
		else printf("0");
		return 0;
	}
	dfs(1);
	printf("%d",ans);
	return 0;
}
