#include <bits/stdc++.h>
using namespace std;
long long n,m,x,match=1;
int main()
{
	freopen("fire.in","r",stdin);
	freopen("fire.out","w",stdout);
	int sum;
	cin>>n>>m>>x;
	sum=60*n;
	for(int i=m-1;i>0;i--)
	{
		sum-=x;
		if(sum>=0)
			match++;
		else break;
	}
	if(match<=10)
		cout<<"So cold!";
	if(match>10 && match<=100)
		cout<<"Start being hotter.";
	if(match>100 && match<=1000)
		cout<<"It's warm!";
	if(match>1000 && match<=10000)
		cout<<"So hot!";
	if(match>10000)
		cout<<"The room is fired.";
	return 0;
}
