#include <bits/stdc++.h>
using namespace std;
int n,m,p,a,b,x,y,z,q,opt[1010],ans;
int f[1010][1010];
int main()
{
	int c,d;
	cin>>n>>m>>p;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			cin>>f[i][j];
			if(f[i][j]==5)
			{
				c=i;
				d=j;
			}
		}
	cin>>a>>b>>x>>y>>z>>q;
	for(int t=1;t<=q;t++)
		cin>>opt[t];
	for(int t=1;t<=q;t++)
	{
		if(f[c][d]==4 || a<0 || b<0 || c<1 || c>n || d<1 || d>m)
		{
			cout<<"Dead"<<endl<<ans;
			return 0;
		}
		if((p==1 && opt[t]==1) || (p==2 && opt[t]==2) || (p==3 && opt[t]==1))
		{
			ans++;
			p=4;
			opt[t]=0;
			a--;
		}
		if((p==1 && opt[t]==-1) || (p==3 && opt[t]==-1) || (p==4 && opt[t]==2))
		{
			ans++;
			p=2;
			opt[t]=0;
			a--;
		}
		if((p==1 && opt[t]==2) || (p==2 && opt[t]==1) || (p==4 && opt[t]==-1))
		{
			ans++;
			p=3;
			opt[t]=0;
			a--;
		}
		if(p==1 && opt[t]==3)
		{
			ans++;
			c--;
			a--;
		}
		if((p==2 && opt[t]==-1) || (p==3 && opt[t]==2) || (p==4 && opt[t]==1))
		{
			ans++;
			p=1;
			opt[t]=0;
			a--;
		}
		if(p==2 && opt[t]==3)
		{
			ans++;
			d--;
			a--;
		}
		if(p==3 && opt[t]==3)
		{
			ans++;
			c++;
			a--;
		}
		if(p==4 && opt[t]==3)
		{
			ans++;
			d++;
			a--;
		}
		if(ans!=0 && ans%2==0)
			b--;
		if(f[c][d]==2)
			a+=x;
		if(f[c][d]==3 && y>0)
		{
			b+=y;
			y-=z;
		}
		cout<<c<<' '<<d<<endl;
	}
			cout<<"Live is beautiful";
			return 0;
}
