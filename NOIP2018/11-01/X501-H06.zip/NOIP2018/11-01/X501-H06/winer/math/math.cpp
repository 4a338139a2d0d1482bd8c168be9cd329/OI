#include <bits/stdc++.h>
using namespace std;
const int maxn=10000010;
int ans,n;
int prime[maxn];
void pri(int m)
{
    prime[0]=prime[1]=0;
	for(int i=2;i<=sqrt(m);i++)
	{
		if(prime[i])
		{
			for(int j=2*i;j<=m;j+=i)
				prime[j]=0;
		}
	}
}
int min(int t)
{
	if(prime[t])
	{
		cout<<ans+1;
		return 0;
	}
	else
	{
		for(int i=t-2;;i--)
		{
			if(prime[i])
            {
				t-=i;
				ans++;
				break;
			}
		}
		min(t);
    }
}
int main()
{
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	cin>>n;
	for(int j=0;j<=n;j++)
		prime[j]=1;
	pri(n);
	min(n);
	return 0;
}
