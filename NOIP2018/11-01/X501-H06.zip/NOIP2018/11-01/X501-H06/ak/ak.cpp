#include<bits/stdc++.h>

using namespace std;

int read() {
	int fg = 1; int sum = 0; char c = getchar();
	for(; !isdigit(c); c = getchar()) if(c == '-') fg = -1;
	for(; isdigit(c); c = getchar()) sum = (sum << 3) + (sum << 1) + (c ^ 0x30);
	return fg * sum;
}

void print(int a) {
	if(a < 0) {putchar('-'); a = -a;}
	if(a > 9) print(a / 10);
	putchar(a % 10 + '0');
}

void file() {
	freopen("ak.in", "r", stdin);
	freopen("ak.out", "w", stdout);
}

int n, a[1000010], sum[1000010];

int main() {
	file();
	n = read();
	for(int i = 1; i <= n; ++i) {
		a[i] = read(); sum[i] = sum[i - 1] ^ a[i];
	}
	for(int i = 1; i <= n; ++i) {
		int maxn = 0;
		for(int j = 1; j <= i; ++j) {
			maxn = max(maxn, sum[j - 1] + (sum[i] ^ sum[j - 1]));
		}
		print(maxn); putchar('\n');
	}
}
