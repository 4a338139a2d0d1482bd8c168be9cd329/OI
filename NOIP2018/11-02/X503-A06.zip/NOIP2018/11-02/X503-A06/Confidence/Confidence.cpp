#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
const int maxn=2e5+10,mod=1e9+7;
int n,m,flag1=1,flag2=1,flag3=1;
struct query{
	int opt,x,y,z;	
}q[maxn];
namespace SUB1{
	inline void solve(){
		for(register int i=1;i<=m;++i)if(q[i].opt==2)printf("0\n");
	}
}
namespace SUB2{
	int sum=0;
	inline void solve(){
		for(register int i=1;i<=m;++i){
			if(q[i].opt==1)(sum+=q[i].z)%=mod;
			else{
				int res=1ll*sum*(q[i].y-q[i].x+1)%mod;
				printf("%d\n",res);
			}
		}
	}
}
namespace SUB3{
	int f[maxn];
	inline void solve(){
		for(register int i=1;i<=m;++i){
			if(q[i].opt==1){
				for(register int j=q[i].y;j<=n;j+=q[i].x)(f[j]+=q[i].z)%=mod;
			}else{
				int res=0;
				for(register int j=q[i].x;j<=q[i].y;++j)(res+=f[j])%=mod;
				printf("%d\n",res);
			}
		}
	}
}
namespace SUB4{
	int f[maxn],sum[maxn],flag=1;
	inline void solve(){
		for(register int i=1;i<=m;++i){
			if(q[i].opt==1){
				for(register int j=q[i].y;j<=n;j+=q[i].x)(f[j]+=q[i].z)%=mod;
			}else{
				if(flag){
					for(register int j=1;j<=n;++j)sum[j]=(sum[j-1]+f[j])%mod;
					flag=0;
				}printf("%d\n",(sum[q[i].y]-sum[q[i].x-1]+mod)%mod);
			}
		}
	}
}
int main(){
	freopen("Confidence.in","r",stdin);
	freopen("Confidence.out","w",stdout);
	n=read(),m=read();
	int t1=1,t2=1;
	for(register int i=1;i<=m;++i){
		q[i].opt=read(),q[i].x=read(),q[i].y=read();
		if(q[i].opt==1){
			t1=0,q[i].z=read();
			if(!t2)flag3=0;
			if(q[i].x^1)flag2=0;
		}else{
			t2=0;
			if(!t1)flag1=0;
		}	
	}if(n<=1000&&m<=1000)SUB3::solve();
	else if(flag1)SUB1::solve();
	else if(flag2)SUB2::solve();
	else if(flag3)SUB4::solve();
	else SUB3::solve();
	return 0;
}
