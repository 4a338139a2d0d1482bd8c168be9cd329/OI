#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
const int maxn=5e4+10,mod=1e9+7;
int a[maxn],n,flag=1;
namespace SUB1{
	inline void solve(){
		int res=1ll*n*(n+1)/2%mod;
		cout<<res<<endl;
	}
}
namespace SUB2{
	inline int getans(int l,int r){
		int ret=0,cnt=1;
		set<int>s;
		for(register int i=l;i<=r;++i)s.insert(a[i]);
		for(set<int>::iterator it=s.begin();it!=s.end();++it,++cnt){
			ret+=1ll*cnt*(*it)%mod;
			if(ret>mod)ret-=mod;
		}return ret;
	}
	inline void solve(){
		int res=0;
		for(register int i=1;i<=n;++i)for(register int j=i;j<=n;++j){
			res+=getans(i,j);
			if(res>mod)res-=mod;
		}printf("%d\n",res);
	}
}
int main(){
	freopen("Warmth.in","r",stdin);
	freopen("Warmth.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i)a[i]=read(),flag&=(a[i]==1);
	if(flag)SUB1::solve();
	else SUB2::solve();
	return 0;
}
