#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
const int maxm=3e3+10,maxn=3e5+10,lim=3e3,inf=0x3f3f3f3f;
inline int gcd(int x,int y){
	return y?gcd(y,x%y):x;
}
int dp[maxm][maxm],f[maxn],n,mx;
namespace GAO{
	const int Lim=3e5;
	int vis[maxn],mp[maxn],id[maxn],a[maxn],cnt;
	int g[maxn];
	inline void init(){
		for(register int i=1;i<=n;++i)vis[f[i]]=1;
		for(register int i=1;i<=Lim;++i){
			if(!vis[i])continue;
			for(register int j=i*2;j<=n;j+=i)vis[j]=0;
		}for(register int i=Lim;i;--i)if(vis[i])mp[i]=++cnt,id[cnt]=i;
	}
	inline void solve(){
		init();
		memset(g,0x3f,sizeof(g));
		for(register int i=1;i<=cnt;++i)g[id[i]]=1;
		for(register int i=2;i<=cnt;++i){
			for(register int j=1;j<cnt;++j){
				int k=gcd(id[i],id[j]);
				if(!mp[k])mp[k]=++cnt,id[cnt]=k;
				g[k]=min(g[k],g[id[i]]+g[id[j]]);
			}
		}if(g[1]==inf)printf("-1\n");
		else printf("%d\n",g[1]);
	}
}
int main(){
	freopen("Conscience.in","r",stdin);
	freopen("Conscience.out","w",stdout);
	n=read();
	memset(dp,0x3f,sizeof(dp));
	for(register int i=1;i<=n;++i)f[i]=read(),mx=max(f[i],mx);
	if(mx>lim||n>lim){
		GAO::solve();
		return 0;
	}for(register int i=1;i<=n;++i){
		dp[i][f[i]]=1;
		for(register int j=1;j<=lim;++j){
			dp[i][j]=min(dp[i][j],dp[i-1][j]);
			int k=gcd(f[i],j);
			dp[i][k]=min(dp[i][k],dp[i-1][j]+1);
		}
	}if(dp[n][1]==inf)printf("-1\n");
	else printf("%d\n",dp[n][1]);
	return 0;
}
