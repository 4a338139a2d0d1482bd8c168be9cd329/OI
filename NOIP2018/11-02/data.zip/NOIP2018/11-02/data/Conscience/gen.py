#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__ = 'cnyali_lk'
import io,os
from random import randint,random

task_name="Conscience"
def gen(a,b):
    n=randint(1,a)
    s="{}\n".format(n)
    for i in range(n):
        s+=str(randint(2,b))+" "
    return s
tasknum=1
subs=6
_n=[0,1,10,300000,300000,3000,300000]
_w=[0,300000,300000,300,3000,300000,300000]
_maxinum=[0,1,6,4,5,6,6]
mini=[0,0]
f=[[],[],[],[],[],[],[],[]]
mxp=[]
t=0
def init(n):
    global f,mxp,mini 
    f[0].append(1)
    for i in range(n+1):
        mxp.append(0)
    for i in range(2,n+1):
        if mxp[i]==0:
            for j in range(1,n//i+1):
                mxp[i*j]=i
        s=i
        while s%mxp[i]==0:
            s//=mxp[i]
        mini.append(mini[s]+1)
        f[mini[i]].append(i)
def lower_bound(a,b):
    l,r=0,len(a)-1
    while l<=r:
        mid=(l+r)//2
        if a[mid]<=b:
            l=mid+1
        else:
            r=mid-1
    return l
def Generate(n,m,w,maxi):
    r=randint(0,maxi)
    s=str(n)+'\n'
    global f
    rng=lower_bound(f[r],m)
    gen=f[r][randint(0,rng-1)]
    i=2
    a=[]
    while gen>1:
        a.append(mxp[gen])
        gen//=mxp[gen]
    for i in range(n):
        ai=1
        for j in range(len(a)):
            if randint(1,50)>=w:
                ai=ai*a[j]
        ai=ai*randint(1,m//ai)
        s=s+str(ai)+" "
    return s
        
def New(sub,s):
    global t
    t+=1
    with open("Subtask{}/{}{}.in".format(sub,task_name,t),"w") as f:
        f.write(s)
    os.system("./{0}<Subtask{1}/{0}{2}.in>Subtask{1}/{0}{2}.ans".format(task_name,sub,t))
    os.system("cat Subtask{}/{}{}.ans".format(sub,task_name,t))
    print("data",t,"in Subtask",sub,"DONE")
init(300000)
for sub in range(1,subs+1):
    os.system("rm -rf Subtask{} 2>/dev/null".format(sub))
    os.mkdir("Subtask{}".format(sub))
    for i in range(5,15):
        New(sub,Generate(_n[sub],_w[sub],i,_maxinum[sub]))

    

