/* Author: CNYALI_LK
LANG: C++
PROG: gen.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__) 
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
#define x first
#define y second
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int inf=0x3f3f3f3f;
const double eps=1e-8;
const double pi=acos(-1.0);
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
template<class T>int dcmp(T a,T b){return a>b;}
template<int *a>int cmp_a(int x,int y){return a[x]<a[y];}
#define min mmin
#define max mmax
#define abs aabs
namespace io {
	const int SIZE = (1 << 21) + 1;
	char ibuf[SIZE], *iS, *iT, obuf[SIZE], *oS = obuf, *oT = oS + SIZE - 1, c, qu[55]; int f, qr;
	// getchar
	#define gc() (iS == iT ? (iT = (iS = ibuf) + fread (ibuf, 1, SIZE, stdin), (iS == iT ? EOF : *iS ++)) : *iS ++)
	// print the remaining part
	inline void flush () {
		fwrite (obuf, 1, oS - obuf, stdout);
		oS = obuf;
	}
	// putchar
	inline void putc (char x) {
		*oS ++ = x;
		if (oS == oT) flush ();
	}
	// input a signed integer
	inline void read (int &x) {
		for (f = 1, c = gc(); c < '0' || c > '9'; c = gc()) if (c == '-') f = -1;
		for (x = 0; c <= '9' && c >= '0'; c = gc()) x = x * 10 + (c & 15); x *= f;
	}
	inline void read (char &x) {
		x=gc();
	}
	inline void read(char *x){
		while((*x=gc())=='\n' || *x==' '||*x=='\r');
		while(!(*x=='\n'||*x==' '||*x=='\r'))*(++x)=gc();
	}
	template<typename A,typename ...B>
	inline void read(A &x,B &...y){
		read(x);read(y...);
	}
	// print a signed integer
	inline void write (int x) {
		if (!x) putc ('0'); if (x < 0) putc ('-'), x = -x;
		while (x) qu[++ qr] = x % 10 + '0',  x /= 10;
		while (qr) putc (qu[qr --]);
	}
	inline void write (char x) {
		putc(x);
	}
	inline void write(const char *x){
		while(*x){putc(*x);++x;}
	}
	inline void write(char *x){
		while(*x){putc(*x);++x;}
	}
	template<typename A,typename ...B>
	inline void write(A x,B ...y){
		write(x);write(y...);
	}
	//no need to call flush at the end manually!
	struct Flusher_ {~Flusher_(){flush();}}io_flusher_;
}
using io :: read;
using io :: putc;
using io :: write;
vector<int> a[8];
int mxp[300005],Min[300005],ok[300005];
void init(int n){
	a[0].push_back(1);	
	ok[1]=1;
	for(int i=2;i<=n;++i){
		if(!mxp[i]){
			for(int j=i;j<=n;j+=i)mxp[j]=i;
		}
		int s=i;
		ok[s]=!!((s/mxp[s])%(mxp[s]));
		while(!(s%mxp[i]))s/=mxp[i];
		ok[i]=ok[s]&&ok[i];
		Min[i]=Min[s]+1;
		if(ok[i])a[Min[i]].push_back(i);
	}
}
char s[1005];
int t;
FILE *f;
void input(int sub){
	++t;
	sprintf(s,"Subtask%d/Conscience%d.in",sub,t);	
	f=fopen(s,"w");
}
void makeout(int sub){
	fclose(f);
	sprintf(s,"./Conscience<Subtask%d/Conscience%d.in>Subtask%d/Conscience%d.ans && cat Subtask%d/Conscience%d.ans",sub,t,sub,t,sub,t);
	system(s);	
	debug("%d in %d OK\n",t,sub);

} 
const int _n[]={0,1,10,(int)3e2,(int)3e3,(int)3e3,(int)3e5};
const int _w[]={0,1,(int)3e2,(int)3e2,(int)3e3,(int)3e5,(int)3e5};
const int _mx[]={0,1,3,3,4,6,6};
vector<int> ps;
int query(vector<int> a,int w){
	vector<int>::iterator i=upper_bound(all(a),w);
	if(i==a.end())return a.size();
	else return i-a.begin();

}
void NoAns(int N,int M){
	int n=rand()%N+1,w=rand()%(M-1)+2;
	fprintf(f,"%d\n",n);
	for(int i=1;i<=n;++i){
		fprintf(f,"%d%c",w*(rand()%(M/w)+1),i==n?'\n':' ');
	}
}
void generate(int N,int M,int R,int ans){
	int r,n,w,W;
	r=rand()%(R-ans+1)+ans;n=rand()%N+1;
	W=w=a[r][rand()%query(a[r],M)];
	while(W>1){
		ps.push_back(mxp[W]);
		W/=mxp[W];
	}
	random_shuffle(all(ps));
	int x,y;
	fprintf(f,"%d\n",n);
	for(int i=1;i<=n;++i){
		x=rand()%ans;
		W=w/ps[x];
		for(int j=ans;j<r;++j)if(rand()%2)W=W/ps[j];
		W*=rand()%(M/W)+1;
		fprintf(f,"%d%c",W,i==n?'\n':' ');
	}
	ps.erase(all(ps));	
}
int main(){
	srand((unsigned long long)new char);
	for(int i=1;i<=6;++i){
		sprintf(s,"rm -rf Subtask%d && mkdir Subtask%d",i,i);
		system(s);
	}
	init(300000);
	input(1);
	fprintf(f,"1\n1\n");
	makeout(1);
	input(1);
	fprintf(f,"1\n233\n");
	makeout(1);
	for(int i=2;i<=6;++i){
		input(i);
		NoAns(_n[i],_w[i]);
		makeout(i);
		input(i);
		generate(_n[i],_w[i],_mx[i],1);
		makeout(i);
		for(int j=1;j<=2;++j){
			input(i);
			generate(_n[i],_w[i],_mx[i],2);
			makeout(i);
		}
		for(int ans=3;ans<=_mx[i];++ans)
			for(int j=1;j<=5;++j){
				input(i);
				generate(_n[i],_w[i],_mx[i],ans);
				makeout(i);
			}
	}
	return 0;
}

