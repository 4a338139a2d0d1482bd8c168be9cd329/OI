#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__ = 'cnyali_lk'

import os
subs=5
for sub in range(1,subs):
    os.system("cp Subtask{}/* Subtask{}".format(sub,sub+1))

