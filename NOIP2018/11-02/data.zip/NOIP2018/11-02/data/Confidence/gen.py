#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__ = 'cnyali_lk'
import os
from random import randint,random
from math import ceil
p=1000000007
taskname="Confidence"
def rand(n,m):
    s="{} {}\n".format(n,m)
    blk=n**0.5
    for i in range(m):
        tp=randint(1,2)
        if tp==1:
            if random()<=0.5 :
                x=int(blk**(1+random()**1.5))
            else:
                x=ceil(blk-blk**(1-random()**1.5))
            y=randint(1,x)
            s=s+"1 {} {} {}\n".format(x,y,randint(0,p-1))
        else:
            l=randint(1,n)
            r=randint(1,n)
            if l>r:
                l,r=r,l
            s=s+"2 {} {}\n".format(l,r)
    return s
def allask(n,m):
    s="{} {}\n".format(n,m)
    for i in range(m):
        l=randint(1,n)
        r=randint(1,n)
        if l>r:
            l,r=r,l
        s=s+"2 {} {}\n".format(l,r)
    return s
def noask(n,m,blk):
    s="{} {}\n".format(n,m)
    for i in range(m):
        s=s+"1 {} {} {}\n".format(blk,randint(1,blk),randint(0,p-1))
    return s
def upd(n,m,blk):
    s="{} {}\n".format(n,m)
    for i in range(m-1):
        s=s+"1 {} {} {}\n".format(blk,randint(1,blk),randint(0,p-1))
    s=s+"2 1 {}\n".format(n)
    return s
def upd1Random(n,m,blk):
    s="{} {}\n".format(n,m)
    for i in range(m):
        tp=randint(1,2)
        if tp==1:
            x=ceil(blk-blk**(1-random()**2))
            s=s+"1 {} {} {}\n".format(x,randint(1,x),randint(0,p-1))
        else:
            l=randint(1,n)
            r=randint(1,n)
            if l>r:
                l,r=r,l
            s=s+"2 {} {}\n".format(l,r)
    return s
def upd2Random(n,m,blk):
    s="{} {}\n".format(n,m)
    for i in range(m):
        tp=randint(1,2)
        if tp==1:
            x=int(blk*((n/blk)**(random()**2)))
            s=s+"1 {} {} {}\n".format(x,randint(1,x),randint(0,p-1))
        else:
            l=randint(1,n)
            r=randint(1,n)
            if l>r:
                l,r=r,l
            s=s+"2 {} {}\n".format(l,r)
    return s
def upd1MoreUpdate(n,m,blk):
    s="{} {}\n".format(n,m)
    for i in range(m-1):
        x=ceil(blk-blk**(1-random()**2))
        s=s+"1 {} {} {}\n".format(x,randint(1,x),randint(0,p-1))
    s=s+"2 1 {}\n".format(n)
    return s
def upd2MoreUpdate(n,m,blk):
    s="{} {}\n".format(n,m)
    for i in range(m-1):
        x=int(blk*((n/blk)**(random()**2)))
        s=s+"1 {} {} {}\n".format(x,randint(1,x),randint(0,p-1))
    s=s+"2 1 {}\n".format(n)
    return s
def upd2UpdateFirst(n,m,blk):
    s="{} {}\n".format(n,m)
    q=randint(1,m)
    for i in range(q):
        x=int(blk*((n/blk)**(random()**2)))
        s=s+"1 {} {} {}\n".format(x,randint(1,x),randint(0,p-1))
    for i in range(m-q):
        l=randint(1,n)
        r=randint(1,n)
        if l>r:
            l,r=r,l
        s=s+"2 {} {}\n".format(l,r)
 
    return s
t=0
def New(sub,s):
    global t
    t+=1
    with open("Subtask{}/{}{}.in".format(sub,taskname,t),"w") as f:
        f.write(s)
    os.system("./{0}<Subtask{1}/{0}{2}.in>Subtask{1}/{0}{2}.ans".format(taskname,sub,t))
    print("data",t,"in Subtask",sub,"DONE")
n,m=200000,200000
for i in range(1,7):
    os.system("rm -rf Subtask{0} 2>/dev/null && mkdir Subtask{0}".format(i))
for i in range(200,1001,200):
    New(1,noask(n,m,i+1))
New(1,allask(n,m))
for i in range(2):
    New(2,noask(n,m,1))
    New(2,upd(n,m,1))
    New(2,upd1Random(n,m,2))
New(2,allask(n,m))
for i in range(10):
    New(3,rand(1000,1000))
for i in range(5):
    New(3,upd1MoreUpdate(1000,1000,1000))
for i in range(6):
    New(4,upd2UpdateFirst(n,m,2000))
New(4,upd2MoreUpdate(n,m,2000))
New(4,allask(n,m))
for i in range(6):
    New(5,upd1Random(n,m,300))
New(5,upd1MoreUpdate(n,m,300))
New(5,allask(n,m))
for i in range(6):
    New(6,rand(n,m))

os.system("Subtask1/* Subtask6")
os.system("Subtask2/* Subtask5")
os.system("Subtask3/* Subtask6")
os.system("Subtask4/* Subtask6")
os.system("Subtask5/* Subtask6")
