#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__ = 'cnyali_lk'
import sys,os
try:
    while True:
        s=input().split()
        os.system("cp Subtask{}/* Subtask{}".format(s[0],s[1]))
except EOFError:
    pass


