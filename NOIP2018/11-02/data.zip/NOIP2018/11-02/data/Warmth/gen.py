#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__ = 'cnyali_lk'
from random import random,randint
import os
def rand(mxn):
    n=randint(2,mxn)
    s=str(n)+"\n"
    for i in range(n):
        s=s+"{} ".format(randint(1,n))
    return s
def perm(mxn):
    n=randint(2,mxn)
    a=list(range(n+1))
    for i in range(2,n+1):
        j=randint(1,i-1)
        a[i],a[j]=a[j],a[i]
    s=str(n)+"\n"
    for i in range(1,n+1):
        s=s+"{} ".format(a[i])
    return s
def Hack(mxn):
    n=mxn
    s=str(n)+"\n"
    for i in range(n):
        s=s+"{} ".format(i%(n>>1)+1)
    return s
def hack2(mxn):
    n=mxn
    s=str(n)+"\n"
    for i in range(n):
        s=s+"{} ".format(n+1-min(i+1,n-i))
    return s
def low(siz,mxn):
    n=randint(siz,mxn)
    s=str(n)+"\n"
    for i in range(n):
        s=s+"{} ".format(randint(1,siz))
    return s
fafa=[Hack,hack2]
t=0
def New(sub,s):
    global t
    t+=1
    with open("Subtask{}/Warmth{}.in".format(sub,t),"w") as f:
        f.write(s)
    os.system("time ./Warmth<Subtask{0}/Warmth{1}.in>Subtask{0}/Warmth{1}.ans".format(sub,t))
    print("data",t,"in Subtask",sub,"DONE")

for i in range(1,7):
    os.system("rm -rf Subtask{0} 2>/dev/null && mkdir Subtask{0}".format(i))
for i in range(5):
    New(1,rand(100))
for i in range(2):
    New(1,perm(100))
for i in range(2):
    New(1,fafa[i](100))
for i in range(5):
    New(1,low((i+1)*10,100))
for i in range(5):
    New(2,rand(1000))
for i in range(2):
    New(2,perm(1000))
for i in range(2):
    New(2,fafa[i](1000))
for i in range(5):
    New(2,low((i+1)*100,1000))
New(3,low(1,50000))
for i in range(5):
    New(4,perm(50000))
for i in range(5):
    New(5,rand(20000))
for i in range(2):
    New(5,perm(20000))
for i in range(2):
    New(5,fafa[i](20000))
for i in range(5):
    New(5,low((i+1)*2000,20000))
for i in range(5):
    New(6,rand(50000))
for i in range(2):
    New(6,perm(50000))
for i in range(2):
    New(6,fafa[i](50000))
for i in range(5):
    New(6,low((i+1)*10000,50000))

os.system("./makeqz<to.conf")
