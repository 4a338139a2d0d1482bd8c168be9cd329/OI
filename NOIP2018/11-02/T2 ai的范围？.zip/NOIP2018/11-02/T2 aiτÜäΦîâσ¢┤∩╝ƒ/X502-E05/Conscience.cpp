#include<bits/stdc++.h>
#define GC getchar
#define MEM memset
#define OUT printf
const int MAX=300005;
using namespace std;
int A[MAX],M,N,S,SUM,CNT;
int B[MAX],F[MAX],LEN,FLAG;
void READ(int &X){
    char C=GC();X=0;
    while(C<'0' || C>'9')
        C=GC();
    while(C>=48 && C<=57){
        X=X*10+C-48;
        C=GC();
    }
}
int GCD(int X,int Y){
	if(Y==0)return X;
	return GCD(Y,X%Y);
}
int main( ){
	freopen("Conscience.in","r",stdin);
	freopen("Conscience.out","w",stdout);
	READ(M);
    if(M==1){OUT("-1\n");return 0;}
    for(register int I=1;I<=M;I++)
    	READ(A[I]);
	sort(A+1,A+M+1);
	for(register int I=2;I<=M;I++){
		if(A[I]!=A[I-1]){S++;B[++LEN]=A[I];}
	}
	for(register int I=1;I<=M;I++){
		if(B[I]>SUM){int TMP=B[I]; B[I]=SUM; SUM=TMP;}
    	SUM=GCD(SUM,B[I]);
    	if(SUM==1 && CNT==0)CNT=I;
	}
	if(SUM!=1){OUT("-1\n");return 0;}
	return 0;
}
