#include<bits/stdc++.h>
#define GC getchar
#define MEM memset
#define OUT printf
const int MOD=1000000000+7;
const int MAX=200005;
using namespace std;
long long A[MAX],M,N,K,SUM;
void READ(long long &X){
    char C=GC();X=0;
    while(C<'0' || C>'9')
        C=GC();
    while(C>=48 && C<=57){
        X=X*10+C-48;
        C=GC();
    }
}
int main( ){
    freopen("Confidence.in","r",stdin);
    freopen("Confidence.out","w",stdout);
	READ(M);READ(N);
    for(register int I=1;I<=N;I++){
    	long long X,Y,Z; READ(K);
    	if(K==1){
    		READ(X);READ(Y);READ(Z);
    		for(register int J=Y;J<=M;J+=X){
    			A[J]+=Z%MOD;
				A[J]%=MOD;
			}
		}else{
			READ(X);READ(Y);
			SUM=0;
			for(register int J=X;J<=Y;J++){
				SUM+=A[J]%MOD;
				SUM%=MOD;
			}
			OUT("%d\n",SUM);
		}
	}
	return 0;
}
