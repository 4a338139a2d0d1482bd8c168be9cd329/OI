#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (r);i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (l);i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
const int N = 2e5 + 10,mod = 1e9 + 7;

struct node {
	int opt,x,y,z;
} Opt[N];

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

inline void Add(int &x,int y) {
	if((x += y) >= mod) x -= mod;
}

struct BIT {
	int Sum[N];
	inline int lowbit(int x) { return x & (-x); }
	inline void Modify(int pos,int val) {
		for(;pos < N;pos += lowbit(pos)) Add(Sum[pos],val);
	}
	inline int Query(int pos) {
		int ans = 0;
		for(;pos;pos -= lowbit(pos)) Add(ans,Sum[pos]);
		return ans;
	}
} T;

int main() {
#ifndef ONLINE_JUDGE
	freopen("Confidence.in","r",stdin);
	freopen("Confidence.out","w",stdout);
#endif

	int n = read(),m = read(),Last = 0;
	For(i,1,m) {
		int opt = read();
		if(opt == 1) {
			int x = read(),y = read(),z = read();
			Opt[i] = (node){1,x,y,z};
		} else {
			int l = read(),r = read();
			Opt[i] = (node){2,l,r,0},Last = i;
		}
	}
	int Sum = 0;
	For(i,1,Last) {
		int opt = Opt[i].opt;
		if(opt == 1) {
			int x = Opt[i].x,y = Opt[i].y,z = Opt[i].z;
			if(x == 1) Add(Sum,z);
			else for(int j = y;j <= n;j += x) T.Modify(j,z);
		} else {
			int l = Opt[i].x,r = Opt[i].y;
			printf("%lld\n",(1ll * Sum * (r - l + 1) + T.Query(r) - T.Query(l - 1) + mod) % mod);
		}
	}
	return 0;
}
