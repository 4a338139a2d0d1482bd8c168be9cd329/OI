#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (r);i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (l);i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
const int N = 1e3 + 10,mod = 1e9 + 7;

int a[N],vis[N];

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

inline void Add(int &x,int y) {
	if((x += y) >= mod) x -= mod;
}

struct BIT {
	int Sum[N];
	inline void init() {
		memset(Sum,0,sizeof(Sum));
	}
	inline int lowbit(int x) { return x & (-x); }
	inline void Modify(int pos,int val) {
		for(;pos < N;pos += lowbit(pos)) Add(Sum[pos],val);
	}
	inline int Query(int pos) {
		int ans = 0;
		for(;pos;pos -= lowbit(pos)) Add(ans,Sum[pos]);
		return ans;
	}
} T[2];

int main() {
#ifndef ONLINE_JUDGE
	freopen("Warmth.in","r",stdin);
	freopen("Warmth.out","w",stdout);
#endif

	int n = read();
	if(n > 2000) return printf("%lld\n",1ll * n * (n + 1) / 2 % mod),0;
	For(i,1,n) a[i] = read();

	int ans = 0;
	For(i,1,n) {
		memset(vis,0,sizeof(vis));
		T[0].init(),T[1].init();
		int Sum = 0,tot = 0;
		For(j,i,n) {
			if(!vis[a[j]]) {
				int cnt = T[0].Query(a[j]);Add(Sum,T[1].Query(n) - T[1].Query(a[j]));
				Add(Sum,1ll * a[j] * (cnt + 1) % mod);
				++tot,vis[a[j]] = true;
				T[0].Modify(a[j],1),T[1].Modify(a[j],a[j]);
			}
			Add(ans,Sum);
		}
	}

	printf("%d\n",ans);

	return 0;
}
