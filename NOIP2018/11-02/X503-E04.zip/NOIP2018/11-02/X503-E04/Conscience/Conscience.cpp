#include<bits/stdc++.h>
#define For(i,l,r) for(int i = (l),i##end = (r);i <= i##end;i++)
#define Fordown(i,r,l) for(int i = (r),i##end = (l);i >= i##end;i--)
#define debug(x) cout << #x << " = " << x << endl

using namespace std;

typedef long long ll;

template <typename T> inline bool chkmin(T &x,T y) { return y < x ? x = y,1 : 0; }
template <typename T> inline bool chkmax(T &x,T y) { return x < y ? x = y,1 : 0; }

const int INF = 0x3f3f3f3f;
const int N = 3e5 + 10;

int a[N],cnt[N],dp[N],Full[N],mu[N],vis[N],Sum[N],Prime[N];

inline int read() {
	int x = 0,flag = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')ch = getchar();
	if(ch == '-')flag = -1,ch = getchar();
	while(isdigit(ch))x = (x << 3) + (x << 1) + (ch - '0'),ch = getchar();
	return x * flag;
}

inline void init(int n) {
	int prime = 0;
	mu[1] = 1,vis[1] = true;
	for(int i = 2;i <= n;i++) {
		if(!vis[i]) Prime[++prime] = i,mu[i] = -1;
		for(int j = 1;j <= prime && i * Prime[j] <= n;j++) {
			vis[i * Prime[j]] = true;
			mu[i * Prime[j]] = -mu[i];
			if(i % Prime[j] == 0) {
				mu[i * Prime[j]] = 0;
				break;
			}
		}
	}
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("Conscience.in","r",stdin);
	freopen("Conscience.out","w",stdout);
#endif

	int n = read(),Lim = 3e5;
	init(Lim + 5);
	memset(dp,63,sizeof(dp));
	For(i,1,n) cnt[a[i] = read()]++,dp[a[i]] = 1;
	For(i,2,Lim) {
		for(int j = i * 2;j <= Lim;j += i) cnt[i] += cnt[j];
		Sum[i] -= mu[i] * cnt[i];
	}
	Fordown(i,Lim,1) for(int j = i * 2;j <= Lim;j += i) Sum[j] += Sum[i];

	Fordown(i,Lim,1) for(int j = i * 2;j <= Lim;j += i)
		if(dp[j] < INF && Sum[j / i] < n) {
			chkmin(dp[i],dp[j] + 1);
		}

	printf("%d\n",dp[1] == INF ? -1 : dp[1]);

	return 0;
}
