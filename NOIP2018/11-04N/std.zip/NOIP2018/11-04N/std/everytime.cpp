#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>

#define fo(i,j,l) for(int i=j;i<=l;++i)
#define fd(i,j,l) for(int i=j;i>=l;--i)

using namespace std;
typedef long long ll;
const ll N=2*67e4,mo=19260817,K=(mo+1)>>1;

int a[N],p[N],d[N];
ll g[N],g0[N],g1[N],g2[N],k[N],suf[N],pre[N];
int n,S;
ll tr[N];

int la[N],dq[N];

inline void cor(int a)
{
	a=n-a+1;
	for(;a<=n;a=a+(a&(-a)))tr[a]=(tr[a]+1)%mo;
}

inline ll ask(int o)
{
	ll y=0; o=n-o+1;
	for(;o;o-=(o&(-o)))y=y+tr[o];
	return y%mo;
}

inline int read()
{
	int o=0; char ch=' ';
	for(;ch<'0'||ch>'9';ch=getchar());
	for(;ch>='0'&&ch<='9';ch=getchar())o=o*10+(ch^48);
	return o;
}

int main()
{
	freopen("everytime.in","r",stdin);
	freopen("everytime.out","w",stdout);
	n=read();
	fo(i,1,n)a[i]=read();
	fo(i,1,n)++p[a[i]];
	fo(i,1,n)if(p[i])d[i]=++d[0],p[i]=0;
	fo(i,1,n)a[i]=d[a[i]],++p[a[i]];
	ll all=0,ans0=0;
	fd(i,n,1){
		g1[a[i]]=(g1[a[i]]+g[a[i]])%mo;
		all=all+g[a[i]];
		++g[a[i]];
		k[i-1]=(all-g1[a[i-1]])%mo;
	}
	fo(i,1,n)g1[i]=g[i]=0;
	fo(i,1,n){
		ans0=(ans0+g[a[i]]*k[i])%mo;
		++g[a[i]];
	}
	double dd=log(n)/log(2);
	S=sqrt(n/dd);
	ll ans1=0;
	fo(i,1,n)if(p[i]>=S){
		fo(l,1,n)g[l]=g[l-1]+(a[l]==i);
		fo(l,1,n)g0[l]=g1[l]=g2[l]=0;
		fo(l,1,n)if(a[l]!=i){
			ans1=(ans1+g[l]*g[l]%mo*g0[a[l]]%mo+g2[a[l]]-2*g[l]*g1[a[l]]%mo-g0[a[l]]*g[l]%mo+g1[a[l]])%mo;
			g2[a[l]]=(g2[a[l]]+g[l]*g[l])%mo; g1[a[l]]=(g1[a[l]]+g[l])%mo; ++g0[a[l]];
		}
	}
	ans1=(ans1+mo)%mo;
	ans1=ans1*K%mo;
	ll ans2=0;
	fo(i,1,n)if(p[i]>=S){
		fo(l,1,n)pre[l]=pre[l-1]+(a[l]==i);
		fd(l,n,1)suf[l]=suf[l+1]+(a[l]==i);
		fo(l,1,n)g[l]=0;
		fo(l,1,n)if(p[a[l]]<S){
			ans2=(ans2+g[a[l]]*suf[l])%mo;
			g[a[l]]=(g[a[l]]+pre[l])%mo;
		}
	}
	ll ans3=0;
	fo(i,1,n)if(p[a[i]]<S){
		la[i]=dq[a[i]]; dq[a[i]]=i;
		for(int o=la[i],p=0;o;o=la[o],++p)ans3=(ans3+ask(o+1)-p*(p-1)/2)%mo;
		for(int o=la[i];o;o=la[o])cor(o);
	}
	all=0; ll ans=0;
	fo(i,1,n)g[i]=((ll)p[i]*(p[i]-1)/2)%mo,ans=(ans+all*g[i])%mo,all=(all+g[i])%mo;
	ans=ans-ans0-ans1-ans2-ans3;
	ans=(ans%mo+mo)%mo;
	cout<<ans;
	return 0;
}
