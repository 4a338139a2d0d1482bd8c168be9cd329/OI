#include <cstdio>
#include <cstdlib>
using namespace std;
double n,m;
int main()
{
    freopen("winner.in","r",stdin);
    freopen("winner.out","w",stdout);
	scanf("%lf%lf",&n,&m);
	printf("%.6lf\n",n*(n-1)/2/m);
	return 0;
}