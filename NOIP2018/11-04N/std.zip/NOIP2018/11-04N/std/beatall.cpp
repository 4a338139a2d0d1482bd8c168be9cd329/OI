#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fod(i,a,b) for(int i=a;i>=b;i--)
#define N 1050005
#define LL long long
using namespace std;
int a[N],h[N],top,st[N],n,t[N];
void read(int &x) //HZJ
{
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
}
/*int read(int &n)//LF
{
	char ch=' ';int q=0,w=1;
	for(;(ch!='-')&&((ch<'0')||(ch>'9'));ch=getchar());
	if(ch=='-')w=-1,ch=getchar();
	for(;ch>='0' && ch<='9';ch=getchar())q=q*10+ch-48;n=q*w;return n;
}*/


void write(int x)
{
	if(x==0){putchar('0');return;}
	char s[12],l=0;
	while(x!=0)s[++l]=x%10+48,x/=10;
	fod(i,l,1)putchar(s[i]);
}
int main()
{
	freopen("beatall.in","r",stdin);
	freopen("beatall.out","w",stdout);
	read(n);
	h[0]=-1;
	fo(i,1,n) read(a[i]),read(h[i]);
	fo(i,1,n)
	{
		while(top&&h[st[top]]<=h[i]) st[top--]=0;
		while(top>1&&(LL)(h[i]-h[st[top]])*(LL)(a[st[top]]-a[st[top-1]])>=(LL)(h[st[top]]-h[st[top-1]])*(LL)(a[i]-a[st[top]])) st[top--]=0;
		st[++top]=i;
		t[i]=st[top-1];
	}
	fo(i,1,n) 
	{
		if(!t[i]) write(i);
		else write(t[i]);
		putchar('\n');
	}
}
