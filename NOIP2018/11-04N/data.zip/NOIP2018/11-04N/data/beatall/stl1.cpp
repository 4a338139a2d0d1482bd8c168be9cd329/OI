#include <cstdio>
#include <algorithm>
#define fo(i,a,b) for(int i=a;i<=b;++i)
#define fod(i,a,b) for(int i=a;i>=b;--i)
#define min(q,w) ((q)>(w)?(w):(q))
#define max(q,w) ((q)<(w)?(w):(q))
#define abs(q) ((q)<0?-(q):(q))
using namespace std;
typedef long long LL;
const int N=1000500;
int read()
{
	char ch=' ';int q=0;
	for(;(ch<'0')||(ch>'9');ch=getchar());
	for(;ch>='0' && ch<='9';ch=getchar())q=(q<<3)+(q<<1)+ch-48;return q;
}
void write(int x)
{
	if(x==0){putchar('0');return;}
	char s[12],l=0;
	while(x!=0)s[++l]=x%10+48,x/=10;
	fod(i,l,1)putchar(s[i]);
}
int m,n;
int a[N][2];
int Go[N];
int za[N];
int main()
{
	freopen("beatall.in","r",stdin);
	freopen("beatall.out","w",stdout);
	int q,w;
	n=read();
	fo(i,1,n)a[i][0]=read(),a[i][1]=read();
	a[0][1]=-1e9;
	fo(i,1,n)
	{
		Go[i]=i-1;
		for(;za[0]&&a[za[za[0]]][1]<=a[i][1];--za[0])if(a[Go[i]][1]<a[Go[za[za[0]]]][1])Go[i]=Go[za[za[0]]];
		if(za[0])
		{
			w=za[za[0]];
			if((LL)(a[i][1]-a[w][1])*(a[i][0]-a[Go[w]][0])>=(LL)(a[i][1]-a[Go[w]][1])*(a[i][0]-a[w][0]))Go[i]=Go[za[za[0]]];
			else if(a[Go[i]][1]<a[za[za[0]]][1])Go[i]=za[za[0]];
		}
	for(;(LL)(a[i][1]-a[Go[i]][1])*(a[i][0]-a[Go[Go[i]]][0])>=(LL)(a[i][1]-a[Go[Go[i]]][1])*(a[i][0]-a[Go[i]][0])&&Go[Go[i]]!=Go[i];Go[i]=Go[Go[i]]);
		if(a[Go[i]][1]<=a[i][1])Go[i]=i;
		za[++za[0]]=i;
	}
	fo(i,1,n) 
	{
		write(Go[i]);
		putchar('\n');
	}
	return 0;
}