#include<bits/stdc++.h>
typedef long long ll;
#define For(i,j,k) for (int i=(int)j;i<=(int)k;++i)
#define Forr(i,j,k) for (int i=(int)j;i>=(int)k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=5e5+1e2;
const int maxm=1e6+1e2;
const int N=30;
struct node {
	int id,l,r;
	bool operator < (const node &aa) const {
		return ((l>aa.l) || (l==aa.l && r>aa.r));
	}
}q[maxm];
int n,m;
int val[maxn],nxt[maxn][N+1];
ll Ans[maxm];

inline void file() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}

inline int read() {
	int x=0,p=1;
	char c=getchar();
	while (!isdigit(c)) { if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) { x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	return x*p;
}

struct Bit {
	ll bit1[maxn],bit2[maxn];

	inline void init() { Set(bit1,0); Set(bit2,0); }

	inline int lowbit(int x) { return x&-x; }

	inline void update(int x,int val) {
		for (int i=x;i<maxn;i+=lowbit(i)) bit1[i]+=val,bit2[i]+=1ll*x*val;
	}

	inline ll query(int x) {
		ll sum=0;
		for (int i=x;i;i-=lowbit(i)) sum+=1ll*(x+1)*bit1[i]-bit2[i];
		return sum;
	}

	inline void Update(int L,int R,int val) {
		update(L,val); update(R+1,-val);
	}

	inline ll Query(int L,int R) {
		return query(R)-query(L-1);
	}
}T;

int main() {
	file();
	int t=read();
	while (t--) {
		T.init();
		n=read(); m=read();
		For (i,1,n) val[i]=read();
		For (j,0,N) nxt[n][j]=n+1;
		Forr (i,n-1,1)
			For (j,0,N) {
				if (val[i+1]&(1<<j)) nxt[i][j]=nxt[i+1][j];
				else nxt[i][j]=i+1;
			}
		For (i,1,m) q[i].id=i,q[i].l=read(),q[i].r=read();
		sort(q+1,q+m+1);
		int pos=n;
		For (i,1,m) {
			while (q[i].l<=pos) {
				int val_and=val[pos],r=pos;
				while (r<=n) {
					int Nxt=n+1;
					For (j,0,N)
						if (val_and&(1<<j)) chkmin(Nxt,nxt[pos][j]);
					int v=sqrt(val_and);
					if (v*v==val_and) T.Update(r,Nxt-1,1);
					val_and&=val[Nxt]; r=Nxt;
				}
				--pos;
			}
			Ans[q[i].id]=T.Query(1,q[i].r);
		}
		For (i,1,m) printf("%lld\n",Ans[i]);
	}
	cerr << clock() << endl;
	return 0;
}
