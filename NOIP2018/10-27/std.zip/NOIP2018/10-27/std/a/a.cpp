#include<bits/stdc++.h>
typedef long long ll;
#define For(i,j,k) for (int i=(int)j;i<=(int)k;++i)
using namespace std;

ll n;
vector<ll>Ans;

inline void file() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}

inline int calc(ll val) {
	int sum=0;
	while (val) sum+=val%10,val/=10;
	return sum;
}

int main() {
	file();
	scanf("%lld",&n);
	for (ll i=max(0ll,n-200);i<=n;++i)
		if (i+calc(i)==n) Ans.push_back(i);
	cout << Ans.size() << endl;
	For (i,0,Ans.size()-1) printf("%lld\n",Ans[i]);
	return 0;
}
