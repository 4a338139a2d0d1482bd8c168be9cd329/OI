#include<bits/stdc++.h>
typedef long long ll;
#define For(i,j,k) for (int i=(int)j;i<=(int)k;++i)
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=1000+10;
const int inf=0x3f3f3f3f;
int n,m,k;
char s1[maxn],s2[maxn];
int dp[maxn][maxn][11][2];

inline void file() {
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}

int main() {
	file();
	scanf("%d%d%d",&n,&m,&k);
	scanf("%s",s1+1); scanf("%s",s2+1);
	For (l,1,k) For (i,1,n) For (j,1,m) {
		if (s1[i]==s2[j]) {
			chkmax(dp[i][j][l][1],dp[i-1][j-1][l][1]+1);
			chkmax(dp[i][j][l][1],max(dp[i-1][j-1][l-1][0],dp[i-1][j-1][l-1][1])+1);
		}
		chkmax(dp[i][j][l][0],max(dp[i-1][j][l][0],dp[i-1][j][l][1]));
		chkmax(dp[i][j][l][0],max(dp[i][j-1][l][0],dp[i][j-1][l][1]));
	}
	printf("%d\n",max(dp[n][m][k][0],dp[n][m][k][1]));
	return 0;
}
