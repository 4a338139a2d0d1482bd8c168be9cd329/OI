#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <set>
#include      <map>
using namespace std;

const int N=500005,M=2000005;

int n,m,p[N],x[N],y[N];

struct Work
{
	int p[N],pos[N],Min[N],add[N],x[N],y[N],Ans[N];
	
	void build(int x,int l,int r)
	{
		if(l==r)
			Min[x]=-l;
		else
		{
			int Mid=l+r>>1;
			build(x<<1,l,Mid);build(x<<1|1,Mid+1,r);
		}
	}
	
	void Add(int x,int l,int r,int L,int R,int t)
	{
		if(L<=l&&r<=R)
			add[x]+=t,Min[x]+=t;
		else
		{
			int Mid=l+r>>1;
			if(L<=Mid)
				Add(x<<1,l,Mid,L,R,t);
			if(R>Mid)
				Add(x<<1|1,Mid+1,r,L,R,t);
			Min[x]=min(Min[x<<1],Min[x<<1|1])+add[x];
		}
	}
	
	int Ask(int x,int l,int r,int t)
	{
		if(Min[x]>t)
			return -1;
		if(l==r)
			return l;
		int Mid=l+r>>1;
		t-=add[x];
		int Ans=Ask(x<<1|1,Mid+1,r,t);
		if(Ans!=-1)
			return Ans;
		return Ask(x<<1,l,Mid,t);
	}
	
	vector<int> sM,sm;
	
	void main()
	{
		build(1,1,n);
		for(int i=n;i;i--)
		{
			while(sM.size()&&p[sM[sM.size()-1]]<p[i])
			{
				if(sM.size()>=2)
					Add(1,1,n,sM[sM.size()-1],sM[sM.size()-2]-1,-p[sM[sM.size()-1]]);
				else
					Add(1,1,n,sM[sM.size()-1],n,-p[sM[sM.size()-1]]);
				sM.pop_back();
			}
			sM.push_back(i);
			if(sM.size()>=2)
				Add(1,1,n,sM[sM.size()-1],sM[sM.size()-2]-1,p[sM[sM.size()-1]]);
			else
				Add(1,1,n,sM[sM.size()-1],n,p[sM[sM.size()-1]]);
			while(sm.size()&&p[sm[sm.size()-1]]>p[i])
			{
				if(sm.size()>=2)
					Add(1,1,n,sm[sm.size()-1],sm[sm.size()-2]-1,p[sm[sm.size()-1]]);
				else
					Add(1,1,n,sm[sm.size()-1],n,p[sm[sm.size()-1]]);
				sm.pop_back();
			}
			sm.push_back(i);
			if(sm.size()>=2)
				Add(1,1,n,sm[sm.size()-1],sm[sm.size()-2]-1,-p[sm[sm.size()-1]]);
			else
				Add(1,1,n,sm[sm.size()-1],n,-p[sm[sm.size()-1]]);
			pos[i]=Ask(1,1,n,-i);
		}
	}
	
	vector<int> Q[N];
	int T[N];
	
	void Cov(int x,int l,int r,int p,int c)
	{
		T[x]=c;
		if(l==r)
			return;
		else
		{
			int Mid=l+r>>1;
			if(p<=Mid)
				Cov(x<<1,l,Mid,p,c);
			else
				Cov(x<<1|1,Mid+1,r,p,c);
		}
	}
	
	int Query(int x,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)
			return T[x];
		int Mid=l+r>>1;
		if(R<=Mid)
			return Query(x<<1,l,Mid,L,R);
		if(L>Mid)
			return Query(x<<1|1,Mid+1,r,L,R);
		return max(Query(x<<1,l,Mid,L,R),Query(x<<1|1,Mid+1,r,L,R));
	}
	
	void query()
	{
		for(int i=1;i<=m;i++)
			Q[x[i]].push_back(i);
		for(int i=1;i<=n;i++)
		{
			Cov(1,1,n,pos[i],i);
			for(auto j: Q[i])
				Ans[j]=Query(1,1,n,y[j],n);
		}
	}
}l,r;

int main()
{
#ifndef ONLINE_JUDGE
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
#endif
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&p[i]),l.p[i]=p[i],r.p[n+1-i]=p[i];
	l.main();r.main();
	scanf("%d",&m);
	for(int i=1;i<=m;i++)
		scanf("%d%d",&x[i],&y[i]),l.x[i]=x[i],l.y[i]=y[i],r.x[i]=n+1-y[i],r.y[i]=n+1-x[i];
	l.query();r.query();
	for(int i=1;i<=m;i++)
		printf("%d %d\n",l.Ans[i],n+1-r.Ans[i]);
	return 0;
}

