#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
int N;
int n, m, q;

int c[2][maxn], ban[maxn], a[maxn];
int suf(int lim, int x){ return x==lim ? lim+1 : lim/(lim/(x+1)); }
void init(){
	for(int i=1;i<=n;i=suf(n,i)){
		int now=0, cnt=0;
		for(int j=2;j<=i;j=suf(i,j)){
			int x=i/j; int t=(x>N)?c[1][n/x]:c[0][x];
			a[++cnt]=t^now; ban[ a[cnt] ]=1;
			if((i/x-i/(x+1)) & 1) now^=t;
		}
		now=1;
		while(ban[now]) now++;
		if(i>N) c[1][n/i]=now; else c[0][i]=now;
		for(int j=1;j<=cnt;j++) ban[ a[j] ]=0; 
	}
}

int main(){
	freopen("txt.in","r",stdin),freopen("txt.out","w",stdout);

	scanf("%d%d", &n, &q);
	// N=(int)sqrt(n);
	N=40000;
	init();
	// for(int i=1;i<=10;i++) printf("%d ", c[1][i]); puts("");
	// for(int i=1;i<=10;i++) printf("%d ", c[0][i]); puts("");
	while(q--){
		scanf("%d", &m);
		int x, ans=0;
		for(int j=1;j<=m;j++){
			scanf("%d", &x); x=n/x;
			ans^=(x>N)?c[1][n/x]:c[0][x];
		}
		printf("%s\n", ans?"Yes":"No");
	}
	return 0;
}
