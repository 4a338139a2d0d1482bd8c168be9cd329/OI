#include<bits/stdc++.h>
using namespace std;

const int maxn=200010;
const int lim=1500;
int n;
char s[10];
struct node{
	int x, y, d, type;
}a[maxn];
double ans;
int sum[maxn];
int incline[5][maxn];

void read(int& x){
	x=0; char c=getchar(); int f=1;
	while(c<'0' || c>'9'){ if(c=='-') f=-1; c=getchar(); }
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	x*=f;
}

int main(){
	freopen("skss.in","r",stdin),freopen("skss.out","w",stdout);

	read(n);
	for(int i=1;i<=n;i++){
		scanf("%s", s);
		if(s[0]=='A') a[i].type=1; else a[i].type=2;
		read(a[i].x), read(a[i].y), read(a[i].d);
	}
	// for(int i=1;i<=n;i++) printf("%d ", a[i].type); puts("");
	ans=0;
	for(int i=-lim;i<=lim;i++){
		// cerr<<i<<endl;
		// printf("\n%d----\n\n", i);
		for(int j=-lim;j<=lim;j++) sum[j+lim]=0;
		for(int j=-lim;j<=lim;j++) for(int k=1;k<=4;k++) incline[k][j+lim]=0;
		// for(int j=-20;j<=10;j++) printf("%d ", sum[j]); puts("");
		int t=0;
		for(int j=1;j<=n;j++){
			int x=a[j].x, y=a[j].y, d=a[j].d/2;
			if(a[j].type==1){
				if(x-d<=i && x+d>i){
					// printf("%d %d\n", y-d, y+d);
					sum[y-d]++, sum[y+d]--;
				}
			}else{
				if(x-d<=i && x+d>i){
					int length=i-(x-d);
					if(x>i){
						sum[y-length]++, sum[y+length]--;
						incline[3][y-length-1]++, 
						incline[4][y-length-1]++,
						incline[2][y+length]++,
						incline[3][y+length]++;
					}else{
						length=x+d-i;
						sum[y-length+1]++, sum[y+length-1]--;
						incline[1][y-length]++, 
						incline[4][y-length]++,
						incline[1][y+length-1]++,
						incline[2][y+length-1]++;
					}
				}
			}
		}
		continue;
		int s=0;
		for(int j=-lim;j<=lim;j++){
			s+=sum[j];
			// if(sum[j]) printf("sum[ %d ] = %d\n", j, sum[j]);
			if(s>=1) ans+=1.0;
			else{
				int t=0;
				for(int k=1;k<=4;k++) t+=(bool)incline[k][j];
				ans+=1.0*t/4;
			}
		}
		// printf("%d %.2lf\n", i, ans);
	}
	printf("%.2lf\n", ans);
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
