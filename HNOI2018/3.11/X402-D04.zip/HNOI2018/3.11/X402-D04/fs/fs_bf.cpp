#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1<<16;
int k, q;
int a, d, m;

int p[maxn], cnt;

void init(){
	priority_queue<int,vector<int>,greater<int> > q;
	for(int i=(1<<(k-1));i<(1<<k);i++){
		q.push(i);
	}
	while(!q.empty()){
		int x=q.top(); q.pop();
		if(x==3) break;
		// printf("x = %d\n", x);
		p[++cnt]=x>>1;
		if(x&1) q.push(x>>1);
	}
	 printf("cnt = %d\n", cnt);
	 for(int i=1;i<=cnt;i++) printf("%d ", p[i]); puts("");
}

int main(){
	freopen("fs.in","r",stdin),freopen("fs.out","w",stdout);

	scanf("%d%d", &k, &q);
	init();
	while(q--){
		scanf("%d%d%d", &a, &d, &m);
		ll ans=0;
		for(int t=1,i=a;i<=m && t<=m;i+=d,t++){
			ans+=p[i];
		}
		printf("%lld\n", ans);
	}
	return 0;
}
