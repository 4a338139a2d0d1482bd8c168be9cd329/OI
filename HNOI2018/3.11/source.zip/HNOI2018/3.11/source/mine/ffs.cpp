#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
const int maxn=100010;
const int inf=1e9;
int n;
int a[maxn];
struct node{ 
	int x, y, id;
	int l, r;
	bool operator <(const node& A)const{ return x<A.x || (x==A.x && y<A.y); }
}q[maxn];
vector<pii> g[maxn], w[maxn];

void read(int &x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int Min[maxn<<2], add[maxn<<2];
void build(int o,int l,int r){
	if(l==r){ Min[o]=-l; return; }
	int mid=(l+r)>>1;
	build(o<<1,l,mid), build(o<<1|1,mid+1,r);
	Min[o]=min(Min[o<<1],Min[o<<1|1]);
}
void pushdown(int o){
	if(add[o]){
		add[o<<1]+=add[o], Min[o<<1]+=add[o];
		add[o<<1|1]+=add[o], Min[o<<1|1]+=add[o];
		add[o]=0;
	}
}
void modify(int o,int l,int r,int ql,int qr,int val){
	if(ql<=l && qr>=r){
		add[o]+=val; Min[o]+=val;
		return;
	}
	pushdown(o);
	int mid=(l+r)>>1;
	if(ql<=mid) modify(o<<1,l,mid,ql,qr,val); if(qr>mid) modify(o<<1|1,mid+1,r,ql,qr,val);
	Min[o]=min(Min[o<<1],Min[o<<1|1]);
}
int query(int o,int l,int r,int val){
	if(l==r) return l;
	pushdown(o);
	int mid=(l+r)>>1;
	if(Min[o<<1|1]==val) return query(o<<1|1,mid+1,r,val); return query(o<<1,l,mid,val);
}

struct Segment_Tree{
	int Min[maxn<<2], Max[maxn<<2];
	void clear(){ memset(Min,0x3f,sizeof(Min)); memset(Max,0,sizeof(Max)); }
	void modify(int o,int l,int r,int pos,int val){
		if(l==r){ Max[o]=Min[o]=val; return; }
		int mid=(l+r)>>1;
		if(pos<=mid) modify(o<<1,l,mid,pos,val); else modify(o<<1|1,mid+1,r,pos,val);
		Max[o]=max(Max[o<<1],Max[o<<1|1]), Min[o]=min(Min[o<<1],Min[o<<1|1]);
	}
	int querymin(int o,int l,int r,int ql,int qr){
		if(ql<=l && qr>=r) return Min[o];
		int mid=(l+r)>>1, ret=inf;
		if(ql<=mid) ret=querymin(o<<1,l,mid,ql,qr); if(qr>mid) ret=min(ret, querymin(o<<1|1,mid+1,r,ql,qr));
		return ret;
	}
	int querymax(int o,int l,int r,int ql,int qr){
		if(ql<=l && qr>=r) return Max[o];
		int mid=(l+r)>>1, ret=0;
		if(ql<=mid) ret=querymax(o<<1,l,mid,ql,qr); if(qr>mid) ret=max(ret, querymax(o<<1|1,mid+1,r,ql,qr));
		return ret;
	}
}T;

int st1[maxn], st2[maxn], top1, top2;
pii Ans[maxn];
int L[maxn], R[maxn];

void get(int* a,int* A){
	// puts("");
	// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
	build(1,1,n); memset(add,0,sizeof(add));
	top1=top2=0;
	st1[0]=n+1; st2[0]=n+1;
	for(int i=n;i>=1;i--){
		while(top1 && a[i]<a[ st1[top1] ]){
			int lst=st1[top1]; top1--;
			modify(1,1,n,lst,st1[top1]-1,a[lst]-a[i]);
		}
		st1[++top1]=i;

		while(top2 && a[i]>a[ st2[top2] ]){
			int lst=st2[top2]; top2--;
			modify(1,1,n,lst,st2[top2]-1,a[i]-a[lst]);
		}
		st2[++top2]=i;
		A[i]=query(1,1,n,-i);
	}
	// for(int i=1;i<=n;i++) printf("%d ", A[i]); puts("");
}

int main(){
	freopen("ffs.in","r",stdin),freopen("ffs.out","w",stdout);
	// freopen("0.in","r",stdin),freopen("ffs.out","w",stdout);

	read(n);
	for(int i=1;i<=n;i++) read(a[i]);
	get(a,R);
	// for(int i=1;i<=n;i++) printf("%d ", R[i]); puts("");
	reverse(a+1,a+1+n);
	get(a,L);
	for(int i=1;i<=n;i++) L[i]=n-L[i]+1;
	reverse(L+1,L+1+n);
	// for(int i=1;i<=n;i++) printf("L[ %d ] = %d\n", i, L[i]); puts("");
	int Q;
	read(Q);
	for(int i=1;i<=Q;i++){
		read(q[i].x), read(q[i].y);
		g[ q[i].x ].push_back(make_pair(i,q[i].y));
		w[ q[i].y ].push_back(make_pair(i,q[i].x));
	}
	T.clear();
	for(int i=1;i<=n;i++){
		T.modify(1,1,n,R[i],i);
		for(int j=0;j<g[i].size();j++){
			Ans[ g[i][j].fi ].fi=T.querymax(1,1,n,g[i][j].se,n);
		}
	}
	T.clear();
	for(int i=n;i>=1;i--){
		T.modify(1,1,n,L[i],i);
		// printf("%d\n", T.querymin(1,1,n,515,515));
		for(int j=0;j<w[i].size();j++){
			Ans[ w[i][j].fi ].se=T.querymin(1,1,n,1,w[i][j].se);
		}
	}
	for(int i=1;i<=Q;i++) printf("%d %d\n", Ans[i].fi, Ans[i].se);
	return 0;
}
