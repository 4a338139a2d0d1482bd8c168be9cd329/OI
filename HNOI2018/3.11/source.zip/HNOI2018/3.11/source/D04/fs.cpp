#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1<<16;
int k, q;
int a, d, m;

int p[maxn], cnt, deg[maxn];
vector<int> g[maxn];

void add(int x,int y){
	g[x].push_back(y), g[y].push_back(x); deg[x]++; deg[y]++;
}

int del[maxn];
void init(){
	priority_queue<int,vector<int>,greater<int> > q;
	for(int i=1;i<(1<<(k-1));i++){
		add(i,i<<1); add(i,i<<1|1);
	}
	for(int i=(1<<(k-1));i<(1<<k);i++){
		q.push(i);
	}
	while(!q.empty()){
		int x=q.top(); q.pop();
		del[x]=1;
		if(cnt==(1<<k)-3) break;
		// printf("x = %d\n", x);
		for(int i=0;i<g[x].size();i++){
			int v=g[x][i]; if(del[v]) continue;
			p[++cnt]=v; break;
		}
		for(int i=0;i<g[x].size();i++){
			int v=g[x][i]; if(del[v]) continue;
			if((--deg[v])==1) q.push(v);
		}
	}
	// printf("cnt = %d\n", cnt);
	// for(int i=1;i<=cnt;i++) printf("%d ", p[i]); puts("");
}

int main(){
	freopen("fs.in","r",stdin),freopen("fs.out","w",stdout);

	scanf("%d%d", &k, &q);
	init();
	while(q--){
		scanf("%d%d%d", &a, &d, &m);
		ll ans=0;
		for(int t=1,i=a;i<(1<<k) && t<=m;i+=d,t++){ ans+=p[i]; }
		printf("%lld\n", ans);
	}
	return 0;
}
