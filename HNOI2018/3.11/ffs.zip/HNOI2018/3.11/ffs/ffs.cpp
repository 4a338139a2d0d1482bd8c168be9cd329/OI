#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
const int maxn=100010;
const int inf=1e9;
int n, q;
int a[maxn];
int ql, qr;
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

void chkmin(int& x,int y){ if(x>y) x=y; }
void chkmax(int& x,int y){ if(x<y) x=y; }

int c[maxn];
int lowbit(int x){ return x&(-x); }
void add(int x,int val){
	while(x<maxn){ c[x]+=val; x+=lowbit(x); }
}
int sum(int x){
	int ret=0;
	while(x){ ret+=c[x]; x-=lowbit(x); }
	return ret;
}

void init(){
	for(int i=1;i<=n;i++){
		int l=a[i], r=a[i];
		for(int j=i;j<=n;j++){
			chkmin(l,a[j]); chkmax(r,a[j]);
			if(r-l+1==j-i+1) g[i].push_back(j);
		}
	}
	for(int i=1;i<=n;i++) sort(g[i].begin(),g[i].end());
}

int solve(int x){
	int l=0, r=g[x].size()-1, ret=inf;
	while(l<=r){
		int mid=(l+r)>>1;
		if(g[x][mid]>=qr) ret=mid, r=mid-1;
		else l=mid+1;
	}
	if(ret>=inf) return inf;
	return g[x][ret];
}

int main(){
	freopen("ffs.in","r",stdin),freopen("ffs.out","w",stdout);

	read(n);
	for(int i=1;i<=n;i++) read(a[i]);
	init();
	read(q);
	while(q--){
		read(ql), read(qr);
		int ans=n+1; pii A;
		for(int i=1;i<=ql;i++){
			int t=solve(i);
			if(t-i+1<ans){
				ans=t-i+1;
				A=make_pair(i,t);
			}
		}
		printf("%d %d\n", A.fi, A.se);
	}
	return 0;
}
