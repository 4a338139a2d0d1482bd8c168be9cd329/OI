#include<bits/stdc++.h>
using namespace std;

int a[1000000];
int main(){
	freopen("ffs.in","w",stdout);
	srand(time(0));
	puts("!");
	/*for(int i=1;i<=100000;++i){
		a[i]=i;	
	}
	for(int i=1;i<=1;++i){
		int x=rand()%100000+1;
		int y=rand()%100000+1;
		swap(a[x],a[y]);
	}
	puts("100000");
	for(int i=1; i<=100000; ++i) 
			printf("%d ",a[i]);
	
	puts("100000");
	for(int i=1;i<=100000;++i){
		int x=rand()%100000+1;
		int y=rand()%100000+1;
		if(x>y)swap(x,y);
		printf("%d %d\n",x,y);
	}*/
}
