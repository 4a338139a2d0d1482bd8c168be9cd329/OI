#include<bits/stdc++.h>
#define getchar getchar_unlocked
const int N=1e5+10;
using namespace std;

int a[N],n,q,ps[N];

inline int read(){
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}

inline int ckmx(int a,int b){return a>b?a:b;}
inline int ckmn(int a,int b){return a<b?a:b;}

struct segt{
	#define l(x) (x<<1)
	#define r(x) ((x<<1)|1)
	#define mm ((l+r)>>1)
	int mx[N<<2],mn[N<<2];
	void init(int x,int l,int r){
		if(l==r){
		 	mx[x]=a[l];
			mn[x]=a[l];
			return;
		}
		init(l(x),l,mm);init(r(x),mm+1,r);
		mx[x]=ckmx(mx[l(x)],mx[r(x)]);
		mn[x]=ckmn(mn[l(x)],mn[r(x)]);
	}
	void init2(int x,int l,int r){
		if(l==r){
			mx[x]=ps[l];
			mn[x]=ps[l];
			return;
		}
		init2(l(x),l,mm);init2(r(x),mm+1,r);
		mx[x]=ckmx(mx[l(x)],mx[r(x)]);
		mn[x]=ckmn(mn[l(x)],mn[r(x)]);
	}
	int gtmx(int x,int l,int r,int ql,int qr){
		if(ql<=l&&r<=qr) return mx[x];
		else{
			int v=0;
			if(ql<=mm) v=ckmx(v,gtmx(l(x),l,mm,ql,qr));
			 if(mm<qr) v=ckmx(v,gtmx(r(x),mm+1,r,ql,qr));
			return v;
		}
	}
	int gtmn(int x,int l,int r,int ql,int qr){
		if(ql<=l&&r<=qr) return mn[x];
		else{
			int v=0x3f3f3f3f;
			if(ql<=mm) v=ckmn(v,gtmn(l(x),l,mm,ql,qr));
			 if(mm<qr) v=ckmn(v,gtmn(r(x),mm+1,r,ql,qr));
			return v;
		}
	}
};
struct segt t1,t2;

namespace solver{
	void find(int l,int r){
		while(1){
			int nl=t1.gtmn(1,1,n,l,r);
			int nr=t1.gtmx(1,1,n,l,r);
			if(r-l==nr-nl) break;
			int tl=0,tr=0;
			tl=t2.gtmn(1,1,n,nl,nr);
			if(tl<l) l=tl; else{
				tr=t2.gtmx(1,1,n,nl,nr);
				if(r<tr) r=tr;
			}
		}
		printf("%d %d\n",l,r);
	}

	void solve(){
		n=read();
		for(int i=1;i<=n;++i)a[i]=read(),ps[a[i]]=i;
		t1.init(1,1,n);
		t2.init2(1,1,n);
		
		q=read();
		int l=0,r=0;
		for(int i=1;i<=q;++i){
			l=read();r=read();
			find(l,r);
		}
	}
}

int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	solver::solve();

}
