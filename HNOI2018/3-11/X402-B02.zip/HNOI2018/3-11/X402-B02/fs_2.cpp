#include<bits/stdc++.h>
const int N=1000000+10;
using namespace std;

priority_queue<int, vector<int>, greater<int> > q;

int n,cnt,qq;
int f[N],z[N];

namespace fk{
	void dfs(int x){
		if(x<=printf("__%d\n",x);
		int y=x*2;
		int z=x*2+1;
		if(y<(1<<n))dfs(y);
		printf("__%d\n",x);
		if(z<(1<<n))dfs(z);
	}
	int deg[N];
	void solve(){
		dfs(1);
		for(int i=1;i<=(1<<n)-1;++i){
			if(i>1){
				deg[i]++;
				deg[i>>1]++;f[i]=(i>>1);
			}
		}
		for(int i=1;i<=(1<<n)-1;++i) if(deg[i]==1) q.push(i);
		while(!q.empty()){
			int x=q.top(); q.pop();
			if(f[x]){
				z[++cnt]=f[x];
				--deg[f[x]];
				if(deg[f[x]]==1) q.push(f[x]);
			}
		}

		for(int i=1;i<=cnt;++i)printf("_%d\n",z[i]);
	
		int a,d,m;
		for(int i=1;i<=qq;++i){
			scanf("%d%d%d",&a,&d,&m);
			long long rec=0;
			for(int j=0;j<m;++j){
				rec+=z[a+j*d];
			}
			printf("%lld\n",rec);
		}
	}
}

int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	scanf("%d%d",&n,&qq);
	fk::solve();
}
