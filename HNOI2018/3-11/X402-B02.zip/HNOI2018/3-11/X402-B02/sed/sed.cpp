#include<bits/stdc++.h>
#define ll unsigned long long 
using namespace std;

ll a[10000];
int n;
ll m;
int main(){
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; ++i) scanf("%lld",&a[i]);
	scanf("%lld",&m);
	for(int i=0; i<(1<<n); ++i){
		ll ret=0;
		for(int j=1;j<=n;++j) if((1ll<<(1ll*j-1ll))&i){
			ret+=a[j];
		}
		if(ret==m){
			for(int j=1;j<=n;++j) printf("%d",(bool)((1ll<<(1ll*j-1ll))&i));
			break;
		}
	}
}
