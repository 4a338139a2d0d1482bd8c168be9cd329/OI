#include<bits/stdc++.h>
using namespace std;
int main(){
	int n=100,m=500;
	freopen("skd.in","w",stdout);

	printf("%d %d %d\n",n,m,10);
	int x=0;
	for(int i=2;i<=n;++i){
		++x;
		int a=rand()%(i-1)+1;
		int b=rand()%(i-1)+1;
		printf("%d %d %d\n",a,b,
			rand()%1000);
	}
	for(int i=x+1;i<=m;++i){
		int a=rand()%n+1;
		int b=rand()%n+1;
		int c=rand()%1000;
		printf("%d %d %d\n",a,b,c);
	}
}
