#include<bits/stdc++.h>
const int N=4000;
const int E=2000;
using namespace std;

int n;
bool a[N+10][N+10],b[N+10][N+10],c[N+10][N+10],e[N+10][N+10];
char str[10];
int dx[4]={0,0,1,1};
int dy[4]={0,1,0,1};

namespace gt{
	

}


namespace fk{
	int abs(int x){return x>0?x:-x;}
	void solve(){
		scanf("%d",&n);
		int x,y,yx,yy,d;
		for(int v=1; v<=n; ++v){
			scanf("%s%d%d%d",str,&x,&y,&d);
			yx=x; yy=y;
			if(str[0]=='A'){
				x-=d/2; y-=d/2;
				for(int j=0;j<d;++j)  
					for(int k=0;k<d;++k){
					 a[x+j+E][y+k+E]=b[x+j+E][y+k+E]=1;
					 c[x+j+E][y+k+E]=e[x+j+E][y+k+E]=1;
				  }
			}
			if(str[0]=='B'){
				x=yx-d/2;y=yy;
				for(int j=0; j<d/2; ++j){
					a[x+E][y+E]=b[x+E][y+E]=1;	
					++x;++y;
				}
				x=yx-d/2;y=yy-1;
				for(int j=0; j<d/2; ++j){
					b[x+E][y+E]=c[x+E][y+E]=1;
					++x;--y;
				}
				x=yx;y=yy+d/2-1;
				for(int j=0; j<d/2; ++j){
					a[x+E][y+E]=e[x+E][y+E]=1;
					++x;--y;
				}

				x=yx;y=yy-d/2;
				for(int j=0; j<d/2; ++j){
					c[x+E][y+E]=e[x+E][y+E]=1;
					++x;--y;
				}
				x=yx;y=yy;
				for(int j=yx-d/2;j<=yx+d/2; ++j)
					for(int k=yy-d/2; k<=yy+d/2; ++k){
						int flag=1;
						for(int v=0;v<=3;++v){
							int tx=j+dx[v];
							int ty=k+dy[v];
							if(abs(tx-x)+abs(ty-y)>d/2){
								flag=0;
								break;
							}
						}
						if(flag){
							a[j+E][k+E]=b[j+E][k+E]=1;
							c[j+E][k+E]=e[j+E][k+E]=1;
						}
				}
			}
		}

		int ret=0;
		for(int i=0; i<N; ++i)
			for(int j=0; j<N; ++j)
				ret+=a[i][j]+b[i][j]+c[i][j]+e[i][j];
		printf("%.2lf\n",ret*0.25);
	}
}

int main(){
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
	fk::solve();
}
