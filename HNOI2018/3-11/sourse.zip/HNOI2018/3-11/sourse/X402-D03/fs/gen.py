from random import *
import sys

sys.stdout = open("fs.in", "w")

K = randint(4, 6)
Q = randint(100, 100)
print(K, Q)

for i in range(Q):
    a = randint(1, (1<<K)-3)
    d = randint(1, 1000000)
    m = randint(1, int(((1<<K)-3-a)/d)+1)
    print(a, d, m)
