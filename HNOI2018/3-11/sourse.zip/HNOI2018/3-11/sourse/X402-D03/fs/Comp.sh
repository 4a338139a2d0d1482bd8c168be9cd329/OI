while true; do
	echo ">>> gen"
	python3 gen.py
	echo ">>> bf"
	./bf
	echo ">>> fs"
	./fs
	if diff ./bf.out ./fs.out;
	then 
		continue
	else
		break
	fi
done
