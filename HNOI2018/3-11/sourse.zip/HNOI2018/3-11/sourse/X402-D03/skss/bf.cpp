#include<bits/stdc++.h>
using namespace std;

#define CNT(x) __builtin_popcount(x)

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n;

namespace PlanA {
	const int MAXN = 2010;
	int C[MAXN<<1][MAXN<<1];
	int h[MAXN<<1][MAXN<<1];
	inline void solve() {
		int i, j;
		char s[10];
		for(i = 1; i <= n; i++) {
			scanf("%s", s);
			int x = read(), y = read(), d = read()>>1;
			if(s[0] == 'A') {
				for(j = x-d; j < x+d; j++) 
					C[j+MAXN][y-d+MAXN]++, C[j+MAXN][y+d+MAXN]--;
			}
			else {
				for(j = x-d; j < x; j++) {
					h[j+MAXN][y+d-x+j+MAXN] |= 1;
					h[j+MAXN][y-d+x-j-1+MAXN] |= 4;
					C[j+MAXN][y-d+x-j+MAXN]++;
					C[j+MAXN][y+d-x+j+MAXN]--;
				}
				for(j = x; j < x+d; j++) {
					h[j+MAXN][y+d-(j-x)-1+MAXN] |= 2;
					h[j+MAXN][y-d+(j-x)+MAXN] |= 8;
					C[j+MAXN][y-d+(j-x)+1+MAXN]++;
					C[j+MAXN][y+d-(j-x)-1+MAXN]--;
				}
			}
		}
		/*for(j = 15; j >= -11; j--) {
			for(i = -11; i <= 11; i++) 
				printf("%2d ", C[i+MAXN][j+MAXN]);
			printf("\n");
		}
		printf("\n");
		exit(0);*/
		double ans = 0;
		for(i = -2000; i <= 2000; i++) {
			for(j = -2000; j <= 2000; j++) {
				C[i+MAXN][j+MAXN] += C[i+MAXN][j-1+MAXN];
				if(C[i+MAXN][j+MAXN] > 0) ans++;
				else {
					int c = CNT(h[i+MAXN][j+MAXN]);
					if(c == 0) continue;
					if(c == 1) ans += 0.5;
					else if(c == 2) {
						if(h[i+MAXN][j+MAXN] == 9 || h[i+MAXN][j+MAXN] == 6) ans += 1;
						else ans += 0.75;
					}
					else ans += 1;
				}
			}
		}
		printf("%.2lf\n", ans);
	}
}

namespace PlanB {
	const int MAXN = 200010;
	const int Base = 2010;
	int C[Base<<1][Base<<1];
	inline void solve() {
		int i, j;
		char s[10];
		for(i = 1; i <= n; i++) {
			scanf("%s", s);
			int x = read(), y = read(), d = read()>>1;
			C[x-d+Base][y-d+Base]++;
			C[x-d+Base][y+d+Base]--;
			C[x+d+Base][y-d+Base]--;
			C[x+d+Base][y+d+Base]++;
		}
		double ans = 0;
		for(i = -2000; i <= 2000; i++)
			for(j = -2000; j <= 2000; j++) {
				C[i+Base][j+Base] += C[i-1+Base][j+Base]+C[i+Base][j-1+Base]-C[i-1+Base][j-1+Base];
				if(C[i+Base][j+Base] > 0) ans += 1.0;
			}
		printf("%.2lf\n", ans);
	}
}

int main() {
	freopen("skss.in", "r", stdin);
	freopen("skss.out", "w", stdout);

	n = read();
	if(n <= 1000) PlanA::solve();
	else PlanB::solve();
	return 0;
}
