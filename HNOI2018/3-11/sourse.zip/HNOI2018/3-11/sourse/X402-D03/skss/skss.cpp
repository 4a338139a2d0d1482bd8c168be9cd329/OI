#include<bits/stdc++.h>
using namespace std;

#define CNT(x) __builtin_popcount(x)

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n;

namespace PlanB {
	const int MAXN = 200010;
	const int Base = 2010;
	int C[Base<<1][Base<<1], sum[Base<<1][Base<<1];
	int h[4][Base<<1][Base<<1];
	int a[Base<<1][Base<<1], b[Base<<1][Base<<1];
	inline void solve() {
		int i, j, k;
		char s[10];
		for(i = 1; i <= n; i++) {
			scanf("%s", s);
			int x = read()+Base, y = read()+Base, d = read()>>1;
			if(s[0] == 'A') {
				C[x-d][y-d]++;
				C[x-d][y+d]--;
				C[x+d][y-d]--;
				C[x+d][y+d]++;
			}
			else {
				h[0][x-d][y]++;
				h[0][x][y+d]--;
				h[1][x][y+d-1]++;
				h[1][x+d][y-1]--;
				h[2][x-d][y-1]++;
				h[2][x][y-d-1]--;
				h[3][x][y-d]++;
				h[3][x+d][y]--;
				a[x-d+1][y]++;
				a[x][y+d-1]--;
				a[x+1][y-d+1]--;
				a[x+d][y]++;
				b[x+1][y+d-2]--;
				b[x+d][y-1]++;
				b[x-d+1][y-1]++;
				b[x][y-d]--;
			}
		}
		double ans = 0;
		cerr << clock() << endl;
		for(k = -3020; k <= 3020; k++) {
			int st = k <= 0? -1510 : k-1510, ed = k >= 0 ? 1510 : k+1510;
			j = st-k;
			for(i = st; i <= ed; i++, j++) {
				h[0][i+Base][j+Base] += h[0][i-1+Base][j-1+Base];
				h[3][i+Base][j+Base] += h[3][i-1+Base][j-1+Base];
				a[i+Base][j+Base] += a[i-1+Base][j-1+Base];
			}
		}
		cerr << clock() << endl;
		for(k = -3020; k <= 3020; k++) {
			int st = k <= 0 ? -1510 : k-1510, ed = k >= 0 ? 1510 : k+1510;
			j = k-st;
			for(i = st; i <= ed; i++, j--) {
				h[1][i+Base][j+Base] += h[1][i-1+Base][j+1+Base];
				h[2][i+Base][j+Base] += h[2][i-1+Base][j+1+Base];
				b[i+Base][j+Base] += b[i-1+Base][j+1+Base];
			}
		}
		cerr << clock() << endl;
		for(i = -1510; i <= 1510; i++)
			for(j = -1510; j <= 1510; j++) {
				C[i+Base][j+Base] += C[i-1+Base][j+Base]+C[i+Base][j-1+Base]-C[i-1+Base][j-1+Base];
				sum[i+Base][j+Base] = sum[i-1+Base][j+Base]+a[i+Base][j+Base]+b[i+Base][j+Base];
				if(C[i+Base][j+Base] > 0 || sum[i+Base][j+Base] > 0) {
					ans += 1.0;
					continue;
				}
				int c = 0, cn;
				for(k = 0; k < 4; k++) if(h[k][i+Base][j+Base]) c |= (1<<k);
				cn = CNT(c);
				if(cn == 0) continue;
				if(cn == 1) ans += 0.5;
				else if(cn == 2) {
					if(c == 9 || c == 6) ans += 1;
					else ans += 0.75;
				}
				else ans += 1;
			}
		printf("%.2lf\n", ans);
		cerr << clock() << endl;
	}
}

int main() {
	freopen("skss.in", "r", stdin);
	freopen("skss.out", "w", stdout);

	n = read();
	PlanB::solve();
	return 0;
}
