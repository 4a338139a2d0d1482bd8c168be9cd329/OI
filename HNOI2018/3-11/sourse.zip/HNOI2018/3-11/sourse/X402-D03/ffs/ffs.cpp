#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, q;
int p[MAXN], c[MAXN];
bool buc[MAXN];

int main() {
	freopen("ffs.in", "r", stdin);
	freopen("ffs.out", "w", stdout);

	int i;
	n = read();
	for(i = 1; i <= n; i++) c[p[i] = read()] = i;
	q = read();
	while(q--) {
		int x = read(), y = read();
		int mn = n+1, mx = 0;
		for(i = x; i <= y; i++) {
			buc[p[i]] = true;
			mn = min(mn, p[i]);
			mx = max(mx, p[i]);
		}
		//printf(">>> %d %d\n", mn, mx);
		int a = x, b = y;
		for(i = mn; i <= mx; i++) {
			if(!buc[i]) {
				//printf("!\n");
				a = min(a, c[i]);
				b = max(b, c[i]);
			}
			else buc[i] = false;
		}
		printf("%d %d\n", a, b);
	}
	return 0;
}
