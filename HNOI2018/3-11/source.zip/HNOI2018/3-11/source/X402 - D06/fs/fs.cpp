#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e5+10;
const int maxm=2e5+10;
priority_queue <int,vector<int>,greater<int> > q;
int to[maxm],nex[maxm],beg[maxn],vis[maxn],prufer[maxn],deg[maxn];
int e;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
int main(){
	int i,j,k,m,n,Q;
#ifndef ONLINE_JUDGE
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
#endif
	k=read();Q=read();
	for(i=1;i<(1<<(k-1));i++){
		add(i,i<<1),add(i,i<<1|1);
		add(i<<1,i),add(i<<1|1,i);
		deg[i]+=2;deg[i<<1]++;deg[i<<1|1]++;
	}
	for(i=1;i<(1<<k);i++)
		if(deg[i]==1)q.push(i);
	int cnt=0;
	while(!q.empty()){
		int x=q.top();q.pop();
		int id=0;
		for(i=beg[x];i;i=nex[i]){
			if(vis[to[i]])continue;
			id=to[i];break;
		}
		prufer[++cnt]=id;vis[x]=1;
		if(cnt==(1<<k)-3)break;
		for(i=beg[x];i;i=nex[i]){
			if(vis[to[i]])continue;
			deg[to[i]]--;
			if(deg[to[i]]==1)q.push(to[i]);
		}
	}
	while(Q--){
		int a=read(),d=read();m=read();
		ll ans=0;
		for(i=a;i<=a+(m-1)*d;i+=d)ans+=1ll*prufer[i];
		printf("%lld\n",ans);
	}
	return 0;
}

