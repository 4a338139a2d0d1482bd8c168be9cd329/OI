#include<set>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e3+10;
int a[maxn],pos[maxn];
set <int> L,R;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void Insert(int Min,int Max,int l,int r){
	int i;
	for(i=Min;i<=Max;i++){
		if(pos[i]>=l && pos[i]<=r)continue;
		if(pos[i]<l)L.insert(i);
		if(pos[i]>r)R.insert(i);
	}
}
int main(){
	int i,j,k,m,n,q;
#ifndef ONLINE_JUDGE
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
#endif
	n=read();for(i=1;i<=n;i++)a[i]=read();
	for(i=1;i<=n;i++)pos[a[i]]=i;
	q=read();
	while(q--){
		int l=read(),r=read(),Max=0,Min=n+1;
		for(i=l;i<=r;i++){
			Min=min(Min,a[i]);
			Max=max(Max,a[i]);
		}
		Insert(Min,Max,l,r);
		while(!L.empty() || !R.empty()){
			while(!L.empty() && l>1){
				l--;
				if(a[l]>=Min && a[l]<=Max)L.erase(a[l]);
				if(a[l]<Min)Insert(a[l]+1,Min-1,l,r),Min=a[l];
				if(a[l]>Max)Insert(Max+1,a[l]-1,l,r),Max=a[l];
			}
			while(!R.empty() && r<n){
				r++;
				if(a[r]>=Min && a[r]<=Max)R.erase(a[r]);
				if(a[r]<Min)Insert(a[r]+1,Min-1,l,r),Min=a[r];
				if(a[r]>Max)Insert(Max+1,a[r]-1,l,r),Max=a[r];
			}
		}
		printf("%d %d\n",l,r);
	}
	return 0;
}

