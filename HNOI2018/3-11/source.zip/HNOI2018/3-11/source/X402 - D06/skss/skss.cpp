#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=2e3+10;
int mp[maxn<<1][maxn<<1];
int mp1[maxn<<1][maxn<<1],mp2[maxn<<1][maxn<<1];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,q;
#ifndef ONLINE_JUDGE
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
#endif
	q=read();
	while(q--){
		char ch=getchar();
		while(!isalpha(ch))ch=getchar();
		if(ch=='A'){
			int x=read(),y=read(),a=read();
			a/=2;x+=maxn;y+=maxn;
			mp[x-a][y-a]++;mp[x-a][y+a]--;mp[x+a][y-a]--;mp[x+a][y+a]++;
		}
		else{
			int x=read(),y=read(),a=read();
			a/=2;x+=maxn;y+=maxn;
			for(i=x-a;i<x;i++){
				int cnt=i-x+a;
				mp1[i][y-cnt]++;mp1[i][y+cnt]--;
				mp2[i][y-cnt-1]|=9;mp2[i][y+cnt]|=12;
			}
			for(i=x;i<x+a;i++){
				int cnt=x+a-i-1;
				mp1[i][y-cnt]++;mp1[i][y+cnt]--;
				mp2[i][y-cnt-1]|=3;mp2[i][y+cnt]|=6;
			}
		}
	}
	int lim=(maxn<<1)-5;
	double ans=0;
	for(i=1;i<=lim;i++)
		for(j=1;j<=lim;j++){
			mp[i][j]=(mp[i][j-1]+mp[i-1][j]-mp[i-1][j-1]+mp[i][j]);
			if(mp[i][j]>=1)ans++;
		}
	for(i=1;i<=lim;i++)
		for(j=1;j<=lim;j++){
			mp1[i][j]=mp1[i][j-1]+mp1[i][j];
			if(mp1[i][j]>=1 && mp[i][j]==0)ans++;
		}
	for(i=1;i<=lim;i++)
		for(j=1;j<=lim;j++)
			if(mp2[i][j] && mp[i][j]==0 && mp1[i][j]==0)
				ans+=0.25*__builtin_popcount(mp2[i][j]);
	printf("%.2lf\n",ans);
	return 0;
}

