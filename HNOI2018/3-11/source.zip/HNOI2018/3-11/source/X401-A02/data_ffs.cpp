#include<bits/stdc++.h>
using namespace std;
int vis[100001];
bool judge(){
	for(int i=1;i<=10000;++i)
		if(!vis[i])
			return 0;
	return 1;	
}
int main(){
	srand(time(NULL));
	int fa=rand();
	srand(fa);
	freopen("ffs.in","w",stdout);
	int n=10000;
	printf("%d\n",n);
	while(!judge()){
		int ovo=rand()%10000+1;	
		if(!vis[ovo]){
			vis[ovo]=1;
			printf("%d ",ovo);
		}
	}
	cout<<endl<<n<<endl;
	for(int i=1;i<=10000;++i){
		int l=rand()%10000+1,r=rand()%10000+1;	
		if(l>r)
			swap(l,r);
		printf("%d %d\n",l,r);
	}
	return 0;
}

