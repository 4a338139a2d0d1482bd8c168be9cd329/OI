#include<bits/stdc++.h>
using namespace std;

const int maxn=(1<<15)+10;
int cnt,a[maxn],size[maxn];
priority_queue<int,vector<int>,greater<int> >q;

int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	size[1]=2;
	for(int i=2;i<(1<<(n-1));++i)
		size[i]=3;
	for(int i=(1<<(n-1));i<(1<<n);++i)
		size[i]=1,q.push(i);
	while(cnt<(1<<n)-3){
		int k=q.top();q.pop();
		--size[k];
		if(size[k/2]>=1)
			a[++cnt]=k/2;
		if(size[k*2+1]>=1)
			a[++cnt]=k*2+1;
		if(size[k*2]>=1)
			a[++cnt]=k*2;
		if(size[k/2])--size[k/2];if(size[k/2]==1) q.push(k/2);
		if(size[k*2])--size[k*2];if(size[k*2]==1) q.push(k*2);
		if(size[k*2+1])--size[k*2+1];if(size[k*2+1]==1) q.push(k*2+1);
	}
//	for(int i=1;i<=cnt;++i)
//		cout<<a[i];
	int x,y,z;
	while(m--){
		scanf("%d%d%d",&x,&y,&z);
		long long ans=0;
		for(int i=0;i<z;++i)
			ans+=a[x+i*y];
		printf("%lld\n",ans);
	}
	return 0;
}

