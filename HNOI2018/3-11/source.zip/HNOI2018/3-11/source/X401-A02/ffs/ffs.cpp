#include<bits/stdc++.h>
#define inf (0x3f3f3f3f)
using namespace std;

const int maxn=1e5+10;
int a[maxn],n;


int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	int x,y,m;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	scanf("%d",&m);
	while(m--){
		scanf("%d%d",&x,&y);
		int l=x,r=y,maxx=-inf,minn=inf;
		for(int i=x;i<=y;++i)
			maxx=max(maxx,a[i]),minn=min(minn,a[i]);
		while(maxx-minn!=r-l){
			int rr=r+1,ll=l-1;
			if(rr==n+1){
				l=ll,maxx=max(maxx,a[ll]),minn=min(minn,a[ll]);		
				continue;
			}
			if(ll==0){
				++r;
				r=rr,maxx=max(maxx,a[rr]),minn=min(minn,a[rr]);
				continue;	
				
			}
			int pr=max(abs(a[rr]-maxx),abs(a[rr]-minn)),pl=max(abs(a[ll]-maxx),abs(a[ll]-minn));
			if(pl<=pr)
				l=ll,maxx=max(maxx,a[ll]),minn=min(minn,a[ll]);
			else
				r=rr,maxx=max(maxx,a[rr]),minn=min(minn,a[rr]);
		}
		printf("%d %d\n",l,r);
	}
	return 0;
}

