#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 3013, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
}
struct ufs{
	int f[N];
	void init(){For(i, 1, 3000)f[i] = i;}
	inline int find(int x){
		int k, j, r;
		r = x;
		while(r != f[r])r = f[r];      
		k = x;        
		while(k != r)j = f[k], f[k] = r, k = j;              
		return r;         
	}
	inline void link(int x, int y){
		x = find(x), y = find(y);
		f[x] = y;
	} 
}F[N];
int n;
short a[N][N];
char s[10];
void init(){
	read(n);
	For(i, 1, 3000)F[i].init();
}

double ans = 0;
inline void check(int i, int j){
	if(a[i][j] == 15 || (a[i][j] & 3) == 3 || (a[i][j] & 12) == 12) {
		a[i][j] = 15;
		ans ++ ;
		if(a[i][j - 1] == 15)F[i].link(j - 1, j);
	}
}
void solve(){
	int mix=3001,miy=3001,mxx=1,mxy=1;
	while(n--){
		int x, y, d;
		scanf("%s",s);
		read(x), read(y), read(d);
		x += 1501, y += 1501;
		if(s[0] == 'A'){
			d /= 2;
			mix = min(mix, x - d);
			mxx = max(mxx, x + d - 1);
			miy = min(miy, y - d);
			mxy = max(mxy, y + d - 1);
			For(i, x - d, x + d - 1){
				For(j, y - d, y + d - 1){
					int t = F[i].find(j);
					if(a[i][t] == 15)t++;
					if(t > y + d - 1)break;
					j = t;
					if(a[i][j] != 15) ans++, a[i][j] = 15;
					if(a[i][j - 1] == 15)F[i].link(j - 1, j);
				}
			}
		}else {
			d /= 2;
			mix = min(mix, x - d);
			mxx = max(mxx, x + d - 1);
			miy = min(miy, y - d);
			mxy = max(mxy, y + d - 1);
			For(i, x - d, x + d - 1){
				int l = (i < x) ? y - (i - (x - d) + 1) : y - (d - (i - x));
				int r = y + (y - l) - 1;
				For(j, l + 1, r - 1){
					int t = F[i].find(j);
					if(a[i][t] == 15)t++;
					if(t > r - 1)break;
					j = t;
					if(a[i][j]!=15)a[i][j] = 15, ans++;
					if(a[i][j - 1] == 15)F[i].link(j - 1, j);
				}
				if(a[i][l] != 15)a[i][l] |= (i<x)?1:8, check(i, l);
				if(a[i][r] != 15)a[i][r] |= (i<x)?4:2, check(i, r);
			}
		}
	}
	#define count __builtin_popcount
	For(i, mix, mxx)
		For(j, miy, mxy)
			if(a[i][j] != 15){
				if(count(a[i][j]) == 1)ans += 0.5;
				else if(count(a[i][j]) == 2)ans += 0.75;
			}
	printf("%.2lf\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
