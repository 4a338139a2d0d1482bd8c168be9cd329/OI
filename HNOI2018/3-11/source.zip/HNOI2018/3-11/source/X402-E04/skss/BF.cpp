
#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 3010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("skss.in","r",stdin);
	freopen("skss1.out","w",stdout);
}

int n, a[N][N], cnt[N];
char s[10];
void init(){
	read(n);
}

double ans = 0;

void solve(){
	int mix=3001,miy=3001,mxx=1,mxy=1;
	while(n--){
		int x, y, d;
		scanf("%s",s);
		read(x), read(y), read(d);
		x += 1501, y += 1501;
		if(s[0] == 'A'){
			d /= 2;
			mix = min(mix, x - d);
			mxx = max(mxx, x + d - 1);
			miy = min(miy, y - d);
			mxy = max(mxy, y + d - 1);
			For(i, x - d, x + d - 1)
				For(j, y - d, y + d - 1)
					a[i][j] = 15;		
		}else {
			d /= 2;
			mix = min(mix, x - d);
			mxx = max(mxx, x + d - 1);
			miy = min(miy, y - d);
			mxy = max(mxy, y + d - 1);
			For(i, x - d, x + d - 1){
				int l = (i < x) ? y - (i - (x - d) + 1) : y - (d - (i - x));
				int r = y + (y - l) - 1;
				For(j, l + 1, r - 1){
					a[i][j] = 15;
				}
				if(i < x){
					if(a[i][l] != 15)a[i][l] |= 1;
					if(a[i][r] != 15)a[i][r] |= 4;				
				}else {
					if(a[i][l] != 15)a[i][l] |= 8;
					if(a[i][r] != 15)a[i][r] |= 2;
				}
			}
		}
	}
	#define count __builtin_popcount
	For(i, mix, mxx)
		For(j, miy, mxy)
			if(a[i][j] != 15){
				if(count(a[i][j]) == 1)ans += 0.5;
				else if(count(a[i][j]) == 2)ans += 0.75;
			}else ans++;
	printf("%.2lf\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
