#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;


int main(){
	int n = 200000, m = 1000;
	freopen("skss.in","w",stdout);
	srand(time(0));
	printf("%d\n",n);
	For(i,1,n){
		int x = rand() % m - rand()%m , 
		    y = rand() % m - rand()%m ,
			d = rand() % m ;
		printf("%c %d %d %d\n",rand()%2?'A':'A',x, y, d);
	}
	return 0;
}
