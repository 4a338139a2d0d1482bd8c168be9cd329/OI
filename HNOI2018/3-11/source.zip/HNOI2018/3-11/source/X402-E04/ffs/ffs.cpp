#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}
int n, a[N], f[N][N];
void init(){
	read(n);
	For(i, 1, n)read(a[i]);
	For(i, 1, n){
		int mx = 0, mi = n + 1;
		For(j, i, n){
			mx = max(mx, a[j]), mi = min(mi, a[j]);
			if(mx - mi == j - i)f[i][j] = j - i;
			else f[i][j] = n + 1;
		}
		Forr(j, n-1, i)
			f[i][j] = min(f[i][j], f[i][j + 1]);
	}
}
void solve(){
	int q;
	read(q);
	while(q--){
		int x, y, mi = n + 1, pos = 0;
		read(x), read(y);
		For(i, 1, x){
			if(f[i][y] < mi)
				mi = f[i][y], pos = i;
		}
		printf("%d %d\n", pos, pos + mi);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
