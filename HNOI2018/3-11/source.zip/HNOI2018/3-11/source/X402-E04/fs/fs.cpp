#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
priority_queue<int, vector<int>, greater<int> >q;
inline void file(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
}
int K, Q, deg[N];
int p[N], m, Begin[N], to[N<<1], Next[N<<1], e;
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
void init(){
	read(K), read(Q);
	For(i, 1, (1<<K) - 1)deg[i] = 3;
	deg[1] = 2;
	For(i, (1<<(K-1)), (1<<K) - 1)deg[i] = 1, q.push(i);
	For(i, 2, (1<<K) - 1)add(i, i / 2), add(i / 2, i);
}
#define Rep(i,u) for(int i = Begin[u], v=to[i];i;i=Next[i],v=to[i])
int vis[N];
void solve(){
	while(!q.empty()){
		int r = q.top();q.pop();vis[r] = 1;
		Rep(i, r)
			if(!vis[v]){
				deg[v] --;
				if(deg[v] == 1)q.push(v);
				p[++m] = v;
			}
	}
	m-=2;
	while(Q--){
		int a, d, l;
		ll ans = 0;
		read(a), read(d), read(l);
		For(i, 0, l - 1)ans += p[i * d + a];
		printf("%lld\n" ,ans);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
