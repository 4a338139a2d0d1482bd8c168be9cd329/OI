#include<iostream>
#include<cstdio>
#include<cstring>

namespace WoDouGanLeXieShenMeAAAAA_____A__A_A_A_holy_shit
{
	const int N=200010,M=5040;

	int cnta[M][M],cntb[M][M];
	bool all[M][M],pat[M][M][4];

	int n;

	void initialize()
	{
		scanf("%d",&n);
		char ty[2];int x,y,z;
		for(int i=1;i<=n;i++)
		{
			scanf("%s %d %d %d",ty,&x,&y,&z);

			x+=M/2,y+=M/2,z/=2;
			if(ty[0]=='A')
			{
				cnta[x-z][y-z]++;
				cnta[x-z][y+z]--;
				cnta[x+z][y-z]--;
				cnta[x+z][y+z]++;
			}
			else
			{
				cntb[x-z+1][y]++;
				cntb[x+1][y+z]--;
				cntb[x+1][y-z]--;
				cntb[x+z+1][y]++;
			}
		}

		for(int i=1;i<M;i++)
			for(int j=1;j<M;j++)
			{
				cnta[i][j]+=cnta[i-1][j]+cnta[i][j-1]-cnta[i-1][j-1];
				cntb[i][j]+=cntb[i-1][j-1]+cntb[i-1][j+1]-(i>1?cntb[i-2][j]:0);
			}

		for(int i=1;i<M;i++)
			for(int j=1;j<M;j++)
			{
				if(cnta[i][j])all[i][j]=1;
				if(cntb[i][j])
				{
					pat[i][j][0]=1;
					pat[i-1][j][3]=1;
					pat[i][j-1][2]=1;
					pat[i-1][j-1][1]=1;
				}
			}
	}

	double getans()
	{
		double ret=0;
		for(int i=1;i<M;i++)
			for(int j=1;j<M;j++)
			{
				int a=0,b=0,c=0,d=0;
				if(all[i][j])a=b=c=d=1;
				if(pat[i][j][0])d=c=1;
				if(pat[i][j][1])a=b=1;
				if(pat[i][j][2])a=d=1;
				if(pat[i][j][3])b=c=1;

				ret+=(a+b+c+d)*0.25;
			}
		return ret;
	}

	void solve()
	{
		initialize();
		printf("%.2lf\n",getans());
	}
}

int main()
{
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
	WoDouGanLeXieShenMeAAAAA_____A__A_A_A_holy_shit::solve();
	return 0;
}
