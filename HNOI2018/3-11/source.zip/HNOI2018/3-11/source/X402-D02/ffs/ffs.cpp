#include<iostream>
#include<cstdio>
#include<cstring>
#define x first
#define y second

inline void check_min(int a,int &b){if(a<b)b=a;}
inline void check_max(int a,int &b){if(a>b)b=a;}

namespace bf
{
	typedef std::pair<int,int> pii;
	const int N=1020;

	pii f[N][N];
	int A[N];
	int n,m;

	void initialize()
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",A+i);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				f[i][j]=pii(1,n);

		int min,max;

		for(int i=1;i<=n;i++)
		{
			min=max=A[i];
			for(int j=i;j<=n;j++)
			{
				check_min(A[j],min),check_max(A[j],max);
				if(max-min==j-i)f[i][j]=pii(i,j);
			}
		}
		for(int len=n;len>1;len--)
			for(int i=1,j;(j=i+len-1)<=n;i++)
			{
				if(f[i][j].y-f[i][j].x<f[i+1][j].y-f[i+1][j].x)f[i+1][j]=f[i][j];
				if(f[i][j].y-f[i][j].x<f[i][j-1].y-f[i][j-1].x)f[i][j-1]=f[i][j];
			}

		scanf("%d",&m);
	}
	void solve()
	{
		initialize();
		for(int x,y;m--;)
			scanf("%d%d",&x,&y),printf("%d %d\n",f[x][y].x,f[x][y].y);
	}
}
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	bf::solve();
	return 0;
}
