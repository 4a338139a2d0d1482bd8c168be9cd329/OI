#include<iostream>
#include<cstdio>
#include<cstring>
#define x first
#define y second

namespace bf
{
	typedef std::pair<int,int> pii;
	const int N=1020;

	int A[N];
	int n,m;

#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
	int min[N*4],max[N*4];
	void build(int p=1,int L=1,int R=n)
	{
		if(L==R)min[p]=max[p]=A[L];
		else build(lcq),build(rcq),min[p]=std::min(min[lt],min[rt]),max[p]=std::max(max[lt],max[rt]);
	}
	int query_min(int s,int t,int p=1,int L=1,int R=n)
	{
		if(s>R || t<L)return N+2333;
		if(L>=s && R<=t)return min[p];
		return std::min(query_min(s,t,lcq),query_min(s,t,rcq));
	}
	int query_max(int s,int t,int p=1,int L=1,int R=n)
	{
		if(s>R || t<L)return 0;
		if(L>=s && R<=t)return max[p];
		return std::max(query_max(s,t,lcq),query_max(s,t,rcq));
	}
#undef lt 
#undef rt 
#undef mid
#undef lcq
#undef rcq

	void initialize()
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",A+i);
		build();
		scanf("%d",&m);
	}
	bool check(int l,int r){return query_max(l,r)-query_min(l,r)==r-l;}
	void query(int l,int r)
	{
		pii ans(1,n);
		for(int i=1;i<=l;i++)
			for(int j=r;j<=n;j++)
				if(check(i,j) && j-i<ans.y-ans.x)
					ans=pii(i,j);
		printf("%d %d\n",ans.x,ans.y);
	}
	void solve()
	{
		initialize();
		for(int x,y;m--;query(x,y))
			scanf("%d%d",&x,&y);
	}
}
int main()
{
	freopen("ffs.in","r",stdin);
	bf::solve();
	return 0;
}
