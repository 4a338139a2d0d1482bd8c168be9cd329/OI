#include<iostream>
#include<cstdio>
#include<cstring>

typedef long long ll;

int k,q;

#define lt (p<<1)
#define rt (lt|1)
int calc(int x,int p,int siz)
{
	int sizt=siz/2;
	if(x<=sizt)return calc(x,lt,sizt);
	else if(x<=sizt*2)return calc(x-sizt,rt,sizt);
	else return p;
}
int query(int x)
{
	int p=1,siz=(1<<k)-1;
	while(1)
	{
		if(x<=(siz/2))return calc(x,lt,siz/2)/2;
		else
		{
			x-=siz/2+1,siz/=2;
			if(!x)return rt;
			p=rt;
		}
	}
	return -1;
}

int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	scanf("%d%d",&k,&q);
	while(q--)
	{
		int a,d,m;
		scanf("%d%d%d",&a,&d,&m);
		ll ans=0;
		for(;m--;a+=d)
		{
			printf("%d\n",query(a));
			ans+=query(a);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
