#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<queue>
using namespace std;
void File(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
priority_queue<int,vector<int>, greater<int> >q;
const int maxn=2<<16;
int k,n,m,de[maxn],cnt,a[maxn];
bool flag[maxn];
int cal(int u){
	if(!flag[u/2])return u/2;
	if(!flag[u*2])return u*2;
	return u*2+1;
}
int main(){
	File();
	scanf("%d%d",&k,&m);
	n=(2<<(k-1))-1;
	de[1]=2;flag[0]=1;
	DREP(i,n,(n+1)/2){
		q.push((int)i);
		de[i]=1;
	}
	REP(i,2,(n-1)/2)de[i]=3;
	REP(i,1,n-2){
		int u=q.top();
		q.pop();
		flag[u]=1;
		int v=cal(u);
		a[++cnt]=v;
		--de[v];
		if(de[v]==1)
			q.push(v);
	}
	REP(i,1,m){
		int x,d,w;
		ll ans=0ll;
		scanf("%d%d%d",&x,&d,&w);
		REP(j,0,w-1)ans+=a[x+j*d];
		printf("%lld\n",ans);
	}
	return 0;
}
