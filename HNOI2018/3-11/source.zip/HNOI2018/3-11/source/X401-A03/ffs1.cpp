#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}
template<typename T>T chckmax(T _,T __){return _>__ ? _ : __;}
template<typename T>T chckmin(T _,T __){return _<__ ? _ : __;}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
const int maxn=1e5+10;
const int inf=0x7fffffff;
int n,m,a[maxn],Max[maxn][20],Min[maxn][20];
int Log[maxn];
int getmax(int x,int y){
	int ret=0;
	while(x<=y){
		ret=chckmax(ret,Max[x][Log[y-x+1]]);
		if(x==y)break;
		x=x+(2<<(Log[y-x+1]-1));
	}
	return ret;
}
int getmin(int x,int y){
	int ret=inf;	
	while(x<=y){
		ret=chckmin(ret,Min[x][Log[y-x+1]]);
		if(x==y)break;
		x=x+(2<<(Log[y-x+1]-1));
	}
	return ret;
}
int main(){
	File();
	scanf("%d",&n);
	REP(i,1,n)scanf("%d",&a[i]);
	REP(i,1,n)Max[i][0]=Min[i][0]=a[i];
	REP(i,1,n)Log[i]=floor((log(i)/log(2)));
	REP(i,1,Log[n])REP(j,1,n){
		int len=(2<<(i-1));
		if(j+len-1>n)break;
		Max[j][i]=chckmax(Max[j][i-1],Max[j+(len/2)][i-1]);
		Min[j][i]=chckmin(Min[j][i-1],Min[j+(len/2)][i-1]);
	}
	return 0;
}
