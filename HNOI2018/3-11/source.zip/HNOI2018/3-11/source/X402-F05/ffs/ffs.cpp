#include <bits/stdc++.h>

#define l first
#define r second
#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

typedef pair<int, int> PII;

const int N = 1e3 + 10;

void chkmin(PII &A, PII B) {
	if (!A.l) A = B;
	if (!B.l) return;
	A = A.r - A.l > B.r - B.l ? B : A;
}

int A[N], n;
PII ans[N][N];

int main() {

	freopen("ffs.in", "r", stdin);
	freopen("ffs.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &A[i]);
	For(l, 1, n) {
		int mn = A[l], mx = A[l];
		For(r, l, n) {
			mn = min(mn, A[r]), mx = max(mx, A[r]);
			if (mx - mn == r - l) ans[l][r] = PII(l, r);
		}
	}
	For(l, 1, n) Forr(r, n, 1) chkmin(ans[l][r], ans[l - 1][r]), chkmin(ans[l][r], ans[l][r + 1]);

	int q;
	scanf("%d", &q);
	while (q--) {
		int x, y;
		scanf("%d%d", &x, &y);
		printf("%d %d\n", ans[x][y].l, ans[x][y].r);
	}

	return 0;
}
