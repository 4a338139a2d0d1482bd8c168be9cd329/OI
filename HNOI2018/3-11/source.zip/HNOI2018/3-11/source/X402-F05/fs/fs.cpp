#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e7 + 10;

int k, q;
int A[N], n;

void DFS(int o) {
	if ((o << 1) >= (1 << k)) return;
	DFS(o << 1);
	A[++n] = o;
	DFS(o << 1 | 1);
	A[++n] = o;
}

int main() {

	freopen("fs.in", "r", stdin);
	freopen("fs.out", "w", stdout);

	scanf("%d%d", &k, &q);
	DFS(1);

	while (q--) {
		int l, d, m;
		scanf("%d%d%d", &l, &d, &m);
		long long ret = 0;
		For(i, 0, m - 1) ret += A[l + i * d];
		printf("%lld\n", ret);
	}

	return 0;
}
