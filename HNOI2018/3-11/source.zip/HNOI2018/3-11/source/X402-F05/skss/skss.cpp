#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

const int N = 2e5 + 10, M = 3020;

struct Square{
	int x, y, r;
}A[N], B[N];

int a, b, n, m;
int ans[M][M], cnt[M][M];
int addv[M][M];

int main() {

	freopen("skss.in", "r", stdin);
	freopen("skss.out", "w", stdout);

	m = M - 2;
	scanf("%d", &n);
	For(i, 1, n) {
		char ty[5];
		int x, y, r;
		scanf("%s%d%d%d", ty, &x, &y, &r);
		x += M / 2, y += M / 2, r /= 2;
		if (ty[0] == 'A') A[++a] = (Square){x, y, r};
		else B[++b] = (Square){x, y, r};
	}

	#define calc(a, x, y) a[x][y] += a[x - 1][y] + a[x][y - 1] - a[x - 1][y - 1]
	#define rcalc(a, x, y) a[x][y] += a[x - 1][y] + a[x][y + 1] - a[x - 1][y + 1]

	For(i, 1, b) {
		int x = B[i].x, y = B[i].y, r = B[i].r;
		addv[x - r + 1][y + 1] += -1, addv[x][y + r] += 1;
		addv[x + 1][y - r + 1] += -1, addv[x + r][y] += 1;
	}
	For(i, 1, m) For(j, 1, m) addv[i][j] += addv[i - 1][j - 1], cnt[i][j] += addv[i][j];
	memset(addv, 0, sizeof addv);

	For(i, 1, b) {
		int x = B[i].x, y = B[i].y, r = B[i].r;
		addv[x - r + 1][y - 1] += 1, addv[x][y - r] += -1;
		addv[x + 1][y + r - 1] += 1, addv[x + r][y] += -1;
	}
	For(i, 1, m) Forr(j, m, 1) addv[i][j] += addv[i - 1][j + 1], cnt[i][j] += addv[i][j];
	memset(addv, 0, sizeof addv);

	For(i, 1, a) {
		int x = A[i].x, y = A[i].y, r = A[i].r;
		cnt[x - r][y - r] += 1, cnt[x + r][y - r] += -1;
		cnt[x - r][y + r] += -1, cnt[x + r][y + r] += 1;
	}
	For(i, 1, m) For(j, 1, m) {
		calc(cnt, i, j);
		if (cnt[i][j]) ans[i][j] |= 15;
	}
	memset(cnt, 0, sizeof cnt);

	//   2
	// 1   4
	//   8

	For(i, 1, b) {
		int x = B[i].x, y = B[i].y, r = B[i].r;
		cnt[x - r][y] += 1, cnt[x][y + r] += -1;
	} 
	For(i, 1, m) For(j, 1, m) {
		cnt[i][j] += cnt[i - 1][j - 1];
		if (cnt[i][j]) ans[i][j] |= 12;
	}
	memset(cnt, 0, sizeof cnt);

	For(i, 1, b) {
		int x = B[i].x, y = B[i].y, r = B[i].r;
		cnt[x][y - r] += 1, cnt[x + r][y] += -1;
	} 
	For(i, 1, m) For(j, 1, m) {
		cnt[i][j] += cnt[i - 1][j - 1];
		if (cnt[i][j]) ans[i][j] |= 3;
	}
	memset(cnt, 0, sizeof cnt);

	For(i, 1, b) {
		int x = B[i].x, y = B[i].y, r = B[i].r;
		cnt[x - r][y - 1] += 1, cnt[x][y - r - 1] += -1;
	}
	For(i, 1, m) Forr(j, m, 1) {
		cnt[i][j] += cnt[i - 1][j + 1];
		if (cnt[i][j]) ans[i][j] |= 6;
	}
	memset(cnt, 0, sizeof cnt);

	For(i, 1, b) {
		int x = B[i].x, y = B[i].y, r = B[i].r;
		cnt[x][y + r - 1] += 1, cnt[x + r][y - 1] += -1;
	}
	For(i, 1, m) Forr(j, m, 1) {
		cnt[i][j] += cnt[i - 1][j + 1];
		if (cnt[i][j]) ans[i][j] |= 9;
	}
	memset(cnt, 0, sizeof cnt);

	int sum = 0;
	For(i, 1, m) For(j, 1, m) sum += __builtin_popcount(ans[i][j]);
	printf("%.2lf\n", sum / 4.0);

	return 0;
}
