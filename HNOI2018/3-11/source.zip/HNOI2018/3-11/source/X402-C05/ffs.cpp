#include<bits/stdc++.h>
using namespace std;
const int maxn=1010;
int n,m,p[maxn],pos[maxn],vis[maxn];
vector<int> st,ed;
void solve(){
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",p+i);
		pos[p[i]]=i;
	}
	scanf("%d",&m);
	for(int l,r,ql,qr;m--;){
		memset(vis,0,sizeof vis);
		scanf("%d%d",&l,&r);
		for(int i=l;i<=r;++i){
			vis[p[i]]=1;
		}
		ql=l;qr=r;
		for(;;){
			st.clear();ed.clear();
			for(int i=1,flag=1;i<=n;++i){
				if(vis[i-1]==0&&vis[i]==1){
					st.push_back(i);
				}
				if(vis[i]==1&&vis[i+1]==0){
					ed.push_back(i);
				}
			}
			if(st.size()==1)break;
			for(int i=0,ll,lr;i<st.size()-1;++i){
				ll=ql,lr=qr;
				for(int j=ed[i]+1;j<=st[i+1]-1;++j){
					vis[j]=1;
					if(pos[j]<ql)ql=pos[j];
					if(pos[j]>qr)qr=pos[j];
				}
				for(int j=ql+1;j<=ll-1;++j){
					vis[j]=1;
				}
				for(int j=qr-1;j>=lr+1;--j){
					vis[j]=1;
				}
			}
		}
		printf("%d %d\n",ql,qr);
		//cerr<<endl<<m<<" "<<st.size()<<" "<<ed.size()<<endl<<endl;
	}
}
int main(){
	freopen("ffs.in","r",stdin);freopen("ffs.out","w",stdout);
	solve();
	return 0;
}
/*
10
2 1 4 3 5 6 7 10 8 9
5
2 3
3 7
4 7
4 8
7 8
*/
