#include<bits/stdc++.h>
using namespace std;
int n,q,S;
vector<int> pru;
#define ls (u<<1)
#define rs (ls|1)
void dfs(int u){
	if(ls<S)dfs(ls);
	if(rs<S)dfs(rs);
	pru.push_back(u>>1);
}
#undef ls
#undef rs
void solve(){
	scanf("%d%d",&n,&q);
	//n=4;
	S=1<<n;
	dfs(1);
//	for(int i=0;i<S-3;++i){
//		cerr<<pru[i]<<" ";
//	}
//	cerr<<endl;
	for(int a,d,m;q--;){
		scanf("%d%d%d",&a,&d,&m);
		--a;long long ans=0;
		for(int i=a;i<=a+(m-1)*d;++i)
			ans=ans+pru[i];
		printf("%lld\n",ans);
	}
}
int main(){
	freopen("fs.in","r",stdin);freopen("fs.out","w",stdout);
	solve();
	return 0;
} 
