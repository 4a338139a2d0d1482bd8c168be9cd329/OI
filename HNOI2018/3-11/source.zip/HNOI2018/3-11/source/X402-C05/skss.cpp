#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct data{
	int x,y,d;
};

vector<data> a,b;

namespace Work1{
	bool cmp(data A,data B){
		int X1=(A.x-A.d/2),X2=(B.x-B.d/2);
		if(X1!=X2)return X1<X2;
		int Y1=(A.y-A.d/2),Y2=(B.y-B.d/2);
		if(Y1!=Y2)return Y1<Y2;
		return A.d>B.d;
		//if(A.x!=B.x)return <(B.x);
		//if(A.y!=B.y)return (A.y-A.d/2)<(B.y);
	}
	struct data2{
		int val,id;
	};
	bool cmp2(data2 A,data2 B){
		if(A.val!=B.val)return A.val<B.val;
		return A.id<B.id;
	}
	const int M=2000,N=4010<<2;
	int rt[N],tag[N];
	
	#define mid (l+r>>1)
	void pushdown(int u,int l,int r){
		if(tag[u]){
			tag[u<<1]+=tag[u];
			tag[u<<1|1]+=tag[u];
			if(tag[u<<1])rt[u<<1]=(mid-l+1);
			if(tag[u<<1|1])rt[u<<1|1]=(r-mid);
			tag[u]=0;
		}
	}
	void ins(int u,int l,int r,int ql,int qr,int v){
		if(ql<=l&&r<=qr){
			tag[u]+=v;
			if(tag[u])rt[u]=r-l+1;
			else rt[u]=0;
			return;
		}
		pushdown(u,l,r);
		if(ql<=mid)ins(u<<1,l,mid,ql,qr,v);
		if(qr>mid)ins(u<<1|1,mid+1,r,ql,qr,v);
		rt[u]=rt[u<<1]+rt[u<<1|1];
	}
	vector<data2> IX,DX;
	
	int ans=0;
	int calc(int x,int ls){
		if(ls!=-4000){
			cerr<<x<<" "<<ls<<endl;
			ans+=(x-ls)*rt[1];
		}
	}
	void work1(){
		//sort(a.begin(),a.end(),cmp);
		for(int i=0;i<a.size();++i){
			IX.push_back((data2){a[i].x-a[i].d/2,i});
			//IX.push_back(i);
			//DX.push_back(i);
			DX.push_back((data2){a[i].x+a[i].d/2,i});
		}
		sort(IX.begin(),IX.end(),cmp2);
		sort(DX.begin(),DX.end(),cmp2);
		for(int i=0,j=0,X,ls=-4000;j<DX.size();){
			//cerr<<ls<<endl;
			if(i==IX.size()){
				X=DX[j].val;
				calc(X,ls);
				while(j<DX.size()&&DX[j].val==X){
					int L=a[DX[j].id].y-a[DX[j].id].d/2;
					int R=a[DX[j].id].y+a[DX[j].id].d/2;
					ins(1,1,4000,L+M+1,R+M,-1);
					++j;
				}
			}
			else{
				if(IX[i].val<DX[j].val){
					X=IX[i].val;
					calc(X,ls);
					while(i<IX.size()&&IX[i].val==X){
						int L=a[IX[i].id].y-a[IX[i].id].d/2;
						int R=a[IX[i].id].y+a[IX[i].id].d/2;
						ins(1,1,4000,L+M+1,R+M,1);
						++i;
					}
				}
				else if(IX[i].val==DX[j].val){
					X=IX[i].val;
					calc(X,ls);
					while(i<IX.size()&&IX[i].val==X){
						int L=a[IX[i].id].y-a[IX[i].id].d/2;
						int R=a[IX[i].id].y+a[IX[i].id].d/2;
						ins(1,1,4000,L+M+1,R+M,1);
						++i;
					}
					while(j<DX.size()&&DX[j].val==X){
						int L=a[DX[j].id].y-a[DX[j].id].d/2;
						int R=a[DX[j].id].y+a[DX[j].id].d/2;
						ins(1,1,4000,L+M+1,R+M,-1);
						++j;
					}
				}
				else{
					X=DX[j].val;
					calc(X,ls);
					while(j<DX.size()&&DX[j].val==X){
						int L=a[DX[j].id].y-a[DX[j].id].d/2;
						int R=a[DX[j].id].y+a[DX[j].id].d/2;
						ins(1,1,4000,L+M+1,R+M,-1);
						++j;
					}
				}
			}	
			ls=X;
		}
		printf("%d\n",ans);
	}
}
int n;
void solve(){
	scanf("%d",&n);
	for(int i=1,x,y,d;i<=n;++i){
		char ch[2];
		scanf("%s%d%d%d",ch,&x,&y,&d);
		if(ch[0]=='A'){
			a.push_back((data){x,y,d});
		}
		else{
			b.push_back((data){x,y,d});
		}
	}
	if(!b.size())Work1::work1();
	//for()
}
int main(){
	freopen("skss.in","r",stdin);freopen("skss.out","w",stdout);
	solve();
	
	return 0;
}
/*
1
A 1 1 4

8
A -7 10 4
B 3 10 8
A -6 6 6
A -2 5 8
B 3 -1 8
B -7 -4 8
A 3 9 2
B 8 6 6
*/
