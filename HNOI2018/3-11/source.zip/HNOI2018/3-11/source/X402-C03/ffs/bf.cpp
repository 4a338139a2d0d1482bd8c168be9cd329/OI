#include<bits/stdc++.h>
using namespace std;

template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}

const int maxn=1e3+10;
int n,p[maxn],q,a[maxn][maxn],b[maxn][maxn];

int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.txt","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&p[i]);
	for(int i=1;i<=n;++i){
		int x=p[i],y=p[i];
		for(int j=i;j<=n;++j){
			chkmin(x,p[j]);
			chkmax(y,p[j]);
			if(y-x==j-i)
				a[i][j]=i,b[i][j]=j;
		}
	}
	for(int i=1;i<=n;++i)
		for(int j=n;j>=i;--j){
			if(a[i][j])
				continue;
			if(i==1)
				a[i][j]=a[i][j+1],b[i][j]=b[i][j+1];
			else if(j==n)
				a[i][j]=a[i-1][j],b[i][j]=b[i-1][j];
			else
				if(b[i-1][j]-a[i-1][j]<b[i][j+1]-a[i][j+1])
					a[i][j]=a[i-1][j],b[i][j]=b[i-1][j];
				else
					a[i][j]=a[i][j+1],b[i][j]=b[i][j+1];
		}
	scanf("%d",&q);
	while(q--){
		int x,y;
		scanf("%d%d",&x,&y);
		printf("%d %d\n",a[x][y],b[x][y]);
	}
	return 0;
}
