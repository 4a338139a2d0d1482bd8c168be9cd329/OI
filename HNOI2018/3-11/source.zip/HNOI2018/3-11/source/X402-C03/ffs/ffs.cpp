#include<bits/stdc++.h>
using namespace std;

template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}

const int maxn=1e5+10,maxlog=20;
int n,q,log_2[maxn];

struct rmq{
	int a[maxn];
	int min[maxlog][maxn],max[maxlog][maxn];
	inline void init(){
		for(int i=1;i<=n;++i)
			min[0][i]=max[0][i]=a[i];
		for(int i=1;(1<<i)<=n;++i)
			for(int j=n+(1<<i)-1;j;--j){
				min[i][j]=min_(min[i-1][j],min[i-1][j+(1<<i-1)]);
				max[i][j]=max_(max[i-1][j],max[i-1][j+(1<<i-1)]);
			}
	}
	inline int querymin(int l,int r){
		int k=log_2[r-l+1];
		return min_(min[k][l],min[k][r+1-(1<<k)]);
	}
	inline int querymax(int l,int r){
		int k=log_2[r-l+1];
		return max_(max[k][l],max[k][r+1-(1<<k)]);
	}
}val,pos;

int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	for(int i=2;i<maxn;++i)
		log_2[i]=log_2[i-1]+(i==(i&-i));
	scanf("%d",&n);
	for(int i=1,x;i<=n;++i){
		scanf("%d",&x);
		val.a[i]=x;
		pos.a[x]=i;
	}
	val.init();
	pos.init();
	scanf("%d",&q);
	while(q--){
		int x,y,a,b;
		scanf("%d%d",&x,&y);
		a=val.querymin(x,y);b=val.querymax(x,y);
		while(y-x<b-a){
			x=pos.querymin(a,b);y=pos.querymax(a,b);
			a=val.querymin(x,y);b=val.querymax(x,y);
		}
		printf("%d %d\n",x,y);
	}
	return 0;
}
