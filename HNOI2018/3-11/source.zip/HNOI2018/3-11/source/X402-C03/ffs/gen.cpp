#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}
int a[100000+10];

int main(){
	init();
	freopen("ffs.in","w",stdout);
	int xxx=1e3;
//	xxx=1e5;
	int n=f(1,xxx),q=f(1,xxx);
	for(int i=1;i<=n;++i)
		a[i]=i;
	for(int i=log(n)*n+n,x;i;--i)
		x=f(2,n),swap(a[x-1],a[x]);
	printf("%d\n",n);
	for(int i=1;i<=n;++i)
		printf("%d ",a[i]);
	printf("\n%d\n",q);
	while(q--){
		int x=f(1,n),y=f(1,n);
		printf("%d %d\n",min(x,y),max(x,y));
	}
	fflush(stdin);
	return 0;
}
