#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
typedef long long ll;
ll f(ll x,ll y){
	return ((ll)rand()<<31|rand())%(y-x+1)+x;
}

int main(){
	init();
	freopen("fs.in","w",stdout);
	int k=f(2,15),q=f(1,300);
	k=30;
	printf("%d %d\n",k,q);
	ll x=1;
	for(int i=1;i<=k;++i)
		x=x*2;
	x-=3;
	while(q--){
		ll a=min(f(1,x),f(1,x));
		ll d=rand()&3?f(1,sqrt(x)):f(1,x);
		ll b=f(1,(x-a+d)/d);
		printf("%lld %lld %lld\n",a,d,b);
	}
	return 0;
}
