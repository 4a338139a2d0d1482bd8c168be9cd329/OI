#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=(1<<15)+10;
int n,q;

inline ll min(ll a,ll b){return a<=b?a:b;}
inline ll max(ll a,ll b){return a>=b?a:b;}
inline void chkmax(ll&a,ll b){if(a<b)a=b;}
inline void chkmin(ll&a,ll b){if(a>b)a=b;}
ll size[maxn];
struct node{
	int a;ll b,c,d;
	node(int aa,ll bb,ll cc,ll dd){
		a=aa;b=bb;c=cc;d=dd;
	}
	bool operator< (node o)const{
		if(a!=o.a)return a<o.a;
		if(b!=o.b)return b<o.b;
		if(c!=o.c)return c<o.c;
		return d<o.d;
	}
};
map<node,pair<ll,ll> > mp1;
pair<ll,ll> dfs1(int dep,ll beg,ll delta,ll end){
	if(beg<1){beg=beg%delta;if(beg<1)beg+=delta;}
	if(end>size[dep]){end=size[dep]+(size[dep]-end)%delta;if(end>size[dep])end-=delta;}
	if(beg>end)
		return make_pair(0,0);
	if(dep>=n)
		return make_pair(0,0);
	if(mp1.count(node(dep,beg,delta,end)))
		return mp1[node(dep,beg,delta,end)];
	ll res1=0,res2=0;
	pair<ll,ll> tmp;
	tmp=dfs1(dep+1,beg,delta,end);
	res1+=tmp.first*2,res2+=tmp.second;
	if(beg<=size[dep+1]+1&&size[dep+1]+1<=end&&(size[dep+1]+1-beg)%delta==0)
		++res1;
	tmp=dfs1(dep+1,beg-size[dep+1]-1,delta,end-size[dep+1]-1);
	res1+=tmp.first*2,res2+=tmp.second+tmp.first;
	if(beg<=size[dep]&&size[dep]<=end&&(size[dep]-beg)%delta==0)
		++res1;
	return mp1[node(dep,beg,delta,end)]=make_pair(res1,res2);
}
map<node,pair<ll,ll> > mp2;
pair<ll,ll> dfs2(int dep,ll beg,ll delta,ll end){
	if(beg<1){beg=beg%delta;if(beg<1)beg+=delta;}
	if(end>size[dep]){end=size[dep]+(size[dep]-end)%delta;if(end>size[dep])end-=delta;}
	if(beg>end)
		return make_pair(0,0);
	if(dep>=n)
		return make_pair(0,0);
	if(mp2.count(node(dep,beg,delta,end)))
		return mp2[node(dep,beg,delta,end)];
	ll res1=0,res2=0;
	pair<ll,ll> tmp;
	if(beg<=1&&1<=end&&(1-beg)%delta==0)
		++res1;
	tmp=dfs2(dep+1,beg-1,delta,end-1);
	res1+=tmp.first*2;res2+=tmp.second;
	if(beg<=size[dep+1]+2&&size[dep+1]+2<=end&&(size[dep+1]+2-beg)%delta==0)
		++res1;
	tmp=dfs2(dep+1,beg-size[dep+1]-2,delta,end-size[dep+1]-2);
	res1+=tmp.first*2;res2+=tmp.first+tmp.second;
	return mp2[node(dep,beg,delta,end)]=make_pair(res1,res2);
}


int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.txt","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=n-1;i;--i)
		size[i]=size[i+1]*2+2;
	while(q--){
		ll ans=0;
		ll a,d,m;
		pair<ll,ll> tmp;
		scanf("%lld%lld%lld",&a,&d,&m);
		m=a+d*(m-1);
		if(a<=size[2]+1&&size[2]+1<=m&&(size[2]+1-a)%d==0)
			++ans;
		if(a<size[2]+1){
			tmp=dfs1(2,a,d,m);
			ans+=2*tmp.first;ans+=tmp.second;
		}
		if(m>size[2]+1){
			tmp=dfs2(2,a-size[2]-1,d,m-size[2]-1);
			ans+=3*tmp.first;ans+=tmp.second;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
