#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=(1<<15)+10;
int n,q;
vector<int> prufer;

void dfs1(int rt,int dep){
	if(dep>=n)
		return;
	dfs1(rt<<1,dep+1);
	prufer.push_back(rt);
	dfs1(rt<<1|1,dep+1);
	prufer.push_back(rt);
}
void dfs2(int rt,int dep){
	if(dep>=n)
		return;
	prufer.push_back(rt);
	dfs2(rt<<1,dep+1);
	prufer.push_back(rt);
	dfs2(rt<<1|1,dep+1);
}

int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	prufer.resize(1);
	scanf("%d%d",&n,&q);
	dfs1(2,2);
	prufer.push_back(1);
	dfs2(3,2);
	while(q--){
		ll ans=0;
		int a,d,m;
		scanf("%d%d%d",&a,&d,&m);
		for(;m--;a+=d)
			ans+=prufer[a];
		printf("%lld\n",ans);
	}
	return 0;
}
