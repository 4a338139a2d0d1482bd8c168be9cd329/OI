#include<bits/stdc++.h>
using namespace std;

const int maxabsn=1500+10,maxn=2*maxabsn,max2n=2*maxn;
int n,ans;
bool vis[maxn][maxn],viss[max2n][max2n];

int main(){
	freopen("skss.in","r",stdin);
	freopen("skss.txt","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		char s[2];
		int x,y,a;
		scanf("%s%d%d%d",s,&x,&y,&a);
		x+=maxabsn;y+=maxabsn;a/=2;
		if(s[0]=='A'){
			int x0=x-a,x1=x+a,y0=y-a,y1=y+a;
			for(int i=x0;i<x1;++i)
				for(int j=y0;j<y1;++j)
					vis[i][j]=true;
		}
		else{
			int xx=x+y,yy=x-y+maxn;
			int x0=xx-a,x1=xx+a,y0=yy-a,y1=yy+a;
			for(int i=x0;i<x1;++i)
				for(int j=y0;j<y1;++j)
					viss[i][j]=true;
		}
	}
	for(int j=maxn-1;j;--j)
		for(int i=1;i<maxn;++i){
			if(vis[i][j]){
				ans+=4;
				continue;
			}
			int x=i+j,y=i-j+maxn;
			if(viss[x][y])
				++ans;
			if(viss[x][y-1])
				++ans;
			if(viss[x+1][y])
				++ans;
			if(viss[x+1][y-1])
				++ans;
		}
	printf("%.2f\n",ans/4.0);
	return 0;
}
