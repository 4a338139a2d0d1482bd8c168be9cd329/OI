#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("skss.in","w",stdout);
	int n=f(1,2e1);
	printf("%d\n",n);
	while(n--){
		int x=f(-1000,1000),y=f(-1000,1000),d=f(1,500)*2;
		printf("%c %d %d %d\n","AB"[f(0,1)],x,y,d);
	}
	return 0;
}
