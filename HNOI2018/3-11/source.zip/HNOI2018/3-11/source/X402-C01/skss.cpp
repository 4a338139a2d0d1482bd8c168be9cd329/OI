/************************************************
 * Au: Hany01
 * Prob: skss bf 50pts?
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("skss.in", "r", stdin);
    freopen("skss.out", "w", stdout);
}

const int maxb = 4023, maxn = 200005;

bitset<maxb> dt, a[maxb], b[maxb], c[maxb], d[maxb];

int MINX = INF, MINY = INF, MAXX = -INF, MAXY = -INF, n, x[maxn], y[maxn], r[maxn], mark = 1, ret[maxb][maxb];
char type[maxn][2];

inline void subtask()
{
	For(i, 1, n) {
		register int x1 = x[i] - r[i] + 1, x2 = x[i] + r[i], y1 = y[i] - r[i] + 1, y2 = y[i] + r[i];
		++ ret[x2 + 1][y2 + 1], ++ ret[x1][y1], -- ret[x2 + 1][y1], -- ret[x1][y2 + 1];
	}

	static int Ans = 0;
	For(i, 1, 4011) For(j, 1, 4011) {
		ret[i][j] += ret[i - 1][j] + ret[i][j - 1] - ret[i - 1][j - 1];
		if (ret[i][j]) ++ Ans;
	}
	printf("%d", Ans), puts(".00");
}

int main()
{

    File();

	n = read();
	For(i, 1, n) {
		scanf("%s", type[i]), x[i] = read() + 2005, y[i] = read() + 2005, r[i] = read() >> 1;
		chkmin(MINX, x[i] - r[i] - 1), chkmax(MAXX, x[i] + r[i]),
		chkmin(MINY, y[i] - r[i] - 1), chkmax(MAXY, y[i] + r[i]);
		if (type[i][0] != 'A') mark = 0;
	}

	if (mark) {
		subtask();
		return 0;
	}

	for (register int t = 1; t <= n; ++ t)
	{
		if (type[t][0] == 'A') {
			dt = 0;
			For(i, y[t] - r[t] + 1, y[t] + r[t]) dt[i] = 1;
			For(i, x[t] - r[t] + 1, x[t] + r[t]) a[i] |= dt, c[i] |= dt;
		} else {
			dt = 0;
			Fordown(i, r[t], 1) {
				//line: x - i + 1, x + i
				register int j = r[t] - i + 1;
				a[x[t] - i + 1] |= dt, c[x[t] - i + 1] |= dt, a[x[t] + i] |= dt, c[x[t] + i] |= dt;
				b[x[t] - i + 1][y[t] - j + 1] = 1, a[x[t] - i + 1][y[t] + j] = 1,
				d[x[t] + i][y[t] - j + 1] = 1, c[x[t] + i][y[t] + j] = 1;
				dt[y[t] - j + 1] = 1, dt[y[t] + j] = 1;
			}
		}
	}

	static double Ans = 0.;
	For(i, MINX, MAXX) For(j, MINY, MAXY) {
		if ((a[i][j] && c[i][j]) || (b[i][j] && d[i][j])) Ans += 1;
		else if (a[i][j] + c[i][j] + b[i][j] + d[i][j] == 2) Ans += .75;
		else if (a[i][j] + c[i][j] + b[i][j] + d[i][j] == 1) Ans += 0.5;
	}
	printf("%.2lf\n", Ans);

    return 0;
}
