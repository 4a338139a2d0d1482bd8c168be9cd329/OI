/************************************************
 * Au: Hany01
 * Prob: ffs LuanGao
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("ffs.in", "r", stdin);
    freopen("ffs.out", "w", stdout);
}

const int maxn = 100005;

int n, a[maxn], p[maxn];

int main()
{

    File();

	n = read();
	For(i, 1, n) a[i] = read();
	For(i, 1, n) p[a[i]] = i;

	for (register int q = read(); q --; )
	{
		register int x = read(), y = read(), Maxv = 0, Maxp = 0, Minv = n, Minp = n, lastminp, lastmaxp, lastminv, lastmaxv;
		For(i, x, y) chkmin(Minv, a[i]), chkmax(Maxv, a[i]);
		For(i, Minv, Maxv) chkmin(Minp, p[i]), chkmax(Maxp, p[i]);
		lastminp = Maxp, lastmaxp = Minp;
		for ( ; lastminp > Minp || lastmaxp < Maxp; ) {
			lastminv = Minv, lastmaxv = Maxv;
			For(i, Minp, lastminp - 1) chkmin(Minv, a[i]), chkmax(Maxv, a[i]);
			For(i, lastmaxp + 1, Maxp) chkmin(Minv, a[i]), chkmax(Maxv, a[i]);
			lastminp = Minp, lastmaxp = Maxp;
			For(i, Minv, lastminv - 1) chkmin(Minp, p[i]), chkmax(Maxp, p[i]);
			For(i, lastmaxv + 1, Maxv) chkmin(Minp, p[i]), chkmax(Maxp, p[i]);
		}
		printf("%d %d\n", Minp, Maxp);
	}

    return 0;
}
