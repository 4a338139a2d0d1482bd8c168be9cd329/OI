#include <bits/stdc++.h>

using std :: max;
using std :: min;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int N = 1e5 + 5;

int n, q;
int p[N], pos[N];

int Log[N];

void LogInit(int lst = 0)
{
	for (int j = 1; j < 20; ++j) {
		for (int i = lst; i < 1<<j; ++i) {
			if (i >= N) break;
			Log[i] = j-1;
		}
		lst = 1 << j;
	}
}

struct SparseTable
{
	static const int LOGN = 20;
	int Mx[N][LOGN], Mn[N][LOGN];

	void StInit(int *A)
	{
		for (int i = 1; i <= n; ++i) {
			Mx[i][0] = Mn[i][0] = A[i];
		}
		for (int j = 1; j < LOGN; ++j) {
			for (int i = 1; i+(1<<j)-1 <= n; ++i) {
				Mx[i][j] = max(Mx[i][j-1], Mx[i+(1<<(j-1))][j-1]);
				Mn[i][j] = min(Mn[i][j-1], Mn[i+(1<<(j-1))][j-1]);
			}
		}
	}

	int queryMn(int l, int r)
	{
		int _log = Log[r-l+1];
		return min(Mn[l][_log], Mn[r-(1<<_log)+1][_log]);
	}

	int queryMx(int l, int r)
	{
		int _log = Log[r-l+1];
		return max(Mx[l][_log], Mx[r-(1<<_log)+1][_log]);
	}
}P, Pos;

int main()
{
	freopen("ffs.in", "r", stdin);
	freopen("ffs.out", "w", stdout);

	n = read();
	for (int i = 1; i <= n; ++i) {
		p[i] = read();
		pos[p[i]] = i;
	}

	LogInit();
	P.StInit(p);
	Pos.StInit(pos);

	q = read();
	for (int c = 1; c <= q; ++c) {
		int l = read(), r = read();
		int x = P.queryMn(l, r);
		int y = P.queryMx(l, r);
		for (;;) {
			if (y - x + 1 == r - l + 1) break;
			l = min(l, Pos.queryMn(x, y));
			r = max(r, Pos.queryMx(x, y));
			x = P.queryMn(l, r);
			y = P.queryMx(l, r);
		}
		printf("%d %d\n", l, r);
	}

	return 0;
}
