#include <bits/stdc++.h>

const int D = 16;

int K, Q, tot;
int A[1 << D];

void dfsInit(int h, int dep)
{
	if (dep == K) return ;
	dfsInit(h << 1, dep + 1);
	A[++tot] = h;
	dfsInit(h << 1 | 1, dep + 1);
	if (h != 1)
		A[++tot] = h;
}

int main()
{
	freopen("fs.in", "r", stdin);
	freopen("fs.out", "w", stdout);

	scanf("%d%d", &K, &Q);

	dfsInit(1, 1);

	while (Q --) {
		int a0, d, n;
		scanf("%d%d%d", &a0, &d, &n);

		int sum = 0;
		for (int i = a0, cnt = 0; cnt < n;) {
			sum += A[i];
			cnt ++;
			i += d;
		}

		printf("%d\n", sum);
	}

	return 0;
}
