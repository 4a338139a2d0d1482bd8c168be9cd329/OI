#include <bits/stdc++.h>

inline int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int N = 2e5;
const int W = 1.5e3;

int n;

namespace Caonima
{
	struct SegmentTree
	{
		#define mid ((l + r) >> 1)
		#define lc (h << 1)
		#define rc (lc | 1)

		static const int T = (W << 3);

		int sum[T], tag[T];

		inline void push_down(int h, int l, int r)
		{
			if (tag[h]) {
				sum[lc] = mid - l + 1;
				sum[rc] = r - mid;
				tag[lc] = tag[rc] = tag[h];
				tag[h] = 0;
			}
		}

		void modify(int h, int l, int r, int ql, int qr)
		{
			if (sum[h] == r - l + 1) return ;
			if (ql <= l && r <= qr) {
				sum[h] = r - l + 1;
				tag[h] = 1;
				return ;
			}

			push_down(h, l, r);
			if (ql <= mid) modify(lc, l, mid, ql, qr);
			if (qr > mid) modify(rc, mid + 1, r, ql, qr);
			sum[h] = sum[lc] + sum[rc];
		}

		inline int query(int h, int l, int r, int u)
		{
			if (l == r) return sum[h];
			push_down(h, l, r);
			return u <= mid? query(lc, l, mid, u) : query(rc, mid + 1, r, u);
		}

		#undef lc
		#undef rc
		#undef mid
	}row[(W << 1) + 5];

	struct Square
	{
		int x, y, l, ty;
	}P[N + 5];

	bool caled[2*W+5][2*W+5][4];

	void main()
	{
		n = read();
		for (int i = 1; i <= n; ++i) {
			static char s[10]; scanf("%s", s);
			P[i].ty = (s[0] == 'B');
			P[i].x = read(); P[i].y = read(); P[i].l = read();
			int x0 = P[i].x - P[i].l/2, y0 = P[i].y - P[i].l/2;
			int x1 = P[i].x + P[i].l/2, y1 = P[i].y + P[i].l/2;
			if (!P[i].ty) {
				for (int j = y0; j < y1; ++j)
					row[j+W].modify(1, -W, W, x0, x1-1);
			}
			else {
				++x0, --x1;
				for (int j = 0; j < P[i].l/2-1; ++j) {
//					assert(x0 + j <= x1 - j - 1);
					row[P[i].y+j+W].modify(1, -W, W, x0 + j, x1 - j - 1);
					row[P[i].y-j-1+W].modify(1, -W, W, x0 + j, x1 - j - 1);
				}
			}
		}

		double S = 0;
		for (int i = 1; i <= n; ++i) {
			if (!P[i].ty) continue;
			int x0 = P[i].x - P[i].l/2, y0 = P[i].y - P[i].l/2;
			int x1 = P[i].x + P[i].l/2, y1 = P[i].y + P[i].l/2;
			for (int j = y0; j < y0 + P[i].l/2; ++j) {
				int p = P[i].x + j - y0;
				if (row[j+W].query(1, -W, W, p)) continue;
				if (caled[j+W][p+W][0]) continue;
				if (caled[j+W][p+W][1] || caled[j+W][p+W][3]) S += 0.25;
				else S += 0.5;
				caled[j+W][p+W][0] = 1;
			}
			for (int j = y0; j < P[i].y; ++j) {
				int p = P[i].x - (j - y0) - 1;
				if (row[j+W].query(1, -W, W, p)) continue;
				if (caled[j+W][p+W][1]) continue;
				if (caled[j+W][p+W][0] || caled[j+W][p+W][2]) S += 0.25;
				else S += 0.5;
				caled[j+W][p+W][1] = 1;
			}
			for (int j = P[i].y; j < P[i].y + P[i].l/2; ++j) {
				int p = x0 + (j - P[i].y);
				if (row[j+W].query(1, -W, W, p)) continue;
				if (caled[j+W][p+W][2]) continue;
				if (caled[j+W][p+W][1] || caled[j+W][p+W][3]) S += 0.25;
				else S += 0.5;
				caled[j+W][p+W][2] = 1;
			}
			for (int j = P[i].y; j < P[i].y + P[i].l/2; ++j) {
				int p = x1 - (j - P[i].y) - 1;
				if (row[j+W].query(1, -W, W, p)) continue;
				if (caled[j+W][p+W][3]) continue;
				if (caled[j+W][p+W][0] || caled[j+W][p+W][2]) S += 0.25;
				else S += 0.5;
				caled[j+W][p+W][3] = 1;
			}
		}
		for (int i = -W; i <= W; ++i) S += row[i+W].sum[1];

		printf("%.2lf\n", S);
	}
}

int main()
{
	freopen("skss.in", "r", stdin);
	freopen("skss.out", "w", stdout);

	Caonima :: main();

//	fprintf(stderr, "%d\n", cnt);
//	fprintf(stderr, "%lf\n", 1.0*clock()/CLOCKS_PER_SEC);
	return 0;
}
