#include <bits/stdc++.h>

int RandInt(int l, int r)
{
	return 1ll * rand() * rand() % (r - l + 1) + l;
}

int main()
{
	freopen("skss.in", "w", stdout);
	srand(time(NULL));

	int n = 2e5; printf("%d\n", n);
	for (int i = 1; i <= n; ++i) {
		int x = RandInt(-500, 500);
		int y = RandInt(-500, 500);
		int d = RandInt(1, 500) * 2;
		printf("A %d %d %d\n", x, y, d);
	}
	return 0;
}
