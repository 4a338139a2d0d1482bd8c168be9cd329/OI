#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=200010,O=1000;

int n,A[2010][2010],B[2010][2010];
double ans;

int main(){
    freopen("skss.in","r",stdin);
    freopen("skss.out","w",stdout);

    read(n);
    while(n--){
        int x,y,d; char op[2];
        scanf("%c",op);
        read(x); read(y); read(d)/=2;
        if(op[0]=='A'){
            int dlx=max(O+x-d+1,0),dly=max(O+y-d+1,0);
            int drx=min(O+x+d+1,2001),dry=min(O+y+d+1,2001);
            A[dlx][dly]++; A[drx][dry]++;
            A[drx][dly]--; A[dlx][dry]--;
        }
        else{
            for(int i=1;i<=d;i++){
                int dl=max(O+y-(d-i)+1,0),dr=min(O+y+(d-i),2001);
                A[min(O+x+i,2001)][dl]++; A[min(O+x+i,2001)][min(dr+1,2001)]--;
                A[min(O+x+i+1,2001)][dl]--; A[min(O+x+i+1,2001)][min(dr+1,2001)]++;
                A[max(O+x-i+1,0)][dl]++; A[max(O+x-i+1,0)][min(dr+1,2001)]--;
                A[max(O+x-i+2,0)][dl]--; A[max(O+x-i+2,0)][min(dr+1,2001)]++;
                B[min(O+x+i,2001)][max(dl-1,0)]|=1; B[max(O+x-i+1,0)][max(dl-1,0)]|=2;
                B[min(O+x+i,2001)][min(dr+1,2001)]|=2; B[max(O+x-i+1,0)][min(dr+1,2001)]|=1;
            }
        }
    }

    for(int i=1;i<=2000;i++)
        for(int j=1;j<=2000;j++){
            A[i][j]+=A[i-1][j]+A[i][j-1]-A[i-1][j-1];
            if(A[i][j]||B[i][j]==3) ans+=1;
            else if(B[i][j]) ans+=0.5;
        }

    printf("%.2lf\n",ans);

    return 0;
}
