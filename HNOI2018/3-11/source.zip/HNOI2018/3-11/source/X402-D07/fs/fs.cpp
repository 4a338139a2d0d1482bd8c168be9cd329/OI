#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=15;

int n,q,sum;
int p[(1<<maxn)+10],cur,cnt[maxn+5];

int main(){
    freopen("fs.in","r",stdin);
    freopen("fs.out","w",stdout);

    read(n); read(q);

    int lim=(1<<n)-3;

    while(cur<=lim){
        int base=n;
        while(1){
            p[++cur]=((1<<(base-1))+(++cnt[base])-1)/2;
            if(base==1) p[cur]=3;
            if(!(cnt[base]&1)||base==2) --base;
            else break;
        }
    }

    while(q--){
        int a,d,m; sum=0;
        read(a); read(d); read(m);
        for(int i=0;i<m;i++) sum+=p[a+i*d];
        printf("%d\n",sum);
    }

    return 0;
}
