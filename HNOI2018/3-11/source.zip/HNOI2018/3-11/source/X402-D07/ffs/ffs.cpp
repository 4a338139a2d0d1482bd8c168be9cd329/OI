#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(),(x).end()

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=1010,INF=0x3f3f3f3f;

int n,q,a[maxn];

vector<int> p[maxn];

int main(){
    freopen("ffs.in","r",stdin);
    freopen("ffs.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++) read(a[i]);
    for(int l=1;l<=n;l++){
        int L=INF,R=0;
        for(int r=l;r<=n;r++){
            chkmin(L,a[r]); chkmax(R,a[r]);
            if(r-l+1==R-L+1) p[l].pb(r);
        }
    }

    read(q);
    while(q--){
        int l,r,L,R,ans=INF;
        read(l); read(r);
        for(int i=l;i;i--){
            int pos=lower_bound(ALL(p[i]),r)-p[i].begin();
            if(pos<SZ(p[i])&&chkmin(ans,p[i][pos]-i+1)) L=i,R=p[i][pos];
        }
        printf("%d %d\n",L,R);
    }

    return 0;
}
