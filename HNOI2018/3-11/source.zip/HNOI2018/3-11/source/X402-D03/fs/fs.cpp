#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline ll read() {
	ll x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int K, Q;

namespace PlanA {
	const int MAXN = 40010;
	int p[MAXN], cnt;

	void calc(int u, int dep, bool f) {
		if(dep == K) return;
		calc(u<<1, dep+1, false);
		p[++cnt] = u;
		if(f) {
			if(dep != K-1) p[++cnt] = (u<<1|1);
			calc(u<<1|1, dep+1, true);
		}
		else {
			calc(u<<1|1, dep+1, false);
			p[++cnt] = u;
		}
	}
	inline void solve() {
		int i;
		PlanA::calc(1, 1, 1);
		Q = read();
		while(Q--) {
			int a = read(), d = read(), m = read();
			ll ans = 0;
			for(i = 0; i < m; i++) ans += p[a+i*d];
			printf("%lld\n", ans);
		}
	}
}

namespace PlanB {
#define fst first
#define snd second
#define mkp make_pair
	typedef pair<ll, ll> pll;
	pll operator + (const pll &a, const pll &b) {
		return mkp(a.fst+b.fst, a.snd+b.snd);
	}
	int cnt[2];
	ll d;
	pll p[2][40010], sum[2][40010];
	int prek = 15;
	void calc(pll u, int dep, bool f, bool t) {
		if(dep == prek) return;
		calc(mkp(u.fst<<1, u.snd<<1), dep+1, false, t);
		p[t][++cnt[t]] = u;
		if(f) {
			if(dep != prek-1) p[t][++cnt[t]] = mkp(u.fst<<1, u.snd<<1|1);
			calc(mkp(u.fst<<1, u.snd<<1|1), dep+1, true, t);
		}
		else {
			calc(mkp(u.fst<<1, u.snd<<1|1), dep+1, false, t);
			p[t][++cnt[t]] = u;
		}
	}
	ll query(ll u, int dep, bool f, ll a) {
		if(dep == K-prek+1) {
			return sum[f][a].fst*u+sum[f][a].snd;
		}
		ll n = (1LL<<(K-dep))-2, res = 0;
		if(a <= n) {
			res += query(u<<1, dep+1, false, a);
			//if(u == 1) printf(">>> %lld %lld\n", res, a);
			if(((n+1)-a)%d == 0) res += u;
			if(f) {
				n += 2;
				if((n-a)%d == 0) res += (u<<1|1);
				res += query(u<<1|1, dep+1, true, ((n-a)/d+1)*d+a-n);
				return res;
			}
			n++;
			res += query(u<<1|1, dep+1, false, ((n-a)/d+1)*d+a-n);
			n = (1LL<<(K-dep+1))-2;
			if((n-a)%d == 0) res += u;
			return res;
		}
		n++;
		if(a == n) res += u;
		if(f) {
			n++;
			if(n >= a && (n-a)%d == 0) res += (u<<1|1);
			if(a <= n) a += ((n-a)/d+1)*d;
			res += query(u<<1|1, dep+1, true, a-n);
			return res;
		}
		if(a <= n) a += d;
		if(a < (1LL<<(K-dep+1))-2) res += query(u<<1|1, dep+1, false, a-n);
		//if(u == 2) printf(">> %lld %lld (%lld)\n", res, a, n);
		n = (1LL<<(K-dep+1))-2;
		//if(u == 2) printf(">> %lld %lld (%lld)\n", res, a, n);
		if((n-a)%d == 0) res += u;
		//if(u == 2) printf(">> %lld %lld\n", res, a);
		return res;
	}
	inline void solve() {
		int i;
		ll a, m;
		calc(mkp(1LL, 0), 1, 0, 0);
		calc(mkp(1LL, 0), 1, 1, 1);
		/*for(i = 1; i <= cnt[0]; i++)
			printf("(%lld, %lld), ", p[0][i].fst, p[0][i].snd);
		printf("\n");
		for(i = 1; i <= cnt[1]; i++)
			printf("(%lld, %lld), ", p[1][i].fst, p[1][i].snd);
		printf("\n");*/
		Q = read();
		while(Q--) {
			a = read(), d = read(), m = read();
			for(i = cnt[0]; i >= 1; i--) {
				sum[0][i] = p[0][i];
				if(i + d > cnt[0]) continue;
				sum[0][i] = sum[0][i]+ sum[0][i+d];
			}
			for(i = cnt[1]; i >= 1; i--) {
				sum[1][i] = p[1][i];
				if(i + d > cnt[1]) continue;
				sum[1][i] = sum[1][i]+ sum[1][i+d];
			}
			printf("%lld\n", query(1, 1, 1, a)-query(1, 1, 1, a+m*d));
		}
	}
}

int main() {
	freopen("fs.in", "r", stdin);
	freopen("fs.out", "w", stdout);

	K = read();
	if(K <= 15) PlanA::solve();
	else PlanB::solve();
	return 0;
}
