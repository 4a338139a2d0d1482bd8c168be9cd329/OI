#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 40010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int K, Q;
int p[MAXN], cnt;

void calc(int u, int dep, bool f) {
	if(dep == K) return;
	calc(u<<1, dep+1, false);
	p[++cnt] = u;
	if(f) {
		if(dep != K-1) p[++cnt] = (u<<1|1);
		calc(u<<1|1, dep+1, true);
	}
	else {
		calc(u<<1|1, dep+1, false);
		p[++cnt] = u;
	}
}

int main() {
	freopen("fs.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i;
	K = read();
	calc(1, 1, 1);
	/*for(i = 1; i <= cnt; i++) printf("%d ", p[i]);
	printf("\n");*/
	Q = read();
	while(Q--) {
		int a = read(), d = read(), m = read();
		ll ans = 0;
		for(i = 0; i < m; i++) ans += p[a+i*d];
		printf("%lld\n", ans);
	}
	return 0;
}
