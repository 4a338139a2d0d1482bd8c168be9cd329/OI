#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
char qwer;
bool gchar(){
	do qwer=getchar(); while(qwer!='A'&&qwer!='B');
	if (qwer=='A') return 1; return 0;
}
const int N=3003,M=6003;
int an[N][N],anl[M][N],anr[M][N]; bool fll[M][N][2],flr[M][N][2];
int main(){
	freopen("skss.in","r",stdin); freopen("skss.out","w",stdout);
	int n=read(),x,y,z,f,a,b,c,d,asdf,ans=0,s=0,mo,ha;
	For(_,1,n){
		f=gchar(),x=read()+1500,y=read()+1500,z=read()>>1;
		if (f){
			a=y-z,b=y+z-1,c=x-z,d=x+z;
			For(i,a,b) ++an[c][i],--an[d][i];
		}
		else{
			a=b=x,c=x-1,d=x; asdf=y-z; mo=asdf+a; ha=asdf-b+3000;
			For(i,asdf,y-1){
				++anl[mo][i]; --anr[ha][i]; fll[mo-1][i][0]=flr[ha][i][1]=1;
			}
			a=b=x,c=x-1,d=x; asdf=y+z-1; ha=asdf-a+3000; mo=asdf+a;
			for(int i=asdf;i>=y;--i){
				--anl[mo][i]; ++anr[ha][i]; fll[mo][i][1]=flr[ha+1][i][0]=1;
			}
		}
	}
	//cerr<<' '<<clock()<<endl;
	For(i,0,2999)
		For(j,0,2999) an[i][j]+=(anl[i+j][j]+anr[j-i+3000][j]);
	For(i,0,2999){
		f=0;
		For(j,0,2999){
			f+=an[j][i]; if (f) ++ans;
			else{
				a=fll[i+j][i][0],b=flr[i-j+3000][i][1],c=flr[i-j+3000][i][0],d=fll[i+j][i][1];
				if ((a&d)||(b&c)) ++ans;
				else{
					asdf=a+b+c+d;
					if (asdf==1) s+=2;
					else if (asdf==2) s+=3;
				}
			}
		}
	}
	printf("%.2lf\n",(double)ans+(double)s/4); //cerr<<clock()<<endl;
	return 0;
}
//cpu:phew!1.000s!
