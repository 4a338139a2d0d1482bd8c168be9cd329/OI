#include<bits/stdc++.h>
#define ll long long
#define Mid ((l+r)>>1)
#define lson rt<<1,l,Mid
#define rson rt<<1|1,Mid+1,r
const int MAXN=100000+10,inf=0x3f3f3f3f;
int n,q,Max[MAXN<<2],Min[MAXN<<2],Mn,Mx;
std::vector<int> G[MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline void PushUp(int rt)
{
	Max[rt]=max(Max[rt<<1],Max[rt<<1|1]);
	Min[rt]=min(Min[rt<<1],Min[rt<<1|1]);
}
inline void Build(int rt,int l,int r)
{
	if(l==r)
	{
		read(Min[rt]);
		Max[rt]=Min[rt];
	}
	else
	{
		Build(lson);
		Build(rson);
		PushUp(rt);
	}
}
inline void Query(int rt,int l,int r,int L,int R)
{
	if(L<=l&&r<=R)
	{
		chkmax(Mx,Max[rt]);
		chkmin(Mn,Min[rt]);
	}
	else
	{
		if(L<=Mid)Query(lson,L,R);
		if(R>Mid)Query(rson,L,R);
	}
}
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	read(n);
	Build(1,1,n);
	for(register int i=1;i<=n;++i)
		for(register int j=i;j<=n;++j)
		{
			Mx=-inf,Mn=inf;
			Query(1,1,n,i,j);
			if(Mx-Mn==j-i)G[i].push_back(j);
		}
	read(q);
	while(q--)
	{
		int x,y,al,ar,res=inf;
		read(x);read(y);
		for(register int i=x;i>=1;--i)
		{
			int l=0,r=G[i].size()-1,now=r;
			while(l<r)
			{
				int mid=(l+r)>>1;
				if(G[i][mid]>=y)now=mid,r=mid;
				else l=mid+1;
			}
			if(G[i][now]<y)continue;
			if(G[i][now]-i+1<res)
			{
				res=G[i][now]-i+1;
				al=i,ar=G[i][now];
			}
		}
		write(al,' ');write(ar,'\n');
	}
	return 0;
}
