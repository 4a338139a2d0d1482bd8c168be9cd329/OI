#include<bits/stdc++.h>
#define ll long long
const int MAXN=40000+10;
int prufer[MAXN],cnt,k,p;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline void dfs(int x,int f,int deep)
{
	if(deep>k)return ;
	dfs(x<<1,x,deep+1);
	dfs(x<<1|1,x,deep+1);
	if(f)prufer[++cnt]=f;
}
int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	read(k);read(p);
	dfs(1,0,1);
	cnt--;
	while(p--)
	{
		int a,d,m;
		read(a);read(d);read(m);
		ll res=0;
		for(register int i=0;i<=m-1;++i)res+=prufer[a+i*d];
		write(res,'\n');
	}
	return 0;
}
