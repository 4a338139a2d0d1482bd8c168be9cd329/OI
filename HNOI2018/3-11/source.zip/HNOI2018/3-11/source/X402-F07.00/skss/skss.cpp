#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=200005,maxm=3005,zero=1500;
int n;
struct Query{
	bool type;
	int x,y,d;
	void input(){
		static char s[10];
		scanf("%s",s);
		x=read(),y=read(),d=read();
		type=s[0]=='A';
	}
}q[maxn];
struct data{int l,r,x;};
vector<data>G[maxm];
int cnt[maxm],delt[maxm];
int main(){
#ifndef ONLINE_JUDGE
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
#endif
	n=read();
	bool flag=1;
	REP(i,1,n){
		q[i].input();
		flag&=q[i].type;
	}
	if(flag){
		REP(i,1,n){
			int x=q[i].x,y=q[i].y,d=q[i].d;
			G[x-d/2+zero].pb((data){y-d/2+zero,y+d/2+zero,1});
			G[x+d/2+zero].pb((data){y-d/2+zero,y+d/2+zero,-1});
		}
		int ans=0,res=0;
		REP(i,0,3000){
			REP(j,0,3000)delt[j]=0;
			REP(j,0,G[i].size()-1){
				delt[G[i][j].l]+=G[i][j].x;
				delt[G[i][j].r]-=G[i][j].x;
			}
			REP(j,0,3000){
				if(j>0)delt[j]+=delt[j-1];
				if(cnt[j]==0)++res;
				cnt[j]+=delt[j];
				if(cnt[j]==0)--res;
			}
			ans+=res;
		}
		printf("%d.00\n",ans);
	}
	return 0;
}
