#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
int n,q_cnt;
int a[maxn],b[maxn],log_2[maxn];
struct RMQ{
	int Min[maxn][17],Max[maxn][17];
	void init(const int *val){
		REP(i,1,n)
			Min[i][0]=Max[i][0]=val[i];
		REP(j,1,16)
			REP(i,1,n-(1<<j)+1){
				Min[i][j]=min(Min[i][j-1],Min[i+(1<<j-1)][j-1]);
				Max[i][j]=max(Max[i][j-1],Max[i+(1<<j-1)][j-1]);
			}
	}
	pair<int,int>query(int l,int r){
		int t=log_2[r-l+1];
		return make_pair(min(Min[l][t],Min[r-(1<<t)+1][t]),max(Max[l][t],Max[r-(1<<t)+1][t]));
	}

}R1,R2;
int main(){
#ifndef ONLINE_JUDGE
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
#endif
	n=read();
	REP(i,1,n)a[i]=read(),b[a[i]]=i;
	R1.init(a),R2.init(b);
	REP(i,1,n){
		if(i==(i&-i))log_2[i]=__builtin_ctz(i);
		else log_2[i]=log_2[i-1];
	}
#define x first
#define y second
	q_cnt=read();
	pair<int,int>A,B;
	REP(i,1,q_cnt){
		A=make_pair(read(),read());
		B=R1.query(A.x,A.y);
		while((A.y-A.x)!=(B.y-B.x))
			A=R2.query(B.x,B.y),B=R1.query(A.x,A.y);
		write(A.x,' '),write(A.y,'\n');
	}
#undef x
#undef y
	return 0;
}
