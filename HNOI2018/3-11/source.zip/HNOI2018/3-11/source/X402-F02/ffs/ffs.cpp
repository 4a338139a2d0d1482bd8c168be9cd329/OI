#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("ffs.in","r",stdin);
      freopen("ffs.out","w",stdout);
  #endif
}
int n,a[N],q;
int Min[N][18],Max[N][18];
void input()
{
	n=read<int>();
	For(i,1,n)a[i]=read<int>();
}
int pos[N],mc[30],Log[N];
int rt[N],ls[N*40],rs[N*40],sum[N*40],sz;
void insert(int &h,int pre,int l,int r,int pos)
{
	h=++sz;
	ls[h]=ls[pre],rs[h]=rs[pre],sum[h]=sum[pre]+1;
	if(l==r)return;
	int mid=(l+r)>>1;
	if(pos<=mid)insert(ls[h],ls[pre],l,mid,pos);
	else insert(rs[h],rs[pre],mid+1,r,pos);
}
int query(int h1,int h2,int l,int r,int s,int t)
{
	if(s<=l&&r<=t&&sum[h2]-sum[h1]==r-l+1)return 0;	
	if(l==r)return l;
	int res,mid=(l+r)>>1;
	if(s<=mid)
	{
		res=query(ls[h1],ls[h2],l,mid,s,t);
		if(res)return res;
	}
	if(mid<t)return query(rs[h1],rs[h2],mid+1,r,s,t);
}
void init()
{
	For(i,1,n)pos[a[i]]=i;
	For(i,1,n)Min[i][0]=Max[i][0]=a[i];
	mc[0]=1;For(i,1,20)mc[i]=mc[i-1]<<1;
	For(i,1,n)Log[i]=Log[i>>1]+1;
	For(j,1,17)for(register int i=1;i+mc[j]-1<=n;++i)
	{
		Min[i][j]=min(Min[i][j-1],Min[i+mc[j-1]][j-1]);
		Max[i][j]=max(Max[i][j-1],Max[i+mc[j-1]][j-1]);
	}
	For(i,1,n)insert(rt[i],rt[i-1],1,n,a[i]);
}
int query_min(int l,int r)
{
	int k=Log[r-l+1]-1;
	return min(Min[l][k],Min[r-mc[k]+1][k]);
}
int query_max(int l,int r)
{
	int k=Log[r-l+1]-1;
	return max(Max[l][k],Max[r-mc[k]+1][k]);
}
void cal(int l,int r)
{
	int temp,t1,t2;
	while(1)
	{
		t1=query_min(l,r),t2=query_max(l,r);
		temp=query(rt[l-1],rt[r],1,n,t1,t2);
		if(!temp)break;
		if(pos[temp]<l)l=pos[temp];
		else r=pos[temp];
	}
	write(l,' '),write(r,'\n');
}
void work()
{
	int l,r;
	q=read<int>();
	while(q--)
	{
		l=read<int>(),r=read<int>();
		cal(l,r);
	}
}
int main()
{
	file();
	input();
	init();
	work();
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
