#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("fs.in","r",stdin);
      freopen("fs.out","w",stdout);
  #endif
}
int k,T;
void input()
{
	k=read<int>();T=read<int>();
}
namespace sub1
{
	const int N=35000;
	int a[N],top,head[N],tt,n;
	struct edge
	{
		int v,nex;
	}e[N<<1];
	int in[N];
	void add(int x,int y)
	{
		++in[x],++in[y];
		e[++tt]=(edge){y,head[x]};head[x]=tt;
		e[++tt]=(edge){x,head[y]};head[y]=tt;
	}
	int power(int x,int y)
	{
		int res=1;
		for(;y;x=x*x,y>>=1)if(y&1)res=res*x;
		return res;
	}
	priority_queue<int,vector<int>,greater<int> >q;
	void init()
	{
		For(i,2,n)add(i/2,i);
		int s=(n+1)>>1;
		For(i,s,n)q.push(i);
		int u,v;
		while(top<n-2)
		{
			u=q.top(),q.pop();
			for(register int i=head[u];i;i=e[i].nex)
			{
				v=e[i].v;
				if(in[v]>1)
				{
					a[++top]=v;
					if((--in[v])==1)q.push(v);
				}
			}
		}
		//For(i,1,top)cout<<a[i]<<' ';
	}
	ll ans;
	void solve()
	{
		n=power(2,k)-1;
		init();
		int st,d,m;
		while(T--)
		{
			st=read<int>();d=read<int>();m=read<int>();
			ans=0;
			For(i,1,m)ans+=a[st],st+=d;
			write(ans,'\n');
		}
	}
}
void work()
{
	sub1::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
