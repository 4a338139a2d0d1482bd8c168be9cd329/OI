#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
typedef long long LL;
using namespace std;
Temp inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
inline void File(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}

const int maxn=100000+10;
int n,q;
int a[maxn];
int Max[maxn<<2],Min[maxn<<2];
bool Good[maxn<<2];
int amax,amin;

#define len (r-l+1)
#define mid ((l+r)>>1)
#define lson rt<<1,l,mid
#define rson rt<<1|1,mid+1,r

inline void build(int rt,int l,int r){
	if(l==r){Max[rt]=Min[rt]=a[l];Good[rt]=1;return;}
	build(lson);
	build(rson);
	
	Max[rt]=max(Max[rt<<1],Max[rt<<1|1]);
	Min[rt]=min(Min[rt<<1],Min[rt<<1|1]);
	if(Max[rt]-Min[rt]==len)Good[rt]=1;
}
inline void query(int rt,int l,int r,int L,int R){
	if(L<=l&&r<=R){
		amax=max(amax,Max[rt]);
		amin=min(amin,Min[rt]);
		return;
	}
	if(L<=mid)query(lson,L,R);
	if(R>mid)query(rson,L,R);
}
inline bool query_init(int L,int R){
	amax=0;amin=n+1;
	query(1,1,n,L,R);
	if(amax-amin==(R-L))return true;
	else return false;
}

int main(){
	File();
	read(n);
	for(Rint i=1;i<=n;i++)read(a[i]);
	build(1,1,n);
	read(q);
	while(q--){
		int x,y;read(x);read(y);
		if(query_init(x,y)){
			printf("%d %d\n",x,y);
			continue;
		}
		int lenn=amax-amin+1;
		for(Rint i=max(1,y-lenn+1);i<=x&&(i+lenn-1)<=n;i++){
			if(query_init(i,i+lenn-1)){
				printf("%d %d\n",i,i+lenn-1);
				break;
			}
		}
	}
    return 0;
}
