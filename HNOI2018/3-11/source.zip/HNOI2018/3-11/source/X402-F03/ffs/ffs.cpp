#include<iostream>
#include<cstdio>
using namespace std;
int a[202020],b[202020];
int n,q,b_l,b_r,maxn,minn;
void check(int x)
{
	if (b_l<=x && x<=b_r) return;
	if (x<b_l)
	{
		for (int i=x;i<b_l;++i)
			maxn=max(maxn,b[i]),minn=min(minn,b[i]);
		b_l=x;
	}
	else
	{
		for (int i=b_r+1;i<=x;++i)
			maxn=max(maxn,b[i]),minn=min(minn,b[i]);
		b_r=x;
	}
}
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	int x,y;
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&x);
		a[i]=x;
		b[x]=i;
	}
	scanf("%d",&q);
	for (int i=1;i<=q;++i)
	{
		maxn=b_r=-1;
		minn=b_l=n+n;
		scanf("%d%d",&x,&y);
		for (int j=x;j<=y;++j)
			b_l=min(b_l,a[j]),b_r=max(b_r,a[j]);
		for (int j=b_l;j<=b_r;++j) 
			maxn=max(maxn,b[j]),minn=min(minn,b[j]);
		while (minn!=x || maxn!=y)
		{
			while (minn!=x)
			{
				--x;
				check(a[x]);
			}
			while (maxn!=y)
			{
				++y;
				check(a[y]);
			}
		}
		printf("%d %d\n",x,y);
	}
	return 0;
}
