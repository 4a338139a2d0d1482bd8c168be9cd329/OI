#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
int k,q;
int two[50],a[10101010];
ll ans;
void dfs(int l,int r,int x)
{
	int mid=(l+r)/2;
	a[mid]=x;
	a[r]=x;
	if (l+1==r) return;
	dfs(l,mid-1,x*2);
	dfs(mid+1,r-1,x*2+1);
}
int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	two[0]=1;
	for (int i=1;i<=30;++i)
		two[i]=two[i-1]*2;
	scanf("%d%d",&k,&q);
	dfs(1,two[k]-2,1);
//	for (int i=1;i<=two[k]-3;++i)
//		printf("%d\n",a[i]);
	int x,y,z;
	for (int i=1;i<=q;++i)
	{
		ans=0;
		scanf("%d%d%d",&x,&y,&z);
		z=x+(z-1)*y;
		for (int j=x;j<=z;j+=y)
			ans+=a[j];
		printf("%lld\n",ans);
	}
	return 0;
}
