#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=(1<<25);
int b[maxn];
int len;
int n;
void dfs(int x){
	if((x<<1)<n){
		dfs(x<<1);
		b[++len]=x;
		dfs(x<<1|1);
		b[++len]=x;
	}
}
int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	int k,cas;
	cin>>k>>cas;
	int a,d,m;
	n=(1<<k)-1;	
	dfs(1);
	while(cas--){
		scanf("%d%d%d",&a,&d,&m);
		long long ans=0;
		for(int i=0;i<m;++i){
			ans+=(long long)b[a];
			a+=d;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
