#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 3000;

namespace SEG {
    const int SZ = N << 2;

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    int add[SZ + 5];

    void modify(int u, int l, int r, int x, int y, int z) {
        if(x <= l && r <= y) {
            add[u] += z;
            return;
        }

        if(x <= mid) 
            modify(lc, l, mid, x, y, z);
        if(mid < y)
            modify(rc, mid+1, r, x, y, z);
    }

    int query(int u, int l, int r, int x) {
        if(l == r) return add[u];
        
        if(x <= mid) 
            return query(lc, l, mid, x) + add[u];
        else 
            return query(rc, mid+1, r, x) + add[u];
    }
}

int n;
struct Line { 
    int l, r, sgn; 
    Line(int _l=0, int _r=0, int _s=0): l(_l), r(_r), sgn(_s) { }
};

vector<Line> P[N + 5];

void solve_a() {
    for(int i = 1; i <= n; ++i) {
        static char ty[2];
        static int x, y, a;

        scanf("%s", ty);
        read(x), read(y), read(a);

        x += 1500, y += 1500, a /= 2;
        P[x - a].pb(Line(y-a, y+a-1, +1));
        P[x + a].pb(Line(y-a, y+a-1, -1));
    }

    int ans = 0, tmp = 0;
    for(int i = 0; i <= N; ++i) {
        if(P[i].size()) {
            tmp = 0;
            for(int j = 0; j < (int) P[i].size(); ++j) 
                SEG::modify(1, 0, N, P[i][j].l, P[i][j].r, P[i][j].sgn);
            for(int j = 0; j <= N; ++j) tmp += (SEG::query(1, 0, N, j) > 0);
        }
        ans += tmp;
    }
    printf("%d.00\n", ans);
}

int main() {
    freopen("skss.in", "r", stdin);
    freopen("skss.out", "w", stdout);

    read(n);
    solve_a(); 

    // if(n <= 1000) { } else 

    return 0;
}
