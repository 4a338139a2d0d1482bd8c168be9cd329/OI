#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;

struct SEG {
    static const int SZ = N << 2;

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    int mx[SZ + 5], mn[SZ + 5];

    void build(int u, int l, int r, int *a) {
        if(l == r) {
            mn[u] = mx[u] = a[l];
            return;
        }

        build(lc, l, mid, a);
        build(rc, mid+1, r, a);

        mx[u] = mx[lc] > mx[rc] ? mx[lc] : mx[rc];
        mn[u] = mn[lc] < mn[rc] ? mn[lc] : mn[rc];
    }

    pii query(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return mp(+oo, -oo);
        if(x <= l && r <= y) return mp(mn[u], mx[u]);
        
        pii tl = query(lc, l, mid, x, y);
        pii tr = query(rc, mid+1, r, x, y);

        return std::make_pair(std::min(tl.fst, tr.fst), std::max(tl.snd, tr.snd));
    }
};

SEG T[2];

int n, q;
int p[N + 5], r[N + 5];
std::map<pii, pii> mp;

int main() {
    freopen("ffs.in", "r", stdin);
    freopen("ffs.out", "w", stdout);

    read(n);
    for(int i = 1; i <= n; ++i) {
        read(p[i]), r[p[i]] = i;
    }

    T[0].build(1, 1, n, p);
    T[1].build(1, 1, n, r);

    read(q);
    for(int i = 0; i < q; ++i) {
        static int x, y;
        read(x), read(y);

        pii pos = mp(x, y), val = T[0].query(1, 1, n, pos.fst, pos.snd);

        while(pos.snd - pos.fst != val.snd - val.fst) {
            pos = T[1].query(1, 1, n, val.fst, val.snd);
            val = T[0].query(1, 1, n, pos.fst, pos.snd);
        }

        printf("%d %d\n", pos.fst, pos.snd);
    }

    return 0;
}
