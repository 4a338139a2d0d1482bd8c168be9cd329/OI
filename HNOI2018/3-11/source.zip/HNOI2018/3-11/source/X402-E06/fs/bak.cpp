#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int K = 30;
const int N = 1 << 15;

int k, q, b;
ll pw[K + 5];

int query_val(int cur, int kth, int d, int ty) {
    if(ty == 1) {
        if(kth== (1 << (k-d)) - 1) return cur;
        if(kth== (1 << (k-d+1)) - 2) return cur;

        if(kth < (1 << (k - d)))
            return query_val(cur << 1, kth, d + 1, 1);
        else 
            return query_val(cur << 1 | 1, kth-(1<<(k-d))+1, d + 1, 1);
    } else {
        if(kth== (1 << (k-d)) - 1) return cur;
        if(kth== (1 << (k-d))) return cur << 1 | 1;

        if(kth < (1 << (k-d)) - 1) {
            return query_val(cur << 1, kth, d + 1, 1);
        } else {
            return query_val(cur << 1 | 1, kth - (1 << (k-d)), d + 1, 0);
        }
    }
}

int id;
int a, c, d, m;
int cnt[N + 5];
ll s[2][N + 5], v[2][N + 5], ans;

int op;
void dfs_init(int dep, int cur, int ty) {
    if(dep >= k-b) { return; }

    dfs_init(dep + 1, cur << 1, 1);

    ++ id;
    cnt[op][id % d] ++;
    v[op][id % d] += pw[dep-1];
    s[op][id % d] += cur;

    dfs_init(dep + 1, cur << 1 | 1);

    ++ id;
    if(dep) {
        cnt[id % d] ++;
        v[id % d] += (pw[dep-1]);
    }
}

void bf_calc(int dep, int cur) {
    if(dep >= k-b) return;

    bf_calc(dep + 1, cur << 1);
    bf_calc(dep + 1, cur << 1 | 1);

    ++ id;
    if(dep) {
        if(c < m && id == (a + d*c)) ans += cur / 2, ++ c;
    }
}
 
void dfs_calc(int dep, int cur) {
    if(dep > b) {
        int nxt = id + (1 << (k-b)) - 1;

        if(c < m && (a + d*c) <= nxt) {
            int x = ((a - id) % d + d) % d;

            if(a + (m-1)*d <= nxt || c == 0) {
                bf_calc(0, cur);
            } else {
                ans += s[x] + v[x] * (cur - 1);
                c += cnt[x];
            }
        }

        id = nxt;
        if(c < m && id == (a + d*c)) ans += cur / 2, ++ c;
        return;
    }

    dfs_calc(dep + 1, cur << 1);
    dfs_calc(dep + 1, cur << 1 | 1);

    ++ id;
    if(c < m && id == (a + d*c)) ans += cur / 2, ++ c;
}

int main() {
    freopen("fs.in", "r", stdin);
    freopen("fs.out", "w", stdout);
    
    read(k), read(q);

    pw[0] = 1;
    for(int i = 1; i <= k; ++i) pw[i] = pw[i-1] << 1;

    for(int i = 1; i <= (1<<k)-3; ++i) {
        printf("%d ", query_val(1, i, 1, 0));
    }
    /*
    b = (k+1) >> 1;
    while(q--) {
        read(a), read(d), read(m);

        ans = 0;
        if(m <= (1 << b)) {
            for(int i = 0; i < m; ++i) 
                ans += query_val(1, a + i*d, 1, 0);
        } else {
            memset(s, 0, sizeof s);
            memset(v, 0, sizeof v);
            memset(cnt, 0, sizeof cnt);

            c = 0;
            id = 0; dfs_init(0, 1);
            id = 0; dfs_calc(1, 1);
        }
        printf("%lld\n", ans);
    }
    */

    return 0;
}

