#include<bits/stdc++.h>
using namespace std;
const int maxn=2010;
struct node{
	int l,r;
};
bool vis[maxn],ok[maxn][maxn];
node b[maxn][maxn];
int a[maxn];
node Min(const node &A,const node &B){
	return A.r-A.l<B.r-B.l?A:B;
}
int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)
			vis[j]=0;
		int cnt=0;
		for(int j=i;j<=n;j++){
			vis[a[j]]=1;
			if(vis[a[j]-1]) cnt--;
			else cnt++;
			if(vis[a[j]+1]) cnt--;
			else cnt++;
			if(cnt==2)
				ok[i][j]=1;
		}
	}
	for(int i=0;i<=n+1;i++)
		for(int j=0;j<=n+1;j++)
			b[i][j]=(node){1,n};
	for(int l=n-1;l>=0;l--){
		for(int i=1;i+l<=n;i++){
			int j=i+l;
			if(ok[i][j]) b[i][j]=(node){i,j};
			else b[i][j]=Min(b[i-1][j],b[i][j+1]);
		}
	}
	int Q;
	scanf("%d",&Q);
	int l,r;
	while(Q--){
		scanf("%d%d",&l,&r);
		printf("%d %d\n",b[l][r].l,b[l][r].r);
	}
	return 0;
}
