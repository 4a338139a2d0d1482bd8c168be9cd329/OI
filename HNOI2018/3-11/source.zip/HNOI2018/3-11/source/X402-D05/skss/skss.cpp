#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
char str[10];
int a[3010][3010];
int main(){
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
	int n;
	scanf("%d",&n);
	int x,y,d;
	for(int i=1;i<=n;i++){
		scanf("%s",str+1);
		scanf("%d%d%d",&x,&y,&d);
		d/=2;
		x+=1500,y+=1500;
		a[x+d][y+d]++;
		a[x-d][y-d]++;
		a[x+d][y-d]--;
		a[x-d][y+d]--;
	}
	for(int i=3005;i>=0;i--)
		for(int j=3005;j>=0;j--)
			a[i][j]+=a[i+1][j];
	for(int i=3005;i>=0;i--)
		for(int j=3005;j>=0;j--)
			a[i][j]+=a[i][j+1];
	int ans=0;
	for(int i=0;i<=3005;i++)
		for(int j=0;j<=3005;j++)
			if(a[i][j]>0)
				ans++;
	printf("%d.00\n",ans);
	return 0;
}
