#include<bits/stdc++.h>
using namespace std;
const int maxn=1<<17;
int a[maxn],b[maxn];
int popws[maxn],T;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
int Min(int x,int y){
	return x<y?x:y;
}
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void clear_graph(){
	memset(beg,0,sizeof(beg));
	e=0;
}
void getprufer(int *A,int k,bool is_true_root){
	static int vis[maxn],d[maxn];
	static priority_queue<int,vector<int>,greater<int> > q;
	int cnt=0;
	for(int i=0;i<(1<<k);i++)
		vis[i]=0,d[i]=0;
	clear_graph();
	for(int i=2;i<(1<<k);i++){
		putin(i>>1,i);
		putin(i,i>>1);
		d[i>>1]++,d[i]++;
	}
	d[1]+=!is_true_root;
	while(!q.empty()) q.pop();
	for(int i=1;i<(1<<k);i++)
		if(d[i]==1)
			q.push(i);
	int u;
	while(!q.empty()){
		if(is_true_root&&cnt==(1<<k)-3) break;
		if(!is_true_root&&cnt==(1<<k)-2) break;
		u=q.top(),q.pop();
		vis[u]=1;
		for(int i=beg[u];i;i=nex[i]){
			if(vis[tto[i]]) continue;
			A[++cnt]=tto[i];
			d[tto[i]]--;
			if(d[tto[i]]==1)
				q.push(tto[i]);
		}
	}
}
void csh(){
	popws[0]=1;
	for(int i=1;i<(1<<15);i++)
		popws[i]=popws[i>>1]<<1;
}
namespace Solve{
	long long k;
	long long s,d,m;
	long long ans;
	struct node{
		long long ws,v;
	};
	node operator + (const node &A,const node &B){
		return (node){A.ws+B.ws,A.v+B.v};
	}
	node operator - (const node &A,const node &B){
		return (node){A.ws-B.ws,A.v-B.v};
	}
	vector<node> veca[maxn],vecb[maxn];
	void getvec(vector<node> *vec,int *A){
		long long upper=Min(d,(1<<(k/2))+1);
		for(int i=1;i<=upper;i++)
			vec[i].resize((1<<(k/2))/d+1);
		long long id,p;
		for(int i=1;i<(1<<(k/2));i++){
			id=(i-1)%d+1,p=(i-1)/d;
			vec[id][p]=(node){popws[A[i]]>>1,A[i]-(popws[A[i]]>>1)};
			if(p>0)
				vec[id][p]=vec[id][p]+vec[id][p-1];
		}
	}
	node Query(vector<node> *vec,long long p){
		if(p>=(1<<(k/2))-1) return (node){0,0};
		long long l=(p-1)/d-1,r=(1<<(k/2))/d;
		int id=(p-1)%d+1;
		while(id+r*d>=(1<<(k/2))-1||r-l>m)
			r--;
		node res=vec[id][r];
		if(l>=0)
			res=res-vec[id][l];
		s+=(r-l)*d;
		m-=r-l;
		return res;
	}
	void dfs(long long u,long long p,int dep){
		if(m<=0) return;
		if(dep+(k>>1)==k){
			node res;
			if(((u+1)&u)==0)
				res=Query(vecb,s-p);
			else
				res=Query(veca,s-p);
			ans=ans+u*res.ws+res.v;
			if(m<=0) return;
			if(p+(1<<(k-dep))-1==s){
				ans+=u>>1;
				s+=d;
				m--;
			}
			return;
		}
		dfs(u<<1,p,dep+1);
		if(m<=0) return;
		if(((u+1)&u)==0){
			if(p+(1<<(k-dep-1))==s){
				ans+=u<<1|1;
				s+=d;
				m--;
			}
			dfs(u<<1|1,p+(1<<(k-dep-1)),dep+1);
		}
		else{
			dfs(u<<1|1,p+(1<<(k-dep-1))-1,dep+1);
			if(m<=0) return;
			if(p+(1<<(k-dep))-1==s){
				ans+=u>>1;
				s+=d;
				m--;
			}
		}
	}
	void solve(){
		ans=0;
		scanf("%lld%lld%lld",&s,&d,&m);
		getvec(veca,a),getvec(vecb,b);
		dfs(1,0,0);
		printf("%lld\n",ans);
	}
}
int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	int k,Q;
	scanf("%d%d",&k,&Q);
	csh();
	getprufer(a,k>>1,0);
	getprufer(b,k>>1,1);
	Solve::k=k;
	for(T=1;T<=Q;T++){
		Solve::solve();
	}
	return 0;
}
