#include<bits/stdc++.h>
using namespace std;
int a[1<<20];
int beg[1<<20],nex[1<<21],tto[1<<21],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void clear_graph(){
	memset(beg,0,sizeof(beg));
	e=0;
}
void getprufer(int k){
	static int vis[1<<20],d[1<<20];
	static priority_queue<int,vector<int>,greater<int> > q;
	int cnt=0;
	clear_graph();
	for(int i=2;i<(1<<k);i++){
		putin(i,i>>1);
		putin(i>>1,i);
		d[i]++,d[i>>1]++;
	}
	for(int i=1;i<(1<<k);i++){
		vis[i]=0;
		if(d[i]==1)
			q.push(i);
	}
	int u;
	while(!q.empty()){
		if((1<<k)-1==cnt+2) break;
		u=q.top(),q.pop();
		vis[u]=1;
		for(int i=beg[u];i;i=nex[i]){
			if(!vis[tto[i]]){
				a[++cnt]=tto[i];
				d[tto[i]]--;
				if(d[tto[i]]==1)
					q.push(tto[i]);
			}
		}
	}
}
int main(){
	freopen("fs.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int k,Q;
	scanf("%d%d",&k,&Q);
	getprufer(k);
	int ans;
	int s,d,m;
	while(Q--){
		scanf("%d%d%d",&s,&d,&m);
		ans=0;
		for(int i=0;i<m;i++){
			ans=ans+a[s+d*i];
			if(s+(d*i)>(1<<k)-3)
				cerr<<"fuck"<<endl;
		}
		printf("%d\n",ans);
		if(Q==0) cerr<<ans<<endl;
	}
	return 0;
}
