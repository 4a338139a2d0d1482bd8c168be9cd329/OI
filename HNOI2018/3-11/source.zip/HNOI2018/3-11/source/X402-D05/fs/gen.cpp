#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=rand()%15+2,m=rand()%300+1;
	printf("%d %d\n",n,m);
	int s,d,M;
	for(int i=1;i<=m;i++){
		if(rand()%2) d=rand()%100+1;
		else d=rand()%((1<<n)-3)+1;
		s=rand()%((1<<n)-3)+1;
		M=rand()%(((1<<n)-3-s)/d+1)+1;
		printf("%d %d %d\n",s,d,M);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("fs.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
