#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("fst.in","w",stdout);
	int n=500,k=8000,r=32;

	printf("%d %d %d\n",n,r,k);
for(int i=1;i<=n;++i)
		printf("%d ",rand()%1000);
for(int i=1;i<=n;++i)
		printf("%d ",rand()%1000);
for(int i=1;i<=n;++i)
		printf("%d ",rand()%1000);

}
