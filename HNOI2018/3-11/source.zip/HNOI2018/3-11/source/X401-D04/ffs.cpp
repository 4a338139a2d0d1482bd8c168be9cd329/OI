#include<bits/stdc++.h>
using namespace std;
const int maxn=(int)1e3+10;
int minn[maxn][maxn],maxx[maxn][maxn],a[maxn],n,q;
inline int init(){
	cin>>n;
	for(register int i=1;i<=n;++i)scanf("%d",&a[i]);
	for(register int i=1;i<=n;++i){
		minn[i][i]=maxx[i][i]=a[i];
		for(register int j=i+1;j<=n;++j){
			maxx[i][j]=max(maxx[i][j-1],a[j]);
			minn[i][j]=min(minn[i][j-1],a[j]);
		}
	}
}
struct shit{
	int a,b;
}ans[maxn][maxn];
inline shit Min(shit x,shit y){
	if(x.b-x.a>y.b-y.a&&y.b&&y.a)return y;
	return x;
}
inline int getans(){
	for(register int i=0;i<=n+1;++i)for(register int j=0;j<=n+1;++j)ans[i][j]={0,0x3f3f3f3f};
	for(register int i=n-1;i>=0;--i){
		for(register int j=1;j+i<=n;++j){
			if(maxx[j][j+i]-minn[j][j+i]==i)ans[j][j+i]={j,j+i};
			else ans[j][j+i]=Min(ans[j-1][j+i],ans[j][j+i+1]);
		}
	}
}
int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	init();
	getans();
	int x,y;
	cin>>q;
	while(q--)scanf("%d%d",&x,&y),printf("%d %d\n",ans[x][y].a,ans[x][y].b);
	return 0;
}

