#include<bits/stdc++.h>
using namespace std;
const int maxn=(int)1e5+10,maxk=17,inf=0x3f3f3f3f;
int bit[maxk+1],finded[maxn];
struct prufer{
	int f[maxn],len,val;
	inline void out(){
		for(register int i=1;i<=len;++i)printf("%d ",f[i]);
		cout<<endl;
	}
}a[maxk],tmp;
inline void init(){
	bit[0]=1;
	for(register int i=1;i<maxk;++i)bit[i]=(bit[i-1]<<1);
	bit[maxk]=inf;
	int j=0;
	for(register int i=1;i<maxn;++i){
		if(bit[j]<=i)++j;
		finded[i]=j;
	}
}
inline prufer spawn(prufer x){
	prufer ans;
	int Len=x.len+bit[x.val+1];
	int j=1,vl=x.val+1,now=bit[vl]-1;
	for(register int i=x.len;i>=1;--i){
		tmp.f[j++]=x.f[i];
		if(finded[x.f[i]]==x.val){
			tmp.f[j++]=now;
			tmp.f[j++]=now--;	
		}
	}
	for(register int i=Len;i>0;--i)ans.f[i]=tmp.f[Len-i+1];
	ans.len=Len,ans.val=vl;
	return ans;
}
int K,Q;
int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.in","r",stdout);
	init();
	cin>>K>>Q;
	a[1].f[1]=1;a[1].len=a[1].val=1;
	a[2].f[1]=a[2].f[2]=2;a[2].f[3]=1;a[2].f[4]=a[2].f[5]=3;a[2].len=5;a[2].val=2;
	for(register int i=3;i<K;++i)a[i]=spawn(a[i-1]);
	int A,D,M;--K;
	while(Q--){
		scanf("%d%d%d",&A,&D,&M);
		long long ans=0,fi=A+(M-1)*D;
		for(register int i=A;i<=fi;i+=D)ans+=a[K].f[i];
		printf("%lld\n",ans);
	}
	return 0;
}

