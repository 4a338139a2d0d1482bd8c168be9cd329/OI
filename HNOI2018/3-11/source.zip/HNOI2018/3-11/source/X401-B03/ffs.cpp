#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
long long ksm(long long x,long long mc)
{
	long long tmp=x%mod;
	long long res=1;
	while(mc)
	{
		if(mc&1ll)res=res*tmp%mod;
		tmp=tmp*tmp%mod;
		mc>>=1ll;
	}
	return res;
}
long long n;
long long p[100100];
long long sum[100100],sqrsum[100100],mul[100100],ssum[100100];
long long tot[100100],tott[100100],tottt[100100],tot1[100100],inv[100100],invv[100100];
set<long long>s,ss,sss,ssss;
vector<int>vec[100100];
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	read(n);
	tottt[0]=mul[0]=1;
	for(long long i=1;i<=n;i++)
	{
		read(p[i]);
//		sum[i]=sum[i-1]+p[i];
		sqrsum[i]=sqrsum[i-1]+p[i]*p[i];
		ssum[i]=ssum[i-1]+p[i]*p[i]*p[i];
//		mul[i]=(mul[i-1]*p[i])%mod;
//		invv[i]=ksm(mul[i],mod-2);
//		tot[i]=tot[i-1]+i;
		tott[i]=tott[i-1]+i*i;
//		tottt[i]=(tottt[i-1]*i)%mod;
		tot1[i]=tot1[i-1]+i*i*i;
	}
//	invv[0]=inv[1]=inv[0]=1;
//	inv[n]=ksm(tottt[n],mod-2ll);
//	for(long long i=n-1;i>=1;i--)inv[i]=inv[i+1]*(i+1)%mod;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			/*s.insert(tot[j]-tot[i-1]),*/ss.insert(tott[j]-tott[i-1]),/*sss.insert(tottt[j]*inv[i-1]%mod),*/ssss.insert(tot1[j]-tot1[i-1]);
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(/*sss.count(mul[j]*invv[i-1]%mod)&&*/ssss.count(ssum[j]-ssum[i-1])&&ss.count(sqrsum[j]-sqrsum[i-1])/*&&s.count(sum[j]-sum[i-1])*/)vec[i].push_back(j);
	long long q;
	read(q);
	while(q--)
	{
		static long long x,y;
		read(x);read(y);
		if(x==y){printf("%lld %lld\n",x,y);continue;}
		static long long sta,ans;sta=x,ans=0x7f7f7f7f;
		static long long a,b;
		while(sta>=1)
		{
			static long long w;
			w=lower_bound(vec[sta].begin(),vec[sta].end(),y)-vec[sta].begin();
			if(w==(long long)vec[sta].size()){sta--;continue;}
			else {
				if(ans>vec[sta][w]-sta)
				{
					ans=vec[sta][w]-sta;
					a=sta;b=vec[sta][w];
				}
				sta--;
			}
			if(y-sta>ans)break;
		}
		printf("%lld %lld\n",a,b);
	}
	return 0;
}
