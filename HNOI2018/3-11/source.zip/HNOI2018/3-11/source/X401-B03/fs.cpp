#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const int N=((1<<16)-1)<<1;
int to[N],beg[N],nex[N];
int ds[N],vis[N];
int e;
void add(int x,int y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
int k,t;
struct node
{
	int x,ed;
	bool operator <(const node &ss)const
	{
		if(ed!=ss.ed)return ed<ss.ed;
		return x<ss.x;
	}
};
set<node>q;
int pru[N],cnt;
void prufer()
{
	for(int i=1;i<=(1<<k)-1;i++)
		q.insert((node){i,ds[i]});
	set<node>::iterator it;
	while(q.size()>2)
	{
		it=q.begin();
		int k=(*it).x;
		vis[k]=1;
		q.erase(it);
		for(int i=beg[k];i;i=nex[i])
			if(!vis[to[i]]){pru[++cnt]=to[i],q.erase((node){to[i],ds[to[i]]}),q.insert((node){to[i],ds[to[i]]-1}),ds[to[i]]--;break;}
	}
}
int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	read(k);read(t);
	for(int i=1;i<=(1<<(k-1))-1;i++)
	{
		add(i,i<<1);
		add(i<<1,i);
		add(i,i<<1|1);
		add(i<<1|1,i);
		ds[i]+=2;ds[i<<1]++;ds[i<<1|1]++;
	}
	prufer();
//	for(int i=1;i<=cnt;i++)
//		cout<<pru[i]<<" ";
//	cout<<endl;
	while(t--)
	{
		static int a,d,m;
		read(a);read(d);read(m);
		int ans=0;
		for(int i=a;i<=a+(m-1)*d;i+=d)
			ans+=pru[i];
		printf("%d\n",ans);
	}
	return 0;
}
