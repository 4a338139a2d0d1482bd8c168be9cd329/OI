#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("ffs1.in","w",stdout);
}

int main(){
	file();
	srand(time(NULL));
	int n=1000;
	printf("%d\n",n);
	int a[220000];
	For(i,1,1000) a[i]=i;
	For(i,1,6){
		int x=rand()%1000+1;
		int y=rand()%1000+1;
		swap(a[x],a[y]);
	}
	For(i,1,n) printf("%d ",a[i]);
	puts("");
	int q=1000;
	cout<<q<<endl;
	For(i,1,q){
		int x=rand()%1000+1;
		int y=rand()%1000+1;
		if(x>y) swap(x,y);
		printf("%d %d\n",x,y);
	}
	return 0;
}

