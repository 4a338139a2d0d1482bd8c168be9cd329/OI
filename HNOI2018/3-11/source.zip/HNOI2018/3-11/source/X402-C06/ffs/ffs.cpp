#include<bits/stdc++.h>
#include<ctime>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}

const int N=1e5+10;
int n,q,A[N],x,y,Gra[N],B[N];
int MIN,MAX,minn,maxx;

bool check(int st,int ed){
	int n=0,S;
	For(i,st,ed) B[++n]=A[i];
	sort(B+1,B+1+n);
	S=B[1]-1;
	For(i,1,n) if(B[i]!=i+S) return false;
	return true;
}

void dfs(int x,int y){
	if(check(x,y)){
		printf("%d %d\n",x,y);
		return;
	}
	MIN=INT_MAX,MAX=INT_MIN;
	minn=x,maxx=y;
	For(i,x,y){
		MAX=max(A[i],MAX);
		MIN=min(A[i],MIN);
	}
	For(i,MIN,MAX){
		minn=min(minn,Gra[i]);
		maxx=max(maxx,Gra[i]);
	}
	dfs(minn,maxx);
}

int main(){
	file();
	read(n);
	For(i,1,n) read(A[i]),Gra[A[i]]=i;
	read(q);
	while(q--){
		read(x),read(y);
		dfs(x,y);
	}
	return 0;
}

