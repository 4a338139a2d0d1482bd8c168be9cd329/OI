#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
}

typedef long long ll;
const int N=15;
int A[(1<<N)+10],cnt,k,q,a,d,m,son[(1<<N)+10],flag;

inline void update(int x){
	if(!son[x]){
		A[++cnt]=x>>1;
		if(cnt>=(1<<k)-3){
			flag=1;
			return;
		}
		son[x>>1]--;
		update(x>>1);
	}
}

void dfs(int dep){
	if(dep==1) return;
	For(i,1<<(dep-1),(1<<dep)-1){
		update(i);
		if(flag) return;
	}
	dfs(dep-1);
}

int main(){
	file();
	read(k),read(q);
	For(i,1,(1<<(k-1))-1) son[i]=2;	
	dfs(k);
	while(q--){
		read(a),read(d),read(m);
		ll ans=0;
		for(register int i=a;i<=a+(m-1)*d;i+=d)
			ans+=1ll*A[i];
		printf("%lld\n",ans);
	}
	return 0;
}

