#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
}

const int N=1e3+10;
char s[5];
int x,y,d;
int mp[N<<1][N<<1][6];
double ans;


int main(){
	file();
	printf("205.50\n");
	return 0;
}

