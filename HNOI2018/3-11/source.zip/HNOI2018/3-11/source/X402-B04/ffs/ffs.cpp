/*
Author: CNYALI_LK
LANG: C++
PROG: ffs.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
int p[192608],mx[192608][21],mn[192608][21];
int max_min(int l,int r){
	int s=1,t=0;
	while(s<<1<=r-l+1){s<<=1;++t;}
	return max(mx[l][t],mx[r-s+1][t])-min(mn[l][t],mn[r-s+1][t]);
}
int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	int n;
	n=read();
	for(int i=1;i<=n;++i){
		p[i]=read();
		mx[i][0]=mn[i][0]=p[i];
	}
	for(int j=1,k=1;j<n;j<<=1,++k){
		for(int i=1;i+j+j-1<=n;++i){
			mx[i][k]=max(mx[i][k-1],mx[i+j][k-1]);
			mn[i][k]=min(mn[i][k-1],mn[i+j][k-1]);
		}
	}
	int q=read()+1,l,r,s;
	while(--q){
		l=read();r=read();
		s=max_min(l,r)-(r-l);
		int ntf=1;
		while(ntf){
			for(int i=0;i<=s;++i)if(max_min(l-s+i,r+i)==(r-l+s)){
				ntf=0;
				printf("%d %d\n",l-s+i,r+i);
				break;
			}	
			++s;
		}
	}
	return 0;
}

