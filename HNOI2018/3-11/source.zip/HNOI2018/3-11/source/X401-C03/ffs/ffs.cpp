#include<bits/stdc++.h>
using namespace std;

int ST1[100005][25][2];
int ST2[100005][25][2];
int n,k;

void init(){
	int len = 0;
	for(int i = 1;i < n;i <<= 1)len ++;
	for(int j = 1,a = 1;j <= len;j ++,a <<= 1){
		for(int i = 1;i <= n;i ++){
			ST1[i][j][0] = min(ST1[i][j - 1][0],ST1[i + a][j - 1][0]);
			ST1[i][j][1] = max(ST1[i][j - 1][1],ST1[i + a][j - 1][1]);
			ST2[i][j][0] = min(ST2[i][j - 1][0],ST2[i + a][j - 1][0]);
			ST2[i][j][1] = max(ST2[i][j - 1][1],ST2[i + a][j - 1][1]);
		}
	}
}

int get_lim(bool way,bool m_m,int a,int b){
	int len = 0;int i = 1;
	for(;i < (b-a+1);i <<= 1)len ++;len --;
	if(way){
		if(m_m){
			return max(ST2[a][len][m_m],ST2[b-i/2+1][len][m_m]);
		}else{
			return min(ST2[a][len][m_m],ST2[b-i/2+1][len][m_m]);
		}
	}else{
		if(m_m){
			return max(ST1[a][len][m_m],ST1[b-i/2+1][len][m_m]);
		}else{
			return min(ST1[a][len][m_m],ST1[b-i/2+1][len][m_m]);
		}
	}
}

int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i ++){
		int s;cin >> s;
		ST1[i][0][1] = ST1[i][0][0] = s;
		ST2[s][0][1] = ST2[s][0][0] = i;
	}
	init();
	int k;cin >> k;
	for(int i = 1;i <= k;i ++){
		int a,b;scanf("%d%d",&a,&b);
		int x = 0,y = 0;
		x = get_lim(false,false,a,b);
		y = get_lim(false,true,a,b);
		while((y - x) != (b - a)){
			x = get_lim(false,false,a,b);
			y = get_lim(false,true,a,b);
			a = get_lim(true,false,x,y);
			b = get_lim(true,true,x,y);
		}
		printf("%d %d\n",a,b); 
	}
}
/*
10
2 1 4 3 5 6 7 10 8 9
5
2 3
3 7
4 7
4 8
7 8
*/
