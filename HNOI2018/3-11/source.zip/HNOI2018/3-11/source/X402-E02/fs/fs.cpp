#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int n,an[1<<15|1],cnt,s[1<<15|1];
void dfs(int x,int y){
	if (y<n) dfs(x<<1,y+1),dfs(x<<1|1,y+1);
	if (y>1) an[++cnt]=(x>>1);
}
int main(){
	freopen("fs.in","r",stdin); freopen("fs.out","w",stdout);
	n=read(); int _=read(),x,y,z;
	dfs(1,1); --cnt; For(i,1,cnt) s[i]=s[i-1]+an[i];
	while(_--) x=read(),y=read(),z=read(),printf("%d\n",s[x+(z-1)*y]-s[x-1]);
	return 0;
}
