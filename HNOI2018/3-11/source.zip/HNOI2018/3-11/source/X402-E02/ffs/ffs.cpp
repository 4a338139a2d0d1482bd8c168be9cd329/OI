#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int a[1005],an[1005][1005],ll[1005];
int main(){
	freopen("ffs.in","r",stdin); freopen("ffs.out","w",stdout);
	int n=read(),l,r,x,y,z,k;
	if (n<=1000){
		For(i,1,n) a[i]=read();
		For(i,1,n){
			an[i][++ll[i]]=i; l=r=a[i];
			For(j,i+1,n){
				if (a[j]<l) l=a[j];
				else if (a[j]>r) r=a[j];
				if (r-l==j-i) an[i][++ll[i]]=j;
			}
		}
		int _=read();
		while(_--){
			x=read(),y=read(),z=n-1,l=1,r=n;
			for(int i=x;i>=1;i--){
				if (y-i>=z) break;
				k=lower_bound(an[i]+1,an[i]+1+ll[i],y)-an[i]; k=an[i][k];
				if (k&&k-i<r-l) z=k-i,r=k,l=i;
			}
			printf("%d %d\n",l,r);
		}
	}
	return 0;
}
