/**********************************************************
	File:ffs.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-3-11 10:39:15
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 100010
int n,p[N],r[N],q;
struct tree
{
	tree *l,*r;
	int s;
	tree()
	{
		l=r=NULL;
		s=0;
	}
}*rp[N],*rr[N];
tree *build(int l,int r)
{
	if(l==r)return new tree;
	tree *k=new tree;
	int mid=(l+r)>>1;
	k->l=build(l,mid);
	k->r=build(mid+1,r);
	return k;
}
namespace debug
{
	void print(tree *k,int l,int r)
	{
		printf("%d %d %d\n",l,r,k->s);
		if(l==r)return;
		int mid=(l+r)>>1;
		print(k->l,l,mid);
		print(k->r,mid+1,r);
	}
}
tree *add(tree *k,int l,int r,int pos)
{
	tree *o=new tree;
	o->s=k->s+1;
	if(l==r)
		return o;
	int mid=(l+r)>>1;
	if(mid>=pos)
	{
		o->l=add(k->l,l,mid,pos);
		o->r=k->r;
	}
	else
	{
		o->l=k->l;
		o->r=add(k->r,mid+1,r,pos);
	}
	return o;
}
int fmax(tree *a,tree *b,int l,int r)
{
	if(l==r)return l;
	int mid=(l+r)>>1;
	if(b->r->s-a->r->s)
		return fmax(a->r,b->r,mid+1,r);
	else
		return fmax(a->l,b->l,l,mid);
}
int fmin(tree *a,tree *b,int l,int r)
{
	if(l==r)return l;
	int mid=(l+r)>>1;
	if(b->l->s-a->l->s)
		return fmin(a->l,b->l,l,mid);
	else
		return fmin(a->r,b->r,mid+1,r);
}
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	n=read();
	rp[0]=build(1,n);
	rr[0]=build(1,n);
	fr(i,1,n)
		r[p[i]=read()]=i;
	fr(i,1,n)rp[i]=add(rp[i-1],1,n,p[i]);
	fr(i,1,n)rr[i]=add(rr[i-1],1,n,r[i]);
	q=read();
	while(q--)
	{
		int l=read(),r=read();
		for(;;)
		{
			int l_=fmin(rp[l-1],rp[r],1,n);
			int r_=fmax(rp[l-1],rp[r],1,n);
			if(r_-l_==r-l)
			{
				printf("%d %d\n",l,r);
				break;
			}
			l=fmin(rr[l_-1],rr[r_],1,n);
			r=fmax(rp[l_-1],rr[r_],1,n);
		}
	}
	return 0;
}