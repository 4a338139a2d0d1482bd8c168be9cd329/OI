/**********************************************************
	File:skss.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-3-11 11:08:46
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 4020
#define M 2001
int t,s[N][N],l=1,r=4001,ans;
int main()
{
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
	t=read();
	fr(i,1,t)
	{
		int x=read(),y=read(),a=read()/2;
		s[x-a+M][y-a+M]++;
		s[x-a+M][y+a+M]--;
		s[x+a+M][y-a+M]--;
		s[x+a+M][y+a+M]++;
	}
//	fr(i,l,r)
//		fr(j,l,r)if(s[i][j])printf("%d %d %d\n",i-M,j-M,s[i][j]);
//	putchar(10);
//	fr(i,0,6)
//		fr(j,0,6)
//			printf("%d%c",s[i+M][j+M],j==6?'\n':' ');
	fr(i,l,r)
		fr(j,l,r)
		{
			s[i][j]+=s[i-1][j]+s[i][j-1]-s[i-1][j-1];
			if(s[i][j])
			{
				ans++;
//				printf("%d %d %d\n",i-M,j-M,s[i][j]);
			}
		}
	printf("%d\n",ans);
	return 0;
}