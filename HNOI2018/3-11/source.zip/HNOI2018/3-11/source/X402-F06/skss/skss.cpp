#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=3e3+10,maxk=1500;
int sum[maxn][maxn];
char ty[10];
int main(){
#ifndef ONLINE_JUDGE
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
#endif
	int n=read();
	REP(i,1,n){
		scanf("%s",ty+1);
		int x=read(),y=read(),d=read();
		int l1=x-d/2,l2=y-d/2,r1=x+d/2,r2=y+d/2;
		l1+=maxk,l2+=maxk,r1+=maxk,r2+=maxk;
		sum[l1][l2]++;sum[l1][r2]--,sum[r1][l2]--,sum[r1][r2]++;
	}
	double cnt=0;
	REP(i,1,maxn-10)
		REP(j,1,maxn-10){
			sum[i][j]+=sum[i][j-1]+sum[i-1][j]-sum[i-1][j-1];
			cnt+=(sum[i][j]>0);
		}
	printf("%.2lf\n",cnt);
	return 0;
}
