#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10,maxk=19;
int a[maxn],b[maxn];
int Min1[maxn][maxk],Min2[maxn][maxk],Max1[maxn][maxk],Max2[maxn][maxk];
int Log[maxn];
inline int query_min1(int L,int R){
	int u=Log[R-L+1];
	return min(Min1[L][u],Min1[R-(1<<u)+1][u]);
}
inline int query_max1(int L,int R){
	int u=Log[R-L+1];
	return max(Max1[L][u],Max1[R-(1<<u)+1][u]);
}
inline int query_min2(int L,int R){
	int u=Log[R-L+1];
	return min(Min2[L][u],Min2[R-(1<<u)+1][u]);
}
inline int query_max2(int L,int R){
	int u=Log[R-L+1];
	return max(Max2[L][u],Max2[R-(1<<u)+1][u]);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
#endif
//	double t1,t2,t3;
//	t1=clock()*1.0/CLOCKS_PER_SEC;
	int n=read();
	REP(i,1,n){
		a[i]=read();
		b[a[i]]=i;
	}
	REP(i,1,n){
		Min1[i][0]=Max1[i][0]=a[i];
		Min2[i][0]=Max2[i][0]=b[i];
	}
	REP(i,2,n) Log[i]=Log[i>>1]+1;
	for(int j=1;(1<<j)<=n;++j)
		REP(i,1,n-(1<<j)+1){
			int u=(1<<j-1);
			Min1[i][j]=min(Min1[i][j-1],Min1[i+u][j-1]);
			Min2[i][j]=min(Min2[i][j-1],Min2[i+u][j-1]);
			Max1[i][j]=max(Max1[i][j-1],Max1[i+u][j-1]);
			Max2[i][j]=max(Max2[i][j-1],Max2[i+u][j-1]);
		}
//	t2=clock()*1.0/CLOCKS_PER_SEC;
//	cerr<<t2-t1<<endl;
	int q=read();
	while(q--){
		int l=read(),r=read();
		while(1){
			int x=query_min1(l,r),y=query_max1(l,r);
			int L=query_min2(x,y),R=query_max2(x,y);
			if(l<=L && R<=r) break;
			l=L,r=R;
		}
		printf("%d %d\n",l,r);
	}
//	t3=clock()*1.0/CLOCKS_PER_SEC;
//	cerr<<t3-t1<<endl;
	return 0;
}
