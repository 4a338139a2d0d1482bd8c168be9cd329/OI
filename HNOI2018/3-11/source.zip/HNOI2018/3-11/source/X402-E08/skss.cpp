#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

inline char read_char() { char ch = getchar(); for (; !isupper(ch); ch = getchar()); return ch; }

void File() {
	freopen ("skss.in", "r", stdin);
	freopen ("skss.out", "w", stdout);
}

typedef pair<float, float> PDD;
#define mp make_pair
#define fir first
#define sec second

const int N = 2e5 + 1e3;
struct square {
	int type;
	float x, y, a;

	inline bool Get_Line (float x0, PDD &res) {
		if (x0 < x - a || x0 > x + a) return false;
	//	cout << x << ' ' << y << ' ' << a << ' ' << x0 << endl;
		if (type == 0) { res = mp(y - a, y + a); }
		if (type == 1) { res = mp(y - a + fabs(x - x0), y + a - fabs(x - x0)); }
		return true;
	}
} lt[N];

int n;

PDD V[N];
inline float f(float x) {
	PDD now; int cnt = 0; For (i, 1, n) if (lt[i].Get_Line(x, now)) V[++cnt] = now;
	sort (V + 1, V + 1 + cnt); 
	//For (i, 1, cnt) printf ("%.2f %.2f\n", V[i].fir, V[i].sec);

	V[++cnt] = mp(1e6, 1e6);
	float res = 0, L = 0, R = 0;
	For (i, 1, cnt)	{
		if (i == 1) { L = V[i].fir; R = V[i].sec; continue; }
		if (V[i].fir > R) { res += R - L; L = V[i].fir; R = V[i].sec; }
		else { R = max(R, V[i].sec); }
	}
	return res;
}

inline float Simpson(float l, float r) { 
	return (f(l) + 4.0 * f((l + r) / 2.0) + f(r)) * (r - l) / 6.0; 
}

const float eps = 1e-4;
inline float asr(float l, float r, float Last) {
	float mid = (l + r) / 2.0, res1 = Last, res2 = Simpson(l, mid), res3 = Simpson(mid, r);
	if (fabs(res1 - (res2 + res3)) <= eps) return res2 + res3;
	return asr(l, mid, res2) + asr(mid, r, res3);
}

void Solve1() {
	float L = 1e8, R = -1e8;
	For (i, 1, n) {
		int type = read_char() - 'A', x = read(), y = read(), a = read();
		a >>= 1;
		L = min(L, (float)x - a); R = max(R, (float)x + a);
		lt[i] = (square) {type, (float)x, (float)y, (float)a};
	}
	float ans = 0;
	for (float i = L; i <= R; i += 1) ans += asr(i, i + 1, Simpson(i, i + 1));
	printf ("%.2lf\n", ans);
	//cerr << (float) clock() / CLOCKS_PER_SEC << endl;
}


const int N_ = 2100;
const int maxn = N_ << 2;

int Lim;
int rres_[N_][N_];

struct Segment_Tree {
	int tag[maxn][maxn];
	int xl, xr, yl, yr;

	void Updatey(int ox, int oy, int l, int r) {
		if (yl <= l && r <= yr) { tag[ox][oy] = true; return ; }
		int mid = (l + r) >> 1;
		if (yl <= mid) Updatey(ox, oy << 1, l, mid);
		if (yr > mid) Updatey(ox, oy << 1 | 1, mid + 1, r);
	}
	
	int cnt = 0;
	void Updatex(int ox, int l, int r) {
		if (xl <= l && r <= xr) { Updatey(ox, 1, 1, Lim); return ; }
		int mid = (l + r) >> 1;
		if (xl <= mid) Updatex(ox << 1, l, mid);
		if (xr > mid) Updatex(ox << 1 | 1, mid + 1, r);
	}

	void Calcy(int ox, int oy, int l, int r, int x) {
		if (tag[ox][oy]) { 
			For (i, l, r) rres_[x][i] = 1; return ; }
		if (l == r) return ;
		int mid = (l + r) >> 1;
		Calcy(ox, oy << 1, l, mid, x);
		Calcy(ox, oy << 1 | 1, mid + 1, r, x);
	} 

	void Push_Down(int ox, int oy, int l, int r) {
		tag[ox << 1][oy] |= tag[ox][oy];
		tag[ox << 1 | 1][oy] |= tag[ox][oy];
		if (l == r) return ;
		int mid = (l + r) >> 1;
		Push_Down(ox, oy << 1, l, mid);
		Push_Down(ox, oy << 1 | 1, mid + 1, r);
	}

	void Calcx(int ox, int l, int r) {
		if (l == r) { Calcy(ox, 1, 1, Lim, l); return ; }
		Push_Down(ox, 1, 1, Lim);
		int mid = (l + r) >> 1;
		Calcx(ox << 1, l, mid);
		Calcx(ox << 1 | 1, mid + 1, r);
	}
} T;



void Solve2() {
	Lim = 2048;
	For (i, 1, n) {
		char type = read_char();
		int x = read() + 1010, y = read() + 1010, a = read() / 2;
		T.xl = x - a + 1; T.xr = x + a;
		T.yl = y - a + 1; T.yr = y + a;
		T.Updatex(1, 1, Lim);
	}
	T.Calcx(1, 1, Lim);
	int ans = 0;
	For (i, 1, Lim) For (j, 1, Lim) ans += rres_[i][j];
	printf ("%d.00\n", ans);
}


int main () {
	File();
	n = read();
	if (n <= 1000) Solve1(); else Solve2();
    return 0;
}
