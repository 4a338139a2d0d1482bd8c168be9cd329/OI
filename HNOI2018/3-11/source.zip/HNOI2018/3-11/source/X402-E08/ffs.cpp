#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("ffs.in", "r", stdin);
	freopen ("ffs.out", "w", stdout);
}

const int N = 1e5 + 1e3;
typedef pair<int, int> PII;
#define mp make_pair
#define fir first
#define sec second
vector<PII> q[N];

const int inf = 0x7f7f7f7f;
int res[N];
PII ans[N];
int pos[N];
int n, p[N], m;

int main () {
	File();
	n = read();
	For (i, 1, n) p[i] = read(), pos[i] = i;
	m = read();
	For (i, 1, m) { int x = read(), y = read(); q[x].push_back(mp(y, i)); }
	
	Set(res, inf);
	For (i, 1, n) {
		int minv = n + 1, maxv = 0;
		For (j, i, n) {
			chkmin(minv, p[j]); chkmax(maxv, p[j]);
			if (maxv - minv == j - i) if (chkmin(res[j], j - i + 1)) pos[j] = j;
		}
		Fordown (j, n, i)
			if (chkmin(res[j], res[j + 1])) pos[j] = pos[j + 1];
		For (j, 0, q[i].size() - 1) {
			ans[q[i][j].sec].sec = pos[q[i][j].fir];
			ans[q[i][j].sec].fir = pos[q[i][j].fir] - res[q[i][j].fir] + 1;
		}
	}
	For (i, 1, m)
		printf ("%d %d\n", ans[i].fir, ans[i].sec);
    return 0;
}
