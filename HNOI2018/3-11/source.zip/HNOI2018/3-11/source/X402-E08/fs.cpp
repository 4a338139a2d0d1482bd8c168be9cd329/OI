#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("fs.in", "r", stdin);
	freopen ("fs.out", "w", stdout);
}

priority_queue<int, vector<int>, greater<int> > Pr;
const int N = 1 << 15;
int P[N], tot[N], k, q, cnt, fa[N];
void Build(int o, int dep) { 
	fa[o] = o >> 1; tot[o] = 2;
	if (dep == k) {Pr.push(o); return ;}  
	Build(o << 1, dep + 1); 
	Build(o << 1 | 1, dep + 1); 
}

void Init() {
	Build (1, 1);
	while (!Pr.empty()) {
		int u = Pr.top(); Pr.pop();
		if (!(--tot[fa[u]])) Pr.push(fa[u]);
		P[++cnt] = fa[u];
		if (cnt == (1 << k) - 3) break ;
	}
	//For (i, 1, cnt) printf ("%d ", P[i]);
}

int main () {
	File();
	k = read(); q = read();
	Init();
	For (i, 1, q) {
		int a = read(), d = read(), m = read();
		long long ans = 0;
		For (i, 0, m - 1) ans += P[a + d * i];
		printf ("%lld\n", ans);
	}
    return 0;
}
