#include<bits/stdc++.h>
const int maxn=132768;
using namespace std;

template<typename T>inline void read(T &x)
{
	x=0;T c=getchar(),p=1;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}

bool flag=0;
int k,q,cnt;
bool vis[maxn];
int ans[maxn];
int siz[maxn],son[maxn][2],fa[maxn];

void File()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);	
}

int main(){
//	freopen("in.txt","r",stdin);
	File();
	read(k);read(q);
	int n=pow(2,k)-1,m=pow(2,k-1);
	siz[1]=2;son[1][0]=2;son[1][1]=3;fa[1]=3;
	fa[2]=fa[3]=1;
	for(int i=2;i<=n-m;i++)
	{
		siz[i]=2;
		son[i][0]=2*i;son[i][1]=2*i+1;
		fa[son[i][0]]=i;fa[son[i][1]]=i;
	}
	int now=m;
	while(1)
	{
		ans[++cnt]=fa[now];vis[now]=1;siz[fa[now]]--;
		if(cnt==n-2)break;
		if(!siz[fa[now]])now=fa[now];
		else
			for(int i=1;i<=n;i++)
				if(!siz[i] && !vis[i]){now=i;break;}
	}
	for(int i=1;i<=q;i++)
	{
		int ANS=0,a,d,m;
		read(a);read(d);read(m);
		for(int j=a;j<=a+(m-1)*d;j+=d)
			ANS+=ans[j];
		printf("%d\n",ANS);
	}
//	for(int i=1;i<=cnt;i++)cout<<ans[i]<<endl;
	return 0;
}

