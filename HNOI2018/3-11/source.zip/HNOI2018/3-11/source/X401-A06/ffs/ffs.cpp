#include<bits/stdc++.h>
#define MAX _MAX
#define MIN _MIN
const int maxn=1e5+1e2;
using namespace std;

template<typename T>inline bool chkmin(T &a,T b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,T b){return a<b?a=b,1:0;}

template<typename T>inline void read(T &x)
{
	x=0;T c=getchar(),p=1;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}

int n;
int a[maxn],Max[maxn*4],Min[maxn*4];

void Build(int rt,int l,int r)
{
	if(l==r){Min[rt]=Max[rt]=a[l];return;}
	int Mid=(l+r)>>1;
	Build(rt<<1,l,Mid);
	Build(rt<<1|1,Mid+1,r);
	Max[rt]=max(Max[rt<<1],Max[rt<<1|1]);
	Min[rt]=min(Min[rt<<1],Min[rt<<1|1]);
}

int query_Max(int rt,int l,int r,int L,int R)
{
	if(L<=l && r<=R)
		return Max[rt];
	int Mid=(l+r)>>1;
	int tp=0;
	if(L<=Mid)tp=query_Max(rt<<1,l,Mid,L,R);
	if(R>Mid)tp=max(tp,query_Max(rt<<1|1,Mid+1,r,L,R));
	return tp;
}

int query_Min(int rt,int l,int r,int L,int R)
{
	if(L<=l && r<=R)
		return Min[rt];
	int Mid=(l+r)>>1;
	int tp=2147483647;
	if(L<=Mid)tp=query_Min(rt<<1,l,Mid,L,R);
	if(R>Mid)tp=min(tp,query_Min(rt<<1|1,Mid+1,r,L,R));
	return tp;
}

int q;

void File()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);	
}

int main(){
//	freopen("in.txt","r",stdin);
	File();
	read(n);
	for(int i=1;i<=n;i++)read(a[i]);
	Build(1,1,n);
//	cout<<"------"<<endl;
//	cout<<query_Max(1,1,n,2,3)<<endl;
	read(q);int qq=q;
	int MIN,MAX;
	while(q--)
	{
		int x,y;
		read(x);read(y);
		MAX=query_Max(1,1,n,x,y);
		MIN=query_Min(1,1,n,x,y);
//		cout<<"L:"<<x<<" R:"<<y<<" MAX:"<<Max<<" MIN:"<<Min<<" "<<query_Max(1,1,n,x,y)<<endl;
		int left=x-1;int right=y+1;int need=MAX-MIN+1-(y-x+1);
//		cout<<"before:"<<left<<" "<<right<<" "<<need<<" "<<MAX<<" "<<MIN<<endl;
		while(1)
		{
			if(need<=0)break;
			while(a[left]<MAX && a[left]>MIN)--need,left--;
			while(a[right]<MAX && a[right]>MIN)--need,right++;
//			if(q==0)cout<<left<<" "<<right<<" "<<need<<endl;
			if(need<=0)break;
			if((min(abs(MIN-a[left]),abs(a[left]-MAX))<=min(abs(MIN-a[right]),abs(a[right]-MAX)) && left!=0 && right!=n+1) || (right==n+1))
			{
				chkmin(MIN,a[left]);
				chkmax(MAX,a[left]);
				need=MAX-MIN+1-(right-left);
				left--;
			}
			if((min(abs(MIN-a[left]),abs(a[left]-MAX))>min(abs(MIN-a[right]),abs(a[right]-MAX)) && right!=n+1 && left!=0) || (left==0))
			{
				chkmin(MIN,a[right]);
				chkmax(MAX,a[right]);
				need=MAX-MIN+1-(right-left+2);
				right++;
			}
			
		}
		//while(a[right-1]==query_Min(1,1,n,left+1,right-1) || a[right-1]==query_Max(1,1,n,left+1,right-1))right--;
		printf("%d %d\n",left+1,right-1);
	}
	return 0;
}

