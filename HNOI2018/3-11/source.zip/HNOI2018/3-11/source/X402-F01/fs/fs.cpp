#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int k,q,n;
int tree[400005];
long long sum[400005][11];
void dfs(int x,int dep){
   if(dep==k){
      tree[++n]=x>>1;
	  return ;
   }
   dfs(x<<1,dep+1);
   dfs(x<<1|1,dep+1);
   if(n!=(1<<k)-3)tree[++n]=x>>1;
}
long long query(int l,int m,int val){
         if(m==1)return tree[l];
         long long res=0;
		 int r=(m/2)*val+l;
		 res+=query(l,m/2,val);
		 res+=query(r,m-m/2,val);
		 return res;
}
int main () {
freopen("fs.in","r",stdin);
freopen("fs.out","w",stdout);
     k=read();
	 dfs(1,1);
	 q=read();
	 F(i,1,(1<<k)-3){
	    F(j,1,10){
		   sum[i][j]=tree[i];
		   if(i-j>0)sum[i][j]+=sum[i-j][j];
		}
	 }
	 while(q--){
	     int l=read(),d=read(),m=read();
		 if(d<=10)printf("%lld\n",sum[l+(m-1)*d][d]-sum[l][d]+tree[l]);
		 else  printf("%lld\n",query(l,m,d));
	 }
	 return 0;
}
