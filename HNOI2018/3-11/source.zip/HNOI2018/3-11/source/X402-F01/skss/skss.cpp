#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n;
const int N=200005;
struct Seg {
    double l,r,h;
	int d;
    Seg() {}
    Seg(double l, double r, double h, int d):l(l),r(r),h(h),d(d) {}
    bool operator< (const Seg& rhs) const {return h < rhs.h;}
}a[N];
int cnt[N<<2];
double sum[N<<2],all[N];
struct node{
   char st;
   int x,y,sz;
}sq[N];
#define lson l, m, rt << 1
#define rson m + 1, r, rt << 1 | 1
void push_up(int l,int r,int rt) {
    if(cnt[rt])sum[rt]=all[r+1]-all[l];
    else if(l==r)sum[rt]=0;
    else sum[rt]=sum[rt<<1]+sum[rt<<1|1];
}
void update(int L,int R,int v,int l,int r,int rt){
    if(L<=l&&r<=R){
        cnt[rt]+=v;
        push_up(l,r,rt);
        return;
    }
    int m=(l+r)>>1;
    if(L<=m) update(L,R,v,lson);
    if(R>m) update(L,R,v,rson);
    push_up(l,r,rt);
}
void bf2(){
        F(i,1,n){
			double x1=sq[i].x-sq[i].sz/2,x2=sq[i].x+sq[i].sz/2,y1=sq[i].y-sq[i].sz/2,y2=sq[i].y+sq[i].sz/2;
            a[i]=Seg(x1, x2, y1, 1);
            a[i+n]=Seg(x1, x2, y2, -1);
            all[i]=x1; 
			all[i+n]=x2;
        }
        n<<=1;
        sort(a+1,a+1+n);
        sort(all+1,all+1+n);
        int m=unique(all+1,all+1+n)-all-1;
        double ans=0;
        F(i,1,n-1) {
            int l=lower_bound(all+1,all+1+m,a[i].l)-all;
            int r=lower_bound(all+1,all+1+m,a[i].r)-all;
            if(l<r)update(l,r-1,a[i].d,1,m,1);
            ans+=sum[1]*(a[i+1].h-a[i].h);
        }
		printf("%.2lf\n",ans);
}
int main () {
freopen("skss.in","r",stdin);
freopen("skss.out","w",stdout);
     scanf("%d",&n);
	 bool flag=1;
	 F(i,1,n){
	    cin>>sq[i].st;
		if(sq[i].st=='B')flag=0;
        scanf("%d%d%d",&sq[i].x,&sq[i].y,&sq[i].sz);
		sq[i].x+=2000;
		sq[i].y+=2000;
	 }
	 if(flag==1)bf2();
    return 0;
}
