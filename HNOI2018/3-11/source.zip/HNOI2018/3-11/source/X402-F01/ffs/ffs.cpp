#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
const int maxn=1e5+10;
const int inf=0x7fffffff;
int n,m,a[maxn],Max[maxn][20],Min[maxn][20];
int Log[maxn];
int getmax(int x,int y){
	int ret=0;
	while(x<=y){
		ret=max(ret,Max[x][Log[y-x+1]]);
		if(x==y)break;
		x=x+(2<<(Log[y-x+1]-1));
	}
	return ret;
}
int getmin(int x,int y){
	int ret=inf;	
	while(x<=y){
		ret=min(ret,Min[x][Log[y-x+1]]);
		if(x==y)break;
		x=x+(2<<(Log[y-x+1]-1));
	}
	return ret;
}
vector<int>G[maxn];
int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	n=read();
	F(i,1,n)a[i]=read();
	F(i,1,n)Max[i][0]=Min[i][0]=a[i];
	F(i,1,n)Log[i]=floor((log(i)/log(2)));
	F(i,1,Log[n])
		F(j,1,n){
		int len=(2<<(i-1));
		if(j+len-1>n)break;
		Max[j][i]=max(Max[j][i-1],Max[j+(len/2)][i-1]);
		Min[j][i]=min(Min[j][i-1],Min[j+(len/2)][i-1]);
	}
	F(i,1,n)
		F(j,i,n)if(getmax(i,j)-getmin(i,j)==j-i)
		G[i].push_back((int)j);
	m=read();
	vector<int>::iterator it;
	F(i,1,m){
		int x=read(),y=read(),aa,bb,ans=inf;
		F(j,1,x){
			it=lower_bound(G[j].begin(),G[j].end(),y);
			if(it==G[j].end())continue;
			if(*it-j<ans){
				ans=*it-j;
				aa=j;
				bb=*it;
			}
		}
		printf("%d %d\n",aa,bb);
	}
	return 0;
}
