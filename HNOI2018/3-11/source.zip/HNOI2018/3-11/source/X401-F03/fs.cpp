#include<bits/stdc++.h>
using namespace std;
int  read(){
	int x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
void write(int  x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
const int maxn=1<<15;
int n,q_cnt;
int s[maxn],tot;
void DFS(int p,int dep){
	if(dep>=n)return;
	int u=p<<1,v=u+1;
	DFS(u,dep+1),s[++tot]=p;
	DFS(v,dep+1),s[++tot]=p;
}
int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	n=read();
	q_cnt=read();
	DFS(1,1);
	for(int i=1;i<=q_cnt;i++)
	{
		long long ans=0;
		int a=read(),d=read(),m=read();
		for(int j=0;j<=m-1;i++)ans+=s[a+d*j];
		write(ans,'\n');
	}
	return 0;
}
