#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=1000+10;
const int M=10000+7;
int a[maxn];
bool p[M][M];
int sum[maxn];
long long c[maxn][maxn];
int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
		sum[i]=(sum[i-1]+a[i])%M;
	}
	for(int i=1;i<=n;++i){
		long long tmp=i;
		int ss=i;
		c[i][i]=a[i];
		for(int j=i+1;j<=n;++j){
			ss=(ss+j)%M;
			tmp=tmp*(long long)j%M;
			p[ss][tmp]=1;
			c[i][j]=(c[i][j-1]*(long long)a[j])%M;
		}
	}

	int cas;
	cin>>cas;
	int x,y;
	while(cas--){
		scanf("%d%d",&x,&y);
		if(x==y){printf("%d %d\n",x,y);continue;}
		int len=y-x;
		bool flag=0;
		for(int i=len;i<n;++i){
			int s=y-i;
			if(s<1) s=1;
			for(int j=s;j<=x;++j){
				int t=j+i;
				if(t>=y){
					if(p[sum[t]-sum[j-1]][c[j][t]]){
						flag=1;
						printf("%d %d\n",j,t);
						break;
					}
				}
			}
			if(flag) break;
		}
	}
	return 0;
}
