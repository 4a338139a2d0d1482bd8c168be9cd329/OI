#include<bits/stdc++.h>
using namespace std;
#define N 33000
int len,Dep[16];
int Pru[N],PP,k,q;
int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	scanf("%d%d",&k,&q);
	len=pow(2,k);
	int now=k;
	int St=len/2;
	while(Dep[k]<len/4)
	{
		Pru[++PP]=(St+Dep[k])/2;
		Dep[k]++;
		if(!(Dep[k]%2))
		{
			int kk=2,now=St+Dep[k]-1;
			while(kk<=Dep[k])
			{
				Pru[++PP]=now/(2*kk);
				kk*=2;
			}
		}
	}
	Pru[++PP]=3;
	St=len/2;
	while(Dep[k]<len/2)
	{
		Pru[++PP]=(St+Dep[k])/2;
		Dep[k]++;
		if(!(Dep[k]%2)) 
		{
			int kk=2,now=St+Dep[k]-1;
			while(kk<=Dep[k]-len/4)
			{
				Pru[++PP]=now/(2*kk);
				kk*=2;
			}
		}
	}
	PP-=2;
	for(int cas=1;cas<=q;++cas)
	{
		int a,m,d,sum=0;
		scanf("%d%d%d",&a,&m,&d);
		for(int i=0;i<m;++i) 
			sum+=Pru[a+i*d];
		printf("%d\n",sum);
	}
	return 0;
}
