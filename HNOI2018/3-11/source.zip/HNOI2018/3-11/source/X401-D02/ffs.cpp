#include<bits/stdc++.h>
using namespace std;
#define N 1010
int n,a[N],q,pu;
int tmax[N<<2],tmin[N<<2];
vector<int>Ans[N];
void build(int rt,int l,int r)
{
	if(l==r) 
	{
		tmax[rt]=a[l],tmin[rt]=a[l];
		return ;
	}
	int mid=(l+r)>>1;
	build(rt<<1,l,mid);
	build(rt<<1|1,mid+1,r);
	tmax[rt]=max(tmax[rt<<1],tmax[rt<<1|1]);
	tmin[rt]=min(tmin[rt<<1],tmin[rt<<1|1]);
}
int Maxk,Mink=N;
void query(int rt,int l,int r,int x,int y)
{
	if(x<=l && r<=y)
	{
		Maxk=max(Maxk,tmax[rt]);
		Mink=min(Mink,tmin[rt]);
		return ;
	}
	int mid=(l+r)>>1;
	if(x<=mid) query(rt<<1,l,mid,x,y);
	if(y>mid) query(rt<<1|1,mid+1,r,x,y);
}
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	build(1,1,n);
	for(int i=1;i<=n;++i)
		for(int j=i;j<=n;++j) 
		{
			Maxk=0,Mink=N;
			query(1,1,n,i,j);
			if(Maxk-Mink+1==j-i+1) Ans[i].push_back(j);
		}
	for(int i=1;i<=n;++i)
		sort(Ans[i].begin(),Ans[i].end());
	scanf("%d",&q);
	for(int cas=1;cas<=q;++cas)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		int l,r;
		for(int i=x;i>=1;--i) 
		{
			l=0,r=Ans[i].size();
			while(l<r)
			{
				int mid=(l+r)>>1;
				if(Ans[i][mid]>=y) r=mid;
				else if(Ans[i][mid]<y) l=mid+1;
			}
			if(Ans[i][l]>=y) {r=Ans[i][l],l=i;break;}
		}
		printf("%d %d\n",l,r);
	}
	return 0;
}
