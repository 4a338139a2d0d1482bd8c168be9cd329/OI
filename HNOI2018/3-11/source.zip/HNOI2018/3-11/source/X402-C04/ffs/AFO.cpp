#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=100009;
const int K=100;

int n,q,p[N],lg2[N];
int stn[N][K],stx[N][K];

inline void chkmin(int &a,int b){if(a>b)a=b;}
inline void chkmax(int &a,int b){if(a<b)a=b;}

namespace bf
{
	inline int qmax()

	int mina()
	{
		for(int i=2;i<=n;i++)
			lg2[i]=lg2[i>>1]+1;
		for(int i=1;i<=n;i++)
			stn[i][0]=stx[i][0]=i;
		for(int i=1;i<=lg2[n];i++)
			for(int j=1;j+(1<<i)-1<=n;j++)
			{
				if(p[stn[j][i-1]]<p[stn[j+(1<<i-1)][i-1]])
					stn[j][i]=stn[j][i-1];
				else stn[j][i]=stn[j+(1<<i-1)][i-1];
				
				if(p[stx[j][i-1]]>p[stx[j+(1<<i-1)][i-1]])
					stx[j][i]=stx[j][i-1];
				else stx[j][i]=stx[j+(1<<i-1)][i-1];
			}
		

	}
}

int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);

	n=read();
	for(int i=1;i<=n;i++)
		p[i]=read();
	q=read();

	return bf::mina();
	return 0;
}
