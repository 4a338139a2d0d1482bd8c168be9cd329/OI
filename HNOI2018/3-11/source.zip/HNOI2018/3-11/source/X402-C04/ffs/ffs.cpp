#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=100009;

int n,q,p[N];

inline void chkmin(int &a,int b){if(a>b)a=b;}
inline void chkmax(int &a,int b){if(a<b)a=b;}

namespace bf
{
	vector<int> vec[N];
	int mina()
	{
		for(int i=1;i<=n;i++)
		{
			int mn=1e9,mx=-1;
			for(int j=i;j<=n;j++)
			{
				chkmin(mn,p[j]);
				chkmax(mx,p[j]);
				if(mx-mn+1==j-i+1)
					vec[i].push_back(j);
			}
		}

	
		for(int i=1,x,y;i<=q;i++)
		{
			x=read();y=read();
			int ans=1e9,al=-1,ar=-1;
			for(int j=x;j;j--)
			{
				int pos=lower_bound(vec[j].begin(),vec[j].end(),y)-vec[j].begin();
				if(pos>=vec[j].size())continue;
				if(vec[j][pos]-j<ans)ans=vec[j][pos]-j,al=j,ar=vec[j][pos];
			}
			printf("%d %d\n",al,ar);
		}

		return 0;
	}
}

int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);

	n=read();
	for(int i=1;i<=n;i++)
		p[i]=read();
	q=read();

	return bf::mina();
	return 0;
}
