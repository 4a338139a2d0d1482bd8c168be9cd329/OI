#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

const int N=200009;
const int M=2015;

int n,flag;
struct sqr
{
	int ty,x,y,d;
}a[N];

namespace bf
{
	const int T=4039;
	int g[T][T];//main
	int f[T][T];//sub1
	int t[T][T];//subupleft
	int b[T][T];//subupright
	int o[T][T];//subdownleft
	int e[T][T];//subdownright

	inline void markA(sqr r)
	{
		int x=r.x,y=r.y,d=r.d/2;
		int lx=x-d,ly=y-d,rx=x+d,ry=y+d;
		g[rx+M][ry+M]++;g[lx+M][ry+M]--;
		g[rx+M][ly+M]--;g[lx+M][ly+M]++;
	}

	inline void coverc(int x,int y,int d,int f[][T])
	{
		d=(d-2)/2;
		if(d<=-1)return;
		f[x-d+M][y+M]++;
		f[x+1+M][y-d-1+M]--;
		f[x+1+M][y+d+1+M]--;
		f[x+d+2+M][y+M]++;
		y--;
		f[x-d+M][y+M]++;
		f[x+1+M][y-d-1+M]--;
		f[x+1+M][y+d+1+M]--;
		f[x+d+2+M][y+M]++;
		x--;
		f[x-d+M][y+M]++;
		f[x+1+M][y-d-1+M]--;
		f[x+1+M][y+d+1+M]--;
		f[x+d+2+M][y+M]++;
		y++;
		f[x-d+M][y+M]++;
		f[x+1+M][y-d-1+M]--;
		f[x+1+M][y+d+1+M]--;
		f[x+d+2+M][y+M]++;

	}

	inline void coverf(int x,int y,int d,int pp[][T])
	{
		d=(d-1)/2;
		pp[x-d+M][y+M]++;
		pp[x+1+M][y-d-1+M]--;
		pp[x+1+M][y+d+1+M]--;
		pp[x+d+2+M][y+M]++;
	}

	inline void markB(sqr r)
	{
		int x=r.x,y=r.y,d=r.d;
		coverf(x,y,d,e);
		coverf(x,y-1,d,o);
		coverf(x-1,y,d,b);
		coverf(x-1,y-1,d,t);
		coverc(x,y,d-2,f);
	}

	int mina30()
	{
		for(int i=1;i<=n;i++)
		{
			int x=a[i].x,y=a[i].y,d=a[i].d/2;
			int lx=x-d,ly=y-d,rx=x+d,ry=y+d;
			g[rx+M][ry+M]++;g[lx+M][ry+M]--;
			g[rx+M][ly+M]--;g[lx+M][ly+M]++;
		}

		int ans=0;
		for(int i=1;i<T;i++)
			for(int j=1;j<T;j++)
			{
				g[i][j]+=g[i-1][j]+g[i][j-1]-g[i-1][j-1];
				if(g[i][j])ans++;
			}
		printf("%.2f\n",(double)ans);
		return 0;
	}

	int mina()
	{
		for(int i=1;i<=n;i++)
			if(a[i].ty==0)
				markA(a[i]);
			else markB(a[i]);

		for(int i=1;i<T;i++)
			for(int j=1;j<T;j++)
				g[i][j]+=g[i-1][j]+g[i][j-1]-g[i-1][j-1];
		for(int i=2;i<T;i++)
			for(int j=2;j<T-1;j++)
			{
				f[i][j]+=f[i-1][j-1]+f[i-1][j+1]-f[i-2][j];
				t[i][j]+=t[i-1][j-1]+t[i-1][j+1]-t[i-2][j];
				b[i][j]+=b[i-1][j-1]+b[i-1][j+1]-b[i-2][j];
				o[i][j]+=o[i-1][j-1]+o[i-1][j+1]-o[i-2][j];
				e[i][j]+=e[i-1][j-1]+e[i-1][j+1]-e[i-2][j];
			}

		double ans=0;
		for(int i=1;i<T;i++)
			for(int j=1;j<T;j++)
			{
				if(f[i][j]>0 || g[i][j]>0)
				{
					ans+=1.0;continue;
				}
				bool tmp[]={t[i][j]>0,b[i][j]>0,e[i][j]>0,o[i][j]>0};
				int cntt=0;
				for(int i=0;i<=3;i++)
					cntt+=tmp[i];
				if(cntt>=3){ans+=1.0;continue;}
				if(cntt==1){ans+=0.5;continue;}

				for(int k=0;k<=1;k++)
					if(tmp[k] && tmp[k+2])
					{
						ans+=1.0;continue;
					}
				for(int k=0;k<=3;k++)
					if(tmp[k] && tmp[(k+1)%4])
					{
						ans+=0.75;continue;
					}
			}
/*
		for(int i=-10+M;i<=10+M;i++,puts(""))
			for(int j=-10+M;j<=10+M;j++)
			{
				if(f[i][j]>0 || g[i][j]>0)
					printf("# ");
				else if(t[i][j]>0)
					printf("t ");
				else if(b[i][j]>0)
					printf("b ");
				else if(o[i][j]>0)
					printf("o ");
				else if(e[i][j]>0)
					printf("e ");
				else
					printf(". ");
			}
*/	

//		cerr<<sizeof(t)/1024/1024*6<<endl;
		printf("%.2f\n",ans);
		return 0;
	}
}

int main()
{
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
	
	n=read();char str[5];
	for(int i=1;i<=n;i++)
	{
		scanf("%s",str+1);
		if(str[1]=='A')
			a[i].ty=0;
		else
			a[i].ty=1;
		a[i].x=read();
		a[i].y=read();
		a[i].d=read();
		if(a[i].ty==1)
			flag=1;
	}

	bf::mina();
	
	return 0;
}
