#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

int k,q,ans;
int seq[1<<16],top;

inline void build(int x,int l,int r,int ty)
{
	if(l==r){seq[++top]=x>>1;return;}
	int mid=l+r>>1;
	if(ty==2)
	{
		build(x<<1,l,mid,1);
		seq[++top]=x<<1|1;
		build(x<<1|1,mid+1,r,2);
	}
	else
	{
		build(x<<1,l,mid,1);
		build(x<<1|1,mid+1,r,1);
		seq[++top]=x>>1;
	}
}

inline int siz(int x)
{
	int tot=0;
	while(x!=1)x>>=1,tot++;
	return (1<<(k-tot))-1;
}

int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	scanf("%d%d",&k,&q);
	build(1,1,1<<(k-1),2);
	top-=2;

	for(int i=1,a,d,m;i<=q;i++)
	{
		scanf("%d%d%d",&a,&d,&m);
		ll ans=0;
		for(int j=a;j<=a+(m-1)*d;j+=d)
			ans+=seq[j];
		printf("%lld\n",ans);
	}

	return 0;
}

