#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e6+10;
unsigned int f[maxn],Min[maxn],F[maxn];
int mu[maxn],prime[maxn],vis[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline unsigned int fpm(unsigned int a,unsigned int b){
	unsigned int ans=1;
	while(b){
		if(b & 1)ans=ans*a;
		a=a*a;b/=2;
	}
	return ans;
}
inline void initialize(int n){
	int i,j,cnt=0;
	vis[1]=1;mu[1]=1;
	for(i=2;i<=n;i++){
		if(!vis[i]){
			mu[i]=-1;
			prime[++cnt]=i;
		}
		for(j=1;j<=cnt && i*prime[j]<=n;j++){
			vis[i*prime[j]]=1;
			mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				break;
			}
		}
	}
}
int main(){
	unsigned int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
#endif
	n=read();k=read();
	initialize(n);
	memset(Min,63,sizeof(Min));
	f[1]=0;
	for(i=2;i<=n;i++)
		for(j=i;j<=n;j+=i)
			Min[j]=min(Min[j],i);
	for(i=2;i<=n;i++)f[i]=i/Min[i];
	for(i=1;i<=n;i++)
		for(j=i;j<=n;j+=i)
			F[j]+=1ll*mu[j/i]*fpm(f[i],k);
	unsigned int ans=0;
	for(i=1;i<=n;i++)ans+=1ll*(n/i)*(n/i)*F[i];
	printf("%u\n",ans);
	return 0;
}

