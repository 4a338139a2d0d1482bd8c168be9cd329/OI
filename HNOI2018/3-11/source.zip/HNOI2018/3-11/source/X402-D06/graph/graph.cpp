#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e2+10;
const int mod=1e9+7;
int dp[maxn][maxn],C[maxn][maxn],Pow3[maxn*maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int fpm(int a,int b){
	int ans=1;
	while(b){
		if(b & 1)ans=1ll*ans*a%mod;
		a=1ll*a*a%mod;b/=2;
	}
	return ans;
}
inline int Mod(int val){
	if(val>=mod)val-=mod;
	if(val<0)val+=mod;
	return val;
}
int main(){
	int i,j,k,l,m,n,T;
#ifndef ONLINE_JUDGE
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
#endif
	n=100;m=100;
	C[0][0]=1;
	Pow3[0]=1;
	for(i=1;i<=n*m;i++)Pow3[i]=1ll*Pow3[i-1]*3%mod;
	for(i=1;i<=n;i++){
		C[i][0]=1;
		for(j=1;j<=n;j++)
			C[i][j]=Mod(C[i-1][j-1]+C[i-1][j]);
	}
	for(i=0;i<=n;i++)
		for(j=0;j<=m;j++){
			int &res=dp[i][j];res=Pow3[i*j];
			for(k=1;k<=i;k++)
				for(l=0;l<=j;l++){
					if(k==i && j==l)continue;
					res=Mod(res-1ll*Pow3[(i-k)*(j-l)]*dp[k][l]%mod*C[i-1][k-1]%mod*C[j][l]%mod);
				}
		}
	T=read();
	while(T--){
		n=read();m=read();
		printf("%d\n",dp[n][m]);
	}
	return 0;
}

