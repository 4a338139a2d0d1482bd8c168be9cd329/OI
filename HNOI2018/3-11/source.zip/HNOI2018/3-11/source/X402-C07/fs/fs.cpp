#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;
priority_queue<int,vector<int>,greater<int> > h;
int k,q,du[1000012],n=0,w[1000012];
void doing(int x,int d){
	du[x/2]++;
	if (d==k)
	{
	  h.push(x);
	  return ;
	}
	doing(x*2,d+1);
	doing(x*2+1,d+1);
}

int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	scanf("%d%d",&k,&q);
	//scanf("%d",&k);
	int k2=(1LL<<k);
	doing(1,1);
	while (!h.empty()&&n<k2-3)
	{
	  int x=h.top();
	  h.pop();
	  w[++n]=x/2;
	  du[x/2]--;
	  if (du[x/2]==0)
	    h.push(x/2);
	}
	//for (int i=1;i<=k2-3;i++)
	//  printf("%d ",w[i]);printf("\n");
	while (q--)
	{
	  int a,d,m;
	  scanf("%d%d%d",&a,&d,&m);
	  int ans=0;
	  for (int i=a;i<=a+(m-1)*d;i+=d)
	    ans+=w[i];
	  printf("%d\n",ans);
	}
	return 0;
}
