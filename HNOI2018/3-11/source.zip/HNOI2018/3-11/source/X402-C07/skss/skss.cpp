#include<cstdio>
#include<algorithm>
using namespace std;

int n,x1,y1,x2,y2,x3,y3,x4,y4,x,y,d,xx1,yy1,xx2,yy2;
char ch;
int a[10][2012][2012],m=0,t[2012];
double ans=0;


struct node{
	int x,y1,y2,w;
	bool operator<(const node &aa) const{
	  return x<aa.x;
	}
}q[400012];

void ad(int x,int y,int d){
	int a1=a[1][x][y],a2=a[2][x][y],a3=a[3][x][y],a4=a[4][x][y];
	if (a1==1&&a2==1)
	  return ;
	if (a3==1&&a4==1)
	  return ;
	if (d==5)
	{
	  int tot=0;
	  tot+=a1;
	  tot+=a2;
	  tot+=a3;
	  tot+=a4;
	  if (tot==2)
	    ans+=0.25;
	  if (tot==1)
	    ans+=0.5;
	  if (tot==0)
	    ans+=1;
	  a[1][x][y]=a[2][x][y]=a[3][x][y]=a[4][x][y]=1;
	  return ;
	}
	if (d==1)
	{
	  if (a1==1)
	    return ;
	  if (a3==1||a4==1)
	    ans+=0.25;
	  if (a3==0&&a4==0)
	    ans+=0.5;
	  a[1][x][y]=1;
	  return ;
	}
	if (d==2)
	{
	  if (a2==1)
	    return ;
	  if (a3==1||a4==1)
	    ans+=0.25;
	  if (a3==0&&a4==0)
	    ans+=0.5;
	  a[2][x][y]=1;
	  return ;
	}
	if (d==3)
	{
	  if (a3==1)
	    return ;
	  if (a1==1||a2==1)
	    ans+=0.25;
	  if (a1==0&&a2==0)
	    ans+=0.5;
	  a[3][x][y]=1;
	  return ;
	}
	if (d==4)
	{
	  if (a4==1)
	    return ;
	  if (a1==1||a2==1)
	    ans+=0.25;
	  if (a1==0&&a2==0)
	    ans+=0.5;
	  a[4][x][y]=1;
	  return ;
	}
}

long long read(){
	long long x=0,f=1;
	char ch=getchar();
	while (ch>'9'||ch<'0')
	{
	  if (ch=='-')
	    f=-1;
	  ch=getchar();
	}
	while (ch>='0'&&ch<='9')
	{
	  x=(x<<1)+(x<<3)+(ch^'0');
	  ch=getchar();
	}
	return x*f;
}

int main(){
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
	n=read();
	if (n<=1000)
	{
	  for (register int i=1;i<=n;i++)
	  {
	    char ch=getchar();
	    while (ch!='A'&&ch!='B')
	      ch=getchar();
	    x=read(),y=read(),d=read();
	    x+=1001,y+=1001;
	    if (ch=='A')
	    {
	  	  x1=x-d/2,y1=y-d/2;//zuo xia
	  	  x2=x+d/2,y2=y+d/2;//you shang
	  	  for (register int i=x1;i<=x2-1;i++)
	  	    for (register int j=y1;j<=y2-1;j++)
			  ad(i,j,5);
	    }
	    if (ch=='B')
	    {
	  	  x1=x-d/2,y1=y;//zuo
	  	  x2=x,y2=y+d/2;//shang
	  	  x3=x+d/2,y3=y;//you
	  	  x4=x,y4=y-d/2;//xia
	  	  xx1=x1,yy1=y1,xx2=x1,yy2=y1-1;
	  	  while (xx1<x2)
	  	  {
	  	    ad(xx1,yy1,4);
	  	    ad(xx2,yy2,1);
	  	    for (register int j=yy2+1;j<=yy1-1;j++)
	  	      ad(xx1,j,5);
	  	    xx1++,yy1++,xx2++,yy2--;
	      }
	      xx1=x2,yy1=y2-1,xx2=x4,yy2=y4;
	      while (xx2<x3)
	      {
	        ad(xx1,yy1,2);
	        ad(xx2,yy2,3);
	        for (register int j=yy2+1;j<=yy1-1;j++)
	          ad(xx1,j,5);
	        xx1++,yy1--,xx2++,yy2++;
	      }
	    }
	  }
	  printf("%.2lf\n",ans);
	  return 0;
	}
	for (register int i=1;i<=n;++i)
	{
	  char ch=getchar();
	  while (ch!='A'&&ch!='B')
	    ch=getchar();
	  x=read(),y=read(),d=read();
	  x+=1001,y+=1001;
	  x1=x-d/2,y1=y-d/2;//zuo xia
	  x2=x+d/2,y2=y+d/2;//you shang
	  q[++m].x=x1,q[m].y1=y1,q[m].y2=y2,q[m].w=0;
	  q[++m].x=x2,q[m].y1=y1,q[m].y2=y2,q[m].w=1;
	}
	sort(q+1,q+1+m);
	int now=0;
	for (register int i=1;i<=m;++i)
	{
	  int x=q[i].x,y1=q[i].y1,y2=q[i].y2,w=q[i].w;
	  if (w==0)
	  {
	  	ans+=now*(q[i].x-q[i-1].x);
	  	for (register int j=y1;j<=y2-1;++j)
	  	{
		  t[j]++;
		  if (t[j]==1)
		    now++;
		}
	  }
	  if (w==1)
	  {
	  	ans+=now*(q[i].x-q[i-1].x);
	  	for (register int j=y1;j<=y2-1;++j)
	  	{
	  	  t[j]--;
	  	  if (t[j]==0)
	  	    now--;
	  	}
	  }
	}
	printf("%.2lf\n",ans);
	return 0;
}
