#include<cstdio>
#include<algorithm>
using namespace std;

int n,q,p[1000012],maxn[4000012],minn[4000012];
int pos[1000012];


void build(int o,int l,int r){
	if (l==r)
	{
	  maxn[o]=p[l];
	  minn[o]=p[l];
	  return ;
	}
	int mid=(l+r)/2;
	build(o*2,l,mid);
	build(o*2+1,mid+1,r);
	maxn[o]=max(maxn[o*2],maxn[o*2+1]);
	minn[o]=min(minn[o*2],minn[o*2+1]);
}

int findmax(int o,int l,int r,int a,int b){
	if (a<=l&&r<=b)
	  return maxn[o];
	int mid=(l+r)/2,anc=-2147483600;
	if (a<=mid)
	  anc=max(anc,findmax(o*2,l,mid,a,b));
	if (b>mid)
	  anc=max(anc,findmax(o*2+1,mid+1,r,a,b));
	return anc;
}

int findmin(int o,int l,int r,int a,int b){
	if (a<=l&&r<=b)
	  return minn[o];
	int mid=(l+r)/2,anc=2147483600;
	if (a<=mid)
	  anc=min(anc,findmin(o*2,l,mid,a,b));
	if (b>mid)
	  anc=min(anc,findmin(o*2+1,mid+1,r,a,b));
	return anc;
}

int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
	  scanf("%d",&p[i]);
	  pos[p[i]]=i;
	}
	build(1,1,n);
//	for (int i=1;i<=n;i++)
//	  for (int j=i;j<=n;j++)
//	    printf("%d %d   %d %d\n",i,j,findmax(1,1,n,i,j),findmin(1,1,n,i,j));
	scanf("%d",&q);
	while (q--)
	{
	  int xx,yy;
	  scanf("%d%d",&xx,&yy);
	  int ok=0;
	  int a=xx,b=yy;
	  int l=findmin(1,1,n,a,b),r=findmax(1,1,n,a,b);
	  if (r-l+1==b-a+1)
	  {
	  	printf("%d %d\n",a,b);
	  	continue;
	  }
	  while (1)
	  {
	  	int numx=-10,numy=-10,x=a,y=b;
		for (int i=l;i<=r;i++)
	    {
		  if (pos[i]<a)
		    if (numx<l-pos[i])
		      numx=l-pos[i],x=pos[i];
		  if (pos[i]>b)
		    if (numy<pos[i]-r)
			  numy=pos[i]-r,y=pos[i];
		}
		a=x,b=y;
		l=findmin(1,1,n,a,b),r=findmax(1,1,n,a,b);
		if (r-l+1==b-a+1)
		{
		  printf("%d %d\n",a,b);
		  break;
		}
	  }
	  /*
	  for (int l=(y-x+1);l<=n;l++)
	  {
		for (int a=max(1,y-l+1);a<=x&&(a+l-1)<=n;a++)
	    {
	      int b=a+l-1;
	      //printf("%d %d %d\n",l,a,b);
	      if ((findmax(1,1,n,a,b)-findmin(1,1,n,a,b)+1)==l)
	      {
	      	printf("%d %d\n",a,b);
	      	ok=1;
	      	break;
	      }
	    }
	    if (ok==1)
	      break;
	  }*/
	}
	
	return 0;
}
