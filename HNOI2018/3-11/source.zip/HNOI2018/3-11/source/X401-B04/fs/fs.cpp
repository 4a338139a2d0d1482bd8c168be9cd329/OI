#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=(1<<15)+10;
inline void read(int &x)
{
	x=0;  int p=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') p=-1; ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		x=(x<<3)+(x<<1)+(ch^'0'); ch=getchar();
	}
	x=x*p;
}
int k,q;
int a,d,m,sum;
int pru[maxn],pre[maxn];
long long b[maxn];

inline void prufer(int n)
{
	int s=0,u=1<<(k-2),o=u,l=1<<1;
	if(u==2) 
	{
		pru[1]=2; pru[2]=2; pru[3]=1; pru[4]=3; pru[5]=3;
		return ;
	}
	/*do{
		pru[++s]=u; pru[++s]=u;
		pru[++s]=u+1; pru[++s]=u+1;
		u=u>>1;
		if(u==2) {
			pru[++s]=2; pru[++s]=2; pru[++s]=1;
			u=o+2,o=o+2;
		}
		//cout<<u<<' '<<s<<endl;
	}while(s<=n-2);*/
	/*do{
		pru[++s]=u; pru[++s]=u; pru[++s]=u>>1;
		pru[++s]=u+1; pru[++s]=u+1; pru[++s]=u>>1;
		pru[++s]=u>>2;
		u=o+l; o=o+l;
		pru[++s]=u; pru[++s]=u; pru[++s]=u>>1; if(s==n-2) break;
		pru[++s]=u+1; pru[++s]=u+1; pru[++s]=u>>1; if(s==n-2) break;
		pru[++s]=u>>2; if(s==n-2) break;
		u=o+l; o=o+l;
		/*if(u==2) {
			pru[++s]=1; u=o+l; o=o+l;
		}*/
	//}while(s<=n-2);
	return ;
}

int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	read(k); read(q);
	int n=1<<k; n=n-2;
	prufer(n);
//	for(register int i=1;i<=n-1;i++) cout<<pru[i]<<' ';
	b[1]=pru[1];
	for(register int i=2;i<=n;i++)
		b[i]=b[i-1]+pru[i];
	for(register int i=1;i<=q;i++){
		int a,d,m; sum=0;
		read(a); read(d); read(m);
		int s=a; sum=pru[s];
		if(d==1) {
			sum=b[(m-1)*d+a]-b[a-1];
			cout<<sum<<endl; continue;
		}
		for(register int j=1;j<=m-1;j++){
			s+=d; sum+=pru[s];
			//cout<<s<<' '<<j<<' '<<d<<endl;
		}
		cout<<sum<<endl;
	}
	return 0;
}
