//2018-03-11
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register int i=a;i<=b;i++)
#define Forr(i,a,b) for(register int i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}
inline void read(int &x)
{
	int p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<3)+(x<<1)+(c^'0');c=getchar();}
	x*=p;
}
int n,q;
int p[1010];
int qwq[1010][1010];
bool check(int x,int y)
{
	int cnt[1010]={0},minn=1<<30,maxx=1<<31;
	For(i,x,y)cnt[p[i]]=1,minn=min(minn,p[i]),maxx=max(maxx,p[i]);
	For(i,minn,maxx)if(!cnt[i])return 1;
	qwq[x][y]=qwq[y][x]=1;
	return 0;
}
void find(int x,int y)
{
	if(x==y||qwq[x][y]){printf("%d %d\n",x,y);return;}
	int cnt=1;
	while(cnt+(y-x+1)<n)
	{
		For(i,0,cnt)
		{
			int OmO=cnt-i;
			if(x-i<=0)break;
			if(y+OmO>n)continue;
			if(x-i>0&&y+OmO<=n&&qwq[x-i][y+OmO]){printf("%d %d\n",x-i,y+OmO);return;}
		}
		cnt++;
	}
	printf("%d %d\n",1,n);
	return;
}
int main()
{
	File();
	read(n);
	For(i,1,n)read(p[i]);
	For(i,1,n)For(j,i+1,n)check(i,j);
	read(q);
	while(q--)
	{
		int x,y;
		read(x),read(y);
		find(x,y);
	}
	return 0;
}
