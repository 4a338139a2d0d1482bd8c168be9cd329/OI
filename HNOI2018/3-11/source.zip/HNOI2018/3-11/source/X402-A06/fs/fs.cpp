#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int st[maxn], top, K, q, pruffer[maxn], cnt, rd[maxn];

int Start, End;

void Get() {
	K = read(), q = read();
}

void dfs(int h) {
	if(h * 2 <= End) {
		rd[h] += 2;
		dfs(h<<1), dfs(h<<1|1);
	}
}

void solve_bf() {
	Start = (1 << K-1), End = (1 << K) - 1;
	rep(i, End, Start) st[++top] = i;
	dfs(1);

	while(End - cnt > 2) {
		int now = st[top--];
		if( (-- rd[now/2]) == 0){
			st[++top] = now/2;
		}
		pruffer[++cnt] = now / 2;
	}

	while(q --) {
		int a = read(), d = read(), m = read(), Ans = 0;
		For(i, 0, m-1) Ans += pruffer[a + i * d];
		printf("%d\n", Ans);
	}
}

int main() {

	freopen("fs.in", "r", stdin);
	freopen("fs.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
