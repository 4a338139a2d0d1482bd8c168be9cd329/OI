#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, Max[maxn][22], Min[maxn][22], a[maxn], Lg[maxn];

int pos[maxn], minn[maxn][22], maxx[maxn][22], q;

void Get() {
	n = read();
	For(i, 1, n) a[i] = read();
	For(i, 1, n) For(j, 0, 20) Max[i][j] = 0, Min[i][j] = inf, maxx[i][j] = 0, minn[i][j] = inf;
	For(i, 1, n) Max[i][0] = Min[i][0] = a[i];

	For(i, 1, n) pos[a[i]] = i;
	For(i, 1, n) maxx[i][0] = minn[i][0] = pos[i];
	q = read();
}

struct node{
	int l, r;
}dp[2010][2010];

bool rem[2010][2010];

void pre_work() {
	For(j, 1, 20) {
		For(i, 1, n) {
			if(i + (1 << j-1) > n) break;
			Max[i][j] = max(Max[i][j-1], Max[i+(1<<j-1)][j-1]);
			Min[i][j] = min(Min[i][j-1], Min[i+(1<<j-1)][j-1]);

			maxx[i][j] = max(maxx[i][j-1], maxx[i+(1<<j-1)][j-1]);
			minn[i][j] = min(minn[i][j-1], minn[i+(1<<j-1)][j-1]);
		}
	}

	For(i, 1, n) Lg[i] = log2(i);
}

void pre_work_first(){
	For(i, 1, n) {
		For(j, i, n) {
			int k = Lg[j-i+1];
			int Maxx = max(Max[i][k], Max[j-(1<<k)+1][k]);
			int Minn = min(Min[i][k], Min[j-(1<<k)+1][k]);
			if(Maxx - Minn + 1 == j - i + 1){
				rem[i][j] = 1;
				dp[i][j].l = i, dp[i][j].r = j;
			}
		}
	}
}

node dfs(int l,int r) {
	if(rem[l][r]) return dp[l][r];
	int k = Lg[r-l+1];
	int Maxx = max(Max[l][k], Max[r-(1<<k)+1][k]);
	int Minn = min(Min[l][k], Min[r-(1<<k)+1][k]);

	k = Lg[Maxx - Minn + 1];
	int L = min(minn[Minn][k], minn[Maxx-(1<<k)+1][k]);
	int R = max(maxx[Minn][k], maxx[Maxx-(1<<k)+1][k]);

	rem[l][r] = 1;
	return dp[l][r] = dfs(L, R);
}

void solve_bf() {
	pre_work();
	pre_work_first();
	while(q --) {
		int l = read(), r = read();
		node T = dfs(l, r);
		printf("%d %d\n", T.l, T.r);
	}
}

void dfs_calc(int l,int r) {
	int k = Lg[r-l+1];
	int Maxx = max(Max[l][k], Max[r-(1<<k)+1][k]);
	int Minn = min(Min[l][k], Min[r-(1<<k)+1][k]);

	if(Maxx - Minn == r - l) {
		printf("%d %d\n", l, r);
		return;
	}

	k = Lg[Maxx - Minn + 1];
	int L = min(minn[Minn][k], minn[Maxx-(1<<k)+1][k]);
	int R = max(maxx[Minn][k], maxx[Maxx-(1<<k)+1][k]);

	dfs_calc(L, R);
}

void solve() {
	pre_work();
	while(q --) {
		int l = read(), r = read();
		dfs_calc(l, r);
	}
}

int main() {

	freopen("ffs.in", "r", stdin);
	freopen("ffs.out", "w", stdout);

	Get();
	if(n <= 1000 && q <= 1000) solve_bf();
	else solve();

	return 0;
}
