#include<bits/stdc++.h>

#define For(i, a, b) for(int i = (a);i <= (b); ++i)

using namespace std;

const int maxn = 100010;

int a[maxn];

int main() {
	
	freopen("ffs.in", "w", stdout);
	srand(time(NULL));
	int n = 1000;
	printf("%d\n", n);
	For(i, 1, n) a[i] = i;
	random_shuffle(a+1, a+n+1);
	For(i, 1, n) printf("%d ", a[i]);
	puts("");

	int q = 1000;
	printf("%d\n", q);
	while(q--){
		int r = rand()%n+1;
		int l = rand()%r+1;
		printf("%d %d\n", l, r);
	}

	return 0;
}
