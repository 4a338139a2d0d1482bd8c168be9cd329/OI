#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, vis[maxn], Max[maxn][22], Min[maxn][22], a[maxn], Lg[maxn];

void Get() {
	n = read();
	For(i, 1, n) a[i] = read();
	For(i, 1, n) For(j, 0, 20) Max[i][j] = 0, Min[i][j] = inf;
	For(i, 1, n) Max[i][0] = Min[i][0] = a[i];
}

struct node{
	int l, r;
}dp[2010][2010];

bool rem[2010][2010];

int pos[maxn];

void pre_work() {
	For(j, 1, 20) {
		For(i, 1, n) {
			if(i + (1 << j-1) > n) break;
			Max[i][j] = max(Max[i][j-1], Max[i+(1<<j-1)][j-1]);
			Min[i][j] = min(Min[i][j-1], Min[i+(1<<j-1)][j-1]);
		}
	}

	For(i, 1, n) Lg[i] = log2(i);
	For(i, 1, n) {
		For(j, i, n) {
			int k = Lg[j-i+1];
			int Maxx = max(Max[i][k], Max[j-(1<<k)+1][k]);
			int Minn = min(Min[i][k], Min[j-(1<<k)+1][k]);
			if(Maxx - Minn + 1 == j - i + 1){
				rem[i][j] = 1;
				dp[i][j].l = i, dp[i][j].r = j;
			}
		}
	}

	For(i, 1, n) pos[a[i]] = i;
}

node dfs(int l,int r) {
	if(rem[l][r]) return dp[l][r];
	int k = Lg[r-l+1];
	int Maxx = max(Max[l][k], Max[r-(1<<k)+1][k]);
	int Minn = min(Min[l][k], Min[r-(1<<k)+1][k]);

	int L = l, R = r;
	For(i, Minn, Maxx) {
		L = min(L, pos[i]);
		R = max(R, pos[i]);
	}

	rem[l][r] = 1;
	return dp[l][r] = dfs(L, R);
}

void solve_bf() {
	pre_work();
	int q = read();
	while(q --) {
		int l = read(), r = read();
		node T = dfs(l, r);
		printf("%d %d\n", T.l, T.r);
	}
}

int main() {

	freopen("ffs.in", "r", stdin);
	freopen("ffs.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
