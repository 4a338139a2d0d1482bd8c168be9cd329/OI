#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
#include<ctime>
#define ls(x) (x<<1)
#define rs(x) ((x<<1)|1)
#define fa(x) (x>>1)
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Dor(i,j,k) for(int i=j;i>=k;--i)
using namespace std;
const int N=1e7+10;
int a[N],d[N];
bool vis[N];
vector<int>puf;
priority_queue<int , vector<int>,greater<int> >qc;
bool cl(int x){
	if(!vis[x]){
		--d[x];
		if(d[x]==1)qc.push(x);
		return true;
	}return false;
}
int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	int m,k;
	scanf("%d%d",&k,&m);
	int s=clock();
	queue<int>q;
	q.push(1);
	while(!q.empty()){
		int u=q.front();q.pop();
		d[u]+=2;
		++d[ls(u)];
		++d[rs(u)];
		if(u<(1<<(k-2)))q.push(ls(u)),q.push(rs(u));
		else qc.push(ls(u)),qc.push(rs(u));
	}
	int siz=(1<<k)-3;
	while(siz--){
		int u=qc.top();qc.pop();
		vis[u]=1;
		if(ls(u)<(1<<k)&&cl(ls(u)))
			puf.push_back(ls(u));
		if(rs(u)<(1<<k)&&cl(rs(u)))
			puf.push_back(rs(u));
		if(fa(u)&&cl(fa(u)))
			puf.push_back(fa(u));
	}
	int x,y,z;
	while(m--){
		scanf("%d%d%d",&x,&y,&z);
		int ans=0;
		while(z--){
			ans+=puf[x-1];
			x+=y;
		}printf("%d\n",ans);
	}
	return 0;
}

