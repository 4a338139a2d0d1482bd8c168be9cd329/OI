#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Dor(i,j,k) for(int i=j;i>=k;--i)
#define ls (rt<<1)
#define rs ((rt<<1)|1)
#define Mid ((l+r)>>1)
using namespace std;
const int N=1e5+10;
const int oo=2100000000;
int a[N],b[N];//a:ֵ��λ�ã�b:λ�õ�ֵ 
struct node{
	int mx,mn;
	node(){
		mx=0,mn=oo;
	}
}c1[N<<2],c2[N<<2];//c1:ֵ��λ�ã�c2:λ�õ�ֵ 
void build1(int rt,int l,int r){
	if(l==r){
		c1[rt].mn=c1[rt].mx=a[l];
		return ;
	}
	build1(ls,l,Mid);
	build1(rs,Mid+1,r);
	c1[rt].mx=max(c1[ls].mx,c1[rs].mx);
	c1[rt].mn=min(c1[ls].mn,c1[rs].mn);
}
void build2(int rt,int l,int r){
	if(l==r){
		c2[rt].mn=c2[rt].mx=b[l];
		return ;
	}
	build2(ls,l,Mid);
	build2(rs,Mid+1,r);
	c2[rt].mx=max(c2[ls].mx,c2[rs].mx);
	c2[rt].mn=min(c2[ls].mn,c2[rs].mn);
}
int Ax,An,lx,ln;//l:ֵ��λ�ã�A:λ�õ�ֵ
void que1(int rt,int l,int r,int L,int R){
	if(L<=l&&r<=R){
		lx=max(lx,c1[rt].mx);
		ln=min(ln,c1[rt].mn);
		return; 
	}
	if(Mid>=L)que1(ls,l,Mid,L,R);
	if(Mid<R)que1(rs,Mid+1,r,L,R);
	return ;
}
void que2(int rt,int l,int r,int L,int R){
	if(L<=l&&r<=R){
		Ax=max(Ax,c2[rt].mx);
		An=min(An,c2[rt].mn);
		return; 
	}
	if(Mid>=L)que2(ls,l,Mid,L,R);
	if(Mid<R)que2(rs,Mid+1,r,L,R);
	return ;
}
int main(){
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	int n,m,L,R;
	scanf("%d",&n);
	For(i,1,n){
		scanf("%d",&b[i]);
		a[b[i]]=i;
	}
	build1(1,1,n);
	build2(1,1,n);
	scanf("%d",&m);
	while(m--){
		scanf("%d%d",&L,&R);
		while(true){
			lx=Ax=0,ln=An=oo;
			que2(1,1,n,L,R);
			que1(1,1,n,An,Ax);
			L=ln,R=lx;
			if(lx-ln==Ax-An)break;
		}
		printf("%d %d\n",L,R);
	}
	return 0;
}

