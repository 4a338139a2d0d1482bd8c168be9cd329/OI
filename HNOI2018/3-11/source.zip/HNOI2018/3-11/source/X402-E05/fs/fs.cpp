#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
}
int k,q;
int deg[N],vis[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
LL a[N],n;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void Get_prufer()
{
	priority_queue<int,vector<int>,greater<int>>q;
	For(i,1,(1<<k)-1)if(deg[i]==1)q.push(i);
	while(!q.empty())
	{
		int u=q.top();q.pop();
		vis[u]=1;
		for(int v,i=bgn[u];i;i=nxt[i])
		if(!vis[v=to[i]])
		{
			a[++n]=v;
			if((--deg[v])==1)
				q.push(v);
		}
	}
	n--;
}
int main()
{
	LL x,y,z;
	file();
	read(k),read(q);
	For(i,2,(1<<k)-1)
	{
		add_edge(i,i>>1);
		add_edge(i>>1,i);
		deg[i]++,deg[i>>1]++;
	}
	Get_prufer();
	while(q--)
	{
		read(x),read(y),read(z);
		LL ret=0;
		For(i,1,z)
		{
			if(x>n)break;
			ret+=a[x];
			x+=y;
		}
		printf("%lld\n",ret);
	}
	return 0;
}
