#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define lc p<<1
#define rc p<<1|1
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=200010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
}
int n,cnta,cntb;
char str[10];
struct Matrix
{
	int x,y,d;
	Matrix(){}
	Matrix(int x,int y,int d):x(x),y(y),d(d){}
}a[N],b[N];
/*
int sum[N],Min[N],Max[N],Ad[N],De[N];
inline void Add_node(int p,int l,int r,int x)
{
	Ad[p]+=x;
	Min[p]+=x,Max[p]+=x;
	if(Max[p]==0)sum[p]=0;
	if(Min[p]>0)sum[p]=r-l+1;
}
inline void Add_tree(int l,int r,int p,int x,int y)
{
	if(x<=l&&r<=y){Add_node(p,l,r,1);return;}
	int mid=(l+r)>>1;pushdown(p,l,r);
	if(x<=mid)Add_tree(ls,lc,x,y);
	if(y> mid)Add_tree(rs,rc,x,y);
	sum[p]=sum[lc]+sum[rc];
}
inline void Del_tree(int l,int r,int p,int x,int y)
{
	if(x<=l&&r<=y&&Min[p]==Max[p])
	{
		Del_node(p,l,r,1);

	}
}
vector<pii>Add[N],Del[N];
inline void SolveA()
{
	int R=4001;
	For(i,1,cnta)
	{
		int x=a[i].x,y=a[i].y,d=a[i].d>>1;
		Add[x-d+R].pb(pii(y-d+R,y+d-1+R));
		Del[x+d+R].pb(pii(y-d+R,y+d-1+R));
	}
	For(i,1,R)
	{
		For(j,0,SZ(Del[i])-1)Del_tree(1,R,1,Del[i][j].ft,Del[i][j].sd);
		For(j,0,SZ(Add[i])-1)Add_tree(1,R,1,Add[i][j].ft,Add[i][j].sd);
		ans+=sum[1];
	}
}
*/
int main()
{
	int x,y,z;
	file();
	read(n);
	For(i,1,n)
	{
		scanf("%s",str);
		read(x),read(y),read(z);
		str[0]=='A'?a[++cnta]=Matrix(x,y,z):b[++cntb]=Matrix(x,y,z);
	}
	/*
	if(!cntb)SolveA();
	else SolveBF();
	*/
	return 0;
}
