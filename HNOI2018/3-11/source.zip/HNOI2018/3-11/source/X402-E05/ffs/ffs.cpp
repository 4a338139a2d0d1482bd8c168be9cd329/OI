#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ft first
#define sd second
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}
int n,q,B2[N];
struct RMQ
{
	int x[N],Min[N][18],Max[N][18];
	inline void init()
	{
		For(i,1,n)Min[i][0]=Max[i][0]=x[i];
		For(i,1,17)For(j,1,n-(1<<i)+1)
		{
			Min[j][i]=min(Min[j][i-1],Min[j+(1<<(i-1))][i-1]);
			Max[j][i]=max(Max[j][i-1],Max[j+(1<<(i-1))][i-1]);
		}
	}
	inline pii Query(int l,int r)
	{
		int x=B2[r-l+1];
		int Mn=min(Min[l][x],Min[r-(1<<x)+1][x]);
		int Mx=max(Max[l][x],Max[r-(1<<x)+1][x]);
		return pii(Mn,Mx);
	}
}a,p;
int main()
{
	int x,y;
	file();
	read(n);
	For(i,1,n)read(p.x[i]);
	For(i,1,n)a.x[p.x[i]]=i;
	For(i,1,n)B2[i]=B2[i-1]+(i>=(1<<(B2[i-1]+1)));
	a.init();
	p.init();
	read(q);
	while(q--)
	{
		read(x),read(y);
		pii A=pii(x,y),P=p.Query(x,y);
		while(A.sd-A.ft!=P.sd-P.ft)
		{
			A=a.Query(P.ft,P.sd);
			P=p.Query(A.ft,A.sd);
		}
		printf("%d %d\n",A.ft,A.sd);
	}
	return 0;
}
