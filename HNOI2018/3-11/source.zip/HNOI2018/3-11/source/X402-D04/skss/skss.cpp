#include<bits/stdc++.h>
using namespace std;

const int maxn=200010;
const int lim=1500;
int n;
char s[10];
struct node{
	int x, y, d, type;
	bool operator <(const node& A)const{ return (x-d)<A.x-A.d || (x-d==A.x-A.d) && x<A.x; }
}a[maxn];
double ans;
int sum[maxn], f[maxn];
int incline[5][maxn];
vector<int> g[maxn], w[maxn];

void read(int& x){
	x=0; char c=getchar(); int f=1;
	while(c<'0' || c>'9'){ if(c=='-') f=-1; c=getchar(); }
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	x*=f;
}

int Min, Max;

void solve(){
	for(int i=1;i<=n;i++){
		int x=a[i].x, y=a[i].y, d=a[i].d/2;
		g[x-d+lim].push_back(y-d); w[x-d+lim].push_back(y+d);
		w[x+d+lim].push_back(y-d); g[x+d+lim].push_back(y+d);
	}
	int Ans=0;
	for(int i=-lim;i<=lim;i++){
		for(int j=-lim;j<=lim;j++) f[j+lim]=0;
		for(int j=0;j<g[i+lim].size();j++) f[ g[i+lim][j]+lim ]++;
		for(int j=0;j<w[i+lim].size();j++){
			// cerr<<w[i+lim][j]<<endl;
			f[ w[i+lim][j]+lim ]--;
		}
		for(int j=-lim+1;j<=lim;j++){
			f[j+lim]+=f[j-1+lim];
			sum[j+lim]+=f[j+lim];
		}
		for(int j=-lim;j<=lim;j++) if(sum[j+lim]>0) Ans++;
	}
	printf("%d.00\n", Ans);
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
}

int main(){
	freopen("skss.in","r",stdin),freopen("skss.out","w",stdout);

	read(n);
	int f=1;
	Min=lim, Max=-lim;
	for(int i=1;i<=n;i++){
		scanf("%s", s);
		if(s[0]=='A') a[i].type=1; else a[i].type=2;
		f &= a[i].type==1;
		read(a[i].x), read(a[i].y), read(a[i].d);
		Min=min(Min, a[i].x-a[i].d/2); Max=max(Max, a[i].x+a[i].d/2);
	}
	// solve(); 
	if(n>3000 && f){ solve(); return 0; }
	// for(int i=1;i<=n;i++) printf("%d ", a[i].type); puts("");
	ans=0;
	sort(a+1,a+1+n);
	for(int i=Min;i<Max;i++){
		// cerr<<i<<endl;
		// printf("\n%d----\n\n", i);
		for(int j=-lim;j<=lim;j++) sum[j+lim]=0;
		for(int j=-lim;j<=lim;j++) for(int k=1;k<=4;k++) incline[k][j+lim]=0;
		// for(int j=-20;j<=10;j++) printf("%d ", sum[j]); puts("");
		int t=0;
		for(int j=1;j<=n;j++){
			int x=a[j].x, y=a[j].y, d=a[j].d/2;
			if(x-d>i) break;
			if(a[j].type==1){
				if(x-d<=i && x+d>i){
					// printf("%d %d\n", y-d, y+d);
					sum[y-d+lim]++, sum[y+d+lim]--;
				}
			}else{
				if(x-d<=i && x+d>i){
					int length=i-(x-d);
					if(x>i){
						sum[y-length+lim]++, sum[y+length+lim]--;
						incline[3][y-length-1+lim]++, 
						incline[4][y-length-1+lim]++,
						incline[2][y+length+lim]++,
						incline[3][y+length+lim]++;
					}else{
						length=x+d-i;
						sum[y-length+1+lim]++, sum[y+length-1+lim]--;
						incline[1][y-length+lim]++, 
						incline[4][y-length+lim]++,
						incline[1][y+length-1+lim]++,
						incline[2][y+length-1+lim]++;
					}
				}
			}
		}
		int s=0;
		for(int j=-lim;j<=lim;j++){
			s+=sum[j+lim];
			// if(sum[j]) printf("sum[ %d ] = %d\n", j, sum[j]);
			if(s>=1) ans+=1.0;
			else{
				int t=0;
				for(int k=1;k<=4;k++) t+=(bool)incline[k][j+lim];
				ans+=1.0*t/4;
			}
		}
		// printf("%d %.2lf\n", i, ans);
	}
	printf("%.2lf\n", ans);
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
