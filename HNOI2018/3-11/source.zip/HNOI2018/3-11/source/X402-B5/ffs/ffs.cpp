#include<bits/stdc++.h>
#define LL long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=100000+100;
int p[maxn];
int d[maxn];
int n;
int L[1010][1010];//位置i～j，权值min
int R[1010][1010];//max
int Min[1010][1010];//权值i～j，位置min
int Max[1010][1010];//max
int q,a,b,l,r,ll,rr;
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++) p[i]=read(),d[p[i]]=i;
	if (n<=1000)
	{
		memset(L,1,sizeof(L));
		memset(Min,1,sizeof(Min));
		for (int i=1;i<=n;i++)
		{
			L[i][i]=R[i][i]=p[i];
			Min[i][i]=Max[i][i]=d[i];
		}
		for (int k=1;k<n;k++)
			for (int i=1,j=i+k;j<=n;i++,j=i+k)
			{
				L[i][j]=min(L[i+1][j],p[i]);
				R[i][j]=max(R[i+1][j],p[i]);
				Min[i][j]=min(Min[i+1][j],d[i]);
				Max[i][j]=max(Max[i+1][j],d[i]);
			}

		q=read();
		while (q--)
		{
			a=read();b=read();l=0;r=0;
			ll=L[a][b];rr=R[a][b];
			while (l!=Min[ll][rr]||r!=Max[ll][rr])
			{
				l=Min[ll][rr];r=Max[ll][rr];
				ll=L[l][r];rr=R[l][r];
			}

			printf("%d %d\n",l,r);
		}
	}
	return 0;
}
