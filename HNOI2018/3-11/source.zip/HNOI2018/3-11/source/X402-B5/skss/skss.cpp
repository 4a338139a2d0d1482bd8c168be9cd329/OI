#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
int N=1001;
int p[2020][2020];
int n,a,b,c,sum;
char ch[10];
int main()
{
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++)
	{
		scanf("%s",ch);
		a=read();b=read();c=read();
		if (ch[0])
		{
			p[a+N][b+N]++;
			p[a+N][b+N+c]--;
			p[a+N+c][b+N]--;
			p[a+N+c][b+N+c]++;
		}
	}
	for (int i=1;i<=N*2;i++)
		for (int j=1;j<=N*2;j++)
		{
			p[i][j]=p[i][j]+p[i-1][j]+p[i][j-1]-p[i-1][j-1];
		}
	for (int i=1;i<=N*2;i++)
		for (int j=1;j<=N*2;j++)
		{
			if (p[i][j]>=1) sum++;
		}
	printf("%d\n",sum);
	return 0;
}
