#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
int k,q;
int a,d,m,s,L;
int b[(1<<15)+20],id;
int sum[(1<<15)+20];
int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	k=read();q=read();
	if (k==2)
	{
		while (q--)
		{
			a=read();d=read();m=read();
			if (a==1) printf("1\n"); else printf("0\n");
		}
		return 0;
	}
	if (k<=15)
	{
		s=1<<(k-2);
		L=(1<<(k-1))-1;
		id=0;
		for (int i=s;i<=L;i++)
		{
			id++;b[id]=i;
			id++;b[id]=i;
			sum[i/2]+=2;
			int now=i/2;
			while (sum[now]==2||sum[now]==4)
			{
				id++;b[id]=now;
				sum[now/2]++;
				if (now==1) break;
				now=now/2;
			}
		}
		while (q--)
		{
			a=read();d=read();m=read();
			ll ans=0;
			for (int i=a;i<=a+(m-1)*d;i+=d)
			{
				ans+=(ll)(b[i]);
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
