#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int inf=0x3f3f3f3f;
const ll infl=1e17;
int p[N],n,stk[N],top;
struct node
{
	int typ,x,l,r,k;// typ=0:upd; typ=1:ask;
	node(int typ=0,int x=0,int l=0,int r=0,int k=0) :typ(typ),x(x),l(l),r(r),k(k) { }
};
bool operator < (node a,node b) {return a.x<b.x||(a.x==b.x&&a.typ<b.typ);}
node A[N*5]; int m=0;

namespace seg
{
	ll addv[N<<2],minv[N<<2];
	int minwh; ll min_;
}

pii ans[N];
int lef[N],rig[N];
void wj()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) p[i]=read();
	int Q=read();
	for(int i=1;i<=Q;++i) 
	{
		int x=read(),y=read();
		A[++m]=node(1,x,y,n,i);
	}

	//find max
	top=0;
	for(int i=1;i<=n;++i)
	{
		while(top&&p[stk[top]]<=p[i]) top--;
		lef[i]=stk[top]+1; if(!top) lef[i]=1;
		stk[++top]=i;
	}
	top=0;
	for(int i=n;i;--i)
	{
		while(top&&p[stk[top]]<=p[i]) top--;
		rig[i]=stk[top]+1; if(!top) rig[i]=n;
		stk[++top]=i;
	}
	for(int i=1;i<=n;++i) A[++m]=node(0,lef[i],i,rig[i],p[i]),A[++m]=node(0,i+1,i,rig[i],-p[i]);
	
	//find min

	for(int i=1;i<=(n<<2);++i) minv[i]=infl;
	return 0;
}
