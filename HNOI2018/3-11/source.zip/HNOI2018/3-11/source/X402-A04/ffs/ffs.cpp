#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;


const int N=3050;
const int inf=0x3f3f3f3f;
int n,Q,p[N];
int ve[N][N],siz[N];

void wj()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) p[i]=read();
	for(int i=1;i<=n;++i)
	{
		int mx=0,mn=inf;
		for(int j=i;j<=n;++j)
		{
			mx=max(mx,p[j]); mn=min(mn,p[j]);
			if(mx-mn==j-i) ve[j][++siz[j]]=i;
		}
	}
	Q=read();
	for(int cas=1;cas<=Q;++cas)
	{
		int x=read(),y=read(),ans=inf,a,b;
		for(int i=y;i<=n;++i)
		{
			int t=upper_bound(ve[i]+1,ve[i]+1+siz[i],x)-ve[i]-1;
			if(!t) continue;
			if(i-ve[i][t]<ans) ans=i-ve[i][t],a=ve[i][t],b=i;
		}
		printf("%d %d\n",a,b);
	}
	return 0;
}
