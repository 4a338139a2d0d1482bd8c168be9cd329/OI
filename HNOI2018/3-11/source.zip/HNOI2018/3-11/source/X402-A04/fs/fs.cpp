#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=70005;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int k,Q,n,deg[N],p[N];
priority_queue<int,vector<int>,greater<int> >q;
bool vis[N];

void wj()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
}
int main()
{
	wj();
	k=read();
	n=(1<<k)-1;
	for(int i=n;i>1;--i)
	{
		add(i>>1,i);
		deg[i>>1]++; deg[i]++;
	}
	for(int i=1;i<=n;++i) if(deg[i]==1) q.push(i);
	int nn=n; n=0;
	while(nn>2)
	{
		int u=q.top(); q.pop();
		vis[u]=1; nn--;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(vis[v]) continue;
			p[++n]=v;
			deg[v]--;
			if(deg[v]==1) q.push(v);
		}
	}
//	for(int i=1;i<=n;++i) printf("%d ",p[i]); return 0;
	Q=read();
	for(int cas=1;cas<=Q;++cas)
	{
		int a=read(),d=read(),m=read();
		ll sum=0;
		for(int i=0;i<m;++i) sum+=p[a+i*d];
		printf("%lld\n",sum);
	}
	return 0;
}
