#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef double db;
typedef pair<db,db> pdd;

const int N=200050;
const int bas=2001;
struct node
{
	int typ,x,y,k;
	node(int typ=0,int x=0,int y=0,int k=0):typ(typ),x(x),y(y),k(k) { }
}mat[N];
bool operator < (node a,node b) {return a.y-a.k<b.y-b.k;}
int n,sum[4050][4050];

pdd seq[N];
db F(db x)
{
	int tot=0;
	for(int i=1;i<=n;++i) if(mat[i].x-mat[i].k<=x&&x<=mat[i].x+mat[i].k)
	{
		if(!mat[i].typ)
			seq[++tot]=pdd(mat[i].y-mat[i].k,mat[i].y+mat[i].k);
		else 
		{
			db d=fabs(x-mat[i].x);
			seq[++tot]=pdd(mat[i].y-mat[i].k+d,mat[i].y+mat[i].k-d);
		}
	}
	sort(seq+1,seq+1+tot);
	db now=-1e9,ans=0;
	for(int i=1;i<=tot;++i)
	{
		ans+=max(seq[i].se-max(now,seq[i].fi),0.0);
		now=max(now,seq[i].se);
	}
	return ans;
}
inline db simpson(db l,db r)
{
	db mid=(l+r)/2;
	return (F(l)+F(r)+4*F(mid))/6*(r-l);
}
db asr(db l,db r,db eps,db A)
{
	db mid=(l+r)/2;
	db L=simpson(l,mid),R=simpson(mid,r);
	if(fabs(L+R-A)<=15*eps) return L+R-(L+R-A)/15;
	return asr(l,mid,eps/2,L)+asr(mid,r,eps/2,R);
}
db asr(db l,db r)
{
	return asr(l,r,1.465,simpson(l,r));
}

char in[5];
void wj()
{
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	bool allA=1;
	db minx=1e13,maxx=-1e13;
	for(int i=1;i<=n;++i)
	{
		scanf("%s",in);
		int x=read(),y=read(),k=read()/2;
		if(in[0]=='A') mat[i]=node(0,x,y,k);
		else mat[i]=node(1,x,y,k),allA=0;
		minx=min(minx,(db)x-k);
		maxx=max(maxx,(db)x+k);
	}
	if(allA)
	{
		for(int i=1;i<=n;++i)
		{
			int x=mat[i].x,y=mat[i].y,k=mat[i].k;
			sum[x-k+1+bas][y-k+1+bas]++;
			sum[x-k+1+bas][y+k+1+bas]--;
			sum[x+k+1+bas][y-k+1+bas]--;
			sum[x+k+1+bas][y+k+1+bas]++;
		}
		int maxn=bas*2;
		for(int i=1;i<=maxn;++i) for(int j=1;j<=maxn;++j)
			sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
		int ans=0;
		for(int i=1;i<=maxn;++i) for(int j=1;j<=maxn;++j) if(sum[i][j]) ans++;
		printf("%.2lf\n",1.0*ans);
		return 0;
	}
	printf("%.2lf",asr(minx,maxx));
	return 0;
}
