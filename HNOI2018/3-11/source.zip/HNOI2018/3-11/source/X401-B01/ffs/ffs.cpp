#include<cstdio>
#include<iostream>
#include<cstring>
#define neko 100010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define chkmax(a,b) ((a)>(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
static int a[neko],id[neko],pl[neko];
static int n,q,mini,maxi,flag;
int main()
{
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	int x,y,l,r;
	scanf("%d",&n);
	f(i,1,n)scanf("%d",&a[i]),id[a[i]]=i;
	scanf("%d",&q);
	f(i,1,q)
	{
		scanf("%d%d",&x,&y),l=x,r=y;
		//printf("%d %d\n",a[x],a[y]);
		mini=1e9,maxi=0,memset(pl,0,sizeof(pl));
		f(j,x,y)++pl[a[j]],mini=chkmin(mini,a[j]),maxi=chkmax(maxi,a[j]);
		while(1)
		{
			//printf("now=%d %d\n",x,y);
			f(j,l,x-1)++pl[a[j]],mini=chkmin(mini,a[j]),maxi=chkmax(maxi,a[j]);
			f(j,y+1,r)++pl[a[j]],mini=chkmin(mini,a[j]),maxi=chkmax(maxi,a[j]);
			x=l,y=r;
			f(j,mini,maxi)
			{
				if(!pl[j])
				{
					if(id[j]<x)l=chkmin(l,id[j]);if(id[j]>y)r=chkmax(r,id[j]);
					flag=1;
				}
			}if(flag)flag=0;else break;
		}printf("%d %d\n",x,y);
	}return 0;
}
