#include<bits/stdc++.h>
#define neko 5010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define chkmax(a,b) ((a)>(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
int n=12,q=10,a[1000010];
int main()
{
	freopen("ffs.in","w",stdout);
	srand(time(NULL));
	printf("%d\n",n);
	f(i,1,n)a[i]=i;
	std::random_shuffle(a+1,a+n+1);
	f(i,1,n)printf("%d ",a[i]);
	puts("");
	printf("%d\n",q);
	f(i,1,q){int x=rand()%5+1;printf("%d %d\n",x,x+rand()%7);}
	return 0;
}
