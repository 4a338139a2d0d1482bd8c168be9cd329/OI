#include<cstdio>
#include<iostream>
#include<set>
#define neko 1000010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
#define travel(i,u,v) for(register int i=head[u],v=e[i].v;i;i=e[i].next,v=e[i].v)
using std::set;
set<int>s;
int k,q,id,count,last,t,sum;
typedef int arr[neko];
arr book,dgr,prufer,head;
struct node
{
	int v,next;
}e[neko<<1];
void add(int x,int y)
{
	e[++t].v=y;
	e[t].next=head[x];
	head[x]=t;
}
int main()
{
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	int x,y,z;
	scanf("%d%d",&k,&q);
	last=1,count=(1<<k)-1;
	f(i,1,(1<<(k-1))-1)
	{
		add(i,i<<1),add(i<<1,i);
		add(i,(i<<1)+1),add((i<<1)+1,i);
		dgr[i]+=2,++dgr[i<<1],++dgr[(i<<1)+1];
	}
	f(i,1,count)if(dgr[i]==1)s.insert(i),book[i]=1;
	set<int>::iterator it;
	while(id<count-2)
	{
		int u=*(it=s.begin());
		s.erase(u);
		travel(i,u,v)
		{
			if(!book[v])
			{
				--dgr[v];
				prufer[++id]=v;
				if(dgr[v]==1)s.insert(v),book[v]=1;
			}
		}
	}//f(i,1,id)printf("%d ",prufer[i]);
	f(i,1,q)
	{
		scanf("%d%d%d",&x,&y,&z);
		sum=0;f(j,0,z-1)sum+=prufer[x+j*y];
		printf("%d\n",sum);
	}
	return 0;
}
