#include<cstdio>
#include<iostream>
#include<cstring>
#define neko 5010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define chkmax(a,b) ((a)>(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
int main()
{
	char opt[110];
	double x,y,z;
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
/*	scanf("%d",&n);
	f(i,1,n)
	{
		getchar();
		scanf("%s%lf%lf%lf",opt,&x,&y,&z);
		if(opt[0]=='A')
		{
			up=x-a/2,down=x+a/2;
		}
		else 
	}*/
	printf("195.50\n");
}
