#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
#endif
}
const int MAXN=200010;
static int n,e1,e2;
static struct sq
{
	int x,y,a;
	bool vis;
	friend bool operator<(sq a,sq b){return a.x-a.a<b.x-b.a;}
}p[MAXN],q[MAXN];
inline void get(char &x){for(x=0;!isupper(x);x=getchar());}
inline void init()
{
	read(n);
	static char opt;
	Rep(i,1,n)
	{
		get(opt);
		if(opt=='A')read(p[++e1].x),read(p[e1].y),read(p[e1].a),p[e1].a/=2;
		else read(q[++e2].x),read(q[e2].y),read(q[e2].a),q[e2].a/=2;
	}
}
namespace Cheat1
{
	int main()
	{
		int s[2111][2111];
		return 0;
	}
}
typedef pair<double,double>Pr;
namespace Cheat2
{
	static double ans;
	static Pr G[MAXN];
	static int tp;
	inline double f(double pos)
	{
		static double sum,dx;tp=0;
		Rep(i,1,e1)
		{
			if(p[i].x-p[i].a>pos)break;
			if(p[i].x+p[i].a>pos)
				p[i].vis=true,
				G[++tp].first=p[i].y-p[i].a
				,G[tp].second=p[i].y+p[i].a;
		}
		Rep(i,1,e2)
		{
			if(q[i].x-q[i].a>pos)break;
			if(q[i].x+q[i].a>pos)
			{
				q[i].vis=true;
				dx=fabs(q[i].x-pos);
				G[++tp].first=dx+q[i].y-q[i].a;
				G[tp].second=-dx+q[i].y+q[i].a;
			}
		}
		if(!tp)return 0.0;
		sort(G+1,G+tp+1);
		static double r;r=G[1].second;sum=G[1].second-G[1].first;
		Rep(i,2,tp)
		{
			if(G[i].second<=r)continue;
			if(G[i].first<=r)sum+=G[i].second-r;
			else sum+=G[i].second-G[i].first;r=G[i].second;
		}
		return sum;
	}
	inline double g(double l,double r)
	{
		static double mid;mid=(l+r)/2.0;
		return (r-l)*(f(l)+f(r))/2.0;
	}
	const double eps=0.00001;
	double simpson(double l,double r,double mans)
	{
		//cerr<<l<<' '<<r<<endl;
		double mid=(l+r)/2.0,lans=g(l,mid),rans=g(mid,r);
		if(fabs(lans+rans-mans)<=eps)return lans+rans;
		return simpson(l,mid,lans)+simpson(mid,r,rans);
	}
	int main()
	{
		static int l,r;
		sort(p+1,p+e1+1);
		sort(q+1,q+e2+1);
		while(e1|e2)
		{
			l=2000;r=-2000;
			Rep(i,1,e1)Chkmin(l,p[i].x-p[i].a),Chkmax(r,p[i].x+p[i].a);
			Rep(i,1,e2)Chkmin(l,q[i].x-q[i].a),Chkmax(r,q[i].x+q[i].a);
			ans+=simpson(l,r,g(l,r));
			l=0;r=0;
			Rep(i,1,e1)if(!p[i].vis){++l;if(l^i)p[l]=p[i];}
			Rep(i,1,e2)if(!q[i].vis){++r;if(r^i)q[r]=q[i];}
			e1=l;e2=r;
		}
		//printf("%.2lf\n",ans);
		ans*=2;
		ans=(int)(ans+0.4);
		printf("%.2lf\n",ans/2.0);
		return 0;
	}
}
int main()
{
	file();
	init();
	//if(!e2)return Cheat1::main();
	return Cheat2::main();
}

