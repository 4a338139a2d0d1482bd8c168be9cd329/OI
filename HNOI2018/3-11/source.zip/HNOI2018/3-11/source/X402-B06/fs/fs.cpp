#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
#endif
}
static int n,q;
const int MAXN=(1<<17)+7;
static int pru[MAXN],e;
void dfs(int x,int tp)
{
	//cout<<x<<endl;
	if(x>=1<<n)return;
	if(tp)
	{
		dfs(x<<1,0);
		pru[++e]=x<<1|1;
		dfs(x<<1|1,1);
	}
	else dfs(x<<1,0),dfs(x<<1|1,0),pru[++e]=x>>1;
}
int main()
{
	file();
	read(n);read(q);
	dfs(1,1);
	static long long sum;
	static int a,d,m;
	Rep(i,1,q)
	{
		read(a);read(d);read(m);sum=0;
		Rep(i,0,m-1)sum+=pru[i*d+a];
		printf("%lld\n",sum);
	}
	return 0;
}

