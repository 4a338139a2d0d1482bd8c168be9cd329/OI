#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("ffs.in","w",stdout);
#endif
}
const int MAXN=1e5+7;
static int a[MAXN],n=1000,q=1000;
int main()
{
	file();
	static int l;
	cout<<n<<endl;
	Rep(i,1,n)a[i]=i;
	srand(time(NULL));
	static int blo=sqrt(n)+1;
	Rep(i,1,n/blo)
		random_shuffle(a+(i-1)*blo+1,a+i*blo+1);
	Rep(i,1,n)printf("%d ",a[i]);putchar('\n');
	cout<<q<<endl;
	Rep(i,1,q)
	{
		l=rand()%n+1;
		printf("%d %d\n",l,rand()%(n-l+1)+l);
	}
	return 0;
}

