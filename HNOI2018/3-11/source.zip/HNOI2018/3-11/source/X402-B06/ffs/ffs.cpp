#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
#endif
}
const int MAXN=1e5+7;
static int a[MAXN],n,q;
inline void init()
{
	read(n);
	Rep(i,1,n)read(a[i]);
}
vector<int>p[MAXN];
namespace Cheat1
{
	void main()
	{
		static int sz,l,r,ans,A,B;
		Rep(i,1,n)
		{
			l=r=a[i];sz=1;p[i].push_back(i);
			Rep(j,i+1,n)
			{
				Chkmin(l,a[j]);Chkmax(r,a[j]);
				if(++sz==r-l+1)p[i].push_back(j);
			}
		}
		read(q);
		Rep(i,1,q)
		{
			read(l);read(r);ans=n,A=1,B=n;
			Repe(j,l,1)
			{
				if(r-j+1>=ans)break;
				if(lower_bound(p[j].begin(),p[j].end(),r)!=p[j].end())
				{
					sz=*lower_bound(p[j].begin(),p[j].end(),r);
					if(sz-j+1<ans)A=j,B=sz,ans=sz-j+1;
				}
			}
			printf("%d %d\n",A,B);
		}
	}
}
inline void solve()
{
	if(n<=1000)return Cheat1::main();
}
int main()
{
	file();
	init();
	solve();
	return 0;
}

