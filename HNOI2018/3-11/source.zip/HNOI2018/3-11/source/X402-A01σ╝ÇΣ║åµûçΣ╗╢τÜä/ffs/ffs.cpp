#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int a1[1000010],l[1000010],k[1010][1010]; 
int main(){
	int i,j,m,q,n,a,b;
	freopen("ffs.in","r",stdin);
	freopen("ffs.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&a1[i]);
	}
	for(i=1;i<=n;i++){
		int max1=0;
		int min1=1000000010;
	    for(j=i;j<=n;j++){
	    	max1=max(max1,a1[j]);
	    	min1=min(min1,a1[j]);
	    	if(max1-min1+1==j-i+1){l[i]++;k[i][l[i]]=j;}
		}
	}
	for(i=1;i<=n;i++){
	    for(j=1;j<=l[i];j++)
	        printf("%d ",k[i][j]);
	    puts("");
	}
	scanf("%d",&q);
	for(i=1;i<=q;i++){
		int x1,y1,sum=1000001000;
	    scanf("%d%d",&a,&b);
		for(int x=1;x<=a;x++){
			int r=1,l1=l[x],ans=1000000010;
		    while(r<=l1){
		    	int mid=(r+l1)/2;
		    	if(k[x][mid]>=b){ans=min(ans,k[x][mid]);l1=mid-1;}
				else r=mid+1;
			}
			if(ans-x<sum){
				sum=ans-x;
				x1=x;
				y1=ans;
			}
		}
		printf("%d %d\n",x1,y1);
	} 
	return 0;
}
/*
10
2 1 4 3 5 6 7 10 8 9
5
2 3
3 7
4 7
4 8
7 8
*/

