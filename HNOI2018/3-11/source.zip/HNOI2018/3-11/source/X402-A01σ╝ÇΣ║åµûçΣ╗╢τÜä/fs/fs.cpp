#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int n,k,e=0,to1[1000010],next1[1000010],begin1[1000010],a[1000010],c[1000010],l=1;
int dfs(int x){
	if(x>=(1<<n))return 0;
	int h=dfs(x*2);
	if(h){
	    c[l]=x;
	    l++;
	    if(x!=1){
	       c[l]=x;
	       l++;   
	   }
	    dfs(x*2+1);
	}
	return 1;
}
int main(){
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
	int i,j,m,a,d;
	scanf("%d%d",&n,&k);
    dfs(1);	
    for(i=1;i<=k;i++){
    	scanf("%d%d%d",&a,&d,&m);
    	int ans=0; 
    	for(j=a;j<=a+(m-1)*d;j+=d)
    	    ans+=c[j];
    	printf("%d\n",ans);
    }
        
	return 0;
}/*
3 5
1 1 1
2 1 1
3 1 1
4 1 1
5 1 1
*/

