#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int f[4010][4010];
int main(){
	int i,j,k,m,n,x,y,a,minx=100000010,miny=1000000010,maxx=0,maxy=0;
	char c;
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
    scanf("%d",&n);
	for(i=1;i<=n;i++){
		getchar();
	    scanf("%c",&c);
		scanf(" %d %d %d",&x,&y,&a);
		int x1=x-a/2+2000;
		int x2=x+a/2+2000;
		int y1=y-a/2+2000;
		int y2=y+a/2+2000;
		minx=min(x1,minx);
		maxx=max(x2,maxx);
		miny=min(y1,miny);
		maxy=max(y2,maxy); 
		f[x1][y1]+=1;
		f[x1][y2]-=1;
		f[x2][y1]-=1;
		f[x2][y2]+=1;
	}
	int ans=0;
	for(i=minx;i<=maxx;i++)
	    for(j=miny;j<=maxy;j++)
	    f[i][j]+=f[i-1][j];
   for(i=minx;i<=maxx;i++)
       for(j=miny;j<=maxy;j++)
          f[i][j]+=f[i][j-1];
   for(i=minx;i<=maxx;i++)
       for(j=miny;j<=maxy;j++)
       if(f[i][j])
           ans+=1;
    printf("%d\n",ans);
			
	return 0;
}/*
4
A -7 10 4
A -6 6 6
A -2 5 8
A 3 9 2
*/
