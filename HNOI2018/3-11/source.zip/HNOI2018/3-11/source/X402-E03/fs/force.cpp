#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1<<20 ;
int n, m, k, deg[maxn+5], p[maxn] ;
bool inq[maxn] ;
priority_queue <int, vector <int>, greater<int> > Q ;
int Begin[maxn+5], To[maxn<<1|1], Next[maxn<<1|1], e ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "fs.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;
#endif
	int i, x, u, _, a, d ;
	Read(k), Read(_) ;
	n = (1<<k)-1 ;
	for ( i = 1<<(k-1) ; i <= n ; i ++ )
		deg[i] = 1, Q.push(i), inq[i] = 1, add(i, i>>1) ;
	for ( i = (1<<(k-1))-1 ; i > 1 ; i -- )
		deg[i] = 3, add(i, i<<1), add(i, i<<1|1), add(i, i>>1) ;
	deg[1] = 2 ;
	add(1, 2), add(1, 3) ;
	while (!Q.empty()) {
		x = Q.top() ;
		Q.pop() ;
		for ( i = Begin[x] ; i ; i = Next[i] ) {
			u = To[i] ;
			if (!inq[u]) {
				p[++m] = u ;
				-- deg[u] ;
				if (deg[u] == 1) {
					Q.push(u) ;
					inq[u] = 1 ;
				}
			}
		}
	}
	-- m ;
	int ans ;
	while (_--) {
		ans = 0 ;
		Read(a), Read(d), Read(x) ;
		for ( i = 0 ; i < x ; i ++ )
			ans += p[a+i*d] ;
		printf ( "%d\n", ans ) ;
	}
	//cerr << "Force " << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
