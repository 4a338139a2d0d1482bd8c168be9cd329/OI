#include <bits/stdc++.h>
using namespace std ;
int main() {
	srand(time(0)) ;
	freopen ( "fs.in", "w", stdout ) ;
	int i, n, k, a, d, m, _ ;
	k = rand()%20+1 ;
	k = 30 ;
	n = (1<<k)-3 ;
	_ = min(300, n-2) ;
	printf ( "%d %d\n", k, _ ) ;
	while (_--) {
		a = rand()%(n/2)+1 ;
		d = rand()%(n-a+1)+1 ;
		m = rand()%((n-a+1)/d) ;
		//a = d = 1, m = n ;
		printf ( "%d %d %d\n", a, d, m ) ;
	}
	return 0 ;
}
