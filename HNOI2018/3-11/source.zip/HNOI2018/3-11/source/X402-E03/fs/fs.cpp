#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
LL n, m, k ;
bool have ;
LL Log ( LL x ) { return 1+(LL)floor(1.0*log(x)/log(2)) ; }
LL solve ( LL dep, LL x, bool fa ) {
	//printf ( "solve %d %d %d\n", dep, x, fa ) ;
	LL t = (1<<(dep-1))-1, Lg ;
	if (fa) {
		if (x+1 == (1<<dep)) {
			have = fa ;
			t = 1 ;
		}
		else if (x <= t) {
			//puts("Left") ;
			t = solve(dep-1, x, 1) ;
			Lg = Log(t) ;
			//printf ( "Log[%d]=%d\n", t, Lg ) ;
			t ^= 1<<Lg ;
			t ^= 1<<(Lg-1) ;
		} else {
			//puts("Right") ;
			t = solve(dep-1, x-t, 1) ;
			Lg = Log(t) ;
			t ^= 1<<Lg ;
		}
	} else {
		if (x == t+1) {
			have = fa ;
			t = 1 ;
		} else if (x <= t) {
			//puts("Left") ;
			t = solve(dep-1, x, 1) ;
			Lg = Log(t) ;
			t ^= 1<<Lg ;
			t ^= 1<<(Lg-1) ;
		} else {
			//puts("Right") ;
			t = solve(dep-1, x-t-1, 0) ;
			Lg = Log(t) ;
			t ^= 1<<Lg ;
		}
	}
	//printf ( "solve %d %d %d = %d\n", dep, x, fa, t ) ;
	return t ;
}
int main() {
	freopen ( "fs.in", "r", stdin ) ;
	freopen ( "fs.out", "w", stdout ) ;
	LL i, a, d, _, ans ;
	Read(k), Read(_) ;
	while (_--) {
		ans = 0 ;
		Read(a), Read(d), Read(m) ;
		for ( i = 0 ; i < m ; i ++ ) {
			//printf ( "calc %d\n", a+i*d ) ;
			n = solve(k, a+i*d, 0) ;
			//printf ( "ans = %d\n", n ) ;
			if (have) n >>= 1 ;
			else n = n<<1|1 ;
			ans += n ;
		}
		printf ( "%lld\n", ans ) ;
	}
	//cerr << "Solve " << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
