#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1e5+5, inf = 0x3f3f3f3f ;
void chkmin ( int &a, int b ) { a = a<b? a:b ; }
void chkmax ( int &a, int b ) { a = a>b? a:b ; }
int n, m, a[maxn] ;
set <int> st[maxn] ;
set <int> :: iterator it ;
int main() {
	freopen ( "ffs.in", "r", stdin ) ;
	freopen ( "ffs.out", "w", stdout ) ;

	int i, j, Max, Min, _, len, lim, ans ;
	Read(n) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(a[i]), st[i].insert(n+1) ;
	for ( i = 1 ; i <= n ; i ++ ) {
		Min = inf, Max = -1, len = 0 ;
		for ( j = i ; j <= n ; j ++ ) {
			chkmin(Min, a[j]) ;
			chkmax(Max, a[j]) ;
			len ++ ;
			if (Max-Min+1 == len)
				st[i].insert(j) ;
		}
	}
	int x, y, u, v, A, B ;
	Read(_) ;
	while (_--) {
		Read(x), Read(y) ;
		ans = inf ;
		for ( i = x, lim = 1 ; i >= lim ; i -- ) {
			it = st[i].lower_bound(y) ;
			u = *it ;
			if (u >= y && u <= n) {
				v = u-i+1 ;
				if (v <= ans) {
					A = i, B = u ;
					ans = v ;
					chkmax(lim, y-v+1) ;
				}
			}
		}
		printf ( "%d %d\n", A, B ) ;
	}
	return 0 ;
}
