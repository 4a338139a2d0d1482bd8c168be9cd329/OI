#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int N = 1000 ;
int g[N*4+100][N*4+100], n, m ;
char tp[5] ;
void check() {
	int i, j, ans = 0 ;
	//for ( j = 8 ; j >= -2; j --, puts("") )
	//	for ( i = -2; i <= 8 ; i ++ )
	//		printf ( "%02d ", g[i+2000][j+2000] ) ;
	
	for ( i = 0 ; i <= 4000 ; i ++ )
		for ( j = 0 ; j <= 4000 ; j ++ )
			ans += __builtin_popcount(g[i][j]) ;
	printf ( "%.2lf\n", ans/4.0 ) ;
}
void Force() {
	int _, x, y, i, j, tx, ty, d ;
	Read(_) ;
	while (_--) {
		scanf ( "%s", tp ) ;
		Read(x), Read(y), Read(d) ;
		x += 2000, y += 2000 ;
		if (tp[0] == 'A') {
			x -= d/2, y -= d/2 ;
			for ( i = x+d-1 ; i >= x ; i -- )
				for ( j = y+d-1 ; j >= y ; j -- )
					g[i][j] |= 15 ;
		} else {
			d >>= 1 ;
			x -= d ;
			for ( tx = i = x+d-1, ty = y+d-1 ; i >= x ; i --, tx --, ty -- ) {
				g[tx][ty] |= 6 ;
				for ( j = ty-1 ; j >= y ; j -- )
					g[i][j] |= 15 ;
			}
			for ( tx = i = x+d-1, ty = y-d ; i >= x ; i --, tx --, ty ++ ) {
				g[tx][ty] |= 12 ;
				for ( j = ty+1 ; j < y ; j ++ )
					g[i][j] |= 15 ;
			}
			
			x += d ;
			for ( tx = i = x+d-1, ty = y ; i >= x ; i --, tx --, ty ++ ) {
				g[tx][ty] |= 3 ;
				for ( j = y ; j < ty ; j ++ )
					g[i][j] |= 15 ;
			}
			for ( tx = i = x+d-1, ty = y-1 ; i >= x ; i --, tx --, ty -- ) {
				g[tx][ty] = 9 ;
				for ( j = y-1 ; j > ty ; j -- )
					g[i][j] |= 15 ;
			}
		}
	}
	check() ;
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "skss.in", "r", stdin ) ;
	freopen ( "skss.out", "w", stdout ) ;
#endif
	Force() ;
	return 0 ;
}
