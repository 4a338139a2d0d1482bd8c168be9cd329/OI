//2018-3-11
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (40000 + 5)

int dep, ln, dig[N], line[N];
priority_queue<int, vector<int>, greater<int> > q;

void Init(){
	int ed = (1 << dep) - 1, now, f;
	For(i, 1, ed) ++dig[i >> 1];
	For(i, 1, ed) if(!dig[i]) q.push(i);

	while(!q.empty()){
		now = q.top(); q.pop();
		line[++ln] = f = now >> 1;

		--dig[f];
		if(!dig[f]) q.push(f);
	}
	ln -= 3;
}

int main(){
	freopen("fs.in", "r", stdin);
	freopen("fs.out", "w", stdout);

	int Q, a, d, m;

	scanf("%d%d", &dep, &Q);
	Init();

	while(Q --){
		scanf("%d%d%d", &a, &d, &m);

		long long ans = 0;
		while(m --){
			ans += line[a]; a += d;
		}
		printf("%lld\n", ans);
	}
	
	return 0;
}
