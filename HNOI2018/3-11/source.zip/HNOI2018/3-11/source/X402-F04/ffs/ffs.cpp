//2018-3-11
//miaomiao
//Read()
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (1000 + 5)

int n, Q, a[N];
bool good[N][N];

void Prepare(){
	int mx, mn;

	For(l, 1, n){
		good[l][l] = true;
		mx = mn = a[l];
		For(r, l + 1, n){
			mx = max(mx, a[r]), mn = min(mn, a[r]);
			if(mx - mn == r - l) good[l][r] = true;
		}
	}
}

int main(){
	freopen("ffs.in", "r", stdin);
	freopen("ffs.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &a[i]);
	Prepare();

	int x, y;

	scanf("%d", &Q);
	while(Q --){
		scanf("%d%d", &x, &y);
		
		int ans = n, al, ar;
		For(l, 1, x) For(r, y, n)
			if(good[l][r] && ans > r - l) ans = r - l, al = l, ar = r;
		printf("%d %d\n", al, ar);
	}

	return 0;
}
