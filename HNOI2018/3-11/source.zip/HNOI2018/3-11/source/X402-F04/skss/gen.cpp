//2018-3-11
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int main(){
	freopen("skss.in", "w", stdout);
	
	int n = 1000;

	srand(time(NULL));
	printf("%d\n", n);
	For(i, 1, n){
		int op1 = rand() % 2, op2 = rand() % 2;
		if(!op1) op1 = -1; if(!op2) op2 = -1;
		int t1 = rand() % 1000 + 1,
			t2 = rand() % 1000 + 1,
			t3 = rand() % 1000 + 1;
		if(t3 & 1) ++t3;
		if(t3 > 1000) t3 -= 2;

		printf("A %d %d %d\n", t1 * op1, t2 * op2, t3);
	}

	return 0;
}
