//2018-3-11
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (4000 + 5)
const int A = 2001;

int n, sum1[N][N], sum2[N][N];
bool f[N][N], g[N][N][4];

void Work(){
	For(i, 1, 4002) For(j, 1, 4002){
		sum1[i][j] += sum1[i - 1][j] + sum1[i][j - 1] - sum1[i - 1][j - 1];
		sum2[i][j] += sum2[i - 1][j - 1] + sum2[i - 1][j + 1];
		if(i > 1) sum2[i][j] -= sum2[i - 2][j];
	}

	For(i, 1, 4002) For(j, 1, 4002){
		if(sum1[i][j]) f[i][j] = true;
		if(sum2[i][j])
			g[i][j][0] = g[i - 1][j][3] = g[i][j - 1][2] = g[i - 1][j - 1][1] = true;
	}
}

int main(){
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);

	char op[5];
	int x, y, z;

	scanf("%d", &n);
	For(i, 1, n){
		scanf("%s%d%d%d", op, &x, &y, &z);
		x += A, y += A, z >>= 1;

		if(op[0] == 'A'){
			sum1[x - z][y - z]++; sum1[x - z][y + z]--;
			sum1[x + z][y - z]--; sum1[x + z][y + z]++;
		}else{
			sum2[x - z + 1][y]++; sum2[x + 1][y + z]--;
			sum2[x + 1][y - z]--; sum2[x + z + 1][y]++;
		}
	}
	Work();

	int a, b, c, d;
	double ans = 0;
	For(i, 1, 4002) For(j, 1, 4002){
		a = 0, b = 0, c = 0, d = 0;
		if(f[i][j]){ans += 1.0; continue;}
		if(g[i][j][0]) c = d = 1; if(g[i][j][1]) a = b = 1;
		if(g[i][j][2]) a = d = 1; if(g[i][j][3]) b = c = 1;
		ans += (a + b + c + d) * 0.25;
	}

	printf("%.2lf\n", ans);

	return 0;
}
