//2018-3-11
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (4000 + 5)
#define M (20000000 + 5)

const int A = 2001;

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0'); chr = getchar();
	}
}

struct node{
	int ls, rs, w;
};
int ql, qr, root[N];

namespace SegTree{
	int hn, tag[M];
	node h[M];

#define lc h[o].ls
#define rc h[o].rs
#define mid ((L + R) >> 1)
	
	void PutTag(int &o, int L, int R, int v){
		if(!o) o = ++hn;
		h[o].w += (R - L + 1) * v; tag[o] += v;
	}
	
	void Pushdown(int o, int L, int R){
		PutTag(lc, L, mid, tag[o]);
		PutTag(rc, mid + 1, R, tag[o]);
		tag[o] = 0;
	}

	void Modify(int &o, int L, int R, int av){
		if(!o) o = ++hn;
		if(ql <= L && qr >= R){
			PutTag(o, L, R, av); return;
		}

		Pushdown(o, L, R);
		if(ql <= mid) Modify(lc, L, mid, av);
		if(qr > mid) Modify(rc, mid + 1, R, av);
		h[o].w = h[lc].w + h[rc].w;
	}

	int Query(int o, int L, int R, int p){
		if(!h[o].w) return 0;

		Pushdown(o, L, R);
		if(L == R){
			if(h[o].w > 0) return 1;
			if(h[o].w < 0) return -1;
			return 0;
		}
		if(p <= mid) return Query(lc, L, mid, p);
		return Query(rc, mid + 1, R, p);
	}
#undef lc
#undef rc
#undef mid
};
using namespace SegTree;

void Add(int x, int av){
	while(x <= 4001){
		Modify(root[x], 1, 4001, av);
		x += x & (-x);
	}
}

int Sum(int x, int y){
	int ret = 0;

	while(x > 0){
		ret += Query(root[x], 1, 4001, y); x -= x & (-x);
	}
	return ret > 0? 1: 0;
}

int al, ar, bl, br;
void Solve(){
	int ans;
	For(i, al, ar) For(j, bl, br) ans += Sum(i, j);
	printf("%d.00\n", ans);
}

int main(){
	freopen("skss.in", "r", stdin);
	freopen("skss.out", "w", stdout);
	
	int n, x, y, d;
	char op[5];

	Read(n);

	al = bl = 1e9, ar = br = 0;
	while(n --){
		scanf("%s", op);
		Read(x), Read(y), Read(d);
		x += A, y += A;

		ql = y - (d >> 1), qr = y + (d >> 1) - 1;
		int l = x - (d >> 1), r = x + (d >> 1) - 1;
	
		al = min(al, l), ar = max(ar, r);
		bl = min(bl, ql), br = max(br, qr);
		Add(l, 1);	Add(r + 1, -1);
	}
	Solve();

	return 0;
}
