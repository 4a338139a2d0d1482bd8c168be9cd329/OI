#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <set>
#include      <map>
using namespace std;

const int N=200005,M=3205;

int n,s1[M*2][M*2],s2[M*2][M*2];

void ins(int s[M*2][M*2],int x,int y,int d)
{
	x-=d/2;y-=d/2;s[x+d+M][y+d+M]++;s[x+M][y+M]++;s[x+d+M][y+M]--;s[x+M][y+d+M]--;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("skss.in","r",stdin);
	freopen("skss.out","w",stdout);
#endif
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		char a;int x,y,d;
		scanf(" %c %d %d %d",&a,&x,&y,&d);
		if(a=='A')
			ins(s1,x,y,d);
		else
			ins(s2,x-y,x+y,d);
	}
	for(int i=0;i<M*2;i++)
		for(int j=0;j<M*2;j++)
		{
			if(i)
				s1[i][j]+=s1[i-1][j],s2[i][j]+=s2[i-1][j];
			if(j)
				s1[i][j]+=s1[i][j-1],s2[i][j]+=s2[i][j-1];
			if(i&&j)
				s1[i][j]-=s1[i-1][j-1],s2[i][j]-=s2[i-1][j-1];
		}
	int Ans=0;
	for(int i=-1600;i<=1600;i++)
		for(int j=-1600;j<=1600;j++)
			if(s1[i+M][j+M])
				Ans+=4;
			else
			{
				int x=i-j,y=i+j;
				if(s2[x+M][y+M])
					Ans++;
				if(s2[x+M][y+M+1])
					Ans++;
				if(s2[x+M-1][y+M])
					Ans++;
				if(s2[x+M-1][y+M+1])
					Ans++;
			}
	printf("%.2lf\n",Ans/4.0);
	return 0;
}

