#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <set>
#include      <map>
using namespace std;

typedef long long LL;
const int N=1<<18;

int the=2,k,q,n,m,pos[N],id[N],len,st[N],Now,bid[N],bk[N];
LL sumid[N],sumk[N];

void work(int i,int type)
{
	if(i*2>=(1<<k))
		return;
	if(type==2)
	{
		if(i*2>=(1<<k))
			return;
		if(i*2*2<(1<<k))
			work(i*2,2);
		pos[++n]=++Now;id[n]=i;
		if(i*2*2<(1<<k))
			work(i*2+1,2);
		pos[++n]=++Now;id[n]=i;
		return;
	}
	if(i*2>=(1<<the)&&type==0)
	{
		m++;st[m]=Now+1;Now+=len;
	}
	else if(i*2<(1<<the))
		work(i*2,0);
	else
		work(i*2,2);
	pos[++n]=++Now;id[n]=i;
	if(type==1)
		pos[++n]=++Now,id[n]=i*2+1;
	if(i*2+1>=(1<<the)&&type==0)
	{
		m++;st[m]=Now+1;Now+=len;
	}
	else
		work(i*2+1,type);
	if(type==0)
		pos[++n]=++Now,id[n]=i;
}

void block(int x,int a)
{
	if(x*2*2<(1<<k))
		block(x*2,a*2);
	Now++,bid[Now]=x,bk[Now]=a;
	if(x*2*2<(1<<k))
		block(x*2+1,a*2);
	Now++,bid[Now]=x,bk[Now]=a;
}

LL askk(int a,int d,int t,int st,int k)
{
	int ed=st+len-1,las=a+(t-1)*d;
	if(a>ed||las<st)
		return 0;
	if(a>=st)
	{
		LL sum=0;
		for(int i=a;i<=las&&i<=ed;i+=d)
			sum+=bid[i-st+1]+bk[i-st+1]*k;
		return sum;
	}
	if(las<=ed)
	{
		LL sum=0;
		for(int i=las;i>=a&&i>=st;i-=d)
			sum+=bid[i-st+1]+bk[i-st+1]*k;
		return sum;
	}
	int pos=ed-ed%d+a%d+d;
	while(pos>ed)
		pos-=d;
	if(pos<st)
		return 0;
	return sumid[pos-st+1]+sumk[pos-st+1]*k;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("fs.in","r",stdin);
	freopen("fs.out","w",stdout);
#endif
	cin>>k>>q;
	the=15;
	if(k>the)
		len=(1<<(k-the))-2;
	work(1,1);
	Now=0;block(1<<the,1);
	while(q--)
	{
		int a,d,t;
		scanf("%d%d%d",&a,&d,&t);
		LL Ans=0;
		for(int i=1;i<=n;i++)
			if((pos[i]-a)%d==0&&(pos[i]-a)/d<t&&pos[i]>=a)
				Ans+=id[i];
		for(int i=1;i<=len;i++)
		{
			sumid[i]=bid[i],sumk[i]=bk[i];
			if(i>d)
				sumid[i]+=sumid[i-d],sumk[i]+=sumk[i-d];
		}
		for(int i=1;i<=m;i++)
			Ans+=askk(a,d,t,st[i],i-1);
		printf("%lld\n",Ans);
	}
	return 0;
}

