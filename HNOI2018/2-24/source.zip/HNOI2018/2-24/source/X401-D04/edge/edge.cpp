#include<bits/stdc++.h>
using namespace std;
const int maxn=(int)1e3+10;
int f[maxn][maxn],du[maxn];
int n,m,k;
int check(){
	int cnt=0;
	memset(du,0,sizeof(du));
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=n;++j){
			if(f[i][j]){
				++du[i];
				if(i<j)++cnt;
			}
		}
	}
	if(cnt!=k)return 0;
	for(register int i=1;i<=m;++i)if(!(du[i]&1))return 0;
	for(register int i=m+1;i<=n;++i)if(du[i]&1)return 0;
	return 1;
}
int ans;
void dfs(int x,int y){
	if(x==n&&y==n){
		ans+=check();
		return;
	}if(x==y){
		dfs(1,y+1);
		return;
	}f[y][x]=f[x][y]=1,dfs(x+1,y),f[y][x]=f[x][y]=0,dfs(x+1,y);
}
int main(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	cin>>n>>m>>k;
	dfs(1,1);
	cout<<ans<<endl;
	return 0;
}
