#include<bits/stdc++.h>
using namespace std;
const int maxn=150+10;
struct edge{
	int to,nxt,bh;
}e[maxn<<1];
int n,f[maxn],siz[maxn];
struct fuck{
	int co,bh;
}d[maxn];
int head[maxn],sz;
inline int read(){
    int X=0,w=1;
    char ch=getchar();
    while(ch<'0'||ch>'9') {if(ch=='-') w=-1;ch=getchar();}
    while(ch>='0'&&ch<='9') X=(X<<3)+(X<<1)+ch-'0',ch=getchar();
    return X*w;
}
inline void added(int x,int y,int z){
	e[++sz].to=y,e[sz].bh=z,e[sz].nxt=head[x],head[x]=sz;
}
void dfs1(int x){
	for(int i=head[x];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==f[x])continue;
		d[v].bh=e[i].bh,f[v]=x,dfs1(v),++siz[x];
	}return;
}
int vis[maxn],viss[maxn];
struct node{
	int w,bh,col;
    bool operator <(const node b)const{  
        return this->w>b.w;  
    }
};
vector<node>v[maxn][maxn];
priority_queue<node>q[maxn];
inline void dfs2(int x){
	for(register int i=head[x];i;i=e[i].nxt){
		int v=e[i].to;
		if(v!=f[x])dfs2(v);
	}
	int tt=0,ww=0;
	if(x!=1)for(register int i=1;i<=n;++i){
		ww=i,tt=0;
		memset(viss,0,sizeof(viss));
		memset(vis,0,sizeof(vis));
		vis[i]=1;
		priority_queue<node>qq;
		qq=q[x];
		while(tt<siz[x]){
			node u=qq.top();qq.pop();
			if(!vis[u.col]&&!viss[u.bh])v[x][i].push_back(u),++tt,ww+=u.w,vis[u.col]=1,viss[u.bh]=1;
		}node u;
		u.bh=x;u.w=ww;u.col=i;q[f[x]].push(u);
	}else{
		static int tt=0,ww=0;
		memset(vis,0,sizeof(vis));
		memset(viss,0,sizeof(viss));
		priority_queue<node>qq;
		qq=q[x];
		while(tt<siz[x]){
			node u=qq.top();qq.pop();
			if(!vis[u.col]&&!viss[u.bh])v[x][0].push_back(u),++tt,ww+=u.w,vis[u.col]=1,viss[u.bh]=1;
		}printf("%d\n",ww);return;
	}return;
}
inline void dfs3(int x){
	for(register int i=0;i<v[x][d[x].co].size();++i){
		node u=v[x][d[x].co][i];
		d[u.bh].co=u.col;
		dfs3(u.bh);
	}
}
bool cmp(fuck xx,fuck yy){
	return xx.bh<yy.bh;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int x,y;cin>>n;
	for(register int i=1;i<n;++i)x=read(),y=read(),added(x,y,i),added(y,x,i);
	dfs1(1),dfs2(1),dfs3(1);
	sort(d+2,d+n+1,cmp);
	for(register int i=2;i<=n;++i)printf("%d ",d[i].co);
	return 0;
}
