#include<bits/stdc++.h>
using namespace std;
int n,m;
const int maxn=(int)1e3+10,mod=998244353;
int table[10][7]={
	{0,0,0,0,0,0,0},
	{0,0,2,3,4,5,6},
	{0,0,2,9,16,25,36},
	{0,0,2,21,64,125,216},
	{0,0,2,45,232,625,1296},
	{0,0,2,93,784,3005,7776},
	{0,0,2,219,2656,13825,45936},
	{0,0,2,507,9496,63845,264816}}; 
int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	cin>>n>>m;
	if(m==2){
		printf("2\n");
		return 0;
	}
	cout<<table[n][m]<<endl;
	return 0;
}
