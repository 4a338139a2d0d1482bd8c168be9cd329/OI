#include<bits/stdc++.h>
using namespace std;

const int maxn=1e3+10;
int n,m,k,ans;
bool g[maxn][maxn];

void dfs(int x,int y,int e){
	if(e>k)
		return;
	if(y>n)
		++x,y=x+1;
	if(y>n){
		if(e!=k)
			return;
		for(int i=1;i<=n;++i){
			int cnt=0;
			for(int j=1;j<=n;++j)
				if(g[i][j])
					++cnt;
			if(i<=m&&cnt%2==0)
				return;
			if(i>m&&cnt%2==1)
				return;
		}
		++ans;
		return;
	}
	g[x][y]=g[y][x]=true;
	dfs(x,y+1,e+1);
	g[x][y]=g[y][x]=false;
	dfs(x,y+1,e);
}

int main(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(m&1){
		puts("0");
		return 0;
	}
	dfs(1,2,0);
	printf("%d\n",ans);
	return 0;
}
