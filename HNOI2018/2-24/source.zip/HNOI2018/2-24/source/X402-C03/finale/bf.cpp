#include<bits/stdc++.h>
using namespace std;

const int maxn=2e3+10,mod=998244353;
int n,m,a[maxn],ans;

void dfs(int pos){
	if(pos>=n){
		for(int i=0;i<n;++i){
			for(int j=0;j<m;++j)
				for(int k=j+1;k<m;++k)
					if(a[(i+j)%n]==a[(i+k)%n])
						goto hell;
			return;
hell:
			;
		}
		++ans;
		return;
	}
	for(int i=1;i<=m;++i){
		a[pos]=i;
		dfs(pos+1);
	}
}

int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.txt","w",stdout);
	scanf("%d%d",&n,&m);
	dfs(0);
	printf("%d\n",ans);
	return 0;
}
