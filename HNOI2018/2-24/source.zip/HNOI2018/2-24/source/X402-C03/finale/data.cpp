#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("finale.in","w",stdout);
	srand(time(0));
	int n=rand()%7+1,m=rand()%6+1;
	cerr<<time(0)<<endl;
	printf("%d %d\n",n,m);
	return 0;
}
