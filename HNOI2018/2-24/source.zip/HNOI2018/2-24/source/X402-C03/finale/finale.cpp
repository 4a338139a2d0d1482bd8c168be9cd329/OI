#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1236,mod=998244353;
int n,m,ans;
int cnt;
map<vector<int>,int> mmp;
vector<int> tmp,xxx[maxn];

struct matrix{
	ll x[maxn][maxn];
}base,res,temp;
inline void mul(matrix&a,matrix&b){
	memset(temp.x,0,sizeof(temp.x));
	for(int i=0;i<cnt;++i)
		for(int k=0;k<cnt;++k)
			if(a.x[i][k])
				for(int j=0;j<cnt;++j)
					(temp.x[i][j]+=a.x[i][k]*b.x[k][j])%=mod;
	a=temp;
}
inline void fpow(ll n){
	for(int i=0;i<cnt;++i)
		res.x[i][i]=1;
	for(;n;n>>=1,mul(base,base))
		if(n&1ll)
			mul(res,base);
}

vector<int> get(vector<int> now){
	while(now.size()>m)
		now.erase(now.begin());
	for(int i=now.size()-1;~i;--i)
		for(int j=i+1;j<now.size();++j)
			if(now[i]==now[j]){
				for(int k=0;k<=i;++k)
					now.erase(now.begin());
				return now;
			}
	return now;
}
void dfs(int pos){
	if(pos==m){
		for(int i=0;i<m;++i)
			for(int j=i+1;j<m;++j)
				if(tmp[i]==tmp[j])
					goto hell;
		return;
hell:
		vector<int> now=get(tmp);
		if(mmp.count(now))
			return;
		xxx[cnt]=now;
		mmp[now]=cnt;
		++cnt;
		return;
	}
	for(int i=1;i<=m;++i){
		tmp.push_back(i);
		dfs(pos+1);
		tmp.pop_back();
	}
}
namespace bf{
	int a[maxn],ans;

	void dfs(int pos){
		if(pos>=n){
			for(int i=0;i<n;++i){
				for(int j=0;j<m;++j)
					for(int k=j+1;k<m;++k)
						if(a[(i+j)%n]==a[(i+k)%n])
							goto hell;
				return;
		hell:
				;
			}
			++ans;
			return;
		}
		for(int i=1;i<=m;++i){
			a[pos]=i;
			dfs(pos+1);
		}
	}
	int main(){
		dfs(0);
		printf("%d\n",ans);
		exit(0);
	}
}
namespace plan{
	int dpp[maxn];
	int dp[2][maxn];
	vector<int> g[maxn];

	void run(int beg){
		memset(dp,0,sizeof(dp));
		dp[0][beg]=1;
		for(int i=0;i<n;++i){
			memset(dp[i&1^1],0,sizeof(dp[i&1^1]));
			for(int j=0;j<cnt;++j)
				for(int k=0;k<g[j].size();++k)
					(dp[i&1^1][g[j][k]]+=dp[i&1][j])%=mod;
		}
		dpp[xxx[beg].size()]=dp[n&1][beg];
	}
	int main(){
		for(int i=0;i<cnt;++i)
			for(int j=1;j<=m;++j){
				tmp=xxx[i];
				tmp.push_back(j);
				tmp=get(tmp);
				if(mmp.count(tmp))
					g[i].push_back(mmp[tmp]);
			}
		memset(dpp,-1,sizeof(dpp));
		for(int i=0;i<cnt;++i){
			if(dpp[xxx[i].size()]==-1)
				run(i);
			(ans+=dpp[xxx[i].size()])%=mod;
		}
		printf("%d\n",ans);
		exit(0);
	}
}

int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	scanf("%d%d",&n,&m);
//	if(n<=7)
//		bf::main();
	dfs(0);
	if(m==6)
		plan::main();
	for(int i=0;i<cnt;++i)
		for(int j=1;j<=m;++j){
			tmp=xxx[i];
			tmp.push_back(j);
			tmp=get(tmp);
			if(mmp.count(tmp))
				base.x[i][mmp[tmp]]=1;
		}
	fpow(n);
	for(int i=0;i<cnt;++i)
		ans=(ans+res.x[i][i])%mod;
	printf("%d\n",ans);
	return 0;
}
