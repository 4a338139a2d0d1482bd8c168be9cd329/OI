#include<bits/stdc++.h>
using namespace std;

const int maxn=150+10,inf=1e9;
int n,u[maxn],v[maxn];
vector<int> g[maxn];
bool vis[maxn][maxn];

namespace bf{
	int ans=inf;
	int tmp[maxn],res[maxn];

	int guess(int pos){
		int res=0;
		for(int i=pos;i<n;++i)
			for(int j=1;;++j)
				if(!vis[u[i]][j]&&!vis[v[i]][j]){
					res+=j;
					break;
				}
		return res;
	}
	void dfs(int pos,int now){
		if(now+guess(pos)>=ans)
			return;
		if(pos==n){
			ans=now;
			for(int i=1;i<pos;++i)
				res[i]=tmp[i];
			return;
		}
		for(int i=1;i<=n;++i){
			if(vis[u[pos]][i]||vis[v[pos]][i])
				continue;
			vis[u[pos]][i]=vis[v[pos]][i]=true;
			tmp[pos]=i;
			dfs(pos+1,now+i);
			vis[u[pos]][i]=vis[v[pos]][i]=false;
		}
	}
	int main(){
		dfs(1,0);
		printf("%d\n",ans);
		for(int i=1;i<n;++i)
			printf("%d ",res[i]);
		puts("");
	}
}
namespace hail_random{
	int ans=inf,res[maxn];
	int tmp[maxn],vis[maxn];
	int a[maxn];

	void solve(){
		memset(tmp,0,sizeof(tmp));
		int rest=n-1,cost=0,now=0;
		while(rest){
			random_shuffle(a+1,a+n);
			++now;
			memset(vis,0,sizeof(vis));
			for(int i=n-1;i;--i){
				int x=a[i];
				if(!tmp[x]&&!vis[u[x]]&&!vis[v[x]]){
					tmp[x]=now;
					vis[u[x]]=vis[v[x]]=true;
					cost+=now;
					--rest;
				}
			}
		}
		if(cost<ans){
			ans=cost;
			for(int i=1;i<n;++i)
				res[i]=tmp[i];
		}
	}
	int main(){
		for(int i=1;i<=n-1;++i)
			a[i]=i;
		srand(time(NULL));
		while(clock()<0.48*CLOCKS_PER_SEC)
			solve();
		printf("%d\n",ans);
		for(int i=1;i<n;++i)
			printf("%d ",res[i]);
		puts("");
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<n;++i){
		scanf("%d%d",&u[i],&v[i]);
		g[u[i]].push_back(v[i]);
		g[v[i]].push_back(u[i]);
	}
	if(n>10)
		hail_random::main();
	else
		bf::main();
	return 0;
}
