#include<bits/stdc++.h>
using namespace std;

const int maxn=150+10,inf=1e9;
int n,u[maxn],v[maxn];
vector<int> g[maxn];
bool vis[maxn][maxn];

namespace bf{
	int ans=inf;
	int tmp[maxn],res[maxn];
	void dfs(int pos,int now){
		if(now>=ans)
			return;
		if(pos==n){
			ans=now;
			for(int i=1;i<pos;++i)
				res[i]=tmp[i];
			return;
		}
		for(int i=1;i<=n;++i){
			if(vis[u[pos]][i]||vis[v[pos]][i])
				continue;
			vis[u[pos]][i]=vis[v[pos]][i]=true;
			tmp[pos]=i;
			dfs(pos+1,now+i);
			vis[u[pos]][i]=vis[v[pos]][i]=false;
		}
	}
	int main(){
		dfs(1,0);
		printf("%d\n",ans);
		for(int i=1;i<n;++i)
			printf("%d ",res[i]);
		puts("");
	}
}
namespace hail_random{
	int main(){
	}
}
namespace search{
	int ans=inf;
	int dp[maxn][maxn];

	void guess(){
	}
	void dfs(int pos,int now){
	}
	int main(){
		dfs(1,0);
		printf("%d\n",ans);
		puts("");
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.txt","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<n;++i){
		scanf("%d%d",&u[i],&v[i]);
		g[u[i]].push_back(v[i]);
		g[v[i]].push_back(u[i]);
	}
	bf::main();
	return 0;
}
