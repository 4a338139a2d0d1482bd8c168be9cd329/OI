#include<bits/stdc++.h>
using namespace std;

pair<int,int> e[1000];

int main(){
	FILE*f=fopen("tree.in","w");
	srand(time(0));
	int n=150;
	fprintf(f,"%d\n",n);
	for(int i=2;i<n;++i)
		e[i]=make_pair(rand()%(i-1)+1,i);
	for(int i=2;i<n;++i)
		fprintf(f,"%d %d\n",e[i].first,e[i].second);
	fclose(f);
//	system("./bf\n");
//	system("./tree\n");
	return 0;
}
