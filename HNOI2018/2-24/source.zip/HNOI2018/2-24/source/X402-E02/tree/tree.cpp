#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int a[11][11],b[11],c[11],q[11],an[11],ans,n;
void dfs(int x,int y){
	if (y>=ans) return;
	if (x==n){
		if (y<ans) ans=y,memcpy(an,q,n<<2);
		return;
	}
	For(i,1,n-1){
		int &e=a[b[x]][i],&f=a[c[x]][i];
		if (e==1||f==1) continue;
		e=f=1; q[x]=i; dfs(x+1,y+i); e=f=0;
	}
}
int main(){
	freopen("tree.in","r",stdin); freopen("tree.out","w",stdout);
	n=read();
	if (n<=10){
		For(i,1,n-1) b[i]=read(),c[i]=read(),an[i]=i;
		ans=(n-1)*n/2; dfs(1,0); printf("%d\n",ans);
		For(i,1,n-1) printf("%d ",an[i]);
	}
	return 0;
}
