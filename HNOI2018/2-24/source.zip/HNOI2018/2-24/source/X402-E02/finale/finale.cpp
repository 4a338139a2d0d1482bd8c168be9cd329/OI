#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int n,m,a[41],f,k; long long ans;
void dfs(int x){
	if (x==n+1){
		For(i,n+1,n+m) a[i]=a[i-n];
		For(i,1,n){
			f=0;
			For(j,i,i+m-1) f|=(1<<(a[j]-1));
			if (f==k) return;
		}
		++ans; return;
	}
	For(i,1,m) a[x]=i,dfs(x+1);
}
int main(){
	freopen("finale.in","r",stdin); freopen("finale.out","w",stdout);
	n=read(),m=read(),k=(1<<m)-1;
	if (n<m){
		ans=1; For(i,1,n) ans*=m; printf("%lld\n",ans); return 0;
	}
	if (m==2) printf("2\n"),exit(0);
	dfs(1),printf("%lld\n",ans);
	return 0;
}
