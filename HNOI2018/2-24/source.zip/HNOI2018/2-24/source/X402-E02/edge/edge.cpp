#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int n,m,k,a[6],ans;
void dfs(int x,int y,int z){
	if (x==n){
		if (z<k) return;
		For(i,1,m) if (!a[i]) return;
		For(i,m+1,n) if (a[i]) return;
		++ans; return;
	}
	int b=x,c=y+1; if (c==n+1) ++b,c=b+1;
	dfs(b,c,z);
	if (z<k) a[x]^=1,a[y]^=1,dfs(b,c,z+1),a[x]^=1,a[y]^=1;
}
int main(){
	freopen("edge.in","r",stdin); freopen("edge.out","w",stdout);
	n=read(),m=read(),k=read();
	if (m%2==1||k>n*(n-1)/2) printf("0\n"),exit(0);
	if (n<=5) dfs(1,2,0),printf("%d\n",ans),exit(0);
	return 0;
}
