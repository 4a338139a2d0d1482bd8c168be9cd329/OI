#include<bits/stdc++.h>
using namespace std;

const int MAXN = 10;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, ans;
int col[MAXN];
bool buc[MAXN];

void dfs(int u) {
	int i, j;
	if(u == n) {
		for(i = 0; i < n; i++) {
			memset(buc, false, sizeof(buc));
			for(j = 1; j <= m; j++) {
				if(buc[col[(i+j-1)%n]]) break;
				buc[col[(i+j-1)%n]] = true;
			}
			if(j > m) return;
		}
		ans++;
		return;
	}
	for(i = 1; i <= m; i++) {
		col[u] = i;
		dfs(u+1);
	}
}

int main() {
	freopen("finale.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	n = read(), m = read();
	dfs(0);
	printf("%d\n", ans);
	return 0;
}
