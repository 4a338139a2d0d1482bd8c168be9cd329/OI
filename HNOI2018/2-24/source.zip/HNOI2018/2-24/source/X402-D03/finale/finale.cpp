#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;
const int MAXM = 7;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int N;
struct Matrix {
	ll m[300][300];
	Matrix(int x = 0) {
		memset(m, 0, sizeof(m));
		if(x == 1) {
			int i;
			for(i = 1; i <= N; i++) m[i][i] = 1;
		}
	}
}A, B;

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

Matrix operator * (const Matrix &a, const Matrix &b) {
	Matrix res;
	int i, j, k;
	for(i = 1; i <= N; i++) 
		for(j = 1; j <= N; j++) 
			for(k = 1; k <= N; k++) 
				update(res.m[i][j], a.m[i][k]*b.m[k][j]%MOD);
	return res;
}

Matrix qpow(Matrix a, ll b) {
	Matrix res = 1;
	while(b) {
		if(b & 1LL) res = res * a;
		b >>= 1, a = a * a;
	}
	return res;
}

int m;
namespace Auto {
	int ch[2000][6], cnt;
	int fa[2000], id[2000];
	bool ban[2000];
	inline void init() {
		cnt = 1;
	}
	inline void insert(int *s, int len) {
		int i, p = 1;
		for(i = 1; i <= len; i++) {
			int c = s[i]-1;
			if(!ch[p][c]) ch[p][c] = ++cnt;
			p = ch[p][c];
		}
		ban[p] = true;
	}
	inline void getfail() {
		int i;
		fa[1] = 0;
		for(i = 0; i < m; i++) ch[0][i] = 1;
		queue<int> q;
		q.push(1);
		while(!q.empty()) {
			int u = q.front();
			q.pop();
			for(i = 0; i < m; i++) {
				int v = ch[u][i];
				if(!v) ch[u][i] = ch[fa[u]][i];
				else {
					fa[v] = ch[fa[u]][i];
					q.push(v);
				}
			}
		}
	}
	inline void calc() {
		int i, j;
		for(i = 1; i <= cnt; i++) {
			if(ban[i]) continue;
			id[i] = ++N;
		}
		for(i = 1; i <= cnt; i++) {
			if(ban[i]) continue;
			for(j = 0; j < m; j++) {
				int v = ch[i][j];
				if(ban[v]) continue;
				A.m[id[v]][id[i]] = 1;
			}
		}
	}
	inline int go(int p, int *s, int len) {
		int i;
		for(i = 1; i <= len; i++) {
			int c = s[i]-1;
			if(ban[ch[p][c]]) return -1;
			p = ch[p][c];
		}
		return p;
	}
}

int n, c[MAXM], cnt;
bool cs[MAXM];
int t[730][7];

void dfs(int u) {
	int i;
	if(u == m+1) {
		Auto::insert(c, m);
		cnt++;
		for(i = 1; i <= m; i++) t[cnt][i] = c[i];
		return;
	}
	for(i = 1; i <= m; i++) {
		if(cs[i]) continue;
		c[u] = i;
		cs[i] = true;
		dfs(u+1);
		cs[i] = false;
	}
}

ll ans;

namespace bf {
	int col[10];
	bool buc[10];

	void dfs(int u) {
		int i, j;
		if(u == n) {
			for(i = 0; i < n; i++) {
				memset(buc, false, sizeof(buc));
				for(j = 1; j <= m; j++) {
					if(buc[col[(i+j-1)%n]]) break;
					buc[col[(i+j-1)%n]] = true;
				}
				if(j > m) return;
			}
			ans++;
			return;
		}
		for(i = 1; i <= m; i++) {
			col[u] = i;
			dfs(u+1);
		}
	}
}

int main() {
	freopen("finale.in", "r", stdin);
	freopen("finale.out", "w", stdout);

	int i, j, k;
	n = read(), m = read();
	if(n <= 7) {
		bf::dfs(0);
		printf("%lld\n", ans);
		return 0;
	}
	Auto::init();
	dfs(1);
	Auto::getfail();
	Auto::calc();
	B = qpow(A, n);
	for(i = 1; i <= N; i++) update(ans, B.m[i][1]);
	if(n < m) {
		printf("%lld\n", ans);
		return 0;
	}
	B = qpow(A, n-m);
	for(i = 1; i <= cnt; i++) {
		for(j = 1; j < m; j++) {
			int u = Auto::go(1, t[i]+j, m-j);
			for(k = 1; k <= Auto::cnt; k++) {
				if(Auto::ban[k]) continue;
				if(Auto::go(k, t[i], m-1) == -1) continue;
				update(ans, MOD-B.m[Auto::id[k]][Auto::id[u]]);
			}
		}
	}
	printf("%lld\n", ans);
	return 0;
}
