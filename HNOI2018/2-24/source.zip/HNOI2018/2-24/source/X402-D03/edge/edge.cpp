#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, K, ans;
int deg[10];
bool g[10][10];

void dfs(int x, int y) {
	if(y > n) x++, y = x+1;
	if(y == n+1) {
		int i, j, e = 0;
		for(i = 1; i <= n; i++) deg[i] = 0;
		for(i = 1; i <= n; i++) 
			for(j = 1; j <= n; j++) 
				if(g[i][j]) 
					e++, deg[i]++, deg[j]++;
		if(e != K) return ;
		for(i = 1; i <= m; i++) if(!(deg[i]&1)) return;
		for(; i <= n; i++) if(deg[i]&1) return;
		ans++;
		return;
	}
	g[x][y] = true;
	dfs(x, y+1);
	g[x][y] = false;
	dfs(x, y+1);
}

int main() {
	freopen("edge.in", "r", stdin);
	freopen("edge.out", "w", stdout);

	int i;
	n = read(), m = read(), K = read();
	if(n == 1) {
		if(K != 0 || m != 0) printf("0\n");
		else printf("1\n");
		return 0;
	}
	dfs(1, 2);
	printf("%d\n", ans);
	return 0;
}
