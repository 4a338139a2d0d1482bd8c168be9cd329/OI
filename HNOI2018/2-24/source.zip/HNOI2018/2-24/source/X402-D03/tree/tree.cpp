#include<bits/stdc++.h>
using namespace std;

const int MAXN = 11;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, col[MAXN], res, ans;
int Ans[MAXN];
vector<int> G[MAXN];
bool buc[MAXN];

void dfs(int u) {
	if(u == n) {
		int i, j;
		for(i = 1; i <= n; i++) {
			memset(buc, false, sizeof(buc));
			for(j = 0; j < (int)G[i].size(); j++) {
				if(buc[col[G[i][j]]]) return;
				buc[col[G[i][j]]] = true;
			}
		}
		if(res < ans) {
			ans = res;
			for(i = 1; i < n; i++) Ans[i] = col[i];
			//copy(Ans+1, Ans+n, col+1);
		}
		return;
	}
	int i;
	for(i = 1; i <= n; i++) {
		col[u] = i;
		res += i;
		dfs(u+1);
		res -= i;
	}
}

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	int i;
	n = read();
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		G[u].push_back(i);
		G[v].push_back(i);
	}
	ans = (1+n)*n;
	dfs(1);
	printf("%d\n", ans);
	for(i = 1; i < n; i++) printf("%d ", Ans[i]);
	printf("\n");
	return 0;
}
