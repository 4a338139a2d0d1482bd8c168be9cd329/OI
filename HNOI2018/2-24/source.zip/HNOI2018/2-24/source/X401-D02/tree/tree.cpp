#include<iostream>
#include<cstdio>
#include<queue>
using namespace std;
const int maxn=160;
int n,ans;
int e,to[maxn<<1],nex[maxn<<1],beg[maxn],mark[maxn<<1];
int which[maxn];
int ind[maxn],son[maxn],fa[maxn];
bool vis[maxn][maxn];
inline void add(int u,int v,int a)
{
	to[++e]=v;
	nex[e]=beg[u];
	beg[u]=e;
	mark[e]=a;
}
void dfs(int u,int f)
{
	fa[u]=f;
	for(register int i=beg[u];i;i=nex[i])
	{
		int v=to[i];
		if(v==f)continue;
		++son[u];
		dfs(v,u);
	}
}
void bfs(int fuck)
{
	queue<int>q;
	q.push(fuck);
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		int l=son[u];
		for(register int i=beg[u];i;i=nex[i])
		{
			int v=to[i];
			if(v==fa[u])continue;
			q.push(v);
			int flag=0;
			for(register int j=1;j<=son[u];++j)
			{
				if((!flag)&&(!vis[u][j])&&j<=son[v])flag=j;
				else if(j>son[v]&&(!vis[u][j]))
				{
					vis[u][j]=1;
					vis[v][j]=1;
					ans+=j;
					flag=-1;
					which[mark[i]]=j;
					break;
				}
			}
			if(flag>0)
			{
				vis[u][flag]=1;
				vis[v][flag]=1;
				ans+=flag;
				which[mark[i]]=flag;
			}
			else if(flag==0)
			{
				vis[u][++l]=1;
				vis[v][l]=1;
				which[mark[i]]=l;
				ans+=l;
			}
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	int u,v;
	for(register int i=1;i<n;++i)
	{
		scanf("%d%d",&u,&v);
		++ind[u],++ind[v];
		add(u,v,i),add(v,u,i);
	}
	int mm=0;
	for(register int i=1;i<=n;++i)
		if(ind[i]>ind[mm])mm=i;
	dfs(mm,mm);
	bfs(mm);
	printf("%d\n",ans);
	for(register int i=1;i<n;++i)
		printf("%d ",which[i]);
	return 0;
}
