#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
const ll maxn=1e9;
const ll mod=998244353;
ll n,m;
int main()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	printf("2\n");
	


	return 0;
}
