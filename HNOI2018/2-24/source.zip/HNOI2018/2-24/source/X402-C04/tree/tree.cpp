#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
typedef pair<int,int> pr;
const int N=159;
int n,ans,tmp;
int ansf[N],tmpf[N],deg[N];
vector<pr> g[N],e;

namespace bf
{
	int c[N];
	ll vis[N];

	inline void dfs(int u,int tot)
	{
		if(tot>=ans)
			return;
		if(u==n)
		{
			if(ans>tot)
			{
				ans=tot;
				memcpy(ansf,tmpf,sizeof(tmpf));
			}
			return;
		}
		
		ll res=((1ll<<n)-1)^(vis[e[u-1].first]|vis[e[u-1].second]);
		for(int i=1,ed=max(deg[e[u-1].first],deg[e[u-1].second]);i<=ed;i++)
			if(res&(1<<i-1))
			{
				vis[e[u-1].first]|=1<<i-1;
				vis[e[u-1].second]|=1<<i-1;
				tmpf[u]=i;
				dfs(u+1,tot+i);
				vis[e[u-1].first]^=1<<i-1;
				vis[e[u-1].second]^=1<<i-1;
			}
	}


	int main()
	{
		ans=1e9+7;
		dfs(1,0);
		printf("%d\n",ans);
		for(int i=1;i<n;i++)
			printf("%d ",ansf[i]);
		puts("");
		return 0;
	}
}

namespace bf_random
{

	inline void dfs(int u,int fa,int faw)
	{
		random_shuffle(g[u].begin(),g[u].end());
		for(int i=0,cur=1,e=g[u].size();i<e;i++,cur++)
		{
			if(g[u][i].first==fa)continue;
			if(cur==faw)cur++;
			tmp+=(tmpf[g[u][i].second]=cur);
			dfs(g[u][i].first,u,cur);
		}
	}

	int main()
	{
		srand(time(0));
		ans=1e9+7;
		while(clock()<400)
		{
			tmp=0;
			dfs(1,0,0);
			if(ans>tmp)
			{
				ans=tmp;
				memcpy(ansf,tmpf,sizeof(tmpf));
			}
		}
		printf("%d\n",ans);
		for(int i=1;i<n;i++)
			printf("%d ",ansf[i]);
		puts("");
		return 0;
	}
}

namespace bf_random2
{
	int a[N];
	bool vis[N][N];

	int main()
	{
		ans=1e9+7;
		for(int i=1;i<n;i++)
			a[i]=i;
		while(clock()<0.48*CLOCKS_PER_SEC)
		{
			tmp=0;
			memset(vis,0,sizeof(vis));
			random_shuffle(a+1,a+n);
			for(int i=1;i<n;i++)
			{
				for(int j=1;j<=n;j++)
					if(!vis[e[a[i]-1].first][j] && !vis[e[a[i]-1].second][j])
					{
						vis[e[a[i]-1].first][j]=vis[e[a[i]-1].second][j]=1;
						tmp+=(tmpf[a[i]]=j);break;
					}
				if(tmp>=ans)goto nxt;
			}
			ans=tmp;
			memcpy(ansf,tmpf,sizeof(tmpf));
			nxt:;
		}
		printf("%d\n",ans);
		for(int i=1;i<n;i++)
			printf("%d ",ansf[i]);
		puts("");
		return 0;
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);

	n=read();
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		g[u].push_back(pr(v,i));
		g[v].push_back(pr(u,i));
		e.push_back(pr(u,v));
		deg[u]++;deg[v]++;
	}
	if(n<=10)
		bf::main();
	else
		bf_random2::main();

	return 0;
}
