#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=1000;
const int md=998244353;

int n,m,ans,a[N];
bool vis[N];

inline void dfs(int p)
{
	if(p==n)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=1;j<=m;j++)
				vis[a[(i+j-1)%n]]=0;
			for(int j=1;j<=m;j++)
				if(vis[a[(i+j-1)%n]])
					goto pass;
				else
					vis[a[(i+j-1)%n]]=1;
			return;
			pass:;
		}
		ans++;
		if(ans>=md)ans-=md;
		return;
	}
	for(int i=1;i<=m;i++)
	{
		a[p]=i;
		dfs(p+1);
	}
}

inline int m2()
{
	puts("2");
	return 0;
}

int main()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);

	scanf("%d%d",&n,&m);
	if(m==2)return m2();
	dfs(0);	
	printf("%d\n",ans);
	return 0;
}
