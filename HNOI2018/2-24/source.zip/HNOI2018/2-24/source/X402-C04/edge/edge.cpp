#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef long long ll;
const int N=1009;
const int md=1e9+7;
const int M=209;

int n,m,k,ans,deg[N];
pr e[N];

inline void dfs(int sp,int res,int las)
{
	if(sp==n && res==k+1)
	{
		ans++;
		if(ans>=md)ans-=md;
		return;
	}
	if(sp>n || res>k+1)return;
	if((deg[sp]&1)==(sp<=m))
		dfs(sp+1,res,sp+1);
	for(int i=las+1;i<=n;i++)
	{
		e[res]=pr(sp,i);
		deg[sp]++;deg[i]++;
		dfs(sp,res+1,i);
		deg[sp]--;deg[i]--;
	}
}

int main()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);

	scanf("%d%d%d",&n,&m,&k);
	dfs(1,1,1);
	printf("%d\n",ans);
	return 0;
}

