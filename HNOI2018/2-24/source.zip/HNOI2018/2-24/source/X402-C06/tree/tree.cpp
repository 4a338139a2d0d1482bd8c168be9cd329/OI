#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}

const int maxn=150+10;
int Gra[maxn][maxn],s,t,n,Ans=INT_MAX;
int S[maxn],Dgr[maxn],ans[maxn],color[maxn];
int vis[maxn][maxn],Max_Degree=INT_MIN;

struct node{
	int s,t;
}a[maxn];

inline void Init(){
	read(n);
	For(i,1,n-1){
		read(s),read(t);
		Gra[s][t]=Gra[t][s]=1;
		Dgr[s]++,Dgr[t]++;
		a[i].s=s,a[i].t=t;
		Max_Degree=max(Max_Degree,max(Dgr[s],Dgr[t]));
	}
}

inline void Dfs(int x,int tot){
	if(x==n){
		if(tot<Ans){
			Ans=tot;
			For(i,1,n-1) ans[i]=color[i];
		}
		return;
	}
	For(i,1,Max_Degree){
		if(vis[a[x].s][i] || vis[a[x].t][i]) continue;	
		vis[a[x].s][i]=vis[a[x].t][i]=1;
		tot+=i,color[x]=i;
		Dfs(x+1,tot);
		tot-=i,color[x]=0;
		vis[a[x].s][i]=vis[a[x].t][i]=0;
	}	
}

int main(){
	file(),Init();
	Dfs(1,0);
	printf("%d\n",Ans);
	For(i,1,n-1) printf("%d ",ans[i]);
	putchar('\n');
	return 0;
}

