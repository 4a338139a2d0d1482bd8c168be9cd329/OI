#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void File(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
}
const int maxn=1e3+10,N=8;
int n,k,m,ans;
int dgr[maxn],vis[N][N];

inline void dfs(int tot,int x,int y){
	if(tot==k+1){
		int cnt=0;
		For(i,1,m) if(dgr[i]&1) cnt++;
		For(i,m+1,n) if(!(dgr[i]&1)) cnt++;
		if(cnt==n) ans++;
		return;
	}	
	For(i,x,n){
		if(i!=x) y=1+i;
		For(j,y,n){
			if(!vis[i][j]){
				vis[i][j]=vis[j][i]=1;
				dgr[i]++,dgr[j]++;
				dfs(tot+1,i,j+1);
				dgr[i]--,dgr[j]--;
				vis[i][j]=vis[j][i]=0;
			}
		}
	}
}

inline void Cheat(){
	if(m&1){
		printf("0\n");
		return;
	}
	if(m==k && k==0 || m==3 && k==1){
		printf("1\n");
		return;
	}
}

int main(){
	File();
	read(n),read(m),read(k);
	if(n<=10){
		dfs(1,1,2);
		printf("%d\n",ans);
	}
	else Cheat();
	return 0;
}

