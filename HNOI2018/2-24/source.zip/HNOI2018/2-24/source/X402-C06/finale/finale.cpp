#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
}

const int N=10;
int a[N<<1],m,n,vis[N],ans;

inline bool Check(){
	For(i,1,(n<<1)-m+1){
		memset(vis,0,sizeof(vis));
		int	cnt=0;
		For(j,i,i+m-1){
			if(!vis[a[j]]) cnt++;
			vis[a[j]]=1;
		}
		if(cnt==m) return false;
	}
	return true;
}

inline void Dfs(int x){
	if(x==n+1){
		if(Check()) ans++;
		return;
	}
	For(i,1,m){
		a[x]=i,a[x+n]=i;
		Dfs(x+1);
		a[x]=0,a[x+n]=0;
	}
}

inline void Cheat(){
	if(m==2){
		printf("2\n");
		return;
	}
}

int main(){
	file();
	read(n),read(m);
	if(n<=7){
		Dfs(1);
		printf("%d\n",ans);
	}
	else Cheat();
	return 0;
}

