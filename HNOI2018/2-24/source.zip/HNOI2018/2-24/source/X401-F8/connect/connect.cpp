#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;
int n,m,k;
int main()
{
	scanf("%D%D%D",&n,&m,&k);
	return 0;
}

