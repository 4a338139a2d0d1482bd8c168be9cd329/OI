#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;
int main()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	if(m==2)printf("2\n");
	else if(m==3)
	{
		int ans=0;
		for(int i=0;i<=n;++i)
		for(int j=0;j<=n-i;++j)
			if(n-i-j!=1||!i||!j)ans++;
		printf("%d\n",ans);
	}
	return 0;
}

