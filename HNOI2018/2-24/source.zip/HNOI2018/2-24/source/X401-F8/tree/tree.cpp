#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;
int n;
int main()
{
	scanf("%d",&n);
	
	return 0;
}

