#include<bits/stdc++.h>
using namespace std;
const int N=3e5+10;
int n,m,ans=0x3f3f3f3f;

int ccc=0;
int acl[N];
int cl[N];
int xl[N];
int bl[N];
int son[N];
int sz,mxsz;
int fa[N];
int rk[N];

struct node{
	int x,v;
};
bool cmp(node a,node b){
	return a.x>b.x;
}
struct node p[N];

int hh[N],ncl[N];

struct graph{
	int bgn[N],to[N],fr[N],w[N],nxt[N],e;
	void add(int x,int y){
		to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e;
	}
	void calc(){
		for(int i=1; i<=n-1; ++i)
			for(int j=bgn[i]; j; j=nxt[j]){
				if(cl[i]==cl[to[j]]) return;
			}

		int ret=0;
		for(int i=1; i<=n-1; ++i) ret+=cl[i];
		ans=min(ans,ret);
		if(ans==ret)
			for(int i=1; i<=n-1; ++i) acl[i]=cl[i];
	}
	
	void dfs(int x){
		for(int i=1; i<=mxsz; ++i){
			cl[x]=i;
			if(x<n-1) dfs(x+1); else calc();
		}
	}
	void solve(){
		dfs(1);
		printf("%d\n",ans);
		for(int i=1; i<=n-1; ++i) printf("%d ",acl[i]);
	}

	void ca(){
		++ccc;
		if(ccc>100) return;
		int ret=0;
		for(int i=1; i<=mxsz; ++i) hh[i]=0;
		for(int i=1; i<=n-1; ++i) hh[cl[i]]++;
		for(int i=1; i<=mxsz; ++i) p[i].x=hh[i],p[i].v=i;
		sort(p+1,p+mxsz+1,cmp);
		for(int i=1; i<=mxsz; ++i) rk[p[i].v]=i;
		for(int i=1; i<=n-1; ++i) ncl[i]=rk[cl[i]];
		for(int i=1; i<=n-1; ++i) ret+=ncl[i];
		ans=min(ans,ret);
		if(ans==ret)
			for(int i=1; i<=n-1; ++i) acl[i]=ncl[i];
	}


	void gfs(int x,int cnt=0){
		if(ccc>100) return;
		for(int i=0; i<=mxsz; ++i) rk[i]=0;
		for(int i=bgn[x]; i; i=nxt[i]) rk[cl[to[i]]]++;
		for(int i=1; i<=mxsz; ++i){
			if(!rk[i]){
				cl[x]=i;
				if(cnt+1==n-1) ca();
				else{
				 	int cf=0;
					for(int j=bgn[x]; j; j=nxt[j])
						if((!cl[to[j]]) && (rand()&1)){
							gfs(to[j],cnt+1);
							cf=1;
						}
				
				  	if(!cf){
					  	for(int j=1; j<=n; ++j){
				  	    	if(!cl[j] && (rand()&1)) gfs(j,cnt+1);
						}
					}
				}
			}
		}
	}

	void find(){
		for(int i=1; i<=n; ++i){
			for(int j=1; j<=n; ++j) cl[j]=0;
			ccc=0;
			gfs(i,0);
		}
	}
};


struct graph a,b,c;


namespace __{
	void solve(){
		scanf("%d",&n);
		int x(0),y(0);
		for(int i=1; i<n; ++i){
			scanf("%d%d",&x,&y);
			a.add(x,y); a.add(y,x);
		}

		for(int i=1; i<=n; ++i){
			sz=0;
			for(int j=a.bgn[i]; j; j=a.nxt[j]){
				++sz; mxsz=max(mxsz,sz);
				for(int k=a.bgn[i]; k; k=a.nxt[k])
					if(j!=k) b.add((j+1)/2,(k+1)/2),
							 b.add((k+1)/2,(j+1)/2);
			}
		}

		if(n<=5) b.solve(); else{ 
			b.find();
			printf("%d\n",ans);
			for(int i=1; i<n; ++i) printf("%d ",acl[i]);
		}
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	__::solve();
}
