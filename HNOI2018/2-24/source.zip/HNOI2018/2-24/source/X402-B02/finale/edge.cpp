#include<bits/stdc++.h>
const int N=1e2+10;
using namespace std;

int d[N];
int n,m,k;
int ans;

void fk(){
	for(int i=1; i<=m; ++i) if(d[i]%2==0) return;
	for(int i=m+1; i<=n; ++i) if(d[i]%2==1) return;
	++ans;
}

void dfs(int x){
	for(int i=1; i<=n; ++i)
		for(int j=1; j<=n; ++j){
			d[i]++; d[j]++;
			if(x<n) dfs(x+1); else fk();
		}
}

int main(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	dfs(1);
	printf("%d\n",ans);
}  
