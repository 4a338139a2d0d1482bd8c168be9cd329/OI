#include<bits/stdc++.h>
#define k m
#define ll long long
const int mod=998244353;
const int N=2e4;
using namespace std;

map<int,bool> mp;
int n,m;
int a[N],ans;

namespace __{
	ll fpm(ll x,ll y){
		ll s=1;
		while(y){
			if(y&1) s=s*x%mod;
			y>>=1; x=x*x%mod;
		}
		return s;
	}
		
	void buf1(){
		puts("2");
	}

	void fk(){
		for(int i=1; i<=n; ++i) a[i+n]=a[i];
		for(int i=1; i<=n; ++i){
			mp.clear();
			for(int j=i; j<=i+k-1; ++j) mp[a[j]]=1;
			if(mp.size() == k) return;
		}
		++ans;
	}

	void dfs(int x){
		for(int i=1; i<=m; ++i){
			a[x]=i;
			if(x<n) dfs(x+1); else fk();
		}
	}

	void calc(){
		dfs(1);
		printf("%d\n",ans);
	}
}


int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m == 2) __::buf1(); else __::calc();
}
