#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
const int maxn=1010;
int n, m, k;
int ans, cnt, use[maxn], deg[maxn];
pii e[maxn];

bool check(){
	for(int i=1;i<=n;i++) deg[i]=0;
	for(int i=1;i<=cnt;i++) if(use[i]) deg[ e[i].fi ]++, deg[ e[i].se ]++;
	for(int i=1;i<=m;i++) if(!(deg[i] & 1)) return false;
	for(int i=m+1;i<=n;i++) if(deg[i] & 1) return false;
	return true;
}

void dfs(int now,int res){
	if(now>cnt){
		if(res!=0) return;
		if(check()) ans++;
		return;
	}
	if(res){
		use[now]=1;
		dfs(now+1,res-1);
		use[now]=0;
	}
	dfs(now+1,res);
}

int main(){
	freopen("edge.in","r",stdin),freopen("edge.out","w",stdout);

	scanf("%d%d%d", &n, &m, &k);
	for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) e[++cnt]=make_pair(i,j);
	dfs(1,k);
	printf("%d\n", ans);
	return 0;
}
