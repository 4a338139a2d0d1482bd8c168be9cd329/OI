#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
typedef long long ll;
const int maxn=1010;
const int mod=1e9+7;
int n, m, K;
int ans, cnt, use[maxn], deg[maxn];
pii e[maxn];

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

bool check(){
	for(int i=1;i<=n;i++) deg[i]=0;
	for(int i=1;i<=cnt;i++) if(use[i]) deg[ e[i].fi ]++, deg[ e[i].se ]++;
	for(int i=1;i<=m;i++) if(!(deg[i] & 1)) return false;
	for(int i=m+1;i<=n;i++) if(deg[i] & 1) return false;
	return true;
}

void dfs(int now,int res){
	if(now>cnt){
		if(res!=0) return;
		if(check()) ans++;
		return;
	}
	if(res){
		use[now]=1;
		dfs(now+1,res-1);
		use[now]=0;
	}
	dfs(now+1,res);
}

int dp[200][200][400];
int C[maxn][maxn];

void init(){
	C[0][0]=1;
	for(int i=1;i<=n;i++){
		C[i][0]=1;
		for(int j=1;j<=i;j++) C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
	}
}

ll calc(int t){
	// printf("%d\n", 260/18);
	memset(dp,0,sizeof(dp));
	dp[0][0][0]=1;
	for(int i=0;i<=m;i++) for(int j=0;j<=t;j++) for(int k=0;k<=2*K;k++) if(dp[i][j][k]){
		int now=dp[i][j][k];
		for(int l=2;l<m+t && l+k<=2*K;l+=2) (dp[i][j+1][l+k]+=now)%=mod;
		for(int l=1;l<m+t && l+k<=2*K;l+=2) (dp[i+1][j][l+k]+=now)%=mod;
	}
	// printf("%lld\n", 1ll*dp[m][t][2*K]);
	// printf("%lld\n", 1ll*dp[m][n-m][2*K]*Pow(C[n][m], mod-2)%mod);
	return dp[m][t][2*K]*Pow(C[m+t][m], mod-2)%mod*C[n-m][t]%mod;
	ll ans=0;
	for(int i=0;i<=n-m;i++){
		ans=(ans+dp[m][i][2*K])%mod;
		printf("%lld\n", dp[m][i][2*K]);
	}
	printf("%lld\n", ans);
}

void solve(){
	ll ans=0;
	for(int i=0;i<=n-m;i++) ans=(ans+calc(i))%mod;
	printf("%lld\n", ans);
}

int main(){
	freopen("edge.in","r",stdin),freopen("edge.out","w",stdout);

	scanf("%d%d%d", &n, &m, &K);
	if(m&1){ puts("0"); return 0; } 
	init();
	if(n>50){ solve(); return 0; }
	for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) e[++cnt]=make_pair(i,j);
	dfs(1,K);
	printf("%d\n", ans);
	return 0;
}
