#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
const int maxn=200;
const int inf=1e9;
int n, c[maxn], val[maxn];
vector<int> g[maxn];
pii a[maxn];
int ans, col[maxn], Max, deg[maxn];

void dfs(int x,int now){
	//if(1.0*clock()/CLOCKS_PER_SEC>=0.45) return;
	if(now>=ans) return;
	if(x==n){
		if(now<ans){
			for(int i=1;i<n;i++) col[i]=c[i]; ans=now;
		}
		return;
	}
	for(int i=1;i<=Max;i++){
		int u=a[x].fi, v=a[x].se;
		if((val[u] & (1<<i)) || (val[v] & (1<<i))) continue;
		c[x]=i; val[u] ^= 1<<i; val[v] ^= 1<<i;
		dfs(x+1,now+i);
		val[u] ^= 1<<i; val[v] ^= 1<<i;
	}
}

int x[maxn], y[maxn], pos[maxn], vis[maxn][maxn], w[maxn];
void solve(){
	srand(time(0));
	ans=inf;
	for(int i=1;i<n;i++){ scanf("%d%d", &x[i], &y[i]); pos[i]=i; }
	int T=100000;
	while(T--){
		for(int i=1;i<=n;i++){
			int a=rand()%(n-1)+1, b=rand()%(n-1)+1;
			swap(pos[a], pos[b]); swap(x[a], x[b]); swap(y[a], y[b]);
		}
		int now=0;
		for(int i=1;i<n;i++){
			int mex=1;
			while(vis[ x[i] ][mex] || vis[ y[i] ][mex]) mex++;
			vis[ x[i] ][mex]=1; vis[ y[i] ][mex]=1;
			w[i]=mex; now+=mex;
		}
		for(int i=1;i<n;i++){
			vis[ x[i] ][ w[i] ]=vis[ y[i] ][ w[i] ]=0;
		}
		if(now<ans){
			ans=now;
			for(int i=1;i<n;i++) col[ pos[i] ]=w[i];
		}
	}
	printf("%d\n", ans);
	for(int i=1;i<n;i++) printf("%d ", col[i]); puts("");
}

int main(){
	freopen("tree.in","r",stdin),freopen("tree.out","w",stdout);

	scanf("%d", &n);
	if(n>10){ solve(); return 0; }
	int u, v;
	for(int i=1;i<n;i++){
		scanf("%d%d", &u, &v);
		a[i]=make_pair(u,v);
		g[u].push_back(v), g[v].push_back(u);
		deg[u]++; deg[v]++;
	}
	for(int i=1;i<=n;i++) Max=max(Max, deg[i]);
	ans=inf;
	dfs(1,0);
	printf("%d\n", ans);
	for(int i=1;i<n;i++) printf("%d ", col[i]); puts("");
	return 0;
}
