#include<bits/stdc++.h>
using namespace std;

const int maxn=100;
const int mod=998244353;
int n, m;
int a[maxn], ans, b[maxn];

bool check(){
	for(int i=n+1;i<=n+n;i++) a[i]=a[i-n];
	// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
	for(int i=1;i<=n;i++){
		int f=1;
		for(int j=0;j<m;j++) b[j+1]=a[i+j];
		sort(b+1, b+1+m);
		for(int j=2;j<=m;j++) if(b[j]==b[j-1]){ f=0; break; }
		if(f) return false;
	}
	return true;
}

void dfs(int x){
	if(x>n){
		if(check()){
			ans++; 
			// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
		}
		return;
	}
	for(int i=1;i<=m;i++){
		a[x]=i;
		dfs(x+1);
	}
}

int main(){
	freopen("finale.in","r",stdin),freopen("finale.out","w",stdout);

	scanf("%d%d", &n, &m);
	if(m==2){ puts("2"); return 0; }
	dfs(1);
	printf("%d\n", ans);
	return 0;
}
