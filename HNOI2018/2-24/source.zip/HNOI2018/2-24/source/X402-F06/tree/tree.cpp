#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmin(int &x,int y){return (y<x)?(x=y,1):0;}
inline bool chkmax(int &x,int y){return (y>x)?(x=y,1):0;}
const int maxn=150+10,inf=0x3f3f3f3f;
int Begin[maxn],Next[maxn<<1],to[maxn<<1],e;
int f[maxn][maxn],w[maxn][maxn];
int px[maxn],py[maxn],slack[maxn],may[maxn],matx[maxn],A[maxn],B[maxn];
vector<int> pre[maxn][maxn];
int Pre[maxn];
void add_edge(int x,int y){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
}
void link(int x){
	int y,tmp;
	while(y=Pre[x]){
		tmp=matx[y];
		may[x]=y;
		matx[y]=x;
		x=tmp;
	}
}
void bfs(int x,int nx,int ny){
	queue<int> q;
	memset(px,0,sizeof(px));
	memset(py,0,sizeof(py));
	memset(slack,inf,sizeof(slack));
	while(!q.empty()) q.pop();
	q.push(x);
	while(1){
		while(!q.empty()){
			int u=q.front();
			q.pop();
			px[u]=1;
			for(int i=1;i<=ny;i++)
				if(!py[i])
					if(A[u]+B[i]==w[u][i]){
						py[i]=1;
						Pre[i]=u;
						if(!may[i]){
							link(i);
							return;
						}
						else q.push(may[i]);
					}
					else if(slack[i]>A[u]+B[i]-w[u][i]){
						slack[i]=A[u]+B[i]-w[u][i];
						Pre[i]=u;
					}
		}
		int num=inf;
		for(int i=1;i<=ny;i++)
			if(!py[i] && num>slack[i])
				num=slack[i];
		for(int i=1;i<=nx;i++)
			if(px[i])
				A[i]-=num;
		for(int i=1;i<=ny;i++)
			if(py[i])
				B[i]+=num;
			else slack[i]-=num;
		for(int i=1;i<=ny;i++)
			if(!py[i] && !slack[i])
				if(!may[i]){
					link(i);
					return;
				}
				else{
					py[i]=1;
					q.push(may[i]);
				}
	}
}
void km(int x,int y,int nx,int ny){
	memset(matx,0,sizeof(matx));
	memset(may,0,sizeof(may));
	memset(Pre,0,sizeof(Pre));
	REP(i,1,nx) A[i]=-inf;
	REP(i,1,ny) B[i]=0;
	REP(i,1,nx) REP(j,1,ny) chkmax(A[i],w[i][j]);
	REP(i,1,nx) bfs(i,nx,ny);
	int ans=0;
	REP(i,1,nx)
		pre[x][y].push_back(matx[i]),ans+=w[i][matx[i]];
	f[x][y]=-ans;
}
int n;
void dfs(int x,int ff){
	int S=0,tmp=0;
	for(int i=Begin[x];i;i=Next[i]){
		if(to[i]==ff) continue;
		dfs(to[i],x),++S;
	}
	if(!S){
		REP(i,1,n-1) f[x][i]=0;
		return;
	}
	REP(i,1,n-1){
		S=0;
		for(int j=Begin[x];j;j=Next[j]){
			if(to[j]==ff) continue;
			++S;
			REP(k,1,n-1) if(k!=i) w[S][k-(k>i)]=-f[to[j]][k]-k;
		}
		km(x,i,S,n-2);
	}
}
int ans[maxn];
void dfs_ans(int x,int y,int ff){
	int S=0;
	for(int i=Begin[x];i;i=Next[i]){
		if(to[i]==ff) continue;
		ans[(i+1)/2]=pre[x][y][S];
		if(ans[(i+1)/2]>=y) ans[(i+1)/2]++;
		S++;
		dfs_ans(to[i],ans[(i+1)/2],x);
	}
}
int vis[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
#endif
	n=read();
	REP(i,1,n-1){
		int x=read(),y=read();
		add_edge(x,y),add_edge(y,x);
	}
	dfs(1,0);
	int num=0,Min=inf;
	REP(i,1,n-1)
		if(chkmin(Min,f[1][i]))
			num=i;
	printf("%d\n",Min);
	int x=1,y=num;
	dfs_ans(x,y,0);
	REP(i,1,e>>1) printf("%d%c",ans[i],i==iend?'\n':' ');
/*	cout<<Min<<endl;
	REP(i,1,n){
		memset(vis,0,sizeof(vis));
		for(int i=Begin[i];i;i=Next[i]){
			if(vis[ans[(i+1)>>1]])
				printf("NO\n");
			vis[ans[(i+1)>>1]]=0;
		}
	}
*/
	return 0;
}
