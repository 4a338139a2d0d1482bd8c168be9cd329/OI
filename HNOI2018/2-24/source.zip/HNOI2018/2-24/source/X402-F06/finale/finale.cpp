#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int mod=998244353;
int n,m,ans;
int a[8],vis[8];
bool check(){
	REP(i,1,n){
		int j=(i+m-2)%n+1;
		memset(vis,0,sizeof(vis));
		if(j>=i) REP(k,i,j) vis[a[k]]=1;
		else{
			REP(k,i,n) vis[a[k]]=1;
			REP(k,1,j) vis[a[k]]=1;
		}
		int num=0;
		REP(i,1,m) num+=vis[i];
		if(num==m) return 0;
	}
	return 1;
}
void dfs(int x){
	if(x>n){
		ans+=check();
		return;
	}
	REP(i,1,m) a[x]=i,dfs(x+1);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
#endif
	n=read(),m=read();
	if(n<=7){
		dfs(1);
		printf("%d\n",ans);
	}
	else if(m==2) printf("2\n");
	else printf("1\n");
	return 0;
}
