#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=200+10,maxk=1000+10,mod=1e9+7;
int ans;
int d[6];
int n,m,k;
bool check(int x){
	DREP(i,x,1) if((i>m && (d[i]&1)) || (i<=m && !(d[i]&1))) return 0;
	return 1;
}
void dfs(int x,int lstx,int lsty){
	if(!check(lstx-1)) return;
	if(x>k){
		if(check(n)){
			ans++;
		}
		return;
	}
	REP(i,lsty+1,n){
		d[lstx]++;
		d[i]++;
		dfs(x+1,lstx,i);
		d[lstx]--;
		d[i]--;
	}
	REP(i,lstx+1,n-1)
		REP(j,i+1,n){
			d[i]++,d[j]++;
			dfs(x+1,i,j);
			d[i]--,d[j]--;
		}
}
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
#endif
	n=read(),m=read(),k=read();
	if(m&1){
		printf("0\n");
		return 0;
	}
	if(k>1ll*n*(n-1)/2){
		printf("0\n");
		return 0;
	}
	if(n<=5){
		dfs(1,1,1);
		printf("%d\n",ans);
		return 0;
	}
	printf("0\n");
	return 0;
}
