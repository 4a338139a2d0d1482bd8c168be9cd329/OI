#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,f[1012],a[1012],ans=0;
const int mod=998244353;
int check(){
	for (int i=n+1;i<=n*2;i++)
	  a[i]=a[i-n];
	for (int i=1;i<=n;i++)
	{
	  int tot=0;
	  for (int j=1;j<=m;j++)
	    f[j]=0;
	  for (int j=i;j<=i+m-1&&j<=n*2;j++)
	    if (!f[a[j]])
	      f[a[j]]=1,tot++;
	  if (tot==m)
	    return false;
	}
	return true;
}

void doing(int pos){
	if (pos==n+1)
	{
	  if (check())
	    ans++;
	  return ;
	}
	for (int i=1;i<=m;i++)
	{
	  a[pos]=i;
	  doing(pos+1);
	}
}

long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	scanf("%d%d",&n,&m);
	if (n<=7)
	{
	  doing(1);
	  printf("%d\n",ans);
	  return 0;
	}
	if (m==1)
	{
	  printf("%d\n",0);
	  return 0;
	}
	if (m==2)
	{
	  printf("%d\n",2);
	  return 0;
	}
	if (m==3)
	{
	  long long ans=mi(2,n);
	  ans=(ans-1+mod)%mod;
	  ans=ans*3;
	  printf("%lld\n",ans);
	  return 0;
	}
	if (m==4)
	{
	  long long ans=mi(4,n);
	  printf("%lld\n",ans);
	  return 0;
	}
	return 0;
}
