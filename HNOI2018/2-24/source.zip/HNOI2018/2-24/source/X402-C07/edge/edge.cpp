#include<cstdio>
#include<algorithm>
using namespace std;

int ans=0,n,m,k,du[100012],q[1012][1012];

int check(){
	for (int i=1;i<=m;i++)
	  if (du[i]%2!=1)
	    return false;
	for (int i=m+1;i<=n;i++)
	  if (du[i]%2!=0)
	    return false;
	return true;
}

void doing(int pos,int begi,int begj){
	if (pos==k+1)
	{
	  if (check())
	    ans++;
	  return ;
	}
	for (int i=begi;i<=n;i++)
	{
	  int p;
	  if (i==begi)
	    p=begj;
	  else
	    p=i+1;
	  for (int j=p;j<=n;j++)
	  	if (!q[i][j])
	    {
		  q[i][j]=q[j][i]=1;
		  du[i]++,du[j]++;
	      doing(pos+1,i,j+1);
	      du[i]--,du[j]--;
	      q[i][j]=q[j][i]=0;
	    }
	}
}

int main(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if (m%2==1)
	{
	  printf("%d\n",0);
	  return 0;
	}
	if (m==0&&k==0)
	{
	  printf("%d\n",1);
	  return 0;
	}
	if (m==2&&k==1)
	{
	  printf("%d\n",1);
	  return 0;
	}
	doing(1,1,2);
	printf("%d\n",ans);
	return 0;
}
