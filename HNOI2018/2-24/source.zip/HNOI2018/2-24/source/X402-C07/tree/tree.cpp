#include<cstdio>
#include<algorithm>
using namespace std;

int f[1012][1012],aa[1012],bb[1012];
int n,m=0,ans=0,c[1012],du[1012];
int tot=1e9,t[1012];

struct node{
	int a,b,id;
	bool operator<(const node &aa) const{
	  return du[a]>du[aa.a]||(du[aa.a]==du[a]&&a<aa.a)||(du[aa.a]==du[a]&&a==aa.a&&b<aa.b);
	}
}q[1012];

void doing(int pos){
	if (ans>=tot)
	  return ;
	if (pos==n)
	{
	  if (ans<tot)
	  {
	  	tot=ans;
	  	for (int i=1;i<=n-1;i++)
	  	  t[i]=c[i];
	  }
	  return ;
	}
	int a=q[pos].a,b=q[pos].b;
	for (int i=1;i<=m;i++)
	{
	  if (f[a][i])
	    continue;
	  if (f[b][i])
	    continue;
	  f[a][i]=f[b][i]=1;
	  c[pos]=i;
	  ans+=i;
	  doing(pos+1);
	  ans-=i;
	  c[pos]=0;
	  f[a][i]=f[b][i]=0;
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n-1;i++)
	{
	  q[i].id=i;
	  scanf("%d%d",&q[i].a,&q[i].b);
	  int a=q[i].a,b=q[i].b;
	  du[a]++,du[b]++;
	  m=max(m,du[a]);
	  m=max(m,du[b]);
	}
	sort(q+1,q+1+n-1);
	doing(1);
	printf("%d\n",tot);
	for (int i=1;i<=n-1;i++)
	  c[q[i].id]=t[i];
	printf("%d",c[1]);
	for (int i=2;i<=n-1;i++)
	  printf(" %d",c[i]);
	return 0;
}
