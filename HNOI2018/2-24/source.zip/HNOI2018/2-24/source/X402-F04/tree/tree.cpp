//2018-2-24
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (150 + 5)
const int oo = 0x3f3f3f3f;

struct node{
	int id, v;
};

int n, m, f[N][N], ans[N], line[N], id[N], w[N];
vector<node> G[N];
vector<int> pt[N][N];

#define v G[now][i].v

void Dfs(int now, int F){
	int tot, nn = 0;
	For(i, 0, G[now].size() - 1) if(v != F) Dfs(v, now);
	For(i, 0, G[now].size() - 1) if(v != F) line[++nn] = v, w[v] = nn;

	For(i, 1, m){
		if(now == 1) i = 0;

		For(j, 1, nn){
			id[j] = id[j - 1] + 1; if(id[j] == i) ++id[j];
		}
		
		f[now][i] = oo; int CNT = 0;
		do{
			if(++CNT > 1e7) break;
			tot = 0;
			For(j, 1, nn) tot += f[line[j]][id[j]];
			
			if(tot < f[now][i]){
				pt[now][i].clear();
				For(j, 1, nn) pt[now][i].pb(id[j]);
				f[now][i] = tot;
			}
		}while(next_permutation(id + 1, id + nn + 1));
	
		f[now][i] += i;
		if(!i) break;
	}
}

void Getans(int now, int F, int o){
//	printf("pt[%d][%d].size() = %d\n", now, o, (int)pt[now][o].size());
	For(i, 0, G[now].size() - 1) if(v != F){
		Getans(v, now, pt[now][o][w[v] - 1]);
		ans[G[now][i].id] = pt[now][o][w[v] - 1];
	}
}

#undef v

int main(){
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	int u, v;

	scanf("%d", &n);
	For(i, 1, n - 1){
		scanf("%d%d", &u, &v);
		G[u].pb((node){i, v}); G[v].pb((node){i, u});
	}
	For(i, 1, n) m = max(m, (int)G[i].size());

	Dfs(1, 0);
	printf("%d\n", f[1][0]);
	
	Getans(1, 0, 0);
	For(i, 1, n - 1) printf("%d%c", ans[i], i == n - 1? '\n': ' ');
	
//	int Tot = 0;
//	For(i, 1, n - 1) Tot += ans[i];
//	printf("Tot = %d\n", Tot);

	return 0;
}
