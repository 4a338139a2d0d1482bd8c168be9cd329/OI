//2018-2-24
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define Set(a, v) memset(a, v, sizeof a)
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

const int P = 998244353;

int n, m, col[10], tot[10], ans;

bool Check(){
	Set(tot, 0);

	int cnt = 0;
	For(i, 1, m){
		++tot[col[i]];
		if(tot[col[i]] > 1) ++cnt;
	}
	if(!cnt) return false;
	
	col[n + 1] = col[1];
	For(i, m + 1, n + 1){
		--tot[col[i - m]];
		if(tot[col[i - m]] == 1) --cnt;
		++tot[col[i]];
		if(tot[col[i]] > 1) ++cnt;
		if(!cnt) return false;
	}

//	For(i, 1, n) printf("%d ", col[i]); puts("");
	return true;
}

void Dfs(int now){
	if(now > n){
		ans += Check(); return;
	}

	For(i, 1, m){
		col[now] = i; Dfs(now + 1);
	}
}

void Bf(){
	Dfs(1);
	printf("%d\n", ans);
}

int main(){
	freopen("finale.in", "r", stdin);
	freopen("finale.out", "w", stdout);
	
	scanf("%d%d", &n, &m);	
	
	if(m == 2){
		puts("2"); return 0;
	}
	Bf();
	

	return 0;
}
