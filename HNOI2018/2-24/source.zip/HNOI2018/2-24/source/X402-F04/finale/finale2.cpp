//2018-2-24
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define Set(a, v) memset(a, v, sizeof a)
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1024 + 5)
const int P = 998244353;

int n, nn, m;
bool vis[10];

int toz[20000][10], siz[20000];

bool Check(int now){
	Set(vis, 0);
	int t, tmp = nn + 1;

	while(tmp){
		vis[t = now / tmp + 1] = true;
		now -= (t - 1) * tmp; tmp /= m;
	}
	For(i, 1, m) if(!vis[i]) return true;
	return false;
}

void Bf(){
	if(m > n){
		int ans = 1;
		For(i, 1, n) ans *= m;
		printf("%d\n", ans); return;
	}

	For(i, 0, nn) For(j, 1, m) if(Check(i * m + j)){
		toz[i][++siz[i]] = (i * m + j) / (nn + 1);
	}
	
	For(st, 0, nn) if(siz[st]){
		For(i, m, n){
			
		}
	}
}

struct Matrix{
	int h[N][N];
}

int main(){
	freopen("finale.in", "r", stdin);
	freopen("finale.out", "w", stdout);
	
	scanf("%d%d", &n, &m);	
	
	nn = 1;
	For(i, 1, m - 1) nn *= m;
	--nn;

	if(m == 2){
		puts("2"); return 0;
	}
	if(n <= 2000){
		Bf(); return 0;
	}

	For(i, 0, nn) For(j, 1, m){
		vis[j] = true;
		For(k, 1, m - 1)
	}

	return 0;
}
