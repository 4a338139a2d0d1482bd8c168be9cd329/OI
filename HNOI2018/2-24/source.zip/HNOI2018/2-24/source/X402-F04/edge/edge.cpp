//2018-2-24
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (1000 + 5)

int n, m, rk, dig[N], ans;

void Dfs(int now, int v, int rem){
	if(v > n) ++now, v = now + 1;
	if(now >= n){
		if(rem) return;
		For(i, 1, m) if(!(dig[i] & 1)) return;
		For(i, m + 1, n) if(dig[i] & 1) return;
		++ans; return;
	}

	For(i, v, n){
		++dig[now]; ++dig[i];
		Dfs(now, i + 1, rem - 1);
		--dig[now]; --dig[i];
	}
	Dfs(now + 1, now + 2, rem);
}

int main(){
	freopen("edge.in", "r", stdin);
	freopen("edge.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &rk);
	Dfs(1, 2, rk);
	printf("%d\n", ans);

	return 0;
}
