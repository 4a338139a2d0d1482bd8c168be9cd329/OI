#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int v[10010],a[100010],n,m,ans=0;
int pd(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)v[j]=0;
	    for(int j=1;j<=m;j++)
	        v[a[(i+j-1+n)%n+1]]++;
	    int d=0;
	    for(int j=1;j<=m;j++)
	         if(v[j]>=2)d=1;
	    if(d==0)return 0;
	}
	return 1;
}
void dfs(int x){
	if(x==n+1){
		if(pd())ans++;
		return;
	}
	for(int i=1;i<=m;i++){
	    a[x]=i;
	    dfs(x+1);
	}
}
int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&n,&m);
	if(n<=7){
	    dfs(1);
	    printf("%d\n",ans);
	    return 0;
	}
	if(m==2){
		printf("2\n");
		return 0;
	}
	return 0;
}

