#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int n,v[100010],hg[100010],q[100010],f[100010],k,m,ans=0;
int pd(int d){
	for(int i=1;i<=n;i++)v[i]=0;
	int sum=0;
	for(int i=2;i<=n;i++){
	     for(int j=1;j<=i-1;j++){
	          if(f[sum+j] && i!=j){
	              v[i]++;
	              v[j]++;
	          }
	          if(f[sum+j] && i==j)return 0;
	      }
	      sum+=i-1;
	}
	for(int i=1;i<=n;i++)hg[i]=0;
	for(int i=1;i<=n;i++)
	     if((i<=m && v[i]%2==0) || (i>m && v[i]%2==1))return 0;
	return 1;
}
void dfs(int x,int y){
	if(x==n*(n-1)/2+1){
		if(y==k && pd(x)){	
        	ans++;
		}
		return;
	}
	if(y>k)return; 
	f[x]=1;
	dfs(x+1,y+1);
	f[x]=0;
	dfs(x+1,y);
}
int main(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	int i,j;
	scanf("%d%d%d",&n,&m,&k);
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}

