#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int v[160][160][160],v3[100010],f2[161][161],g[100010],sum=100000010,begin1[100010],n,next1[100010],to1[100010],x[100010],y[100010],e,ans1[1010][1010],f[1010][1010],h;
struct node{
	int x,q;
}q[100010];
void add(int x,int y){
	to1[++e]=y;
	next1[e]=begin1[x];
	begin1[x]=e;
}
void dfs(int x1,int ans){
	int i,j;
	//if(x1==n)printf("%d %d\n",x1,ans);
	if(x1==n){
		if(sum>ans){
			sum=ans;
			for(i=1;i<n;i++)
			      ans1[x[i]][y[i]]=f[x[i]][y[i]];
		}
		return;
	}
	if(ans>=sum)return;
	for(i=1;i<=n;i++){
		if(!v[x[x1]][y[x1]][i] && !v[y[x1]][x[x1]][i]){
			f[x[x1]][y[x1]]=i;
			for(j=begin1[x[x1]];j;j=next1[j])v[to1[j]][x[x1]][i]++;
			for(j=begin1[y[x1]];j;j=next1[j])v[to1[j]][y[x1]][i]++;
			dfs(x1+1,ans+i);
			for(j=begin1[x[x1]];j;j=next1[j])v[to1[j]][x[x1]][i]--;
			for(j=begin1[y[x1]];j;j=next1[j])v[to1[j]][y[x1]][i]--;
		}
	}
}
int cmp(int a,int b){
	return a>b;
}
void zz(){
	int ans1=0;
	int r=0,l=1,i;
	q[0].x=1;
	q[0].q=0;
	v3[1]=1;
	while(r<l){
		int xx=q[r].x,q1=q[r].q;
		r++;
		int l1=0;
		for(i=begin1[xx];i;i=next1[i]){
		      if(!v3[to1[i]])g[++l1]=to1[i];
		      v3[to1[i]]=1;
		}
		sort(g+1,g+l1+1,cmp);
		int l2=1,sum1=1;
        while(l2<=l1){
		    if(sum1==q1)sum1++;
		    f2[xx][g[l2]]=sum1;
		    ans1+=sum1;
		    q[l].x=g[l2];
		    q[l].q=f2[xx][g[l2]];
		    l++;
		    l2++;
		    sum1++;
		}
	}
	printf("%d\n",ans1);
	for(i=1;i<n;i++)
	    printf("%d ",f2[x[i]][y[i]]);
	puts("");
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int i,j,k,m;
	scanf("%d",&n);
	for(i=1;i<n;i++){
	    scanf("%d%d",&x[i],&y[i]);
	    add(x[i],y[i]);
	    add(y[i],x[i]);
	    g[x[i]]++;
	    g[y[i]]++;
	}
	h=0;
	for(i=1;i<=n;i++)
	    h=max(h,g[i]);
	if(n<=10){
    	dfs(1,0);
	    printf("%d\n",sum);
	    for(i=1;i<n;i++)
	         printf("%d ",ans1[x[i]][y[i]]);
	}else zz();
	return 0;
}
/*
10
1 2
1 3
2 4
2 5
3 6
3 7
3 8
7 9
7 10

*/
