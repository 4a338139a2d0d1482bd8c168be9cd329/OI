/**********************************************************
	File:edge.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-24 08:48:23
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 1010
#define mod 1000000009
int n,m,k,u[N],v[N],d[N],e,ans;
void dfs(int x,int kk)
{
	if(x==e+1)
	{
		if(kk!=k)return;
		fr(i,1,m)
			if(!d[i])
				return;
		fr(i,m+1,n)
			if(d[i])
				return;
		ans++;
		return;
	}
	dfs(x+1,kk);
	d[u[x]]^=1;
	d[v[x]]^=1;
	dfs(x+1,kk+1);
	d[u[x]]^=1;
	d[v[x]]^=1;
}
int main()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	n=read();
	m=read();
	k=read();
	fr(i,1,n-1)
		fr(j,i+1,n)
		{
			e++;
			u[e]=i;
			v[e]=j;
		}
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}