/**********************************************************
	File:gen.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-24 11:05:25
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 200
int f[N],n=50;
int getf(int x)
{
	return f[x]=x==f[x]?x:getf(f[x]);
}
#include<stdlib.h>
int main()
{
	freopen("tree.in","w",stdout);
//	srand((unsigned long long)new char);
	printf("%d\n",n);
	fr(i,2,n)printf("1 %d\n",i);
/*	fr(i,1,n)f[i]=i;
	fr(i,1,n-1)
	{
		int u=rand()%n+1,v=rand()%n+1;
		while(getf(u)==getf(v))
		{
			u=rand()%n+1;
			v=rand()%n+1;
		}
		f[getf(u)]=getf(v);
		printf("%d %d\n",u,v);
	}*/
	return 0;
}