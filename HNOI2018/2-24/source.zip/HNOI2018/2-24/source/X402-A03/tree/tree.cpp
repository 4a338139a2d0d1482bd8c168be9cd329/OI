/**********************************************************
	File:tree.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-24 09:45:28
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#include<stdlib.h>
int n;
#define N 200
#define E 500
/*
int begin[N],next[N],to[N],e;
void add(int u,int v)
{
	e++;
	to[e]=v;
	next[e]=begin[u];
	begin[u]=e;
}
*/
#define fo(i,a) for(int i=begin[a];i;next[i])
namespace main1
{
	#define inf (1<<25)
	int pr[N],use[N],ans,w[N],u[N],v[N];
	void dfs(int x,int k)
	{
//			printf("%d\n- ",k);
//			fr(i,1,x-1)printf("%d%c",w[i],i==x-1?'\n':' ');
		if(k>=ans)return;
		if(x==n)
		{
			ans=k;
			fr(i,1,n-1)pr[i]=w[i];
			return;
		}
		fr(i,1,n-1)
			if(!((use[u[x]]|use[v[x]])&(1<<(i-1))))
			{
				w[x]=i;
				use[u[x]]^=(1<<(i-1));
				use[v[x]]^=(1<<(i-1));
				dfs(x+1,k+i);
				use[u[x]]^=(1<<(i-1));
				use[v[x]]^=(1<<(i-1));
			}
	}
	int main()
	{
	fr(i,1,n-1)
		{
			u[i]=read();
			v[i]=read();
		}
		ans=inf;
		dfs(1,0);
		printf("%d\n",ans);
		fr(i,1,n-1)printf("%d%c",pr[i],i==n-1?'\n':' ');
		return 0;
	}
}
namespace main2
{
	int u[N],v[N],pr[N],ans,w[N],pos[N];
	int use[N][N];
	int main()
	{
		srand((unsigned long long)new char);
		fr(i,1,n-1)
		{
			u[i]=read();
			v[i]=read();
			pos[i]=i;
		}
		ans=inf;
		fr(i,1,100000)
		{
			fr(i,1,n)
			{
				int a=rand()%(n-1)+1,b=rand()%(n-1)+1,k;
				k=u[a];u[a]=u[b];u[b]=k;
				k=v[a];v[a]=v[b];v[b]=k;
				k=pos[a];pos[a]=pos[b];pos[b]=k;
			}
			int aans=0;
			fr(i,1,n-1)
			{
				int mi=1;
				while(use[u[i]][mi]||use[v[i]][mi])mi++;
				use[u[i]][mi]=1;
				use[v[i]][mi]=1;
				w[i]=mi;aans+=mi;
			}
			fr(i,1,n-1)
			{
				use[u[i]][w[i]]=0;
				use[v[i]][w[i]]=0;
			}
			if(aans<ans)
			{
				ans=aans;
				fr(i,1,n-1)
					pr[pos[i]]=w[i];
			}
		}
//		fr(i,1,n-1)printf("%d %d\n",u[i],v[i]);
		printf("%d\n",ans);
		fr(i,1,n-1)printf("%d%c",pr[i],i==n-1?'\n':' ');
		return 0;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read();
	if(n<=10)return main1::main();
	return main2::main();
}