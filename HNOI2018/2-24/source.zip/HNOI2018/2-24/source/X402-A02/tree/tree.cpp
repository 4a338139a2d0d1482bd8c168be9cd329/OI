/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-24 08:43
#
# Filename: tree.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 11;

int n, a[maxn][maxn], Ans[maxn], f[maxn], ans;
bool vis[maxn][maxn];
int u[maxn], v[maxn];

bool pd()
{
    mem(vis);
    REP(i, 1, n - 1)
    {
        if ( vis[u[i]][f[i]] == true ) return false;
        else vis[u[i]][f[i]] = true;
        if ( vis[v[i]][f[i]] == true ) return false;
        else vis[v[i]][f[i]] = true;
    }
    return true;
}

void dfs(int x, int sum, int t)
{
    if ( sum >= ans ) return ;
    if ( x == n )
    {
        if ( pd() ) 
        {
            REP(i, 1, n - 1) Ans[i] = f[i];
            ans = sum;
        }
        return ;
    }
    REP(i, 1, t) 
    {
        f[x] = i;
        dfs(x + 1, sum + i, t);
    }
}

int main()
{
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);
    scanf("%d", &n); 
    REP(i, 1, n - 1)
    {
        scanf("%d%d", &u[i], &v[i]);
        a[u[i]][v[i]] = a[v[i]][u[i]] = 1;
    }
    ans = 1000000000;
    REP(i, 2, 9)
    {
        dfs(1, 0, i);
    }
    printf("%d\n", ans);
    REP(i, 1, n - 1) printf("%d ", Ans[i]);
    return 0;
}

