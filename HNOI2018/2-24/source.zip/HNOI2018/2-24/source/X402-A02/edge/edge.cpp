/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-24 09:37
#
# Filename: edge.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

int n, m, k;

int main()
{
    freopen("edge.in", "r", stdin);
    freopen("edge.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k); 

    return 0;
}

