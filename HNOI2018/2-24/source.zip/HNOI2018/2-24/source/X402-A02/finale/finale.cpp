/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-24 09:10
#
# Filename: finale.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 2010;

int n, m, ans;
int a[maxn], vis[maxn];

void dfs(int x)
{
    if ( x == n + 1 )
    {
        REP(i, 1, n) a[i + n] = a[i];
        REP(i, 1, n) 
        {
            mem(vis);
            int sum = 0;
            REP(j, i, i + m - 1) vis[a[j]] = 1;
            REP(j, 1, m) sum += vis[j];
            if ( sum == m ) return ;
        }
        ++ ans;
        return ;
    }
    REP(i, 1, m)
    {
        a[x] = i;
        dfs(x + 1);
    }
}

int main()
{
    freopen("finale.in", "r", stdin);
    freopen("finale.out", "w", stdout);
    scanf("%d%d", &n, &m);
    if ( m == 2 ) 
    {
        printf("2\n");
        return 0;
    }
    dfs(1);
    printf("%d\n", ans);
    return 0;
}

