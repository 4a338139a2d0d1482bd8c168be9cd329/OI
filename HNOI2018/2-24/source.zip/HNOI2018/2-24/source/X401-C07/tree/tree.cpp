#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Rep(i,j,k) for(int i=j;i<k;++i)
using namespace std;
const int maxn=160;
struct edge{
	int to,nxt,bh;
}e[maxn<<1];
int n,f[maxn],siz[maxn];
struct cdc{
	int co,bh;
}d[maxn];
int head[maxn],tot;
inline void add(int x,int y,int z){
	e[++tot].to=y;
	e[tot].bh=z;
	e[tot].nxt=head[x];
	head[x]=tot;
}
void dfs1(int x){
	for(int i=head[x];i;i=e[i].nxt){
		int to=e[i].to;
		if(to==f[x])continue;
		d[to].bh=e[i].bh;
		f[to]=x;
		dfs1(to);
		++siz[x];
	}return ;
}
bool vis[maxn],viss[maxn];
struct node{
	int w,bh,col;
    bool operator <(const node b)const{  
        return this->w>b.w;  
    }
};
vector<node>v[maxn][maxn];
priority_queue<node>q[maxn];
void dfs2(int x){
	for(int i=head[x];i;i=e[i].nxt){
		int to=e[i].to;
		if(to!=f[x])dfs2(to);
	}
	int tt=0,ww=0;
	if(x!=1)For(i,1,n){
		ww=i,tt=0;
		memset(viss,0,sizeof(viss));
		memset(vis,0,sizeof(vis));
		vis[i]=1;
		priority_queue<node>qq;
		qq=q[x];
		while(tt<siz[x]){
			node u=qq.top();qq.pop();
			if(!vis[u.col]&&!viss[u.bh]){
				v[x][i].push_back(u);
				++tt;ww+=u.w;
				vis[u.col]=1;
				viss[u.bh]=1;
			}
		}
		node u;
		u.bh=x;u.w=ww;u.col=i;
		q[f[x]].push(u);
	}
	else{
		int tt=0,ww=0;
		memset(vis,0,sizeof(vis));
		memset(viss,0,sizeof(viss));
		priority_queue<node>qq;
		qq=q[x];
		while(tt<siz[x]){
			node u=qq.top();qq.pop();
			if(!vis[u.col]&&!viss[u.bh]){
				v[x][0].push_back(u);
				++tt;ww+=u.w;
				vis[u.col]=1;
				viss[u.bh]=1;
			}
		}
		printf("%d\n",ww);
		return ;
	}
	return ;
}
void dfs3(int x){
	Rep(i,0,v[x][d[x].co].size()){
		node u=v[x][d[x].co][i];
		d[u.bh].co=u.col;
		dfs3(u.bh);
	}
}
bool cmp(cdc xx,cdc yy){
	return xx.bh<yy.bh;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int x,y;
	scanf("%d",&n);
	Rep(i,1,n){
		scanf("%d%d",&x,&y);
		add(x,y,i);
		add(y,x,i);
	}
	dfs1(1);
	dfs2(1);
	dfs3(1);
	sort(d+2,d+n+1,cmp);
	for(int i=2;i<=n;++i)
		printf("%d ",d[i].co);
	return 0;
}

