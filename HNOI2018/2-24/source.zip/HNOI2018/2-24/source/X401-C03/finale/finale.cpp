#include<bits/stdc++.h>
using namespace std;
#define LL long long

LL calc[7] = {1,1,2,6,24,120,720};
LL C[7][7] = {{1},{1,1},{1,2,1},{1,3,3,1},{1,4,6,4,1},{1,5,10,10,5,1},{1,6,15,20,15,6,1}};
const LL modn = 998244353;

LL f_pow(LL a,LL b,LL mod){
	LL ans = 1;
	while(b){
		if( b & 1 )(ans *= a) %= mod;
		( a *= a ) %= mod;
		b >>= 1;
	}
	return ans;
}

int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	LL m,n;cin >> m >> n;
	LL ans = f_pow(n-1,m,modn) * (calc[n - 1] * C[n][n - 1]) % modn;
	cout << ans;
	return 0;
}

