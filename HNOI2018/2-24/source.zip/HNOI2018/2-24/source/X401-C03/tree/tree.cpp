#include<bits/stdc++.h>
using namespace std;

vector<int>to[100005];
int minx[100005];

void dfs(int now,int last){
	int mi = 1;
	for(int i = 0;i ^ to[now].size();i ++){
		if( to[now][i] != last){
			mi ++ ;
			dfs( to[now][i],now);
		}
	}
	minx[now] = mi;
}

int main(){
	int a;cin >> a;
	for(int i = 1;i ^ a;i ++){
		int m,n;scanf("%d%d",&m,&n);
		to[m].push_back(n);
		to[n].push_back(m);
	}
	
	dfs(1,1);
	int ans = 0;
	for(int i = 1;i <= a;i ++){
		ans += ( minx[i] ) * (minx[i] - 1) / 2;
	}
	cout << ans;
	return 0;
}

