//2018-02-24
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register int i=a;i<=b;i++)
#define Forr(i,a,b) for(register int i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
}
inline void read(ll &x)
{
	ll p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}
#define mod 998244353
ll n,m,ans;
ll a[20];
inline void check()
{
	int flag=0;
	For(i,1,n)
	{
		ll qwq[100]={0},cnt=0;
		For(j,i,min(2*n,i+m-1))if(!qwq[a[j]])qwq[a[j]]=1,cnt++;
		if(cnt==m){flag=1;break;}

	}
	if(!flag)ans++;
}
void dfs(int x)
{
	if(x==n+1)
	{
		check();
		return;
	}
	else
	{
		For(i,1,m)
		{
			a[x]=a[x+n]=i;
			dfs(x+1);
		}
	}
}
int main()
{
	File();
	read(n),read(m);
	if(m==2){puts("2");return 0;}

		dfs(1);
		printf("%lld\n",ans%mod);

	return 0;
}
