//2018-02-24
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register int i=a;i<=b;i++)
#define Forr(i,a,b) for(register int i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
}
inline void read(int &x)
{
	int p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}

int main()
{
 	File();
	puts("0"); 
	return 0;
}


