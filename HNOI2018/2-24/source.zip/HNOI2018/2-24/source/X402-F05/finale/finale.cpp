#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1510;
const int Mod = 998244353;

int sz;

struct Matrix {

	const static int SZ = 230;
	
	int A[SZ][SZ];

	Matrix(int id = 0) {
		For(i, 0, sz) For(j, 0, sz) A[i][j] = 0;
		if (id == 1) For(i, 0, sz) A[i][i] = 1;
	}

	inline int* operator[] (int x) { return A[x]; }
	inline const int* operator[] (int x) const { return A[x]; }

	Matrix operator * (const Matrix& B) const {
		Matrix C;
		For(i, 0, sz) For(j, 0, sz) if (A[i][j])
			For(k, 0, sz) C[i][k] = (C[i][k] + 1ll * A[i][j] * B[j][k]) % Mod;
		return C;
	}

	Matrix operator ^ (int e) {
		Matrix x = *this, ret(1);
		while (e) {
			if (e & 1) ret = ret * x;
			x = x * x;
			e >>= 1;
		}
		return ret;
	}

}trans;

int n, m;
int G[N][N];

int getid(int *A) {
	int val = 0;
	For(i, 1, m - 1) {
		val = val * (m + 1) + A[i];
		if (!A[i]) A[i + 1] = 0;
	}
	return val;
}

int st[N][10];
int id[1000010];
int P[10];
int vis[10];

void DFS_init(int i) {
	if (i > 1) {
		P[i] = 0;
		id[getid(P)] = ++sz;
		For(x, 1, m - 1) st[sz][x] = P[x];
	}
	if (i == m) return;
	For(x, 1, m) if (!vis[x]) {
		vis[x] = true;
		P[i] = x;
		DFS_init(i + 1);
		vis[x] = false;
	}
}

int ans;
int val[20], g[20];

void DFS_work(int i) {
	if (i == m) {
		For(j, 1, m) vis[j] = false;
		For(j, 1, m - 1) val[j] = P[j] = g[j], assert(P[j]);
		
		For(j, 1, m - 1) P[j] = vis[P[j]] ? 0 : P[j], vis[P[j]] = true;
		int o = id[getid(P)];
		For(j, 1, sz) {
			int c = m - 1;
			For(k, 1, m - 1) if (st[j][k]) val[++c] = st[j][k];

			bool ok = true;
			For(l, 1, c - m + 1) {
				bool flag = false;
				For(k, 1, m) vis[k] = false;
				For(k, 0, m - 1) {
					if (!val[l + k]) continue;
					if (vis[val[l + k]]) { flag = true; break; }
					vis[val[l + k]] = true;
				}
				if (!flag) { ok = false; break; }
			}

			if (ok) (ans += G[o][j]) %= Mod;
		}

		return;
	}
	For(x, 1, m) {
		g[i] = x;
		DFS_work(i + 1);
	}
}

int main() {

	freopen("finale.in", "r", stdin);
	freopen("finale.out", "w", stdout);

	scanf("%d%d", &n, &m);

	if (n < m) {
		ans = 1;
		For(i, 1, n) ans *= m;
		printf("%d\n", ans);
		return 0;
	}

	DFS_init(1);

	For(i, 1, sz) For(j, 1, m) {
		P[1] = j;
		For(k, 2, m) P[k] = st[i][k - 1] == P[1] || !P[k - 1] ? 0 : st[i][k - 1];
		if (P[m]) continue;
		int x = id[getid(P)];
		if (x) G[i][x]++;
	}

	For(i, 1, sz) For(j, 1, sz) trans[i][j] = G[i][j];
	trans = trans ^ (n - m + 1);
	For(i, 1, sz) For(j, 1, sz) G[i][j] = trans[i][j];

	DFS_work(1);
	printf("%d\n", ans);

	return 0;
}
