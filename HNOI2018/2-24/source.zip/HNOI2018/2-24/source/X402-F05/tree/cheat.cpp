#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 155;

int Begin[N], Next[N << 1], to[N << 1], id[N << 1], e = 1;

void add(int u, int v, int w) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e, id[e] = w;
}

int n;
int ans, col[N];
int w[N];
bool vis[N];

void DFS(int o, int ban, int f) {
	int ch = 0;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (i == (f ^ 1)) continue;
		if (++ch == ban) ++ch;
		w[id[i]] = ch;
		DFS(u, ch, i);
	}
}

int main() {

	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	scanf("%d", &n);
	For(i, 2, n) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v, i - 1), add(v, u, i - 1);
	}

	ans = 1e9;
	For(i, 1, n) {
		memset(w, 0, sizeof w);
		DFS(i, 0, 0);
		int ret = 0;
		For(j, 1, n - 1) ret += w[j];
		if (ret < ans) {
			ans = ret;
			For(j, 1, n - 1) col[j] = w[j];
		}
	}

	printf("%d\n", ans);
	For(i, 1, n - 1) printf("%d%c", col[i], i == n ? '\n' : ' ');

	return 0;
}
