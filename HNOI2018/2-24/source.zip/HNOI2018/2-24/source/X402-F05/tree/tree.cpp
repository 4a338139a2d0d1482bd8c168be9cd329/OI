#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 155;
const int C = 15;

int Begin[N], Next[N << 1], to[N << 1], id[N << 1], e = 1;

void add(int u, int v, int w) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e, id[e] = w;
}

int n;

namespace BF {

	int f[N][N], st[N];
	int dp[C][1 << C], pre[C][1 << C];
	int p[N][N][N];
	int col[N];

	void DFS(int o, int fa) {
		
		for (int i = Begin[o]; i; i = Next[i]) {
			int u = to[i];
			if (u == fa) continue;
			DFS(u, o);
		}

		memset(dp[0], 0x3f, sizeof dp[0]);
		dp[0][0] = 0;
		int ch = 0;
		for (int ed = Begin[o]; ed; ed = Next[ed]) {
			int u = to[ed];
			if (u == fa) continue;
			++ch;
			memset(dp[ch], 0x3f, sizeof dp[ch]);
			for (int i = (1 << C) - 1; i; --i) {
				int &x = dp[ch][i];
				if (__builtin_popcount(i) != ch) continue; 
				For(k, 0, C - 1) if (i & (1 << k)) {
					int w = dp[ch - 1][i ^ (1 << k)] + f[u][k];
					if (w < x) x = w, pre[ch][i] = k;
				}
			}
		}

		memset(f[o], 0x3f, sizeof f[o]);
		for (int i = 0; i < (1 << C) - 1; ++i) {
			int x = dp[ch][i];
			if (x > 1e9) continue;
			For(j, 0, C - 1) if (!(i & (1 << j))) {
				int w = !fa ? x : x + j + 1;
				if (w < f[o][j]) f[o][j] = w, st[j] = i;
			}
		}

		For(i, 0, C - 1) {
			//printf("%d%c", f[o][i], i == C - 1 ? '\n' : ' ');
			int s = st[i], c = ch;
			while (s) {
				p[o][i][c] = pre[c][s];
				s ^= 1 << pre[c][s], --c;
			}
		}
	}

	void getans(int o, int g, int fa) {
		int c = 0;
		for (int i = Begin[o]; i; i = Next[i]) {
			int u = to[i];
			if (u == fa) continue;
			++c;
			col[id[i]] = p[o][g][c];
			getans(u, p[o][g][c], o);
		}
	}

	void main() {
		DFS(1, 0);
		int ans = 1e9, pos = 0;
		For(i, 0, C - 1) if(ans > f[1][i]) ans = f[1][i], pos = i;
		printf("%d\n", ans);
		getans(1, pos, 0);
		For(i, 1, n - 1) printf("%d%c", col[i] + 1, i == n - 1 ? '\n' : ' ');
	}

};

int deg[N];

namespace Cheat {

	int w[N];
	vector<int> c[N];

	void main() {
		For(i, 1, n - 1) w[i] = 1;
		while (true) {
			bool ok = true;
			For(i, 1, n) {
				for (int j = Begin[i]; j; j = Next[j])
					c[w[id[j]]].push_back(j);
				for (int j = Begin[i]; j; j = Next[j]) {
					int x = w[id[j]];
					if (c[x].size() > 1) {
						ok = false;
						int sz = int(c[x].size()) - 1, mx = 0, p = 0;
						For(k, 0, sz) if (deg[to[c[x][k]]] > mx) {
							mx = deg[to[c[x][k]]];
							p = c[x][k];
						}
						w[id[p]]++;
					}
					c[x].clear();
				}
			}
			if (ok) break;
		}
		int ans = 0;
		For(i, 1, n - 1) ans += w[i];
		printf("%d\n", ans);
		For(i, 1, n - 1) printf("%d%c", w[i], i == n - 1 ? '\n' : ' ');
	}
};

int main() {

	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	scanf("%d", &n);
	For(i, 2, n) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v, i - 1), add(v, u, i - 1);
		++deg[u], ++deg[v];
	}

	bool low_deg = true;
	For(i, 1, n) if (deg[i] >= C) { low_deg = false; break; }
	if (low_deg) BF::main();
	else Cheat::main();

	return 0;
}
