#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int Mod = 1e9 + 7;
const int N = 12;

int n, m, k;
int dp[2][1 << N][N * N / 2];

void add(int &x, int y) {
	x += y;
	if (x >= Mod) x -= Mod;
}

int main() {

	freopen("edge.in", "r", stdin);
	freopen("edge.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);

	int s = 0, c = 0;
	dp[s][0][0] = 1;
	For(u, 0, n - 1) For(v, u + 1, n - 1) {
		For(i, 0, (1 << n) - 1) For(j, 0, c) {
			int &x = dp[s][i][j];
			if (!x) continue;
			add(dp[s ^ 1][i ^ (1 << u) ^ (1 << v)][j + 1], x);
			add(dp[s ^ 1][i][j], x);
			x = 0;
		}
		++c;
		s ^= 1;
	}
	printf("%d\n", dp[s][(1 << m) - 1][k]);

	return 0;
}
