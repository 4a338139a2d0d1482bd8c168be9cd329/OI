#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int Mod=998244353;
int n,m,tmp[18],ans,pot[7];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void write(int x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
inline void chkmin(int &x,int y){x=(y<x?y:x);}
inline void chkmax(int &x,int y){x=(y>x?y:x);}
inline bool check()
{
	for(register int i=n+1;i<=n*2;++i)tmp[i]=tmp[i-n];
	for(register int l=1;l+m-1<=n*2;++l)
	{
		int r=l+m-1,mark=1;
		memset(pot,0,sizeof(pot));
		for(register int i=l;i<=r;++i)pot[tmp[i]]++;
		for(register int i=1;i<=m;++i)
			if(pot[i]!=1)
			{
				mark=0;
				break;
			}
		if(mark)return false;
	}
	return true;
}
inline void dfs(int x)
{
	if(x>n)
	{
		if(check())ans++;
		return ;
	}
	for(register int i=1;i<=m;++i)tmp[x]=i,dfs(x+1);
}
inline void bf()
{
	dfs(1);
	write(ans,'\n');
}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
int main()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	read(n);read(m);
	if(m==2)write(2,'\n');
	if(m==3)write((int)((qexp(2,n)-1)%Mod*m%Mod),'\n');
	else bf();
	return 0;
}
