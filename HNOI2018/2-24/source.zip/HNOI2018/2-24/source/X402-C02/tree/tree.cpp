#include<bits/stdc++.h>
using namespace std;
const int MAXN=20+5,inf=0x3f3f3f3f;
int n,e,to[MAXN<<1],beg[MAXN],nex[MAXN<<1],w[MAXN<<1],ans[MAXN],color[MAXN],res=inf;
struct node{
	int u,v,col;
};
node side[MAXN];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void write(int x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
inline void chkmin(int &x,int y){x=(y<x?y:x);}
inline void chkmax(int &x,int y){x=(y>x?y:x);}
inline void insert(int x,int y,int z)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}
inline bool tdfs(int x,int f)
{
	memset(color,0,sizeof(color));
	for(register int i=beg[x];i;i=nex[i])
		if(color[side[w[i]].col])return false;
		else color[side[w[i]].col]=1;
	for(register int i=beg[x];i;i=nex[i])
		if(to[i]==f)continue;
		else if(!tdfs(to[i],x))return false;
	return true;
}
inline void chkans(int was)
{
	if(was<res)
	{
		res=was;
		for(register int i=1;i<n;++i)ans[i]=side[i].col;
	}
}
inline void dfs(int x,int was)
{
	if(was>=res)return ;
	if(x>=n)
	{
		if(tdfs(1,0))chkans(was);
		return ;
	}
	for(register int i=1;i<=n&&was+i<=res;++i)side[x].col=i,dfs(x+1,was+i);
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n);
	for(register int i=1;i<n;++i)
	{
		int u,v;
		read(u);read(v);
		insert(u,v,i);
		insert(v,u,i);
		side[i].u=u,side[i].v=v;
	}
	dfs(1,0);
	write(res,'\n');
	for(register int i=1;i<n;++i)write(ans[i],' ');
	return 0;
}
