#include<bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(),(x).end()

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef pair<int,int> PII;

const int maxn=160,INF=0x3f3f3f3f;

int n,ans;
int c[maxn];

int head[maxn],nxt[maxn<<1],to[maxn<<1],e;
int deg[maxn];
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}

int Id[maxn][maxn];

int tmp[maxn];

int dfs(int u,int fa,int col){
    int res=0;
    vector<PII> t;
    vector<int> w;

    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(v!=fa) t.pb(mp(deg[v],v));
    }

    sort(ALL(t),greater<PII>());

    int cur=1;
    for(int i=0;i<SZ(t);i++){
        if(cur==col) ++cur;
        res+=cur; w.pb(cur++);
    }

    sort(ALL(w),greater<int>());

    for(int i=0;i<SZ(t);i++) tmp[Id[u][t[i].second]]=w[i];
    for(int i=0;i<SZ(t);i++) res+=dfs(t[i].second,u,w[i]);

    return res;
}

int main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);

    read(n);

    for(int i=1;i<n;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ae(v,u);
        Id[u][v]=Id[v][u]=i;
        ++deg[u]; ++deg[v];
    }

    ans=INF;
    for(int i=1;i<=n;i++){
        memset(tmp,0,sizeof tmp);
        if(chkmin(ans,dfs(i,0,0))) memcpy(c,tmp,sizeof tmp);
    }

    printf("%d\n",ans);
    for(int i=1;i<n;i++) printf("%d ",c[i]);

    return 0;
}
