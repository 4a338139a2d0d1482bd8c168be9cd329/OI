#include<bits/stdc++.h>

using namespace std;

#define mp make_pair

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef pair<int,int> PII;

const int maxn=10,maxm=15;

int n,m,k,ans;

PII Id[maxm];
int cnt;
bool deg[maxn];

int main(){
    freopen("edge.in","r",stdin);
    freopen("edge.out","w",stdout);
    
    read(n); read(k); read(m);

    for(int i=1;i<n;i++)
        for(int j=i+1;j<=n;j++) Id[++cnt]=mp(i,j);

    int all=1<<cnt;

    for(int s=0;s<all;s++) if(__builtin_popcount(s)==m){
        memset(deg,0,sizeof deg);
        for(int i=1;i<=cnt;i++) if((s>>(i-1))&1){
            deg[Id[i].first]^=1;
            deg[Id[i].second]^=1;
        }

        bool flag=1;
        for(int i=1;i<=k;i++) if(!deg[i]){ flag=0; break; }
        for(int i=k+1;i<=n;i++) if(deg[i]){ flag=0; break; }
        if(flag) ++ans;
    }

    printf("%d\n",ans);

    return 0;
}
