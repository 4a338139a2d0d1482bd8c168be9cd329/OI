#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=8,mo=998244353;

int n,m,ans,a[maxn];

bool check(){
    int col[maxn];
    for(int i=1;i<=n;i++){
        memset(col,0,sizeof col);
        for(int j=i;j<=i+6;j++) ++col[a[(j-1)%n+1]];
        bool flag=1;
        for(int j=1;j<=m;j++) if(!col[j]){ flag=0; break; }
        if(flag) return 0;
    }
    return 1;
}

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

void dfs(int u){
    if(u==n+1) return void(ans+=check());
    for(int i=1;i<=m;i++) a[u]=i,dfs(u+1);
}

int main(){
    freopen("finale.in","r",stdin);
    freopen("finale.out","w",stdout);

    read(n); read(m);

    if(n<=7){ dfs(1); printf("%d\n",ans); }
    else if(m==2) puts("2");
    else printf("%lld\n",1ll*((fpm(2,n)-1)%mo+mo)%mo*3%mo);

    return 0;
}
