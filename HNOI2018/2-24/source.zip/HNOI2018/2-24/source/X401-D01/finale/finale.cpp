#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	x=x*w;
}
inline void File(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
}

int n,m;

int main(){
	File();
	read(n);read(m);
	cout<<2<<endl;
	return 0;
}
