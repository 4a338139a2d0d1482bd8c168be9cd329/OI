#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	x=x*w;
}
inline void File(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}

const int maxn=160;
int n;
int e,beg[maxn],to[maxn<<1],nex[maxn<<1];
int cnt,col[maxn];
int ind[maxn];
int ans;

struct node{
	int p,k;
}sum[100000+10];

inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
inline void dfs(int x,int fa,int c){
	sum[c].p++;
	int p=0;
	for(Rint i=beg[x];i;i=nex[i]){
		int y=to[i];
		if(y==fa)continue;
		if((++p)==c)p++;
		col[i]=p;
		dfs(y,x,p);
	}
}
inline int cmp(node x,node y){
	return x.p>y.p;
}
#include<map>
map<int,int> mp;

int main(){
	File();
	read(n);
	for(Rint i=1;i<n;i++){
		int x,y;
		read(x);read(y);
		add(x,y);add(y,x);
		ind[x]++;ind[y]++;
		cnt=max(cnt,max(ind[x],ind[y]));
	}
	for(Rint i=1;i<=cnt;i++)sum[i].k=i;
	dfs(1,0,0);
	sort(sum+1,sum+1+cnt,cmp);
	for(Rint i=1;i<=cnt;i++)mp[sum[i].k]=i;
	for(Rint i=1;i<=e;i++){
		col[i]=mp[col[i]];
		ans+=col[i];
	}
	printf("%d\n",ans);
	for(Rint i=1;i<=e;i+=2){
		printf("%d ",max(col[i],col[i+1]));
	}
	return 0;
}
