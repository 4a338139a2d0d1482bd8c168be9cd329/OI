#include<bits/stdc++.h>
#define N 2100
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const int mod=1e9+7;
int n,m,k,cnt,tot;
int edge[N];
struct node
{
	int x,y;
}e[N];
void dfs(int x,int sum)
{
	if(x==cnt+1)
	{
		if(sum!=k)return ;
		for(int i=1;i<=n;i++)
		{
			if(i<=m)
			{
				if(!edge[i])return;
			}
			else if(edge[i])return ;
		}
		tot++;
		tot%=mod;
		return ;
	}
	dfs(x+1,sum);
	edge[e[x].x]^=1;edge[e[x].y]^=1;
	dfs(x+1,sum+1);
	edge[e[x].x]^=1;edge[e[x].y]^=1;
}
int main()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	read(n);read(m);read(k);
	for(int i=1;i<=n-1;i++)
		for(int j=i+1;j<=n;j++)
		{
			e[++cnt].x=i;
			e[cnt].y=j;
		}
	dfs(1,0);
	cout<<tot<<endl;
	return 0;
}
