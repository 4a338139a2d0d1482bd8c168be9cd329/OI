#include<bits/stdc++.h>
#define N 500
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n;
int to[N],beg[N],nex[N],w[N];
int a[N],maxn,ans,Ans[N],val[N];
int cnt=0;
struct node
{
	int x,y;
}e[N];
set<int>st[N];
bool flag;
void dfs(int x,int sum)
{
	if(sum>=ans)return ;
	if(x==n)
	{
		ans=min(ans,sum);
		memcpy(Ans,a,sizeof(Ans));
		return ;
	}
	for(int i=1;i<=maxn;i++)
	{
		if(st[e[x].x].count(i))continue;
		if(st[e[x].y].count(i))continue;
		a[x]=i;
		st[e[x].x].insert(i);
		st[e[x].y].insert(i);
		dfs(x+1,sum+i);
		a[x]=0;
		st[e[x].x].erase(i);
		st[e[x].y].erase(i);
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n);
	for(int i=1;i<=n-1;i++)
	{
		static int x,y;
		read(x);read(y);
		e[++cnt].x=x;e[cnt].y=y;
		val[x]++;val[y]++;
		maxn=max(maxn,val[x]);maxn=max(maxn,val[y]);
	}
	ans=0x7f7f7f7f;
	dfs(1,0);
	printf("%d\n",ans);
	for(int i=1;i<n-1;i++)
	printf("%d ",Ans[i]);
	printf("%d\n",Ans[n-1]);
	return 0;
}
