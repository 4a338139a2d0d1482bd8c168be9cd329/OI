#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
long long n,m;
long long ksm(long long x,long long mc)
{
	long long tmp=x%mod;
	long long res=1;
	while(mc)
	{
		if(mc&1)res=res*tmp%mod;
		tmp=tmp*tmp%mod;
		mc>>=1;
	}
	return res;
}
long long a[100010],tot,sum;
bool pd()
{
	for(int i=1;i<=n;i++)
	{
		static int flag=0;
		flag=0;
		for(int j=i;j<=i+m-1;j++)
			for(int k=i;k<=i+m-1;k++)
			if(j==k)continue;
			else if(a[j]==a[k]){flag=1;break;}
		if(!flag)return 0;
	}
	return 1;
}
void dfs(long long x)
{
	if(x==n+1)
	{
		sum++;
		if(!pd())tot++;
		if(sum>=mod)sum-=mod;
		if(tot>=mod)tot-=mod;
		return ;
	}
	for(long long i=1;i<=m;i++)
	{
		a[x]=i;
		a[x+n]=i;
		dfs(x+1);
		a[x]=0;
		a[x+n]=0;
	}
}
int main()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	read(n);read(m);
	if(m==2)return printf("2\n"),0;
	dfs(1);
	printf("%lld\n",((sum-tot)%mod+mod)%mod);
	return 0;
}
