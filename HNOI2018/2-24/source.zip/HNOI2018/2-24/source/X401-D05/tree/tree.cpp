#include<bits/stdc++.h>
using namespace std;
#define N 160
int n;
struct node
{
	int from,to;
}E[N<<1];
int res=0x7f7f7f7f;
int tans[N],ans[N];
bool vis[N][N];
void dfs(int step,int sum)
{
	if(sum>=res) return ;
	if(step==n)
	{
		if(sum<res)
		{
			res=sum;
			for(int i=1;i<n;++i) 
				tans[i]=ans[i];
		}
		return ;
	}
	for(int i=1;i<=n;++i) 
	{
		ans[step]=i;
		if(!vis[E[step].from][i]) vis[E[step].from][i]=1;else return ;
		if(!vis[E[step].to][i]) vis[E[step].to][i]=1;else {vis[E[step].from][i]=0;return ;}
		dfs(step+1,sum+i);
		ans[step]=0;
		vis[E[step].from][i]=0,vis[E[step].to][i]=0;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	int x,y;
	for(int i=1;i<n;++i) 
	{
		scanf("%d%d",&x,&y);
		E[i].from=x,E[i].to=y;
	}
	dfs(1,0);
	printf("%d\n",res);
	for(int i=1;i<n;++i) printf("%d ",tans[i]);
	return 0;
}
