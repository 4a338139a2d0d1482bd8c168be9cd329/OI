#include<bits/stdc++.h>
using namespace std;
#define Temp template<typename T>
Temp inline void read(T &x)
{
	x=0;char c=getchar();T f=1;
	while(!isdigit(c)) {if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

int n,m,k;
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	read(n),read(m),read(k);
	for(int i=1;i<=m;++i) 
	{
		
		
	}
	return 0;
}
