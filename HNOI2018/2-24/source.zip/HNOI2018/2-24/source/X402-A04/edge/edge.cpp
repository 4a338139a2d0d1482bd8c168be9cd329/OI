#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=1e9+7;
const int N=15;
int n,m,k,cnt=0,deg[N];
pii e[N*N];

void wj()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
}
int main()
{
	wj();
	n=read(); k=read(); m=read();
	//if(k&1) {puts("0");return 0;}
	if(n>7) {puts("0");return 0;}
	for(int i=1;i<=n;++i) for(int j=i+1;j<=n;++j) e[cnt++]=pii(i,j);
	int tot=1<<cnt,ans=0;
	for(int s=0;s<tot;++s) if(__builtin_popcount(s)==m)
	{
		for(int i=1;i<=n;++i) deg[i]=0;
		for(int i=0;i<cnt;++i) if(s&1<<i) deg[e[i].fi]++,deg[e[i].se]++;
		bool can=1;
		for(int i=1;i<=k;++i) if(!(deg[i]&1)) {can=0;break;}
		for(int i=k+1;i<=n;++i) if(deg[i]&1) {can=0;break;}
		ans+=can;
	}
	printf("%d\n",ans);
	return 0;
}
