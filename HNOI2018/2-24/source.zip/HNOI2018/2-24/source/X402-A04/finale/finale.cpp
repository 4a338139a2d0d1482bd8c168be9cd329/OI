#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
//#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int M=11;
const int TOT=301;
const int mod=998244353;

int n,m,pw[11];
bool cant[TOT];
int tot;

int mat[TOT][TOT],V[TOT][TOT],C[TOT][TOT];

void mul1()
{
	for(int i=0;i<tot;++i) for(int j=0;j<tot;++j) C[i][j]=0;
	for(int i=0;i<tot;++i) for(int k=0;k<tot;++k) if(mat[i][k]) for(int j=0;j<tot;++j)
		C[i][j]=(C[i][j]+1ll*mat[i][k]*mat[k][j])%mod;
	for(int i=0;i<tot;++i) for(int j=0;j<tot;++j) mat[i][j]=C[i][j];
}
void mul2()
{
	for(int i=0;i<tot;++i) for(int j=0;j<tot;++j) C[i][j]=0;
	for(int i=0;i<tot;++i) for(int k=0;k<tot;++k) if(V[i][k]) for(int j=0;j<tot;++j)
		C[i][j]=(C[i][j]+1ll*V[i][k]*mat[k][j])%mod;
	for(int i=0;i<tot;++i) for(int j=0;j<tot;++j) V[i][j]=C[i][j];
}

int a[123];
void dfs(int r)
{
	if(r==n)
	{
		bool can=1;
		for(int i=0;i<n;++i)
		{
			int s=0,num=0;
			for(int j=i;j<=i+m-1;++j) s|=1<<a[j%n],num++;
			if(__builtin_popcount(s)==num) {can=0;break;}
		}
		a[r]+=can;
		return ;
	}
	for(int i=0;i<m;++i)
	{
		a[r]=i;
		dfs(r+1);
		a[r]=0;
	}
}

void wj()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
}
int main()
{
	wj();
	//clock_t sta=clock();
	n=read(); m=read();

	if(n<=7) {dfs(0);printf("%d\n",a[n]);return 0;}
	pw[0]=1;
	for(int i=1;i<=m+1;++i) pw[i]=pw[i-1]*m;

	tot=pw[m];
	for(int s=0;s<pw[m];++s)
	{
		int S=0;
		for(int i=0;i<m;++i) S|=1<<(s/pw[i]%m);
		if(__builtin_popcount(S)==m) cant[s]=1;
	}
	for(int s=0;s<pw[m];++s)
	{
		if(cant[s]) continue;
		int s1=s; //s -> s1
		for(int i=0;i<m;++i) s1=s*m%pw[m]+i,mat[s1][s]=1;
	}

	for(int i=0;i<tot;++i) V[i][i]=1;
	int nn=n;
	for(;nn;nn>>=1,mul1()) if(nn&1) mul2();
	
	//for(int i=0;i<tot;++i) for(int j=0;j<tot;++j) cerr<<V[i][j]<<(j==tot-1?'\n':' ');
	int ans=0;
	for(int s=0;s<tot;++s) if(!cant[s])
		ans=(ans+V[s][s])%mod;
	printf("%d\n",ans);

	//clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
