#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=165;
const int inf=0x3f3f3f3f;
int head[N],cnt=1;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int n;

namespace bf
{
	int col[N<<1],minn=inf;
	int plan[N<<1];
	void check()
	{
		for(int u=1;u<=n;++u)
		{
			int s=0,num=0;
			for(int i=head[u];i;i=e[i].next) {s|=1<<col[i];num++;}
			if(__builtin_popcount(s)!=num) return ;
		}
		int ans=0;
		for(int i=2;i<=cnt;i+=2) ans+=col[i];
		if(ans<minn)
		{
			minn=ans;
			for(int i=2;i<=cnt;i+=2) plan[i]=col[i];
		}
	}
	void dfs(int r)
	{
		if(r==cnt+1)
		{
			check();
			return ;
		}
		for(int i=1;i<n;++i)
		{
			col[r]=col[r^1]=i;
			dfs(r+2);
		}
	}
	void solve()
	{
		dfs(2);
		printf("%d\n",minn);
		for(int i=2;i<=cnt;i+=2) printf("%d ",plan[i]);
	}
}

int f[N][N],g[23][1<<20|1],G[23][1<<20|1];
int h[N][N],F[N][N][N],S[23][1<<20|1],ssum[23],deg[N];
int maxd,tot,dsa;

void dfs(int u,int fa)
{
	int num=0,c[25];
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,u);
		num++;
		c[num]=v;
	}
	g[0][0]=0;
	for(int i=1;i<=num;++i) for(int qq=1,s=S[i][qq];qq<=ssum[i];qq++,s=S[i][qq])
	{
		g[i][s]=inf;
		for(int j=1;j<=maxd;++j) if(s&1<<j-1)
		{
			if(g[i-1][s^1<<j-1]+f[c[i]][j]<g[i][s])
			{
				g[i][s]=g[i-1][s^1<<j-1]+f[c[i]][j];
				G[i][s]=s^1<<j-1;
			}
		}
	}
	if(u==1) maxd++,dsa=maxd;
	for(int qq=1,s=S[num][qq];qq<=ssum[num];qq++,s=S[num][qq])
	{
		for(int j=1;j<=maxd;++j) if(!(s&1<<j-1))
		{
			if(g[num][s]+(j==dsa?0:j)<f[u][j])
			{
				f[u][j]=g[num][s]+(j==dsa?0:j);
				h[u][j]=s;
			}
		}
	}
	for(int j=1;j<=maxd;++j)
	{
		if(f[u][j]==inf) continue;
		int s=h[u][j],now=num;
		while(s)
		{
			int s0=G[now][s];
			F[u][j][now]=__builtin_ctz(s^s0)+1;
			s=s0; now--;
		}
	}
	if(u==1) maxd--;
}

int color[N<<1];
void dd(int u,int col,int pre)
{
	color[pre]=col; color[pre^1]=col;
	int num=0;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(i==(pre^1)) continue;
		num++;
		dd(v,F[u][col][num],i);
	}
}

void wj()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read();
		deg[x]++; deg[y]++;
		add(x,y);
	}
	/*if(n<=5)
	{
		bf::solve();
		return 0;
	}*/

	maxd=0;
	for(int i=1;i<=n;++i) maxd=max(maxd,deg[i]);
	tot=1<<maxd;

	for(int s=0;s<tot;++s) 
	{
		int bcnt=__builtin_popcount(s);
		S[bcnt][++ssum[bcnt]]=s;
	}
	memset(f,inf,sizeof(f));
	dfs(1,0);

	int ans=inf,wh=0;
	for(int i=1;i<=maxd+1;++i) 
	{
		if(f[1][i]<ans) ans=f[1][i],wh=i;
	}
	printf("%d\n",ans);

	dd(1,wh,0);
	for(int i=2;i<=cnt;i+=2) printf("%d ",color[i]);

	//check
	/*int sum=0;
	for(int i=2;i<=cnt;i+=2) sum+=color[i];
	if(sum!=ans) {cerr<<"ERR1";return 0;}
	bool can=1;
	for(int u=1;u<=n;++u)
	{
		int s=0,num=0;
		for(int i=head[u];i;i=e[i].next) s|=1<<color[i],num++;
		if(__builtin_popcount(s)!=num) {can=0;break;}
	}
	if(!can) {cerr<<"ERR2";return 0;}
	cerr<<"YES";*/
	return 0;
}
