#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
}
int n,m,k,deg[N],ans;
inline int check()
{
	For(i,1,m)if(!(deg[i]&1))return 0;
	For(i,m+1,n)if(deg[i]&1)return 0;
	return 1;
}
inline void dfs(int now,int tot)
{
	if(tot>k)return;
	if(now==n+1){ans+=tot==k?check():0;return;}
	For(i,0,(1<<(now-1))-1)
	{
		int cnt=0;
		For(j,1,n)
		if(i&(1<<(j-1)))
			deg[j]++,deg[now]++,cnt++;
		dfs(now+1,tot+cnt);
		For(j,1,n)
		if(i&(1<<(j-1)))
			deg[j]--,deg[now]--;
	}
}
int main()
{
	file();
	read(n),read(m),read(k);
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}
