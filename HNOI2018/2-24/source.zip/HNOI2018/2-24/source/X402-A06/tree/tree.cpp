#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, rd[maxn], link[1010][1010], color[1010][1010], vis[maxn];

int Min = inf;

struct node{
	int u, v;
}edge[maxn];

void Get(){
	n = read();
	For(i, 2, n){
		int x = read(), y = read();
		++ rd[x], ++ rd[y];

		edge[i-1].u = x, edge[i-1].v = y;
		link[x][y] = link[y][x] = 1;
	}
}

int ans[maxn], a[maxn];

void check(int tot){
	for(int i = 1;i <= n; ++i){
		for(int j = 1;j <= n; ++j) vis[j] = 0;
		for(int j = 1;j <= n; ++j){
			if(i == j || !link[i][j]) continue;
			if(vis[color[i][j]]) return;
			vis[color[i][j]] = 1;
		}
	}

	Min = tot;
	For(i, 1, n - 1) ans[i] = a[i];
}

void dfs(int h,int tot){
	if(tot >= Min) return;
	if(h == n){
		check(tot);
		return;
	}
	For(i, 1, n - 1){
		color[edge[h].u][edge[h].v] = color[edge[h].v][edge[h].u] = i;
		a[h] = i;
		dfs(h+1, tot+i);
	}
}

void solve_bf(){
	Min = inf;
	dfs(1, 0);

	printf("%d\n", Min);
	For(i, 1, n - 1) printf("%d ", ans[i]); printf("\n");
}

int main(){

	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
