#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m, a[maxn], Ans, vis[maxn];

void Get(){
	n = read(), m = read();
}

void check(){
	For(i, 1, n) a[i+n] = a[i];
	For(i, 1, n){
		For(j, 1, m) vis[j] = 0;
		For(j, i, i+m-1) vis[a[j]] = 1;

		bool flag = 0;
		For(j, 1, m) if(!vis[j]){ flag = 1; break;}
		if(!flag) return ;
	}

	++ Ans;
}

void dfs(int h){
	if(h == n+1) {
		check();
		return;
	}
	For(i, 1, m){
		a[h] = i;
		dfs(h+1);
	}
}

void solve_bf(){
	if(m == 2) { puts("2"); return;}
	dfs(1);
	printf("%d\n", Ans);
}

int main(){

	freopen("finale.in", "r", stdin);
	freopen("finale.out", "w", stdout);
	
	Get();
	solve_bf();

	return 0;
}
