#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int rd[maxn], vis[1010][1010], n, k, m, Ans;

void Get(){
	n = read(), m = read(), k = read();
}

void check(){
	For(i, 1, n){
		if(i <= m){
			if(rd[i]&1){}
			else return;
		}
		else {
			if(rd[i]&1) return;
		}
	}

	++ Ans;
}

void dfs(int h,int up1,int up2){
	if(h > k){
		check();
		return;
	}

	For(i, up1, n){
		int tmp = 0;
		if(i == up1) tmp = up2;
		else tmp = i+1;

		For(j, tmp, n){
			if(vis[i][j]) continue;
			vis[i][j] = 1;
			++ rd[i], ++ rd[j];

			dfs(h+1, i, j+1);

			-- rd[i], -- rd[j];
			vis[i][j] = 0;
		}
	}
}

void solve_bf(){
	dfs(1, 1, 2);
	printf("%d\n", Ans);
}

int main(){

	freopen("edge.in", "r", stdin);
	freopen("edge.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
