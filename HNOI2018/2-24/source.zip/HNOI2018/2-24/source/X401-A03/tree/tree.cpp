#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
void File(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
template<typename T>T chckmax(T _,T __){return _>__ ? _ : __;}
template<typename T>T chckmin(T _,T __){return _<__ ? _ : __;}
template<typename T>
void read(T &x){
	T _=0,s=1;char __=getchar();
	while(!isdigit(__))s*=__=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	x=_*s;
}
const int maxn=50+10;
int n,len,ans[maxn],minx=0x7fffffff,c[maxn];
bool vis[maxn][maxn];
struct egde{
	int to;
	int from;
}E[maxn*2];
void add(int u,int v){
	++len;
	E[len].to=v;
	E[len].from=u;
}
void dfs(int k,int sum){
	if(sum>=minx)return;
	if(k>len){
		if(sum<minx){
			minx=sum;
			//cerr<<minx<<endl;
			REP(i,1,len)ans[i]=c[i];
		}
		return;
	}
	REP(i,1,len){
		int u=E[k].from,v=E[k].to;
		if(vis[u][i]==1 || vis[v][i]==1)continue;
		vis[u][i]=1;
		vis[v][i]=1;
		c[k]=i;
		dfs(k+1,sum+i);
		c[k]=0;
		vis[u][i]=0;
		vis[v][i]=0;
	}
}
int main(){
	File();
	read(n);
	REP(i,1,n-1){
		int u,v;
		read(u);read(v);
		add(u,v);
	}
	dfs(1,0);
	cout<<minx<<endl;
	REP(i,1,len)cout<<ans[i]<<" ";
	return 0;
}
