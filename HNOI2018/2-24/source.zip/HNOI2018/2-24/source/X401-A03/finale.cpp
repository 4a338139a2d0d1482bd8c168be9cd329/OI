#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
}
template<typename T>T chckmax(T _,T __){return _>__ ? _ : __;}
template<typename T>T chckmin(T _,T __){return _<__ ? _ : __;}
template<typename T>
void read(T &x){
	T _=0,s=1;char __=getchar();
	while(!isdigit(__))s*=__=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	x=_*s;
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
const ll mod=998244353;
const int maxn=1000+10;
const int maxm=6;
ll n,f[maxn][maxm][maxm];
int m,c[maxn],ans;
bool chck(int k){
	bool bin[maxn]={0};
	DREP(i,k,k-m+1)bin[c[i]]=1;
	REP(i,1,m)if(!bin[i])return 1;
	return 0;
}
void dfs(int k){
	if(k>n){
		REP(j,m,n+m-1)if(!chck(j))return;
		++ans;
		return;
	}
	REP(i,1,m){
		c[k]=c[k+n]=i;
		dfs(k+1);
	}
}
int main(){
	File();
	read(n);read(m);
	if(m==2){
		printf("2\n");
		return 0;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}

