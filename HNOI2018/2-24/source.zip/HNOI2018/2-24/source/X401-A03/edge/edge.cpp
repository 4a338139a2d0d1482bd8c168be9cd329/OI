#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
}
template<typename T>T chckmax(T _,T __){return _>__ ? _ : __;}
template<typename T>T chckmin(T _,T __){return _<__ ? _ : __;}
template<typename T>
void read(T &x){
	T _=0,s=1;char __=getchar();
	while(!isdigit(__))s*=__=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	x=_*s;
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
const ll mod=1e9+7;
const int maxn=100+10;
int n,k,m,dis[maxn][maxn],degree[maxn],ans,O_O=1;
void dfs(int th){
	if(th>k){
		REP(i,1,m)if(degree[i]%2==0)return;
		REP(i,m+1,n)if(degree[i]%2==1)return;
		++ans;
		return;
	}
	REP(i,1,n)REP(j,i+1,n){
		if(dis[i][j])continue;
		dis[i][j]=dis[j][i]=1;
		++degree[i];++degree[j];
		dfs(th+1);
		dis[i][j]=dis[j][i]=0;
		--degree[i];--degree[j];
	}
}
int main(){
	File();
	read(n);read(m);read(k);
	if(n<=10){
		REP(i,1,k)O_O*=i;
		dfs(1);
		cout<<ans/O_O<<endl;
	}
	else puts("0\n");
	return 0;
}
