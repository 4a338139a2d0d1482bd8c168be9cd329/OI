#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=100;
const ll maxN=10000000;
struct node {
	int l,r;
}s[maxn];
int n,m,k,tot,ans;
int us[maxn],cntt[maxn],p[maxn];
int e[maxn][maxn];
ll x=937;
ll h[maxN];

inline void file() {
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
}

inline void init() {
	For (i,1,n) For (j,i+1,n) {
		++tot;
		s[tot].l=i; s[tot].r=j;
	}
}

inline bool check() {
	int pp[maxn];
	For (i,1,k) pp[i]=p[i];
	sort(pp+1,pp+k+1);
	ll ch=0;
	For (i,1,k) ch=(ch*x+pp[i])%maxN;
	if (h[ch]) return 0;
	h[ch]=1;
	int cnt=0;
	For (i,1,n) if (cntt[i]%2==1) cnt++;
	if (cnt!=m) return 0;
	For (i,1,m) if (cntt[i]%2==0) return 0;
	return 1;
}

void dfs(int kk) {
	if (kk==k+1) {
		if (check()) ans++;
		return ;
	}
	For (i,1,tot) if (!us[i]) {
		us[i]=1; e[s[i].l][s[i].r]=1; e[s[i].r][s[i].l]=1;
		cntt[s[i].l]++; cntt[s[i].r]++;
		p[kk]=i;
		dfs(kk+1);
		us[i]=0; e[s[i].l][s[i].r]=0; e[s[i].r][s[i].l]=0;
		cntt[s[i].l]--; cntt[s[i].r]--;
	}
}

int main() {
	file();
	scanf("%d%d%d",&n,&m,&k);
	init();
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
