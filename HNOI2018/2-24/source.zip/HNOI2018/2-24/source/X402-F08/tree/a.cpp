#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=200+10;
const int maxN=100000+100;
struct node {
	int u,d;
//	bool operator < (const node &aa) const {
//		return d>aa.d;
//	}
};
int n,tot=1;
int cnt[maxn],fa[maxn],deep[maxn],anss[maxn];
int a[maxn][maxn],col[maxn][maxn];

queue<int>q;

inline void file() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

void dfs(int u,int f) {
	For (i,1,n) if (a[u][i]) {
		if (i==f) continue;
		fa[i]=u; dfs(i,u);
	}
}

int main() {
	file();
	read(n);
	For (i,1,n-1) {
		int x,y; read(x); read(y);
		a[x][y]=++tot; a[y][x]=++tot; cnt[x]++; cnt[y]++;
	}
	dfs(1,0);
//	For (i,1,n) printf("%d ",fa[i]); cout << endl;
	For (i,1,n) if (cnt[i]==1) {
		cnt[i]--; q.push(i);
	}
	while (!q.empty()) {
		int u=q.front(); q.pop();
		For (i,1,n) if (!col[fa[u]][i] && !col[u][i]) {
			anss[a[fa[u]][u]/2]=i;
			col[fa[u]][i]=1; col[u][i]=1;
			break;
		}
		cnt[fa[u]]--;
		if (cnt[fa[u]]==1 && fa[u]!=1) q.push(fa[u]);
	}
	int ans=0;
	For (i,1,tot/2) ans+=anss[i];
	printf("%d\n",ans);
	For (i,1,tot/2) printf("%d ",anss[i]);
	return 0;
}
