#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
#include<cstdlib>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=200+10;
const int maxN=100000+100;
struct node {
	int u,fa,deep;
	bool operator < (const node &aa) const {
		return deep>aa.deep;
	}
};
int n,tot=1;
int cnt[maxn],anss[maxn];
int a[maxn][maxn],col[maxn][maxn];

node s[maxn];
priority_queue<node>q;

inline void file() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

void dfs(int u,int f) {
	For (i,1,n) if (a[u][i]) {
		if (i==f) continue;
		s[i].fa=u; s[i].deep=s[u].deep+1; dfs(i,u);
	}
}

int main() {
	file();
	read(n);
	For (i,1,n-1) {
		int x,y; read(x); read(y);
		a[x][y]=++tot; a[y][x]=++tot; cnt[x]++; cnt[y]++;
	}
	For (i,1,n) s[i].u=i;
	s[1].deep=0; dfs(1,0);
//	For (i,1,n) printf("%d %d %d\n",s[i].u,s[i].fa,s[i].deep);
	For (i,1,n) if (cnt[i]==1) {
		cnt[i]--; q.push(s[i]);
	}
	while (!q.empty()) {
		node p=q.top(); q.pop();
		For (i,1,n) if (!col[p.fa][i] && !col[p.u][i]) {
			anss[a[p.fa][p.u]/2]=i;
			col[p.fa][i]=1; col[p.u][i]=1;
			break;
		}
		cnt[p.fa]--;
		if (cnt[p.fa]==1 && p.fa!=1) q.push(s[p.fa]);
	}
	int ans=0;
	For (i,1,tot/2) ans+=anss[i];
	printf("%d\n",ans);
	For (i,1,tot/2) printf("%d ",anss[i]);
	return 0;
}
