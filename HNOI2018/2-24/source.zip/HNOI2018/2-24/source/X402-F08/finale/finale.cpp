#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=20;
int n,m,ans;
int vis[maxn],s[maxn];

inline void file() {
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline bool check() {
	For (i,0,n-1) {
		Set(vis,0);
		For (j,0,m-1) vis[s[(i+j)%n]]=1;
		int flag=1;
		For (i,1,m) if (!vis[i]) { flag=0; break; }
		if (flag) return 1;
	}
	return 0;
}

void dfs(int nn) {
	if (nn==n) {
		if (!check()) ans++;
		return ;
	}
	For (i,1,m) {
		s[nn]=i;
		dfs(nn+1);
	}
}

int main() {
	file();
	scanf("%d%d",&n,&m);
	dfs(0);
	printf("%d\n",ans);
	return 0;
}
