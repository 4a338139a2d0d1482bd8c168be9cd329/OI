#include <bits/stdc++.h>

const int N = 2000;
const int mod = 998244353;

int fpm(int x, int e)
{
	int res = 1;
	for(; e; e >>= 1){
		if(e & 1) res = 1ll * res * x % mod;
		x = 1ll * x * x % mod;
	}
	return res;
}

int n, m;
int C[N + 5][N + 5];

int g[N + 5];
int fac[N + 5];

void Init()
{
	scanf("%d%d", &n, &m);
}

const int P = 720;
/*
//6-permutation

int cnt, p[P + 5][6 + 5];
int id[1000000 + 5];
int con_begin[P + 5];
//if begin with P, the con of end
*/

int ans = 0;
int per[6 + 5];
bool inq[6 + 5];

void DFS_calc(int step)
{
	if(step >= n){
//		for(int i = 0; i < n; ++i){
//			printf("%d%c", per[i], i != n-1? ' ':'\n');
//		}
		for(int i = 0; i < n; ++i){
			int vis[10] = {0};
			int cnt = 0;
			for(int j = i; j < i + m; ++j){
				if(!vis[per[j%n]]){
					vis[per[j%n]] = 1;
					cnt ++;
				}
			}
			if(cnt == m) return ;
		}
		ans ++;
		return ;
	}
	for(int i = 1; i <= m; ++i){
		per[step] = i;
		DFS_calc(step + 1);
		per[step] = 0;
//		inq[i] = false;
	}
}

void Exec()
{
	if(n <= 2000){
		if(m == 2){
			printf("%d\n", m);
		}else
		{
			DFS_calc(0);
			printf("%d\n", ans);
		}
	}
}

int main()
{
	freopen("finale.in", "r", stdin);
	freopen("finale.out", "w", stdout);

	Init();
	Exec();

	return 0;
}
