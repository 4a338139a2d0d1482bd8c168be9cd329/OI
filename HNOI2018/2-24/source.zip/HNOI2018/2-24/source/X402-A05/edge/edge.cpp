#include <bits/stdc++.h>

const int N = 10;

int n, m, K;
int A[N + 5][N + 5];
int ans;

void DFS_calc(int x, int y)
{
	if(x > n){
		int edge_cnt = 0;
//		for(int i = 1; i <= n; ++i)
//			for(int j = 1; j <= n; ++j){
//				printf("%d%c", A[i][j], j != n? ' ':'\n');
//			}
		for(int i = 1; i <= n; ++i){
			bool flag = 0;
			for(int j = 1; j <= n; ++j){
				edge_cnt += A[i][j];
				flag ^= A[i][j];
			}
			if(flag != (i<=K)) return ;
		}
		ans += (edge_cnt/2 == m);
		return ;
	}
	if(y > n){
		DFS_calc(x + 1, x + 2);
		return ;
	}

	A[x][y] = A[y][x] = 1;
	DFS_calc(x, y + 1);
	A[x][y] = A[y][x] = 0;
	DFS_calc(x, y + 1);
}

int main()
{
	freopen("edge.in", "r", stdin);
	freopen("edge.out", "w", stdout);

	scanf("%d%d%d", &n, &K, &m);
	DFS_calc(1, 2);
	printf("%d\n", ans);

	return 0;
}
