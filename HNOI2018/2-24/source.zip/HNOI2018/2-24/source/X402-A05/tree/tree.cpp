#include <bits/stdc++.h>

#define exec_time() (1.0 * clock()/CLOCKS_PER_SEC)

const int N = 150;

int n;

int e = 1, Begin[N + 5];
struct Edge
{
	int to, next;
	Edge(int to = 0, int next = 0) : to(to), next(next) {}
}E[(N<<1) + 5];

void add_edge(int u, int v)
{
	E[++e] = Edge(v, Begin[u]); Begin[u] = e;
	E[++e] = Edge(u, Begin[v]); Begin[v] = e;
}

void Init()
{
	scanf("%d", &n);
	for(int i = 1; i < n; ++i){
		int u, v;
		scanf("%d%d", &u, &v);
		add_edge(u, v);
	}
	return ;
}

bool ban[N + 15][N + 15];
int inq[N + 15];

int color[N + 15];
int ans = 1e9;
int finalC[N + 15];

void DFS_calc(int u, int ret)
{
	if(ret >= ans) return ;
	if(u >= n){
		if(ans > ret){
			for(int i = 1; i < n; ++i){
				finalC[i] = color[i];
			}
			ans = ret;
		}
		return ;
	}
	int org[N + 15] = {0};
	for(int c = 1; c < n; ++c){
		if(inq[u] & (1 << c)) continue;
		color[u] = c;
		for(int i = 1; i < n; ++i){
			org[i] = inq[i];
			if(ban[u*2][i*2]){
				inq[i] |= (1 << c);
			}
		}
		DFS_calc(u + 1, ret + c);
		color[u] = 0;
		for(int i = 1; i < n; ++i)
			inq[i] = org[i];
	}
}

void Exec()
{
	for(int u = 1; u <= n; ++u){
		int stk[N] = {0}, top = 0;
		for(int i = Begin[u]; i; i = E[i].next){
			stk[++top] = i;
		}
		for(int i = 1; i <= top; ++i){
			for(int j = 1; j <= top; ++j){
				if(j == i) continue;
				ban[stk[i]][stk[j]] = 1;
				ban[stk[i]][stk[j] ^ 1] = 1;
				ban[stk[i] ^ 1][stk[j]] = 1;
				ban[stk[i] ^ 1][stk[j] ^ 1] = 1;
			}
		}
	}

	DFS_calc(1, 0);

	printf("%d\n", ans);
	for(int i = 1; i < n; ++i){
		printf("%d%c", finalC[i], i != n? ' ':'\n');
	}
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	Init();
	Exec();

	return 0;
}
