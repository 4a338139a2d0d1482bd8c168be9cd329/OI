#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 405, Mod = 1e9+7 ;
int ans, n, m, g[maxn][maxn], k ;
int deg[maxn] ;
void calc() {
	memset (deg, 0, sizeof deg) ;
	int i, j ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = i+1 ; j <= n ; j ++ )
			if (g[i][j]) ++deg[i], ++deg[j] ;
	for ( i = 1 ; i <= m ; i ++ )
		if (!(deg[i]&1)) return ;
	for ( i = m+1 ; i <= n ; i ++ )
		if (deg[i]&1) return ;
	++ ans ;
}
int main() {
	//Force
	freopen ( "edge.in", "r", stdin ) ;
	freopen ( "edge.out", "w", stdout ) ;
	int i, j, s ;
	Read(n), Read(m), Read(k) ;
	s = n*(n-1)/2 ;
	s = pow(2, s) ;
	int t, x ;
	for ( t = 0 ; t <= s ; t ++ ) {
		x = t ;
		if (__builtin_popcount(x) != k) continue ;
		for ( i = 1 ; i <= n ; i ++ )
			for ( j = i+1 ; j <= n ; j ++ )
				g[i][j] = x&1, x >>= 1 ;
		calc() ;
	}
	cout << ans << endl ;
	return 0 ;
}
