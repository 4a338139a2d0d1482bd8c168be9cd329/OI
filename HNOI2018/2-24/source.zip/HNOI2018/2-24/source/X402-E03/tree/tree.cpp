#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 200 ;
struct node {
	int u, v, w ;
} e[maxn] ;
set <int> st[maxn] ;
int deg[maxn], p[maxn], n, m, ans = 0x3f3f3f3f ;
void dfs ( int stp, int v ) {
	if (v >= ans) return ;
	int i ;
	if (stp >= n) {
		for ( i = 1 ; i <= n ; i ++ )
			st[i].clear() ;
		for ( i = 1 ; i < n ; i ++ ) {
			st[e[i].u].insert(e[i].w) ;
			st[e[i].v].insert(e[i].w) ;
		}
		for ( i = 1 ; i <= n ; i ++ )
			if (st[i].size() ^ deg[i]) return ;
		ans = v ;
		for ( i = 1 ; i < n ; i ++ )
			p[i] = e[i].w ;
		return ;
	}
	for ( i = 1 ; i <= n ; i ++ ) {
		e[stp].w = i ;
		dfs(stp+1, v+i) ;
	}
}
int main() {
	freopen ( "tree.in", "r", stdin ) ;
	freopen ( "tree.out", "w", stdout ) ;
	Read(n) ;
	int i ;
	for ( i = 1 ; i < n ; i ++ ) {
		Read(e[i].u), Read(e[i].v) ;
		++deg[e[i].u], ++deg[e[i].v] ;
	}
	dfs(1, 0) ;
	printf ( "%d\n", ans ) ;
	for ( i = 1 ; i < n ; i ++ )
		printf ( "%d ", p[i] ) ;
	return 0 ;
}
