#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 2005, Mod = 998244353 ;
int n, m, a[maxn], ans ;
int c[10] ;
bool judge ( int l, int r ) {
	int i ;
	memset (c, 0, sizeof c) ;
	for ( i = l ; i <= r ; i ++ )
		c[a[i]] ++ ;
	for ( i = 1 ; i <= m ; i ++ )
		if (!c[i]) return 0 ;
	return 1 ;
}
void dfs ( int stp ) {
	int i ;
	if (stp > n) {
		for ( i = 1 ; i <= n ; i ++ )
			a[i+n] = a[i] ;
		for ( i = m ; i <= n*2 ; i ++ )
			if (judge(i-m+1, i)) return ;
		++ ans ;
		return ;
	}
	for ( i = 1 ; i <= m ; i ++ ) {
		a[stp] = i ;
		dfs(stp+1) ;
	}
}
void Force() {
	dfs(1) ;
	cout << ans << endl ;
}
int main() {
	freopen ( "finale.in", "r", stdin ) ;
	freopen ( "finale.out", "w", stdout ) ;
	Read(n), Read(m) ;
	if (m == 2) puts("2") ;
	else Force() ;
	return 0 ;
}
