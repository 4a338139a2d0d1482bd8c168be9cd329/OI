#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 250, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
int n;
struct node{
	int id,v;
	bool operator <(const node &r)const {
		return v > r.v;
	}
};
vector<node>G[N];
int Begin[N], Next[N * N], to[N * N], e;
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
int seq[N], label[N], tag[N];
#define Rep(i,u) for(int i = Begin[u], v = to[i];i;i = Next[i], v = to[i])
inline void init(){
	read(n);
	For(i, 1, n - 1){
		int x, y;
		read(x), read(y);
		G[x].push_back((node){i,y}), G[y].push_back((node){i,x});
	}
	For(i, 1, n){
		int S = G[i].size() ;
		For(j, 0, S - 1){
			int v = G[i][j].id;
			For(k, j + 1, S - 1){
				int u = G[i][k].id;
				add(u, v), add(v, u);
			}
		}
	}
}
void MCS(){
	Forr(i, n-1, 1){
		int u = 0, mx = -1;
		For(j, 1, n-1)if(label[j] > mx && !tag[j])mx = label[j], u = j;
		tag[u] = i, seq[i] = u;
		Rep(j, u)label[v] ++;
	}
}
int col[N], vis[N], cnt[N];

node P[N];
void solve(){
	MCS();cnt[0] = -1;
	Forr(i, n-1, 1){
		int u = seq[i], d = 0;
		For(j, 1, n)vis[j] = 0;
		Rep(j, u)if(tag[v] > tag[u])
			vis[col[v]] = 1, d++;
		int cc = 0;
		For(j, 1, n - 1)if(!vis[j] && cnt[cc]<=cnt[j])cc = j;
		For(j, 1, n - 1)vis[j] = 0;
		col[u] = cc;
		cnt[col[u]] ++;
	}
	int now = 0;
	For(i, 1, n - 1)P[i] = (node){i, cnt[i]};
	sort(P + 1, P + n);
	int ans = 0;
	For(i, 1, n - 1){
		ans += P[i].v * i;
		vis[P[i].id] = i;
	}
	printf("%d\n",ans);
	For(i, 1, n - 1)printf("%d ", vis[col[i]]);puts("");
}
int main(){
	file();
	init();
	solve();
	return 0;
}
