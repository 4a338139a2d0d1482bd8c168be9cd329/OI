#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1010, INF = 0x3f3f3f3f, Mod = 1e9 + 7;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c = getchar();
	while( isdigit(c))x = x * 10 + c - 48, c = getchar();
}
inline void file(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
}
int n, k, m;
ll dp[N][N], fac, inv[N];
ll qpow(ll a, ll b){
	ll ret = 1;
	for(; b; b >>= 1, a = a * a % Mod)if(b & 1)ret = ret * a % Mod;
	return ret;
}
void init(){
	read(n), read(m), read(k);
	For(i, 1, k)inv[i] = qpow(i, Mod - 2);
	fac = 1;
	For(i, 1, m)fac = fac * (n - i + 1) % Mod * inv[i] % Mod;
	fac = qpow(fac, Mod - 2);
}
inline ll C(ll x){
	return x * (x - 1) / 2 % Mod;
}
inline void add(ll &x, ll y){
	x = x + y < Mod ? x + y : x + y - Mod;
}
void solve(){
	if(m & 1)return void(puts("0"));
	dp[0][0] = 1;
	For(i, 1, k){
		For(j, 0, n){
			dp[i][j] = dp[i - 1][j] * j * (n - j) % Mod;
			if(j > 1)add(dp[i][j], dp[i - 1][j - 2] * C(n - j + 2) % Mod);
			if(j + 2 <= n)add(dp[i][j], dp[i - 1][j + 2] * C(j + 2) % Mod);
			if(i > 1)add(dp[i][j], Mod - dp[i - 2][j] * (C(n) - i + 2) % Mod);
			dp[i][j] = dp[i][j] * inv[i] % Mod;
		}
	}
	printf("%lld\n", dp[k][m] * fac % Mod);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
