#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("edge.in","r",stdin);
	freopen("BF.out","w",stdout);
}
int n,m,k;
void init(){
	read(n), read(m), read(k);
}
int d[N], ans, ans1;
void dfs(int u, int v,int c){
	if(c == k){
		int cnt=0;
		For(i, 1, n)cnt+=d[i];
		if(cnt == m)ans1++;
		For(i, 1, m)if(!d[i])return ;
		For(i, m + 1, n)if(d[i])return ;
		ans ++;
		return ;
	}
	if(u == n + 1)return ;
	int nxu = u, nxv;
	nxv = v + 1;
	if(nxv == u) nxv ++ ;
	if(nxv > n)nxu = u + 1, nxv = u + 2;
	d[u]^=1, d[v]^=1;
	dfs(nxu, nxv, c + 1);
	d[u]^=1, d[v]^=1;
	dfs(nxu, nxv, c);
}
void solve(){
	dfs(1, 2, 0);
	printf("%d\n",ans);
	printf("%d\n",ans1);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
