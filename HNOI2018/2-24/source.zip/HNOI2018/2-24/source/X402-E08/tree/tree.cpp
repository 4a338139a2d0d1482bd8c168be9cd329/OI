#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("tree.in", "r", stdin);
	freopen ("tree.out", "w", stdout);
}

const int N = 155;

int n;
int maxcolor;

int dp[N][N];

int ans[N];
int base[N][N];
int Best[N][N][N];

const int inf = 0x3f3f3f3f;

const int Node = N * N * 2, Edge = Node * 4;

int rcol[Node], rrow[Node];

struct MCMF {
	int Head[Node], to[Edge], Next[Edge], val[Edge], cap[Edge], dis[Node], inq[Node], pre[Node], e, n, S, T;

	void Init() { e = 1; Set(Head, 0); }

	void add_edge(int u, int v, int w, int flow) { to[++e] = v; Next[e] = Head[u]; Head[u] = e; cap[e] = flow; val[e] = w; }

	void Add(int u, int v, int w, int flow) { add_edge (u, v, w, flow); add_edge (v, u, -w, 0); }

	bool Spfa() {
		queue<int> Q;
		Q.push(S); inq[S] = true;
		For (i, 1, n) dis[i] = inf; dis[S] = 0;
		while (!Q.empty()) {
			int u = Q.front(); Q.pop(); inq[u] = false;
			for (register int i = Head[u]; i; i = Next[i]) {
				register int v = to[i];
				if (cap[i] && chkmin(dis[v], dis[u] + val[i])) {
					if (!inq[v]) {Q.push(v); inq[v] = true;} pre[v] = i;
				}
			}
		}
		return (dis[T] != inf);
	}

	int Run() {
		int sum_cost = 0;
		while (Spfa()) {
			register int min_flow = inf, u;
			for (u = T; u != S; u = to[pre[u] ^ 1]) {
				chkmin(min_flow, cap[pre[u]]);
			}
			for (u = T; u != S; u = to[pre[u] ^ 1]) {
				cap[pre[u]] -= min_flow;
				cap[pre[u] ^ 1] += min_flow;
				sum_cost += val[pre[u]] * min_flow;
			}
		}
		return sum_cost;
	}


	inline void Check(int a, int b) {
		static int u, v;
		For (i, 1, n)
			for (register int j = Head[i]; j; j = Next[j]) if ((!(j & 1)) && cap[j ^ 1]) {
				u = i; v = to[j]; if (rrow[u] && rcol[v]) {
					Best[a][b][rrow[u]] = rcol[v];
				}
			}
	}
};
MCMF MT;

vector<int> G[N];

int row[N], col[N];
int cc[N];

int square[N][N];

inline void Build(int line, int limit) {
	MT.Init();
	static int S_, T_, S, T, cnt;
	cnt = 0;
	For (i, 1, limit) row[i] = ++cnt, rrow[cnt] = cc[i]; 
	For (i, 1, maxcolor) if (i != line) col[i] = ++cnt, rcol[cnt] = i;
	S_ = ++cnt; T_ = ++cnt; S = ++cnt; T = ++cnt;
	MT.n = cnt; MT.T = T; MT.S = S;

	MT.Add(S, S_, 0, limit); MT.Add(T_, T, 0, limit);
	For (i, 1, limit) MT.Add(S_, row[i], 0, 1);
	For (i, 1, maxcolor) if (i != line) MT.Add(col[i], T_, 0, 1);

	For (i, 1, limit) For (j, 1, maxcolor) if (j != line)
		MT.Add(row[i], col[j], square[i][j], 1);
}

void Dfs(int u, int fa) {
	//cerr << u << ' ' << fa << endl;
	register int len = (int)G[u].size();
	register int son = 0;
	For (i, 0, len - 1) {
		register int v = G[u][i]; if (v == fa) continue ; Dfs(v, u);
	}

	For (i, 0, len - 1) {
		register int v = G[u][i]; if (v == fa) continue ; ++ son;
		For (j, 1, maxcolor) square[son][j] = dp[v][j] + j;
		cc[son] = v;
	}
	if (!son) return ;

	if (fa) { For (i, 1, maxcolor) { Build(i, son); dp[u][i] = MT.Run(); MT.Check(u, i); } }
	else { Build(0, len); dp[u][0] = MT.Run(); MT.Check(u, 0); }
}

void OutAns(int u, int fa, int col) {
	int len = (int)G[u].size();
	For (i, 0, len - 1) {
		register int v = G[u][i]; if (v == fa) continue ;
		int nowcol = Best[u][col][v];
		ans[base[u][v]] = nowcol;
		OutAns(v, u, nowcol);
	}
}

int deg[N];

int main () {
	File();
	n = read();
	maxcolor = 0;

	For (i, 1, n - 1) {
		int u = read(), v = read();
		G[u].push_back(v); G[v].push_back(u);
		base[u][v] = base[v][u] = i;
		++deg[u]; ++deg[v];
	}
	For (i, 1, n)
		chkmax(maxcolor, deg[i]);
	if (n <= 50) maxcolor = n - 1;

	Dfs(1, 0);
	printf ("%d\n", dp[1][0]);
	OutAns(1, 0, 0);
	For (i, 1, n - 1) {
		printf ("%d%c", ans[i], i == n - 1 ? '\n' : ' ');
	}

	cerr << (double)clock() / CLOCKS_PER_SEC << endl;
    return 0;
}
