#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("finale.in", "r", stdin);
	freopen ("finale.out", "w", stdout);
}

int n, m;

const int N = 51;
int Col[N];
inline bool Judge() {
	For (i, 1, m) Col[n + i] = Col[i];
	bool Have[N];
	For (i, 1, n) {
		Set(Have, false);
		bool flag = true;
		For (j, i, i + m - 1) {
			if (!Have[Col[j]]) Have[Col[j]] = true;
			else  { flag = false; break ; }
		}
		if (flag) return true;
	}
	return false;
}

int ans = 0;
void Dfs(int dep) {
	if (dep == n + 1) {
		if (!Judge()) ++ ans;
		return ;
	}
	For (j, 1, m) {
		Col[dep] = j;
		Dfs(dep + 1);
	}
}

void Solve1() {
	ans = 0;
	Dfs(1);
	printf ("%d\n", ans);
}

const int Mod = 998244353;
typedef long long ll;
ll fpm(ll x, ll power) {
	ll res = 1;
	for (; power; power >>= 1, (x *= x) %= Mod)
		if (power & 1) (res *= x) %= Mod;
	return res;
}

int main () {
	File();
	n = read(); m = read();
	if (m == 2) return puts("2"), 0;
	if (m > n) return printf ("%lld\n", fpm(m, n)), 0;
	Solve1();

    return 0;
}
