#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("edge.in", "r", stdin);
	freopen ("edge.out", "w", stdout);
}

int n, m, k;

const int N = 11;
int u[N], v[N], cnt = 0, deg[N];

int main () {
	File() ;
	n = read(); m = read(); k = read();

	For (i, 1, n) For (j, i + 1, n) { u[cnt] = i; v[cnt] = j; ++cnt;}

	int ans = 0;
	int nn = (1 << cnt) - 1;
	For (i, 0, nn)
		if (__builtin_popcount(i) == k) {
			Set(deg, 0);
			For (j, 0, cnt - 1) if (i & (1 << j)) { ++deg[u[j]]; ++deg[v[j]]; }
			bool flag = true; For (j, 1, m) if (!(deg[j] & 1)) { flag = false; break; }
			if (flag) {
				For (j, 0, cnt - 1) if (i & (1 << j)) cout << u[j] << ' ' << v[j] << endl;
				cout << endl;
				++ ans;
			}
		}
	printf ("%d\n", ans);
    return 0;
}
