#include<cstdio>
int main()
{
	
}
