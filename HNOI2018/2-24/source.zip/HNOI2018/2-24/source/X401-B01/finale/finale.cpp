#include<cstdio>
#include<cstring>
#define neko 2010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
int n,m,ans;
int mp[15],num[15],col[neko];
void dfs(int step)
{
	if(step>n)
	{
		f(i,1,m-1)col[n+i]=col[i];
		//f(i,1,n+m-1)printf("%d ",col[i]);
		//puts("");
		f(i,1,n+m-1)
		{
			memset(mp,0,sizeof(mp));
			memset(num,0,sizeof(num));
			f(j,i,i+m-1)++mp[col[j]];
			f(j,1,m)++num[mp[j]];
			if(num[1]==m)return;
		}//printf("Yes\n");
		++ans;if(ans>=998244353)ans%=998244353;return;
	}
	f(i,1,m)
	{
		col[step]=i;
		dfs(step+1);
	}
}
int main()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==2)printf("2\n");
	else dfs(1),printf("%d\n",ans);
	return 0;
}
