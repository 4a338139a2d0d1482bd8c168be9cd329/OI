#include<cstdio>
#include<cstring>
#include<algorithm>
#define neko 1010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define chkmax(a,b) ((a)>(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
#define travel(i,u,v) for(register int i=head[u],v=e[i].v;i;i=e[i].next,v=e[i].v)
int ans=1e9,t,n,paint[neko<<1][neko<<1],ansx[neko<<1],edge[neko];
struct node
{
	int u,v,color;
}e[neko<<1];
void add(int x,int y)
{
	e[++t].u=x;
	e[t].v=y;
}
void dfs(int step,int sum)
{
	if(sum>ans)return;
	if(step>=n)
	{
		//f(i,1,t)printf("%d ",e[i].color);
		//puts("");
		if(sum<ans)
		{
			ans=sum;
			f(i,1,t)ansx[i]=e[i].color;
		}return;
	}
	f(i,1,n-1)
	{
		e[step].color=i;
		if((paint[e[step].u][e[step].color])||(paint[e[step].v][e[step].color]))continue;
		paint[e[step].u][e[step].color]=paint[e[step].v][e[step].color]=1;
		dfs(step+1,sum+i);
		paint[e[step].u][e[step].color]=paint[e[step].v][e[step].color]=0;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int x,y;
	scanf("%d",&n);
	f(i,1,n-1)
	{
		scanf("%d%d",&x,&y);
		add(x,y);
	}
	dfs(1,0);
	printf("%d\n",ans);
	f(i,1,t)printf("%d ",ansx[i]);
	return 0;
}
