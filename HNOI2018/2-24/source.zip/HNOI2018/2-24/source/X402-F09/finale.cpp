#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int mod=998244353;
int n,m,ans;
int cnt[50],tmp[50];
inline long long quickmod(long long a,long long b){
    long long ans=1;
    a%=mod;
    while(b){
        if(b%2==1)ans=(ans*a)%mod;
        b/=2;
        a=(a*a)%mod;
    }
    return ans;
}
inline bool chk(){
	for(register int i=n+1;i<=2*n;++i){
        tmp[i]=tmp[i-n];
    }
	for(register int l=1;l+m-1<=n*2;++l){
		int r=l+m-1;
        bool flag=0;
		memset(cnt,0,sizeof(cnt));
		for(register int i=l;i<=r;++i){
            cnt[tmp[i]]++;
        }
		for(register int i=1;i<=m;++i){
			if(cnt[i]!=1){
				flag=1;
				break;
			}
        }
		if(!flag)return 0;
	}
	return 1;
}
inline void dfs(int x){
	if(x>n){
		if(chk())ans++;
		return ;
	}
	for(register int i=1;i<=m;++i){
        tmp[x]=i;
        dfs(x+1);
    }
}
int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	read(n);read(m);
	if(m==2){
        printf("2\n");
    }
    else if(m==3){
        printf("%lld\n",((quickmod(2,n)-1)%mod*m%mod));
    }
	else{
        dfs(1);
        printf("%d\n",ans);
    }
	return 0;
}
