#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=105;
int n,tot,head[maxn];
struct node{
	int u,v,col;
}ed[maxn];
struct edge{
    int to,next,w;
}e[maxn];
inline void add(int u,int v,int w){
	e[++tot].to=v;
    e[tot].next=head[u];
    e[tot].w=w;
    head[u]=tot;
}
int ans[maxn],col[maxn],Ans=INT_MAX/2-1;
inline bool check(int rt,int fa){
	memset(col,0,sizeof(col));
	for(register int i=head[rt];i;i=e[i].next){
		int w=e[i].w;
        int Col=ed[w].col;
        if(col[Col]){
            return 0;
        }
		else{
            col[Col]=1;
        }
    }
	for(register int i=head[rt];i;i=e[i].next){
		if(e[i].to==fa)continue;
		else{
            if(!check(e[i].to,rt)){
                return 0;
            }
        }
    }
	return 1;
}
inline void dfs(int rt,int num){
	if(num>=Ans)return ;
	if(rt>=n){
		if(check(1,0)){
			if(num<Ans){
				Ans=num;
				for(register int i=1;i<n;++i){
            		ans[i]=ed[i].col;
        		}
			}
		}
        return ;
	}
	for(register int i=1;i<=n;++i){
        if(num+i>Ans)break;
        ed[rt].col=i;
        dfs(rt+1,num+i);
    }
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n);
	for(register int i=1;i<=n-1;++i){
		int u,v;
		read(u);read(v);
		add(u,v,i);add(v,u,i);
		ed[i].u=u,ed[i].v=v;
	}
	dfs(1,0);
	printf("%d\n",Ans);
	for(register int i=1;i<=n-1;++i){
        printf("%d ",ans[i]);
    }
	return 0;
}
