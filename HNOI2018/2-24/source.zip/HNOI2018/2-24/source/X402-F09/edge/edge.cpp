#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
const int mod=1e9+7;
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=205;
int n,m,k,cnt,ans;
int edge[maxn<<1];
struct edge{
    int u,v;
}e[maxn*maxn];
inline void dfs(int pos,int sum){
    if(pos>cnt){
        if(sum!=k)return ;
        for(register int i=1;i<=n;++i){
            if(i<=m){
                if(edge[i]%2==1)continue;
                else return ;
            }
            if(i>m){
                if(edge[i]%2==0)continue;
                else return ;
            }
        }
        ans++;
        if(ans>=mod)ans-=mod;
        return ;
    }
    dfs(pos+1,sum);
    edge[e[pos].u]^=1;
    edge[e[pos].v]^=1;
    dfs(pos+1,sum+1);
    edge[e[pos].u]^=1;
    edge[e[pos].v]^=1;
}
int main(){
    freopen("edge.in","r",stdin);
    freopen("edge.out","w",stdout);
    read(n);read(m);read(k);
    for(register int i=1;i<n;++i){
        for(register int j=i+1;j<=n;++j){
            e[++cnt].v=j;e[cnt].u=i;
        }
    }
    if(k>cnt){
        puts("0");
        return 0;
    }
    else{
        dfs(1,0);
        printf("%d\n",ans);
    }
    return 0;
}
