#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register int i=a;i<=b;i++)
#define Forr(i,a,b) for(register int i=a;i>=b;i--)
using namespace std;
inline void read(int &x)
{
	int p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}
#define N (150+10)
int n,cnt,maxc,cntc,ans=0x3f3f3f3f;
int ed[N][3],OmO[N][N],qwq[N],dep[N],a[N];

inline void check(int tot)
{
	if(tot<ans){
		ans=tot;
		For(i,1,n-1)a[i]=ed[i][2];
	}
}
bool cheat(int x,int tot)
{
	int flag=0;
	int pd[N][N]={0};
	For(i,1,x-1){
		if(pd[ed[i][0]][ed[i][2]]||pd[ed[i][1]][ed[i][2]]){flag=1;break;}
		pd[ed[i][0]][ed[i][2]]=pd[ed[i][1]][ed[i][2]]=1;
	}
	if(flag)return 0;
	return 1;
}

void dfs(int x,int tot)
{
	if(tot>=ans)return;
	if(x==n){
		check(tot);
		return;
	}
	else{
		For(i,1,maxc){
			ed[x][2]=i;
			if(cheat(x+1,tot+i))dfs(x+1,tot+i);
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n);
	for(register int i=1;i<=n-1;i++){
		int x,y;
		read(x),read(y);
		qwq[x]++; qwq[y]++;
		maxc=max(maxc,max(qwq[x],qwq[y]));
		ed[i][0]=x,ed[i][1]=y;
	}
	if(maxc==n-1){cout<<n*(n-1)/2<<endl;int u=0;For(i,1,n-1)printf("%d%c",++u,i==n-1?'\n':' ');return 0;}
	dfs(1,0);
	printf("%d\n",ans);
	For(i,1,n-1)printf("%d%c",a[i],i==n-1?'\n':' ');
	return 0;
}
