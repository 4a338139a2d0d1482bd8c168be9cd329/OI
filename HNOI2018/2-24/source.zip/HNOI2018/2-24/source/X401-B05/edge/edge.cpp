#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=1000000+10;
inline void read(int &x)
{
    x=0;  int p=1;
    char ch=getchar();
    while(ch<'0' || ch>'9'){
        if(ch=='-') p=-1; ch=getchar();
    }
    while(ch>='0' && ch<='9'){
        x=(x<<1)+(x<<3)+(ch^'0'); ch=getchar();
    }
    x=x*p;
}
int main()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	puts("0");
	return 0;
}
