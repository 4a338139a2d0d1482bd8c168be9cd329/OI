#include<bits/stdc++.h>
#define mod (998244353)
#define For(i,a,b) for(register int i=a;i<=b;++i)
#define FOR(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
using namespace std;
inline void file(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
}
int main(){
	file();
	ll m,n;
	cin>>n>>m;
	if(m==2){
		cout<<2;
		return 0;
	}
	return 0;
}
