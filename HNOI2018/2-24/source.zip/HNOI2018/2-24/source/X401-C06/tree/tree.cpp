#include<bits/stdc++.h>
#define mod (998244353)
#define For(i,a,b) for(register int i=a;i<=b;++i)
#define FOR(i,a,b) for(register int i=a;i>=b;--i)
#define next Next
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
using namespace std;
const int maxn=150+5;
int e=1,to[maxn<<1],next[maxn<<1],head[maxn];
int root,size[maxn],color[maxn],pd[maxn][maxn];
int n,qaq[maxn],ans=1e9+8,now[maxn];
int maxsize;
struct node{
	int x,y;
}a[maxn];
inline void file(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
inline void read(int &x){
	int f=1;x=0;char c=getchar();
	while(c>'9'||c<'0'){
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		x=x*10+c-'0';
		c=getchar();
	}
	x*=f;
}
inline void dfs(int x,int sum){
	if(sum>=ans)
		return;
	if(x==n-1){
		ans=sum;
		for(int i=1;i<n;++i)
			qaq[i]=now[i];
		return;
	}
	int ovo=max(size[a[x+1].x],size[a[x+1].y]);
	for(int i=1;i<=ovo;++i)
		if(!pd[a[x+1].x][i]&&!pd[a[x+1].y][i]){
			now[x+1]=i;
			pd[a[x+1].x][i]=pd[a[x+1].y][i]=1;
			dfs(x+1,sum+i);
			pd[a[x+1].x][i]=pd[a[x+1].y][i]=0;
		}
}
int main(){
	file();
	int x,y;
	read(n);
	for(int i=1;i<n;++i){
		read(a[i].x);read(a[i].y);
		++size[a[i].x],++size[a[i].y];
	}
	dfs(0,0);
	printf("%d\n",ans);
	for(int i=1;i<n;++i)
		printf("%d ",qaq[i]);
	return 0;
}

