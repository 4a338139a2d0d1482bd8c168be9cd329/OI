#include<bits/stdc++.h>
#define ll long long
const int maxn=1e6+100;
const int mod=998244353;
using namespace std;

template<typename T>inline bool chkmax(T &a,T b){return a<b?a=b,1:0;}
template<typename T>inline bool chkmin(T &a,T b){return a>b?a=b,1:0;}

template<typename T>inline void read(T &x)
{
	x=0;T c=getchar(),p=1;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;	
}

int n,m,ans;
bool vis[10];
int a[maxn];

bool check()
{
	for(int i=1;i<=n;i++)
	{
		int flag=0;
		for(int j=1;j<=m;j++)vis[j]=0;
		for(int j=0;j<=m-1;j++)
			if(!vis[a[(i+j)%n]])flag++,vis[a[(i+j)%n]]=1;
		if(flag>=m)return 0;
	}
	return 1;
}

void dfs(int now)
{
	if(now==n){
		if(!check())return;
		else ans++;
		return ;	
	}
	for(int i=1;i<=m;i++)
	{
		a[now]=i;
		dfs(now+1);
	}
}

int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	read(n);read(m);
	if(m==2)return printf("2\n"),0;
	dfs(0);
	printf("%d\n",ans);
	return 0;
}
// 1 3 7 15 31 73
// 1 4 16 58 196 664
