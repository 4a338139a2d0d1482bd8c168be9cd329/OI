#include<bits/stdc++.h>
const int maxn=250;
using namespace std;

template<typename T>inline bool chkmax(T &a,T b){return a<b?a=b,1:0;}
template<typename T>inline bool chkmin(T &a,T b){return a>b?a=b,1:0;}

template<typename T>inline void read(T &x)
{
	x=0;T c=getchar(),p=1;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}

int e,n,sum=2147483647;
bool vis[maxn][maxn];
int ans[maxn],pu[maxn];

struct edge{
	int to,from,id;
}a[maxn];

void dfs(int step,int now)
{
	if(now>=sum)return;
	if(step==n)
	{
		if(chkmin(sum,now))
		{
			for(int i=1;i<n;i++)
				pu[i]=ans[i];
		}
		return ;
	}
	for(int i=1;i<=n-1;i++)
	{
		ans[step]=i;
		if(!vis[a[step].from][i])vis[a[step].from][i]=1;else return;
		if(!vis[a[step].to][i])vis[a[step].to][i]=1;else {vis[a[step].from][i]=0;return;}
		dfs(step+1,now+i);
		vis[a[step].from][i]=0;vis[a[step].to][i]=0;
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n);
	for(int i=1;i<n;i++)
		read(a[i].from),read(a[i].to),a[i].id=i;
	dfs(1,0);
	printf("%d\n",sum);
	for(int i=1;i<=n-1;i++)printf("%d ",pu[i]);
	return 0;
}
/*
5
1 2
1 3
2 4
2 5
*/

