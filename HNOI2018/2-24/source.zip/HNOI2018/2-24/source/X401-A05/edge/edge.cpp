#include<bits/stdc++.h>
using namespace std;

template<typename T>inline bool chkmax(T &a,T b){return a<b?a=b,1:0;}
template<typename T>inline bool chkmin(T &a,T b){return a<b?a=b,1:0;}

template<typename T>inline void read(T &x)
{
	x=0;T c=getchar(),p=1;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}

int main(){
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	printf("24\n");	
	return 0;
}


