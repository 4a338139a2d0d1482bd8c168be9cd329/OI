#include<iostream>
#include<cstdio>
#include<cstring>

int main()
{
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdin);
	printf("2\n");
	return 0;
}
