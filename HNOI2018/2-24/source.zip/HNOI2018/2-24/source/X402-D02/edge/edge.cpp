#include<iostream>
#include<cstdio>
#include<cstring>

namespace MeiYouFenDeBaoLi
{
	typedef long long ll;
	const int N=205,MOD=1000000007;
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}
	inline void inc(int a,int &b){b=(a+b)%MOD;}

	int fact[N],ifact[N];
	int C(int n,int m){if(n<m)return 0;return (ll)fact[n]*ifact[m]%MOD*ifact[n-m]%MOD;}

	void initialize()
	{
		fact[0]=1;
		for(int i=1;i<N;i++)fact[i]=(ll)fact[i-1]*i%MOD;
		ifact[N-1]=inv(fact[N-1]);
		for(int i=N-1;i;i--)ifact[i-1]=(ll)ifact[i]*i%MOD;
	}

	int f[N][N][N];
	int n,m,k;

	void dp()
	{
		f[0][0][0]=1;
		for(int i=0;i<n;i++)
			for(int j=0;j<=i;j++)
				for(int l=0;l<=k;l++)
				{
					int v=f[i][j][l];
					if(!v)continue;

					for(int e0=0;e0+l<=k;e0++)
						for(int e1=0;e0+e1+l<=k;e1++)
							inc((ll)v*C(j,e0)%MOD*C(i-j,e1)%MOD,f[i+1][j-e0+e1+((e0+e1)%2!=0)][l+e0+e1]);
				}
	}

	void solve()
	{
		initialize();
		scanf("%d%d%d",&n,&m,&k);
		dp();
		int ans=(f[n][m][k]*inv((C(n,m)+MOD)%MOD)%MOD+MOD)%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	MeiYouFenDeBaoLi::solve();
	return 0;
}
