/************************************************
 * Au: Hany01
 * Prob: finale bf_20
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (998244353)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("finale.in", "r", stdin);
    freopen("finale.out", "w", stdout);
}

int n, m, flag[10], co[10], cnt, mark;

inline void check()
{
	For(i, 1, n) {
		Set(flag, 0);
		mark = 0;
		rep(j, m) {
			register int jj = (i + j - 1) % n + 1;
			if (flag[co[jj]]) { mark = 1; break; }
			flag[co[jj]] = 1;
		}
		if (!mark) return ;
	}
	++ cnt;
}

inline void dfs(int cur)
{
	if (cur == n + 1) { check(); return ; }
	For(i, 1, m) co[cur] = i, dfs(cur + 1);
}

inline LL Pow(LL a, LL b) {
	LL Ans = 1;
	for ( ; b; b >>= 1, a = a * a % Mod) if (b & 1) (Ans *= a) %= Mod;
	return Ans;
}

int main()
{
    File();
	n = read(), m = read();
	if (m == 2) {
		cout << 2 << endl;
		return 0;
	}
	if (m == 3) {
		cout << (Pow(2, n) - 1) * 3ll % Mod << endl;
		return 0;
	}
	if (n <= 7) {
		dfs(1);
		printf("%d\n", cnt);
		return 0;
	}
    return 0;
}
