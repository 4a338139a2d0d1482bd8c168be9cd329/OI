/************************************************
 * Au: Hany01
 * Prob: edge dp乱搞
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("edge.in", "r", stdin);
    freopen("edge.out", "w", stdout);
}

const int maxn = 205;

int N, M, K;
LL f[maxn][maxn][maxn], fac[maxn], ifac[maxn];

inline LL Pow(LL a, LL b) {
	LL Ans = 1;
	for ( ; b; b >>= 1, a = a * a % Mod) if (b & 1) (Ans *= a) %= Mod;
	return Ans;
}

inline LL C(int n, int m) { return fac[n] * ifac[m] % Mod * ifac[n - m] % Mod; }

int main()
{
    File();
	N = read(), M = read(), K = read();
	f[0][0][0] = 1;
	fac[0] = 1;
	For(i, 1, N) fac[i] = fac[i - 1] * i % Mod;
	ifac[N] = Pow(fac[N], Mod - 2);
	Fordown(i, N, 1) ifac[i - 1] = ifac[i] * i % Mod;
	For(i, 0, N - 1) For(j, 0, K) For(k, 0, i) For(x, 0, min(i - k, K - j)) For(y, 0, min(k, K - j - x))
		(f[i + 1][j + x + y][k - y + x + (i + 1 <= M ? ((x + y + 1) & 1) : ((x + y) & 1))] += f[i][j][k] * C(i - k, x) % Mod * C(k, y) % Mod) %= Mod;
	printf("%lld\n", f[N][K][0]);
    return 0;
}
