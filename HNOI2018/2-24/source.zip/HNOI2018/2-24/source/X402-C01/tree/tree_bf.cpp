/************************************************
 * Au: Hany01
 * Prob: tree_bf
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);
}

const int maxn = 155, maxm = 305;

int n, m, uu[maxn], vv[maxm], flag[maxn], v[maxm], co[maxm], nex[maxm], beg[maxn], e, Sum, Ans, cc[maxm], ansc[maxn];

inline void add(int uu, int vv, int cc) { v[++ e] = vv, co[e] = cc, nex[e] = beg[uu], beg[uu] = e; }

inline bool check()
{
	e = 0, Set(beg, 0);
	For(i, 1, n - 1) add(uu[i], vv[i], cc[i]), add(vv[i], uu[i], cc[i]);
	For(i, 1, n) {
		Set(flag, 0);
		for (register int j = beg[i]; j; j = nex[j]) {
			if (flag[co[j]]) return 0;
			flag[co[j]] = 1;
		}
	}
	return 1;
}

inline void dfs(int cur)
{
	if (Sum >= Ans) return ;
	if (cur == n) {
		if (check())
			if (chkmin(Ans, Sum))
				For(i, 1, n - 1) ansc[i] = cc[i];
		return ;
	}
	For(i, 1, n - 1) cc[cur] = i, Sum += i, dfs(cur + 1), Sum -= i;
}

int main()
{
    File();
	n = read();
	For(i, 1, n - 1) uu[i] = read(), vv[i] = read();
	Ans = INF;
	dfs(1);
	printf("%d\n", Ans);
	For(i, 1, n - 1) printf("%d ", ansc[i]);
    return 0;
}
