/************************************************
 * Au: Hany01
 * Prob: tree 魔性乱搞
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);
}

const int maxn = 155;

int n, beg[maxn], nex[maxn << 1], v[maxn << 1], e, f[maxn][maxn], Ans, Sum, cnt, lst[maxn], flag[maxn], NOW, uu[maxn], vv[maxn], ansco[maxn];
vector<int> Ansc[maxn][maxn];
int tmpc[maxn];

inline void add(int uu, int vv) { v[++ e] = vv, nex[e] = beg[uu], beg[uu] = e; }

void dfss(int cur)
{
	if (cur > cnt) {
		For(i, 1, n - 1) if (!flag[i]) if (chkmin(f[NOW][i], Sum + i)) {
			For(j, 1, cnt) Ansc[NOW][i][j] = tmpc[j];
		}
		return;
	}
	For(i, 1, n - 1) if (!flag[i]) {
		Sum += f[lst[cur]][i], flag[i] = 1;
		tmpc[cur] = i;
		dfss(cur + 1);
		Sum -= f[lst[cur]][i], flag[i] = 0;
	}
}

inline void select(int u, int fa)
{
	cnt = 0, NOW = u;
	for (register int i = beg[u]; i; i = nex[i]) if (v[i] != fa) lst[++ cnt] = v[i];
	cerr << cnt << endl;
	dfss(1);
}

void dfs(int u, int fa)
{
	if (!beg[u]) {
		For(i, 1, n - 1) f[u][i] = i;
		return ;
	}
	for (register int i = beg[u]; i; i = nex[i]) if (v[i] != fa) dfs(v[i], u);
	select(u, fa);
}

inline void confirmans(int u, int v, int co)
{
	For(i, 2, n) if ((uu[i] == u && vv[i] == v) || (uu[i] == v && vv[i] == u)) {
		ansco[i] = co;
		return;
	}
}

void findans(int u, int nowco, int fa)
{
	for (register int i = beg[u], j = 1; i; i = nex[i], ++ j) if (v[i] != fa)
		confirmans(u, v[i], Ansc[u][nowco][j]), findans(v[i], Ansc[u][nowco][j], u);
}

int main()
{
    File();
	n = read();
	For(i, 2, n) uu[i] = read(), vv[i] = read(), add(uu[i], vv[i]), add(vv[i], uu[i]);
	Set(f, 127);
	For(i, 1, n) For(j, 1, n) Ansc[i][j].resize(n + 1);
	dfs(1, 0);
	Ans = INF;
	int tmpp;
	For(i, 1, n - 1) if (chkmin(Ans, f[1][i] - i)) tmpp = i;
	printf("%d\n", Ans);
	findans(1, tmpp, 1);
	For(i, 2, n) printf("%d ", ansco[i]);
    return 0;
}
