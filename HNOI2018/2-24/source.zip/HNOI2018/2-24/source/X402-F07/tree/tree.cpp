#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=155;
vector<int>E[maxn];
int n,deg[maxn];
int id[maxn][maxn];
namespace solver_1{
	int col[maxn];
	int ans,deg[maxn];
	bool vis[maxn][maxn];
	vector<int>s;
	bool cmp(const int &x,const int &y){
		return deg[x]<deg[y];
	}
	void calc(){
		REP(k,1,n-1){
			int Max=0,u;
			REP(i,1,n)chkmax(Max,deg[i]);
			REP(i,1,n)if(deg[i]==Max)u=i;
			deg[u]=0,s.clear();
			REP(i,0,E[u].size()-1)if(deg[E[u][i]])s.pb(E[u][i]);
			sort(s.begin(),s.end(),cmp);
			REP(i,0,s.size()-1){
				int v=s[i];
				REP(j,1,n){
					if((!vis[u][j])&&(!vis[v][j])){
						ans+=j;
						col[id[u][v]]=j;
						vis[u][j]=vis[v][j]=1;
						--deg[v];
						break;
					}
				}
			}
		}
	}
}
namespace solver_2{
	int col[maxn];
	int ans,deg[maxn];
	bool vis[maxn][maxn];
	queue<int>Q;
	void calc(){
		REP(i,1,n)if(deg[i]==1)Q.push(i);
		while(!Q.empty()){
			int u=Q.front(),fa;Q.pop();
			if(deg[u]!=1)continue;
			REP(i,0,E[u].size()-1)
				if(deg[E[u][i]]!=1){
					fa=E[u][i];
					break;
				}
			REP(i,1,n)
				if((!vis[u][i])&&(!vis[fa][i])){
					ans+=i;
					col[id[u][fa]]=i;
					vis[u][i]=vis[fa][i]=1;
					if(--deg[fa]==1)Q.push(fa);
					break;
				}
		}
	}
}
namespace solver_3{
	int col[maxn];
	int ans,deg[maxn];
	bool vis[maxn][maxn];
	vector<int>s;
	bool cmp(const int &x,const int &y){
		return deg[x]>deg[y];
	}
	void calc(){
		REP(k,1,n-1){
			int Max=0,u;
			REP(i,1,n)chkmax(Max,deg[i]);
			REP(i,1,n)if(deg[i]==Max)u=i;
			deg[u]=0,s.clear();
			REP(i,0,E[u].size()-1)if(deg[E[u][i]])s.pb(E[u][i]);
			sort(s.begin(),s.end(),cmp);
			REP(i,0,s.size()-1){
				int v=s[i];
				REP(j,1,n){
					if((!vis[u][j])&&(!vis[v][j])){
						ans+=j;
						col[id[u][v]]=j;
						vis[u][j]=vis[v][j]=1;
						--deg[v];
						break;
					}
				}
			}
		}
	}
}
namespace solver_4{
	int col[maxn];
	int ans,deg[maxn];
	bool vis[maxn][maxn];
	pair<int,int>edge[maxn];
	bool cmp(const pair<int,int>&p,const pair<int,int>&q){
		return deg[p.first]+deg[p.second]<deg[q.first]+deg[q.second];
	}
	void calc(){
		REP(i,1,n)
			REP(j,1,n)
				if(id[i][j])
					edge[id[i][j]]=make_pair(i,j);
		sort(edge+1,edge+n);
		REP(i,1,n-1){
			int u=edge[i].first,v=edge[i].second;
			REP(j,1,n)
				if((!vis[u][j])&&(!vis[v][j])){
					ans+=j;
					col[id[u][v]]=j;
					vis[u][j]=vis[v][j]=1;
					break;
				}
		}
	}
}
namespace solver_5{
	int col[maxn];
	int ans=1e9,deg[maxn];
	bool vis[maxn][maxn];
	int tmp_col[maxn],res;
	pair<int,int>edge[maxn];
	void calc(){
		REP(i,1,n)
			REP(j,1,n)
				if(id[i][j])
					edge[id[i][j]]=make_pair(i,j);
		srand(12590204);
		while(1){
			if(1.0*clock()/CLOCKS_PER_SEC>=0.48)break;
			res=0;
			memset(vis,0,sizeof(vis));
			random_shuffle(edge+1,edge+n);
			REP(i,1,n-1){
				int u=edge[i].first,v=edge[i].second;
				REP(j,1,n)
					if((!vis[u][j])&&(!vis[v][j])){
						res+=j;
						tmp_col[id[u][v]]=j;
						vis[u][j]=vis[v][j]=1;
						break;
					}
			}
			if(chkmin(ans,res))memcpy(col,tmp_col,sizeof(col));
		}
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
#endif
	n=read();
	REP(i,1,n-1){
		int u=read(),v=read();
		E[u].pb(v),E[v].pb(u);
		solver_1::deg[u]++,solver_1::deg[v]++;
		solver_2::deg[u]++,solver_2::deg[v]++;
		solver_3::deg[u]++,solver_3::deg[v]++;
		solver_4::deg[u]++,solver_4::deg[v]++;
		solver_5::deg[u]++,solver_5::deg[v]++;
		id[u][v]=id[v][u]=i;
	}
	int Min=1e9;
	solver_1::calc(),chkmin(Min,solver_1::ans);
	solver_2::calc(),chkmin(Min,solver_2::ans);
	solver_3::calc(),chkmin(Min,solver_3::ans);
	solver_4::calc(),chkmin(Min,solver_4::ans);
//	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	solver_5::calc(),chkmin(Min,solver_5::ans);
//	cerr<<solver_1::ans<<endl;
//	cerr<<solver_2::ans<<endl;
//	cerr<<solver_3::ans<<endl;
//	cerr<<solver_4::ans<<endl;
//	cerr<<solver_5::ans<<endl;
	write(Min,'\n');
	if(solver_1::ans==Min){
		REP(i,1,n-1)
			write(solver_1::col[i],i==n-1?'\n':' ');
		return 0;
	}else if(solver_2::ans==Min){
		REP(i,1,n-1)
			write(solver_2::col[i],i==n-1?'\n':' ');
		return 0;
	}else if(solver_3::ans==Min){
		REP(i,1,n-1)
			write(solver_3::col[i],i==n-1?'\n':' ');
		return 0;
	}else if(solver_4::ans==Min){
		REP(i,1,n-1)
			write(solver_4::col[i],i==n-1?'\n':' ');
	}else if(solver_5::ans==Min){
		REP(i,1,n-1)
			write(solver_5::col[i],i==n-1?'\n':' ');
	}
	return 0;
}
