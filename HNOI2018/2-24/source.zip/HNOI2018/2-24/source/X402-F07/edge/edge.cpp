#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1005,mod=1e9+7;
int n,m,pos;
int dp[2][maxn][maxn];
int C[maxn][maxn];
void init(){
	REP(i,0,n)
		C[i][0]=1;
	REP(i,1,n)
		REP(j,1,n)
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
}
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
	if(x<0)x+=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
#endif
	n=read(),pos=read(),m=read();
	init();
	dp[1][0][pos==0]=1;
	REP(i,2,n){
		int t=i&1;
		REP(j,0,m)
			REP(k,0,i)
				dp[t][j][k]=0;
		REP(j,0,m){
			REP(k,0,i-1){
				if(!dp[t^1][j][k])continue;
				REP(l,0,k)
					REP(r,0,i-k-1)
						add(dp[t][j+l+r][k-l+r+(((l+r)&1)==(i<=pos))],1ll*C[k][l]*C[i-k-1][r]%mod*dp[t^1][j][k]%mod);
			}
		}
	}
	write(dp[n&1][m][n],'\n');
	return 0;
}
