#include<bits/stdc++.h>
using namespace std;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
const int maxn=210;
const int maxm=100100;
const int INF=1e9;
struct Edge{
	int s,t;
}edge[maxn];
int n,S,T;
int d[maxn],col[maxn];
int beg[maxm],tto[maxm<<1],nex[maxm<<1],e;
int c[maxm<<1],w[maxm<<1];
int id(int x,int y){
	return (x-1)*n+y;
}
void clear_graph(){
	e=1;
	memset(beg,0,sizeof(beg));
}
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void putin(int s,int t,int C,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
	c[e]=C;
}
void Addedge(int s,int t,int C,int v){
	putin(s,t,C,v);
	putin(t,s,-C,0);
}
void dfs(int u,int fa){
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		col[tto[i]]=col[u]^1;
		dfs(tto[i],u);
	}
}
int dis[maxm],f[maxm];
bool SPFA(){
	static queue<int> q;
	bool inq[maxm];
	while(!q.empty()) q.pop();
	for(int i=0;i<=T;i++)
		dis[i]=INF,inq[i]=0;
	dis[S]=0;
	q.push(S);
	int u;
	while(!q.empty()){
		u=q.front();
		q.pop();
		inq[u]=0;
		for(int i=beg[u];i;i=nex[i]){
			if(w[i]&&dis[u]+c[i]<dis[tto[i]]){
				dis[tto[i]]=dis[u]+c[i];
				f[tto[i]]=i;
				if(!inq[tto[i]]){
					q.push(tto[i]);
					inq[tto[i]]=1;
				}
			}
		}
	}
	return dis[T]<INF;
}
int solve(){
	int u=T,res=0,mn=INF;
	while(u!=S){
		chkmin(mn,w[f[u]]);
		u=tto[f[u]^1];
	}
	u=T;
	while(u!=S){
		res+=c[f[u]]*mn;
		w[f[u]]-=mn,w[f[u]^1]+=mn;
		u=tto[f[u]^1];
	}
	return res;
}
vector<int> vec[maxn];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	clear_graph();
	for(int i=1;i<n;i++){
		scanf("%d%d",&edge[i].s,&edge[i].t);
		d[edge[i].s]++,d[edge[i].t]++;
		putin(edge[i].s,edge[i].t);
		putin(edge[i].t,edge[i].s);
	}
	dfs(1,0);
	clear_graph();
	S=n*n,T=n*n+1;
	for(int i=1;i<n;i++){
		for(int j=1;j<n;j++){
			vec[i].push_back(e+1);
			if(col[edge[i].s])
				Addedge(id(edge[i].s,j),id(edge[i].t,j),j,1);
			else
				Addedge(id(edge[i].t,j),id(edge[i].s,j),j,1);
		}
	}
	for(int i=1;i<=n;i++){
		if(col[i]) Addedge(S,id(i,0),0,d[i]);
		else Addedge(id(i,0),T,0,d[i]);
		for(int j=1;j<n;j++){
			if(col[i])
				Addedge(id(i,0),id(i,j),0,1);
			else
				Addedge(id(i,j),id(i,0),0,1);
		}
		if(d[i]>30) return -1;
	}
	int ans=0;
	while(SPFA())
		ans+=solve();
	printf("%d\n",ans);
	for(int i=1;i<n;i++){
		for(int j=0;j<n-1;j++)
			if(w[vec[i][j]]==0)
				printf("%d ",j+1);
	}
	printf("\n");
	return 0;
}
