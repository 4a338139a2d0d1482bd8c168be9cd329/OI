#include<cstdio>
using namespace std;
const long long md=1e9+7;
long long f[1010][1010];
long long powd(long long x,long long y){
	long long ans=1;
	while(y){
		if(y&1) ans=ans*x%md;
		x=x*x%md;
		y>>=1;
	}
	return ans;
}
long long F(long long x){
	return (x*(x-1)/2)%md;
}
int main()
{
	freopen("edge.in","r",stdin);
	freopen("edge.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	f[0][m]=1;
	long long rev;
	for(int i=1;i<=k;i++)
	{
		rev=powd(i,md-2);
		for(int j=0;j<=n;j++)
		{
			f[i][j]=f[i-1][j]*(n-j)%md*j%md;
			if(j>=2)
				(f[i][j]+=f[i-1][j-2]*F(n-j+2))%=md;
			if(j<=n-2)
				(f[i][j]+=f[i-1][j+2]*F(j+2))%=md;
			if(i>1)
				f[i][j]=(f[i][j]-f[i-2][j]*(F(n)-i+2)%md+md)%md;
			f[i][j]=f[i][j]*rev%md;
		}
	}
	printf("%lld\n",f[k][0]);
	return 0;
}
