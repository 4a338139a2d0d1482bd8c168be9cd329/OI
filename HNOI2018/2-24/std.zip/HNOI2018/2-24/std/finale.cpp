#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
string procstatus(){
	ifstream t("/proc/self/status");
	return (string){istreambuf_iterator<char>(t),istreambuf_iterator<char>()};
}
int num;
int n,m;
struct node{
	int t,v;
};
vector<node> vec[1500*5];
int a[10],vis[10];
int b[10],pd[10];
int mp[1000100];
int zip(int *c,int l){
	int res=0;
	for(int i=l;i>=1;i--)
		res=res*(m+1)+c[i];
	return res;
}
void build_dfs(int l,int p){
	if(p>l){
		mp[zip(a,l)]=++num;
		return;
	}
	for(int i=1;i<=m;i++){
		if(vis[i]) continue;
		vis[i]=1;
		a[p]=i;
		build_dfs(l,p+1);
		vis[i]=0;
	}
}
int star[10];
void compelete(int l){
	for(int i=1;i<=m;i++){
		if(!vis[i])
			a[++l]=i;
	}
}
int getans(int fir,int l){
	static int c[10];
	for(int i=1;i<=l;i++)
		c[i]=a[b[i]];
	return (fir-1)*star[2]+mp[zip(c,l)];
}
void dfs_build(int fir,int &cnt,int ps,int l,int p){
	if(p>l){
		vec[ps].push_back((node){++cnt,getans(fir,l)});
		return;
	}
	for(int i=1;i<=m;i++){
		if(pd[i]) continue;
		b[p]=i;
		pd[i]=1;
		dfs_build(fir,cnt,ps,l,p+1);
		pd[i]=0;
	}
}
void Add_vector(int fir,int p,int l){
	int cnt=star[l];
	for(int i=1;i<m;i++){
		dfs_build(fir,cnt,p,i,1);
	}
}
void trade(int fir,int l){
	compelete(l);
	Add_vector(fir,++num,l);
}
void solve_dfs(int fir,int l,int p){
	if(p>l){
		trade(fir,l);
		return;
	}
	for(int i=1;i<=m;i++){
		if(vis[i]) continue;
		vis[i]=1;
		a[p]=i;
		solve_dfs(fir,l,p+1);
		vis[i]=0;
	}
}
void build(){
	for(int j=1;j<m;j++)
		build_dfs(j,1);
	for(int i=1;i<=m;i++)
		star[i]=num*(i-1);
	num=0;
	for(int i=1;i<m;i++)
		for(int j=1;j<m;j++)
			solve_dfs(i,j,1);
}
long long dp[10010],dq[10010];
void Mult(long long *A,long long *B){
	static long long fa[10010],fb[10010];
	for(int i=1;i<=star[m];i++)
		fa[i]=A[i],fb[i]=B[i],A[i]=0;
	for(int i=1;i<=star[m];i++)
		for(int j=0;j<(int)vec[i].size();j++)
			(A[vec[i][j].v]+=fa[i]*fb[vec[i][j].t])%=md;
}
bool isfir;
void dfs_getnext(long long *A,int fir,int l,int p){
	if(p>l){
		num++;
		if(dq[num]==0) return;
		int ps;
		for(int i=1;i<=m;i++)
		{
			a[p]=i;
			for(int j=1;j<=m;j++)
				pd[j]=0;
			pd[i]=1;
			for(ps=l;ps>=1;ps--){
				if(pd[a[ps]]) break;
				pd[a[ps]]=1;
			}
			if(l+1-ps>=m) continue;
			if(isfir&&ps==0) continue;
			(A[star[2]*(fir-1)+mp[zip(a+ps,l+1-ps)]]+=dq[num])%=md;
		}
		return;
	}
	for(int i=1;i<=m;i++){
		if(!vis[i]){
			vis[i]=1;
			a[p]=i;
			dfs_getnext(A,fir,l,p+1);
			vis[i]=0;
		}
	}
}
void Add(long long *A){
	for(int i=1;i<=star[m];i++)
		dq[i]=A[i],A[i]=0;
	num=0;
	for(int i=1;i<m;i++)
		for(int j=1;j<m;j++)
			dfs_getnext(A,i,j,1);
}
long long ans,v;
void dfs_color(int p,int r,int lim){
	if(p>r){
		(ans+=dp[(lim-1)*star[2]+mp[zip(a,lim+r)]]*v)%=md;
		return;
	}
	static bool vas[10];
	for(int i=lim+1;i<=m;i++){
		if(vas[i]) continue;
		vas[i]=1;
		a[p]=i;
		dfs_color(p+1,r,lim);
		vas[i]=0;
	}
}
void printarray(long long *A){
	for(int j=1;j<=star[m];j++)
		printf("%lld ",A[j]);
	printf("\n");
}
int main(){
	freopen("finale.in","r",stdin);
	freopen("finale.out","w",stdout);
	static long long f[10010];
	scanf("%d%d",&n,&m);
	build();
	for(int i=1;i<m;i++){
		a[i]=i;
		dp[(i-1)*star[2]+mp[zip(a,i)]]=1;
		f[(i-1)*star[2]+mp[zip(a,i)]]=1;
	}

	isfir=1;
	Add(dp);
	isfir=0;
	n--;
	static int stk[100];
	int top=0;
	while(n){
		stk[++top]=n&1;
		n>>=1;
	}
	for(int i=top;i>=1;i--){
		Mult(f,f);
		if(stk[i]) Add(f);
	}
	Mult(dp,f);

	for(int i=1;i<m;i++){
		v=1;
		for(int j=m;j>m-i;j--)
			v=v*j%md;
		for(int j=1;i+j<=m;j++){
			for(int k=j;k<j+i;k++)
				a[k]=k-j+1;
			dfs_color(1,j-1,i);
		}
	}
	printf("%lld\n",ans);
//	cerr<<ans<<endl;
//	cerr<<procstatus()<<endl;
//	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
	return 0;
}
