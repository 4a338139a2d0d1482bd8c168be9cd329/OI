#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
vector<int> vec[maxn];
int c[maxn];
bool vis[maxn];
int main(int argc,char *argv[]){
	FILE *fin,*fout,*fans,*fre,*fzt;
	fin=fopen(argv[1],"r");
	fout=fopen(argv[2],"r");
	fans=fopen(argv[3],"r");
	fre=fopen(argv[5],"w");
	fzt=fopen(argv[6],"w");
	int n,s,t;
	fscanf(fin,"%d",&n);
	for(int i=1;i<n;i++){
		fscanf(fin,"%d%d",&s,&t);
		vec[s].push_back(i);
		vec[t].push_back(i);
	}
	int ans,x;
	fscanf(fans,"%d",&ans);
	fscanf(fout,"%d",&x);
	if(ans!=x){
		fprintf(fzt,"Wrong Anwer!\n");
		fprintf(fre,"0");
		return 0;
	}
	int sum=0;
	for(int i=1;i<n;i++){
		if(fscanf(fout,"%d",&c[i])==EOF){
			fprintf(fzt,"Output Not Enough.\n");
			fprintf(fre,"0");
			return 0;
		}
		if(!(1<=c[i]&&c[i]<=100000)){
			fprintf(fzt,"Limit of The Color Exceeded.\n");
			fprintf(fre,"0");
			return 0;
		}
		sum=sum+c[i];
	}
	if(fscanf(fout,"%d",&x)!=EOF){
		fprintf(fzt,"Output Too Much.\n");
		fprintf(fre,"0");
		return 0;
	}
	if(sum!=ans) return -1;
	for(int i=1;i<=n;i++){
		for(int j=0;j<(int)vec[i].size();j++){
			if(vis[c[vec[i][j]]]){
				fprintf(fzt,"Two Edges Have The Same Color at Point %d.\n",i);
				fprintf(fre,"0");
				return 0;
			}
			vis[c[vec[i][j]]]=1;
		}
		for(int j=0;j<(int)vec[i].size();j++)
			vis[c[vec[i][j]]]=0;
	}
	fprintf(fre,"5");
	return 0;
}
