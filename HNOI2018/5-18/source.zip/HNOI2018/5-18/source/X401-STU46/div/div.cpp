#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
int n,m,a[201],b[201][100001],total[1001],tot[201];
void divide(int p)
{
	for(int i=1;i<=sqrt(a[p]);i++)
		if(a[p]%i==0)
		{
			b[p][++b[p][0]]=i;
			b[p][++b[p][0]]=a[p]/i;
		}
}
void divide1(int p)
{
	for(int i=1;i<=sqrt(a[p]);i++)
		if(a[p]%i==0)
		{
			total[i]++;
			if(i*i!=a[p])
				total[a[p]/i]++;
		}
}
int main()
{
	freopen("div.in","r",stdin);
	freopen("div.out","w",stdout);
	cin>>n>>m;
	if(m==1)
	{
		cin>>a[1];
		divide(1);
		sort(b[1]+1,b[1]+b[1][0]+1);
		for(int i=1;i<=b[1][0];i++)
			if(b[1][i]>n)
			{
				cout<<n-i+1<<endl<<i-1;
				return 0;
			}
		cout<<n-b[1][0]<<endl<<b[1][0];
		return 0;
	}
	if(n<=1000)
	{
		for(int i=1;i<=m;i++)
		{
			cin>>a[i];
			divide1(i);
		}
		for(int i=1;i<=n;i++)
			tot[total[i]]++;
		for(int i=0;i<=m;i++)
			cout<<tot[i]<<endl;
		return 0;
	}
	for(int i=1;i<=m;i++)
		cin>>a[i];
	for(int i=1;i<=m;i++)
		cout<<"0\n";
	cout<<n;
}
