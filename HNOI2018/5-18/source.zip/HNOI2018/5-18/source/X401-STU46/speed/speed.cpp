#include<iostream>
#include<cstdio>
using namespace std;
int maxx,n,m,road[21][21][3],l[70001],r[70001],book[21];
void dfs(int q,int step,int x)
{
	maxx=max(maxx,step);
	for(int i=1;i<=n;i++)
	{
		if(road[x][i][0]==1&&book[i]==0&&q>=road[x][i][1]&&q<=road[x][i][2])
		{
			book[i]=1;
			dfs(q,step+1,i);
			book[i]=0;
		}
	}
}
bool pd(int q,int left,int right)
{
	if(q>=left&&q<=right)
		return true;
	return false;
}
int main()
{
	freopen("speed.in","r",stdin);
	freopen("speed.out","w",stdout);
	cin>>n>>m;
	if(n<=20&&m<=20)
	{
		int q,a,b,lo,ro;
		for(int i=1;i<n;i++)
		{
			cin>>a>>b>>lo>>ro;
			road[a][b][0]=1;
			road[b][a][0]=1;
			road[a][b][1]=lo;
			road[b][a][1]=lo;
			road[a][b][2]=ro;
			road[b][a][2]=ro;
		}
		for(int i=1;i<=m;i++)
		{
			maxx=0;
			cin>>q;
			for(int i=1;i<=n;i++)
			{
				book[i]=1;
				dfs(q,0,i);
				book[i]=0;
			}
			cout<<maxx<<endl;
		}
		return 0;
	}
	else
	{
		int q,a,b,lo,ro;
		for(int i=1;i<n;i++)
		{
			cin>>a>>b>>lo>>ro;
			l[a]=lo;
			r[a]=ro;
		}
		for(int i=1;i<=m;i++)
		{
			cin>>q;
			int left=1,right=1,maxx=0;
			while(left<=n&&right<=n)
			{
				while(pd(q,l[right],r[right])&&right<=n)
					right++;
				maxx=max(maxx,right-left);
				left=right;
				while(!pd(q,l[left],r[left])&&left<=n)
					left++;
				right=left;
			}
			cout<<maxx<<endl;
		}
	}
}
