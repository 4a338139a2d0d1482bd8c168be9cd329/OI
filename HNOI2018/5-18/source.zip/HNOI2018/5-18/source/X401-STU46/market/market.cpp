#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int n,m,maxc,kind,before=0;
long long f[1000001];
struct node
{
	int c,v,t;
}k[301];
struct node2
{
	int t,use;
}k2[100001];
int cmp(node x,node y)
{
	return x.t<y.t;
}
int cmp1(node2 x,node2 y)
{
	return x.t<y.t;
}
int main()
{
	freopen("market.in","r",stdin);
	freopen("market.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>k[i].c>>k[i].v>>k[i].t;
	for(int i=1;i<=m;i++)
	{
		cin>>k2[i].t>>k2[i].use;
		maxc=max(maxc,k2[i].use);
	}
	sort(k+1,k+n+1,cmp);
	sort(k2+1,k2+m+1,cmp1);
	for(int i=1;i<=m;i++)
	{
		while(k[kind].t<=k2[i].t&&kind<=n)
			kind++;
		kind--;
		for(int j=before+1;j<=kind;j++)
			for(int l=maxc;l>=k[j].c;l--)
				f[l]=max(f[l],f[l-k[j].c]+k[j].v);
		cout<<f[k2[i].use]<<endl;
		before=kind;
	}
}
