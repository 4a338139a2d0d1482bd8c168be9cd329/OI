#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;

map<int,int>mp;

int n,m,sum,maxn,tot;

int num[210],a[210];

inline void find(int x){
	for(int i=1;i*i<=x;++i)
		if(x%i==0){
			int t=x/i;
			if(mp[i]) num[mp[i]]--;
			mp[i]++,num[mp[i]]++;
			if(t!=i&&t<=n){
				if(mp[t]) num[mp[t]]--;
				mp[t]++,num[mp[t]]++;
			}
		}
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("div.in","r",stdin);
	freopen("div.out","w",stdout);
#endif
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i) 
		scanf("%d",&a[i]),find(a[i]);
	for(int i=1;i<=m;++i) sum+=num[i];
	printf("%d\n",n-sum);
	for(int i=1;i<=m;++i) printf("%d\n",num[i]);
	return 0;
}
