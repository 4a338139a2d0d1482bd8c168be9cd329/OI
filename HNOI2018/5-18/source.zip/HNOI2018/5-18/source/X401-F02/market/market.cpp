#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std;

const int inf=1000000010;

struct shop{
	int c,val,t;
}a[310];

struct ask{
	int w,T,num;
}d[100010];

int n,m,tot;

int f[90010],ans[100010];

int tmp(shop a,shop b){return a.t<b.t;}

int cmp(ask a,ask b){return a.T<b.T;}

inline void dp(int x,int w){
	for(int i=tot;i>=x;--i) f[i]=min(f[i],f[i-x]+w);
	for(int i=tot-1;i>0;--i) f[i]=min(f[i],f[i+1]);
}

inline int ef(int w){
	int mid,l=0,r=tot,sum;
	while(l<=r){
		mid=(l+r)>>1;
		if(f[mid]<=w) sum=mid,l=mid+1;
		else r=mid-1;
	}
	return sum;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("market.in","r",stdin);
	freopen("market.out","w",stdout);
#endif
	scanf("%d%d",&n,&m);  tot=n*300;
	for(int i=1;i<=n;++i) scanf("%d%d%d",&a[i].c,&a[i].val,&a[i].t);
	for(int i=1;i<=m;++i) scanf("%d%d",&d[i].T,&d[i].w),d[i].num=i;
	sort(a+1,a+n+1,tmp);
	sort(d+1,d+m+1,cmp);
	for(int i=1;i<=tot;++i) f[i]=inf;
	for(int j=1,i=1;i<=m;++i){
		while(j<=n&&a[j].t<=d[i].T) dp(a[j].val,a[j].c),++j;
		ans[d[i].num]=ef(d[i].w);
	}
	for(int i=1;i<=m;++i) printf("%d\n",ans[i]);
	return 0;
}
