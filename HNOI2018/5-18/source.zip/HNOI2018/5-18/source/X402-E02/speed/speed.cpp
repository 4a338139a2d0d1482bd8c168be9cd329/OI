#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int read(){
	int x=0;
	char ch=0;
	while (ch<'0' || ch>'9') ch=getchar();
	while (ch<='9' && ch>='0'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x;	
}
const int N=70005;
int head[50],cnt;
struct node{
	int next,to,l,r;
}a[50];
struct path{
	int l,r,d;
}s[50][50];
void add(int u,int v,int l,int r){
	a[++cnt].to=v;
	a[cnt].next=head[u];
	head[u]=cnt;
	a[cnt].l=l;
	a[cnt].r=r;
}
int n,m;
struct edge{
	int u,v,l,r;
}p[N];
struct query{
	int v,id;
}q[N];
bool cmp(edge a,edge b){
	return a.r>b.r;
}
bool cmp2(query a,query b){
	return a.v>b.v;
}
int num[N];
int f[N],sz[N],ans;
int find(int x){
	if (x==f[x]) return x;
	return f[x]=find(f[x]);
}
void link(int u,int v){
	int fx=find(u),fy=find(v);
	if (fx!=fy){
		f[fx]=fy;
		sz[fy]+=sz[fx];
		ans=max(ans,sz[fy]);
	}
}
void dfs(int S,int x,int fa,int d){
	s[S][x].d=d;
	for (int i=head[x];i;i=a[i].next){
		int y=a[i].to;
		if (y==fa) continue;
		s[S][y].l=max(s[S][x].l,a[i].l);
		s[S][y].r=min(s[S][x].r,a[i].r);
		dfs(S,y,x,d+1);
	}
}
int main(){	
	freopen("speed.in","r",stdin);
	freopen("speed.out","w",stdout);
	n=read();m=read();
	if (n<=20 && m<=20){
		for (int i=1;i<n;++i){
			int u=read(),v=read(),l=read(),r=read();
			add(u,v,l,r);add(v,u,l,r);
		}
		for (int i=1;i<=n;++i){
			s[i][i].l=0;
			s[i][i].r=1e9;
			dfs(i,i,0,0);
		}
		while (m--){
			int x=read();
			ans=0;
			for (int i=1;i<=n;++i)
				for (int j=1;j<=n;++j)
					 if (s[i][j].l<=x && s[i][j].r>=x)
						ans=max(ans,s[i][j].d);
			printf("%d\n",ans);
		}
		return 0;
	}
	for (int i=1;i<n;++i){
		p[i].u=read();
		p[i].v=read();
		p[i].l=read();
		p[i].r=read();
	}
	for (int i=1;i<=m;++i){
		q[i].id=i;
		q[i].v=read();
	}
	sort(p+1,p+n,cmp);
	sort(q+1,q+m+1,cmp2);
	int now=0;
	for (int i=1;i<=n;++i){
		f[i]=i;
		sz[i]=1;
	}
	for (int i=1;i<=m;++i){
		while (p[now+1].r>=q[i].v && now<n-1){
			++now;
			link(p[now].u,p[now].v);
		}
		num[q[i].id]=ans;
	}
	for (int i=1;i<=m;++i)
		printf("%d\n",num[i]-1);
	return 0;
}
