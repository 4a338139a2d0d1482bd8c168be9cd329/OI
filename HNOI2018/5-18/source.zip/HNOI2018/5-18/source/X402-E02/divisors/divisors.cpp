#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
using namespace std;
const int N=301;
const int inf=1e9+7;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		if (ch=='-') w=-1;
		ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*w;
}
int n,m,sum;
int a[210],ans[210];
map <int,int>mp;
void solve(int x){
	for (int i=1;i*i<=x && i<=n;++i){
		if (x%i==0){
			if (mp[i]) --ans[mp[i]];
			else ++sum;
			++mp[i];++ans[mp[i]];
			if (i*i!=x && x/i<=n){
				if (mp[x/i]) --ans[mp[x/i]];
				else ++sum;
				++mp[x/i];++ans[mp[x/i]];
			}
		}
	}
}
int main(){
	freopen("divisors.in","r",stdin);
	freopen("divisors.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=m;++i){
		int x=read();
		solve(x);
	}	
	printf("%d\n",n-sum);
	for (int i=1;i<=m;++i)
		printf("%d\n",ans[i]);
	return 0;
}
