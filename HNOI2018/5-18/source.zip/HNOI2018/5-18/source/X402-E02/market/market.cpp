#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
const int N=301;
const int inf=1e9+7;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		if (ch=='-') w=-1;
		ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*w;
}
int dp[N][N*N];
int mn[N][N*N];
struct node{
	int w,v,t;
}a[N];
bool cmp(node u,node v){
	return u.t<v.t;
}
struct query{
	int id,t,c;
}q[100005];
bool cmp2(query u,query v){
	return u.t<v.t;
}
int ans[100005];
int n,m,sum;
int find(int x,int y){
	if (mn[x][sum]<=y) return sum+1;
	int l=0,r=sum;
	while (l<r){
		int mid=(l+r)>>1;
		if (mn[x][mid]>y) r=mid;
		else l=mid+1;
	}
	return r;
}
int main(){
	freopen("market.in","r",stdin);
	freopen("market.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=n;++i){
		a[i].w=read();
		a[i].v=read();
		sum+=a[i].v;
		a[i].t=read();
	}
	sort(a+1,a+n+1,cmp);
	dp[0][0]=0;
	for (int j=1;j<=sum;++j)
		dp[0][j]=inf;
	for (int i=1;i<=n;++i){
		for (int j=0;j<=sum;++j){
			dp[i][j]=dp[i-1][j];
			if (j>=a[i].v) dp[i][j]=min(dp[i][j],dp[i-1][j-a[i].v]+a[i].w);
			if (dp[i][j]>1e9) dp[i][j]=inf;
		}
		mn[i][sum]=dp[i][sum];
		for (int j=sum-1;j>=0;--j)
			mn[i][j]=min(dp[i][j],mn[i][j+1]);
	}
	for (int i=1;i<=m;++i){
		q[i].id=i;
		q[i].t=read();
		q[i].c=read();
	}
	sort(q+1,q+m+1,cmp2);
	int now=0;
	for (int i=1;i<=m;++i){
		while (a[now+1].t<=q[i].t && now<n) ++now;
		int k=find(now,q[i].c)-1;
		ans[q[i].id]=k;
	}
	for (int i=1;i<=m;++i)
		printf("%d\n",ans[i]);
	return 0;
}
