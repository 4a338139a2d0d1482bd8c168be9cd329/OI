#include <bits/stdc++.h>
using namespace std;
int m,n,a[201],ans[201],fac[600000];
int main() {
	freopen("div.in","r",stdin);
	freopen("div.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i = 1;i <= m;i++) {
		scanf("%d",&a[i]);
		int tmp = sqrt(a[i]);
		for (int j = 1;j <= tmp;j++)
			if (!(a[i]%j)) {
				fac[++fac[0]] = j;
				if (a[i]/j != j) fac[++fac[0]] = a[i]/j;
			}
	}
	sort(fac+1,fac+fac[0]+1);
	int pos = 1,num = fac[1],tmp = 0;
	while (pos <= fac[0] && num <= n) {
		int cnt = 0;
		for (;fac[pos] == num && num <= n;cnt++,pos++);
		ans[cnt]++; tmp++;
		num = fac[pos];
	}
	printf("%d\n",n-tmp);
	for (int i = 1;i <= m;i++) printf("%d\n",ans[i]);
	return 0;
}
