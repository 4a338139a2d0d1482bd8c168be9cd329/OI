#include <bits/stdc++.h>
using namespace std;
const int maxn = 100000 + 10;
int n,m,c[maxn],v[maxn],t[maxn],f[maxn];
int main() {
	freopen("market.in","r",stdin);
	freopen("market.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i = 1;i <= n;i++) scanf("%d%d%d",&c[i],&v[i],&t[i]);
	for (int Case = 1,T,M;Case <= m;Case++) {
		memset(f,0,sizeof(f));
		scanf("%d%d",&T,&M);
		for (int i = 1;i <= n;i++)
			if (t[i] <= T)
				for (int j = M;j >= c[i];j--)
					f[j] = max(f[j],f[j-c[i]]+v[i]);
		printf("%d\n",f[M]);
	}
	return 0;
}
