#include<bits/stdc++.h>
using namespace std;
const int N=71000;
int n,q,s[N][2],fa[N],sz[N],rt[N];bool rev[N];
bool isrt(int x){return s[fa[x]][0]!=x&&s[fa[x]][1]!=x;}
void pushup(int x){sz[x]=sz[s[x][0]]+sz[s[x][1]]+1;}
void rotate(int x){
	int y=fa[x],z=fa[y],tx=s[y][1]==x,&son=s[x][tx^1];
	fa[x]=z; if(!isrt(y))s[z][s[z][1]==y]=x;//else
	if(son)fa[son]=y; s[y][tx]=son;
	fa[y]=x; son=y;
	pushup(y);
}
void pushdown(int x){
	if(rev[x]){
		int &ls=s[x][0],&rs=s[x][1];
		swap(ls,rs);
		rev[ls]^=1,rev[rs]^=1,rev[x]=0;
	}
}
void down(int x){if(!isrt(x))down(fa[x]);pushdown(x);}
void splay(int x){
	down(x);
	while(!isrt(x)){
		int y=fa[x],z=fa[y];
		if(!isrt(y))s[y][1]==x^s[z][1]==y?rotate(x):rotate(y);
		rotate(x);
	}
	pushup(x);
}
void access(int x){for(int y=0;x;x=fa[x])splay(x),s[x][1]=y,y=x;}
int findrt(int x){while(fa[x])x=fa[x];pushdown(x);while(s[x][0])x=s[x][0],pushdown(x);return x;}
int findtop(int x){while(!isrt(x))x=fa[x];return x;}
void rert(int x){access(x),splay(x),rev[x]^=1;}
void Link(int x,int y){rert(x),fa[x]=y;}
//void Cut(int x,int y){}
int callen(int x,int y){rert(x),access(y),splay(y);return sz[y]-1;}//x==rt
struct edge{int u,v,l,r;}e1[N],e2[N];
bool cmp(const edge &a,const edge &b){return a.l<b.l;}
bool cmp2(const edge &a,const edge &b){return a.r<b.r;}
//multiset<int>st;

int ans[N],Len;

void Add(edge a){
	int rt1=findrt(a.u),u1=rt[rt1];
	int rt2=findrt(a.v),u2=rt[rt2];
	Link(a.u,a.v);
	int len1=callen(rt1,u1);
	int len2=callen(rt2,u2);
//	st.erase(st.find(len1));
//	st.erase(st.find(len2));
	int len3=callen(rt1,rt2);
	int len4=callen(u1,u2);
	int len5=callen(rt1,u2);
	int len6=callen(u1,rt2);
	int len=max(max(max(max(max(len1,len2),len3),len4),len5),len6);
//	st.insert(len);
	Len=max(len,Len);
	if(len==len1)rert(rt1),rt[rt1]=u1;
	else if(len==len2)rert(rt2),rt[rt2]=u2;
	else if(len==len3)rert(rt1),rt[rt1]=rt2;
	else if(len==len4)rert(u1),rt[u1]=u2;
	else if(len==len5)rert(rt1),rt[rt1]=u2;
	else rert(u1),rt[u1]=rt2;
}
struct BAOLI{
	vector<int>vec[25];
	int ss,tt,dep[25];
	void dfs(int u,int f){
		dep[u]=dep[f]+1;
		if(!tt||dep[tt]<dep[u])tt=u;
		for(int i=0;i<vec[u].size();i++)
			if(vec[u][i]!=f)dfs(vec[u][i],u);
	}
	void work(){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)vec[j].clear();
			for(int j=1;j<n;j++)
				if(e1[j].l<=i&&i<=e1[j].r)
					vec[e1[j].u].push_back(e1[j].v),vec[e1[j].v].push_back(e1[j].u);
			memset(dep,0,sizeof(dep));
			for(int j=1;j<=n;j++)if(!dep[j]){
				tt=0;	
				dfs(j,0);
				ss=tt,tt=0;
				dfs(ss,0);
				ans[i]=max(ans[i],dep[tt]-dep[ss]);
			}
		}
		for(int i=1,x;i<=q;i++)scanf("%d",&x),printf("%d\n",ans[x]);
	}
}baoli;
int main()
{
	freopen("speed.in","r",stdin);
	freopen("speed.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<n;i++)scanf("%d%d%d%d",&e1[i].u,&e1[i].v,&e1[i].l,&e1[i].r);
	if(0){
		baoli.work();
		return 0;
	}
	sort(e1+1,e1+n,cmp2);
	//sort(e2+1,e2+1+n,cmp2);
	for(int i=1;i<=n;i++)sz[i]=1,rt[i]=i;//,st.insert(0);
	for(int i=n,j=n-1;i>=1;i--){
		while(e1[j].r>=i&&j>=1)Add(e1[j--]);
	//	while(e2[k].r<i&&k<=n)Erase(e2[k++]);
		ans[i]=Len;
	}
	for(int i=1,x;i<=q;i++)scanf("%d",&x),printf("%d\n",ans[x]);
	return 0;
}
