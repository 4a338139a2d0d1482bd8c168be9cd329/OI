#include<bits/stdc++.h>
using namespace std;
map<int,int>mp;
int n,m,cnt[205];
void solve(int x){
	for(int i=1;i*i<=x;i++)
		if(x%i==0){
			if(i<=n)mp[i]++;
			if(i*i!=x&&x/i<=n)mp[x/i]++;
		}
}
int main(){
	freopen("div.in","r",stdin);
	freopen("div.out","w",stdout);
	int a,sum=0;
	cin>>n>>m;
	for(int i=1;i<=m;i++)scanf("%d",&a),solve(a);
	for(map<int,int>::iterator i=mp.begin();i!=mp.end();i++)
		cnt[i->second]++,sum++;
	printf("%d\n",n-sum);
	for(int i=1;i<=m;i++)printf("%d\n",cnt[i]);
	return 0;
}
