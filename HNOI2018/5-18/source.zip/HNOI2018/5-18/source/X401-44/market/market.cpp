#include<bits/stdc++.h>
using namespace std;
const int N=305,M=1.01e5,MAX=90000;
typedef long long ll;
int n,m,c[N],v[N],t[N],id[N];
int T[M],MN[M],Id[M],ans[M];
ll f[MAX+10];
bool cmp(int x,int y){return t[x]<t[y];}
bool cmp2(int x,int y){return T[x]<T[y];}
inline void Min(ll &x,ll y){if(x>y)x=y;}
void Push(int C,int V){
	for(int i=MAX;i>=V;i--)Min(f[i],min(f[i-V]+C,f[i+1]));
}
int main()
{
	freopen("market.in","r",stdin);
	freopen("market.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)scanf("%d%d%d",c+i,v+i,t+i),id[i]=i;
	sort(id+1,id+1+n,cmp);
	for(int i=1;i<=m;i++)scanf("%d%d",T+i,MN+i),Id[i]=i;
	sort(Id+1,Id+1+m,cmp2);
	memset(f,0x3f,sizeof(f));
	f[0]=0;
	for(int i=1,j=1;i<=m;i++){
		while(t[id[j]]<=T[Id[i]]&&j<=n)Push(c[id[j]],v[id[j]]),j++;
		ans[Id[i]]=upper_bound(f,f+MAX+1,MN[Id[i]])-f-1;
	}
	for(int i=1;i<=m;i++)printf("%d\n",ans[i]);
	return 0;
}
