#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define bitcnt(x) __builtin_popcount(x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=21;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
}
int n,a[N];
int dp[1<<N];
inline void Add(int&x,int y){x=x+y<mod?x+y:x+y-mod;}
vector<int>A,B;
inline bool check(int st,int x)
{
	A.clear(),B.clear();
	For(i,1,n)if((st>>(i-1))&1)A.pb(i);
	For(i,1,n)if(a[i]>=x)B.pb(i);
	if(SZ(A)!=SZ(B))return 0;
	For(i,0,SZ(A)-1)if(B[i]>A[i])return 0;
	return 1;
}
int main()
{
	//file();
	read(n);For(i,1,n)read(a[i]);
	dp[0]=1;
	For(x,0,(1<<n)-1)
	if(check(x,n-bitcnt(x)+1))
		For(i,1,n)
		if(!((x>>(i-1))&1))
				Add(dp[x|(1<<(i-1))],dp[x]);
	printf("%d\n",dp[(1<<n)-1]);
	return 0;
}

