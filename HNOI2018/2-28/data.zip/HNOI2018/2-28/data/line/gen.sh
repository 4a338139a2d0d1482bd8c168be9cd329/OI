./test > line7.in 
./line < line7.in >line7.out
./test > line8.in 
./line < line8.in >line8.out
./test > line9.in 
./line < line9.in >line9.out
./test > line10.in 
./line < line10.in >line10.out
./test > line11.in 
./line < line11.in >line11.out
./test > line12.in 
./line < line12.in >line12.out
