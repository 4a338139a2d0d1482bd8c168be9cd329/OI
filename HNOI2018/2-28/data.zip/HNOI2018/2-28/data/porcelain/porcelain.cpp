#include<bits/stdc++.h>
#define Sz(x) sizeof(x)
#define LS l,mid
#define RS mid+1,r
#define LC p<<1
#define RC p<<1|1
#define pub push_back
#define pob pop_back
#define SZ(x) ((int)x.size())
#define ALL(x) x.begin(),x.end()
#define getchar getchar_unlocked
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
using namespace std;
typedef long long LL;
const int N=300005;
const int inf=0x3f3f3f3f;
const int FLAG=12;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
}
int n,m,lstans,len;
int dep[N],dis[N],dfq[N];
int pos[N],dfs_time,RMQ[N<<1][21],lg2[N<<1];
int dfn[N],dfs_cnt,ls[N],rs[N];
int bgn[N],nxt[N<<1],to[N<<1],w[N<<1],E;
struct edge
{
	int u,v;
	edge(){}
	edge(int u,int v):u(u),v(v){}
}e[N];
struct Tree
{
	int l,r,ans;
	Tree(){ans=-inf;}
	Tree(int l,int r,int ans):l(l),r(r),ans(ans){}
}a[N];
inline bool operator<(const Tree&A,const Tree&B){return A.l==B.l?A.r<B.r:A.l<B.l;}
inline void add_edge(int u,int v,int ew){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v,w[E]=ew;}
inline bool cmp_ans(const Tree&A,const Tree&B){return A.ans<B.ans;}
inline bool cmp_dfn(const int&x,const int&y){return dfn[x]<dfn[y];}
inline bool cmp_dep(const int&x,const int&y){return dep[x]<dep[y];}
inline bool in_tree(const int&x,const int&y){return ls[x]<=ls[y]&&rs[y]<=rs[x];}
inline void dfs(int u,int f)
{
	ls[u]=dfn[u]=++dfs_cnt;
	RMQ[pos[u]=++dfs_time][0]=u;
	dfq[dfs_cnt]=u;
	dep[u]=dep[f]+1;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dis[v]=dis[u]+w[i];
		dfs(v,u);
		RMQ[++dfs_time][0]=u;
	}
	rs[u]=dfs_cnt;
}
inline void init_RMQ(int n)
{
	For(i,1,n)lg2[i]=(1<<(lg2[i-1]+1))<=i?lg2[i-1]+1:lg2[i-1];
	For(j,1,20)
		For(i,1,n-(1<<(j-1))+1)
			RMQ[i][j]=min(RMQ[i][j-1],RMQ[i+(1<<(j-1))][j-1],cmp_dep);
}
inline int Get_lca(int x,int y)
{
	x=pos[x],y=pos[y];
	if(x>y)swap(x,y);
	register int ret=lg2[y-x+1];
    return min(RMQ[x][ret],RMQ[y-(1<<ret)+1][ret],cmp_dep);
}
inline int Get_dis(int x,int y){return dis[x]+dis[y]-(dis[Get_lca(x,y)]<<1);}
int id[N],in[N],q[N],top;
vector<int>G[N];
struct node
{
	int len;vector<int>t,down,up,s;
	node(){}
	inline void dfs1(int u)
	{
		if(in[u])down[u]=0;
		int Max=-inf,Maxc=-inf,Maxp=0;
		for(int i=0;i<=SZ(G[u])-1;i+=2)
		{
			int v=G[u][i],w=G[u][i|1];
			dfs1(v);
			if(down[v]==-inf)continue;
			if(Max<=down[v]+w)
				Maxc=Max,Max=down[v]+w,Maxp=v;
			else 
				chkmax(Maxc,down[v]+w);
		}
		chkmax(down[u],Max);
		for(int i=0;i<=SZ(G[u])-1;i+=2)
		{
			int v=G[u][i],w=G[u][i|1];
			chkmax(up[v],(Maxp==v?Maxc:Max)+w);
		}
	}
	inline void dfs2(int u)
	{
		for(int i=0;i<=SZ(G[u])-1;i+=2)
		{
			int v=G[u][i],w=G[u][i|1];
			if(up[u]!=inf)chkmax(up[v],up[u]+w);
			if(in[u])chkmax(up[v],w);
			dfs2(v);
		}
	}
	inline void Build()
	{
		t=s;sort(ALL(t),cmp_dfn);
		For(i,0,SZ(t)-1)t.pub(Get_lca(t[i],t[i+1]));
		t.pub(1);
		sort(ALL(t),cmp_dfn);
		t.resize(unique(ALL(t))-t.begin());
		len=SZ(t);
		down=vector<int>(len,-inf),up=vector<int>(len,-inf);
		For(i,0,len-1)id[t[i]]=i,G[i].clear(),in[i]=0;
		For(i,0,SZ(s)-1)in[id[s[i]]]=1;
		top=0;
		For(i,0,len-1)
		{
			int u=t[i];
			while(top&&!in_tree(q[top],t[i]))top--;
			if(top)
			{
				G[id[q[top]]].pub(id[u]);
				G[id[q[top]]].pub(dis[u]-dis[q[top]]);
			}
			q[++top]=u;
		}
		dfs1(0),dfs2(0);
		For(i,0,len-1)G[i].clear();
	}
	inline int Query(int x)
	{
		int l=0,r=len-1,posl=-1,posr=-1;
		while(l<=r)
		{
			int mid=(l+r)>>1;
			if(dfn[t[mid]]<=dfn[x])posl=mid,l=mid+1;
			else r=mid-1;
		}
		posr=posl+1;
		int f=1;
		if(posl!=-1)f=max(f,Get_lca(t[posl],x),cmp_dep);
		if(posr!=-1&&posr<len)f=max(f,Get_lca(t[posr],x),cmp_dep);
		int v=lower_bound(ALL(t),f,cmp_dfn)-t.begin();
		return max(Get_dis(x,t[v])+down[v],dis[x]-dis[t[v]]+up[v]);
	}
}t[1<<19];
inline void Build_tree(int l,int r,int p)
{
	if(l==r){t[p].s.pub(dfq[l]);return;}
	int mid=(l+r)>>1;
	Build_tree(LS,LC),Build_tree(RS,RC);
	For(i,0,t[LC].s.size()-1)t[p].s.pub(t[LC].s[i]);
	For(i,0,t[RC].s.size()-1)t[p].s.pub(t[RC].s[i]);
	if(r-l+1>FLAG)t[p].Build();
}
inline int Query_tree(int l,int r,int p,int x,int y,int rt)
{
	if(x<=l&&r<=y)
	{
		if(r-l+1<=FLAG)
		{
			int ret=-inf;
			For(i,0,t[p].s.size()-1)chkmax(ret,Get_dis(t[p].s[i],rt));
			return ret;
		}
		return t[p].Query(rt);
	}
	int mid=(l+r)>>1,ret=-inf;
	if(x<=mid)chkmax(ret,Query_tree(LS,LC,x,y,rt));
	if(y> mid)chkmax(ret,Query_tree(RS,RC,x,y,rt));
	return ret;
}
inline void Solve()
{
	int rt,K,x,cnt=0;
	read(rt);read(K);
	a[++cnt]=Tree(1,n,-inf);
	For(i,1,K)read(x),a[++cnt]=Tree(ls[e[x].u],rs[e[x].u],-inf);
	sort(a+1,a+cnt+1);
	static int st[N];
	int top=0,pre=0;
	For(i,1,cnt)
	{
		while(top&&a[st[top]].r<a[i].l)
		{
			int x=st[top];
			if(pre+1<=a[x].r)chkmax(a[x].ans,Query_tree(1,n,1,pre+1,a[x].r,rt));
			pre=a[x].r,top--;
		}
		if(pre+1<=a[i].l-1)chkmax(a[st[top]].ans,Query_tree(1,n,1,pre+1,a[i].l-1,rt));
		pre=a[i].l-1,st[++top]=i;
	}
	while(top)
	{
		int x=st[top];
		if(pre+1<=a[x].r)chkmax(a[x].ans,Query_tree(1,n,1,pre+1,a[x].r,rt));
		pre=a[x].r,top--;
	}
	sort(a+1,a+cnt+1,cmp_ans);
	For(i,1,cnt)printf("%d ",a[i].ans);
	puts("");
}
int main()
{
	int x,y,z;
	file();
	read(n),read(m);
	For(i,1,n-1)
	{
		read(x),read(y),read(z);
		add_edge(x,y,z),add_edge(y,x,z);
		e[i]=edge(x,y);
	}
	dfs(1,0);
	init_RMQ(dfs_time);
	For(i,1,n-1)if(dep[e[i].u]<dep[e[i].v])swap(e[i].u,e[i].v);
	Build_tree(1,n,1);
	while(m--)Solve();
	return 0;
}
