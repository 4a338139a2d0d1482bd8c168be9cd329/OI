./test < z1.txt > 1.in
./test < z2.txt > 2.in
./test < z3.txt > 3.in
./test < z4.txt > 4.in
./test < z5.txt > 5.in
./porcelain < 1.in >1.ans
./porcelain < 2.in >2.ans
./porcelain < 3.in >3.ans
./porcelain < 4.in >4.ans
./porcelain < 5.in >5.ans

