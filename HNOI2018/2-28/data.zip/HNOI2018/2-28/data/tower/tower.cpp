#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=2000010;
const int inf=0x3f3f3f3f;
const LL mod=998244353;
const LL Inv2=499122177;
const LL Inv6=166374059;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
}
LL n,m,Ans,MAX;
LL ans[5];
LL A[N],B[N],C[N];
unordered_map<LL,LL>mA,mB,mC;
inline void Add(LL&x,LL y){x=x+y<mod?x+y:x+y-mod;}
int p[N],mu[N],pr[N/10],cnt;
inline void init(int n)
{
	mu[1]=1;
	For(i,2,n)
	{
		if(!p[i])pr[++cnt]=i,mu[i]=-1;
		for(int j=1;j<=cnt&&i*pr[j]<=n;++j)
		{
			int x=i*pr[j];p[x]=1;
			if(i%pr[j]==0)break;
			mu[x]=-mu[i];
		}
	}
	For(i,1,n)
	{
		Add(A[i]=A[i-1],mu[i]);
		Add(B[i]=B[i-1],(mod+mu[i]*i)%mod);
		Add(C[i]=C[i-1],(mod+1ll*mu[i]*i*i%mod)%mod);
	}
}
inline LL S(LL n){n%=mod;return (n+1)*n%mod*Inv2%mod;}
inline LL S2(LL n){n%=mod;return n*(n+1)%mod*(2*n+1)%mod*Inv6%mod;}
inline LL Get_A(LL n)
{
	if(n<=MAX)return A[n];
	if(mA.count(n))return mA[n];
	LL ret=1;
	for(LL l=2,r;l<=n;l=r+1)
	{
		r=n/(n/l);
		Add(ret,mod-(r-l+1)*Get_A(n/l)%mod);
	}
	return mA[n]=ret;
}
inline LL Get_B(LL n)
{
	if(n<=MAX)return B[n];
	if(mB.count(n))return mB[n];
	LL ret=1;
	for(LL l=2,r,pre=S(1),now;l<=n;l=r+1,pre=now)
	{
		r=n/(n/l);
		now=S(r);
		Add(ret,mod-(now+mod-pre)*Get_B(n/l)%mod);
	}
	return mB[n]=ret;
}
inline LL Get_C(LL n)
{
	if(n<=MAX)return C[n];
	if(mC.count(n))return mC[n];
	LL ret=1;
	for(LL l=2,r,pre=S2(1),now;l<=n;l=r+1,pre=now)
	{
		r=n/(n/l);
		now=S2(r);
		Add(ret,mod-(now+mod-pre)*Get_C(n/l)%mod);
	}
	return mC[n]=ret;
}
LL nowA,preA,nowB,preB,nowC,preC;
int main()
{
	//file();
	read(n),read(m);
	if(n>m)swap(n,m);
	init(MAX=min((LL)pow(n,0.7)+1,(LL)(N-10)));
	for(LL l=1,r;l<=n;l=r+1)
	{
		r=min(n/(n/l),m/(m/l));
		LL x=(n/l)%mod,y=(m/l)%mod;
		nowA=Get_A(r),nowB=Get_B(r),nowC=Get_C(r);
		Add(ans[1],(nowA+mod-preA)*x%mod*y%mod);
		Add(ans[2],(nowB+mod-preB)*S(x)%mod*y%mod);
		Add(ans[3],(nowB+mod-preB)*x%mod*S(y)%mod);
		Add(ans[4],(nowC+mod-preC)*S(x)%mod*S(y)%mod);
		preA=nowA,preB=nowB,preC=nowC;
	}
	Add(Ans,ans[1]*n%mod*m%mod);
	Add(Ans,mod-ans[2]*m%mod);
	Add(Ans,mod-ans[3]*n%mod);
	Add(Ans,ans[4]);
	printf("%lld\n",Ans*4ll%mod);
	return 0;
}
