./test > tower7.in
./tower < tower7.in > tower7.ans
./test > tower8.in
./tower < tower8.in > tower8.ans
./test > tower9.in
./tower < tower9.in > tower9.ans
./test > tower10.in
./tower < tower10.in > tower10.ans
