#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef long long ll;
typedef double db;
#define x first
#define y second
const ll md=998244353;
ll n,m,ans;
pr stk[4],sstk[4];
bool vis[500][500];

inline int minn(int a,int b){if(a<b)return a;return b;}
inline int maxx(int a,int b){if(a>b)return a;return b;}
inline int gcd(int a,int b){return b?gcd(b,a%b):a;}

inline int cross(pr a,pr b)
{
	return a.x*b.y-a.y*b.x;
}

inline db calc()
{
	return fabs(cross(stk[1],stk[2])+cross(stk[2],stk[3])+cross(stk[3],stk[1]))/2.0;
}

inline void dfs(int p,int lasx,int lasy)
{
	if(p>=4)
	{
		db s=calc();
		if(s==0.5)
		{
			ans++;
			if(ans>=md)
				ans-=md;
		}
		return;
	}

	for(int i=lasx;i<=n;i++)
		for(int j=(i==lasx)?lasy:1;j<=m;j++)
			if(!vis[i][j])
			{
				stk[p]=pr(i,j);
				for(int k=1;k<p;k++)
					if(gcd(stk[p].x-stk[k].x,abs(stk[p].y-stk[k].y))!=1)
						goto nxt;
				vis[i][j]=1;
				dfs(p+1,i,j);
				vis[i][j]=0;
				nxt:;
			}
}

int main()
{
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);

	scanf("%lld%lld",&n,&m);
	dfs(1,1,1);
	printf("%d\n",ans);
	return 0;
}
