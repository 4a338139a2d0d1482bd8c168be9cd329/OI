#include<bits/stdc++.h>
using namespace std;

const int N=22;
const int md=1e9+7;

int n,ans;
int a[N];
vector<int> vec;
set<vector<int> >ha;

inline void dfs(vector<int> a)
{
	if(ha.find(a)!=ha.end())return;
	ans++;if(ans>=md)ans-=md;ha.insert(a);
	for(int i=0;i<n;i++)
		for(int j=i+1;j<n;j++)
			if(a[i]>a[j])
			{
				swap(a[i],a[j]);
				dfs(a);
				swap(a[i],a[j]);
			}
}

int main()
{
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		vec.push_back(a[i]);
	dfs(vec);
	printf("%d\n",ans);
	return 0;
}
