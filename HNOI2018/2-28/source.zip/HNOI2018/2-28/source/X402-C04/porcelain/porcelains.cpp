#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

inline int minn(int a,int b){if(a<b)return a;return b;}
inline int maxx(int a,int b){if(a>b)return a;return b;}
inline void chkmin(int &a,int b){if(a>b)a=b;}
inline void chkmax(int &a,int b){if(a<b)a=b;}

typedef pair<int,int> pr;
const int N=100009;
const int K=21;

struct tuple{int a,b,c;};

struct event
{
	int l,r;
	tuple p;
};

bool flag;
int n,m,ri,k;
int to[N<<1],nxt[N<<1],w[N<<1],beg[N],tot=1;
int fat[N][K],dep[N],dis[N],maxv[N],mem[N],etop;
int seg[N<<1],id[N],ed[N],stk[N],dfn,top;
vector<int> ans;
vector<event> recover;
pr se[N<<1];

int bit[N<<1];
inline void add(int p,int v)
{
	for(int i=p;i<=dfn;i+=i&-i)
		bit[i]+=v;
}
inline void mark(int l,int r){add(r,1);add(l-1,-1);}
inline int exi(int p)
{
	int ret=0;
	for(int i=p;i;i-=i&-i)
		ret+=bit[i];
	for(int i=p-1;i;i-=i&-i)
		ret-=bit[i];
	return ret;
}

namespace splay
{
	const int M=N<<1;
	int ch[M][2],fa[M],val[M],tx[M],tn[M],rt;

	inline void out(int x)
	{
		if(ch[x][0])out(ch[x][0]);
		printf("%d:[%d,%d][%d],bel %d,val %d,min %d,max %d\n",x,ch[x][0],ch[x][1],fa[x],seg[x],val[x],tn[x],tx[x]);
		if(ch[x][1])out(ch[x][1]);
	}
	
	inline void update(int x)
	{
		chkmax(tx[x]=val[x],maxx(tx[ch[x][0]],tx[ch[x][1]]));
		chkmin(tn[x]=val[x],minn(tn[ch[x][0]],tn[ch[x][1]]));
	}

	inline int build(int l,int r)
	{
		if(l>r)return 0;
		int mid=l+r>>1;
		val[mid]=tx[mid]=tn[mid]=dis[seg[mid]];
		if(l==r)return mid;
		fa[ch[mid][0]=build(l,mid-1)]=mid;
		fa[ch[mid][1]=build(mid+1,r)]=mid;
		update(mid);
		return mid;
	}

	inline void init()
	{
		tx[0]=-1e9+7;
		tn[0]=1e9+7;
		rt=build(1,dfn);
	}

	inline void rotate(int x)
	{
		int y=fa[x],z=fa[y];
		int l=(ch[y][1]==x);
		if(z)ch[z][ch[z][1]==y]=x;
		fa[x]=z;fa[y]=x;fa[ch[x][l^1]]=y;
		ch[y][l]=ch[x][l^1];ch[x][l^1]=y;
		update(y);update(x);
	}

	inline void splay(int x,int t=0)
	{
		for(int y=fa[x],z=fa[y];fa[x]!=t;rotate(x),y=fa[x],z=fa[y])
			if(fa[y]!=t)
			{
				if(ch[z][1]==y^ch[y][1]==x)rotate(y);
				else rotate(x);
			}
		if(!t)rt=x;
	}

	inline int fpre(int p)
	{
		splay(p);
		int ret=ch[p][0];
		while(ch[ret][1])ret=ch[ret][1];
		return ret;
	}
	
	inline int fnxt(int p)
	{
		splay(p);
		int ret=ch[p][1];
		while(ch[ret][0])ret=ch[ret][0];
		return ret;
	}

	inline int getseg(int l,int r)
	{
		if(l==1 && r==dfn)return rt;
		int l1=fpre(l),r1=fnxt(r);
		splay(l1);splay(r1,l1);
		return ch[r1][0];
	}

	inline tuple cut(int l,int r)
	{
		int l1=fpre(l),r1=fnxt(r);
		splay(l1);splay(r1,l1);
		int ret=ch[r1][0];
		ch[r1][0]=fa[ret]=0;
		update(r1);update(l1);
		return (tuple){l1,r1,ret};
	}

	inline int queryx(int p)
	{
		return tx[p];
	}

	inline int queryn(int p)
	{
		return tn[p];
	}
	
	inline void link(int l,int r,int p)
	{
		splay(l);splay(r,l);
		ch[r][0]=p;fa[p]=r;
		update(r);update(l);
	}

}

using namespace splay;

inline void add(int u,int v,int c)
{
	to[++tot]=v;nxt[tot]=beg[u];w[tot]=c;beg[u]=tot;
}

inline void dfs_pre(int u)
{	
	maxv[u]=dis[u];
	seg[id[u]=++dfn]=u;
	for(int i=beg[u],v;i;i=nxt[i])
		if((v=to[i])!=fat[u][0])
		{
			dis[v]=dis[u]+w[i];
			dep[v]=dep[u]+1;
			fat[v][0]=u;
			for(int j=1;j<K;j++)
				fat[v][j]=fat[fat[v][j-1]][j-1];
			dfs_pre(v);
			chkmax(maxv[u],maxv[v]);
		}
	seg[ed[u]=++dfn]=u;
}

inline int lca(int a,int b)
{
	if(dep[a]>dep[b])swap(a,b);
	for(int i=K-1;i>=0;i--)
		if(dep[fat[b][i]]>=dep[a])
			b=fat[b][i];
	if(a==b)return a;
	for(int i=K-1;i>=0;i--)
		if(fat[a][i]!=fat[b][i])
			a=fat[a][i],b=fat[b][i];
	return fat[a][0];
}

inline int dist(int u,int v)
{
	return dis[u]+dis[v]-2*dis[lca(u,v)];
}

inline int jump(int u,int d)
{
	for(int i=k-1;i>=0;i--)
		if(d&(1<<i))
			u=fat[u][i];
	return u;
}

inline int chkson(int u,int v)
{
	return jump(v,dep[v]-dep[u]-1);
}

int main()
{
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);

	n=read();m=read();
	for(int i=1,u,v,c;i<n;i++)
	{
		u=read();v=read();c=read();
		add(u,v,c);add(v,u,c);
	}
	dfs_pre(dep[1]=1);
	init();

	while(m--)
	{
		ri=read();k=read();etop=0;
		bool kill=0;
		for(int i=1,j,u,v;i<=k;i++)
		{
			j=read();u=to[j<<1],v=to[j<<1|1];
			if(dep[to[j<<1]]<dep[to[j<<1|1]])
				u=to[j<<1|1];
			se[++etop]=pr(id[u],u);
			se[++etop]=pr(ed[u],u);
		}
		se[++etop]=pr(1,1);
		se[++etop]=pr(dfn,1);
		sort(se+1,se+etop+1);
		top=0;
		for(int i=1;i<=etop;i++)
		{
			if(top && se[i].second==se[stk[top]].second)
			{
				int l=se[stk[top]].first,r=se[i].first;
				int currt=se[i].second;
				top--;

				if(l<=id[ri] && id[ri]<=r)//in subtree
				{
					if(currt==ri)//is root
					{
						kill=1;
						ans.push_back(queryx(getseg(l,r))-dis[ri]);
						if(l!=1 && r!=dfn)
						{
							recover.push_back((event){l,r,cut(l,r)});
							mark(l,r);
						}
					}
					else if(!kill)//cover
					{
						kill=1;
						int v=chkson(currt,ri),cans=-1e9+7;
						tuple cuts={0,0,-1},cutt={0,0,-1};

						if(exi(id[v]) && v!=ri)
							cuts=cut(id[v],ed[v]);
						if(exi(id[ri]))
							cutt=cut(id[ri],ed[ri]);

						if(~cutt.c)
							chkmax(cans,queryx(cutt.c)-dis[ri]);
						if(~cuts.c)
						{
							int tmp;
							chkmax(cans,tmp=(dis[r]-queryn(cuts.c)));
							cerr<<tmp<<endl;
						}
						chkmax(cans,queryx(getseg(l,r))+dis[ri]-2*dis[currt]);

						if(~cutt.c)
						{
							recover.push_back((event){id[ri],ed[ri],cutt});
							mark(id[ri],ed[ri]);
						}
						if(~cuts.c)
						{
							recover.push_back((event){id[v],ed[v],cuts});
							mark(id[v],ed[v]);
						}
						if(l!=1 && r!=dfn)
						{
							recover.push_back((event){l,r,cut(l,r)});
							mark(l,r);
						}
						ans.push_back(cans);
					}
					else//have cut
					{
						int v=chkson(currt,ri);
						tuple cuts={0,0,-1};
						if(exi(id[v]))
							cuts=cut(id[v],ed[v]);

						int cans=-1e9+7;
						if(~cuts.c)
							chkmax(cans,dis[ri]-queryn(cuts.c));
						chkmax(cans,queryx(getseg(l,r))+dis[ri]-2*dis[currt]);

						if(~cuts.c)
						{
							mark(id[v],ed[v]);
							recover.push_back((event){id[v],ed[v],cuts});
						}
						if(l!=1 && r!=dfn)
						{
							mark(l,r);
							recover.push_back((event){l,r,cut(l,r)});
						}
						ans.push_back(cans);
					}
				}
				else
				{
					int lcas=lca(currt,ri),cans=-1e9+7;
					chkmax(cans,queryx(getseg(l,r))+dis[ri]-2*dis[lcas]);
					ans.push_back(cans);
					mark(l,r);
					recover.push_back((event){l,r,cut(l,r)});
				}
			}
			else
				stk[++top]=i;
		}

		sort(ans.begin(),ans.end());
		for(int i=0,e=ans.size();i<e;i++)
			printf("%d ",ans[i]);
		puts("");
		ans.clear();
		for(int i=recover.size()-1;i>=0;i--)
		{
			int l=recover[i].l,r=recover[i].r;
			tuple p=recover[i].p;
			link(p.a,p.b,p.c);
			add(l-1,1);add(r,-1);
		}
		recover.clear();
	}

	return 0;
}
