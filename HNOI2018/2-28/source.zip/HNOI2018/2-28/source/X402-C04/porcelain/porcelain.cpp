#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

const int N=100009;
const int K=21;

int n,m,r,k;
int to[N<<1],nxt[N<<1],w[N<<1],beg[N],tot=1;
int fa[N][K],dep[N],dis[N],stk[N],top;
bool ban[N<<1];

inline void chkmax(int &a,int b){if(a<b)a=b;}

inline void add(int u,int v,int c)
{
	to[++tot]=v;nxt[tot]=beg[u];w[tot]=c;beg[u]=tot;
}

inline void dfs_pre(int u)
{	
	for(int i=beg[u],v;i;i=nxt[i])
		if((v=to[i])!=fa[u][0])
		{
			dis[v]=dis[u]+w[i];
			dep[v]=dep[u]+1;
			fa[v][0]=u;
			for(int j=1;j<K;j++)
				fa[v][j]=fa[fa[v][j-1]][j-1];
			dfs_pre(v);
		}

}

inline int lca(int a,int b)
{
	if(dep[a]>dep[b])swap(a,b);
	for(int i=K-1;i>=0;i--)
		if(dep[fa[b][i]]>=dep[a])
			b=fa[b][i];
	if(a==b)return a;
	for(int i=K-1;i>=0;i--)
		if(fa[a][i]!=fa[b][i])
			a=fa[a][i],b=fa[b][i];
	return fa[a][0];
}

inline int dist(int u,int v)
{
	return dis[u]+dis[v]-2*dis[lca(u,v)];
}

inline void dfs(int u,int pos)
{
	chkmax(stk[pos],dist(u,r));
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa[u][0])
		{
			if(ban[i])
				dfs(to[i],++top);
			else
				dfs(to[i],pos);
		}
}

int main()
{
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);

	n=read();m=read();
	for(int i=1,u,v,c;i<n;i++)
	{
		u=read();v=read();c=read();
		add(u,v,c);add(v,u,c);
	}
	dfs_pre(dep[1]=1);

	while(m--)
	{
		memset(ban,0,sizeof(ban));
		memset(stk,128,sizeof(stk));
		top=0;

		r=read();k=read();
		for(int i=1,j;i<=k;i++)
		{
			j=read();
			ban[j<<1]=ban[j<<1|1]=1;
		}
		dfs(1,++top);
		sort(stk+1,stk+top+1);
		for(int i=1;i<=top;i++)
			printf("%d ",stk[i]);
		puts("");
	}

	return 0;
}
