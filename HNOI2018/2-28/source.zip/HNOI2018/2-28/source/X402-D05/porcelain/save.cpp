#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
int Max(int x,int y){
	return x>y?x:y;
}
int n,m,mxdep;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e=1;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
bool vis[maxn];
namespace Root{
	int siz[maxn],mxson[maxn];
	void getsiz(int u,int fa){
		siz[u]=1,mxson[u]=0;
		for(int i=beg[u];i;i=nex[i]){
			if(tto[i]==fa) continue;
			if(vis[tto[i]]) continue;
			getsiz(tto[i],u);
			chkmax(mxson[u],siz[tto[i]]);
			siz[u]+=siz[tto[i]];
		}
	}
	int findrt(int Siz,int u,int fa){
		chkmax(mxson[u],Siz-siz[u]);
		if(mxson[u]*2<=Siz) return u;
		int v;
		for(int i=beg[u];i;i=nex[i]){
			if(tto[i]==fa) continue;
			if(vis[tto[i]]) continue;
			v=findrt(Siz,tto[i],u);
			if(v!=-1) return v;
		}
		return -1;
	}
	int getroot(int u){
		getsiz(u,0);
		return findrt(siz[u],u,0);
	}
}
int mmp[maxn],dp[18][maxn];
namespace tree{
#define mid ((l+r)>>1)
	struct node{
		int l,r,v;
	}tr[maxn*80];
	int num;
	void Build_tree(int dep,int &h,int l,int r){
		h=++num;
		if(l==r){
			tr[h].v=dp[dep][mmp[l]];
			return;
		}
		Build_tree(dep,tr[h].l,l,mid);
		Build_tree(dep,tr[h].r,mid+1,r);
		tr[h].v=Max(tr[tr[h].l].v,tr[tr[h].r].v);
	}
	int Query(int h,int l,int r,int s,int t){
		if(t<s) return 0;
		if(!h) return 0;
		if(s<=l&&r<=t) return tr[h].v;
		if(t<=mid) return Query(h<<1,l,mid,s,t);
		else if(s>mid) return Query(h<<1|1,mid+1,r,s,t);
		else return Max(Query(h<<1,l,mid,s,mid),Query(h<<1|1,mid+1,r,mid+1,t));
	}
}
int f[18][maxn],mpv[18][maxn],mpe[18][maxn];
int pre[18][maxn],rt[18][maxn],siz[18][maxn];
int low[18][maxn];
int dfs_time;
void dfs_getmp(int dep,int u){
	pre[dep][u]=++dfs_time,mmp[dfs_time]=u;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==f[dep][u]) continue;
		if(vis[tto[i]]) continue;

		mpe[dep][i>>1]=tto[i];
		dp[dep][tto[i]]=dp[dep][u]+1;
		mpv[dep][tto[i]]=mpv[dep][u];
		f[dep][tto[i]]=u;

		dfs_getmp(dep,tto[i]);
	}
	low[dep][u]=dfs_time;
}
void solve(int u,int dep){
	chkmax(mxdep,dep);

	dfs_time=0;
	f[dep][u]=0;
	dp[dep][u]=0;
	mpv[dep][u]=u;

	dfs_getmp(dep,u);

	siz[dep][u]=dfs_time;
	tree::Build_tree(dep,rt[dep][u],1,dfs_time);

	vis[u]=1;
	for(int i=beg[u];i;i=nex[i]){
		if(vis[tto[i]]) continue;
		solve(tto[i],dep+1);
	}
	vis[u]=0;
}
struct Edge{
	int s,t;
}edge[maxn];
struct node{
	int id,p,op;
};
bool cmp(const node &A,const node &B){
	return A.p==B.p?A.op<B.op:A.p<B.p;
}
vector<int> vec[maxn];
int Find_lca(int s,int t){
	for(int i=mxdep;i>=0;i--)
		if(mpv[i][s]==mpv[i][t])
			return mpv[i][s];
	return 0;
}
int stk[maxn],ttp;
int ans[maxn];
void solve_ans(int r){
	ttp=0;
	static node a[maxn<<1];
	static int ttk[maxn<<1];
	int top,ztz;
	int vr;
	for(int i=mxdep;i>=0;i--){
		vr=mpv[i][r];
		if(!vec[vr].size()) continue;
		top=0,ztz=0;
		for(int j=0;j<(int)vec[vr].size();j++){
			a[++top]=(node){vec[vr][j],pre[i][vec[vr][j]],1};
			a[++top]=(node){vec[vr][j],low[i][vec[vr][j]]+1,-1};
			ans[vec[vr][j]]=0;
		}
		sort(a+1,a+top+1,cmp);
		int las=1;
		for(int j=1;j<=top;j++){
			if(ztz)
				chkmax(ans[ttk[ztz]],tree::Query(rt[i][vr],1,siz[i][vr],las,a[j].p-1));
			if(a[j].op==1)
				ttk[++ztz]=a[j].id;
			else
				ztz--;
			las=a[j].p;
		}
		for(int j=1;j<=top;j++)
			if(a[j].op==1)
				stk[++ttp]=ans[a[j].id]+dp[i][r];
		vec[vr].clear();
	}
}
int main(){
	freopen("porcelain.in","r",stdin);
//	freopen("porcelain.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	int s,t,v;
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&s,&t,&v);
		edge[i].s=s,edge[i].t=t;
		putin(s,t,v);
		putin(t,s,v);
	}
	solve(Root::getroot(1),0);
	int r,k;
	int x;
	for(m=1;m<=M;m++){
		scanf("%d%d",&r,&k);
		for(int i=1;i<=k;i++){
			scanf("%d",&x);
			vec[Find_lca(Find_lca(edge[x].s,edge[x].t),r)].push_back(x);
		}
		vec[r].push_back(r);
		solve_ans(r);
		sort(stk+1,stk+ttp+1);
		for(int i=1;i<=ttp;i++)
			printf("%d ",stk[i]);
		printf("\n");
	}
	return 0;
}
