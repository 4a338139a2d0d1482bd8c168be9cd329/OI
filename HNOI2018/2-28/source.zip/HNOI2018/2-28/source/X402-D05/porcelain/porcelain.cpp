#include<bits/stdc++.h>
using namespace std;
const int maxn=3010;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
int n,m;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e=1;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
bool vis[maxn],pd[maxn];
int dep[maxn];
void dfs1(int u,int fa){
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		dep[tto[i]]=dep[u]+w[i];
		dfs1(tto[i],u);
	}
}
int dfs2(int u,int fa){
	int res=dep[u];
	pd[u]=1;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[i>>1]) continue;
		chkmax(res,dfs2(tto[i],u));
	}
	return res;
}
int main(){
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
	int M;
	int s,t,v;
	scanf("%d%d",&n,&M);
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&s,&t,&v);
		putin(s,t,v);
		putin(t,s,v);
	}
	int rt,k,x;
	static int stk[maxn];
	int top;
	for(m=1;m<=M;m++){
		scanf("%d%d",&rt,&k);
		for(int i=1;i<=k;i++){
			scanf("%d",&x);
			vis[x]=1;
		}
		dep[rt]=0;
		dfs1(rt,0);
		top=0;
		for(int i=1;i<=n;i++)
			if(!pd[i])
				stk[++top]=dfs2(i,0);
		sort(stk+1,stk+top+1);
		for(int i=1;i<=top;i++)
			printf("%d ",stk[i]);
		printf("\n");
		memset(pd,0,sizeof(pd));
		memset(vis,0,sizeof(vis));
	}
	return 0;
}
