#include<bits/stdc++.h>
using namespace std;
string procstatus(){
	ifstream t("/proc/self/status");
	return (string){istreambuf_iterator<char>(t),istreambuf_iterator<char>()};
}
const int md1=998244353,md2=1e9+9;
const int maxn=200;
const int md=1e9+7;
int a[maxn];
int n;
map<pair<int,int>,int> mp;
void remove(int *c,int *b,int num){
	int top=0;
	for(int i=1;i<=num;i++)
		if(b[i]!=1)
			c[++top]=b[i]-1;
}
pair<int,int> zip(int *b,int num){
	pair<int,int> res;
	res.first=res.second=0;
	for(int i=1;i<=num;i++){
		res.first=(res.first*(long long)(n+1)+b[i])%md1;
		res.second=(res.second*(long long)(n+1)+b[i])%md2;
	}
	return res;
}
int dfs(int *b,int num){
	if(num==1) return 1;
	pair<int,int> zp=zip(b,num);
	if(mp[zp]) return mp[zp];
	int c[21],stk[21],p;
	for(int i=1;i<=num;i++){
		if(b[i]==1){
			p=i;
			break;
		}
	}
	int top=0,ans=0;
	remove(c,b,num);
	(ans+=dfs(c,num-1))%=md;
	stk[0]=p;
	for(int i=p-1;i>=1;i--){
		while(top>0&&b[i]<b[stk[top]]) top--;
		stk[++top]=i;
		for(int j=1;j<=top;j++)
			swap(b[stk[j]],b[stk[j-1]]);
		remove(c,b,num);
		(ans+=dfs(c,num-1))%=md;
		for(int j=top;j>=1;j--)
			swap(b[stk[j]],b[stk[j-1]]);
	}
	mp[zp]=ans;
	return ans;
}
int main(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	printf("%d\n",dfs(a,n));
	return 0;
}
