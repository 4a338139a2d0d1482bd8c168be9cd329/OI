#include<bits/stdc++.h>
using namespace std;
map<pair<int,int>,bool> mp;
const int md1=1e9+7,md2=1004535809;
int n;
int a[200];
pair<int,int> zip(int *b){
	pair<int,int> res;
	res.first=0,res.second=0;
	for(int i=1;i<=n;i++){
		res.first=(res.first*(long long)(n+1)+b[i])%md1;
		res.second=(res.second*(long long)(n+1)+b[i])%md2;
	}
	return res;
}
int cnt=0;
void dfs(){
	if(mp[zip(a)]) return;
	mp[zip(a)]=1;
	cnt++;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(a[i]>a[j])
			{
				swap(a[i],a[j]);
				dfs();
				swap(a[j],a[i]);
			}
		}
	}
}
int main(){
	freopen("line.in","r",stdin);
	freopen("baoli.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	dfs();
	printf("%d\n",cnt);
	cerr<<cnt<<endl;
	return 0;
}
