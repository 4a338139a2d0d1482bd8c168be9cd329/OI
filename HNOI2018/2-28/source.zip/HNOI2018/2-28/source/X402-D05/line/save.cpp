#include<bits/stdc++.h>
using namespace std;
const int maxn=200;
const int md=1e9+7;
int a[maxn];
int dp[1<<20];
int val[maxn];
int main(){
	freopen("line.in","r",stdin);
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		a[i]--;
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<i;j++){
			if(a[j]<a[i])
				val[a[i]]|=1<<a[j];
		}
	}
	dp[0]=1;
	for(int i=0;i<(1<<n);i++){
		for(int j=0;j<n;j++){
			if(i&(1<<j)) continue;
			if((i&(val[j]))==val[j])
			{
				(dp[i|(1<<j)]+=dp[i])%=md;
				if((i|(1<<j))==7)
					printf("%d %d\n",i,dp[i]);
			}
		}
	}
	printf("%d\n",dp[(1<<n)-1]);
	return 0;
}
