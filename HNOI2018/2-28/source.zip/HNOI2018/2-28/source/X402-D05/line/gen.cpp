#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	static int a[100];
	int n=9;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		a[i]=i;
	random_shuffle(a+1,a+n+1);
	for(int i=1;i<=n;i++)
		printf("%d ",a[i]);
	printf("\n");
}
int main(){
	srand(time(0)+getx());
	freopen("line.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
