#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
int dp[200000];
int n,m;
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
long long solve(int k,int b){
	for(int i=0;i<=n*m+n*m+1;i++)
		dp[i]=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			dp[j*k-i*b+n*m]++;
	long long res=0;
	for(int i=1;i<=n*m*2;i++){
		if(!dp[i]) continue;
		res=(res+(dp[i]-1)%md*(dp[i+1]+dp[i-1]))%md;
	}
	return res;
}
int main(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	scanf("%d%d",&n,&m);
	long long ans=0;
	for(int i=0;i<=n-1;i++){
		for(int j=0;j<=m-1;j++){
			if(__gcd(i,j)!=1) continue;
			(ans+=solve(i,j)*((i&&j)?2:1))%=md;
		}
	}
	ans=ans*powd(3,md-2)%md;
	printf("%lld\n",ans);
	return 0;
}
