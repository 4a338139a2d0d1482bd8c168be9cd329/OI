#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

struct Range {
	int lx, rx, ly, ry;
};

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int n, m;

inline Range count(int x, int y) {
	Range res;
	res.lx = max(1, 1-x), res.rx = min(m, m-x);
	res.ly = max(1, 1-y), res.ry = min(n, n-y);
	return res;
}

ll ans/*, c[20]*/;

int main() {
	freopen("tower.in", "r", stdin);
	freopen("tower.out", "w", stdout);

	n = read(), m = read();
	int i, j, x, y;
	for(i = -m+1; i <= m-1; i++) {
		for(j = -n+1; j <= n-1; j++) {
			if(i == 0 && j == 0) continue;
			int g = __gcd(i, j);
			if(g != 1 && g != -1) continue;
			Range r1 = count(i, j);
			for(x = -m+1; x <= m-1; x++) {
				int sum = x*j+1;
				if(i == 0) {
					if(sum != 0) continue;
					for(y = -n+1; y <= n-1; y++) {
						Range r2 = count(x, y);
						int lx = max(r1.lx, r2.lx), rx = min(r1.rx, r2.rx);
						int ly = max(r1.ly, r2.ly), ry = min(r1.ry, r2.ry);
						if((rx-lx+1)<= 0 || (ry-ly+1) <= 0) continue;
						//if((rx-lx+1)*(ry-ly+1) == 2) printf("%d %d %d %d %lld\n", i, j, x, y, (rx-lx+1)*(ry-ly+1)%MOD);
						//c[(rx-lx+1)*(ry-ly+1)]++;
						update(ans, (rx-lx+1)*(ry-ly+1)%MOD);
					}
					continue;
				}
				if(sum % i != 0) continue;
				y = sum/i;
				if(y < -n+1 || y > n-1) continue;
				Range r2 = count(x, y);
				int lx = max(r1.lx, r2.lx), rx = min(r1.rx, r2.rx);
				int ly = max(r1.ly, r2.ly), ry = min(r1.ry, r2.ry);
				if((rx-lx+1) <= 0 || (ry-ly+1) <= 0) continue;
				/*if((rx-lx+1)*(ry-ly+1) == 2) {
					printf("%d %d %d %d\n", r1.lx, r1.rx, r1.ly, r1.ry);
					printf("%d %d %d %d\n", r2.lx, r2.rx, r2.ly, r2.ry);
					printf("%d %d %d %d %lld\n", i, j, x, y, (rx-lx+1)*(ry-ly+1)%MOD);
				}*/
				//c[(rx-lx+1)*(ry-ly+1)]++;
				update(ans, (rx-lx+1)*(ry-ly+1)%MOD);
			}
			//cerr << i << ' ' << j << endl;
		}
	}
	//printf("%lld %lld %lld %lld %lld %lld %lld\n", c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
	//printf("%lld %lld %lld %lld %lld %lld %lld\n", c[8], c[9], c[10], c[11], c[12], c[13], c[14]);
	printf("%lld\n", ans*qpow(3, MOD-2)%MOD);
	return 0;
}
