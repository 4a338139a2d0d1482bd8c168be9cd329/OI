#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

struct Range {
	int lx, rx, ly, ry;
};

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int n, m;

inline Range count(int x, int y) {
	Range res;
	res.lx = max(1, 1-x), res.rx = min(m, m-x);
	res.ly = max(1, 1-y), res.ry = min(n, n-y);
	return res;
}

ll ans;

int main() {
	freopen("tower.in", "r", stdin);
	freopen("tower.out", "w", stdout);

	n = read(), m = read();
	int x1, y1, x2, y2, x3, y3;
	for(x1 = 1; x1 <= m; x1++) 
		for(y1 = 1; y1 <= n; y1++) 
			for(x2 = 1; x2 <= m; x2++) 
				for(y2 = 1; y2 <= n; y2++) 
					for(x3 = 1; x3 <= m; x3++) 
						for(y3 = 1; y3 <= n; y3++) {
							int s = (x2-x1)*(y3-y1)-(y2-y1)*(x3-x1);
							if(s == 1) ans++;
						}
	printf("%lld\n", ans*qpow(3, MOD-2)%MOD);
	return 0;
}
