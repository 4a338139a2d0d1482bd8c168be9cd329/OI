#include<bits/stdc++.h>
using namespace std;

#define fst first
#define snd second
#define mkp make_pair
typedef pair<int, int> pii;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, r, K;

/*namespace PLAN {
	const int MAXN = 100010;
	struct Edge {
		int u, v;
	}E[MAXN];
	int st[MAXN], to[MAXN<<1], e;
	int nxt[MAXN<<1], w[MAXN<<1];
	inline void Add(int u, int v, int W) {
		to[++e] = v, nxt[e] = st[u];
		st[u] = e;
		to[++e] = u, nxt[e] = st[v];
		st[v] = e;
	}
	class LCT {
#define ls(p) (ch[(p)][0])
#define rs(p) (ch[(p)][1])
#define rel(p) (rs(fa[(p)]) == (p))
#define isroot(p) (ls(fa[(p)]) != (p) && rs(fa[(p)]) != (p))
	public:
		int fa[MAXN], ch[MAXN][2];
		int val[MAXN], mx[MAXN], im[MAXN];
		int S[MAXN];
		bool rev[MAXN];
		inline void update(int x) {
			mx[x] = max(val[x], im[x]);
			if(ls(x)) chkmax(mx[x], mx[ls(x)]);
			if(rs(x)) chkmax(mx[x], mx[rs(x)]);
		}
		inline void pushdown(int x) {
			if(rev[x]) {
				swap(ls(x), rs(x));
				rev[ls(x)] ^= 1;
				rev[rs(x)] ^= 1;
				rev[x] = 0;
			}
		}
		inline void rotate(int x) {
			int y = fa[x], f = rel(x), z = ch[x][f^1];
			fa[x] = fa[y];
			if(!isroot(y)) ch[fa[y]][rel(y)] = x;
			ch[fa[y] = x][f^1] = y;
			ch[fa[z] = y][f] = z;
			update(y);
		}
		inline void splay(int x) {
			int top, t;
			S[top = 1] = x;
			for(t = x; !isroot(t); t = fa[t]) S[++top] = fa[t];
			while(top) pushdown(S[top--]);
			for(int y = fa[x]; !isroot(y); rotate(x), y = fa[x]) 
				if(!isroot(y)) rotate(rel(x) == rel(y) ? y : x);
			update(x);
		}
		inline void access(int x) {
			for(int t = 0; fa[x]; t = x, x = fa[x]) 
				splay(x), rs(x) = t, update(x);
		}
		inline void reverse(int x) {
			access(x), splay(x), rev[x] ^= 1;
		}
		inline void link(int x, int y) {
			reverse(x), fa[x] = y;
		}
		inline void cut(int x, int y) {
			reverse(x), access(y), splay(y);
			fa[x] = ls(y) = 0, update(y);
		}
	}T;
	int fa[MAXN], dis[MAXN];
	void dfs(int u, int fa) {
		int i;
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(v == fa) continue;
			dis[v] = dis[u]+w[i];
			dfs(v, u);
		}
	}
	vector<int> del, ans;
	inline void solve() {
		int i, j;
		for(i = 1; i < n; i++) { 
			E[i].u = read(), E[i].v = read();
			Add(E[i].u, E[i].v, read());
		}
		r = read();
		dfs(r, 0);
		for(i = 1; i <= n; i++) T.mx[i] = T.val[i] = dis[i];
		for(i = 1; i < n; i++) T.link(E[i].u, E[i].v);
		bool done = true;
		while(m--) {
			if(done) done = false;
			else read();
			K = read();
			del.clear();
			for(i = 1; i <= K; i++) {
				int id = read();
				del.push_back(id);
				T.cut(E[id].u, E[id].v);
			}
			for(i = 1; i <= n; i++) {
				if(!T.fa[i]) 
		}
	}
}*/
const int MAXN = 3010;
struct Edge {
	int u, v, w;
}e[MAXN];
bool ban[MAXN];
vector<pii> G[MAXN];
int fa[MAXN], dis[MAXN];
bool vis[MAXN];

void DFS(int u) {
	int i;
	for(i = 0; i < (int)G[u].size(); i++) {
		if(G[u][i].snd == fa[u]) continue;
		fa[G[u][i].snd] = u;
		dis[G[u][i].snd] = dis[u]+e[G[u][i].fst].w;
		DFS(G[u][i].snd);
	}
}

int dfs(int u) {
	int i, res = dis[u];
	vis[u] = true;
	for(i = 0; i < (int)G[u].size(); i++) {
		if(ban[G[u][i].fst]) continue;
		int v = G[u][i].snd;
		if(vis[v]) continue;
		res = max(res, dfs(v));
	}
	return res;
}

vector<int> ans;

int main() {
	freopen("porcelain.in", "r", stdin);
	freopen("porcelain.out", "w", stdout);

	n = read(), m = read();
	/*if(n > 3000 || m > 3000) {
		PLAN::solve();
		return 0;
	}*/
	int i, u, v;
	for(i = 1; i < n; i++) {
		u = e[i].u = read(), v = e[i].v = read();
		e[i].w = read(); G[u].push_back(mkp(i, v));
		G[v].push_back(mkp(i, u));
	}

	while(m--) {
		r = read(), K = read();
		memset(ban, false, sizeof(ban));
		memset(vis, false, sizeof(vis));
		ans.clear();
		for(i = 1; i <= K; i++) ban[read()] = true;
		fa[r] = 0, dis[r] = 0, DFS(r);
		/*for(i = 1; i <= n; i++) printf("%d ", dis[i]);
		printf("\n");*/
		for(i = 1; i <= n; i++)
			if(!vis[i]) {
				ans.push_back(dfs(i));
				//printf("%d:%d\n", i, ans.back());
			}

		sort(ans.begin(), ans.end());
		for(i = 0; i <= K; i++) printf("%d ", ans[i]);
		printf("\n");
	}
	return 0;
}
