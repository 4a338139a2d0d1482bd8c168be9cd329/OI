#include<bits/stdc++.h>
using namespace std;

const int MAXN = 25;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, fac[MAXN];

inline int contor(const vector<int> &a) {
	int i, j, res = 0;
	for(i = n-2; i >= 0; i--) {
		int c = 0;
		for(j = i+1; j < n; j++) 
			if(a[j] < a[i]) c++;
		res += c * fac[n-1-i];
	}
	return res;
}

bool done[MAXN];

inline vector<int> incontor(int x) {
	vector<int> a;
	memset(done, false, sizeof(done));
	int i, j, c;
	for(i = n-1; i > 0; i--) {
		c = x / fac[i];
		for(j = 1; j <= n; j++) {
			if(!done[j]) {
				if(c) c--;
				else break;
			}
		}
		done[j] = true;
		a.push_back(j);
		x %= fac[i];
	}
	for(i = 1; i <= n; i++) if(!done[i]) a.push_back(i);
	return a;
}

vector<int> a;
queue<int> q;
set<int> s;

int main() {
	freopen("line.in", "r", stdin);
	freopen("line.out", "w", stdout);

	n = read();
	int i, j, x;
	for(i = 1; i <= n; i++) a.push_back(read());
	fac[0] = 1;
	for(i = 1; i <= n; i++) fac[i] = fac[i-1]*i;
	q.push(x = contor(a));
	s.insert(x);
	a = incontor(x);
	while(!q.empty()) {
		int u = q.front();
		q.pop();
		a = incontor(u);
		for(i = 0; i < n; i++) {
			for(j = i+1; j < n; j++) {
				if(a[i] < a[j]) continue;
				swap(a[i], a[j]);
				u = contor(a);
				if(!s.count(u)) {
					s.insert(u);
					q.push(u);
				}
				swap(a[i], a[j]);
			}
		}
	}
	printf("%d\n", (int)s.size());
	/*for(auto p : s) {
		a = incontor(p);
		for(i = 0; i < n; i++) printf("%d ", a[i]);
		printf("\n");
	}*/
	return 0;
}
