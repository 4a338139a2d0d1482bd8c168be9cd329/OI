#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int mod=998244353;
ll n,m,ans;
int xx[3],yy[3];

int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
void dfs(int x,int y,int pos){
	if(pos==3){
		if(abs((xx[1]-xx[0])*(yy[2]-yy[0])-(xx[2]-xx[0])*(yy[1]-yy[0]))!=1)
			return;
		++ans;
		return;
	}
	for(int j=y+1;j<=m;++j){
		xx[pos]=x;yy[pos]=j;
		dfs(x,j,pos+1);
	}
	for(int i=x+1;i<=n;++i)
		for(int j=1;j<=m;++j){
			xx[pos]=i;yy[pos]=j;
			dfs(i,j,pos+1);
		}
}

int main(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	dfs(0,m,0);
	printf("%lld\n",ans);
	return 0;
}
