#include<bits/stdc++.h>
//#include<tr1/unordered_map>
using namespace std;

typedef long long ll;
const int mod=998244353;
ll n,m,ans;

inline ll max_(ll a,ll b){return a>=b?a:b;}
/*
void solve(ll x,ll y){
	vector<ll> vec;
	for(ll i=x+1;i<=n;++i)
		for(ll j=1;j<=m;++j)
			vec.push_back((i-x)*(j-y));
	sort(vec.begin(),vec.end());
	for(ll i=0,j,p;i<vec.size();){
		j=i;
		while(j+1<vec.size()&&vec[i]==vec[j+1])
			++j;
		p=upper_bound(vec.begin(),vec.end(),vec[i]+1)-vec.begin();
		ans=(ans+(j-i+1)*(p-j-1))%mod;
		i=j+1;
	}
}
void solve(ll y){
	tr1::unordered_map<ll,ll> mp;
	for(ll i=1;i<n;++i){
		ll tmp=0;
		for(ll j=1;j<=m;++j){
			ll val=i*(j-y);
			++mp[val];
			if(mp.count(val-1))
				tmp=(tmp+mp[val-1])%mod;
			if(mp.count(val+1))
				tmp=(tmp+mp[val+1])%mod;
		}
		ans=(ans+tmp*(n-i))%mod;
	}
}
*/
void solve(){
	map<ll,vector<pair<ll,ll> > > mp;
	for(int i=1;i<n;++i)
		for(int j=-m+1;j<m;++j){
			if(!mp.count(i*j))
				mp[i*j];
			mp[i*j].push_back(make_pair(i,j));
		}
	map<ll,vector<pair<ll,ll> > >::iterator p=mp.begin(),q=mp.begin();
	if(p==mp.end())
		return;
	++p;
	for(;p!=mp.end();++p,++q){
		if(p->first!=q->first+1)
			continue;
		for(int i=0;i<q->second.size();++i){
			int a=q->second[i].first,c=q->second[i].second;
			for(int j=0;j<p->second.size();++j){
				int b=p->second[j].first,d=p->second[j].second;
				int e=max_(a,b),f=max_(max_(abs(c),abs(d)),abs(c-d));
				ans=(ans+(ll)(n-e)*(m-f))%mod;
			}
		}
	}
}

int main(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if(n<m)swap(n,m);
	ans=(ll)(n-1)*(m-1)%mod*m%mod;
	solve();
	printf("%lld\n",ans);
	return 0;
}
