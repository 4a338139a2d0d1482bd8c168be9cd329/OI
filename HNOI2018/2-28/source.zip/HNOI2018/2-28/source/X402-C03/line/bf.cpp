#include<bits/stdc++.h>
using namespace std;

const int maxn=20+10,mod=1e9+7;
int n,a[maxn];
vector<char> vec;
set<vector<char> > s;

void dfs(vector<char> now){
	if(s.insert(now).second)
		for(int i=0;i<n;++i)
			for(int j=i+1;j<n;++j)
				if(vec[i]>vec[j]){
					swap(vec[i],vec[j]);
					dfs(vec);
					swap(vec[i],vec[j]);
				}
}

int main(){
	freopen("line.in","r",stdin);
	freopen("line.txt","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
		vec.push_back(a[i]);
	}
	dfs(vec);
	printf("%d\n",(signed)s.size()%mod);
	return 0;
}
