#include<bits/stdc++.h>
using namespace std;

const int maxn=20+10,mod=1e9+7;
int n,a[maxn];

int main(){
	freopen("line.in","w",stdout);
	int seed;
	srand(seed=time(0)+clock()*clock()*clock());
	cerr<<seed<<endl;
	n=max(rand()%9+1,rand()%9+1);
//	n=20;
	printf("%d\n",n);
	for(int i=1;i<=n;++i)a[i]=i;
	random_shuffle(a+1,a+n+1);
	for(int i=1;i<=n;++i)
		printf("%d ",a[i]);
	return 0;
}
