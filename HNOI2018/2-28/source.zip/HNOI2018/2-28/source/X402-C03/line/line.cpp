#include<bits/stdc++.h>
using namespace std;

const int maxn=20,mod=1e9+7;
int n,a[maxn],dp[1<<maxn];

inline bool check(int i){
	int cnt=__builtin_popcount(i);
	for(int j=0,x=0,y=0;j<n;++j){
		x+=a[j]<=cnt;
		y+=i>>j&1;
		if(y<x)
			return false;
	}
	return true;
}

int main(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;++i)
		scanf("%d",&a[i]);
	dp[0]=1;
	for(int i=1;i<(1<<n);++i){
		if(!check(i))
			continue;
		for(int j=0;j<n;++j)
			if(i>>j&1)
				(dp[i]+=dp[i^(1<<j)])%=mod;
	}
	printf("%d\n",dp[(1<<n)-1]);
	return 0;
}
