#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+10;
int n,m,r,k,a[maxn];
int ecnt,ebeg[maxn],enxt[maxn<<1],eto[maxn<<1],ew[maxn<<1],eid[maxn<<1];
bool forbit[maxn];
multiset<int> ans;

inline void ae(int u,int v,int w,int id){
	++ecnt;
	enxt[ecnt]=ebeg[u];
	ebeg[u]=ecnt;
	eto[ecnt]=v;
	ew[ecnt]=w;
	eid[ecnt]=id;
}
void dfs(int pos,int fa,int dis,int&res){
	if(res<dis)
		res=dis;
	for(int i=ebeg[pos],v;i;i=enxt[i])
		if((v=eto[i])!=fa)
			if(forbit[eid[i]]){
				int tmp=dis+ew[i];
				dfs(v,pos,dis+ew[i],tmp);
				ans.insert(tmp);
			}
			else
				dfs(v,pos,dis+ew[i],res);
}

int main(){
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,u,v,w;i<n;++i){
		scanf("%d%d%d",&u,&v,&w);
		ae(u,v,w,i);
		ae(v,u,w,i);
	}
	while(m--){
		scanf("%d%d",&r,&k);
		for(int i=1;i<=k;++i){
			scanf("%d",&a[i]);
			forbit[a[i]]=true;
		}
		ans.clear();
		int tmp=0;
		dfs(r,r,0,tmp);
		ans.insert(tmp);
		for(multiset<int>::iterator i=ans.begin();i!=ans.end();++i)
			printf("%d ",*i);
		puts("");
		for(int i=1;i<=k;++i)
			forbit[a[i]]=false;
	}
	return 0;
}
