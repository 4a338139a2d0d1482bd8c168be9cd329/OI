#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
#define ull unsigned long long 
using namespace std;
const int N = 21, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
}
int n, a[N];
ull pw[N];
void init(){
	read(n);
	For(i, 1, n)read(a[i]);
	pw[0] = 1;
	For(i, 1, n)pw[i] = pw[i - 1] * 10;
}
ll ans=0;
tr1::unordered_map<ull, int>vis;
void dfs(ull now){
	if(!vis[now])vis[now] = 1, ++ans;
	else return ;
	For(i, 1, n)
		For(j, i + 1, n)if(a[i]	> a[j]){
			swap(a[i], a[j]);
			dfs(now + (ull)(a[i] - a[j]) * (pw[j - 1] - pw[i - 1])); 
			swap(a[i], a[j]);
		}
}
void solve(){
	ull cnt = 0;
	For(i, 1, n)cnt += a[i] * pw[i - 1];
	dfs(cnt);
	printf("%lld\n", ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
