#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();int f = 0;
	while(!isdigit(c))f |= (c=='-'), c = getchar();
	while( isdigit(c))x = x * 10 + c - 48, c = getchar();
}
inline void file(){
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
}
struct Segment_tree{
	#define mid ((l+r)>>1)
	#define lc h<<1
	#define rc h<<1|1
	#define Lc lc,l,mid
	#define Rc rc,mid+1,r
	int Max[N], Add[N];
	inline void pushdown(int h){
		if(Add[h]){
			Max[lc]+=Add[h],Max[rc]+=Add[h],Add[lc]+=Add[h],Add[rc]+=Add[h];
			Add[h]=0;
		}
	}
	inline void pushup(int h){
		Max[h]=max(Max[lc],Max[rc]);
	}
	inline void Modify(int 
}
int main(){
	file();
	init();
	sovle();
	return 0;
}
