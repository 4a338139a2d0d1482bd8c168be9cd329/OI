#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 200, INF = 0x3f3f3f3f, Mod = 998244353;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
}
int n, m;
inline void init(){
	read(n), read(m);
}
inline bool check(int x1, int x2, int y1, int y2){
	if(__gcd(abs(x1-x2), abs(y1-y2)) == 1)return 1;
	return 0;
}
inline int S(int x1, int y1, int x2, int y2){
	return abs(x1 * y2 - x2 * y1);
}
void solve(){
	int ans = 0;
	For(x1, 1, n)For(y1, 1, m)
		For(x2, 1, n)For(y2, 1, m)
			if(check(x1,x2,y1,y2))
				For(x3, 1, n)For(y3, 1, m)
					if(check(x1,x3,y1,y3)&&check(x2,x3,y2,y3))
						if(S(x2-x1,y2-y1,x3-x1,y3-y1) == 1)ans++;
	printf("%d\n",ans/6);
}
int main(){
	file();
	init();
	solve();
	return 0;
}

