#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	#endif
}
const int MAXN=1e5+7;
static int n,m;
static int ans;
const int mod=998244353;
int main(void){
	file();
	read(n);read(m);
    static int sum;
    Rep(i,1,n-1)Rep(j,1,m-1)
    {
        sum=0;
        Rep(k,0,i-1)if(j*k%i==i-1)++sum;
        Rep(k,1,i)if((j*k-1)%i==0)++sum;
        (ans+=1ll*(n-i)*(m-j)%mod*sum%mod)%=mod;
    }
    swap(n,m);
    Rep(i,1,n-1)Rep(j,1,m-1)
    {
        sum=0;
        Rep(k,0,i-1)if(j*k%i==i-1)++sum;
        Rep(k,1,i)if((j*k-1)%i==0)++sum;
        (ans+=1ll*(n-i)*(m-j)%mod*sum%mod)%=mod;
    }
    printf("%d\n",ans);
    return 0;
}

