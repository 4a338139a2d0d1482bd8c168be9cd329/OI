#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("line.in","w",stdout);
	#endif
}
const int MAXN=27;
const int n=10;
static int z[MAXN];
int main(void){
	file();
    srand(time(NULL));
	Rep(i,1,n)z[i]=i;
    random_shuffle(z+1,z+n+1);
    cout<<n<<endl;
    Rep(i,1,n)cout<<z[i]<<' ';cout<<endl;
    return 0;
}

