#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	#endif
}
const int MAXN=21;
static int a[MAXN],n;
static int ans;
inline void init()
{
    read(n);
    static int x;
    Rep(i,1,n)read(x),a[x]=i;
}
static int z[MAXN],k[MAXN];
inline int Judge()
{
    Rep(i,1,n)k[i]=a[i];
    Repe(i,n,1)
    {
        if(k[i]>z[i])return 0;
        for(register int j=i-1;j&&(k[i]^z[i]);--j)
            if(k[j]>k[i]&&k[j]<=z[i])
                swap(k[j],k[i]);
        if(k[i]^z[i])return 0;
    }
    return 1;
}
inline void solve()
{
    Rep(i,1,n)z[i]=i;
    do
    {
        ans+=Judge();
    }while(next_permutation(z+1,z+n+1));
    printf("%d\n",ans);
}
int main(void){
	file();
	init();
    solve();
    return 0;
}

