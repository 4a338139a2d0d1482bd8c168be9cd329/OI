#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
	#endif
}
const int MAXN=1e5+7;
static int n,m;
typedef pair<int,int> Pr;
static vector<Pr>edg[MAXN];
static int ed[MAXN][2];
inline void init()
{
    read(n);read(m);
    static int w;
    Rep(i,1,n-1)
    {
        read(ed[i][0]);read(ed[i][1]);read(w);
        edg[ed[i][0]].push_back(Pr(ed[i][1],w));
        edg[ed[i][1]].push_back(Pr(ed[i][0],w));
    }
}
#define fir first
#define sec second
namespace Cheat1
{
    int dis[3111][3111],vis[3111];
    static queue<int>G;
    inline void dfs(int s)
    {
        static int u,v;vis[s]=s;
        G.push(s);
        while(!G.empty())
        {
            u=G.front();G.pop();
            Rep(i,0,edg[u].size()-1)
                if(vis[v=edg[u][i].fir]^s)
                {
                    dis[s][v]=dis[s][u]+edg[u][i].sec;
                    vis[v]=s;G.push(v);
                }
        }
    }
    static int ans[3333];
    vector<Pr>spe[MAXN];
    inline void bfs(int x)
    {
        G.push(x);
        static int u;
        while(!G.empty())
        {
            u=G.front();G.pop();
            dfss(u);
        }
    }
    void main()
    {
        memset(dis,0x3f,sizeof dis);
        Rep(i,1,n)dfs(i);
        static int r,k,x;
        Rep(i,1,m)
        {
            Rep(j,1,n)spe[j].clear();
            read(r);read(k);
            Rep(j,1,k)
            {
                read(x);
                spe[ed[x][0]].push_back(ed[x][1]);
                spe[ed[x][1]].push_back(ed[x][0]);
            }
            bfs(r);
            sort(ans+1,ans+e+1);
            Rep(i,1,e)printf("%d ",ans[i]);putchar('\n');
        }
    }
}
inline void solve()
{
    if(m<=3000)Cheat1::main();
}
int main(void){
	file();
    init();
    solve();
	return 0;
}

