#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=20+5;
const int maxHash=1e6+10;
int a[maxn],Hash[maxHash];
int ans=0,n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
void dfs(){
	int i,j,flag=0,val=0;
	for(i=1;i<=n;i++){
		val*=7;val+=a[i];
		if(a[i]!=i)flag=1;
	}
	if(!Hash[val]){
		Hash[val]=1;
		ans++;
	}
	else return;
	for(i=1;i<=n;i++)
		for(j=i+1;j<=n;j++)
			if(a[i]>a[j]){
				swap(a[i],a[j]);
				dfs();
				swap(a[i],a[j]);
			}
}
int main(){
	int i,j,k,m;
#ifndef ONLINE_JUDGE
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
#endif
	n=read();
	for(i=1;i<=n;i++)a[i]=read();
	dfs();
	printf("%d\n",ans);
	return 0;
}

