#include<vector>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e5+10;
const int maxm=2e5+10;
int to[maxn<<1],nex[maxn<<1],beg[maxn],w[maxn<<1],dfn[maxn],id[maxn],dis[maxn],dep[maxn],sz[maxn];
int dfs_cnt,e,n;
struct Edge{
	int x,y,z;
}edge[maxn];
struct Q{
	int sum,id;
	vector <int> G,ans;
};
vector <Q> query[maxn];
vector <int> tmp,Tmp,Ans[maxm];
bool cmp(int x,int y){
	return dep[x]>dep[y];
}
inline int max(int x,int y){
	return x>y?x:y;
}
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
struct Seg_T{
	int Max[maxn<<2],col[maxn<<2],colT[maxn<<2],MaxT[maxn<<2];
	void Cls(){
		col[1]=0;colT[1]=0;
	}
	void Push_Down(int h){
		if(MaxT[h]!=0){
			Max[h<<1]+=MaxT[h];Max[h<<1|1]+=MaxT[h];
			MaxT[h<<1]+=MaxT[h];MaxT[h<<1|1]+=MaxT[h];
			MaxT[h]=0;
		}
		if(colT[h]!=-1){
			col[h<<1]=col[h<<1|1]=colT[h<<1]=colT[h<<1|1]=colT[h];
			colT[h]=-1;
		}
	}
	void Build(int h,int l,int r){
		if(l==r){
			Max[h]=dis[id[l]];
			colT[h]=-1;
			return;
		}
		int mid=(l+r)>>1;
		Build(h<<1,l,mid);
		Build(h<<1|1,mid+1,r);
		Max[h]=max(Max[h<<1],Max[h<<1|1]);
	}
	void Modify(int h,int l,int r,int L,int R,int val){
		if(L<=l && r<=R){
			Max[h]+=val;
			MaxT[h]+=val;
			return;
		}
		Push_Down(h);
		int mid=(l+r)>>1;
		if(L<=mid)Modify(h<<1,l,mid,L,R,val);
		if(R>mid)Modify(h<<1|1,mid+1,r,L,R,val);
		Max[h]=max(Max[h<<1],Max[h<<1|1]);
	}
	int Query(int h,int l,int r,int L,int R){
		if(L<=l && r<=R && col[h]==0){
			col[h]=1;colT[h]=1;
			return Max[h];
		}
		if(L<=l && r<=R && col[h]==1)return -INF;
		Push_Down(h);
		int mid=(l+r)>>1,ans=-INF;
		if(L<=mid)ans=max(ans,Query(h<<1,l,mid,L,R));
		if(R>mid)ans=max(ans,Query(h<<1|1,mid+1,r,L,R));
		if(col[h<<1]==col[h<<1|1])col[h]=col[h<<1];
		else col[h]=-1;
		return ans;
	}
}T;
inline void add(int x,int y,int z){
	to[++e]=y;nex[e]=beg[x];
	beg[x]=e;w[e]=z;
}
void dfs(int x,int fa){
	int i;
	dfn[x]=++dfs_cnt;id[dfs_cnt]=x;sz[x]=1;
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		dep[to[i]]=dep[x]+1;
		dis[to[i]]=dis[x]+w[i];
		dfs(to[i],x);
		sz[x]+=sz[to[i]];
	}
}
void Dfs(int x,int fa){
	int i,j;
	for(i=0;i<(int)query[x].size();i++){
		T.Cls();
		for(j=0;j<(int)query[x][i].G.size();j++){
			int p=query[x][i].G[j];
			query[x][i].ans.push_back(T.Query(1,1,n,dfn[p],dfn[p]+sz[p]-1));
		}
		query[x][i].ans.push_back(T.Query(1,1,n,1,n));
		sort(query[x][i].ans.begin(),query[x][i].ans.end());
	}
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		T.Modify(1,1,n,1,n,w[i]);
		T.Modify(1,1,n,dfn[to[i]],dfn[to[i]]+sz[to[i]]-1,-2*w[i]);
		Dfs(to[i],x);
		T.Modify(1,1,n,dfn[to[i]],dfn[to[i]]+sz[to[i]]-1,2*w[i]);
		T.Modify(1,1,n,1,n,-w[i]);
	}
}
int main(){
	int i,j,k,m,q;
#ifndef ONLINE_JUDGE
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
#endif
	n=read();q=read();
	for(i=1;i<n;i++){
		int x=read(),y=read(),z=read();
		edge[i]=(Edge){x,y,z};
		add(x,y,z);add(y,x,z);
	}
	dfs(1,0);
	for(i=1;i<n;i++)
		if(dep[edge[i].x]>dep[edge[i].y])swap(edge[i].x,edge[i].y);
	T.Build(1,1,n);
	int tot=0;
	while(q--){
		tot++;
		tmp.clear();
		int pos=read(),sum=read(),Id=tot;
		for(i=1;i<=sum;i++){
			int eid=read();
			tmp.push_back(edge[eid].y);
		}
		sort(tmp.begin(),tmp.end(),cmp);
		query[pos].push_back((Q){sum,Id,tmp,Tmp});
	}
	Dfs(1,0);
	for(i=1;i<=n;i++)
		for(j=0;j<(int)query[i].size();j++)
			for(k=0;k<(int)query[i][j].ans.size();k++){
				Ans[query[i][j].id].push_back(query[i][j].ans[k]);
			}
	for(i=1;i<=tot;i++){
		int Sz=Ans[i].size();
		for(j=0;j<Sz;j++)
			printf("%d ",Ans[i][j]);
		puts("");
	}
	return 0;
}

