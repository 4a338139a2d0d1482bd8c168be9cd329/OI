#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-6;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline bool chk(int x1,int y1,int x2,int y2,int x3,int y3){
	double a=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	double b=sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
	double c=sqrt((x2-x3)*(x2-x3)+(y2-y3)*(y2-y3));
	if(a<eps || b<eps || c<eps)return 0;
	if(a<b)swap(a,b);if(a<c)swap(a,c);if(b<c)swap(b,c);
	if(a+b-eps<c)return 0;
	double p=(a+b+c)/2;
	double S=sqrt(p*(p-a)*(p-b)*(p-c));
	if(fabs(S-0.5)<eps)return 1;
	else return 0;
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
#endif
	n=read();m=read();
	int x1,y1,x2,y2,x3,y3;
	int ans=0;
	for(x1=1;x1<=n;x1++)
		for(y1=1;y1<=m;y1++)
			for(x2=1;x2<=n;x2++)
				for(y2=1;y2<=m;y2++)
					for(x3=1;x3<=n;x3++)
						for(y3=1;y3<=n;y3++)
							if(chk(x1,y1,x2,y2,x3,y3))ans++;
	printf("%d\n",ans/6);
	return 0;
}

