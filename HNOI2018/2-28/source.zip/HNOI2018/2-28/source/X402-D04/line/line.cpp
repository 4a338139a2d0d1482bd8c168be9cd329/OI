#include<bits/stdc++.h>
using namespace std;

const int maxn=25;
int n;
int a[maxn];
map<vector<int>,int> mp;

int ans;
void get(){
	// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
	vector<int> g;
	for(int i=1;i<=n;i++) g.push_back(a[i]);
	if(!mp.count(g)) mp[g]=1, ans++;
}
void dfs(int x){
	get();
	for(int i=x;i<=n;i++) for(int j=i+1;j<=n;j++) if(a[i]>a[j]){
		swap(a[i],a[j]);
		dfs(i);
		swap(a[i],a[j]);
	}
}

int main(){
	freopen("line.in","r",stdin),freopen("line.out","w",stdout);

	scanf("%d", &n);
	for(int i=1;i<=n;i++) scanf("%d", &a[i]);
	dfs(1);
	printf("%d\n", ans);
	return 0;
}
