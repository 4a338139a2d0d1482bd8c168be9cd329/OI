#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1010;
const int mod=998244353;
int n, m;
ll ans;

int gcd(int x,int y){ return !y ? x : gcd(y,x%y); }

int main(){
	freopen("tower.in","r",stdin),freopen("tower.ans","w",stdout);
	
	scanf("%d%d", &n, &m);
	n--; m--;
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) if(gcd(i,j)==1){ ans+=(n-i+1)*(m-j+1); }
	printf("%lld\n", ans*4%mod);
	return 0;
}
