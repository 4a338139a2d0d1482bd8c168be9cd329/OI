#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=10000010;
const int maxm=1000010;
const int mod=998244353;
ll n, m, inv2, inv6;
ll ans;

int cnt, prime[maxn+10];
bool isprime[maxn+10];
short mu[maxn+10];
ll f1[maxm], f2[maxm], f[maxm];

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

void init(){
	mu[1]=1;
	for(int i=2;i<maxn;i++){
		if(!isprime[i]){ prime[++cnt]=i, mu[i]=-1; }
		for(int j=1;j<=cnt && 1ll*i*prime[j]<maxn;j++){
			isprime[i*prime[j]]=1; mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){ mu[i*prime[j]]=0; break; }
		}
	}
	for(int i=1;i<maxm;i++) f1[i]=(f1[i-1]+1ll*mu[i]*i%mod)%mod;
	for(int i=1;i<maxm;i++) f2[i]=(f2[i-1]+1ll*mu[i]*i%mod*i%mod)%mod;
	inv2=Pow(2,mod-2);
	inv6=Pow(6,mod-2);
	// for(int i=1;i<=10;i++) printf("%d ", mu[i]); puts("");
}

ll gcd(ll x,ll y){ return !y ? x : gcd(y,x%y); }

ll ans1,ans2,ans3,ans4;

ll Sum(ll x,ll y){ return (x*(x+1)%mod*inv2%mod)%mod * ( (y*(y+1)%mod*inv2%mod)%mod) %mod; }
ll C2(ll x){ 
	x%=mod;
	return x*(x+1)%mod*inv2%mod; 
}

ll sum2(ll x){
    x%=mod;
    return x*(x+1)%mod*(2*x+1)%mod*inv6%mod;
}

ll S(ll x){
	if(x<maxm) return f[x];
	ll ret=0;
	for(ll l,r,i=2;i<=x;i=r+1){
		l=i; r=x/(x/i);
		ret=(ret-(r-l+1)*S(x/i)%mod+mod)%mod;
	}
	return ret;
}

ll S1(ll x){
	if(x<maxm) return f1[x];
	ll ret=0;
	for(ll l,r,i=2;i<=x;i=r+1){
		l=i; r=x/(x/i);
		ret=(ret-(C2(r)-C2(l-1))*S1(x/i)%mod+mod)%mod;
	}
	return ret;
}

ll S2(ll x){
	if(x<maxm) return f2[x];
	ll ret=0;
	for(ll l,r,i=2;i<=x;i=r+1){
		l=i; r=x/(x/i);
		ret=(ret-(sum2(r)-sum2(l-1))*S2(x/i)%mod+mod)%mod;
	}
	return ret;
}

int main(){
	freopen("tower.in","r",stdin),freopen("tower.out","w",stdout);
	
	init();
	scanf("%lld%lld", &n, &m); n--; m--;
	for(ll l,r,i=1;i<=min(n,m);i=r+1){
		l=i; r=min(n/(n/i), m/(m/i))+1;
		(ans1+=(S(r)-S(l-1))*(n/i)%mod*(m/i)%mod)%=mod;
	}
	// for(ll i=1;i<=min(n,m);i++) (ans1+=mu[i]*(n/i)*(m/i)%mod)%=mod;
	// printf("ans1 = %lld\n", ans1);
	ans1=ans1*(n+1)%mod*(m+1)%mod;
	for(ll l,r,i=1;i<=min(n,m);i=r+1){
		l=i; r=min(n/(n/i), m/(m/i))+1;
		(ans2+=(S1(r)-S1(l-1))*C2(n/i)%mod*(m/i)%mod)%=mod;
	}
	// for(ll i=1;i<=min(n,m);i++) (ans2+=mu[i]*i*C2(n/i)%mod*(m/i)%mod)%=mod;
	// printf("ans2 = %lld\n", ans2); 
	ans2=ans2*(m+1)%mod;
	for(ll l,r,i=1;i<=min(n,m);i=r+1){
		l=i; r=min(n/(n/i), m/(m/i))+1;
		(ans3+=(S1(r)-S1(l-1))*C2(m/i)%mod*(n/i)%mod)%=mod;
	}
	// for(ll i=1;i<=min(n,m);i++) (ans3+=mu[i]*i*C2(m/i)%mod*(n/i)%mod)%=mod;
	//printf("ans3 = %lld\n", ans3);
	ans3=ans3*(n+1)%mod;
	for(ll l,r,i=1;i<=min(n,m);i=r+1){
		l=i; r=min(n/(n/i), m/(m/i))+1;
		(ans4+=(S2(r)-S2(l-1))* Sum(n/i, m/i)%mod)%=mod;
	}
	// for(ll i=1;i<=min(n,m);i++) (ans4+=mu[i]*i*i%mod* Sum(n/i, m/i)%mod )%=mod;
	// printf("ans4 = %lld\n", ans4);
	// for(int i=1;i<n;i++) for(int j=1;j<m;j++) if(gcd(i,j)==1) ans+=(n-i)*(m-j);
	printf("%lld\n", (ans1-ans2-ans3+ans4+mod+mod)%mod*4%mod);
	return 0;
}
