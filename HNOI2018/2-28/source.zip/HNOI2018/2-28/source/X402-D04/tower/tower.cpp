#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=10000010;
const int mod=998244353;
ll n, m;
ll ans;

int cnt, prime[maxn+10];
bool isprime[maxn+10];
short mu[maxn+10];
void init(){
	mu[1]=1;
	for(int i=2;i<maxn;i++){
		if(!isprime[i]){ prime[++cnt]=i, mu[i]=-1; }
		for(int j=1;j<=cnt && 1ll*i*prime[j]<maxn;j++){
			isprime[i*prime[j]]=1; mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){ mu[i*prime[j]]=0; break; }
		}
	}
	// for(int i=1;i<=10;i++) printf("%d ", mu[i]); puts("");
}

ll gcd(ll x,ll y){ return !y ? x : gcd(y,x%y); }

ll ans1,ans2,ans3,ans4;

ll Sum(ll x,ll y){ return (x*(x+1)/2)%mod * ( (y*(y+1)/2)%mod) %mod; }
ll C2(ll x){ return x*(x+1)/2%mod; }

int main(){
	freopen("tower.in","r",stdin),freopen("tower.out","w",stdout);
	
	init();
	scanf("%lld%lld", &n, &m); n--; m--;
	for(ll i=1;i<=min(n,m);i++) (ans1+=mu[i]*(n/i)*(m/i)%mod)%=mod;
	// printf("ans1 = %lld\n", ans1);
	ans1=ans1*(n+1)%mod*(m+1)%mod;
	for(ll i=1;i<=min(n,m);i++) (ans2+=mu[i]*i*C2(n/i)%mod*(m/i)%mod)%=mod;
	// printf("ans2 = %lld\n", ans2); 
	ans2=ans2*(m+1)%mod;
	for(ll i=1;i<=min(n,m);i++) (ans3+=mu[i]*i*C2(m/i)%mod*(n/i)%mod)%=mod;
	//printf("ans3 = %lld\n", ans3);
	ans3=ans3*(n+1)%mod;
	for(ll i=1;i<=min(n,m);i++) (ans4+=mu[i]*i*i%mod* Sum(n/i, m/i)%mod )%=mod;
	// printf("ans4 = %lld\n", ans4);
	// for(int i=1;i<n;i++) for(int j=1;j<m;j++) if(gcd(i,j)==1) ans+=(n-i)*(m-j);
	printf("%lld\n", (ans1-ans2-ans3+ans4+mod+mod)%mod*4%mod);
	return 0;
}
