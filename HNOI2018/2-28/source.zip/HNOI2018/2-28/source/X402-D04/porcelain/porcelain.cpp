#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
const int inf=1e9;
int n, m;
vector<int> g[maxn], w[maxn], id[maxn];

void chkmax(int& x,int y){ if(x<y) x=y; }

int tot;
int ans[maxn], dis[maxn], ban[maxn], vis[maxn];
void dfs(int x, int f){
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==f) continue;
		dis[v]=dis[x]+w[x][i];
		dfs(v,x);
	}
}

int root, cnt, bel[maxn];
void getid(){
	for(int i=1;i<=n;i++) vis[i]=0;
	queue<int> q;
	q.push(root); vis[root]=1; bel[root]=1;
	while(!q.empty()){
		int x=q.front(); q.pop();
		// printf("x = %d\n", x);
		for(int i=0;i<g[x].size();i++){
			int v=g[x][i]; if(vis[v]) continue;
			bel[v]=bel[x];
			if(ban[ id[x][i] ]) bel[v]=++tot;
			vis[v]=1; q.push(v);
		}
	}
}

int main(){
	freopen("porcelain.in","r",stdin),freopen("porcelain.out","w",stdout);
	//freopen("1.in","r",stdin),freopen("porcelain.out","w",stdout);

	scanf("%d%d", &n, &m);
	int u, v, z;
	for(int i=1;i<n;i++){
		scanf("%d%d%d", &u, &v, &z);
		g[u].push_back(v), w[u].push_back(z), id[u].push_back(i);
		g[v].push_back(u), w[v].push_back(z), id[v].push_back(i);
	}
	for(int i=1;i<=m;i++){
		for(int j=1;j<n;j++) ban[j]=0;
		scanf("%d%d", &root, &cnt);
		for(int j=1;j<=cnt;j++){
			scanf("%d", &u); ban[u]=1;
		}
		for(int j=1;j<=n;j++) ans[j]=-inf;
		tot=1;
		dis[root]=0;
		dfs(root, 0);
		getid();
		// for(int j=1;j<=n;j++) printf("%d ", bel[j]); puts("");
		// puts("dis");
		// for(int j=1;j<=n;j++) printf("%d ", dis[j]); puts("");
		for(int j=1;j<=n;j++) chkmax(ans[ bel[j] ], dis[j]);
		sort(ans+1,ans+1+cnt+1);
		for(int j=1;j<=cnt+1;j++) printf("%d ", ans[j]); puts("");
	}
	return 0;
}
