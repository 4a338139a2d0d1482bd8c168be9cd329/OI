#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
int ans,n,m;
int xx1,xx2,xx3,yy1,yy2,yy3;
inline int solve(){
    int tx1=xx2-xx1,ty1=yy2-yy1,tx2=xx3-xx1,ty2=yy3-yy1;
    return(abs(tx1*ty2-tx2*ty1));
}
int main(){
    freopen("tower.in","r",stdin);
    freopen("tower.out","w",stdout);
    read(n);read(m);
    for(xx1=1;xx1<=n;++xx1){
        for(yy1=1;yy1<=m;++yy1){
            for(xx2=1;xx2<=n;++xx2){
                for(yy2=1;yy2<=m;++yy2){
                    for(xx3=1;xx3<=n;++xx3){
                        for(yy3=1;yy3<=m;++yy3){
                            if(solve()==1)ans++;
                        }
                    }
                }
            }
        }
    }
    printf("%d\n",ans/6);
    return 0;
}
