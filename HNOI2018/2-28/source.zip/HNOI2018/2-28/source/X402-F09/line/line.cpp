#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int mod=1e9+7;
#define pb push_back
vector<int> vec;
map<vector<int>,int>ma;
int ans,n;
inline void dfs(vector<int> a){
    int len=a.size();
    for(register int i=0;i<len;++i){
        if(a[i]>i){
            for(register int j=i+1;j<len;++j){
                if(a[j]<a[i]){
                    vector<int> b;
                    b=a;
                    b[i]=a[j];b[j]=a[i];
                    if(!ma[b]){
                        ma[b]=1;
                        ans++;
                        if(ans>=mod)ans-=mod;
                        dfs(b);
                    }
                }
            }
        }
    }
}
int main(){
    freopen("line.in","r",stdin);
    freopen("line.out","w",stdout);
    read(n);
    for(register int i=1;i<=n;++i){
        int a;
        read(a);
        vec.pb(a);
    }
    ma[vec]=1;
    ans++;
    dfs(vec);
    printf("%d\n",ans);
    return 0;
}
