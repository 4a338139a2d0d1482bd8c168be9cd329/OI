#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
const int maxn=100010;
int f[maxn],val[maxn<<1],head[maxn],cnt,ans[maxn],n,m,tot=1;
struct edge{
    int to,next,w;
}e[maxn<<1];
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
inline int _max(int a,int b){
    return a>b?a:b;
}
inline void add(int u,int v,int w){
    e[++tot].to=v;
    e[tot].next=head[u];
    e[tot].w=w;
    head[u]=tot;
}
inline void dfs(int rt,int fa,int d,int pos){
	f[rt]=d;
	for(register int i=head[rt];i;i=e[i].next){
		if(e[i].to==fa){
            continue;
        }
		else{
			dfs(e[i].to,rt,d+e[i].w,pos);
			if(val[i]==pos)ans[++cnt]=f[e[i].to];
			else f[rt]=_max(f[rt],f[e[i].to]);
		}
    }
}
int main(){
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
	read(n);read(m);
	for(register int i=1;i<=n-1;++i){
		int u,v,w;
		read(u);
        read(v);
        read(w);
		add(u,v,w);
		add(v,u,w);
	}
	for(register int i=1;i<=m;++i){
		int r,k;
		read(r);read(k);
		for(register int j=1;j<=k;++j){
			int x;
			read(x);
			val[x*2]=i;
            val[x*2+1]=i;
		}
        cnt=0;
		dfs(r,0,0,i);
		ans[++cnt]=f[r];
		sort(ans+1,ans+cnt+1);
		for(register int j=1;j<=cnt;++j){
            printf("%d ",ans[j]);
        }
        printf("\n");
	}
	return 0;
}
