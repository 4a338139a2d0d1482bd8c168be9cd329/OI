#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmax(int &x,int y){return (y>x)?(x=y,1):0;}
const int maxn=1e5+10,inf=0x3f3f3f3f;
int Begin[maxn],Next[maxn<<1],to[maxn<<1],w[maxn<<1],e;
void add_edge(int x,int y,int z){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
	w[e]=z;
}
int dep[maxn],p[maxn],tmp,num[maxn],f[maxn],rt;
int dfs(int x,int ff){
	int Max=dep[x];
	for(int i=Begin[x];i;i=Next[i]){
		if(to[i]==ff) continue;
		dep[to[i]]=dep[x]+w[i];
		int u=dfs(to[i],x);
		if(p[(i+1)/2]) num[++tmp]=u;
		else chkmax(Max,u);
	}
	return Max;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
#endif
	int n=read(),m=read();
	REP(i,1,n-1){
		int x=read(),y=read(),z=read();
		add_edge(x,y,z),add_edge(y,x,z);
	}
	REP(i,1,m){
		REP(i,1,n-1) p[i]=0;
		rt=read();
		tmp=read();
		REP(i,1,tmp){
			int x=read();
			p[x]=1;
		}
		tmp=0;
		dep[rt]=0;
		int x=dfs(rt,0);
		num[++tmp]=x;
		sort(num+1,num+tmp+1);
		REP(i,1,tmp) printf("%d%c",num[i],i==iend?'\n':' ');
	}
	return 0;
}
