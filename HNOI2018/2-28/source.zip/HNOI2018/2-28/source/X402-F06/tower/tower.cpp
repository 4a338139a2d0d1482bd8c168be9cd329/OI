#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int mod=998244353;
const double eps=0.1;
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return res;
}
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
double hallen(double x,double y,double z){
	double p=(x+y+z)/2;
	return sqrt(p*(p-x)*(p-y)*(p-z));
}
inline int pf(int x){
	return x*x;
}
bool check(int a,int b,int c,int d,int e,int f){
	double x=sqrt(pf(a-c)+pf(b-d)),y=sqrt(pf(a-e)+pf(b-f)),z=sqrt(pf(c-e)+pf(d-f));
	if(fabs(hallen(x,y,z)-0.5)<=eps) return 1;
	return 0;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
#endif
	int n=read(),m=read();
	int ans=0;
	REP(a,1,n) REP(b,1,m) REP(c,1,n) REP(d,1,m)
		if((a!=c || b!=d) && __gcd(abs(a-c),abs(b-d))==1)
			REP(e,1,n) REP(f,1,m){
				if(a==e && b==f) continue;
				if(c==e && d==f) continue;
				int x=abs(e-a),y=abs(f-b);
				if(__gcd(x,y)!=1) continue;
				int u=abs(e-c),v=abs(f-d);
				if(__gcd(u,v)!=1) continue;
				if(x*v==u*y) continue;
				int i=abs(c-a),j=abs(b-d);
				if(x*j==i*y) continue;
				if(u*j==i*v) continue;
				if(check(a,b,c,d,e,f)) add(ans,1);
		}
	ans=1ll*ans*ksm(6,mod-2)%mod;
	printf("%d\n",ans);
	return 0;
}
