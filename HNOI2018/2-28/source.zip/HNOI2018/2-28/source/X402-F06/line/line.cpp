#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=20,mod=1e9+7;
int a[maxn+10],ans;
int fac[maxn],n;
bitset<3628810> p;
int contor(){
	int res=0;
	REP(i,1,n){
		int num=0;
		REP(j,i+1,n)
			if(a[i]>a[j])
				num++;
		res+=num*fac[n-i];
	}
	return res;
}
void dfs(){
	int x=contor();
	if(p[x]) return;
	ans++,p[x]=1;
	REP(i,1,n) REP(j,i+1,n) if(a[i]>a[j]){
		swap(a[i],a[j]);
		dfs();
		swap(a[i],a[j]);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
#endif
	n=read();
	REP(i,1,n) a[i]=read();
	if(n<=10){
		fac[0]=1;
		REP(i,1,n) fac[i]=fac[i-1]*i;
		dfs();
		printf("%d\n",ans);
	}
	return 0;
}
