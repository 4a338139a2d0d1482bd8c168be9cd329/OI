#include <bits/stdc++.h>

typedef double lf;

const lf eps = 1e-9;
const int N = 1e5 + 10;
const int mod = 998244353;

int n, m, cnt;

lf Halen(lf a, lf b, lf c)
{
	lf p = (a + b + c) / 2;
	return p * (p-a) * (p-b) * (p-c);
}

struct Point
{
	int x, y;

	lf dis(Point rhs)
	{
		return sqrt((x-rhs.x) * (x-rhs.x) + (y-rhs.y) * (y-rhs.y));
	}
}P[N + 5];

int main()
{
	freopen("tower.in", "r", stdin);
	freopen("tower.out", "w", stdout);

	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
			P[++cnt] = (Point) {i, j};

	int ans = 0;
	if(cnt <= 500){
		for(int i = 1; i <= cnt; ++i)
			for(int j = i; j <= cnt; ++j)
				for(int k = j; k <= cnt; ++k){
					if(fabs(Halen(P[i].dis(P[j]), P[j].dis(P[k]), P[i].dis(P[k])) - 0.25) <= eps){
						ans ++;
					}
				}
	}
	else
	{
		ans = 1ll * (m-1) * (n-1) % mod * (n+m-2) % mod;
		for(int i = 1; i <= cnt; ++i){
			for(int j = i; j <= cnt; ++j){
				if(P[i].x == P[j].x) continue;
				if(P[j].y == P[i].y) continue;
				for(int k = j; k <= cnt; ++k){
					if(fabs(Halen(P[i].dis(P[j]), P[j].dis(P[k]), P[i].dis(P[k])) - 0.25) <= eps){
						ans ++;
						if(ans >= mod) ans -= mod;
					}
				}
			}
		}
	}

	printf("%d\n", ans);
	return 0;
}
