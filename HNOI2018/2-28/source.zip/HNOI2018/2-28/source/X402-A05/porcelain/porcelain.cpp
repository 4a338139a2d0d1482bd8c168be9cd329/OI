#include <bits/stdc++.h>

#define SZ(x) ((int)((x).size()))

bool chkmax(int &a, int b) { return a < b? a = b, 1 : 0; }
int read(int x = 0, int f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar()) f |= c == '-';
	for(;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 100000;
const int inf = 0x3f3f3f3f;

int n, m;

int e = 1, Begin[N + 5];
struct Edge
{
	int to, next, w;
	Edge(int to = 0, int next = 0, int w = 0) : to(to), next(next), w(w) {}
}E[(N + 5) << 1];

void add_edge(int u, int v, int w)
{
	E[++e] = Edge(v, Begin[u], w); Begin[u] = e;
	E[++e] = Edge(u, Begin[v], w); Begin[v] = e;
}

namespace bfer
{
	const int M = 3000;

	bool ban[M + 5][(M + 5) << 1];
	int root[M + 5];

	bool vis[N + 5];
	std::vector<int> con[N + 5];

	void DFS_init(int ith, int u, int o)
	{
		con[o].push_back(u);
		vis[u] = true;

		for(int i = Begin[u]; i; i = E[i].next){
			int v = E[i].to;
			if(ban[ith][i] || vis[v]) continue;
			DFS_init(ith, v, o);
		}
	}

	int dist[N + 5];

	void DFS_calc(int u, int fa)
	{
		for(int i = Begin[u]; i; i = E[i].next){
			int v = E[i].to;
			if(v == fa) continue;

			dist[v] = dist[u] + E[i].w;
			DFS_calc(v, u);
		}
	}

	void main()
	{
		for(int i = 1; i <= m; ++i){
			root[i] = read();
			int len = read();
			for(int j = 1; j <= len; ++j){
				int id = read();
				ban[i][id<<1] = true;
				ban[i][id<<1|1] = true;
			}
		}
		
		for(int i = 1; i <= m; ++i){
			int cnt = 0;
			for(int j = 1; j <= n; ++j)
				if(!vis[j]){
					DFS_init(i, j, cnt);
					cnt ++;
				}

			dist[root[i]] = 0;
			DFS_calc(root[i], 0);

			std::vector<int> ans;
			ans.resize(cnt);
			for(int j = 0; j < cnt; ++j){
				ans[j] = -inf;
				for(int k = 0; k < SZ(con[j]); ++k){
					chkmax(ans[j], dist[con[j][k]]);
				}
			}

			std::sort(ans.begin(), ans.end());
			for(int j = 0; j < SZ(ans); ++j){
				printf("%d ", ans[j]);
			}
			printf("\n");

			for(int j = 1; j <= n; ++j) vis[j] = false;
			for(int j = 0; j < cnt; ++j){
				con[j].clear();
			}
		}
	}
}

namespace AllSame
{
/*	bool ban[(N + 5) << 1];
	int root[N + 5];

	bool vis[N + 5];
	std::vector<int> con[N + 5];
	int ans[N + 5];

	std::vector<int> G[N + 5];
	std::vector<int> nxt[N + 5];
	std::vector<int> bound[N + 5];

	void AddEdge(int u, int v)
	{
		bound[bel[v]].push_back(v);
		nxt[bel[v]].push_back(u);
		G[bel[v]].push_back(bel[u]);
	}

	void DFS_init(int u, int o)
	{
		con[o].push_back(u);
		vis[u] = true;

		for(int i = Begin[u]; i; i = E[i].next){
			int v = E[i].to;
			if(ban[i] || vis[v]) continue;
			DFS_init(v, o);
		}
	}

	int DFS_pre(int ith, int u, int fa)
	{
		int ret = -inf;
		for(int i = Begin[u]; i; i = E[i].next){
			int v = E[i].to;
			if(v == fa || bel[v] != ith) continue;
			chkmax(ret, DFS_pre(ith, v, u) + E[i].w);
		}
		return ret == -inf? 0 : ret;
	}*/

	void main()
	{
	/*	for(int i = 1; i <= m; ++i){
			root[i] = read();
			int len = read();
			for(int j = 1; j <= len; ++j){
				int id = read();
				ban[id<<1] = true;
				ban[id<<1|1] = true;
			}
		}

		int cnt = 0;
		for(int i = 1; i <= n; ++i){
			if(!vis[i]) DFS_init(i, ++ cnt);
		}

		for(int u = 1; u <= n; ++u){
			for(int i = Begin[u]; i; i = E[i].next){
				int v = E[i].to;
				if(bel[v] != bel[u]){
					AddEdge(bel[v], bel[u]);
					AddEdge(bel[u], bel[v]);
				}
			}
		}

		for(int i = 1; i <= cnt; ++i){
			for(int j = 0; j < SZ(bound[i]); ++j){
				Mx[i].push_back(DFS_pre(i, bound[i][j], 0));
			}
		}*/
		puts("啊掉磨博士");
	}
}

int main()
{
	freopen("porcelain.in", "r", stdin);
	freopen("porcelain.out", "w", stdout);

	n = read(), m = read();
	for(int i = 1; i < n; ++i){
		int u, v, w;
		u = read(), v = read(), w = read();
		add_edge(u, v, w);
	}

	if(n <= 30000 && m <= 30000){
		bfer :: main();
	}
	else
		AllSame :: main();

	return 0;
}
