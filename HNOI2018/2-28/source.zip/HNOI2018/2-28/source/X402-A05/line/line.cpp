#include <bits/stdc++.h>

typedef long long ll;

const int N = 20;

int p[N + 5], n;
std::map<ll, bool> id;

ll get_id(int *p, int n)
{
	ll base = 1, res = 1;
	for(int i = 1; i <= n; ++i){
		res = res + p[i] * base;
		if(i != n) base *= n;
	}
	return res;
}

void DFS_calc()
{
	bool &o = id[get_id(p, n)];
	if(o) return ;

//	for(int i = 1; i <= n; ++i){
//		printf("%d%c", p[i], i != n? ' ':'\n');
//	}
	o = true;
	for(int i = 1; i <= n; ++i){
		for(int j = 1; j < i; ++j){
			if(p[j] > p[i]){
				std::swap(p[j], p[i]);
				DFS_calc();
				std::swap(p[j], p[i]);
			}
		}
	}
}

int main()
{
	freopen("line.in", "r", stdin);
	freopen("line.out", "w", stdout);

	scanf("%d", &n);
	for(int i = 1; i <= n; ++i)
		scanf("%d", &p[i]);
	DFS_calc();
	printf("%d\n", (int)id.size());
//	std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;

	return 0;
}
