#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

int n,m,ans;

inline void file() {
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
}

int gcd(int a,int b) { return b==0?a:gcd(b,a%b); }

dd dis(int x1,int y1,int x2,int y2) {
	return sqrt((dd)((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)));
}

int main() {
	file();
	scanf("%d%d",&n,&m);
	For (x1,1,n) For (y1,1,m)
		For (x2,1,n) For (y2,1,m) {
			if (gcd(abs(x1-x2),abs(y1-y2))!=1) continue;
				For (x3,1,n) For (y3,1,m) {
				if (gcd(abs(x1-x3),abs(y1-y3))!=1) continue;
				if (gcd(abs(x2-x3),abs(y2-y3))!=1) continue;
				dd d1=dis(x1,y1,x2,y2);
				dd d2=dis(x1,y1,x3,y3);
				dd d3=dis(x2,y2,x3,y3);
				dd p=(d1+d2+d3)/2;
				dd S=sqrt(p*(p-d1)*(p-d2)*(p-d3));
				if (fabs(S-0.5)<=0.0000001) ans++;
			}
		}
	printf("%d\n",ans/6);
	return 0;
}
