#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const ll modd=998244353;
ll n,m,ans;

inline void file() {
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
}

int main() {
	file();
	scanf("%lld%lld",&n,&m);
	n--; m--;
	ans=(ans+n*m%modd)%modd;
	For (i,2,max(n,m)) {
		if (i<=n) ans=(ans+m*(n-i+1)%modd)%modd;
		if (i<=m) ans=(ans+n*(m-i+1)%modd)%modd;
	}
	printf("%lld\n",ans*4%modd);
	return 0;
}
