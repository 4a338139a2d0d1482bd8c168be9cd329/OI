#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=3000+10;
const int inf=0x3f3f3f3f;
struct node {
	int to,dis,next;
}e[maxn<<1];
int n,m,tot=1,cnt;
int head[maxn],a[maxn][maxn];
int ok[maxn<<1],vis[maxn];
int anss[maxn];

inline void file() {
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void add(int from,int to,int dis) {
	tot++;
	e[tot].to=to; e[tot].dis=dis; e[tot].next=head[from]; head[from]=tot;
}

void dfs1(int top,int u,int fa) {
	for (int i=head[u];i!=0;i=e[i].next) {
		int v=e[i].to;
		if (v==fa) continue;
		a[top][v]=a[top][u]+e[i].dis;
		dfs1(top,v,u);
	}
}

void dfs2(int u) {
	vis[u]=cnt;
	for (int i=head[u];i!=0;i=e[i].next) {
		if (ok[i/2]) continue;
		int v=e[i].to;
		if (vis[v]) continue;
		dfs2(v);
	}
}

int main() {
	file();
	read(n); read(m);
	For (i,1,n-1) {
		int x,y,z; read(x); read(y); read(z);
		add(x,y,z); add(y,x,z);
	}
	For (i,1,n) dfs1(i,i,0);
	while (m--) {
		Set(ok,0); Set(vis,0); Set(anss,-inf); cnt=0;
		int r,k;
		read(r); read(k);
		For (i,1,k) {
			int x; read(x); ok[x]=1;
		}
		For (i,1,n)
			if (!vis[i]) {
				++cnt;
				dfs2(i);
			}
		For (i,1,n) chkmax(anss[vis[i]],a[r][i]);
		sort(anss+1,anss+cnt+1);
		For (i,1,cnt) printf("%d ",anss[i]); cout << endl;
	}
	return 0;
}
