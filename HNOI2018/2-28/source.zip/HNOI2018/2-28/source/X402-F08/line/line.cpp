#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=50;
const ll maxm=10000000;
int n,ans=1;
int a[maxn];
ll x=97,h[maxm+100];

inline void file() {
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline bool Hash() {
	ll ss=0;
	For (i,1,n) ss=(ss*x+a[i])%maxm;
	if (h[ss]) return 1;
	h[ss]=1;
	return 0;
}

void dfs() {
	For (i,1,n) For (j,i+1,n)
		if (a[i]>a[j]) {
			swap(a[i],a[j]);
			if (Hash()) {
				swap(a[i],a[j]);
				continue;
			}
			++ans;
			dfs();
			swap(a[i],a[j]);
		}
}

int main() {
	file();
	read(n);
	For (i,1,n) read(a[i]);
	Hash();
	dfs();
	printf("%d\n",ans);
	return 0;
}
