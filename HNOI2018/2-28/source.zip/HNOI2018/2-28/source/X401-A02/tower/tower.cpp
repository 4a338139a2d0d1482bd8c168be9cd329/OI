#include<bits/stdc++.h>
#define For(i,a,b) for(register int i=a;i<=b;++i)


using namespace std;
const int maxn=10+2;
inline double juli(int x1,int y1,int x2,int y2){
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
int main(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	int n,m,ans=0;
	scanf("%d%d",&n,&m);
	For(x1,1,n)For(y1,1,m)
	For(x2,1,n)For(y2,1,m)
	For(x3,1,n)For(y3,1,m){
		double a=juli(x1,y1,x2,y2),b=juli(x1,y1,x3,y3),c=juli(x2,y2,x3,y3);
		double p=(a+b+c)/2;
		double s=sqrt(p*(p-a)*(p-b)*(p-c));
		float qaq=s;
		if(qaq==0.5)
			++ans;
	//	cout<<s<<endl;
	}
	printf("%d",ans/6);
	return 0;
}
