#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
map<unsigned long long,bool> mp;
inline void Swap(int &x,int &y){
	int tmp=x;x=y;y=tmp;
}

void file(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
}

const int maxn=20+5,mod=1e9+7;
int a[maxn],n;
ll ans;

inline unsigned long long hash(){
	unsigned long long res=0;
	for(int i=1;i<=n;++i){
		res+=a[i]*a[i];
		res=res*res*res;
		res*=a[i];
	}
	return res;
}


inline void dfs(){
	int flag=0;
	unsigned long long ovo=hash();
	if(mp[ovo])
		return;
	++ans,mp[ovo]=1;
	for(int i=1;i<=n;++i)
		if(a[i]!=i)
			flag=1;
	if(!flag)
		return;
	for(int i=1;i<=n;++i)
		for(int j=1;j<i;++j)
			if(a[i]<a[j]){
				Swap(a[i],a[j]);
				dfs();
				Swap(a[i],a[j]);
			}
}
int main(){
	file();
	double times=clock();
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	dfs();
	printf("%lld\n",ans%mod);
	return 0;
}

