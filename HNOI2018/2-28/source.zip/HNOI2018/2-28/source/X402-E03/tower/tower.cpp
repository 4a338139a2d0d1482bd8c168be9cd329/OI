#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 55, Mod = 998244353 ;
int n, m ;
struct node {
	int x, y ;
} ;
int calc ( node A, node B, node C ) {
	C.x -= A.x, B.x -= A.x ;
	C.y -= A.y, B.y -= A.y ;
	return abs(C.x*B.y - C.y*B.x) ;
}
bool p0 ( node A, node B ) {
	if (A.x==B.x&&abs(A.y-B.y)==1)return 1;
	return 0;
}
bool p1 ( node A, node B ) {
	if (A.y==B.y&&abs(A.x-B.x)==1)return 1;
	return 0;
}
int main() {
	freopen ( "tower.in", "r", stdin ) ;
	freopen ( "tower.out", "w", stdout ) ;
	while (cin>>n>>m) {
		int S = n*m, a, b, c, ans = 0 ;
		node A, B, C ;
		//int t0 = 0, t1 = 0 ; bool fg ;
		for ( a = 0 ; a ^ S ; a ++ ) {
			A.x = a%m, A.y = a/m ;
			for ( b = a+1 ; b ^ S ; b ++ ) {
				B.x = b%m, B.y = b/m ;
				for ( c = b+1 ; c ^ S ; c ++ ) {
					C.x = c%m, C.y = c/m ;
					if (calc(A, B, C) == 1) {
						++ ans ;
						/*fg=0;
						if (p0(A,B)||p0(A,C)||p0(B,C))++t0,fg=1;
						if (p1(A,B)||p1(A,C)||p1(B,C))++t1,fg=1;
						if (!fg)printf ( "(%d,%d) (%d,%d)\n", B.x-A.x, B.y-A.y, C.x-A.x, C.y-A.y ) ;*/
					}
				}
			}
				//puts("") ;
		}
		//printf ( "t0=%d t1=%d\n", t0, t1 ) ;
		//printf ( "c0=%d c1=%d\n", Calc(m,n), Calc(n,m)) ;
		cout << ans << endl ;
	}
	//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
