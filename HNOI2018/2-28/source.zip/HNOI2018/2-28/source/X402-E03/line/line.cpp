#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 12 ;
int n ;
struct node {
	int a[maxn] ;
	friend bool operator < ( node A, node B ) {
		for ( int i = 1 ; i <= n ; i ++ )
			if (A.a[i] ^ B.a[i]) return A.a[i] < B.a[i] ;
		return 0 ;
	}
} st, tmp ;
int cnt ;
map <node, int> g ;
void dfs ( node A ) {
	if (g[A]) return ;
	//A.print() ;
	g[A] = ++cnt ;
	int i, j ;
	for ( i = 0 ; i ^ n ; i ++ )
		for ( j = i+1 ; j ^ n ; j ++ )
			if (A.a[i] > A.a[j]) {
				swap(A.a[i], A.a[j]) ;
				dfs(A) ;
				swap(A.a[i], A.a[j]) ;
			}
}
int main() {
	freopen ( "line.in", "r", stdin ) ;
	freopen ( "line.out", "w", stdout ) ;
	Read(n) ;
	for ( register int i = 0 ; i ^ n ; i ++ )
		Read(st.a[i]) ;
	dfs(st) ;
	cout << cnt << endl ;
	return 0 ;
}
