#include <bits/stdc++.h>
using namespace std ;
void chkmax ( int &a, int b ) { a = a>b? a:b ; }
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 3005, inf = 0x3f3f3f3f ;
int n, m, e = 1, Begin[maxn], Next[maxn*2], To[maxn*2], W[maxn*2] ;
void add ( int x, int y, int z ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
	W[e] = z ;
}
bool vis[maxn] ;
int s[maxn], rt, val[maxn], fa[maxn] ;
struct Edge {
	int u, v ;
} E[maxn] ;
void init() {
	for ( int i = 1 ; i <= n ; i ++ ) {
		fa[i] = i ;
		vis[i] = 0 ;
		val[i] = -inf ;
	}
}
void dfs ( int x ) {
	vis[x] = 1 ;
	int i, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (!vis[u]) {
			val[u] = val[x]+W[i] ;
			dfs(u) ;
		}
	}
}
int find ( int x ) { return fa[x] = fa[x]==x? x:find(fa[x]) ; }
void Force() {
	int i, x, u, v ;
	init() ;
	Read(rt), Read(m) ;
	vis[rt] = 1, val[rt] = 0, dfs(rt) ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(x) ;
		vis[x] = 0 ;
	}
	for ( i = 1 ; i ^ n ; i ++ )
		if (vis[i]) {
			u = E[i].u, v = E[i].v ;
			if (find(u) ^ find(v)) {
				chkmax(val[find(u)], val[find(v)]) ;
				fa[find(v)] = find(u) ;
			}
		}
	for ( m = 0, i = 1 ; i <= n ; i ++ )
		if (fa[i] == i) s[++m] = val[i] ;
	sort(s+1, s+m+1) ;
	for ( i = 1 ; i <= m ; i ++ ) printf ( "%d ", s[i] ) ;
	puts("") ;
}
int main() {
	freopen ( "porcelain.in", "r", stdin ) ;
	freopen ( "porcelain.out", "w", stdout ) ;
	int i, x, u, v, _ ;
	Read(n), Read(_) ;
	for ( i = 1 ; i ^ n ; i ++ ) {
		Read(x), Read(u), Read(v) ;
		add(x, u, v) ;
		add(u, x, v) ;
		E[i] = (Edge){x, u} ;
	}
	while (_--) Force() ;
	return 0 ;
}
