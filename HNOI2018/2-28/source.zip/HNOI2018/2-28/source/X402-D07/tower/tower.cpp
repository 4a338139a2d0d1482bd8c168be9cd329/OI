#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

int n,m,ans;

int cross(int x_1,int y_1,int x_2,int y_2){
    return x_1*y_2-x_2*y_1;
}

bool check(int ax,int ay,int bx,int by,int cx,int cy){
    return abs(cross(bx-ax,by-ay,cx-ax,cy-ay))==1;
}

int main(){
    freopen("tower.in","r",stdin);
    freopen("tower.out","w",stdout);

    read(n); read(m);
    
    for(int ax=1;ax<=n;ax++)
        for(int ay=1;ay<=m;ay++)
            for(int bx=ax;bx<=n;bx++)
                for(int by=(bx==ax)?ay+1:1;by<=m;by++)
                    for(int cx=bx;cx<=n;cx++)
                        for(int cy=cx==bx?by+1:1;cy<=m;cy++)
                            if(check(ax,ay,bx,by,cx,cy)) ++ans;

    printf("%d\n",ans);

    return 0;
}
