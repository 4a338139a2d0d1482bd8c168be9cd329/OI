#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(),(x).end()

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=3010;

int n,m;

int head[maxn],nxt[maxn<<1],to[maxn<<1],w[maxn<<1],e=1;
bool ban[maxn];

void ae(int x,int y,int c){
    to[++e]=y; nxt[e]=head[x]; head[x]=e; w[e]=c;
}

int dis[maxn];

void dfs(int u,int fa){
    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(v!=fa) dis[v]=dis[u]+w[i],dfs(v,u);
    }
}

vector<int> t;

bool vis[maxn];

int calc(int u){
    int res=dis[u]; vis[u]=1;
    for(int i=head[u];i;i=nxt[i]) if(!ban[i>>1]){
        int v=to[i];
        if(!vis[v]) chkmax(res,calc(v));
    }
    return res;
}

int main(){
    freopen("porcelain.in","r",stdin);
    freopen("porcelain.out","w",stdout);

    read(n); read(m);

    for(int i=1;i<n;i++){
        int u,v,c;
        read(u); read(v); read(c);
        ae(u,v,c); ae(v,u,c);
    }

    while(m--){
        int u,k; t.clear();
        memset(ban,0,sizeof ban);
        memset(vis,0,sizeof vis);
        memset(dis,0,sizeof dis);

        read(u); dfs(u,0);
        read(k); for(int i=1;i<=k;i++) ban[read(u)]=1;

        for(int i=1;i<=n;i++) if(!vis[i]) t.pb(calc(i));
        sort(ALL(t));

        for(int i=0;i<SZ(t);i++) printf("%d ",t[i]);
        puts("");
    }

    return 0;
}
