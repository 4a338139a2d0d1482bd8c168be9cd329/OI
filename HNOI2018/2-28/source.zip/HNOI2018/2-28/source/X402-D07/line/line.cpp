#include<bits/stdc++.h>

using namespace std;

#define pb push_back

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

int n,ans;

map<vector<int>,bool> p;

void dfs(vector<int> t){
    if(!p.count(t)) ++ans,p[t]=1;
    else return;
    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++) if(t[i]>t[j]){
            swap(t[i],t[j]);
            dfs(t);
            swap(t[i],t[j]);
        }
}

int main(){
    freopen("line.in","r",stdin);
    freopen("line.out","w",stdout);

    vector<int> t;
    read(n); int x;
    for(int i=1;i<=n;i++) t.pb(read(x));
    dfs(t);
    printf("%d\n",ans);

    return 0;
}
