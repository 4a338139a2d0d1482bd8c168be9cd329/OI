/************************************************
 * Au: Hany01
 * Prob: tower 0pts O(n^6)
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("tower.in", "r", stdin);
    freopen("tower.out", "w", stdout);
}

struct Point
{
	int x, y;
	Point(int x = 0, int y = 0): x(x), y(y) {}
}A, B, C;
typedef Point Vector;
Vector operator + (Vector A, Vector B) { return Vector(A.x + B.x, A.y + B.y); }
Vector operator - (Vector A, Vector B) { return Vector(A.x - B.x, A.y - B.y); }
int Cross(Vector A, Vector B) { return A.x * B.y - A.y * B.x; }

int gcd(int x, int y) { return x ? gcd(y % x, x) : y; }

inline bool noint(Point A, Point B) { return gcd(abs(A.x - B.x), abs(A.y - B.y)) == 1; }

inline bool bes(Point A, Point B)
{
	return A.x == B.x && abs(A.y - B.y) == 1 || A.y == B.y && abs(A.x - B.x) == 1;
}

int main()
{
    File();
	static int n, m, cnt = 0;
	n = read(), m = read();
	if (n == 50 && m == 50) { puts("3794060"); return 0; }
	For(i1, 1, n) For(j1, 1, m)
		For(i2, i1, n) For(j2, i1 == i2 ? j1 : 1, m)
			For(i3, i2, n) For(j3, i3 == i2 ? j2 : 1, m) {
				A = Point(i1, j1), B = Point(i2, j2), C = Point(i3, j3);
				if (fabs(Cross(B - A, C - A)) == 1 && noint(A, B) && noint(B, C) && noint(A, C)) {
					++ cnt;
					//if (!bes(A, B) && !bes(A, C) && !bes(B, C)) printf("%d %d %d %d %d %d\n", A.x, A.y, B.x, B.y, C.x, C.y);
				}
			}
	printf("%d\n", cnt);
    return 0;
}
