/************************************************
 * Au: Hany01
 * Prob: porcelain
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("porcelain.in", "r", stdin);
    freopen("porcelain.out", "w", stdout);
}

const int maxn = 3005;

int now, n, m, e, v[maxn << 1], nex[maxn << 1], beg[maxn], w[maxn << 1], dep[maxn], Ans[maxn], cnt, isbrk[maxn];

inline void add(int uu, int vv, int ww) { v[++ e] = vv, w[e] = ww, nex[e] = beg[uu], beg[uu] = e; }

void dfs(int u, int fa)
{
	register int tmp = INF;
	for (register int i = beg[u]; i; i = nex[i]) if (v[i] != fa) {
		dep[v[i]] = w[i] + dep[u];
		if (isbrk[i >> 1]) tmp = now, now = ++ cnt, Ans[now] = -INF;
		dfs(v[i], u);
		chkmax(Ans[now], dep[v[i]]);
		if (isbrk[i >> 1]) now = tmp;
	}
}

int main()
{
    File();

	int uu, vv, ww, tmp, rt;
	n = read(), m = read(), e = 1;
	For(i, 2, n) uu = read(), vv = read(), ww = read(), add(uu, vv, ww), add(vv, uu, ww);

	while (m --) {
		rt = read(), tmp = read(), Set(isbrk, 0);
		For(i, 1, tmp) isbrk[read()] = 1;
		now = cnt = 1, Ans[1] = 0, dep[rt] = 0, dfs(rt, 0);
		sort(Ans + 1, Ans + 1 + cnt);
		For(i, 1, cnt) printf("%d ", Ans[i]);
		putchar('\n');
	}

    return 0;
}
