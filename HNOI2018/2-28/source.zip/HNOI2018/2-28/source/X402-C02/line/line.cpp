#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int Mod=1e9+7,MAXN=20+5;
int n,A[MAXN],vis[1<<MAXN],f[1<<MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline void init()
{
	for(register int i=0;i<(1<<n);++i)
	{
		vis[i]=true;
		int now=__builtin_popcount(i),pre=0,nxt=0;
		for(register int j=0;j<n;++j)
		{
			pre+=(A[j]<=now?1:0);nxt+=(i>>j&1);
			if(nxt<pre)
			{
				vis[i]=false;
				break;
			}
		}
	}
}
int main()
{
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	read(n);
	for(register int i=1;i<=n;++i)read(A[i]);
	init();
	f[0]=1;
	for(register int i=1;i<(1<<n);++i)
	{
		if(!vis[i])continue;
		for(register int j=0;j<n;++j)
			if(i>>j&1)(f[i]+=f[i^(1<<j)])%=Mod;
	}
	write(f[(1<<n)-1],'\n');
	return 0;
}
