#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=100+10,Mod=998244353;
ll ans;
int n,m,cnt;
pair<int,int> can[MAXN*MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline ll cross(pair<int,int> i,pair<int,int> j)
{
	return i.first*j.second-i.second*j.first;
}
inline bool check(pair<int,int> i,pair<int,int> j,pair<int,int> k)
{
	j.first-=i.first;j.second-=i.second;
	k.first-=i.first;k.second-=i.second;
	if(cross(j,k)==1||cross(j,k)==-1)return true;
	else return false;
}
int main()
{
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	read(n);read(m);
	for(register int i=1;i<=n;++i)
		for(register int j=1;j<=m;++j)can[++cnt]=make_pair(i,j);
	for(register int i=1;i<=cnt;++i)
		for(register int j=i+1;j<=cnt;++j)
			for(register int k=j+1;k<=cnt;++k)
				if(check(can[i],can[j],can[k]))ans=(ans+1)%Mod;
	write(ans,'\n');
	return 0;
}
