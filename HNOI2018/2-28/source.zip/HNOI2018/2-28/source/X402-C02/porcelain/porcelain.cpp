#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=100000+10;
int f[MAXN],pot[MAXN<<1],to[MAXN<<1],e=1,nex[MAXN<<1],beg[MAXN],w[MAXN<<1],cnt,ans[MAXN],n,m;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline void insert(int x,int y,int z)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}
inline void dfs(int x,int fa,int d,int id)
{
	f[x]=d;
	for(register int i=beg[x];i;i=nex[i])
		if(to[i]==fa)continue;
		else
		{
			dfs(to[i],x,d+w[i],id);
			if(pot[i]==id)ans[++cnt]=f[to[i]];
			else chkmax(f[x],f[to[i]]);
		}
}
int main()
{
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
	read(n);read(m);
	for(register int i=1;i<n;++i)
	{
		int u,v,k;
		read(u);read(v);read(k);
		insert(u,v,k);
		insert(v,u,k);
	}
	for(register int i=1;i<=m;++i)
	{
		int r,k;
		read(r);read(k);
		for(register int j=1;j<=k;++j)
		{
			int x;
			read(x);
			pot[x<<1]=pot[(x<<1)^1]=i;
		}
		cnt=0;
		dfs(r,0,0,i);
		ans[++cnt]=f[r];
		sort(ans+1,ans+cnt+1);
		for(register int j=1;j<=cnt;++j)write(ans[j],' ');
		putchar('\n');
	}
	return 0;
}
