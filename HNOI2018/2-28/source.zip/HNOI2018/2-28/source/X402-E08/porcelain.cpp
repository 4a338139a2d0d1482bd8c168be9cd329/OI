#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("porcelain.in", "r", stdin);
	freopen ("porcelain.out", "w", stdout);
}

const int N = 3010, M = N << 1;
int n, m;
int to[M], Next[M], Head[N], val[M], ban[M], e = 1;

void add_edge(int u, int v, int w) { to[++e] = v; Next[e] = Head[u]; Head[u] = e; val[e] = w;}
void Add(int u, int v, int w) { add_edge(u, v, w); add_edge(v, u, w); }

int r, k, lis[N], dis[N];
int ans[N], col[N];

int flag;

void Dfs(int u, int fa) {
	if (flag) {col[u] = flag; chkmax(ans[flag], dis[u]); }
	for (register int i = Head[u]; i; i = Next[i]) {
		register int v = to[i];
		if (v == fa || ban[i]) continue ;
		if (!flag) dis[v] = dis[u] + val[i]; 
		Dfs(v, u);
	}
}

inline void Solve() {
	flag = 0; dis[r] = 0;Dfs(r, 0);

	For (i, 1, k) ban[lis[i] << 1] = ban[lis[i] << 1 | 1] = true;
	Set(col, 0);
	For (i, 1, n) if (!col[i]) { ++flag; ans[flag] = -0x3f3f3f3f; Dfs(i, 0); }

	sort(ans + 1, ans + 1 + flag);
	For (i, 1, flag) printf ("%d ", ans[i]);
	printf ("\n");

	For (i, 1, k) ban[lis[i] << 1] = ban[lis[i] << 1 | 1] = false;
}

int main () {
	File();
	n = read(); m = read();
	if (n > 3000) return 0;
	For (i, 1, n - 1) { int u = read(), v = read(), w = read(); Add(u, v, w); }
	For (i, 1, m) {
		r = read(); k = read();
		For (j, 1, k) lis[j] = read();
		Solve();
	}
    return 0;
}
