#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("tower.in", "r", stdin);
	freopen ("tower.out", "w", stdout);
}

int n, m;

#define Point(a) For(a##x, 1, n) For(a##y, 1, m)
#define Pow2(a) ((a) * (a))
#define Dis(a, b) (sqrt(Pow2(a##x - b##x) + Pow2(a##y - b##y)))
#define Same(a, b) ((a##x == b##x) && (a##y == b##y))

inline double Area(double a, double b, double c) {
	double p = (a + b + c) / 2;
	return sqrt(p * (p - a) * (p - b) * (p - c));
}

const double eps = 1e-6;

long long ans;

int main () {
	File();
	n = read(); m = read();
	//cout << ans << endl;
	int res = 0;
	Point(a) Point(b) if (!Same(a, b)) Point(c) if (!Same(b, c) && !Same(a, c))
		if (fabs(Area(Dis(a, b), Dis(b, c), Dis(a, c)) - 0.5) <= eps) ++ res;
	printf ("%d\n", res / 6);
    return 0;
}
