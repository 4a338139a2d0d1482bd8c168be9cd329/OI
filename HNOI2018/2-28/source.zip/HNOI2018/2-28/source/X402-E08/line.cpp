#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("line.in", "r", stdin);
	freopen ("line.out", "w", stdout);
}

set<string> S;

int ans = 0, n, len;
void Dfs(string now) {
	if (!S.count(now)) { S.insert(now); ++ans; } else return ;
	//For (i, 0, n - 1) cout << (int)now[i] << ' '; cout << endl;
	For (i, 0, n - 2)
		For (j, i + 1, n - 1)
			if (now[i] > now[j]) { swap(now[i], now[j]); Dfs(now); swap(now[i], now[j]); }
}

const int NN = (1 << 20) - 1, N = 21;

typedef long long ll;
const int Mod = 1e9 + 7;

inline void Add(int &a, int b) { if ((a += b) >= Mod) a -= Mod; }

int dp[N][NN];

int a[N], nn;
int can[N][N];

int bit_count[NN];

string str;
int main () {
	File();
	n = read(); nn = (1 << n) - 1;
	For (i, 0, nn) bit_count[i] = bit_count[i >> 1] + (i & 1);
	For (i, 1, n) a[i] = read() - 1;
	For (i, 1, n) {
		For (j, 1, i) {
			if (a[j] >= a[i]) can[i][a[j]] = true;
			For (k, i, n) {
				if (a[i] >= a[k]) can[i][a[k]] = true;
				if (a[j] >= a[k] && a[k] >= a[i]) can[i][a[k]] = true;
				if (a[j] >= a[k] && a[i] >= a[j]) can[i][a[j]] = true;
			}
		}
	//	cout << "i: " << i << endl; For (j, 0, n - 1) if (can[i][j]) cout << j + 1 << ' '; cout << endl;
	}


	str.resize(100);
	For (i, 0, n - 1) str[i] = a[i + 1] + 1;
	if (n <= 6) { Dfs(str); printf ("%d\n", ans); return 0; }

	dp[0][0] = 1;
	For (i, 1, n) {
		For (j, 0, nn)
			if (bit_count[j] == i) {
				For (k, 0, n - 1)
					if (can[i][k] && ((1 << k) & j))
						Add(dp[i][j], dp[i - 1][j ^ (1 << k)]);
			}
	}
	printf ("%d\n", dp[n][nn]);


    return 0;
}
