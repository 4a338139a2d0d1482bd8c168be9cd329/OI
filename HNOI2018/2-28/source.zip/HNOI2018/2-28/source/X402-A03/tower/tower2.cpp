/**********************************************************
	File:tower.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-28 08:52:06
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 998244353
int n,m,ans;
int main()
{
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	n=read();
	m=read();
	fr(i1,1,n)
		fr(j1,1,m)
			fr(i2,i1,n)
				fr(j2,i1==i2?j1:1,m)
					fr(i3,i2,n)
						fr(j3,i2==i3?j2:1,m)
						{
						//	printf("%d\n",abs((i2-i1)*(j3-j1)-(j2-j1)*(i3-i1)));
							if(abs((i2-i1)*(j3-j1)-(j2-j1)*(i3-i1))==1)
							{
						//		printf("%d %d %d %d %d %d\n",i1,i2,j1,j2,i3,j3);
								ans++;
								if(ans>mod)ans-=mod;
							}
						}
	printf("%d\n",ans);
}
//3794060
