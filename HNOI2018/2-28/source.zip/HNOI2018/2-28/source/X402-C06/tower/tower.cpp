#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
}

typedef long long ll;
const ll mod=998244353;
const int maxn=1e7+10;
ll n,m,ans;
int xie[maxn<<1];


int main(){
	file();
	read(n),read(m);
	ans=(n<<1)+(m<<1)-4;
	ans=ans*(m-1)%mod*(n-1)%mod;
	int sum=n+m-1,xb=min(n,m)-1,val=0;
	For(i,1,xb) xie[i]=i;
	Forr(i,sum,sum-xb+1) xie[i]=++val;
	ll ansx;
	
	ansx=(((ll)(xb-2))*((ll)(xb-3))%mod+((ll)(xb-2)))%mod*((ll)(sum-2*xb-1))%mod;	
cout<<ansx<<endl;
	For(i,3,xb) (ansx+=((ll)(i-1)*(ll)(i+1-3))%mod)%=mod;
cout<<ansx<<endl;
	For(i,sum-xb,sum-2) 
		(ansx+=((ll)(xie[i]-2-1)*((ll)(xie[i+1]-3))%mod+(ll)(2*(xie[i+1]-2)))%mod)%=mod;
cout<<ansx<<endl;
	(ansx*=2)%=mod;
	printf("%lld\n",(ans+ansx)%mod);
	return 0;
}


