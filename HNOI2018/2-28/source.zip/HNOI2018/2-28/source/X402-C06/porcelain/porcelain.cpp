#include<bits/stdc++.h>
#define mem(a,b) memset(a,b,sizeof(a))
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
}

const int maxn=1e5+10;
int beg[maxn<<1],nex[maxn<<1],to[maxn<<1],w[maxn<<1],e,num[maxn<<1];
int n,m,fa[maxn],cnt,id[maxn],tot;
int r,k,K[maxn<<1],ans[maxn],dis[maxn],vis[maxn],q[maxn<<1];

inline void add(int x,int y,int z,int i){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
	num[e]=i;
}

int find(int x){
	if(x==fa[x]) return fa[x];
	else return fa[x]=find(fa[x]);
}

inline void Search(){
	mem(vis,0),cnt=0;
	For(i,1,n) fa[i]=i;
	For(i,1,n){
		if(vis[i]) continue;
		cnt++;
		queue<int> Q;
		Q.push(i);
		while(!Q.empty()){
			int s=Q.front();Q.pop();
			vis[s]=1;
			for(register int i=beg[s];i;i=nex[i]){
				if(q[num[i]]) continue;
				int t=to[i];
				fa[t]=fa[s];
				if(!vis[t]){
					vis[t]=1;
					Q.push(t);
				}
			}
		}
	}	
}

inline void Clear(){
	mem(ans,0),mem(K,0),mem(q,0);
}

inline void Do(){
	mem(vis,0),mem(id,0),tot=0;
	For(i,1,n) dis[i]=-100000;
	dis[r]=0;
	queue<int> Q;
	Q.push(r);
	vis[r]=1;
	while(!Q.empty()){
		int s=Q.front();
		Q.pop();
		for(register int i=beg[s];i;i=nex[i]){
			int t=to[i];
			if(vis[t]) continue;
			dis[t]=dis[s]+w[i];
			vis[t]=1;
			Q.push(t);	
		}
	}
}

inline void Solve(){
	Do();
	For(i,1,n){
		if(!id[fa[i]]) id[fa[i]]=++tot;
		ans[i]=INT_MIN/3;
		ans[id[fa[i]]]=max(ans[id[fa[i]]],dis[i]);
	}
	sort(ans+1,ans+1+cnt);
	For(i,1,cnt) printf("%d ",ans[i]);
	putchar('\n');
}

int main(){
	file();
	read(n),read(m);
	For(i,1,n-1){
		int x,y,z;
		read(x),read(y),read(z);
		add(x,y,z,i);
		add(y,x,z,i);
	}
	while(m--){
		Clear();
		read(r),read(k);
		For(i,1,k) read(K[i]),q[K[i]]=1; //broken edge		
		Search();
		Solve();
	}	
	return 0;
}

