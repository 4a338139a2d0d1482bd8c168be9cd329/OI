#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
}

typedef long long ll;
const int maxn=20+5,MAX_FAC=40320+1e3;
const ll mod=1e9+7;
int vis[MAX_FAC],a[maxn],n,ans,fac[maxn];

int contor(){
	int res=0;
	For(i,0,n-1){
		int temp=0;
		For(j,i+1,n-1) if(a[j]<a[i]) temp++;
		res+=temp*fac[n-i-1];
	}
	return res;
}

inline void dfs(int x){
	int v=contor();
	if(!vis[v]){
		ans++,vis[v]=1;
		//printf("%d\n",v);
	}
	else return ;
	For(i,0,n-2) For(j,i+1,n-1){
		if(a[i]>a[j]){
			swap(a[i],a[j]);
			dfs(x+1);
			swap(a[i],a[j]);
		}
	}	
}

int main(){
	file();
	read(n),fac[1]=1;
	For(i,0,n-1){
		read(a[i]);
	}
	For(i,2,n) fac[i]=fac[i-1]*i;
	dfs(1);
	printf("%d\n",ans);
	return 0;
}

