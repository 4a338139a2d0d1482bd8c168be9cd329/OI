//2018-2-28
//miaomiao
//Read()
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)

int OP;
char chr;
inline void Read(int &x){
	chr = getchar(); OP = 1;
	while(chr < '0' || chr > '9'){
		chr = getchar(); if(chr == '-') OP = -1;
	}

	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
	x *= OP;
}

struct node{
	int id, v, w;
};

int n, rt, m, dis[N], ans[N];
bool ban[N], vis[N];

vector<node> G[N];

#define v G[now][i].v

void Dfs(int now, int F){
	For(i, 0, G[now].size() - 1) if(v != F){
		dis[v] = dis[now] + G[now][i].w;
		Dfs(v, now);
	}
}

int Col(int now, int F){
	int ret = dis[now]; vis[now] = true;
	For(i, 0, G[now].size() - 1) if(v != F){
		if(ban[G[now][i].id]) continue;
		ret = max(ret, Col(v, now));
	}
	return ret;
}

#undef v

int main(){
	freopen("porcelain.in", "r", stdin);
	freopen("porcelain.out", "w", stdout);
	
	int T, u, v, w;
	Read(n), Read(T);

	For(i, 1, n - 1){
		Read(u); Read(v); Read(w);
		G[u].pb((node){i, v, w}); G[v].pb((node){i, u, w});
	}

	while(T --){
		Read(rt), Read(m);
		For(i, 1, n - 1) ban[i] = false;
		For(i, 1, m) scanf("%d", &v), ban[v] = true;
		
		dis[rt] = 0; Dfs(rt, 0);
		For(i, 1, n) vis[i] = 0;

		int an = 0;
		For(i, 1, n) if(!vis[i]) ans[++an] = Col(i, 0);

		sort(ans + 1, ans + an + 1);
		For(i, 1, an) printf("%d%c", ans[i], i == an? '\n': ' ');
	}

	return 0;
}
