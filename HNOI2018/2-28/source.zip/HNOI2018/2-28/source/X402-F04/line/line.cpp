//2018-2-28
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (20 + 5)
const int P = 1e9 + 7;

int n;

struct node{
	int num[N];

	bool operator <(const node &rhs)const{
		For(i, 1, n)
			if(num[i] != rhs.num[i]) return num[i] < rhs.num[i];
		return false;
	}
}st;

int ans;
map<node, int> ms;
queue<node> q;

void Bfs(){
	ms[st] = ans = 1;
	node now;

	q.push(st);
	while(!q.empty()){
		now = q.front(); q.pop();

		For(i, 1, n) For(j, i + 1, n) if(now.num[i] > now.num[j]){
			swap(now.num[i], now.num[j]);
			if(!ms.count(now)){
				ms[now] = 1; ++ans; q.push(now);
			}
			swap(now.num[i], now.num[j]);
		}
	}
}

int main(){
	freopen("line.in", "r", stdin);
	freopen("line.out", "w", stdout);
	
	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &st.num[i]);
	
	Bfs();
	printf("%d\n", ans);

	return 0;
}
