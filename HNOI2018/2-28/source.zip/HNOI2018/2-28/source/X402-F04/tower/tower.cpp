//2018-2-28
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int n, m, ans;

int main(){
	freopen("tower.in", "r", stdin);
	freopen("tower.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	For(i1, 1, n) For(j1, 1, m) For(i2, i1, n)
	  For(j2, i1 == i2? j1 : 1, m) For(i3, i2, n)
		For(j3, i2 == i3? j2: 1, m)
			if(abs((i2 - i1) * (j3 - j1) - (j2 - j1) * (i3 - i1)) == 1) ans++;
						
	printf("%d\n",ans);
	
	return 0;
}
