#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n,m;
const double eps=1e-7;
double dis(double x,double y,double xx,double yy)
{
	return sqrt((x-xx)*(x-xx)+(y-yy)*(y-yy));
}
double S(double a,double b,double c)
{
	double p=(a+b+c)/2.0;
	return sqrt(p*(p-a)*(p-b)*(p-c));
}
int main()
{
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	read(n);read(m);
	int ans=0;
	for(double x=1;x<=n;x++)
		for(double y=1;y<=m;y++)
			for(double xx=1;xx<=n;xx++)
				for(double yy=1;yy<=m;yy++)
					for(double xxx=1;xxx<=n;xxx++)
						for(double yyy=1;yyy<=m;yyy++)
			if(fabs(S(dis(x,y,xx,yy),dis(x,y,xxx,yyy),dis(xx,yy,xxx,yyy))-0.5)<=eps)ans++;
	cout<<ans<<endl;
	return 0;
}
