#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n;
const long long mod=1e9+7;
char a[30];
set<string>mapp;
void bfs()
{
	queue<string>q;
	string k;
	for(register int i=1;i<=n;i++)k=k+a[i];
	q.push(k);
	mapp.insert(k);
	register int i,j;
	register char tmp;
	while(!q.empty())
	{
		k=q.front();
		q.pop();
		for(i=0;i<n;i++)
			for(j=i+1;j<n;j++)
			if(k[i]>k[j])
			{
				tmp=k[i];k[i]=k[j];k[j]=tmp;
				if(!mapp.count(k))q.push(k),mapp.insert(k);
				tmp=k[i];k[i]=k[j];k[j]=tmp;
			}
	}
}
int main()
{
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	read(n);
	if(n<=6)
	{
		for(register int i=1;i<=n;i++){static int x;read(x);a[i]=x+48;}
		bfs();
		printf("%d\n",mapp.size());
		return 0;
	}
	else
	{
		for(register int i=1;i<=n;i++){static int x;read(x);a[i]=x+48;}
		long long ans=1;
		for(int i=1;i<=n;i++)
		{
			long long tot=1;
			for(int j=i+1;j<=n;j++)
				if(a[i]>a[j])tot++;
			ans=(ans*tot)%mod;
		}
		printf("%lld\n",ans);
		return 0;
	}
	return 0;
}
