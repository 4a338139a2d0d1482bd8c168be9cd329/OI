#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
#define mp make_pair
#define x first
#define y second
const int maxn=100005,inf=0x3f3f3f3f;
int n,m;
vector<pair<int,int> >E[maxn];
pair<int,int>edge[maxn];
int fa[maxn],ans[maxn];
int find_fa(int u){
	return u==fa[u]?u:fa[u]=find_fa(fa[u]);
}
void BFS(int s){
	static queue<int>Q;
	static int dis[maxn];
	REP(i,1,n)dis[i]=ans[i]=-inf;
	dis[s]=0,Q.push(s);
	while(!Q.empty()){
		int u=Q.front();Q.pop();
		chkmax(ans[find_fa(u)],dis[u]);
		REP(i,0,E[u].size()-1){
			int v=E[u][i].x;
			if(dis[v]==-inf)
				dis[v]=dis[u]+E[u][i].y,Q.push(v);
		}
	}
}
void work(){
	static bool mark[maxn];
	REP(i,1,m){
		int pos=read(),cnt=read();
		REP(j,1,n)mark[j]=0,fa[j]=j;
		REP(j,1,cnt)mark[read()]=1;
		REP(j,1,n-1)
			if(!mark[j])
				fa[find_fa(edge[j].y)]=find_fa(edge[j].x);
		BFS(pos);
		sort(ans+1,ans+1+n);
		REP(j,n-cnt,n)
			write(ans[j],j==n?'\n':' ');
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n-1){
		int u=read(),v=read(),w=read();
		E[u].pb(mp(v,w)),E[v].pb(mp(u,w));
		edge[i]=mp(u,v);
	}
	if((n<=3000)&&(m<=3000))work();
	return 0;
}
