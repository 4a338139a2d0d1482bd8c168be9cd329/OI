#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int mod=998244353;
const lf eps=1e-9;
int n,m,ans;
lf dis(int a,int b,int c,int d){
	return sqrt((a-c)*(a-c)+(b-d)*(b-d));
}
lf calc(lf x,lf y,lf z){
	if(x<y)swap(x,y);
	if(x<z)swap(x,z);
	if(y<z)swap(y,z);
	if(x==y+z)return 0;
	lf p=(x+y+z)/2;
	return sqrt(p*(p-x)*(p-y)*(p-z));
}
bool dcmp(lf x){
	return (x>-eps)&&(x<eps);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
#endif
	n=read(),m=read();
	REP(a,1,n)
		REP(b,1,m)
			REP(c,1,n)
				REP(d,1,m)
					REP(e,1,n)
						REP(f,1,m){
							lf tmp=calc(dis(a,b,c,d),dis(a,b,e,f),dis(c,d,e,f));
							if(dcmp(tmp-0.5))++ans;
						}
	write(ans/6,'\n');
	return 0;
}
