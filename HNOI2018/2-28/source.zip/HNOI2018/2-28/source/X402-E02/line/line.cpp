#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
bool fl[3628805],f[11]; int w[23],a[23],q[3628805],l,r,n,qwer,asdf;
int fu(){
	asdf=0; memset(f,0,11);
	For(i,1,n){
		qwer=0;
		For(j,1,a[i]-1) if (!f[j]) ++qwer;
		asdf+=qwer*w[i]; f[a[i]]=1;
	}
	return asdf;
}
void ff(int s){
	memset(f,0,11);
	For(i,1,n){
		qwer=s/w[i]; s-=qwer*w[i]; asdf=0;
		for(;qwer>=0;) {++asdf; if (!f[asdf]) --qwer;}
		f[asdf]=1; a[i]=asdf;
	}
}
int main(){
	freopen("line.in","r",stdin); freopen("line.out","w",stdout);
	int x; n=read(); For(i,1,n) a[i]=read();
	if (n<=10){
		x=1; For(i,1,n) w[n-i+1]=x,x*=i; x=fu(),l=0,r=1,q[1]=x,fl[x]=1;
		while(l<r){
			x=q[++l]; ff(x);
			For(i,1,n-1)
				For(j,i+1,n)
					if (a[i]>a[j]){
						swap(a[i],a[j]); x=fu();
						if (!fl[x]) fl[x]=1,q[++r]=x; swap(a[i],a[j]);
					}
		}
		printf("%d\n",r); cerr<<clock()<<endl;
	}
	return 0;
}
