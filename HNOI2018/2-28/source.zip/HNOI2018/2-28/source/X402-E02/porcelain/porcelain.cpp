#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=100005;
int e,to[N<<1],head[N],nex[N<<1],w[N<<1],co[N<<1]; bool fl[N];
void add(int x,int y,int z,int i){
	to[++e]=y; nex[e]=head[x]; head[x]=e; w[e]=z; co[e]=i;
}
int cnt,s,an[N];
void dfs(int x,int y,int f,int g){
	if (y>an[g]) an[g]=y;
	for(int i=head[x];i;i=nex[i])
		if (to[i]!=f){
			if (fl[co[i]]) dfs(to[i],y+w[i],x,++cnt);
			else dfs(to[i],y+w[i],x,g);
		}
}
int main(){
	freopen("porcelain.in","r",stdin); freopen("porcelain.out","w",stdout);
	int n=read(),m=read(),x,y,z;
	if (n>30000&&m>30000) return 0;
	For(i,1,n-1) x=read(),y=read(),z=read(),add(x,y,z,i),add(y,x,z,i);
	For(_,1,m){
		x=read(),s=read(); memset(fl,0,n);
		For(i,1,s) y=read(),fl[y]=1; cnt=1;
		memset(an,128,(s+2)<<2); dfs(x,0,0,1);
		sort(an+1,an+1+cnt); For(i,1,cnt) printf("%d ",an[i]); printf("\n");
	}
	return 0;
}
