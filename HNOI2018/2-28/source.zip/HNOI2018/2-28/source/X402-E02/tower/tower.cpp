#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int gcd(int x,int y){
	return x==0?y:gcd(y%x,x);
}
double x,y,z,q;
double f(int a,int b,int c,int d,int e,int f){
	x=sqrt((a-c)*(a-c)+(b-d)*(b-d));
	y=sqrt((a-e)*(a-e)+(b-f)*(b-f));
	z=sqrt((c-e)*(c-e)+(d-f)*(d-f));
	q=(x+y+z)/2;
	q=q*(q-x)*(q-y)*(q-z); return sqrt(q);
}
int main(){
	freopen("tower.in","r",stdin); freopen("tower.out","w",stdout);
	int n=read(),m=read(),ans=0; double a;
	For(i1,1,n) For(j1,1,m)
		For(i2,1,n) For(j2,1,m)
			For(i3,1,n) For(j3,1,m){
				a=f(i1,j1,i2,j2,i3,j3); if (fabs(a-0.5)<=0.1) ++ans;
			}
	printf("%d\n",ans/6);
	return 0;
}
