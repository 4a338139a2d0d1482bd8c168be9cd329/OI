#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<map>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

typedef unsigned long long ul;
const int N=25;
const int mod=1e9+7;
const ul bas=1e9+7;
int a[N],n,ans=0;

map<ul,int>mp;
void dfs()
{
	ul Hash=0;
	for(int i=1;i<=n;++i) Hash=Hash*n+a[i]-1;

	if(mp[Hash]) return ;
	mp[Hash]=1;
	ans=(ans+1)%mod;
	if(ans>=mod) ans-=mod;

	for(int i=1;i<=n;++i) for(int j=i+1;j<=n;++j) if(a[i]>a[j])
	{
		swap(a[i],a[j]);
		dfs();
		swap(a[i],a[j]);
	}
}

void wj()
{
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) a[i]=read();
	dfs();
	printf("%d\n",ans);
	return 0;
}
