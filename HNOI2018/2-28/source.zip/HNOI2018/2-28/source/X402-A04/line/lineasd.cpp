#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=25;
int a[N],n;

void wj()
{
	freopen("line.in","r",stdin);
	//freopen("line.out","w",stdout);
}
int main()
{
	//wj();
	n=4;
	for(int i=1;i<=n;++i) a[i]=i;
	int lim=2,ans=0;
	do
	{
		int num=0;
		for(int i=1;i<=n;++i) for(int j=i+1;j<=n;++j) if(a[i]>a[j]) num++;
		if(num<=lim) {for(int i=1;i<=n;++i) cerr<<a[i]<<' ';cerr<<endl;ans++;}
		//ans++;
		//cerr<<ans<<": ";
		//for(int i=1;i<=n;++i) cerr<<a[i]<<' ';cerr<<endl;
	}while(next_permutation(a+1,a+1+n));
	cerr<<ans;
	return 0;
}
