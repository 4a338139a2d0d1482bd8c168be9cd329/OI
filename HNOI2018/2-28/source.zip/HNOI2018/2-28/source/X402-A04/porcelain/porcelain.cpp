#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int M=200050;
const int inf=0x3f3f3f3f;
int head[N],cnt=1;
struct node
{
	int to,next,w;
}e[N<<1];
inline void add(int x,int y,int w)
{
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],w};head[y]=cnt;
}
pii edg[N];
bool ban[N<<1];
int n,m;

namespace bf
{
	int dis[3050],ans[3050],tot=0;
	bool vis[3050];
	void dfs1(int u,int fa,int d)
	{
		dis[u]=d;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa) continue;
			dfs1(v,u,d+e[i].w);
		}
	}
	void dfs2(int u,int fa)
	{
		vis[u]=1; ans[tot]=max(ans[tot],dis[u]);
		for(int i=head[u];i;i=e[i].next) if(!ban[i])
		{
			int v=e[i].to;
			if(v==fa) continue;
			dfs2(v,u);
		}
	}
	void solve()
	{
		for(int cas=1;cas<=m;++cas)
		{
			for(int i=1;i<n;++i) ban[i<<1]=0,ban[i<<1|1]=0;
			for(int i=1;i<=n;++i) vis[i]=0;
			tot=0;

			int r=read(),k=read();
			for(int i=1;i<=k+1;++i) ans[i]=-inf;
			for(int i=1;i<=k;++i)
			{
				int x=read();
				ban[x<<1]=1; ban[x<<1|1]=1;
			}

			dfs1(r,0,0);
			for(int i=1;i<=n;++i) if(!vis[i]) {tot++;dfs2(i,0);}
			sort(ans+1,ans+1+tot);
			for(int i=1;i<=tot;++i) printf("%d ",ans[i]);
			printf("\n");
		}
	}
}

int askr[M],askk[M];
vector<int>ask[M];

namespace rsa
{
	int dfn[N],efn[N],clk=0,dis[N],rnk[N],dep[N];
	ll add[N<<2],maxv[N<<2];
	void dfs(int u,int fa,int d)
	{
		dfn[u]=++clk; rnk[clk]=u;
		dis[u]=d;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa) continue;
			dep[v]=dep[u]+1;
			dfs(v,u,d+e[i].w);
		}
		efn[u]=clk;
	}
	void build(int o,int l,int r)
	{
		if(l==r) {maxv[o]=dis[rnk[l]];return ;}
		int mid=l+r>>1;
		build(o<<1,l,mid); build(o<<1|1,mid+1,r);
		maxv[o]=max(maxv[o<<1],maxv[o<<1|1]);
	}
	void pushdown(int o)
	{
		if(add[o])
		{
			add[o<<1]+=add[o]; add[o<<1|1]+=add[o];
			maxv[o<<1]+=add[o]; maxv[o<<1|1]+=add[o];
			add[o]=0;
		}
	}
	void update(int o,int l,int r,int x,int y,int k)
	{
		if(x<=l&&r<=y) {maxv[o]+=k;add[o]+=k;return ;}
		pushdown(o);
		int mid=l+r>>1;
		if(x<=mid) update(o<<1,l,mid,x,y,k);
		if(y>mid) update(o<<1|1,mid+1,r,x,y,k);
		maxv[o]=max(maxv[o<<1],maxv[o<<1|1]);
	}
	ll ans_;
	void query(int o,int l,int r,int x,int y)
	{
		if(maxv[o]<ans_) return ;
		if(x<=l&&r<=y) {ans_=max(ans_,maxv[o]);return ;}
		pushdown(o);
		int mid=l+r>>1;
		if(x<=mid) query(o<<1,l,mid,x,y);
		if(y>mid) query(o<<1|1,mid+1,r,x,y);
	}

	int p[N],ans[N];
	bool cmp(int a,int b) {return dep[a]>dep[b];}
	void solve()
	{
		dfs(askr[1],0,0);
		build(1,1,n);
		for(int cas=1;cas<=m;++cas)
		{
			for(int i=0;i<askk[cas];++i)
			{
				int x=edg[ask[cas][i]].fi,y=edg[ask[cas][i]].se;
				if(dep[x]<dep[y]) swap(x,y);
				//subtree: x
				p[i+1]=x;
			}

			sort(p+1,p+1+askk[cas],cmp);
			for(int i=1;i<=askk[cas];++i)
			{
				int x=p[i];
				ans_=-1e18;
				query(1,1,n,dfn[x],efn[x]);
				ans[i]=ans_;
				update(1,1,n,dfn[x],efn[x],-inf);
			}
			ans_=-1e18;
			query(1,1,n,1,n);
			ans[askk[cas]+1]=ans_;
			for(int i=1;i<=askk[cas];++i) update(1,1,n,dfn[p[i]],efn[p[i]],inf);

			sort(ans+1,ans+1+askk[cas]+1);
			for(int i=1;i<=askk[cas]+1;++i) printf("%d ",ans[i]);
			printf("\n");
		}
	}
}

namespace bf2
{
	int bel[N],tot=0,ans[N];
	bool ban[N],vis[N],isout[N];
	int blkmax[N],dis[N],f[N][21],dep[N];
	vector<pii>out[N];

	void dfsdep(int u,int fa,int d,int d2)
	{
		dep[u]=d; dis[u]=d2; f[u][0]=fa;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa) continue;
			dfsdep(v,u,d+1,d2+e[i].w);
		}
	}
	int lca(int x,int y)
	{
		if(dep[x]<dep[y]) swap(x,y);
		int d=dep[x]-dep[y];
		for(int i=18;i>=0;--i) if(d&1<<i) x=f[x][i];
		if(x==y) return x;
		for(int i=18;i>=0;--i) if(f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
		return f[x][0];
	}
	void dfs(int u,int fa)
	{
		bel[u]=tot; vis[u]=1;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa) continue;
			if(ban[i]) 
			{
				if(!isout[u]) isout[u]=1;
				out[tot].pb(pii(u,v));
				continue;
			}
			dfs(v,u);
		}
	}
	void dfs2(int u,int fa,int d)
	{
		blkmax[bel[u]]=max(blkmax[bel[u]],d);
		for(int i=head[u];i;i=e[i].next) if(!ban[i])
		{
			int v=e[i].to;
			if(v==fa) continue;
			dfs2(v,u,d+e[i].w);
		}
	}

	void dfs3(int u,int d)
	{
		for(int i=0,siz=out[bel[u]].size();i<siz;++i)
		{
			int v=out[bel[u]][i].fi;
			int dd=dis[u]+dis[v]-dis[lca(u,v)]*2;
			ans[bel[u]]=max(ans[bel[u]],d+dd);
			if(u==v) continue;
			dfs3(out[bel[u]][i].se,d+dd);
		}
	}
	void solve()
	{
		dfsdep(1,0,0,0);
		for(int i=0;i<askk[1];++i) ban[ask[1][i]<<1]=1,ban[ask[1][i]<<1|1]=1;
		for(int i=1;i<=n;++i) if(!vis[i]) tot++,dfs(i,0);
		for(int i=1;i<=n;++i) if(isout[i]&&out[bel[i]].size()==1)
			dfs2(i,0,0);
		
		for(int j=1;j<=18;++j) for(int i=1;i<=n;++i) f[i][j]=f[f[i][j-1]][j-1];
		for(int cas=1;cas<=m;++cas)
		{
			tot=0;
			for(int i=1;i<=askk[cas]+1;++i) ans[i]=-inf;
			dfs3(askr[cas],0);
			sort(ans+1,ans+1+askk[cas]+1);
			for(int i=1;i<=askk[cas]+1;++i) printf("%d ",ans[i]);
			printf("\n");
		}
	}
}

void wj()
{
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
}
int main()
{
	wj();
	bool rsame=1;
	clock_t sta=clock();
	n=read(); m=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read(),z=read();
		add(x,y,z);
		edg[i]=pii(x,y);
	}

	if(n<=3000&&m<=3000) {bf::solve();return 0;}

	for(int i=1;i<=m;++i)
	{
		askr[i]=read(); askk[i]=read();
		for(int j=1;j<=askk[i];++j) ask[i].pb(read());
		if(i>1&&askr[i]!=askr[i-1]) rsame=0;
	}
	if(rsame) {rsa::solve();return 0;}
	bf2::solve();
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
