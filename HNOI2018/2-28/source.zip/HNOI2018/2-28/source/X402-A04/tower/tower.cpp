#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

const int mod=998244353;
const db eps=1e-8;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int n,m;
int x[5],y[5];
inline db dis(int i,int j)
{
	return sqrt(1.0*(x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]));
}
void print()
{
	for(int i=1;i<=3;++i) cerr<<x[i]<<' '<<y[i]<<' ';
	cerr<<endl;
}

void wj()
{
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
}
int main()
{
	wj();
	n=read(),m=read();
	int ans=0;
	for(x[1]=1;x[1]<=n;x[1]++) for(y[1]=1;y[1]<=m;y[1]++)
	for(x[2]=1;x[2]<=n;x[2]++) for(y[2]=1;y[2]<=m;y[2]++)
	for(x[3]=1;x[3]<=n;x[3]++) for(y[3]=1;y[3]<=m;y[3]++)
	{
		db a=dis(1,2),b=dis(2,3),c=dis(1,3);
		db p=(a+b+c)/2;
		db s=sqrt(p*(p-a)*(p-b)*(p-c));
		if(fabs(s-0.5)<=eps) ans++;//,print();
	}
	cout<<ans/6<<endl;
	/*ans=0;
	ans=(ans+1ll*m*(n-1)%mod*(m-1)%mod*2%mod)%mod;
	ans=(ans+1ll*n*(m-1)%mod*(n-1)%mod*2%mod)%mod;
	ans=(ans-1ll*(m-1)*(n-1)%mod*4%mod+mod)%mod;
	int sum=0;
	for(int i=1;i<=m;++i) sum=(sum+1ll*(n-2)*(m-i+1>>1)%mod*2%mod)%mod;
	for(int i=1;i<=n;++i) sum=(sum+1ll*(m-2)*(n-i+1>>1)%mod*2%mod)%mod;
	ans=(ans+1ll*sum*qpow(4,mod-2)%mod)%mod;
	printf("%d\n",ans);*/
	return 0;
}
