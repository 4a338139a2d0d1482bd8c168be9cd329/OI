#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int max(int a,int b){
	return a>b?a:b;
}
int min(int a,int b){
	return a<b?a:b;
}
int abs(int a){
	return a<0?-a:a;
}
int main(){
	int i,j,k,m,n,ans=0,a,b,x,y,ud=0;
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(a=1;a<=n;a++)
	    for(b=1;b<=m;b++)
	         for(x=1;x<=n;x++)
	             for(y=1;y<=m;y++)
	                 for(i=1;i<=n;i++)
	                     for(j=1;j<=m;j++){
	                         if(abs((x-a)*(b-j)-(i-a)*(b-y))==1){
	                             ans++;
	                         }
	                     }   
	printf("%d\n",ans/6);
	return 0;
}
