#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int a[1000010],v1[1000040],v2[1000040],v3[1000010],v4[1000050],v5[1000010],n,ans=0;
int f[20]={1009,1013,1019,1021,1031,1033,1039,1091,1181,1163};
int js(){
	int sum1=0,i,sum4=0,sum5=0,sum2=0,sum3=0,mod1=1000003,mod2=1000033,mod3=1000037,mod4=1000039;
	for(i=1;i<=n;i++){
	    sum1=sum1*10+a[i];
	    sum2=sum2*10+a[i];
	    sum3=sum3*10+a[i];
	    sum4=sum4*10+a[i];
	    sum5+=f[i-1]*a[i];
	    sum5%=1000000;
	    sum1%=mod1;
	    sum2%=mod2;
	    sum3%=mod3;
	    sum4%=mod4;
	}
	if(v1[sum1] && v2[sum2] && v3[sum3] && v4[sum4] && v5[sum5])return 1;
	v1[sum1]=v2[sum2]=v3[sum3]=v4[sum4]=v5[sum5]=1;
	return 0;
}
void dfs(){
	int i,j;
	if(!js())ans++;
	else return;
	for(i=1;i<=n;i++)
	   for(j=i+1;j<=n;j++){
	   	    if(a[i]>a[j]){
	   	    	swap(a[i],a[j]);
	   	    	dfs();
	   	    	swap(a[i],a[j]);
	   	    }
	   	}
}
int main(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	int i,j,k,m;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	    scanf("%d",&a[i]);
	dfs();
	printf("%d\n",ans);
	return 0;
}

