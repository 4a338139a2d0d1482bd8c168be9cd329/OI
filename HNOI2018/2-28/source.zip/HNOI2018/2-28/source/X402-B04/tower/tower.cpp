/*
Author: CNYALI_LK
LANG: C++
PROG: tower.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-5;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
const ll p=998244353;
ll gcd(ll a,ll b){return b?gcd(b,a%b):a;}
ll mj(ll xa,ll ya,ll xb,ll yb,ll xc,ll yc){
	double a=sqrt(sqr(xa-xb)+sqr(ya-yb)),b=sqrt(sqr(xc-xb)+sqr(yc-yb)),c=sqrt(sqr(xa-xc)+sqr(ya-yc));
	double p=(a+b+c)/2;
	if((p*(p-a)*(p-b)*(p-c)-0.25)<=eps)return 1;
	return 0;
}
int main(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	ll n,m;	
	n=read();m=read();
	ll ans=0;
	for(ll i=1-n;i<n;++i)for(ll j=1-m;j<m;++j)if(gcd(abs(i),abs(j))==1){
		for(ll k=1-n;k<n;++k)for(ll l=1-m;l<m;++l)if(gcd(abs(k),abs(l))==1)if(gcd(abs(i-k),abs(j-l))==1){

			if(mj(i,j,k,l,0,0)){
//				printf("Second%lld,%lld,%lld,%lld\n",i,j,k,l);
				ans+=max(n-max(i,max(k,0LL))+min(i,min(k,0LL)),0LL)*max(m-max(j,max(l,0LL))+min(j,min(l,0LL)),0LL);
//				printf("%lld\n",ans);
				ans%=p;
			}
		}
	}
	ans=ans*166374059%p;
	printf("%lld\n",ans);
	return 0;
}

