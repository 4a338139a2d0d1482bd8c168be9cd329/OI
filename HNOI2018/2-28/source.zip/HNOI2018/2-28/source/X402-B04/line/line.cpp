/*
Author: CNYALI_LK
LANG: C++
PROG: line.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>

#include<tr1/unordered_set>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll q[4567891],*l,*r;
ll	n,a;
tr1::unordered_set<ll> se;
ll t[1926];
void bfs(ll a){
	t[0]=1;
	for(ll i=1;i<=n;++i){
		t[i]=t[i-1]*n;
	}
	*(l=r=q)=a;
	se.insert(a);
	ll s;
	while(l<=r){
		s=*l;	
		for(ll i=0;i<n;++i)for(ll j=i+1;j<n;++j){
			ll wa=(s/t[i])%n,wb=(s/t[j])%n;
			if(wa<wb){
				s-=wa*t[i]-wb*t[i];
				s+=wa*t[j]-wb*t[j];
				if(!se.count(s)){
					*(++r)=s;
					se.insert(s);
				}
				s=*l;
			}
		}
		++l;
	}
}
int main(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	n=read();
	for(ll i=1;i<=n;++i)a=a*n+(read()-1);
	bfs(a);
	printf("%lld\n",r-q+1);		
	return 0;
}

