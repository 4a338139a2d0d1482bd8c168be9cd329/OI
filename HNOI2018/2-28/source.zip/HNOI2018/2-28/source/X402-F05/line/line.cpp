#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 21;

int n;
int A[N];

namespace BF {

	const int M = 1e6;

	bool vis[M];
	int ans = 0, P[N];
	queue<int> q;

	int getval(int *w) {
		int ret = 0;
		Forr(i, n, 1) ret = ret * n + w[i] - 1;
		return ret;
	}

	void push(int x) {
		if (!vis[x]) vis[x] = true, ++ans, q.push(x);
	}

	void main() {

		push(getval(A));
		while (!q.empty()) {
			int o = q.front(); q.pop();
			For(i, 1, n) P[i] = o % n + 1, o /= n;
			For(i, 1, n) For(j, i + 1, n)
				if (P[i] > P[j]) {
					swap(P[i], P[j]);
					push(getval(P));
					swap(P[i], P[j]);
				}
		}
		printf("%d\n", ans);
	}

};

int main() {

	freopen("line.in", "r", stdin);
	freopen("line.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &A[i]);
	
	if (n <= 7) BF::main();

	return 0;
}
