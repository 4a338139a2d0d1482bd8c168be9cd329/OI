#include <bits/stdc++.h>

#define x first
#define y second
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int Mod = 998244353;
const int inv = 166374059;

int gcd(int x, int y) {
	if (x < 0) x = -x;
	if (y < 0) y = -y;
	return !y ? x : gcd(y, x % y);
}

int n, m;

int main() {

	freopen("tower.in", "r", stdin);
	freopen("tower.out", "w", stdout);

	scanf("%d%d", &n, &m);

	int ans = 0;
	For(x1, 1, n) For(y1, 1, m)
		For(x2, 1, n) For(y2, 1, m) if (gcd(x2 - x1, y2 - y1) == 1)
			For(x3, 1, n) For(y3, 1, m) if (gcd(x3 - x1, y3 - y1) == 1) {
				int X1 = x2 - x1, Y1 = y2 - y1, X2 = x3 - x1, Y2 = y3 - y1;
				if (abs(X1 * Y2 - X2 * Y1) == 1) ++ans;
			}
	printf("%d\n", ans / 6);

	/*

	int c = 0;
	For(i, 1 - n, n - 1) For(j, 1 - m, m - 1) if (gcd(i, j) == 1) P[++c] = make_pair(i, j);
	int ans = 0;
	For(i, 1, c) For(j, i + 1, c) 
		if (abs(P[i].x * P[j].y - P[i].y * P[j].x) == 1) {
			int X = (P[i].x > 0) ^ (P[j].x > 0) ? abs(P[i].x + P[j].x) : max(abs(P[i].x), abs(P[j].x)),
				Y = (P[i].y > 0) ^ (P[j].y > 0) ? abs(P[i].y + P[j].y) : max(abs(P[i].y), abs(P[j].y));
			if (X < n && Y < m) (ans += (n - X) * (m - Y)) %= Mod;
		}
	printf("%lld\n", 1ll * ans * inv % Mod);
	int ans = 0;
	For(i, 1, c) For(j, i, c) {
		if (abs(P[i].x * P[j].y - P[i].y * P[j].x) == 1)
			(ans += (n - max(P[i].x, P[j].x)) * (m - max(P[i].y, P[j].y))) %= Mod;
		if (P[i].x && P[j].x && P[i].y + P[j].y < m && abs(P[i].x * -P[j].y - P[i].y * P[j].x) == 1)
			(ans += (n - max(P[i].x, P[j].x)) * (m - (P[i].y + P[j].y))) %= Mod;
	}
	printf("%d\n", ans);
	*/

	return 0;
}
