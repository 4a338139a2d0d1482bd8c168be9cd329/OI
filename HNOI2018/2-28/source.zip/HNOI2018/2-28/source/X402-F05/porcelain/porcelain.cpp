#include <bits/stdc++.h>

#define pb push_back
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10, M = 2e5 + 10;

int Begin[N], Next[M], to[M], len[M], e = 1;

void add(int u, int v, int w) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e, len[e] = w;
}

int n, m;
int *id[M];
int r[M], c[M], buffer[M << 2];

int fa[N], lb[N], rb[N], ver[N];

void DFS_init(int o) {
	static int clk = 0;
	lb[o] = ++clk;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == fa[o]) continue;
		fa[u] = o;
		ver[i >> 1] = u;
		DFS_init(u);
	}
	rb[o] = clk;
}

int mark[M];
int ans[N], dis[N], tot;

void DFS_dis(int o, int f, int x, int d) {
	dis[o] = d;
	ans[x] = max(ans[x], d);
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f) continue;
		DFS_dis(u, o, mark[i >> 1] ? ++tot : x, d + len[i]);
	}
}

namespace BF {

	void main() {
		For(i, 1, m) {
			For(j, 1, c[i]) mark[id[i][j]] = true;
			For(j, 0, c[i]) ans[j] = -2e9;
			tot = 0;
			DFS_dis(r[i], 0, 0, 0);
			assert(tot == c[i]);
			sort(ans, ans + c[i] + 1);
			For(j, 0, c[i]) printf("%d%c", ans[j], j == c[i] ? '\n' : ' ');
			For(j, 1, c[i]) mark[id[i][j]] = false;
		}
	}

};

namespace Subtask1 {
	


};

namespace Subtask2 {

	bool cmp(int x, int y) {
		return lb[x] < lb[y];
	}

	int Max[N][18], Log2[N];

	void init_rmq() {
		int D = 0;
		For(i, 1, n) Max[lb[i]][0] = dis[i], D = max(D, dis[i]);
		For(i, 2, n) Log2[i] = Log2[i >> 1] + 1;
		For(j, 1, 17) 
			for (int i = 1; i + (1 << j) - 1 <= n; ++i) 
				Max[i][j] = max(Max[i][j - 1], Max[i + (1 << (j - 1))][j - 1]);
	}

	int qry(int l, int r) {
		if (l > r) return -2e9;
		++r;
		int j = Log2[r - l - 1];
		return max(Max[l][j], Max[r - (1 << j)][j]);
	}

	vector<int> pos[N];
	int s[N];
	int st[N], top;
	int ans[N];

	void main() {
		DFS_dis(r[1], 0, 0, 0);
		init_rmq();	

		For(i, 1, m) {	
			s[0] = 1;
			For(j, 1, c[i]) s[j] = ver[id[i][j]];
			sort(s, s + c[i] + 1, cmp);
			For(j, 0, c[i]) pos[j].clear(), pos[j].pb(lb[s[j]]);
			st[top = 1] = 0;

			For(j, 1, c[i]) {
				while (rb[s[st[top]]] < lb[s[j]]) --top;
				pos[st[top]].pb(lb[s[j]] - 1), pos[st[top]].pb(rb[s[j]] + 1);
				st[++top] = j;
			}

			For(j, 0, c[i]) {
				ans[j] = -2e9;
				pos[j].pb(rb[s[j]]);
				int sz = pos[j].size() / 2;
				For(k, 0, sz - 1) ans[j] = max(ans[j], qry(pos[j][k << 1], pos[j][k << 1 | 1]));
			}
			sort(ans, ans + c[i] + 1);
			For(j, 0, c[i]) printf("%d%c", ans[j], j == c[i] ? '\n' : ' ');

		}
	}

};

int main() {

	freopen("porcelain.in", "r", stdin);
	freopen("porcelain.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n - 1) {
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		add(u, v, w), add(v, u, w);
	}
	DFS_init(1);
	id[0] = buffer;

	bool samer = true, samee = true;

	For(i, 1, m) {
		scanf("%d%d", &r[i], &c[i]);
		id[i] = id[i - 1] + c[i - 1] + 1;
		For(j, 1, c[i]) scanf("%d", &id[i][j]);
		samer &= r[i] == r[1];
		sort(id[i] + 1, id[i] + c[i] + 1);
		For(j, 1, c[i]) samee &= id[i][j] == id[1][j];
	}

	if (1ll * n * m <= 2e8) BF::main();
	else if (samer) Subtask2::main();

	return 0;
}
