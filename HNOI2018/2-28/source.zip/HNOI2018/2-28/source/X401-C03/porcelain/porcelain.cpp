#include<bits/stdc++.h>
#define IN inline
#define LL long long
using namespace std;

namespace lct{
	#define fa   t[x].pa
	#define lson t[x].ch[0]
	#define rson t[x].ch[1]
	struct node{int ch[2],pa,sum,w;bool mark;}t[100005];
	IN bool isRson(int x){ return x == t[fa].ch[1]; }
	IN bool isNson(int x){ return x != t[fa].ch[0] and x != t[fa].ch[1] ;}
	IN void updata(int x){ t[x].sum = t[lson].sum ^ t[rson].sum ^ t[x].w ;}
	IN void turn  (int x){ t[x].mark ^= 1; swap(lson, rson);}
	IN void push_down(int x){ if( t[x].mark )turn(lson),turn(rson);t[x].mark = 0;}
	IN void pd    (int x){ if( !isNson(x) )pd(fa);push_down(x); }
	IN void rotate(int x){
		int f = fa,g = t[f].pa;bool o = isRson(x);
		if( !isNson(f) )t[g].ch[ isRson(f) ]=x;     t[x].pa=g;
        t[f].ch[o    ] = t[x].ch[o ^ 1]; t[ t[f].ch[o] ].pa=f;
        t[x].ch[o ^ 1] = f             ; t[ f          ].pa=x;
		updata(f);updata(x);
	}
	IN void splay (int x){
		pd(x);
		for(;!isNson(x);rotate(x)) if(!isNson(fa))rotate( (isRson(x) == isRson(fa) ) ? fa:x);
	}
	IN void access(int x){ for(int y=0 ;x; y=x, x=fa) splay(x), rson = y, updata(x);}
	IN void make_root(int x){ access(x); splay(x); turn(x);}
	IN int  find_root(int x){ access(x); splay(x); while(lson) push_down(x), x = lson;return x;}
	IN void link  (int x,int y){ make_root(x); fa = y;}
	IN void split (int x,int y){ make_root(x); access(y); splay(y); }
	IN void cut   (int x,int y){ split(x,y)  ; fa = t[y].ch[0] = 0; updata(x); }
}using namespace lct;

int main(){
	int a,b;cin >> a >> b;
	for(int i = 1;i <= a;i ++)scanf("%d",&t[i].w);
	for(int i = 1;i <= b;i ++){
		int op,x,y;scanf("%d%d%d",&op,&x,&y);
		if(op == 0)split(x,y),printf("%d\n",t[y].sum);
		if(op == 1)if( find_root(x) != find_root(y) )link(x,y);
		if(op == 2)if( find_root(x) == find_root(y) )cut(x,y);
		if(op == 3)t[x].w = y,splay(x);
	}
}
