#include<bits/stdc++.h>
using namespace std;

int num[25];
long long ans = 1;
long long mod = 1e9 + 7;

int main(){
	//freopen("line.in","r",stdin);
	//freopen("line.out","w",stdout);
	int a;cin >> a;
	for(int i = 1;i <= a;i ++)cin >> num[i];
	for(int i = 1;i <= a;i ++){
		long long all = 1;
		for(int j = i + 1;j <= a;j ++){
			if(num[j] < num[i])all ++;
		}
		(ans *= all) %= mod;
	}
	cout << ans;
	return 0;
}
