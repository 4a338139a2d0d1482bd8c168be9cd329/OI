#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,q[3012][3012];
int tot=0,pre[100012],now[100012],son[100012],num[100012],v[100012];
int maxn,h[100012],w,vis[100012],f[100012];

void add(int a,int b,int c,int i){
	tot++;
	pre[tot]=now[a];
	now[a]=tot;
	son[tot]=b;
	v[tot]=c;
	num[tot]=i;
}

void doing(int pos,int x,int fa,int dis){
	q[pos][x]=dis;
	for (int p=now[x];p>0;p=pre[p])
	{
	  int s=son[p];
	  if (s==fa)
	    continue;
	  doing(pos,s,x,dis+v[p]);
	}
}

void dfs(int x,int fa){
	maxn=max(maxn,q[w][x]);
	vis[x]=1;
	for (int p=now[x];p>0;p=pre[p])
	{
	  if (f[num[p]]==0)
	    continue;
	  int s=son[p];
	  if (s==fa)
	    continue;
	  dfs(s,x);
	}
}

int main(){
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n-1;i++)
	{
	  int a,b,c;
	  scanf("%d%d%d",&a,&b,&c);
	  add(a,b,c,i);
	  add(b,a,c,i);
	}
	for (int i=1;i<=n;i++)
	  doing(i,i,0,0);
	while (m--)
	{
	  int k;
	  scanf("%d%d",&w,&k);
	  for (int i=1;i<=n;i++)
	    f[i]=1,vis[i]=0;
	  for (int i=1;i<=k;i++)
	  {
	  	int aa;
		scanf("%d",&aa);
	  	f[aa]=0;
	  }
	  int tt=0;
	  for (int i=1;i<=n;i++)
	  	if (!vis[i])
	  	{
	  	  maxn=-1000000000;
	  	  dfs(i,0);
	  	  h[++tt]=maxn;
	    }
	  sort(h+1,h+1+tt);
	  printf("%d",h[1]);
	  for (int i=2;i<=tt;i++)
	    printf(" %d",h[i]);
	  printf("\n");
	}
	return 0;
}
