#include<cstdio>
#include<algorithm>
using namespace std;

int n,a[100012],ans=0,fac[112];
bool f[5000012],q[112];


int check(){
	int num=0;
	for (int i=1;i<=n;i++)
	{
	  int aa=0;
	  for (int j=i+1;j<=n;j++)
	    if (a[i]>a[j])
		  aa++;
	  num+=aa*fac[n-i];
	}
	num++;
	if (f[num])
	  return false;
	f[num]=1;
	return true;
}

void doing(int pos){
	if (check())
	  ans++;
	else
	  return ;
	for (int i=1;i<=n;i++)
	  for (int j=i+1;j<=n;j++)
      {
		if (a[i]>a[j])
	  	{
		  swap(a[i],a[j]);
		  doing(pos+1);
		  swap(a[i],a[j]);
		}
	  }
}

int main(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	scanf("%d",&n);
	fac[1]=1;
	for (int i=2;i<=n;i++)
	  fac[i]=fac[i-1]*i;
	for (int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
	doing(1);
	printf("%d\n",ans);
	return 0;
}
