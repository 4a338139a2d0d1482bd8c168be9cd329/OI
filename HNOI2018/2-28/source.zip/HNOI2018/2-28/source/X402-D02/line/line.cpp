#include<iostream>
#include<cstdio>
#include<cstring>

const int N=10000000;

bool vis[N];

int s[N];
int n;

int calc()
{
	int ret=0;
	for(int i=1;i<=n;i++)
		ret=ret*7+s[i];
	return ret;
}

void dfs()
{
	int h=calc();
	if(vis[h])return;vis[h]=1;

	for(int i=1;i<=n;i++)
		for(int j=1;j<i;j++)
			if(s[j]>s[i])
			{
				std::swap(s[i],s[j]);
				dfs();
				std::swap(s[i],s[j]);
			}
}

int main()
{
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",s+i);
	dfs();
	
	int ans=0;
	for(int i=0;i<N;i++)
		ans+=vis[i];
	printf("%d\n",ans);
	return 0;
}
