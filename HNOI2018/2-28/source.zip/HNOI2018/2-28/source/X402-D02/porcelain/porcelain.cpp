#include<iostream>
#include<cstdio>
#include<cstring>
#include<set>
#include<ctime>

inline bool check_max(int a,int &b){return a>b?b=a,1:0;}
inline bool check_min(int a,int &b){return a<b?b=a,1:0;}

inline void read(int &x)
{
	char c=x=0,flag=1;
	for(c=getchar();!isdigit(c) && c!='-';c=getchar());
	if(c=='-')flag=-1,c=getchar();
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
	x*=flag;
}

namespace gongye
{
	typedef std::multiset<int>::iterator sit;
	const int N=201000,INF=1000000007;

	struct normal_tree
	{
		int begin[N],next[N],to[N],w[N];
		int dep[N],sum[N],top[N],fa[N];
		int e;
		void add(int x,int y,int z,bool k=1)
		{
			to[++e]=y;
			next[e]=begin[x];
			begin[x]=e;
			w[e]=z;
			if(k)add(y,x,z,0);
		}
		int predfs(int p=1,int h=0)
		{
			dep[p]=dep[h]+1;
			top[p]=p,fa[p]=h;

			int sizp=1,sizq,maxsiz=0,maxson=0;
			for(int i=begin[p],q;i;i=next[i])
				if((q=to[i])!=h)
				{
					sum[q]=sum[p]+w[i];
					if(check_max(sizq=predfs(q,p),maxsiz))maxson=q;
					sizp+=sizq;
				}
			top[maxson]=p;
			return sizp;
		}
		int ask(int p){return top[p]==p?p:top[p]=ask(top[p]);}
		int get_lca(int u,int v)
		{
			if(ask(u)==ask(v))return dep[u]<dep[v]?u:v;
			if(dep[ask(u)]<dep[ask(v)])std::swap(u,v);
			return get_lca(fa[ask(u)],v);
		}
		int dis(int u,int v){return sum[u]+sum[v]-sum[get_lca(u,v)]*2;}
	}T;

#define L(p) (st[p][0])
#define R(p) (st[p][1])
#define F(p) (fa[p])
#define P(p) (st[fa[p]][1]==p)

	int st[N][2],fa[N];
	int topv[N],botv[N];
	int w[N],sum[N];

	std::multiset<int> val[N];

#define calc(p) (*(--val[p].end()))

	bool rev[N];

	void output()
	{
		for(int i=1;i<=9;i++)
		{
//			if(!F(i) && !L(i) && !R(i))continue;
			if(i!=1 && i!=2 && i!=6 && i!=7 &&  i!=9)continue;
			printf("%d : %d|%d/%d , rev:%d , sum:%d , topv:%d ,botv:%d\n",i,F(i),L(i),R(i),rev[i],sum[i],topv[i],botv[i]);
			printf("        val ? %d , %d\n",!val[i].empty(),val[i].empty()?-1:calc(i));
		}
		printf("------------------\n");
	}


	inline bool isr(int p){return L(F(p))!=p && R(F(p))!=p;}
	void upd(int p)
	{
		int sl=w[p]+sum[L(p)],sr=w[p]+sum[R(p)];

		if(val[p].empty())topv[p]=sl;
		else topv[p]=calc(p)+sl;
		check_max(std::max(topv[L(p)],topv[R(p)]+sl),topv[p]);

		if(val[p].empty())botv[p]=sr;
		else botv[p]=calc(p)+sr;
		check_max(std::max(botv[R(p)],botv[L(p)]+sr),botv[p]);

		sum[p]=sum[L(p)]+sum[R(p)]+w[p];
	}
	inline void put(int p)
	{
		std::swap(topv[p],botv[p]);
		std::swap(L(p),R(p));
		rev[p]^=1;
	}
	inline void down(int p)
	{
		if(rev[p])
		{
			put(L(p)),put(R(p));
			rev[p]=0;
		}
	}
	void Down(int p)
	{
		if(!isr(p))Down(F(p));
		down(p);
	}
	void rot(int p)
	{
		int f=F(p),h=F(f),i=P(p),j=P(f),s=st[p][i^1];
		if(!isr(f))st[fa[p]=h][j]=p;
		else fa[p]=h;
		st[fa[f]=p][i^1]=f;
		st[fa[s]=f][i]=s;
		upd(f);
	}
	void splay(int p)
	{
		Down(p);
		for(;!isr(p);rot(p))
		{
//			if(p==6)
//			{
//				printf("233 < %d\n",F(p));
//				printf(" %d , %d\n",L(9),R(9));
//			}

			if(isr(F(p)));
			else if(P(p)==P(F(p)))rot(F(p));
			else rot(p);
		}
		upd(p);
	}
	void access(int p)
	{
		splay(p);
		int s=R(p);R(p)=0;
		if(s)val[p].insert(topv[s]);

		for(int f;(f=F(p))!=0;rot(p),upd(p))
		{
			splay(f);
			s=R(f),R(f)=p;

			if(s)val[f].insert(topv[s]);
			val[f].erase(val[f].find(topv[p]));
		}
	}
	void setrt(int p)
	{
		access(p);
		put(p);
	}
	void link(int u,int v)
	{
		setrt(u);
		F(u)=v;
		val[v].insert(topv[u]);
	}
	inline int findrt(int p)
	{
		while(F(p))p=F(p);
		return p;
	}
	bool uni(int u,int v)
	{
		setrt(u);
		while(F(v))v=F(v);
		return u==v;
	}
	void cut(int u,int v)
	{
		setrt(u);
		access(v);
		L(v)=F(u)=0;
		upd(v);
	}
	int query(int v)
	{
		setrt(v);
		access(v);
		int ret=w[v];
		if(!val[v].empty())ret+=calc(v);
		return ret;
	}

#define E(i) (n+(i))

	int edge[N][2];
	int n,m;

	void initialize()
	{
		read(n),read(m);
		for(int i=1,u,v,h;i<n;i++)
		{
			read(u),read(v),read(h);

			edge[i][0]=u,edge[i][1]=v;
			T.add(u,v,h);

			w[E(i)]=h;
			link(u,E(i)),link(v,E(i));
		}
		T.predfs();
	}

#define fuck(p) (query(p)+T.dis(p,rt))

	int cnt=0;

	void work()
	{
		static int id[N];
		static std::multiset<int> ans;

		ans.clear();

		int rt,k;
		read(rt),read(k);
		setrt(rt);
		for(int i=1;i<=k;i++)
			read(id[i]);

		cnt+=k;
//		printf(":%d %d\n",rt,k);

		ans.insert(fuck(rt));

		for(int i=1,x,u,v,h;i<=k;i++)
		{
			x=id[i],u=edge[x][0],v=edge[x][1];
			h=findrt(u);

			ans.erase(ans.find(fuck(h)));

			cut(u,E(x));
			cut(v,E(x));
			if(!uni(u,h))std::swap(u,v);

			ans.insert(fuck(h));
			ans.insert(fuck(v));
		}

		for(int i=1,x,u,v;i<=k;i++)
		{
			x=id[i],u=edge[x][0],v=edge[x][1];
			link(u,E(x));
			link(v,E(x));
		}

		for(sit it=ans.begin();it!=ans.end();it++)
			printf("%d ",*it);
		printf("\n");
	}

	void solve()
	{
		initialize();
		while(m--)work();

//		fprintf(stderr,"cnt = %d\n",cnt);
	}
}

int main()
{
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
	gongye::solve();

//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
