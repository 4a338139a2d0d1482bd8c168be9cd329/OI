#include<iostream>
#include<cstdio>
#include<cstring>
#define x first
#define y second

typedef long long ll;
typedef std::pair<int,int> pii;
const int MOD=998244353;

int cross(pii A,pii B){return A.x*B.y-A.y*B.x;}

int calc(pii A,pii B,pii C)
{
	B=pii(B.x-A.x,B.y-A.y);
	C=pii(C.x-A.x,C.y-A.y);
	int ret=cross(B,C);
	if(ret<0)ret*=-1;
	return ret;
}

pii s[105];

int n,m,tot;

int main()
{
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
	scanf("%d%d",&n,&m);
	tot=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			s[++tot]=pii(i,j);

	int ans=0;
	for(int i=1;i<=tot;i++)
		for(int j=i+1;j<=tot;j++)
			for(int k=j+1;k<=tot;k++)
				if(calc(s[i],s[j],s[k])==1)
					ans++;

	printf("%d\n",ans);
	return 0;
}
