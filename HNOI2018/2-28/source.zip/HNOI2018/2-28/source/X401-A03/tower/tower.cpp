#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=n;--i)
#define ll long long
using namespace std;
void File(){
	freopen("tower.in","r",stdin);
	freopen("tower.out","w",stdout);
}
bool pd(int x1,int y1,int x2,int y2,int x3,int y3){
	int s=abs((x2-x1)*(y3-y1)-(x3-x1)*(y2-y1));
	return s==1;
}
ll n,m,ans;
int main(){
	File();
	scanf("%lld%lld",&n,&m);
	REP(x1,1,n)REP(y1,1,m)
	REP(x2,1,n)REP(y2,1,m)
	REP(x3,1,n)REP(y3,1,m)
		if(pd(x1,y1,x2,y2,x3,y3))++ans;
	printf("%lld\n",ans/6);
	return 0;
}
