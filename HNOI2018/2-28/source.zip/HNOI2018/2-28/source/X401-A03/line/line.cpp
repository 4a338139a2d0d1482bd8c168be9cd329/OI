#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<map>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
using namespace std;
void File(){
	freopen("line.in","r",stdin);
	freopen("line.out","w",stdout);
}
const int maxn=20+10;
const int maxx=1e7;
int n,a[maxn],ans,e[maxn];
map<ll,bool>s;
bool pd(){
	ll p=0;
	REP(i,1,n)p=(p<<1)+(p<<3)+a[i];
	if(s[p]==1)return 0;
	else return s[p]=1;
}
void dfs(){
	REP(i,1,n)REP(j,e[i]+1,n)
		if(a[e[i]]>a[j]){
			swap(a[e[i]],a[j]);
			if(pd()){
				++ans;
				dfs();
			}
			swap(a[e[i]],a[j]);
		}
}
int main(){
	File();
	scanf("%d",&n);
	REP(i,1,n)scanf("%d",&a[i]);
	REP(i,1,n)e[i]=i;
	REP(i,1,100)swap(e[rand()%n+1],e[rand()%n+1]);
	dfs();
	cout<<ans+1<<endl;
	return 0;
}
