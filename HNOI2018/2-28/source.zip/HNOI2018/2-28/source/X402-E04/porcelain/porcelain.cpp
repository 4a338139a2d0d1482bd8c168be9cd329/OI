#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();int f=0;
	while(!isdigit(c))f |= (c == '-'), c = getchar();
	while( isdigit(c)) x = x * 10 + c - 48, c = getchar();
	x = f ? -x : x;
}
inline void file(){
	freopen("porcelain.in","r",stdin);
	freopen("porcelain.out","w",stdout);
}
namespace BF{
	int n, m, Begin[N], Next[N<<1], to[N<<1], e=1, w[N<<1], Ban[N<<1];
	inline void add(int x, int y, int z){
		to[++e] = y, Next[e] = Begin[x], Begin[x] = e;w[e] = z;
	}
	void init(){
		read(n), read(m);
		For(i, 1, n - 1){
			int x, y, z;
			read(x), read(y), read(z);
			add(x, y, z), add(y, x, z);
		}
	}
	int ans[N], op[N], vis[N], fa[N], dep[N];
	void dfs(int u, int f){
		fa[u] = f;vis[u] = 0;
		Rep(i, u)if(v^f){
			dep[v] = dep[u] + w[i], dfs(v, u);
			if(Ban[i])vis[v] = 1;
		}
	}
	void dfs1(int u){
		ans[ans[0]] = max(ans[ans[0]], dep[u]);
		Rep(i, u)if(!Ban[i] && v != fa[u])dfs1(v);
	}
	void solve(){
		init();
		while(m --){
			int r, k;
			read(r), read(k);
			For(i, 1, k){
				int x;
				read(x), x *= 2, Ban[x] = Ban[x^1] = 1;
				op[i] = x;
			}
			dep[r] = 0;
			dfs(r, 0);
			ans[0] = 0;vis[r] = 1;
			For(i, 1, n)if(vis[i])++ans[0], ans[ans[0]] = -INF, dfs1(i);
			sort(ans + 1, ans + ans[0] + 1);
			For(i, 1, ans[0])printf("%d ",ans[i]);
			puts("");
			For(i, 1, k){
				int x = op[i];
				Ban[x] = Ban[x ^ 1] = 0;
			}
		}
	}
}
namespace BF1{
	
}
void solve(){
	if(n <= 3000)BF::solve();
	else BF1::solve();
}
int main(){
	file();
	solve();
	return 0;
}
