/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-28 09:02
#
# Filename: tower.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const LL Mod = 998244353;

LL n, m, ans;

int main()
{
    freopen("tower.in", "r", stdin);
    freopen("tower.out", "w", stdout);
    cin >> n >> m;
    REP(i1, 1, n)
        REP(j1, 1, m)
            REP(i2, i1, n)
                REP(j2, i1 == i2 ? j1 : 1, m)
                    REP(i3, i2, n)
                        REP(j3, i2 == i3 ? j2 : 1, m)
                        {
                            if ( abs((i2 - i1) * (j3 - j1) - (i3 - i1) * (j2 - j1)) == 1 )
                            {
                                ++ ans;
                                if ( ans > Mod ) ans -= Mod;
                            }
                        }
    printf("%lld\n", ans);
    return 0;
}

