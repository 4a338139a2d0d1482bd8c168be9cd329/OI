/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-28 09:14
#
# Filename: line.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 110;
const int Mod = 1000000007;

int n, a[maxn], ans;
bool Hash1[10000010], Hash2[10000010], Hash3[10000010], Hash4[10000010];
int s1[maxn] = {9113, 2699, 3217, 2203, 4751, 4177, 7151, 8089, 7927, 9697, 8293, 9011};
int s2[maxn] = {7653, 9227, 3347, 4363, 3911, 6473, 8039, 1097, 1987, 4733, 9871, 8699};
int s3[maxn] = {8263, 7219, 7643, 5347, 4327, 2791, 3907, 1321, 1721, 1229, 1117, 9973};
int s4[maxn] = {9137, 8293, 8737, 8573, 9719, 9661, 8101, 8501, 8329, 8423, 9371, 9931};

bool pd()
{
    int sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0;
    REP(i, 1, n)
    {
        sum1 += a[i] * s1[i];
        sum2 += a[i] * s2[i]; 
        sum3 += a[i] * s3[i];
        sum4 += a[i] * s4[i];
    }
    if ( Hash1[sum1] == true && Hash2[sum2] == true && Hash3[sum3] == true && Hash4[sum4] == true )  
    {
        // Hash1[sum1] = Hash2[sum2] = true;
        return false;
    }
    Hash1[sum1] = Hash2[sum2] = Hash3[sum3] = Hash4[sum4] = true;
    return true;
}

void dfs()
{
    if ( pd() ) 
    {
        ++ ans;
        ans %= Mod;
    }
    else return ;
    REP(i, 1, n - 1)
        REP(j, i + 1, n)
        {
            if ( a[i] <= a[j] ) continue ;
            swap(a[i], a[j]);
            dfs();
            swap(a[i], a[j]);
        }
}

int main()
{
    freopen("line.in", "r", stdin);
    freopen("line.out", "w", stdout);
    scanf("%d", &n);
    REP(i, 1, n) scanf("%d", &a[i]);
    dfs();
    printf("%d\n", ans);
    return 0;
}

