#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int mod = 998244353;

int n, m, ans[1010][1010];

int gcd(int x,int y){return !y ? x : gcd(y, x%y);}

void pre_work(){
	int Max = max(n, m);
	For(i, 1, Max){
		For(j, 1, Max){
			ans[i][j] = (ans[i][j-1] + ans[i-1][j]) % mod;
			(ans[i][j] += (gcd(j+1, i) == 1 && gcd(j, i) == 1) && (i - 1) / 2 == 0) %= mod;
			ans[i][j] = ( (ans[i][j] - ans[i-1][j-1]) % mod + mod) % mod;
		}
	}
}

void Get(){
	n = read(), m = read();
}

void solve_bf(){
	int Ans = 0;
	For(i, 1, n){
		For(j, 1, m){
			if(j+1 <= m){
				(Ans += ans[n-i][m-j-1]) %= mod;
				(Ans += ans[i-1][m-j-1]) %= mod;

				(Ans += ans[i-1][j-1]) %= mod;
				(Ans += ans[n-i][j-1]) %= mod;
			}

			if(i+1 <= n){
				(Ans += ans[m-j][n-i-1]) %= mod;
				(Ans += ans[m-j][i-1]) %= mod;

				(Ans += ans[j-1][n-i-1]) %= mod;
				(Ans += ans[j-1][i-1]) %= mod;
			}
		}
	}

	(Ans += 1ll * (n-1) * (m-1) % mod * 4 % mod) %= mod;
	printf("%d\n", Ans);
}

void bf(){
	int Ans = 0;
	For(i, 1, n){
		For(j, 1, m){
			For(u, i+1, n){
				For(v, j+1, m){
					if(gcd(u-i, v-j) != 1) continue;

					For(o, i, u){
						For(p, j, v){
							if(i == o && j == p) continue;
							if(u == o && v == p) continue;

							if(gcd(o-i, p-j) != 1) continue;
							if(gcd(u-o, v-p) != 1) continue;
							
							int S = 0;
							S = (v-j) * (u-i);
							S -= (o-i) * (p-j);
							S -= (u-o) * (v-p);
							S -= min( (u-o) * (p-j), (o-i) * (v-p) ) * 2;

							if(S == 1) ++ Ans;
						}
					}
				}
			}
		}
	}

	printf("%d\n", Ans * 2);
}

int main(){

	freopen("tower.in", "r", stdin);
	freopen("tower.out", "w", stdout);
	
	Get();
	bf();

	return 0;
}
