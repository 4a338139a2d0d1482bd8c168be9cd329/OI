#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 5000010;

const int p = 2333333;

const int pp = 23333333;

const int mod = 1e9 + 7;

int n, a[maxn], Hash[maxn], Begin[maxn], to[maxn], e, Next[maxn], Ans;

void Get(){
	n = read();
	For(i, 1, n) a[i] = read();
}

int calc(){
	int ans = 0;
	For(i, 1, n) ans = 1ll * ans * pp % mod + a[i];
	return ans % mod;
}

void add(int ans){
	to[++e] = ans;
	Next[e] = Begin[ans % p];
	Begin[ans % p] = e;
}

bool check(){
	int ans = calc();
	for(int i = Begin[ans % p]; i; i = Next[i]){
		int v = to[i];
		if(v == ans) return 0;
	}

	add(ans);
	return 1;
}

void dfs(){
	For(i, 1, n){
		For(j, i+1, n){
			if(a[i] > a[j]){
				int tmp = a[i];
				a[i] = a[j];
				a[j] = tmp;

				if(check()) {
					++ Ans;
					dfs();
				}

				tmp = a[i];
				a[i] = a[j];
				a[j] = tmp;
			}
		}
	}
}

void solve_bf_0point(){
	Ans += check();
	dfs();
	printf("%d\n", Ans);
}

int main(){
	
	freopen("line.in", "r", stdin);
	freopen("line.out", "w", stdout);

	Get();
	solve_bf_0point();

	return 0;
}
