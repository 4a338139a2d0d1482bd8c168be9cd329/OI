#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int Begin[maxn], to[maxn], e, Next[maxn], id[maxn], st[maxn], vis[maxn], w[maxn];

int n, m, cnt, ans[maxn];

void add(int x,int y,int z,int zz){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
	w[e] = z;
	id[e] = zz;
}

void dfs(int h,int father,int now,int dis){
	ans[now] = max(ans[now], dis);
	for(int i = Begin[h];i ;i = Next[i]){
		int v = to[i];
		if(v == father) continue;
		
		if(!vis[id[i]]) dfs(v, h, now, dis + w[i]);
		else {
			++ cnt;
			dfs(v, h, cnt, dis + w[i]);
		}
	}
}

void bf(int r){
	cnt = 1;
	dfs(r, -1, 1, 0);

	sort(ans + 1, ans + cnt + 1);
	For(i, 1, cnt) printf("%d ", ans[i]);
	printf("\n");
	For(i, 1, cnt) ans[i] = -2000000000;
}

void Get(){
	n = read(), m = read();
	For(i, 2, n) {
		int x = read(), y = read(), z = read();
		add(x, y, z, i-1);
		add(y, x, z, i-1);
	}

	For(i, 1, n) ans[i] = -2000000000;

	while(m --){
		int r = read(), k = read();
		cnt = 0;
		For(i, 1, k){
			st[i] = read();
			vis[st[i]] = 1;
		}
		bf(r);
		For(i, 1, k) vis[st[i]] = 0;
	}
}

int main(){

	freopen("porcelain.in", "r", stdin);
	freopen("porcelain.out", "w", stdout);

	Get();

	return 0;
}
