#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;

char file[200];
int n, m, edges;
bool mark[N << 2];

inline void print(int ty, int eid) {
    if(eid <= n) 
        printf("%d %d %d %d %d\n", ty, 1, eid, 2, eid);
    else if(eid <= 2*n - 1) {
        eid -= n;
        printf("%d %d %d %d %d\n", ty, 1, eid, 1, eid + 1);
    } else {
        eid -= 2*n - 1;
        printf("%d %d %d %d %d\n", ty, 2, eid, 2, eid + 1);
    }
}

void gen(int id, int limn, int limm, bool flag) {

    srand(id * id * id);
    sprintf(file, "bridge%d.in", id);
    freopen(file, "w", stdout);

    n = limn - (rand() % 100);
    m = limm - (rand() % 100);
    edges = n * 3 - 2;

    printf("%d %d\n", n, m);

    if(flag) {
        vector<int> e;
        for(int i = 1; i <= edges; ++i) {
            e.pb(i);
        }

        random_shuffle(e.begin(), e.end());

        for(int i = 0; i < (int) e.size(); ++i) {
            print(2, e[i]);
            if(! (-- m)) break;
        }
    } else {
        for(int i = 1; i <= edges; ++i) mark[i] = true;
        for(int i = 1; i <= m; ++i) {
            int e = rand() % edges + 1;

            if(mark[e] ^= 1) {
                print(1, e);
            } else {
                print(2, e);
            }
        }
    }
}

int main() {

    /*
    gen(0, 1000, 3000, 0);
    gen(1, 1000, 3000, 0);
    gen(2, 1000, 3000, 0);
    gen(3, 1000, 3000, 0);

    gen(4, 50000, 100000, 1);
    gen(5, 50000, 100000, 1);
    gen(6, 100000, 150000, 1);
    gen(7, 100000, 200000, 1);
    gen(8, 100000, 200000, 1);
    gen(9, 100000, 200000, 1);
    gen(10, 100000, 200000, 1);
    gen(11, 100000, 200000, 1);

    gen(12, 100000, 150000, 0);
    gen(13, 100000, 150000, 0);
    gen(14, 100000, 200000, 0);
    gen(15, 100000, 200000, 0);
    gen(16, 150000, 200000, 0);
    gen(17, 150000, 200000, 0);
    gen(18, 200000, 200000, 0);
    gen(19, 200000, 200000, 0);
    */

    gen (233, 1500, 3000, 1);

    return 0;
}
