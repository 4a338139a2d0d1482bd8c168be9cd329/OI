#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 200000;

namespace SEG {
    const int SZ = N << 2;

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    int sum[SZ + 5];
    void build(int u, int l, int r) {
        if(l == r) {
            sum[u] = 0;
            return;
        }

        build(lc, l, mid);
        build(rc, mid+1, r);

        sum[u] = sum[lc] + sum[rc];
    }

    void modify(int u, int l, int r, int p, int v) {
        if(l == r) {
            sum[u] += v;
            return;
        }

        if(p <= mid) 
            modify(lc, l, mid, p, v);
        else 
            modify(rc, mid+1, r, p, v);

        sum[u] = sum[lc] + sum[rc];
    }

    inline int query(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return 0;
        if(x <= l && r <= y) return sum[u];
        return query(lc, l, mid, x, y) + query(rc, mid+1, r, x, y);
    }
}

int ans;
int n, m, T;

struct node {
    int l, r;

    node () { }
    node (int _l, int _r): l(_l), r(_r) { }

    inline bool operator < (const node& rhs) const {
        return r < rhs.r || (r == rhs.r && l > rhs.l);
    }
};

std::set<node> S;
typedef std::set<node>::iterator sit;

void input() {
    read(n);
    ans = 0;

    S.clear();
    SEG::build(1, 0, n);
    SEG::modify(1, 0, n, 0, 2);
    SEG::modify(1, 0, n, n, 2);
    for(int i = 0; i <= n; ++i) S.insert(node(i, i));
}

inline int len(sit it) {
    int x = (*it).l, y = (*it).r;
    return (y - x + 1) << 1;
}
inline int chk(sit it) {
    int x = (*it).l, y = (*it).r;
    return SEG::query(1, 0, n, x, y);
}

void solve() {
    read(m);

    while(m--) {
        static int tmp, p, q;
        static int op, x1, y1, x2, y2;
        read(op), read(x1), read(y1), read(x2), read(y2);

        if(x1 > x2) { std::swap(x1, x2); std::swap(y1, y2); }
        if(y1 > y2) { std::swap(y1, y2); std::swap(x1, x2); }

        if(y1 == y2-1) {
            sit it = S.lower_bound(node(y1, y1));
            if(it != S.end())   p = chk(std::next(it));
            if(it != S.begin()) q = chk(std::prev(it));

            if((tmp = chk(it)) > 0) ans -= len(it) - tmp;
            if(it != S.end())   ans -= p && tmp;
            if(it != S.begin()) ans -= q && tmp;

            SEG::modify(1, 0, n, y1, op == 1 ? -1 : +1);

            if((tmp = chk(it)) > 0) ans += len(it) - tmp;
            if(it != S.end()) ans += p && tmp;
            if(it != S.begin()) ans += q && tmp;
        } else {
            if(op == 1) {
                sit it = S.lower_bound(node(y1, y1));
                if(it != S.end())   p = chk(std::next(it));
                if(it != S.begin()) q = chk(std::prev(it));

                if((tmp = chk(it)) > 0) ans -= len(it) - tmp;
                if(it != S.end()) ans -= p && tmp;
                if(it != S.begin()) ans -= q && tmp;

                sit _l = S.insert(node((*it).l, y1 - 1)).fst;
                sit _r = S.insert(node(y1, (*it).r)).fst;
                S.erase(it);

                if((tmp = chk(_r)) > 0) ans += len(_r) - tmp;
                if(_r != S.end()) ans += p && tmp;
                if((tmp = chk(_l)) > 0) ans += len(_l) - tmp;
                if(_l != S.begin()) ans += q && tmp;

                ans += chk(_l) && chk(_r);
            } else {
                sit _l = S.lower_bound(node(y1-1, y1-1)), _r = S.lower_bound(node(y1, y1));

                if((tmp = chk(_r)) > 0) ans -= len(_r) - tmp;
                if(_r != S.end())   ans -= (p = chk(std::next(_r))) && tmp;
                if((tmp = chk(_l)) > 0) ans -= len(_l) - tmp;
                if(_l != S.begin()) ans -= (q = chk(std::prev(_l))) && tmp;

                ans -= chk(_l) && chk(_r);

                sit it = S.insert(node((*_l).l, (*_r).r)).fst;

                S.erase(_l);
                S.erase(_r);

                if((tmp = chk(it)) > 0) ans += len(it) - tmp;
                if(it != S.end())   ans += p && tmp;
                if(it != S.begin()) ans += q && tmp;
            }
        }
        printf("%d\n", ans);
    }
}

int main() {
    freopen("bridge233.in", "r", stdin);
    freopen("bridge233.out", "w", stdout);

    input();
    solve();
    
    return 0;
}
