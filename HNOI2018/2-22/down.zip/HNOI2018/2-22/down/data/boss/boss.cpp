#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 1000;

int T;
int a[N + 5];
int n, m, hp, mp, sp, d_hp, d_mp, d_sp, x;

int n1, b[N + 5], y[N + 5];
int n2, c[N + 5], z[N + 5];
int f[N + 5][N + 5], g[N + 5][N + 5], h[N + 5][N + 5];

void input() {
    read(n), read(m), read(hp), read(mp), read(sp);
    read(d_hp), read(d_mp), read(d_sp), read(x);

    for(int i = 1; i <= n; ++i) read(a[i]);
    read(n1); for(int i = 1; i <= n1; ++i) read(b[i]), read(y[i]);
    read(n2); for(int i = 1; i <= n2; ++i) read(c[i]), read(z[i]);
}

void calcF() {
    memset(f, oo, sizeof f);

    f[0][hp+1] = f[0][hp] = 0;
    for(int i = 1; i <= n; ++i) {
        for(int j = 1; j <= hp; ++j) if(f[i-1][j] < oo) {

            int k = std::min(j+d_hp, hp);
            if(k > a[i]) chkmin(f[i][k-a[i]], f[i-1][j] + 1);
            if(j > a[i]) chkmin(f[i][j-a[i]], f[i-1][j]);
        }
        for(int j = 1; j <= hp; ++j) chkmin(f[i][hp+1], f[i][j]);
    }
}

void calcG() {
    memset(g, ~oo, sizeof g);

    g[0][mp+1] = g[0][mp] = 0;
    for(int i = 1; i <= n; ++i) {
        for(int j = 0; j <= mp; ++j) if(g[i-1][j] >= 0) {
            for(int k = 1; k <= n1; ++k) if(j >= b[k])
                chkmax(g[i][j - b[k]], g[i-1][j] + y[k]);
            chkmax(g[i][std::min(j+d_mp, mp)], g[i-1][j]);
        }
        for(int j = 0; j <= mp; ++j) chkmax(g[i][mp+1], g[i][j]);
    }
}

void calcH() {
    memset(h, ~oo, sizeof h);

    h[0][sp+1] = h[0][sp] = 0;
    for(int i = 1; i <= n; ++i) {
        for(int j = 0; j <= sp; ++j) if(h[i-1][j] >= 0) {
            for(int k = 1; k <= n2; ++k) if(j >= c[k]) 
                chkmax(h[i][j - c[k]], h[i-1][j] + z[k]);
            chkmax(h[i][std::min(j+d_sp, sp)], h[i-1][j] + x);
        }
        for(int j = 0; j <= sp; ++j) chkmax(h[i][sp+1], h[i][j]);
    }
}

void solve() {
    
    calcF();
    calcG();
    calcH();

    static int atk[N + 5];
    memset(atk, ~oo, sizeof atk);

    for(int i = 0; i <= n; ++i) {
        for(int j = 0; j + i <= n; ++j) {
            chkmax(atk[j + i], h[j][sp + 1] + g[i][mp + 1]);
        }
    }

    for(int i = 0; i < n; ++i) {
        if(f[i][hp + 1] <= i) {
            if(atk[i - f[i][hp + 1] + 1] >= m) {
                printf("Yes %d\n", i + 1);
                return;
            }
        } else {
            puts("No");
            return;
        }
    }

    puts(f[n][hp+1] <= n ? "Tie" : "No");
}

int main() {
    // freopen("boss.in", "r", stdin);
    // freopen("boss.out", "w", stdout);

    read(T);
    while(T--) {
        input();
        solve();
    }

    return 0;
}
