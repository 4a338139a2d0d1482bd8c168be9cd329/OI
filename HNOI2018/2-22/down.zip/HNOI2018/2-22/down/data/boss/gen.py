import os, sys
from random import *

def gen (case_id, nl, nr, ml, mr, hpr, mpr, spr, n1, n2, limH):

    fname = "boss%s" % case_id
    # file = open("%s.in" % fname, "w")

    t = randint(4, 5)
    outp = "%d\n" % t

    for case in range(t):

        H1 = randint(1, limH)
        H2 = randint(1, limH)
        H3 = randint(1, limH)

        n = randint(nl, nr)
        m = randint(ml, mr)
        hp = randint(hpr // 2, hpr)
        mp = randint(mpr // 2, mpr)
        sp = randint(spr // 2, spr)
        dhp = randint(1, hp // 2)
        dmp = randint(1, mp // 2)
        dsp = randint(1, sp // 2)
        x = randint(1, H1)

        outp += "%d %d %d %d %d %d %d %d %d\n" % (n, m, hp, mp, sp, dhp, dmp, dsp, x)

        N1 = randint(1, n1)
        N2 = randint(1, n2)

        for i in range(n): 
            outp += "%d " % (randint(1, hp // 2))
        outp += "\n"

        outp += "%d " % N1
        for i in range(N1): 
            outp += "%d %d " % (randint(1, mp // 2), randint(1, H2))
        outp += "\n"

        outp += "%d " % N2
        for i in range(N2): 
            outp += "%d %d " % (randint(1, sp // 2), randint(1, H3))
        outp += "\n"

    print(outp, file = open("%s.in" % fname, "w"))
    os.system ("time ./boss < %s.in > %s.out" % (fname, fname))

# gen ("sample", 80, 100, 9000, 10000, 70, 70, 70, 5, 5, 2000)

# gen (0, 8, 10, 9000, 10000, 70, 70, 70, 1, 1, 2000)
# gen (1, 8, 10, 9000, 10000, 70, 70, 70, 1, 1, 2000)
# 
# gen (2, 80, 100, 9000, 10000, 70, 70, 70, 5, 5, 2000)
# gen (3, 80, 100, 9000, 10000, 70, 70, 70, 5, 5, 2000)
# gen (4, 80, 100, 9000, 10000, 70, 70, 70, 10, 10, 2000)
# gen (5, 80, 100, 9000, 10000, 70, 70, 70, 10, 10, 2000)
# 
# gen (6, 800, 1000, 900000, 1000000, 800, 1000, 1000, 10, 10, 10000)
# gen (7, 800, 1000, 900000, 1000000, 1000, 800, 1000, 10, 10, 10000)
# gen (8, 800, 1000, 900000, 1000000, 1000, 1000, 800, 10, 10, 10000)
# gen (9, 800, 1000, 900000, 1000000, 1000, 1000, 1000, 10, 10, 10000)
# gen (10, 800, 1000, 900000, 1000000, 800, 800, 1000, 10, 10, 10000)
# gen (11, 800, 1000, 900000, 1000000, 800, 1000, 800, 10, 10, 10000)
# gen (12, 800, 1000, 900000, 1000000, 1000, 800, 800, 10, 10, 10000)
# gen (13, 800, 1000, 900000, 1000000, 800, 800, 800, 10, 10, 10000)
# gen (14, 800, 1000, 900000, 1000000, 1000, 1000, 1000, 10, 10, 10000)

gen (15, 800, 1000, 9000, 10000, 1000, 1000, 1000, 10, 10, 100)
gen (16, 800, 1000, 9000, 10000, 1000, 1000, 1000, 10, 10, 100)
gen (17, 800, 1000, 90000, 100000, 1000, 1000, 1000, 10, 10, 1000)
gen (18, 800, 1000, 90000, 100000, 1000, 1000, 1000, 10, 10, 1000)
gen (19, 800, 1000, 900000, 1000000, 1000, 1000, 1000, 10, 10, 10000)
