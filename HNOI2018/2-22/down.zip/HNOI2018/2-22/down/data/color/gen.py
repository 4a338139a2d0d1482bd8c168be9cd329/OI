import sys, os
from random import *

def randchar(l, r):
    x = randint(0, 20)

    if(x > r): 
        return 'B'
    if(x < l):
        return 'W'

    return 'X'
    
def gen(case_id, limn, limk):

    fname = "color%s" % case_id

    n = randint(limn // 2, limn)
    k = randint(1, limk)

    outp = "%d %d\n" % (n, k)
    for i in range(n):
        if(i <= n//2):
            outp += randchar(1, 10)
        else:
            outp += randchar(10, 19)
    outp += "\n"

    print (outp, file = open("%s.in" % fname, "w"))
    os.system("time ./color < %s.in > %s.out" % (fname, fname))

# gen (0, 20)
# gen (1, 20)
# gen (2, 2000, 50)
# gen (3, 2000, 50)
# gen (4, 2000, 50)
# gen (5, 1000000, 80)
# gen (6, 1000000, 80)
# gen (7, 1000000, 100)
# gen (8, 1000000, 120)
# gen (9, 1000000, 150)

gen ("sample", 20, 4)
