#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 1000000;
const int mo = 1e9 + 7;
const int i2 = (mo + 1) / 2;

int n, k, lst;
char st[N + 5];

int sum[N + 5];
int l1[N + 5], l2[N + 5];

int s[N + 5][2];
int pw1[N + 5], pw2[N + 5];
int f[N + 5][2], g[N + 5][2];

int fpm(int x, int y) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1)
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

int main() {
    // freopen("color.in", "r", stdin);
    // freopen("color.out", "w", stdout);

    read(n), read(k);
    scanf("%s", st + 1);

    pw1[0] = pw2[0] = 1;
    for(int i = 1; i <= n; ++i) {
        pw1[i] = (pw1[i-1] << 1) % mo;
        pw2[i] = 1ll * pw2[i-1] * i2 % mo;
    }

    if(2*k > n) {
        puts("0");
        return 0;
    }

    for(int i = 1; i <= n; ++i) sum[i] = sum[i-1] + (st[i] == 'X');
    for(int i = 1; i <= n; ++i) l1[i] = (st[i] != 'W') ? l1[i-1] + 1 : 0;
    for(int i = n; i >= 1; --i) l2[i] = (st[i] != 'B') ? l2[i+1] + 1 : 0;

    lst = 0;
    f[0][1] = 1;
    s[0][1] = 1;

    for(int i = 1; i <= n; ++i) {

        int p = std::max(i - k + 1, lst);
        if(st[i] != 'W') { f[i][0] = (s[i-1][1] - (p ? s[p-1][1] : 0)) % mo; } 
        if(st[i] != 'B') { f[i][1] = (f[i-1][1] + f[i-1][0]) % mo; } 

        if(st[i] == 'W') lst = i;
        s[i][0] = (s[i-1][0] + f[i][0]) % mo;
        s[i][1] = (s[i-1][1] + f[i][1]) % mo;
    }

    lst = n+1;
    g[n+1][0] = 1;
    s[n+1][0] = 1;

    for(int i = n; i >= 1; --i) {

        int p = std::min(i + k - 1, lst);
        if(st[i] != 'B') { g[i][1] = (s[i+1][0] - s[p+1][0]) % mo; }
        if(st[i] != 'W') { g[i][0] = (g[i+1][1] + g[i+1][0]) % mo; }

        if(st[i] == 'B') lst = i;
        s[i][0] = (s[i+1][0] + g[i][0]) % mo;
        s[i][1] = (s[i+1][1] + g[i][1]) % mo;
    }

    int ans = 0, res = 0;
    for(int i = n; i >= 1; --i) {
        if(l1[i] >= k) ans = (ans + 1ll * pw2[sum[i]] * f[i-k][1] % mo * res) % mo;
        if(l2[i] >= k) res = (res + 1ll * pw1[sum[i-1]] * g[i+k][0]) % mo;
    }
    printf("%d\n", (ans % mo + mo) % mo);

    return 0;
}
