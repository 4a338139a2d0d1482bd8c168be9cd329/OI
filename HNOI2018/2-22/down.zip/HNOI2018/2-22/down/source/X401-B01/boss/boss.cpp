#include<cstdio>
#include<iostream>
#include<cstring>
#define neko 1000010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
int n,m,maxhp,maxmp,maxsp,dh,dm,ds,blade,magic,skill;
int ans=1e9,cas,flag;
typedef int arr[neko];
arr a,b,y,c,z;
void read(int &x)
{
	char c=getchar();int p=1;x=0;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0'),c=getchar();}
	x*=p;
}
void dfs(int step,int hp,int mp,int sp,int bosshp)
{
	//if(step==5)printf("%d %d %d %d %d\n",step,hp,mp,sp,bosshp);
	if(bosshp<=0)
	{
		ans=chkmin(ans,step-1);
		return;
	}
	if(hp<=0)return;
	if(step>n){flag=1;return;}
	dfs(step+1,hp-a[step],mp,(sp+ds>=maxsp)?maxsp:sp+ds,bosshp-blade);
	f(i,1,magic)if(mp>=b[i])dfs(step+1,hp-a[step],mp-b[i],sp,bosshp-y[i]);
	f(i,1,skill)if(sp>=c[i])dfs(step+1,hp-a[step],mp,sp-c[i],bosshp-z[i]);
	dfs(step+1,((hp+dh>=maxhp)?maxhp:hp+dh)-a[step],mp,sp,bosshp);
	dfs(step+1,hp-a[step],(mp+dm>=maxmp)?maxmp:mp+dm,sp,bosshp);
}
void init()
{
	
}
int main()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	read(cas);
	while(cas--)
	{
		//init();
		read(n),read(m),read(maxhp),read(maxmp),read(maxsp),read(dh),read(dm),read(ds),read(blade);
		f(i,1,n)read(a[i]);
		read(magic);f(i,1,magic)read(b[i]),read(y[i]);
		read(skill);f(i,1,skill)read(c[i]),read(z[i]);
		dfs(1,maxhp,maxmp,maxsp,m);
		if(ans<1e9)printf("Yes %d\n",ans),ans=1e9;
		else if(flag)printf("Tie\n"),flag=0;
		else printf("No\n");
	}
}
