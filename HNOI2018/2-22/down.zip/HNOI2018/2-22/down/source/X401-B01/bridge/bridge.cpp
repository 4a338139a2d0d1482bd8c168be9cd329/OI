#include<cstdio>
#include<iostream>
#include<cstring>
#define neko 400010
#define meko 1200010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
int n,m,cnt,t,ans;
typedef int arr[neko];
arr dfn,low,head;
struct node
{
	int u,v,next;
}e[meko<<1];
void read(int &x)
{
	char c=getchar();int p=1;x=0;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0'),c=getchar();}
	x*=p;
}
void add(int x,int y)
{
	e[++t].u=x;
	e[t].v=y;
	e[t].next=head[x];
	head[x]=t;
}
void dfs(int u,int fa)
{
    dfn[u]=low[u]=++cnt;
    for(register int i=head[u];i;i=e[i].next)
    {
        int v=e[i].v;
        if(!dfn[v])	 
        {
            dfs(v,u);
            low[u]=chkmin(low[u],low[v]);
            if(low[v]>dfn[u])++ans;
        }else if(v!=fa)low[u]=chkmin(low[u],dfn[v]);
    }
}
void init(int x,int y,int z,int o)
{
	int alp=(x-1)*n+y,bet=(z-1)*n+o,tt=t;
	//f(i,1,t)printf("%d %d\n",e[i].u,e[i].v);
	for(register int i=1;i<=t;i+=2)
	{
		if((e[i].u==alp&&e[i].v==bet)||(e[i].v==alp&&e[i].u==bet))
		{
			t=0;memset(head,0,sizeof(head));
			f(j,1,i-1)add(e[j].u,e[j].v);
			f(j,i,tt-2)add(e[j+2].u,e[j+2].v);
			break;
		}
	}
	//f(i,1,t)printf(" %d %d\n",e[i].u,e[i].v);
}
void clear()
{
	memset(dfn,0,sizeof(dfn));
	memset(low,0,sizeof(low));
	ans=0,cnt=0;
}
int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	int opt,x,y,z,o;
	scanf("%d%d",&n,&m);
	f(i,1,n-1)add(i,i+1),add(i+1,i),add(i,i+n),add(i+n,i);
	add(n,n*2),add(n*2,n);
	f(i,n+1,n*2-1)add(i,i+1),add(i+1,i);
	f(i,1,m)
	{
		read(opt),read(x),read(y),read(z),read(o);
		if(opt==1)add((x-1)*n+y,(z-1)*n+o),add((z-1)*n+o,(x-1)*n+y);
		else init(x,y,z,o);
		f(i,1,n*2)if(!dfn[i])dfs(i,i);
		printf("%d\n",ans);
		clear();
	}
	return 0;
}

