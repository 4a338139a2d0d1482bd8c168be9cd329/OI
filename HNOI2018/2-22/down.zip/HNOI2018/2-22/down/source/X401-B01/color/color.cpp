#include<cstdio>
#include<iostream>
#include<cstring>
#define neko 1000010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
int mod=1e9+7,flag,n,ans,realk;
char a[neko];
void dfs(int step)
{
	if(step==n)
	{
		//puts(a);
		f(i,0,n-2)
		 f(j,i+1,n-1)
		 {
		  f(k,0,realk-1)
		   if((a[i+k]!='B')||(a[j+k]!='W')){flag=1;break;}
		  if(!flag){++ans;if(ans>=mod)ans%=mod;return;}
		  else flag=0;
		 }return;
	}
	if(a[step]=='X')
	{
		a[step]='W';
		dfs(step+1);
		a[step]='B';
		dfs(step+1);
		a[step]='X';
	}
	else dfs(step+1);
}
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout); 
	scanf("%d%d",&n,&realk);
	getchar();
	scanf("%s",a);
	dfs(0),printf("%d\n",ans);
	return 0;
}
