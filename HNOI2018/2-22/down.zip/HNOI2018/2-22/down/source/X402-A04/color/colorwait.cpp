#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1000500;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
char s[N];
int n,k,num[5],ans=0;

int tt1[N*2],tt2[N*2],*G=tt1+1000050,*H=tt2+1000050;
int g[N],h[N];
int numx[N];

void wj()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
}
int main()
{
	wj();
	n=read(); k=read();
	scanf("%s",s+1);
	if(k>n/2) {printf("0\n");return 0;}
	/*dfs(1);
	printf("%d\n",ans);
	return 0;*/
	for(int i=1;i<=n;++i) 
	{
		numx[i]=numx[i-1];
		if(s[i]=='X') numx[i]++;
	}

	int sum=1,now=0;
	G[0]=1;
	for(int i=1;i<=n;++i)
	{
		g[i]=*(G+k);
		sum-=*(G+k);
		G[k]=0;
		int *nw;
		if(s[i]=='B') G=G-1,now++;
		else if(s[i]=='W') 
		{
			while(now) G[now]=0,now--;
			G[0]=sum;
		}
		else
		{
			G=G-1; now++;
			G[0]=sum;
			sum+=sum;
		}
	}
	g[n+1]=*(G+k);

	now=0; sum=1; H[0]=1;
	for(int i=n;i;--i)
	{
		h[i]=*(H+k);
		sum-=*(H+k);
		H[k]=0;
		int *nw;
		if(s[i]=='W') H=H-1,now++;
		else if(s[i]=='B') 
		{
			while(now) H[now]=0,now--;
			H[0]=sum;
		}
		else
		{
			H=H-1; now++;
			H[0]=sum;
			sum+=sum;
		}
	}
	h[0]=*(H+k);

	for(int i=1;i<=n&&i+k-1<=n;++i) for(int j=i+k;j<=n&&j+k-1<=n;++j)
	{
		//cerr<<i<<' '<<j<<' '
		//<<1ll*g[i+k][k]*h[j-1][k]%mod*qpow(2,numx[j-1]-numx[i+k-1])%mod<<endl;
		ans=(ans+1ll*g[i+k]*h[j-1]%mod*qpow(2,numx[j-1]-numx[i+k-1]))%mod;
	}
	printf("%d\n",ans);
	return 0;
}
