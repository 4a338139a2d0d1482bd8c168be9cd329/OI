#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=2050;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
char s[N];
int n,k,num[5],ans=0;

void dfs(int r)
{
	if(r==n+1)
	{
		num[0]=0; num[1]=0;
		for(int i=1;i<=k;++i)
		{
			if(s[i]=='B') num[0]++;
			else if(s[i]=='W') num[1]++;
		}
		int L=inf,R=-inf;
		if(!num[1]) L=1;
		else if(!num[0]) R=1;
		for(int i=k+1;i<=n;++i)
		{
			if(s[i]=='B') num[0]++;
			else if(s[i]=='W') num[1]++;
			if(s[i-k]=='B') num[0]--;
			else if(s[i-k]=='W') num[1]--;
			if(!num[1]) L=min(L,i);
			else if(!num[0]) R=max(R,i);
		}
		if(L<R) ans++;
		return ;
	}
	if(s[r]=='B') {dfs(r+1);return ;}
	if(s[r]=='W') {dfs(r+1);return ;}
	s[r]='B';
	dfs(r+1);
	s[r]='W';
	dfs(r+1);
	s[r]='X';
}

int g[N][N],h[N][N];
int numx[N];

void wj()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
}
int main()
{
	wj();
	n=read(); k=read();
	scanf("%s",s+1);
	if(k>n/2) {printf("0\n");return 0;}
	/*dfs(1);
	printf("%d\n",ans);
	return 0;*/
	for(int i=1;i<=n;++i) 
	{
		numx[i]=numx[i-1];
		if(s[i]=='X') numx[i]++;
	}

	g[1][0]=1;
	for(int i=1;i<=n;++i) for(int j=0;j<i&&j<k;++j)
	{
		if(s[i]=='B') g[i+1][j+1]=(g[i+1][j+1]+g[i][j])%mod;
		else if(s[i]=='W') g[i+1][0]=(g[i+1][0]+g[i][j])%mod;
		else 
		{
			g[i+1][j+1]=(g[i+1][j+1]+g[i][j])%mod;
			g[i+1][0]=(g[i+1][0]+g[i][j])%mod;
		}
	}
	h[n][0]=1;
	for(int i=n;i;--i) for(int j=0;j<k&&j<=n-i;++j)
	{
		if(s[i]=='W') h[i-1][j+1]=(h[i-1][j+1]+h[i][j])%mod;
		else if(s[i]=='B') h[i-1][0]=(h[i-1][0]+h[i][j])%mod;
		else
		{
			h[i-1][j+1]=(h[i-1][j+1]+h[i][j])%mod;
			h[i-1][0]=(h[i-1][0]+h[i][j])%mod;
		}
	}
	for(int i=1;i<=n&&i+k-1<=n;++i) for(int j=i+k;j<=n&&j+k-1<=n;++j)
	{
		//cerr<<i<<' '<<j<<' '
		//<<1ll*g[i+k][k]*h[j-1][k]%mod*qpow(2,numx[j-1]-numx[i+k-1])%mod<<endl;
		ans=(ans+1ll*g[i+k][k]*h[j-1][k]%mod*qpow(2,numx[j-1]-numx[i+k-1]))%mod;
	}
	printf("%d\n",ans);
	return 0;
}
