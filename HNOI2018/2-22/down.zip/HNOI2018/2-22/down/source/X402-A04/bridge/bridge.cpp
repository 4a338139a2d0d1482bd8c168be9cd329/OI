#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=6050;
int head[N],cnt=1;
struct node
{
	int to,next;
}e[N*6];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
bool ban[N*6];
int n,id[4][N];
int dfn[N],clk=0,low[N],ans=0;

void dfs(int u,int pre)
{
	dfn[u]=low[u]=++clk;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(i==(pre^1)||ban[i]) continue;
		if(!dfn[v])
		{
			dfs(v,i);
			low[u]=min(low[v],low[u]);
			if(low[v]>dfn[u]) ans++;
		}
		else low[u]=min(low[u],dfn[v]);
	}
}

void wj()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
}
int main()
{
	wj();
	n=read(); int T=read();
	for(int i=1;i<=n;++i) id[1][i]=i,id[2][i]=n+i;
	for(int i=1;i<n;++i) add(i,i+1);
	for(int i=n+1;i<n+n;++i) add(i,i+1);//2*n-2
	for(int i=1;i<=n;++i) add(i,i+n);

	for(int cas=1;cas<=T;++cas)
	{
		int opt=read();
		int x=id[read()][read()],y=id[read()][read()];
		if(x>y) swap(x,y);
		opt--;
		if(y==x+1)
		{
			if(x>n) x--;
			ban[x<<1]=opt; ban[x<<1|1]=opt;
		}
		else x=2*n-2+x,ban[x<<1]=opt,ban[x<<1|1]=opt;

		for(int i=1;i<=n+n;++i) dfn[i]=0;
		clk=0; ans=0;
		for(int i=1;i<=n+n;++i) if(!dfn[i]) dfs(i,0);
		printf("%d\n",ans);
	}
	return 0;
}
