#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=105;
const int M=75;
int f[N][M][M][M];
int n,m,hp,mp,sp,dhp,dmp,dsp,X;
int A[N];
pii magic[N],spec[N];

void wj()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
}
int main()
{
	wj();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		n=read(); m=read(); hp=read(); mp=read(); sp=read();
		dhp=read(); dmp=read(); dsp=read(); X=read();
		for(int i=1;i<=n;++i) A[i]=read();
		int n1=read();
		for(int i=1;i<=n1;++i) magic[i].fi=read(),magic[i].se=read();
		int n2=read();
		for(int i=1;i<=n2;++i) spec[i].fi=read(),spec[i].se=read();

		int now=hp;
		for(int i=1;i<=n;++i) 
		{
			now=min(now+dhp,hp); now-=A[i];
			if(now<=0) {now=-1;break;}
		}
		if(now==-1) {puts("No");continue;}

		for(int i=1;i<=n;++i) for(int j=1;j<=hp;++j) 
		for(int k=0;k<=mp;++k) for(int l=0;l<=sp;++l) f[i][j][k][l]=-1;
		f[1][hp][mp][sp]=0;
		int ans=0;
		for(int i=1;i<=n&&!ans;++i) for(int j=1;j<=hp&&!ans;++j) 
		for(int k=0;k<=mp&&!ans;++k) for(int l=0;l<=sp&&!ans;++l)
		{
			int x=f[i][j][k][l];
			if(x==-1) continue;
			if(x+X>=m) {ans=i;break;}
			if(j-A[i]>0) 
			{
				f[i+1][j-A[i]][k][min(sp,l+dsp)]
				=max(f[i+1][j-A[i]][k][min(sp,l+dsp)],x+X);
				
				f[i+1][j-A[i]][min(mp,k+dmp)][l]=
				max(f[i+1][j-A[i]][min(mp,k+dmp)][l],x);
			}
			for(int o=1;o<=n1;++o) if(k>=magic[o].fi)
			{
				if(x+magic[o].se>=m) {ans=i;break;}
				if(j>A[i]) f[i+1][j-A[i]][k-magic[o].fi][l]
				=max(f[i+1][j-A[i]][k-magic[o].fi][l],x+magic[o].se);
			}
			for(int o=1;o<=n2;++o) if(l>=spec[o].fi)
			{
				if(x+spec[o].se>=m) {ans=i;break;}
				if(j>A[i]) f[i+1][j-A[i]][k][l-spec[o].fi]
				=max(f[i+1][j-A[i]][k][l-spec[o].fi],x+spec[o].se);
			}
			if(min(hp,j+dhp)-A[i]>0) f[i+1][min(hp,j+dhp)-A[i]][k][l]
			=max(f[i+1][min(hp,j+dhp)-A[i]][k][l],x);
		}
		if(ans) printf("Yes %d\n",ans);
		else puts("Tie");
	}
	return 0;
}
