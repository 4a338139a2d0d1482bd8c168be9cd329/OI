﻿#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 5e5, maxm = maxn*12 ;
struct Edge {
	int op, u, v ;
} E[maxn] ;
int n, m, e = 1, Begin[maxn], To[maxm], Next[maxm] ;
bool W[maxm], iscut[maxm], vis[maxm] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
	W[e] = 1 ;
}
void create() {
	for ( int i = 1 ; i ^ n ; i ++ ) {
		add(i, i+1), add(i+1, i) ;
		add(i, i+n), add(i+n, i) ;
		add(i+n, i+1+n), add(i+1+n, i+n) ;
	}
	add(n, n<<1), add(n<<1, n) ;
}
int dfn[maxn], clk ;
int dfs ( int x ) {
	dfn[x] = ++clk ;
	//printf ( "dfn[%d]=%d\n", x, dfn[x] ) ;
	int i, u, pre = clk, t ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		if (!W[i] || vis[i]) continue ;
		u = To[i] ;
		if (!dfn[u]) {
			vis[i] = vis[i ^ 1] = 1 ;
			t = dfs(u) ;
			if (t >= dfn[u]) iscut[i] = iscut[i ^ 1] = 1 ;
			else iscut[i] = iscut[i ^ 1] = 0 ;
			pre = min(pre, t) ;
		} else pre = min(pre, dfn[u]) ;
	}
	//printf ( "pre[%d]=%d\n", x, pre ) ;
	return pre ;
}
int calculate() {
	int i, t = 0 ;
	for ( i = n<<1 ; i ; i -- )
		dfn[i] = 0 ;
	clk = 0 ;
	for ( i = 1 ; i <= e ; i ++ )
		iscut[i] = vis[i] = 0 ;
	for ( i = 1 ; i <= n ; i ++ ) {
		if (!dfn[i]) dfs(i) ;
		if (!dfn[i+n]) dfs(i+n) ;
	}
	for ( i = 2 ; i <= e ; i += 2 )
		if (W[i] && iscut[i]) ++ t ;
	return t ;
}
void Force() {
	create() ;
	int i, j, u, v ;
	for ( i = 1 ; i <= m ; i ++ ) {
		u = E[i].u, v = E[i].v ;
		for ( j = Begin[u] ; j ; j = Next[j] )
			if (To[j] == v) {
				W[j] = W[j ^ 1] = E[i].op&1 ;
				break ;
			}
		printf ( "%d\n", calculate() ) ;
	}
}
int main() {
	//Force
	freopen ( "bridge.in", "r", stdin ) ;
	freopen ( "bridge.out", "w", stdout ) ;
	Read(n), Read(m) ;
	int i, u, v ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(E[i].op), Read(u), Read(v) ;
		E[i].u = (u-1)*n + v ;
		Read(u), Read(v) ;
		E[i].v = (u-1)*n + v ;
		if (E[i].u < E[i].v) swap(u, v) ;
	}
	Force() ;
	return 0 ;
}
