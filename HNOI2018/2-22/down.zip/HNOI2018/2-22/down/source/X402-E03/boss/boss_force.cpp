#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 12, maxm = 1e4+5, maxp = 75 ;
int n, m, hp, mp, sp, dsp, dmp, dhp, X ;
int ewin, n1, B[maxn], Y[maxn], n2, C[maxn], Z[maxn], A[maxn] ;
bool alose ;
void dfs ( int stp, int HP, int MP, int SP, int M ) {
	HP = min(HP, hp), MP = min(MP, mp), SP = min(SP, sp) ;
	if (stp >= ewin) return ;
	if (M <= 0) {
		ewin = stp-1 ;
		return ;
	}
	if (HP <= 0) return ;
	if (stp > n) {
		alose = 0 ;
		return ;
	}
	HP -= A[stp] ;
	dfs(stp+1, HP, MP, SP+dsp, M-X) ;
	for ( int i = 1 ; i <= n1 ; i ++ )
		if (MP >= B[i]) dfs(stp+1, HP, MP-B[i], SP, M-Y[i]) ;
	for ( int i = 1 ; i <= n2 ; i ++ )
		if (SP >= B[i]) dfs(stp+1, HP, MP, SP-C[i], M-Z[i]) ;
	dfs(stp+1, HP+dhp, MP, SP, M) ;
	dfs(stp+1, HP, MP+dmp, SP, M) ;
}
int main() {
	//Force
	freopen ( "boss.in", "r", stdin ) ;
	freopen ( "boss.out", "w", stdout ) ;
	int _, i ;
	Read(_) ;
	while (_--) {
		Read(n), Read(m) ;
		Read(hp), Read(mp), Read(sp) ;
		Read(dhp), Read(dmp), Read(dsp) ;
		Read(X) ;
		for ( i = 1 ; i <= n ; i ++ )
			Read(A[i]) ;
		Read(n1) ;
		for ( i = 1 ; i <= n1 ; i ++ )
			Read(B[i]), Read(Y[i]) ;
		Read(n2) ;
		for ( i = 1 ; i <= n2 ; i++ )
			Read(C[i]), Read(Z[i]) ;
		ewin = n+2 ;
		alose = 1 ;
		dfs(1, hp, mp, sp, m) ;
		if (ewin <= n) {
			printf ( "Yes %d\n", ewin ) ;
		} else if (alose) puts("No") ;
		else puts("Tie") ;
	}
	return 0 ;
}
