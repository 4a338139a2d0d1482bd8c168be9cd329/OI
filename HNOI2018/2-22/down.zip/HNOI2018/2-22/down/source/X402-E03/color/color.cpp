#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const int maxn = 4005, Mod = 1000000007 ;
int n, m, f[maxn][maxn][2][2] ;
int dp[maxn][maxn] ;
char s[maxn] ;
int main() {
	freopen ( "color.in", "r", stdin ) ;
	freopen ( "color.out", "w", stdout ) ;
	scanf ( "%d%d", &n, &m ) ;
	scanf ( "%s", s+1 ) ;
	int i, j, ans = 0 ;
	f[0][0][0][0] = 1 ;
	for ( i = 1 ; i <= n ; i ++ ) {
		for ( j = 0 ; j <= n ; j ++ ) {
			if (s[i] == 'W' || s[i] == 'X') {
				(f[i][0][0][0] += (f[i - 1][j][0][0] + f[i - 1][j][1][0])%Mod) %= Mod ;
				(f[i][j + 1][0][1] += (f[i - 1][j][0][1] + f[i - 1][j][1][1])%Mod) %= Mod ;
			}
			if (s[i] == 'B' || s[i] == 'X') {
				(f[i][j + 1][1][0] += (f[i - 1][j][0][0] + f[i - 1][j][1][0])%Mod) %= Mod ;
				(f[i][0][1][1] += (f[i - 1][j][0][1] + f[i - 1][j][1][1])%Mod) %= Mod ;
			}
		}
		(f[i][0][1][1] += f[i][m][1][0]) %= Mod ;
		f[i][m][1][0] = 0 ;
	}

	dp[n+1][0] = 1 ;
	for ( i = n ; i ; i -- )
		for ( j = 0 ; j <= m ; j ++ ) {
			if (s[i] == 'W' || s[i] == 'X')
				(dp[i][j + 1] += dp[i + 1][j]) %= Mod ;
			if (s[i] == 'B' || s[i] == 'X')
				(dp[i][0] += dp[i + 1][j]) %= Mod ;
		}
	for ( i = 0 ; i <= n+1 ; i ++ )
		for ( j = 1 ; j <= m ; j ++ )
			(dp[i][j] += dp[i][j - 1]) %= Mod ;
	for ( i = 1 ; i <= n ; i ++ )
		(ans += (LL)f[i][m][0][1]*dp[i+1][m-1]%Mod) %= Mod ;
	cout << ans << endl ;
	return 0 ;
}
