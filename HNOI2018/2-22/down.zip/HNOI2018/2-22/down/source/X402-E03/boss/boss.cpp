#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 105, maxp = 105, inf = 0x3f3f3f3f ;
int n, m, f[2][maxp][maxp][maxp] ;
int HP, MP, SP, DHP, DMP, DSP, X, n1, n2 ;
int A[maxn], B[maxn], C[maxn], Y[maxn], Z[maxn] ;
void chk ( int &a, int b ) { a = a<b? a:b ; }
void solve() {
	int i, j, hp, mp, sp, c ;
	bool t = 0 ;
	memset (f, inf, sizeof f) ;
	f[0][HP][MP][SP] = m ;
	for ( i = 1 ; i <= n ; i ++ ) {
		t ^= 1 ;
		memset (f[t], inf, sizeof f[t]) ;
		for ( hp = 1 ; hp <= HP ; hp ++ )
		for ( mp = 0 ; mp <= MP ; mp ++ )
		for ( sp = 0 ; sp <= SP ; sp ++ )
			if ((c = f[t ^ 1][hp][mp][sp]) ^ inf) {
				if (c <= X) {
					printf ( "Yes %d\n", i ) ;
					return ;
				}
				if (hp > A[i]) chk(f[t][hp - A[i]][mp][min(SP, sp+DSP)], c-X) ;
				for ( j = 1 ; j <= n1 ; j ++ )
					if (mp >= B[j]) {
						if (c <= Y[j]) {
							printf ( "Yes %d\n", i ) ;
							return ;
						}
						if (hp > A[i]) chk(f[t][hp - A[i]][mp - B[j]][sp], c-Y[j]) ;
					}
				for ( j = 1 ; j <= n2 ; j ++ )
					if (sp >= C[j]) {
						if (c <= Z[j]) {
							printf ( "Yes %d\n", i ) ;
							return ;
						}
						if (hp > A[i]) chk(f[t][hp - A[i]][mp][sp - C[j]], c-Z[j]) ;
					}
				if (min(hp+DHP, HP)-A[i] > 0) chk(f[t][min(hp+DHP, HP)-A[i]][mp][sp], c) ;
				if (hp-A[i] > 0) chk(f[t][hp-A[i]][min(mp+DMP, MP)][sp], c) ;
			}
	}
	bool tie = 0 ;
	for ( hp = 1 ; hp <= HP ; hp ++ )
	for ( mp = 0 ; mp <= MP ; mp ++ )
	for ( sp = 0 ; sp <= SP ; sp ++ )
		if (f[t][hp][mp][sp] ^ inf) {
			tie = 1 ;
			break ;
		}
	if (tie) puts("Tie") ;
	else puts("No") ;
}
int main() {
	freopen ( "boss.in", "r", stdin ) ;
	freopen ( "boss.out", "w", stdout ) ;
	int _, i ;
	Read(_) ;
	while (_--) {
		Read(n), Read(m), Read(HP), Read(MP), Read(SP) ;
		Read(DHP), Read(DMP), Read(DSP), Read(X) ;
		for ( i = 1 ; i <= n ; i ++ )
			Read(A[i]) ;
		Read(n1) ;
		for ( i = 1 ; i <= n1 ; i ++ )
			Read(B[i]), Read(Y[i]) ;
		Read(n2) ;
		for ( i = 1 ; i <= n2 ; i ++ )
			Read(C[i]), Read(Z[i]) ;
		solve() ;
	}
	return 0 ;
}
