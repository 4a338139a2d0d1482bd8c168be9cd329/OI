#include <bits/stdc++.h>

typedef std::pair<int, int> Pii;
#define fst first
#define snd second
#define read(x) scanf("%d", &x)

template <typename T> bool chkmax(T &a, T b) { return a < b? a = b, 1 : 0; }
/*template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		c = getchar();
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}*/

const int N = 100;
const int C = 70;

int D[N + 5];
int n, m;
int HP, MP, SP, Dhp, Dmp, Dsp, A;
int dp[N + 5][C + 5][C + 5][C + 5];

Pii M[N + 5];
Pii S[N + 5];
int N1, N2;

int main()
{
	freopen("boss.in", "r", stdin);
	freopen("boss.out", "w", stdout);

	int T; read(T);
	for(int cases = 1; cases <= T; ++cases)
	{
		read(n), read(m);
		read(HP), read(MP), read(SP);
		read(Dhp), read(Dmp), read(Dsp);
		read(A);

		for(int i = 1; i <= n; ++i) read(D[i]);

		scanf("%d", &N1);
		for(int i = 1; i <= N1; ++i){
			read(M[i].fst);
			read(M[i].snd);
		}
		std::sort(M + 1, M + N1 + 1);

		scanf("%d", &N2);
		for(int i = 1; i <= N2; ++i){
			read(S[i].fst);
			read(S[i].snd);
		}
		std::sort(S + 1, S + N2 + 1);

		bool die = true;

		memset(dp, -1, sizeof dp);
		dp[0][HP][MP][SP] = 0;
		for(int i = 0; i <= n; ++i){
			for(int hp = 1; hp <= HP; ++hp)
				for(int mp = 0; mp <= MP; ++mp)
					for(int sp = 0; sp <= SP; ++sp)if(dp[i][hp][mp][sp] >= 0){
						int &now = dp[i][hp][mp][sp];
						if(now >= m){
							printf("Yes %d\n", i);
							goto hehe;
						}
						if(i == n){
							die = false;
							continue;
						}
						if(now + A >= m){
							printf("Yes %d\n", i + 1);
							goto hehe;
						}
						for(int j = 1; j <= N1; ++j){
							if(mp < M[j].fst) break;
							if(hp > D[i + 1])
								chkmax(dp[i + 1][hp-D[i + 1]][mp-M[j].fst][sp], now + M[j].snd);
							if(now + M[j].snd >= m){
								printf("Yes %d\n", i + 1);
								goto hehe;
							}
						}
						for(int j = 1; j <= N2; ++j){
							if(sp < S[j].fst) break;
							if(hp > D[i + 1])
								chkmax(dp[i + 1][hp-D[i + 1]][mp][sp-S[j].fst], now + S[j].snd);
							if(now + S[j].snd >= m){
								printf("Yes %d\n", i + 1);
								goto hehe;
							}
						}


						if(hp > D[i + 1]){
							chkmax(dp[i + 1][hp-D[i + 1]][mp][std::min(sp + Dsp, SP)], now + A);
							chkmax(dp[i + 1][hp-D[i + 1]][std::min(mp + Dmp, MP)][sp], now);
						}
						if(std::min(hp + Dhp, HP) > D[i + 1]){
							chkmax(dp[i + 1][std::min(hp + Dhp, HP) - D[i + 1]][mp][sp], now);
						}
					}
		}
		puts(die? "No" : "Tie");
		hehe:;
	}
//	std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;

	return 0;
}
//caonimade shabi kuaidu
