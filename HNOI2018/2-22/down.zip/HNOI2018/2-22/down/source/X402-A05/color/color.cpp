#include <bits/stdc++.h>

const int N = 2000;

char s[N + 5];
int ans, n, k;

void DFS_calc(int u)
{
	if(u > n){
		for(int i = 1; i <= n; ++i){
			if(s[i] != 'B') continue;
			for(int j = i + k; j <= n; ++j){
				if(s[j] != 'W') continue;
				int len = 0;
				while(j + len <= n && s[i + len] == s[i] && s[j] == s[j + len])
					len ++;
				if(len >= k){
					ans ++; return ;
				}
			}
		}
		return ;
	}
	if(s[u] == 'X'){
		s[u] = 'W';
		DFS_calc(u + 1);
		s[u] = 'B';
		DFS_calc(u + 1);
		s[u] = 'X';
		return ;
	}
	DFS_calc(u + 1);
}

//int dp[N + 5][N + 5][2][2];

int main()
{
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);

	scanf("%d%d", &n, &k);
	scanf("%s", s + 1);
	if(n <= 20){
		DFS_calc(1);
		printf("%d\n", ans);
	}else
	{
		puts("0");
	}

	return 0;
}
