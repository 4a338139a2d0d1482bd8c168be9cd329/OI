#include <bits/stdc++.h>

template <typename T> bool chkmin(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 400000;
const int M = 3 * N;

int n, m;

inline int Id(int &u0, int &v0, int &u1, int &v1)
{
	if(u0 > u1 || v0 > v1){
		std::swap(u0, u1);
		std::swap(v0, v1);
	}
	if(u0 == u1)
		return (u0-1) * (n-1) + v0;
	else
		return 2 * (n-1) + v0;
}

int e, Begin[N + 5];
struct Edge
{
	int to, next;
	Edge(int to = 0, int next = 0) : to(to), next(next) {}
}E[M + 5];

void add_edge(int u, int v)
{
	E[++e] = Edge(v, Begin[u]), Begin[u] = e;
	E[++e] = Edge(u, Begin[v]), Begin[v] = e;
}

int dfs_clock;
int dfn[N + 5], low[N + 5];

bool del[M + 5];
bool is_bridge[M + 5];
int bridge_cnt;

void DFS_calc(int u, int fa)
{
	low[u] = dfn[u] = ++dfs_clock;

	for(int i = Begin[u]; i; i = E[i].next){
		if(del[i]) continue;

		int v = E[i].to;
		if(!dfn[v]){
			DFS_calc(v, u);
			chkmin(low[u], low[v]);
		}else if(v != fa){
			chkmin(low[u], low[v]);
		}

		if(low[v] > dfn[u]){
			bridge_cnt ++;
			is_bridge[i] = true;
		}
	}
}

void bfer()
{
	for(int q = 1; q <= m; ++q){
		int ty, u0, v0, u1, v1;
		read(ty), read(u0), read(v0), read(u1), read(v1);

		int id = Id(u0, v0, u1, v1);
		del[id<<1] = del[(id<<1)-1] = !(ty & 1);

		bridge_cnt = 0;
		dfs_clock = 0;
		for(int i = 1; i <= n*2; ++i){
			dfn[i] = low[i] = 0;
		}
		for(int i = 1; i <= n*2; ++i)
			if(!dfn[i]) DFS_calc(i, 0);

		printf("%d\n", bridge_cnt);
	}
}

/*struct SegmentTree
{
#define mid ((l + r) >> 1)
#define lc (h << 1)
#define rc (lc | 1)

	SegmentTree()
	{
		memset(tag, -1, sizeof tag);
		memset(sum,  0, sizeof sum);
	}

	int tag[(N << 2) + 5];
	int sum[(N << 2) + 5];

	void push_down(int h, int l, int r)
	{
		if(tag[h] != -1){
			sum[lc] = (mid - l + 1) * tag[h];
			sum[rc] = (r - mid) * tag[h];
			tag[lc] = tag[rc] = tag[h];
			tag[h] = -1;
		}
	}

	void Insert(int h, int l, int r, int p, int v)
	{
		if(l == r) sum[h] = v;
		else
		{
			push_down(h, l, r);
			u <= mid? Insert(lc, l, mid, p, v) : Insert(rc, mid + 1, r, p, v);
			sum[h] = sum[lc] + sum[rc];
		}
	}

	void Modify(int h, int l, int r, int ql, int qr, int v)
	{
		if(ql <= l && r <= qr){
			sum[h] = v * (r - l + 1);
			tag[h] = v;
		}else
		{
			push_down(h, l, r);
			if(ql <= mid) modify(lc, l, mid, ql, qr, v);
			if(qr > mid) modify(rc, mid + 1, r, ql, qr, v);
		}
	}

	int find_nxt(int h, int l, int r, int p)
	{
		if(!cnt[h]) return 0;
		if(l == r) return l;
		if(p < mid && cnt[lc]){
			int tmp = find_nxt(lc, l, mid, p);
			if(tmp) return tmp;
		}
		return find_nxt(rc, mid + 1, r, p);
	}

	int find_pre(int h, int l, int r, int p)
	{
		if(!cnt[h]) return 0;
		if(l == r) return l;
		if(p > mid + 1 && cnt[rc]){
			int tmp = find_pre(rc, mid + 1, r, p);
			if(tmp) return tmp;
		}
		return find_pre(lc, l, mid, p);
	}

	int query(int h, int l, int r, int ql, int qr)
	{
		if(ql <= l && r <= qr) return sum[h];
		else
		{
			push_down(h, l, r);
			return (ql <= mid? query(lc, l, mid, ql, qr) : 0) +
				(qr > mid? query(rc, mid + 1, r, ql, qr) : 0);
		}
	}

#undef lc
#undef rc
#undef mid
}R[2], C;

struct Ask
{
	int u0, v0, u1, v1, id;
	Ask(int u0 = 0, int v0 = 0, int u1 = 0, int v1 = 0, int id = 0)
		: u0(u0), v0(v0), u1(u1), v1(v1), id(id) {}
}q[N + 5];

int fa[N + 5];
int find(int x)
{
	return fa[x] = fa[x] == x? x : find(fa[x]);
}
void merge(int u, int v)
{
	int a = find(u), b = find(v);
	if(a == b) return false;
	return fa[b] = a, true;
}*/

void Offline()
{
/*	for(int i = 1; i <= n<<1; ++i) 
		fa[i] = i;
	for(int i = 1; i <= m; ++i){
		int ty, u0, v0, u1, v1;
		read(ty), read(u0), read(v0), read(u1), read(v1);

		int id = Id(u0, v0, u1, v1);
		q[i] = Ask(u0, v1, u1, v1, id);
		del[id*2] = del[id*2-1] = true;
	}

	DFS_calc(1, 0);
	for(int i = 1; i <= 2*(n-1); ++i){
		int ty = i >= n;
		if(is_bridge[i * 2] | is_bridge[i * 2 - 1])
			R[ty].Insert(1, 1, n, i, 1);
		if(!del[i * 2])
			merge(i + ty, i + ty + 1);
	}
	for(int i = 1; i <= n; ++i){
		if(!del[(2*n-2 + i) * 2]){
			C.Insert(1, 1, n, i, 1);
			merge(i, i + n);
		}
	}

	std::stack<int> S;
	for(int i = m; i >= 1; --i){
		S.push(bridge_cnt);
		if(q[i].id > 2*n-2){
		}
	}
	*/
}

bool Init()
{
	read(n); read(m);
	for(int i = 1; i < n; ++i){
		add_edge(i, i + 1);
	}
	for(int i = 1; i < n; ++i){
		add_edge(i + n, i + n + 1);
	}
	for(int i = 1; i <= n; ++i){
		add_edge(i, i + n);
	}

	return n <= 3000;
}

int main()
{
	freopen("bridge.in", "r", stdin);
	freopen("bridge.out", "w", stdout);

	Init();
	bfer();
	//else 
	//	Offline();

	return 0;
}
