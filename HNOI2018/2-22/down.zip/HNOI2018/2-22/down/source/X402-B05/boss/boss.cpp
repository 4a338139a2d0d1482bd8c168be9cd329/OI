#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
int T;
const int maxn=1010;
const int maxn1=15;
int n,m,hp,mp,sp,dhp,dmp,dsp,X;
int a[maxn],n1,n2;
struct node
{
	int b,y;
} b[maxn1],c[maxn1];
bool cmp(node bb,node cc)
{
	return bb.b<cc.b;
}
int dp[2][110][110][110];
int ans;
void work1()
{
	memset(dp[0],0x3f3f3f3f,sizeof(dp[0]));
	int inf=dp[0][0][0][0];
	dp[0][hp][mp][sp]=m;
	int x,y,z,cur=0;
	sort(b+1,b+n1+1,cmp);
	sort(c+1,c+n2+1,cmp);
	for (int i=0;i<n;i++)
	{
		bool flag=false,f2=false;
		cur^=1;
		memset(dp[cur],0x3f3f3f3f,sizeof(dp[cur]));
		for (int j=1;j<=hp;j++)
		{
			for (int k=0;k<=mp;k++)
			{
				for (int l=0;l<=sp;l++)
				{
					if (dp[cur^1][j][k][l]!=inf) f2=true;
					//1
					x=j-a[i+1];
					y=k;
					z=l+dsp;
					z=min(z,sp);
					if (dp[cur^1][j][k][l]-X<=0&&dp[cur^1][j][k][l]!=inf)
					{
//						printf("dp:%d 1 %d %d %d %d\n",dp[cur^1][j][k][l],i,j,k,l);
						flag=true;
						break;
					}
					if (x>0&&dp[cur^1][j][k][l]!=inf)
						qmin(dp[cur][x][y][z],dp[cur^1][j][k][l]-X);
					//2
					for (int I=1;I<=n1;I++)
					{
						y=k-b[I].b;
						z=l;
						if (y<0) break;

						if (dp[cur^1][j][k][l]-b[I].y<=0&&dp[cur^1][j][k][l]!=inf)
						{
//							printf("2 %d %d %d %d\n",i,j,k,l);
							flag=true;break;
						}
						if (x>0&&dp[cur^1][j][k][l]!=inf)
							qmin(dp[cur][x][y][z],dp[cur^1][j][k][l]-c[I].y);

					}
					if (flag) break;
					//3
					for (int I=1;I<=n2;I++)
					{
						y=k;
						z=l-c[I].b;
						if (z<0) break;
				
						if (dp[cur^1][j][k][l]-c[I].y<=0&&dp[cur^1][j][k][l]!=inf)
						{
//							printf("3 %d %d %d %d\n",i,j,k,l);
							flag=true;break;
						}
						if (x>0&&dp[cur^1][j][k][l]!=inf)
							qmin(dp[cur][x][y][z],dp[cur^1][j][k][l]-c[I].y);

					}
					//4
					x=min(hp,j+dhp)-a[i+1];
					y=k;
					z=l;
					if (x>0&&dp[cur^1][j][k][l]!=inf)
						qmin(dp[cur][x][y][z],dp[cur^1][j][k][l]);
					//5
					x=j-a[i+1];
					y=min(j+dmp,mp);
					z=l;
					if (x>0&&dp[cur^1][j][k][l]!=inf)
						qmin(dp[cur][x][y][z],dp[cur^1][j][k][l]);
				}
				if (flag) break;
			}
			if (flag) break;
		}
		if (flag)
		{
			printf("Yes %d\n",i+1);
			return;
		}
		if (!f2)
		{
			printf("No\n");
			return;
		}
	}
	printf("Tie\n");
}
int main()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	T=read();
	while (T--)
	{
		n=read();m=read();
		hp=read();mp=read();sp=read();
		dhp=read();dmp=read();dsp=read();
		X=read();
		for (int i=1;i<=n;i++) a[i]=read();
		n1=read();
		for (int i=1;i<=n1;i++) 
		{
			b[i].b=read();
			b[i].y=read();
		}
		n2=read();
		for (int i=1;i<=n2;i++)
		{
			c[i].b=read();
			c[i].y=read();
		}
	//	if (n<=100&&m<=10000&&hp<=70&&mp<=70&&sp<=70)
		{
			work1();
			continue;
		}
	}
	return 0;
}
