#include<bits/stdc++.h>
#define ll long long
using namespace std;
int qmax(int &x,int y) {if (x<y) x=y;}
int qmin(int &x,int y) {if (x>y) x=y;}
int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[20];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	if (x<0) putchar('-'),x=-x;
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=200100;
int n,m;
int g[3][maxn];
int fa[2][maxn][2],dfs_time;
int dfn[2][maxn],low[2][maxn];
void dfs(int x,int y)
{
	dfn[x][y]=low[x][y]=++dfs_time;
	int xx,yy;
	if (!g[2][y])
	{
		xx=1-x,yy=y;
		if (!dfn[xx][yy])
		{
			fa[xx][yy][0]=x;
			fa[xx][yy][1]=y;
			dfs(xx,yy);
			qmin(low[x][y],low[xx][yy]);
		} else if (!(xx==fa[x][y][0]&&yy==fa[x][y][1]))
		{
			qmin(low[x][y],dfn[xx][yy]);
		}
	}
	if (!g[x][y])
	{
		xx=x,yy=y+1;
		if (!dfn[xx][yy])
		{
			fa[xx][yy][0]=x;
			fa[xx][yy][1]=y;
			dfs(xx,yy);
			qmin(low[x][y],low[xx][yy]);
		} else if (!(xx==fa[x][y][0]&&yy==fa[x][y][1]))
		{
			qmin(low[x][y],dfn[xx][yy]);
		}
	}
	if (!g[x][y-1])
	{
		xx=x,yy=y-1;
		if (!dfn[xx][yy])
		{
			fa[xx][yy][0]=x;
			fa[xx][yy][1]=y;
			dfs(xx,yy);
			qmin(low[x][y],low[xx][yy]);
		} else if (!(xx==fa[x][y][0]&&yy==fa[x][y][1]))
		{
			qmin(low[x][y],dfn[xx][yy]);
		}
	}
}
void work1()
{
	int type,X0,Y0,X1,Y1;
	while (m--)
	{
		type=read();
		X0=read();Y0=read();X1=read();Y1=read();
		if (Y0==Y1) g[2][Y0]=type==2?1:0;
		else
		{
			X0--,X1--;
			if (Y1<Y0) g[X0][Y1]=type==2?1:0;
			else g[X0][Y0]=type==2?1:0;
		}
		for (int i=1;i<=n;i++) 
		{
			dfn[0][i]=dfn[1][i]=0;
			fa[0][i][0]=fa[1][i][0]=0;
			fa[0][i][1]=fa[1][i][1]=0;
		}
		for (int i=1;i<=n;i++)
		{
			if (dfn[0][i]==0)
			{
				dfs(0,i);
			}
			if (dfn[1][i]==0)
			{
				dfs(1,i);
			}
		}
		int sum=0;
		for (int j=0;j<=1;j++)
			for (int i=1;i<=n;i++)
			{
				if (!(fa[j][i][1]==0&&fa[j][i][0]==0)&&low[j][i]>dfn[fa[j][i][0]][fa[j][i][1]]) sum++;
			}
		printf("%d\n",sum);
	}
	return;
}
int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	n=read();m=read();
	g[0][0]=1;g[1][0]=1;
	g[0][n]=1;g[1][n]=1;
	if (n<=3000&&m<=3000)
	{
		work1();
		return 0;
	}
	return 0;
}
