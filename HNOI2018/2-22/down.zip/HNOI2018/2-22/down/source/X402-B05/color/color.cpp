#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const ll yyb=1000000007;
const int maxn=1e6+100;
int n,k;
char ch[maxn];
ll ans;
void dfs(int x)
{
	if (x==n+1)
	{
		int s1=0,s2=0;
		for (int i=1;i<=n;i++)
		{
			if (ch[i]=='B')
			{
				if (s2!=k) s2=0;
				if (s1<k) s1++;
			} else
			{
				if (s1==k)
				{
					if (s2<k) s2++;
				} else s1=0;
			}
			if (s1==k&&s2==k) 
			{
//				printf("%s\n",ch+1);	
				ans++;
				break;
			}
		}
		return;
	}
	if (ch[x]!='X') dfs(x+1); 
	else
	{
		ch[x]='B';
		dfs(x+1);
		ch[x]='W';
		dfs(x+1);
		ch[x]='X';
	}
}
ll f[4010][4010];
ll dp[4010][4010];
ll q[5010];
ll s[5010];
ll sum[4010][4010];
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	n=read();k=read();
	scanf("%s",ch+1);
	if (n<=20||n>=4000)
	{
		dfs(1);
		printf("%lld\n",ans%yyb);
		return 0;
	}
	if (n<=4000)
	{
		dp[0][0]=f[0][0]=1;
		sum[0][k-1]=1;
		for (int i=1;i<=n-k;i++)
		{
			if (ch[i]=='W'||ch[i]=='X') dp[i][0]=sum[i-1][k-1];
			for (int j=0;j<=min(i,k);j++)
			{
				if (ch[i]=='B'||ch[i]=='X')
				{
					if (j-1>=0)
					{
				//	printf("(%d,%d)",i,j);
						dp[i][j]+=dp[i-1][j-1];
						if (dp[i][j]>=yyb) dp[i][j]-=yyb;	
					}
				} 
			}
			sum[i][0]=dp[i][0];
//			printf("%d ",dp[i][0]);
			for (int j=1;j<=k;j++)
			{
//				printf("%d ",dp[i][j]);
				sum[i][j]=sum[i][j-1]+dp[i][j];
				if (sum[i][j]>=yyb) sum[i][j]-=yyb;
			}
//			printf("\n");
		}
//		printf("----------\n");
		memset(sum,0,sizeof(sum));
		sum[n+1][k-1]=1;
		f[n+1][0]=1;
		for (int i=n;i>=1;i--)
		{
//			for (int j=k;j<=k;j++)
//			{
//				f[i][j]=f[i+1][j];
//			}
			if (ch[i]=='B'||ch[i]=='X') f[i][0]=sum[i+1][k-1];
			for (int j=0;j<=min(k,n-i+1);j++)
			{
				if (ch[i]=='W'||ch[i]=='X')
				{
					if (j-1>=0)
					{
						f[i][j]+=f[i+1][j-1];
						if (f[i][j]>=yyb) f[i][j]-=yyb;
					}
				}
			}
//			printf("%d ",f[i][0]);
			sum[i][0]=f[i][0];
			for (int j=1;j<=k;j++)
			{
//				printf("%d ",f[i][j]);
				sum[i][j]=sum[i][j-1]+f[i][j];
				if (sum[i][j]>=yyb) sum[i][j]-=yyb;
			}
			s[i]=s[i+1]+f[i][k];
			if (s[i]>=yyb) s[i]-=yyb;
			q[i]=q[i+1]%yyb;
			if (ch[i]=='X')
			{
				q[i]*=2;
				q[i]%=yyb;
			}
			q[i]+=f[i][k];
			q[i]%=yyb;
//			cout<<q[i]<<endl;
//			printf("\n");
		}
		ans=0;
		for (int i=k;i<=n-k;i++)
		{
//			printf("(%d %d)",i,j);
			ans+=dp[i][k]*q[i+1]%yyb;
			ans%=yyb;
//			printf("%lld\n",ans);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
