#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
const int maxn1=3000+10;
const int maxn2=2000000+10;
template<typename T>
void read(T &x){
	T _=0,s=1;char __=getchar();
	while(!isdigit(__))s*= __=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	x=_*s;
}
void File(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
}
struct node{
	int key,x0,y0,x1,y1;
}a[maxn2];
int n,m,dis[maxn2][3];
void subtask1(){
}
int main(){
	File();
	bool sub1=1;
	bool sub2=1;
	read(n);read(m);
	if(n>3000 || m>3000)sub1=0;
	REP(i,1,m){
		read(a[i].key);
		read(a[i].x0);
		read(a[i].y0);
		read(a[i].x1);
		read(a[i].y1);
		if(a[i].key==1)
			sub2=0;
	}
	if(sub1){
		REP(i,1,n){

		}
	}
	if(sub2){

	}
	return 0;
}
