#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
const int maxn=1000+10;
const int mod=1000000007;
void File(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
}
char s[maxn];
int n,k,q[maxn],len,tot,ans;
void dfs(int th){
	if(th>tot){
		int b=0,w=0;
		int i;
		for(i=1;i<=n;i++){
			if(s[i]=='B')++b;
			else b=0;
			if(b==k)break;
		}
		for(;i<=n;i++){
			if(s[i]=='W')++w;
			else w=0;
			if(w==k)break;
		}
		if(w==k && b==k){
			++ans;
		}
		return;
	}
	s[q[th]]='B';
	dfs(th+1);
	s[q[th]]='W';
	dfs(th+1);
	s[q[th]]='X';
}
int main(){
	File();
	scanf("%d%d",&n,&k);
	scanf("%s",s+1);
	len=strlen(s+1);
	REP(i,1,len)
		if(s[i]=='X')
			q[++tot]=i;
	dfs(1);
	cout<<ans%mod<<endl;
	return 0;
}
