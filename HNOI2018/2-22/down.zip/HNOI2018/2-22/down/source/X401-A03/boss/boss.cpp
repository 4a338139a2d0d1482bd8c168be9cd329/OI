#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
const int maxn=1000+10;
template<typename T>
void read(T &___){
	T _=0,s=1;char __=getchar();
	while(!isdigit(__))s*= __=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	___=_*s;
}
void File(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
}
int HP,MP,SP;
int T,n,m,hp,mp,sp,n1,n2,b[20],y[20],c[20],z[20];
int dhp,dmp,dsp,x,a[maxn],ans=0x7fffffff,q[maxn];
bool flag;
void dfs(int k){
	if(m<=0){
		ans=min(ans,k-1);
		return;
	}	
	if(hp<=0)return;
	if(k>n){
		flag=1;
		return;
	}
	//cout<<hp<<" "<<m<<endl;
	//REP(i,1,k-1)cout<<q[i]<<" ";
	//cout<<endl;
	hp-=a[k];
	int sp1=sp,mp1,hp1;

	q[k]=1;
	m-=x;sp= sp+dsp>SP ? SP : sp+dsp;
	dfs(k+1);
	m+=x;sp=sp1;

	if(b[1]<=mp){
		q[k]=2;
		mp-=b[1];m-=y[1];
		dfs(k+1);
		mp+=b[1];m+=y[1];
	}

	if(c[1]<=sp){
		q[k]=3;
		sp-=c[1];m-=z[1];
		dfs(k+1);
		sp+=c[1];m+=z[1];
	}	

	q[k]=4;
	hp1=hp;hp= hp+dhp>HP ? HP : hp+dhp;
	dfs(k+1);
	hp=hp1;

	q[k]=5;
	mp1=mp;mp= mp+dmp>MP ? MP : mp+dmp;
	dfs(k+1);
	mp=mp1;
	hp+=a[k];
}
int main(){
	File();
	read(T);
	while(T--){
		ans=0x7fffffff;
		read(n);read(m);read(HP);read(MP);read(SP);
		hp=HP;mp=MP;sp=SP;
		read(dhp);read(dmp);read(dsp);read(x);
		REP(i,1,n)read(a[i]);
		read(n1);
		REP(i,1,n1)read(b[i]),read(y[i]);
		read(n2);
		REP(i,1,n2)read(c[i]),read(z[i]);
		dfs(1);
		if(ans!=0x7fffffff)cout<<"Yes "<<ans<<endl;
		else if(flag==1)cout<<"Tie"<<endl;
		else cout<<"No"<<endl;
	}
	return 0;
}

