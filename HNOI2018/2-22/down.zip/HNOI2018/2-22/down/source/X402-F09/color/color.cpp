#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
const int maxn=1e6+5;
const long long mod=1e9+7;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
int n,k,w[maxn],b[maxn];
long long dp[maxn][3][2];
char str[maxn];
int main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    read(n);read(k);
    scanf("%s",str+1);
    dp[0][0][1]=1;
    for(register int i=1;i<=n;++i){
        w[i]=w[i-1];b[i]=b[i-1];
        if(str[i]=='W')w[i]++;
        if(str[i]=='B')b[i]++;
    }
    for(register int i=1;i<=n;++i){
        long long tmp;
        if(str[i]!='W'){
            if(i>=k&&w[i]==w[i-k]){
                tmp=dp[i-k][0][1];
            }
            else tmp=0;
            dp[i][2][0]=(dp[i-1][2][0]+dp[i-1][2][1])%mod;
            dp[i][0][0]=((dp[i-1][0][0]+dp[i-1][0][1]-tmp%mod)+mod)%mod;
            dp[i][1][0]=((dp[i-1][1][0]+dp[i-1][1][1])%mod+tmp)%mod;
        }
        if(str[i]!='B'){
            if(i>=k&&b[i]==b[i-k]){
                tmp=dp[i-k][1][0];
            }
            else tmp=0;
            dp[i][0][1]=(dp[i-1][0][0]+dp[i-1][0][1])%mod;
            dp[i][1][1]=((dp[i-1][1][0]+dp[i-1][1][1]-tmp%mod)+mod)%mod;
            dp[i][2][1]=((dp[i-1][2][0]+dp[i-1][2][1])%mod+tmp)%mod;
        }
    }
    printf("%lld\n",(dp[n][2][0]+dp[n][2][1])%mod);
    return 0;
}
