#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=200005;
const int maxm=1500005;
int a[maxn],n,m,ans;
int head[maxm],tot,vis[maxm],fa[maxm];
struct edge{
    int to,next;
}e[maxm<<1];
bool flag[maxm];
#define pi pair<int,int>
#define mp make_pair
map< pi ,int>flag1,flag2;
inline int _min(int a,int b){
    return a<b?a:b;
}
inline void add(int u,int v){
    e[++tot].to=v;
    e[tot].next=head[u];
    head[u]=tot;
	flag2[mp(u,v)]=tot;
}
int dfn[maxn],low[maxn],sum,clok;
inline void dfs(int u){
    int child=0;
    dfn[u]=low[u]=++clok;
    vis[u]=sum;
    for(register int i=head[u];i;i=e[i].next){
		if(flag[i])continue;
        int v=e[i].to;
        if(vis[v]!=sum){
            child++;
            fa[v]=u;
            dfs(v);
            low[u]=_min(low[u],low[v]);
			if(low[v]>dfn[u])ans++;
        }
        else if(v!=fa[u])low[u]=min(low[u],dfn[v]);
    }
}
int main(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	read(n);read(m);
	int cnt=0;
	for(register int i=1;i<=2;i++){
		for(register int j=1;j<=n;j++){
			flag1[mp(i,j)]=++cnt;
        }
    }
	for(register int i=1;i<n;i++){
		int a,b,c,d;
		a=flag1[mp(1,i)];
        b=flag1[mp(1,i+1)];
        c=flag1[mp(2,i)];
        d=flag1[mp(2,i+1)];
		add(a,b);add(b,a);
		add(c,d);add(d,c);
		add(a,c);add(c,a);
	}
	add(flag1[mp(1,n)],flag1[mp(2,n)]);add(flag1[mp(2,n)],flag1[mp(1,n)]);
	for(register int i=1;i<=n;i++){
    	if(!vis[i]){
            fa[i]=-1;
            dfs(i);
        }
    }
	for(register int i=1;i<=m;i++){
		int q,x,y,xx,yy;
		read(q);read(x);read(y);read(xx);read(yy);
		if(q==1){
			if(!flag1.count(mp(x,y)))flag1[mp(x,y)]=++cnt;
			if(!flag1.count(mp(xx,yy)))flag1[pi(xx,yy)]=++cnt;
			add(flag1[mp(x,y)],flag1[mp(xx,yy)]);add(flag1[mp(xx,yy)],flag1[mp(x,y)]);
		}
		else if(q==2){
			flag[flag2[pi(flag1[pi(x,y)],flag1[pi(xx,yy)])]]=1;
			flag[flag2[pi(flag1[pi(xx,yy)],flag1[pi(x,y)])]]=1;
		}
        ++sum;
		ans=0;
        clok=0;
		for(int j=1;j<=cnt;j++){
		   if(vis[j]!=sum){
                fa[j]=-1;
                dfs(j);
            }
        }
		printf("%d\n",ans);
    }
    return 0;
}
