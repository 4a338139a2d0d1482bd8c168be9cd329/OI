#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=200010;

int n,m,sum;
int lst[maxn],nxt[maxn];

bool can[maxn][2];

set<int> s;

namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    int T[maxn<<2];

    void update(int h,int l,int r,int p,int x){
        if(l==r) return void(T[h]+=x);
        if(p<=mid) update(ls,lc,p,x);
        else update(rs,rc,p,x);
        T[h]=T[ls]+T[rs];
    }

    int query(int h,int l,int r,int L,int R){
        if(L>R) return 0;
        if(L<=l&&r<=R) return T[h];
        int ret=0;
        if(L<=mid) ret+=query(ls,lc,L,R);
        if(R>mid) ret+=query(rs,rc,L,R);
        return ret;
    }
}

using namespace SGT;

int main(){
    freopen("bridge.in","r",stdin);
    freopen("bridge.out","w",stdout);

    read(n); read(m);

    s.insert(0);
    
    for(int i=1;i<=n;i++){
        s.insert(i);
        lst[i]=i-1,nxt[i]=i+1;
        if(i==1||i==n) can[i][i==n]=1;
    }

    while(m--){
        int op,ax,ay,bx,by;
        read(op);
        read(ax); read(ay);
        read(bx); read(by);

        if(op==2){
            if(ax==bx){
                auto it=s.upper_bound(ay); --it;
                int p=*it;
                update(1,1,n-1,ay,1);
                int w=query(1,1,n-1,max(1,p),min(n,nxt[p])-1);

                if(!p||nxt[p]==n+1) --sum;

                else{
                    if(w==1) sum+=(nxt[p]-p)*2-1;
                    else --sum;
                }

                if(p>0){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][1]=(nxt[p]==n+1||w>0);
                    if(can[p][0]&&can[p][1]) ++sum;
                }

                p=nxt[p];
                if(p<=n){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][0]=(!lst[p]||w>0);
                    if(can[p][0]&&can[p][1]) ++sum;
                }
            }

            else{
                s.erase(s.find(ay));
                nxt[lst[ay]]=nxt[ay];
                lst[nxt[ay]]=lst[ay];
                if(can[ay][0]&&can[ay][1]) --sum;
                can[ay][0]=can[ay][1]=0;

                int w;
                w=query(1,1,n-1,max(1,lst[ay]),ay-1);
                if(!lst[ay]||w>0) sum-=(ay-lst[ay])*2-w;

                w=query(1,1,n-1,ay,min(n,nxt[ay])-1);
                if(nxt[ay]==n+1||w>0) sum-=(nxt[ay]-ay)*2-w;

                w=query(1,1,n-1,max(1,lst[ay]),min(n,nxt[ay])-1);
                if(!lst[ay]||nxt[ay]==n+1||w>0) sum+=(nxt[ay]-lst[ay])*2-w;

                int p;
                p=lst[ay];
                if(p>0){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][1]=(nxt[p]==n+1||w>0);
                    if(can[p][0]&&can[p][1]) ++sum;
                }

                p=nxt[ay];
                if(p<=n){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][0]=(!lst[p]||w>0);
                    if(can[p][0]&&can[p][1]) ++sum;
                }
            }
        }

        else{
            if(ax==bx){
                auto it=s.upper_bound(ay); --it;
                int p=*it;
                update(1,1,n-1,ay,-1);
                int w=query(1,1,n-1,max(1,p),min(n,nxt[p])-1);

                if(!p||nxt[p]==n+1) ++sum;

                else{
                    if(w==1) sum-=(nxt[p]-p)*2-1;
                    else ++sum;
                }

                if(p>0){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][1]=(nxt[p]==n+1||w>0);
                    if(can[p][0]&&can[p][1]) ++sum;
                }

                p=nxt[p];
                if(p<=n){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][0]=(!lst[p]||w>0);
                    if(can[p][0]&&can[p][1]) ++sum;
                }
            }
            
            else{
                auto it=s.upper_bound(ay); --it;
                lst[ay]=*it;
                nxt[ay]=nxt[lst[ay]];
                nxt[lst[ay]]=lst[nxt[ay]]=ay;
                s.insert(ay);

                if(can[ay][0]&&can[ay][1]) --sum;
                can[ay][0]=can[ay][1]=0;

                int w,p;
                w=query(1,1,n-1,max(1,lst[ay]),min(n,nxt[ay])-1);
                if(!lst[ay]||nxt[ay]==n+1||w>0) sum-=(nxt[ay]-lst[ay])*2-w;

                w=query(1,1,n-1,max(1,lst[ay]),ay-1);
                if(!lst[ay]||w>0) sum+=(ay-lst[ay])*2-w;

                p=lst[ay];
                if(p>0){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][1]=w>0;
                    if(can[p][0]&&can[p][1]) ++sum;
                }

                can[ay][0]=(p==0||w>0);

                w=query(1,1,n-1,ay,min(n,nxt[ay])-1);
                if(nxt[ay]==n+1||w>0) sum+=(nxt[ay]-ay)*2-w;

                p=nxt[ay];
                if(p<=n){
                    if(can[p][0]&&can[p][1]) --sum;
                    can[p][0]=w>0;
                    if(can[p][0]&&can[p][1]) ++sum;
                }

                can[ay][1]=(p==n+1||w>0);

                if(can[ay][0]&&can[ay][1]) ++sum;
            }
        }

        printf("%d\n",sum);
    }

    return 0;
}
