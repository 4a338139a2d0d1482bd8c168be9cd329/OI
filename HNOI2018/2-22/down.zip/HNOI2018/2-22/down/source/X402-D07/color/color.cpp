#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=2010,mo=1e9+7;

int n,m,ans;
char s[maxn];
int dp[maxn][maxn],sum[maxn];
int pre[maxn],suf[maxn];

void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}

bool check(int p,char c){
    for(int i=1;i<=m;i++,p++)
        if(s[p]!=c&&s[p]!='X') return 0;
    return 1;
}

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

void DP(int* ss,char c){
    memset(dp,0,sizeof dp);
    memset(sum,0,sizeof sum);
    dp[0][0]=sum[0]=1;
    for(int i=1;i<=n;i++){
        if(s[i]!=c&&s[i]!='X') Add(dp[i][0],sum[i-1]);

        else if(s[i]==c){
            for(int j=1;j<=m&&i-j+1>0;j++) Add(dp[i][j],dp[i-1][j-1]);
        }

        else{
            Add(dp[i][0],sum[i-1]);
            for(int j=1;j<=m&&i-j+1>0;j++) Add(dp[i][j],dp[i-1][j-1]);
        }

        for(int j=0;j<m;j++) Add(sum[i],dp[i][j]);
    }

    for(int i=1;i<=n;i++) ss[i]=dp[i][m];
}

int cnt[maxn];

int main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);

    read(n); read(m);
    if(m>n) puts("0"),exit(0);

    scanf("%s",s+1);
    int len=strlen(s+1);

    DP(pre,'B');
    reverse(s+1,s+len+1);
    DP(suf,'W');
    reverse(s+1,s+len+1);

    for(int i=1;i<=n;i++) cnt[i]=cnt[i-1]+(s[i]=='X');

    for(int L=1;L<=n;L++)
        for(int R=1;n-R+1>L;R++)
            Add(ans,1ll*pre[L]*suf[R]%mo*fpm(2,(cnt[n-R]-cnt[L]))%mo);

    printf("%d\n",ans);

    return 0;
}
