#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=1010,INF=0x3f3f3f3f;

bool flag;
int ans;

int n,m,hp,mp,sp,Dhp,Dmp,Dsp,X,n1,n2;
int a[maxn],b[15],c[15],y[15],z[15];

int dp[maxn][maxn];
int D,d[maxn],w1[maxn],w2[maxn];

int main(){
    freopen("boss.in","r",stdin);
    freopen("boss.out","w",stdout);

    int _; read(_);

    while(_--){
        read(n); read(m);
        read(hp); read(mp); read(sp);
        read(Dhp); read(Dmp); read(Dsp);
        read(X);
        for(int i=1;i<=n;i++) read(a[i]);
        read(n1);
        for(int i=1;i<=n1;i++) read(b[i]),read(y[i]);
        read(n2);
        for(int i=1;i<=n2;i++) read(c[i]),read(z[i]);

        flag=0; int now=hp;
        for(int i=1;i<=n;i++){
            now=min(now+Dhp,hp)-a[i];
            if(now<=0){ flag=1; break; }
        }

        memset(dp,0,sizeof dp);

        for(int i=1;i<=n;i++)
            for(int j=1;j<=hp;j++){
                if(j>a[i]) chkmax(dp[i+1][j-a[i]],dp[i][j]+1);
                if(min(j+Dhp,hp)-a[i]>0) chkmax(dp[i+1][min(j+Dhp,hp)-a[i]],dp[i][j]);
            }

        memset(d,0,sizeof d); D=0;

        for(int i=1;i<=n;i++){
            for(int j=1;j<=hp;j++) chkmax(d[i],dp[i][j]+1);
            chkmax(D,d[i]);
        }

        memset(dp,0,sizeof dp);

        for(int i=1;i<=D;i++)
            for(int j=0;j<=mp;j++){
                chkmax(dp[i+1][min(j+Dmp,mp)],dp[i][j]);
                for(int k=1;k<=n1;k++) if(j>=b[k])
                    chkmax(dp[i+1][j-b[k]],dp[i][j]+y[k]);
            }

        memset(w1,0,sizeof w1);

        for(int i=0;i<=D;i++)
            for(int j=0;j<=mp;j++) chkmax(w1[i],dp[i+1][j]);

        memset(dp,0,sizeof dp);

        for(int i=1;i<=D;i++)
            for(int j=0;j<=sp;j++){
                chkmax(dp[i+1][min(j+Dsp,sp)],dp[i][j]+X);
                for(int k=1;k<=n2;k++) if(j>=c[k])
                    chkmax(dp[i+1][j-c[k]],dp[i][j]+z[k]);
            }

        memset(w2,0,sizeof w2);

        for(int i=0;i<=D;i++)
            for(int j=0;j<=sp;j++) chkmax(w2[i],dp[i+1][j]);

        int mint=INF;
        for(int nD=1;nD<=D;nD++){
            int Max=0;
            for(int i=nD;~i;i--){
                chkmax(Max,w2[nD-i]);
                if(w1[i]+Max>=m){ mint=nD; break; }
            }
            if(mint!=INF) break;
        }

        ans=INF;
        for(int i=0;i<=n;i++) if(d[i]>=mint){ ans=i; break; }

        if(ans!=INF) printf("Yes %d\n",ans);
        else if(flag) puts("No");
        else puts("Tie");
    }

    return 0;
}
