#include<bits/stdc++.h>
using namespace std;
#define Temp template<typename T>
Temp inline void read(T &x) 
{
	x=0;char c=getchar();T f=1;
	while(!isdigit(c)) {if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

#define N 500
#define inf 0x3f3f3f3f
int dp[N][N][N];
int T,n,n1,n2,m,HP,MP,SP,Dhp,Dmp,Dsp,X;
int a[N],b[N],c[N],y[N],z[N],ans;
void readin(){
	read(n),read(m),read(HP),read(MP),read(SP),read(Dhp),read(Dmp),read(Dsp),read(X);
	for(int i=1;i<=n;++i) read(a[i]);
	read(n1);for(int i=1;i<=n1;++i) read(b[i]),read(y[i]);
	read(n2);for(int i=1;i<=n2;++i) read(c[i]),read(z[i]);
}
int Can_we()
{
	int tot=0;
	for(int i=1;i<=n;++i) tot+=a[i];
	if(tot>=HP+Dhp*n) return 0;
	return 1;
}
void work()
{
	ans=0;
	bool Yes=0;
	for(int i=1;i<=HP;++i) for(int j=1;j<=MP;++j) for(int k=1;k<=SP;++k) dp[i][j][k]=inf;
	dp[HP][MP][SP]=m;
	for(int t=1;t<=n;++t) 
	{
		if(Yes) break;
		for(int i=1;i<=HP;++i)
		{
			if(Yes) break;
			for(int j=1;j<=MP;++j)
			{
				if(Yes) break;
				for(int k=1;k<=SP;++k)
				{
					if(dp[i][j][k]<=X) {ans=t;Yes=1;break;}
					for(int I=1;I<=n1;++I) if(b[I]<=j && dp[i][j][k]<=y[I]){ans=t;Yes=1;break;}
					if(Yes) break;
					for(int I=1;I<=n2;++I) if(c[I]<=k && dp[i][j][k]<=z[I]){ans=t;Yes=1;break;}
					if(Yes) break;
					//-------------
					
					if(i-a[t]+Dhp<=0) break;
					dp[min(i+Dhp,HP)-a[t]][j][k]=min(dp[min(i+Dhp,HP)-a[t]][j][k],dp[i][j][k]);
					dp[i-a[t]][j][min(SP,k+Dsp)]=min(dp[i-a[t]][j][min(SP,k+Dsp)],dp[i][j][k]-X);
					for(int I=1;I<=n1;++I) if(b[I]<=j) dp[i-a[t]][j-b[I]][k]=min(dp[i-a[t]][j-b[I]][k],dp[i][j][k]-y[I]);
					for(int I=1;I<=n2;++I) if(c[I]<=k) dp[i-a[t]][j][k-c[I]]=min(dp[i-a[t]][j][k-c[I]],dp[i][j][k]-z[I]);
					dp[i-a[t]][min(MP,j+Dmp)][k]=min(dp[i-a[t]][min(MP,j+Dmp)][k],dp[i][j][k]);
				}
			}
		}
	}
	if(Yes) printf("Yes %d\n",ans);
	else 
	{
		if(Can_we()) puts("Tie");
		else puts("No");
	}
}
int main()
{
	//freopen("boss.in","r",stdin);
	//freopen("boss.out","w",stdout);
	read(T);
	for(int cas=1;cas<=T;++cas) 
	{
		readin();
		work();
	}
	return 0;
} 
