#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("bridge.in", "r", stdin);
	freopen ("bridge.out", "w", stdout);
}

int n, m;

int ans = 0;

const int N = 200010;
int row[N][2];
int col[N];

int will[N];
bool have[N];

int cnt[N][2];

int Calc() {
	int res = 0;
	Set(will, 0);

	int Last = 0;
	For (i, 1, n) {
		int flag = 0;
		For (j, 0, 1) {
			cnt[i][j] = cnt[i - 1][j] + row[i - 1][j];
			if (cnt[i][j] - cnt[Last][j] == (i - Last) ) ++ flag;
		}
		if (Last && flag == 2 && col[i])
			For (j, Last, i) will[j] = 1;
		if (col[i]) Last = i;
	}

	For (i, 1, n) {
		if (will[i + 1] && will[i] && row[i][0] && row[i][1]) continue ;
		res += row[i][0] + row[i][1];
		if (will[i - 1] && will[i] && row[i - 1][0] && row[i - 1][1]) continue ;
		res += col[i];
	}
	return res;
}

int main () {
	File();
	n = read();
	m = read();
	For (i, 1, n) {
		if (i < n) row[i][0] = row[i][1] = 1;
		col[i] = 1;
	}
	For (i, 1, m) {
		int opt = read(),
			xi = read(), yi = read(),
			xj = read(), yj = read();
		opt = opt == 2 ? 0 : 1;
		if (xi == xj) row[yi][xi - 1] = opt;
		else col[yi] = opt;
		printf ("%d\n", Calc() );
	}
    return 0;
}
