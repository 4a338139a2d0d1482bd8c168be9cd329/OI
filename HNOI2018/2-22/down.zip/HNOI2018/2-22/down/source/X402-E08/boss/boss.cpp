#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("boss.in", "r", stdin);
	freopen ("boss.out", "w", stdout);
}

const int N = 1010;
int n, m, hp, mp, sp, dhp, dmp, dsp, x;
int maxhp, maxmp, maxsp;
int n1, n2;
int b[N], y[N];
int c[N], z[N];
int a[N];

void Input() {
	cin >> n >> m >> hp >> mp >> sp >> dhp >> dmp >> dsp >> x;
	maxhp = hp; maxmp = mp; maxsp = sp; 

	For (i, 1, n) cin >> a[i];
	n1 = read(); For (i, 1, n1) cin >> b[i] >> y[i];
	n2 = read(); For (i, 1, n2) cin >> c[i] >> z[i];
}

const int inf = 0x3f3f3f3f;
int ans = inf;

inline bool Judge(int round) { if (m <= 0) { ans = min(ans, round - 1); return true; } if (hp <= 0) return true; return false; }

bool cut;
int Best[103][71][71][71];
// round hp mp sp

void Solve2() {
	Set(Best, -1);
	ans = inf;
	Best[1][hp][mp][sp] = 0;
	For (i, 1, n + 1) {
		For (ihp, 0, maxhp)
			For (imp, 0, maxmp)
				For (isp, 0, maxsp) {
					if (Best[i][ihp][imp][isp] == -1) continue ;
					if (Best[i][ihp][imp][isp] >= m) { ans = i - 1; return ; }
					if (i == n + 1) ans = inf - 1;
					int now = Best[i][ihp][imp][isp];
					if (ihp > a[i]) {
							chkmax(Best[i + 1][ihp - a[i]][imp][min(maxsp, isp + dsp)], now + x);

						For (j, 1, n1) if (imp >= b[j]) 
							chkmax(Best[i + 1][ihp - a[i]][imp - b[j]][isp], now + y[j]);

						For (j, 1, n2) if (isp >= c[j])
							chkmax(Best[i + 1][ihp - a[i]][imp][isp - c[j]], now + z[j]);

							chkmax(Best[i + 1][ihp - a[i]][min(maxmp, imp + dmp)][isp], now);
					} 
					int nowhp = min(ihp + dhp, maxhp);
					if (nowhp > a[i]) chkmax(Best[i + 1][nowhp - a[i]][imp][isp], now);
				}
	}
}

void Dfs(int round) {
	if (round > n) { if (ans == inf) ans = inf - 1; if (Judge(round)) return ; return ;}
	if (Judge(round)) return ;
	
	int bef[5];
	{
		bef[1] = m; bef[2] = sp; bef[3] = hp;
		m -= x; sp = min(sp + dsp, maxsp); hp -= a[round];
		Dfs(round + 1);
		m = bef[1]; sp = bef[2]; hp = bef[3];
	} //normal attack

	For (i, 1, n1)
		if (mp >= b[i]) {
			bef[1] = m; bef[2] = mp; bef[3] = hp;
			m -= y[i]; mp -= b[i]; hp -= a[round];
			Dfs(round + 1);
			m = bef[1]; mp = bef[2]; hp = bef[3];
		}
	//AP attack

	For (i, 1, n2)
		if (sp >= c[i]) {
			bef[1] = m; bef[2] = sp; bef[3] = hp;
			m -= z[i]; sp -= c[i]; hp -= a[round];
			Dfs(round + 1);
			m = bef[1]; sp = bef[2]; hp = bef[3];
		}
	//angry attack

	{
		bef[1] = hp;
		hp = min(maxhp, hp + dhp);
		hp -= a[round];
		Dfs(round + 1);
		hp = bef[1];
	}
	//recover hp


	{
		bef[1] = mp; bef[2] = hp;
		mp = min(maxmp, mp + dmp);
		hp -= a[round];
		Dfs(round + 1);
		mp = bef[1]; hp = bef[2];
	}
	//recover mp
}

void Solve1() {
	ans = inf;
	Dfs(1);	
}

void Output() {
	if (ans == inf) puts("No");
	else if (ans == inf - 1) puts("Tie");
	else printf ("Yes %d\n", ans);
}

int main () {
	File();
	int cases = read();
	while (cases --) {
		Input();
		if (n <= 10 && n1 == 1 && n2 == 1) Solve1();
		else Solve2();
		Output();
	}
    return 0;
}
