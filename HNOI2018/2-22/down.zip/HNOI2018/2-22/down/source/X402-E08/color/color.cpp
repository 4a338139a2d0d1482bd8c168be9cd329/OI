#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

const int N = 1e6 + 1e3;
char str[N];
int n, k;
int ans = 0;

int cnt[N][2];
int id[256];
inline int Calc () {
	For (i, 1, n) {
		cnt[i][0] = cnt[i - 1][0];
		cnt[i][1] = cnt[i - 1][1];
		++ cnt[i][id[(int)str[i]]];
	}

	For (i, 1, n) if (cnt[i + k - 1][0] - cnt[i - 1][0] == k) {
		For (j, i + 1, n) if (cnt[j + k - 1][1] - cnt[j - 1][1] == k) return 1;
		return 0;
	}
	return 0;
}

void Dfs(int dep) {
	if (dep == n + 1) { ans += Calc(); return ; }
	if (str[dep] == 'X') {
		str[dep] = 'W'; Dfs(dep + 1);
		str[dep] = 'B'; Dfs(dep + 1);
		str[dep] = 'X';
	} else Dfs(dep + 1);
}

void File() {
	freopen ("color.in", "r", stdin);
	freopen ("color.out", "w", stdout);
}

int main () {
	File();
	id['B'] = 0;
	id['W'] = 1;
	id['X'] = 2;
	n = read(); k = read();	
	scanf ("%s", str + 1);
	Dfs(1);
	printf ("%d\n", ans);
    return 0;
}
