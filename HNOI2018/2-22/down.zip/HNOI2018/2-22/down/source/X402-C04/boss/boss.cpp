#include<bits/stdc++.h>
using namespace std;

const int N=100009;
const int H=79;
const int M=1000009;
const int NN=19;
const int Inf=1e9+7;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int minn(int a,int b){if(a>b)return b;return a;}
inline void chkmax(int &a,int b){if(a<b)a=b;}

int n,m,hp,mp,sp,dhp,dmp,dsp,x;
int n1,n2,b[NN],y[NN],c[NN],z[NN];
int a[N],f[2][H][H][H];

inline int mina()
{
	n=read();m=read();hp=read();
	mp=read();sp=read();dhp=read();
	dmp=read();dsp=read();x=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	n1=read();
	for(int i=1;i<=n1;i++)
		b[i]=read(),y[i]=read();
	n2=read();
	for(int i=1;i<=n2;i++)
		c[i]=read(),z[i]=read();
	
	for(int j=0;j<=hp;j++)
		for(int k=0;k<=mp;k++)
			for(int l=0;l<=sp;l++)
				f[0][j][k][l]=-Inf;

	int ans=-1;
	f[0][hp][mp][sp]=0;

	for(int i=0;i<n;i++)
	{
		int fl=0;
		
		for(int j=0;j<=hp;j++)
			for(int k=0;k<=mp;k++)
				for(int l=0;l<=sp;l++)
					f[i&1^1][j][k][l]=-Inf;

		for(int j=1;j<=hp;j++)
			for(int k=0;k<=mp;k++)
				for(int l=0;l<=sp;l++)
					if(f[i&1][j][k][l]>=0)
					{
						fl=1;
						if(f[i&1][j][k][l]>=m)
						{
							ans=i;
							goto out;
						}
						if(j<=a[i])continue;
						
						//1
						chkmax(f[i&1^1][j-a[i]][k][minn(sp,l+dsp)],f[i&1][j][k][l]+x);
						//2
						for(int q=1;q<=n1;q++)
							if(k>=b[q])
							{
								chkmax(f[i&1^1][j-a[i]][k-b[q]][l],f[i&1][j][k][l]+y[q]);
							}
						//3
						for(int q=1;q<=n1;q++)
							if(l>=c[q])
								chkmax(f[i&1^1][j-a[i]][k][l-c[q]],f[i&1][j][k][l]+z[q]);
						//4
						chkmax(f[i&1^1][minn(hp,j-a[i]+dhp)][k][l],f[i&1][j][k][l]);
						//5
						chkmax(f[i&1^1][j-a[i]][minn(k+dmp,mp)][l],f[i&1][j][k][l]);
					}
		if(!fl)
		{
			puts("No");
			return 0;
		}
	}
	out:;
	if(ans!=-1)
		printf("Yes %d\n",ans);
	else
	{
		for(int j=1;j<=hp;j++)
			for(int k=0;k<=mp;k++)
				for(int l=0;l<=sp;l++)
					if(f[n&1][j][k][l]>=m)
					{
						printf("Yes %d\n",n);
						return 0;
					}
		puts("Tie");
	}
	return 0;
}

int main()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);

	int T=read();
	while(T--)
		mina();

	return 0;
}
