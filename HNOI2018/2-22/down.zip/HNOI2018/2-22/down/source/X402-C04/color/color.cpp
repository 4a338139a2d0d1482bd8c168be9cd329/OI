#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=4005;
const int md=1000000007;
int n,m;
ll f[N][N][2][2],g[N][N],ans;
char s[N];

inline void chk(ll &x){if(x>=md)x-=md;}

int main() 
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	scanf("%s",s+1);
	f[0][0][0][0]=1;
	
	for(int i=1;i<=n;i++) 
	{
		for(int j=0;j<=n;j++) 
		{
			if(s[i]=='W' || s[i]=='X') 
			{
				chk(f[i][0][0][0]+=(f[i-1][j][0][0]+f[i-1][j][1][0])%md);
				chk(f[i][j+1][0][1]+=(f[i-1][j][0][1]+f[i-1][j][1][1])%md);
			}
			if(s[i]=='B' || s[i]=='X') 
			{
				chk(f[i][j+1][1][0]+=(f[i-1][j][0][0]+f[i-1][j][1][0])%md);
				chk(f[i][0][1][1]+=(f[i-1][j][0][1]+f[i-1][j][1][1])%md);
			}
		}
		chk(f[i][0][1][1]+=f[i][m][1][0]);
		f[i][m][1][0]=0;
	}

	g[n+1][0]=1;
	for(int i=n;i;i--)
		for(int j=0;j<=m;j++) 
		{
			if(s[i]=='W' || s[i]=='X')
				(g[i][j+1]+=g[i+1][j])%=md;
			if(s[i]=='B' || s[i]=='X')
				(g[i][0]+=g[i+1][j])%=md;
		}
	
	for(int i=0;i<=n+1;i++)
		for(int j=1;j<=m;j++)
			(g[i][j]+=g[i][j-1])%=md;
	for(int i=1;i<=n;i++)
		(ans+=(ll)f[i][m][0][1]*g[i+1][m-1]%md)%=md;

	printf("%lld\n",ans);
	return 0;
}
