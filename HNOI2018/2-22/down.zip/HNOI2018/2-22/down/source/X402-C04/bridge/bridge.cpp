#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef pair<int,int> pr;
const int N=200009;

struct query
{
	int ty,x0,y0,x1,y1;
}q[N];

bool flag;
int n,m,fa[N*2],f[N][3];
set<pr> s;

inline int pa(int x,int y)
{
	return (x-1)*n+y;
}

inline pr prs(int a,int b)
{
	return pr(min(a,b),max(a,b));
}

inline int find(int x)
{
	if(fa[x]==x)return x;
	return fa[x]=find(fa[x]);
}

inline void merge(int a,int b)
{
	if(find(a)==find(b))return;
	fa[find(a)]=find(b);
}

inline bool judge(int p1,int p2)
{
	for(int i=1;i<=n*2;i++)
		fa[i]=i;
	for(set<pr>::iterator it=s.begin();it!=s.end();it++)
		if((*it)!=pr(p1,p2))
			merge((*it).first,(*it).second);
	return !(find(p1)==find(p2));
}

inline int calc()
{
	int ans=0;
	for(set<pr>::iterator it=s.begin();it!=s.end();it++)
		ans+=judge((*it).first,(*it).second);
	return ans;
}

inline int bf()
{
	for(int i=1;i<n;i++)
	{
		f[i][0]=f[i][1]=f[i][2]=1;
		s.insert(prs(pa(1,i),pa(1,i+1)));
		s.insert(prs(pa(2,i),pa(2,i+1)));
		s.insert(prs(pa(1,i),pa(2,i)));
	}
	f[n][1]=1;
	s.insert(prs(pa(1,n),pa(2,n)));

	for(int i=1;i<=m;i++)
	{
		if(q[i].ty==1)
		{
			s.insert(prs(pa(q[i].x0,q[i].y0),pa(q[i].x1,q[i].y1)));
			printf("%d\n",calc());
		}
		else
		{
			s.erase(prs(pa(q[i].x0,q[i].y0),pa(q[i].x1,q[i].y1)));
			printf("%d\n",calc());
		}
	}
	return 0;
}

int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);

	n=read();m=read();
	for(int i=1;i<=m;i++)
	{
		q[i].ty=read();
		q[i].x0=read();
		q[i].y0=read();
		q[i].x1=read();
		q[i].y1=read();
		if(q[i].ty==1)flag=1;
	}

	return bf();
}
