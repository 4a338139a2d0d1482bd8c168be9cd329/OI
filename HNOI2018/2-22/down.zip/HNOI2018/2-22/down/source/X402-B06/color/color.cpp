#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a);i<=(b);++i)
#define Forward(i,a,b) for(i=(a);i>=(b);--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	#endif
}
const int MAXN=1e6+7;
static int n,k;
static char s[MAXN];
inline void init()
{
    read(n);read(k);
    scanf("%s",s+1);
}
static int ans;
inline bool Judge()
{
    static int las,i;
    las=0;
    For(i,1,n)
    {
        if(s[i]=='B')++las;
        else las=0;
        if(las>=k)break;
    }
    For(i,i,n)
    {
        if(s[i]=='W')++las;
        else las=0;
        if(las>=k)break;
    }
    return las>=k;
}
int lasp;
void dfs(int pos)
{
    if(pos>lasp&&Judge()){++ans;return;}
    int i;
    For(i,pos,n)if(s[i]=='X')
    {
        s[i]='B';dfs(i+1);
        s[i]='W';dfs(i+1);
        s[i]='X';
        return;
    }
}
inline void solve()
{
    Repe(i,n,1)if(s[i]=='X'){lasp=i;break;}
    if(k>n/2)return (void)puts("0");
    dfs(1);cout<<ans<<endl;
}
int main(void){
	file();
    init();
    solve();
	return 0;
}

