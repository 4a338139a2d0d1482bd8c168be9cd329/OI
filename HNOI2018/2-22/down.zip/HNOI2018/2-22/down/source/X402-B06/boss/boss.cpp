#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	#endif
}
const int MAXN=1011;
static int n,m,hp,mp,sp,dh,dm,ds,x;
static int a[MAXN],n1,n2,flag;
static struct hit
{
    int deq,dam;
    friend bool operator<(hit a,hit b)
    {return a.dam^b.dam?a.dam>b.dam:a.deq<b.deq;}
}b[MAXN],c[MAXN];
static int mag[MAXN][MAXN],spe[MAXN][MAXN];//i天消耗j魔法/气血造成的伤害值
static int dp[MAXN][MAXN];//i天剩下j点体力至少喝药次数
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
inline void predone()
{
    memset(mag,0,sizeof mag);
    memset(spe,0,sizeof spe);
    memset(dp,0x3f,sizeof dp);
    Rep(i,1,n)
    {
        Rep(j,dm,mp)mag[i][j]=mag[i-1][j-dm];
        Rep(j,1,n1)Repe(k,mp-b[i].deq,0)
            Chkmax(mag[i][k],mag[i-1][k+b[j].deq]+b[j].dam);
    }
    Rep(i,1,n)
    {
        Rep(j,ds,sp)spe[i][j]=spe[i-1][j-ds]+x;
        Rep(j,1,n2)Repe(k,sp-c[i].deq,0)
            Chkmax(spe[i][k],spe[i-1][k+c[j].deq]+c[j].dam);
    }
    dp[1][hp]=0;
    Rep(i,2,n)
    {
        Rep(j,1,hp-a[i-1])dp[i][j]=dp[i-1][j+a[i-1]];
        Repe(j,hp,dh)Chkmin(dp[i][j],dp[i][j-dh]+1);
        Rep(j,hp-dh+1,hp-1)Chkmin(dp[i][hp],dp[i][j]+1);
    }
    Rep(i,1,n)Rep(j,1,mp)Chkmax(mag[i][j],mag[i][j-1]);
    Rep(i,1,n)Rep(j,1,sp)Chkmax(spe[i][j],spe[i][j-1]);
    Rep(i,1,n)Repe(j,hp-1,1)Chkmin(dp[i][j],dp[i][j+1]);
}
inline void init()
{
    flag=true;
    read(n);read(m);read(hp);read(mp);read(sp);
    read(dh);read(dm);read(ds);read(x);
    if(dh>hp)dh=hp;if(dm>mp)dm=mp;if(ds<sp)ds=sp;
    Rep(i,1,n)read(a[i]);
    Rep(i,1,n)if(a[i]>hp)n=i-1,flag=false;
    read(n1);Rep(i,1,n1)read(b[i].deq),read(b[i].dam);
    read(n2);Rep(i,1,n2)read(c[i].deq),read(c[i].dam);
    sort(b+1,b+n1+1);sort(c+1,c+n2+1);
    predone();
}
inline bool Judge(int lim)
{
    Rep(i,0,lim)
    {
        if(spe[i][sp]+mag[lim-i][mp]>=m)return true;
    }
    return false;
}
inline bool Alive()
{
    static int hh;hh=hp;
    Rep(i,1,n)
    {
        hh=min(hh+dh,hp);
        hh-=a[i];
        if(hh<=0)return false;
    }
    return true;
}
inline void solve()
{
    int l=1,r=n,mid;
    while(l<=r)
    {
        mid=(l+r)>>1;
        if(Judge(mid))r=mid-1;
        else l=mid+1;
    }
    Rep(i,1,n)if(i-dp[i][1]>=l)return (void)printf("Yes %d\n",i);
    if(flag&&Alive())puts("Tie");
    else puts("No");
}
int main(void){
	file();
    static int _;
    read(_);
    while(_--)
    init(),
    solve();
	return 0;
}

