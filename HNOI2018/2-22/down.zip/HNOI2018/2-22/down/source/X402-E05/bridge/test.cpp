#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
#ifdef ztzshiwo
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);
#endif
}
int n,m,cnt;
int p[1000000];
inline void Get_edge(int x)
{
	if(x<n)printf("%d %d %d %d\n",1,x,1,x+1);
	else if(x<2*n)printf("%d %d %d %d\n",1,x-n+1,2,x-n+1);
	else printf("%d %d %d %d\n",2,x+1-2*n,2,x+2-2*n);
}
inline void Erase()
{
	int x=rand()%cnt+1;
	cnt--;
	For(i,1,3*n-2)
	{
		if(p[i])x--;
		if(!x)
		{
			printf("%d ",2);
			p[i]=0;
			Get_edge(i);
			return;
		}
	}
}
inline void ADD()
{
	int x=rand()%(3*n-2-cnt)+1;
	cnt++;
	For(i,1,3*n-2)
	{
		if(!p[i])x--;
		if(!x)
		{
			printf("%d ",1);
			Get_edge(i);
			p[i]=1;
			return;
		}
	}
}
int main()
{
	srand(time(0));
	freopen("bridge.in","w",stdout);
	n=rand()%2000+1000;
	m=rand()%3000+3000;
	cnt=3*n-2;
	printf("%d %d\n",n,m);
	For(i,1,3*n-2)p[i]=1;
	For(i,1,m)
	{
		if(cnt==3*n-2)Erase();
		else 
		if(cnt==0)ADD();
		else 
		{
			if(rand()&1)Erase();
			else ADD();
		}
	}
	return 0;
}
