#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const int inf=0x3f3f3f3f;
const LL mod=1e9+7;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
}
int n,K,w[N],b[N],ans;
char S[N];
inline bool check()
{
	int l=0,r=0;
	For(i,1,n)
	{
		w[i]=w[i-1]+(S[i]=='W');
		b[i]=b[i-1]+(S[i]=='B');
		if(i>=K&&b[i]-b[i-K]==0&&!l)l=i;
		if(i>=K&&w[i]-w[i-K]==0)r=i-K+1;
	}
	return l&&r&&l<r;
}
inline void dfs(int now)
{
	if(now==n+1){ans+=check();return;}
	if(S[now]=='X')
	{
		S[now]='W';
		dfs(now+1);
		S[now]='B';
		dfs(now+1);
		S[now]='X';
	}
	else dfs(now+1);
}
int main()
{
	file();
	read(n),read(K);
	scanf("%s",S+1);
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
