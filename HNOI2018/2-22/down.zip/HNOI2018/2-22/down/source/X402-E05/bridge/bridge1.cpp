#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=10010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge1.out","w",stdout);
}
int n,m,G[N][3],ans;
//0:left 1:up or down 2:right
int dfn[N],low[N],dfs_time;
inline void dfs(int u,int f)
{
	dfn[u]=low[u]=++dfs_time;
	For(i,0,2)
	if(G[u][i])
	{
		int v;
		if(i==0)v=u-1;
		if(i==2)v=u+1;
		if(i==1)v=u>n?u-n:u+n;
		if(v==f)continue;
		if(!dfn[v])
			dfs(v,u),chkmin(low[u],low[v]);
		else
			chkmin(low[u],dfn[v]);
	}
	if(low[u]==dfn[u]&&f)ans++;
}
inline void Solve()
{
	dfs_time=0;
	mem(dfn,0),mem(low,0);ans=0;
	For(i,1,n<<1)
	if(!dfn[i])dfs(i,0);

	printf("%d\n",ans);
}
int main()
{
	int type,x0,y0,x1,y1,x,y;
	file();
	read(n),read(m);
	For(i,1,n)
	{
		if(i==1)G[i][1]=G[i][2]=1;
		else if(i==n)G[i][0]=G[i][1]=1;
		else G[i][0]=G[i][1]=G[i][2]=1;
	}
	For(i,1,n)
	{
		if(i==1)G[i+n][1]=G[i+n][2]=1;
		else if(i==n)G[i+n][0]=G[i+n][1]=1;
		else G[i+n][0]=G[i+n][1]=G[i+n][2]=1;
	}
	For(i,1,m)
	{
		read(type),read(x0),read(y0),read(x1),read(y1);
		x=(x0-1)*n+y0,y=(x1-1)*n+y1;
		if(y0>y1)swap(x,y);
		if(x0==x1)G[x][2]=G[y][0]=2-type;
		if(y0==y1)G[x][1]=G[y][1]=2-type;
		Solve();
	}
	return 0;
}
