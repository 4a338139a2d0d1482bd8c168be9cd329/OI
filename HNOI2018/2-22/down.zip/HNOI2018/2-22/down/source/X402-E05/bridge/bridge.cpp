#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=400010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
}
int n,m,ans;
int cnth[N],to[N];
set<int>S,H;
set<int>::iterator it;
struct SegmentTree
{
#define lc p<<1
#define rc p<<1|1
#define ls l,mid
#define rs mid+1,r
	int Set[N<<3],t[N<<3];
	SegmentTree(){mem(Set,-1);}
	inline void pushdown(int p,int l,int r)
	{
		if(Set[p]!=-1)
		{
			int mid=(l+r)>>1;
			Set[lc]=Set[p],t[lc]=Set[p]*(mid-l+1);
			Set[rc]=Set[p],t[rc]=Set[p]*(r-mid);
			Set[p]=-1;
		}
	}
	inline void Set_tree(int l,int r,int p,int x,int y,int z)
	{
		if(x<=l&&r<=y){Set[p]=z;t[p]=z*(r-l+1);return;}
		int mid=(l+r)>>1;pushdown(p,l,r);
		if(x<=mid)Set_tree(ls,lc,x,y,z);
		if(y> mid)Set_tree(rs,rc,x,y,z);
		t[p]=t[lc]+t[rc];
	}
}T;
inline int find_right(int x,int flag)
{
	it=H.lower_bound(x);
	int up=it==H.end()?n+1:(*it);
	if(S.empty())return 0;
	it=S.upper_bound(up);
	if(it==S.begin())return 0;
	--it;
	if(*it==x)return 0;
	if(!flag)if(*it<=x)return 0;
	return *it;
}
inline int find_left(int x,int flag)
{
	int down;
	if(H.empty())down=0;
	else
	{
		it=H.lower_bound(x);
		if(it==H.begin())down=0;
		else --it,down=(*it);
	}
	if(S.empty())return 0;
	it=S.upper_bound(down);
	if(flag)
	{
		if(*it==x)return 0;
	}
	else if(*it>x)return 0;
	return *it;
}
int main()
{
	int type,x0,y0,x1,y1;
	file();
	read(n),read(m);
	For(i,1,n-1)cnth[i]=2;
	For(i,1,n)S.insert(i);
	to[1]=n,to[n]=1;
	while(m--)
	{
		read(type),read(x0),read(y0),read(x1),read(y1);
		if(x0==x1)
		{
			if(y0>y1)swap(y0,y1);
			if(type==1)
			{
				cnth[y0]++;
				T.Set_tree(1,n,1,y0,y0,cnth[y0]);
				if(cnth[y0]==2)
				{
					H.erase(y0);
					int l=find_left(y0,0),r=find_right(y0,0);
					if(l&&r&&l!=r)
					{
						if(to[l])to[to[l]]=0;
						else ans--;
						if(to[r])to[to[r]]=0;
						else ans--;
						to[l]=r,to[r]=l;
						T.Set_tree(1,n,1,l,r-1,0);
					}
				}
			}
			if(type==2)
			{
				cnth[y0]--;
				if(cnth[y0]==1)
				{
					int l=find_left(y0,0),r=find_right(y0,0);
					H.insert(y0);
					if(l&&r&&to[l]==r&&to[r]==l)
					{
						//printf("l:%d r:%d y0:%d\n",l,r,y0);
						T.Set_tree(1,n,1,l,r-1,2);
						ans+=2;
						to[l]=0,to[r]=0;
						int pos=find_right(l,1);
						//printf("posl:%d\n",pos);
						if(l<pos)
						{
							if(to[pos])to[to[pos]]=0;
							else ans--;
							to[l]=pos,to[pos]=l;
							T.Set_tree(1,n,1,l,pos-1,0);
						}
						pos=find_left(r,1);
						//printf("posr:%d\n",pos);
						if(pos&&pos<r)
						{
							if(to[pos])to[to[pos]]=0;
							else ans--;
							to[r]=pos,to[pos]=r;
							T.Set_tree(1,n,1,pos,r-1,0);
						}
						//printf("ans:%d\n",ans);
					}
				}
				T.Set_tree(1,n,1,y0,y0,cnth[y0]);
			}
		}
		if(y0==y1)
		{
			if(type==1)
			{
				S.insert(y0);
				int pos=find_left(y0,1),flag=1;
				if(pos&&to[pos]&&pos<y0&&y0<to[pos])flag=0;
				//printf("posl:%d flag:%d ",pos,flag);
				if(pos&&pos<y0&&(!to[pos]||to[pos]<y0))
				{
					if(to[pos])to[to[pos]]=0;
					else ans--;
					to[y0]=pos,to[pos]=y0;
					T.Set_tree(1,n,1,pos,y0-1,0);
					ans--;
				}
				pos=find_right(y0,1);
				if(pos&&to[pos]&&to[pos]<y0&&y0<pos)flag=0;
				//printf("posr:%d flag:%d ",pos,flag);
				if(pos&&pos>y0&&(!to[pos]||to[pos]>y0))
				{
					if(to[pos])to[to[pos]]=0;
					else ans--;
					to[y0]=pos,to[pos]=y0;
					T.Set_tree(1,n,1,y0,pos-1,0);
					ans--;
				}
				ans+=flag;
				//printf("ans:%d\n",ans);
			}
			if(type==2)
			{
				S.erase(y0);
				if(to[y0])
				{
					int pre=to[y0];to[y0]=0;
					if(pre<y0)
					{
						it=S.lower_bound(y0);--it;
						if(*it==pre)
							to[pre]=0,ans++;
						else
							to[pre]=*it,to[*it]=pre;
						T.Set_tree(1,n,1,*it,y0-1,2);
					}
					else
					{
						it=S.upper_bound(y0);
						if(*it==pre)
							to[pre]=0,ans++;
						else
							to[pre]=*it,to[*it]=pre;
						T.Set_tree(1,n,1,y0,(*it)-1,2);
					}
				}
				else 
				{
					int l=find_left(y0,1),r=find_right(y0,1);
					if(l&&r&&to[l]==r&&to[r]==l);
					else ans--;
				}
			}
		}
		//For(i,1,n)if(to[i])printf("%d to:%d\n",i,to[i]);
		printf("%d\n",T.t[1]+ans);
	}
	cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
