#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n,m,hp,mp,sp,dhp,dmp,dsp,x,t;
int A[1010],B[15],C[15],Y[15],Z[15];
int n1,n2,ans,flag;
void dfs(int round,int qx,int mo,int fn,int enemy)
{
	if(round-1>=ans)return ;
	if(enemy<=0)ans=round-1;
	if(round==n+1)return ;
	if(qx<=0)return ;
	dfs(round+1,qx-A[round],mo,min(fn+dsp,sp),enemy-x);
	if(mo>=B[1])dfs(round+1,qx-A[round],mo-B[1],fn,enemy-Y[1]);
	if(fn>=C[1])dfs(round+1,qx-A[round],mo,fn-C[1],enemy-Z[1]);
	if(qx!=hp&&min(qx+dhp,hp)-A[round]>0)dfs(round+1,min(qx+dhp,hp)-A[round],mo,fn,enemy);
	if(qx-A[round]>=0&&mo!=mp)dfs(round+1,qx-A[round],min(mo,mo+dmp),fn,enemy);
}
int main()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	read(t);
	while(t--)
	{
		ans=0x7f7f7f7f;
		flag=0;
		read(n);read(m);read(hp);read(mp);read(sp);read(dhp);read(dmp);read(dsp);read(x);
		for(int i=1;i<=n;i++)read(A[i]);
		read(n1);
		for(int i=1;i<=n1;i++)read(B[i]),read(Y[i]);
		read(n2);
		for(int i=1;i<=n2;i++)read(C[i]),read(Z[i]);
		if(n<=10&&n1==n2&&n1==1)
		{
			int now=hp;
			for(int i=1;i<=n;i++)
				now=min(hp,now+dhp)-A[i];
			if(now>0)flag=1;
			dfs(1,hp,mp,sp,m);
			if(ans==0x7f7f7f7f)printf("%s\n",flag==1?"Tie":"No");
			else printf("%s %d\n","Yes",ans);
			continue;
		}
	}
	return 0;
}
