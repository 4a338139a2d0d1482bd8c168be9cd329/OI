#include<bits/stdc++.h>
#define N 1400100
using namespace std;
inline void read(int &x) 
{ 
    x=0; 
    static int p;p=1; 
    static char c;c=getchar(); 
    while(!isdigit(c)){if(c=='-')p=-1;c=getchar();} 
    while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();} 
    x*=p; 
} 
int Fa[N];
int find(int x)
{
	return Fa[x]=Fa[x]==x?x:find(Fa[x]);
}
struct Cheater
{
	int x,y,xx,yy;
}opt[200010];
int Ans[200010];
int n,m,e,ans;
int to[N],beg[N],nex[N],vis[N],fa[N],bri[N];
bool ban[N];
typedef pair<int,int> pi;
map<pi,int>bh,bbh;
void add(int x,int y)
{
    to[++e]=y;
    nex[e]=beg[x];
    beg[x]=e;
	bbh[pi(x,y)]=e;
}
int clk;
int dfn[N],low[N],xjb=0;
void dfs(int u)
{
    int child=0;
    dfn[u]=low[u]=++clk;
    vis[u]=xjb;
    for(int i=beg[u];i;i=nex[i])
    {
		if(ban[i])continue;
        int y=to[i];
        if(vis[y]!=xjb)
        {
            child++;
            fa[y]=u;
            dfs(y);
            low[u]=min(low[u],low[y]);
			if(low[y]>dfn[u])ans++;
        }
        else if(y!=fa[u]) low[u]=min(low[u],dfn[y]);
    }
}
int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	read(n);read(m);
	int cnt=0;
	for(int i=1;i<=2;i++)
		for(int j=1;j<=n;j++)
			bh[pi(i,j)]=++cnt;
	for(int i=1;i<n;i++)
	{
		static int x,y,z,s;
		x=bh[pi(1,i)];y=bh[pi(1,i+1)];z=bh[pi(2,i)];s=bh[pi(2,i+1)];
		add(x,y);add(y,x);
		add(z,s);add(s,z);
		add(x,z);add(z,x);
	}
	add(bh[pi(1,n)],bh[pi(2,n)]);add(bh[pi(2,n)],bh[pi(1,n)]);
	for(int i=1;i<=n;i++)
		if(!vis[i]){fa[i]=-1;dfs(i);}
	for(int i=1;i<=m;i++)
	{
		static int q,x,y,xx,yy;
		read(q);read(x);read(y);read(xx);read(yy);
		if(q==1)
		{
			if(!bh.count(pi(x,y)))bh[pi(x,y)]=++cnt;
			if(!bh.count(pi(xx,yy)))bh[pi(xx,yy)]=++cnt;
			add(bh[pi(x,y)],bh[pi(xx,yy)]);add(bh[pi(xx,yy)],bh[pi(x,y)]);
		}
		else if(q==2)
		{
			ban[bbh[pi(bh[pi(x,y)],bh[pi(xx,yy)])]]=true;
			ban[bbh[pi(bh[pi(xx,yy)],bh[pi(x,y)])]]=true;
		}
		ans=0;clk=0;
		xjb++;
		for(int j=1;j<=cnt;j++)
			if(vis[j]!=xjb){fa[j]=-1;dfs(j);}
		printf("%d\n",ans);
	}
	return 0;
	/*	else
		{
		int cnt=0;
		for(int i=1;i<=2;i++)
		for(int j=1;j<=n;j++)
		bh[pi(i,j)]=++cnt;
		for(int i=1;i<=cnt;i++)Fa[i]=i;
		for(int i=1;i<=m;i++)
		{
		static int q;
		read(q);read(opt[i].x);read(opt[i].y);read(opt[i].xx);read(opt[i].yy);
		bbh[pi(bh[pi(opt[i].x,opt[i].y)],bh[pi(opt[i].xx,opt[i].yy)])]=1;
		bbh[pi(bh[pi(opt[i].xx,opt[i].yy)],bh[pi(opt[i].x,opt[i].y)])]=1;
		}
		for(int i=1;i<n;i++)
		{
		static int x,y,z,s;
		static int fx,fy;
		x=bh[pi(1,i)];y=bh[pi(1,i+1)];z=bh[pi(2,i)];s=bh[pi(2,i+1)];
		if(!bbh.count(pi(x,y)))
		{
		add(x,y);add(y,x);
		fx=find(x);fy=find(y);
		if(fx!=fy)fa[fx]=fy;
		}
		if(!bbh.count(pi(z,s)))
		{
		add(z,s);add(s,z);
		fx=find(z);fy=find(s);
		if(fx!=fy)fa[fx]=fy;
		}
		if(!bbh.count(pi(x,z)))
		{
		add(x,z);add(z,x);
		fx=find(x);fy=find(z);
		if(fx!=fy)fa[fx]=fy;
		}
		}
		if(!bbh.count(pi(bh[pi(1,n)],bh[pi(2,n)])))
		{
		add(bh[pi(1,n)],bh[pi(2,n)]);add(bh[pi(2,n)],bh[pi(1,n)]);
		static int fx,fy;
		fx=find(bh[pi(1,n)]);fy=find(bh[pi(2,n)]);
		if(fx!=fy)fa[fx]=fy;
		}
		xjb++;
		for(int i=1;i<=cnt;i++)
		if(vis[i]!=xjb){fa[i]=-1;dfs(i);}
		Ans[m+1]=ans;
		for(int i=m;i>=1;i--)
		{
		static int x,y,fx,fy;
		x=bh[pi(opt[i].x,opt[i].y)];y=bh[pi(opt[i].xx,opt[i].yy)];
		fx=find(x);fy=find(y);
		if(fx!=fy)Ans[i]=Ans[i+1]+1,fa[fx]=fy;
		else Ans[i]=Ans[i+1];
		}
		for(int i=2;i<=m+1;i++)
		printf("%d\n",Ans[i]);
		}
	 */
	return 0; 
}
