#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const int mod=1000000007;
int n,k;
char s[1000010];
int ans;
bool pd(int x)
{
	for(int i=x+1;i<=x+k-1;i++)
	if(s[i]!=s[x])return 0;
	return 1;
}
void dfs(int x)
{
	if(x==n+1)
	{
		int flag1=0x7f7f7f7f,flag2=0;
		for(int i=1;i<=n;i++)
			if(s[i]=='B'&&pd(i))flag1=min(flag1,i);
		for(int i=1;i<=n;i++)
			if(s[i]=='W'&&pd(i))flag2=max(flag2,i);
		if(flag1<flag2)ans++;
		return ;
	}
	if(s[x]=='X')
	{
		s[x]='W';
		dfs(x+1);
		s[x]='B';
		dfs(x+1);
		s[x]='X';
	}
	else dfs(x+1);
}
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	read(n);read(k);
	scanf("%s",s+1);
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
