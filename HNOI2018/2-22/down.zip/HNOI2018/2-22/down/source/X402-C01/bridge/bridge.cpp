/************************************************
 * Au: Hany01
 * Date: Feb 22th, 2018
 * Prob: bridge
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
typedef set<int>::iterator It;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("bridge.in", "r", stdin);
    freopen("bridge.out", "w", stdout);
}

const int maxn = 200005;

set<int> S;
PII bel, bel1;
int n, m, Ans, L, R;

struct Fenwick_Tree
{
	int c[maxn];
	inline int lb(int x) { return x & -x; }
	inline void update(int pos, int dt) { for ( ; pos <= n; pos += lb(pos)) c[pos] += dt; }
	inline int query(int pos) { int Ans = 0; for ( ; pos; pos -= lb(pos)) Ans += c[pos]; return Ans; }
	inline int query(int l, int r) { return query(r) - query(l - 1); }
}FT;

PII pos(int x) {
	It it = S.upper_bound(x);
	It it1 = it;
	-- it1;
	return mp(*it1, (*it) - 1);
}

inline bool isfengbi(int l, int r) {
	return FT.query(l, r) == (r - l + 1) * 2 && (l != 1 || L) && (r != n - 1 || R);
}

inline bool isjustkai(int l, int r) {
	int Sum = FT.query(l, r) + 2;
	if (l == 1 && !L) -- Sum;
	if (r == n - 1 && !R) -- Sum;
	return Sum == (r - l + 1) * 2 + 1;
}

inline bool iskai(int l, int r) {
	return FT.query(l, r) < (r - l + 1) * 2 || (l == 1 && !L) || (r == n - 1 && !R);
}

int main()
{
    File();
	register int x1, y1, x2, y2, type;
	n = read(), m = read();
	For(i, 1, n) S.insert(i);
	For(i, 1, n - 1) FT.update(i, 2);
	L = R = 1;
	while (m --) {
		type = read(), x1 = read(), y1 = read(), x2 = read(), y2 = read();
		if (x1 > x2 || y1 > y2) swap(x1, x2), swap(y1, y2);
		if (type == 1 && y1 < y2) {
			FT.update(y1, 1), ++ Ans;
			bel = pos(y1);
			if (isfengbi(bel.fir, bel.sec)) {
				Ans -= (bel.sec - bel.fir + 1) * 2;
				int e = bel.fir;
				if (e != 1) {
					bel1 = pos(e - 1);
					if (iskai(bel1.fir, bel1.sec)) -- Ans;
				} else -- Ans;
				e = bel.sec + 1;
				if (e != n) {
					bel1 = pos(e);
					if (iskai(bel1.fir, bel1.sec)) -- Ans;
				} else -- Ans;
			}
		} else if (type == 2 && y1 < y2) {
			FT.update(y1, -1), -- Ans;
			bel = pos(y1);
			if (isjustkai(bel.fir, bel.sec)) {
				Ans += (bel.sec - bel.fir + 1) * 2;
				int e = bel.fir;
				if (e != 1) {
					bel1 = pos(e - 1);
					if (iskai(bel1.fir, bel1.sec)) ++ Ans;
				} else ++ Ans;
				e = bel.sec + 1;
				if (e != n) {
					bel1 = pos(e);
					if (iskai(bel1.fir, bel1.sec)) ++ Ans;
				} else ++ Ans;
			}
		} else if (type == 1) {
			if (y1 == 1) {
				L = 1; ++ Ans;
				bel = pos(1);
				if (isfengbi(bel.fir, bel.sec)) {
					Ans -= (bel.sec - bel.fir + 1) * 2 + 1;
					int e = bel.sec + 1;
					if (e != n) {
						bel1 = pos(e);
						if (iskai(bel1.fir, bel1.sec)) -- Ans;
					} else -- Ans;
				}
			} else if (y1 == n) {
				R = 1; ++ Ans;
				bel = pos(n - 1);
				if (isfengbi(bel.fir, bel.sec)) {
					Ans -= (bel.sec - bel.fir + 1) * 2 + 1;
					int e = bel.fir;
					if (e != 1) {
						bel1 = pos(e - 1);
						if (iskai(bel1.fir, bel1.sec)) -- Ans;
					} else -- Ans;
				}
			} else {
				S.insert(y1);
				bel = pos(y1 - 1), bel1 = pos(y1);
				bool f1 = isfengbi(bel.fir, bel.sec), f2 = isfengbi(bel1.fir, bel1.sec);
				if (!f1 && !f2) ++ Ans;
				else if (!f1 && f2) {
					Ans -= (bel1.sec - bel1.fir + 1) * 2;
					int e = bel1.sec + 1;
					if (e != n) {
						PII bel2 = pos(e);
						if (iskai(bel2.fir, bel2.sec)) -- Ans;
					} else -- Ans;
				}
				else if (f1 && !f2) {
					Ans -= (bel.sec - bel.fir + 1) * 2;
					int e = bel.fir;
					if (e != 1) {
						PII bel2 = pos(e - 1);
						if (iskai(bel2.fir, bel2.sec)) -- Ans;
					} else -- Ans;
				}
			}
		} else {
			if (y1 == 1) {
				L = 0; -- Ans;
				bel = pos(1);
				if (isjustkai(bel.fir, bel.sec)) {
					Ans += (bel.sec - bel.fir + 1) * 2 + 1;
					int e = bel.sec + 1;
					if (e != n) {
						bel1 = pos(e);
						if (iskai(bel1.fir, bel1.sec)) ++ Ans;
					} else ++ Ans;
				}
			} else if (y1 == n) {
				R = 0; -- Ans;
				bel = pos(n - 1);
				if (isjustkai(bel.fir, bel.sec)) {
					Ans += (bel.sec - bel.fir + 1) * 2 + 1;
					int e = bel.fir;
					if (e != 1) {
						bel1 = pos(e - 1);
						if (iskai(bel1.fir, bel1.sec)) ++ Ans;
					} else ++ Ans;
				}
			} else {
				bel = pos(y1 - 1), bel1 = pos(y1);
				bool f1 = isfengbi(bel.fir, bel.sec), f2 = isfengbi(bel1.fir, bel1.sec);
				if (!f1 && !f2) -- Ans;
				else if (!f1 && f2) {
					Ans += (bel1.sec - bel1.fir + 1) * 2;
					int e = bel1.sec + 1;
					if (e != n) {
						PII bel2 = pos(e);
						if (iskai(bel2.fir, bel2.sec)) ++ Ans;
					} else ++ Ans;
				}
				else if (f1 && !f2) {
					Ans += (bel.sec - bel.fir + 1) * 2;
					int e = bel.fir;
					if (e != 1) {
						PII bel2 = pos(e - 1);
						if (iskai(bel2.fir, bel2.sec)) ++ Ans;
					} else ++ Ans;
				}
				S.erase(y1);
			}
		}
		printf("%d\n", Ans);
	}
    return 0;
}
