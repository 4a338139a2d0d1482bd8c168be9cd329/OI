/*
Author: CNYALI_LK
LANG: C++
PROG: boss.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}

int t,n,m,hp,mp,sp,dhp,dmp,dsp,x,n1,n2;
int f[2][128][128][128];
int a[102424],b[102424],c[102424],y[102424],z[102424];
void getans(){
	for(int i=1;i<=n;++i){
		memset(f[(i&1)^1],0xcc,sizeof(f[(i&1)^1]));
		for(int j=1;j<=hp;++j){
			for(int k=0;k<=mp;++k){
				for(int l=0;l<=sp;++l)if(f[i&1][j][k][l]!=0xcccccccc){
					chkmax(f[(i&1)^1][max(min(j+dhp,hp)-a[i],0)][k][l],f[i&1][j][k][l]);
					chkmax(f[(i&1)^1][max(j-a[i],0)][min(k+dmp,mp)][l],f[i&1][j][k][l]);
					if(f[i&1][j][k][l]+x>=m){printf("Yes %d\n",i);return;}
					chkmax(f[(i&1)^1][max(j-a[i],0)][k][min(l+dsp,sp)],f[i&1][j][k][l]+x);
					for(int t=1;t<=n1;++t)
						if(k>=b[t])
							if(f[i&1][j][k][l]+y[t]>=m){
								printf("Yes %d\n",i);
								return;
							}else{
								chkmax(f[(i&1)^1][max(j-a[i],0)][k-b[t]][l],f[i&1][j][k][l]+y[t]);
							}
					for(int t=1;t<=n2;++t)
						if(l>=c[t])
							if(f[i&1][j][k][l]+z[t]>=m){
								printf("Yes %d\n",i);
								return;
							}else{
								chkmax(f[(i&1)^1][max(j-a[i],0)][k][l-c[t]],f[i&1][j][k][l]+z[t]);
							}	
				}
			}
		}
	}
	for(int j=1;j<=hp;++j)for(int k=0;k<=mp;++k)for(int l=0;l<=sp;++l)if(f[(n+1)&1][j][k][l]!=0xcccccccc){printf("Tie\n");return;}
	printf("No\n");
}
int main(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	t=read();
	while(t){
		--t;
		n=read(),m=read(),hp=read(),mp=read(),sp=read(),dhp=read(),dmp=read(),dsp=read(),x=read();
		for(int i=1;i<=n;++i)a[i]=read();
		n1=read();
		for(int i=1;i<=n1;++i)b[i]=read(),y[i]=read();
		n2=read();	
		for(int i=1;i<=n2;++i)c[i]=read(),z[i]=read();
		memset(f,0xcc,sizeof(f));
		f[1][hp][mp][sp]=0;
		getans();
	}
	return 0;
}

