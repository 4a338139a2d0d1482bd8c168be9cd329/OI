#include<bits/stdc++.h>
using namespace std;

const int maxn=2e5+10;
int n,m,e,onring;
bool a[maxn][2],b[maxn],flag[maxn][2];
int sum[maxn<<2],stl[maxn<<2],str[maxn<<2];

void build(int rt,int l,int r){
	sum[rt]=(r-l+1)*2;
	stl[rt]=l;
	str[rt]=r;
	if(l==r){
		a[l][0]=a[l][1]=b[l]=true;
		return;
	}
	int mid=l+r>>1;
	build(rt<<1,l,mid);
	build(rt<<1|1,mid+1,r);
}
void modifya(int rt,int l,int r,int pos,int poss){
	if(l==r){
		a[pos][poss]^=1;
		sum[rt]=a[pos][0]+a[pos][1];
		return;
	}
	int mid=l+r>>1;
	if(pos<=mid)
		modifya(rt<<1,l,mid,pos,poss);
	else
		modifya(rt<<1|1,mid+1,r,pos,poss);
	sum[rt]=sum[rt<<1]+sum[rt<<1|1];
}
int findsum(int rt,int l,int r,int x,int y){
	if(l==x&&r==y)
		return sum[rt];
	int mid=l+r>>1;
	if(y<=mid)
		return findsum(rt<<1,l,mid,x,y);
	else if(x>mid)
		return findsum(rt<<1|1,mid+1,r,x,y);
	else
		return findsum(rt<<1,l,mid,x,mid)+findsum(rt<<1|1,mid+1,r,mid+1,y);
}
inline int findsum(int l,int r){
	if(l<r)
		return findsum(1,1,n,l,r-1);
	else
		return 0;
}
void modifyb(int rt,int l,int r,int pos){
	if(l==r){
		b[pos]^=1;
		stl[rt]=str[rt]=b[pos]?pos:0;
		return;
	}
	int mid=l+r>>1;
	if(pos<=mid)
		modifyb(rt<<1,l,mid,pos);
	else
		modifyb(rt<<1|1,mid+1,r,pos);
	stl[rt]=stl[rt<<1]?stl[rt<<1]:stl[rt<<1|1];
	str[rt]=str[rt<<1|1]?str[rt<<1|1]:str[rt<<1];
}
int findleft(int rt,int l,int r,int pos){
	if(pos==r)
		return str[rt];
	int mid=l+r>>1;
	if(pos<=mid)
		return findleft(rt<<1,l,mid,pos);
	int tmp=findleft(rt<<1|1,mid+1,r,pos);
	if(tmp)
		return tmp;
	else
		return findleft(rt<<1,l,mid,mid);
}
inline int findleft(int pos){
	if(pos>1)
		return findleft(1,1,n,pos-1);
	else
		return 0;
}
int findright(int rt,int l,int r,int pos){
	if(pos==l)
		return stl[rt];
	int mid=l+r>>1;
	if(pos>mid)
		return findright(rt<<1|1,mid+1,r,pos);
	int tmp=findright(rt<<1,l,mid,pos);
	if(tmp)
		return tmp;
	else
		return findright(rt<<1|1,mid+1,r,mid+1);
}
inline int findright(int pos){
	if(pos<n)
		return findright(1,1,n,pos+1);
	else
		return 0;
}
inline void update2(int l,int r,int x,int y){
	if(findsum(l,r)==2*(r-l))
		onring-=2*(r-l);
	if(flag[l][0]||flag[l][1])
		--onring;
	if(flag[r][0]||flag[r][1])
		--onring;
	modifya(1,1,n,y,x);
	if(findsum(l,r)==2*(r-l)){
		onring+=2*(r-l);
		flag[l][1]=flag[r][0]=true;
	}
	else
		flag[l][1]=flag[r][0]=false;
	if(flag[l][0]||flag[l][1])
		++onring;
	if(flag[r][0]||flag[r][1])
		++onring;
}
inline void add2(int l,int r,int y){
	if(l==y){
		if(flag[r][1])
			--onring;
	}
	else{
		if(flag[l][0])
			--onring;
	}
	modifyb(1,1,n,y);
	if(findsum(l,r)==2*(r-l)){
		onring+=2*(r-l);
		flag[l][1]=flag[r][0]=true;
	}
	else
		flag[l][1]=flag[r][0]=false;
	if(flag[l][0]||flag[l][1])
		++onring;
	if(flag[r][0]||flag[r][1])
		++onring;
}
inline void del2(int l,int r,int y){
	if(findsum(l,r)==2*(r-l))
		onring-=2*(r-l);
	if(flag[l][0]||flag[l][1])
		--onring;
	if(flag[r][0]||flag[r][1])
		--onring;
	modifyb(1,1,n,y);
	flag[l][1]=flag[r][0]=false;
	if(y==l){
		if(flag[r][1])
			++onring;
	}
	else{
		if(flag[l][0])
			++onring;
	}
}
inline void add3(int l,int y,int r){
	if(findsum(l,r)==2*(r-l))
		onring-=2*(r-l);
	if(flag[l][0]||flag[l][1])
		--onring;
	if(flag[r][0]||flag[r][1])
		--onring;
	modifyb(1,1,n,y);
	if(findsum(l,y)==2*(y-l)){
		onring+=2*(y-l);
		flag[l][1]=flag[y][0]=true;
	}
	else
		flag[l][1]=flag[y][0]=false;
	if(findsum(y,r)==2*(r-y)){
		onring+=2*(r-y);
		flag[y][1]=flag[r][0]=true;
	}
	else
		flag[y][1]=flag[r][0]=false;
	if(flag[l][0]||flag[l][1])
		++onring;
	if(flag[y][0]||flag[y][1])
		++onring;
	if(flag[r][0]||flag[r][1])
		++onring;
}
inline void del3(int l,int y,int r){
	if(findsum(l,y)==2*(y-l))
		onring-=2*(y-l);
	if(findsum(y,r)==2*(r-y))
		onring-=2*(r-y);
	if(flag[l][0]||flag[l][1])
		--onring;
	if(flag[y][0]||flag[y][1])
		--onring;
	if(flag[r][0]||flag[r][1])
		--onring;
	modifyb(1,1,n,y);
	if(findsum(l,r)==2*(r-l)){
		onring+=2*(r-l);
		flag[l][1]=flag[r][0]=true;
	}
	else
		flag[l][1]=flag[r][0]=false;
	if(flag[l][0]||flag[l][1])
		++onring;
	if(flag[r][0]||flag[r][1])
		++onring;
}

int main(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==1){
		for(int i=0;i<m;++i)
			printf("%d\n",i&1);
		return 0;
	}
	e=3*n-2;
	build(1,1,n);
	onring=e;
	for(int i=1;i<n;++i)
		flag[i][1]=flag[i+1][0]=1;
	while(m--){
		int type,x1,y1,x2,y2;
		scanf("%d%d%d%d%d",&type,&x1,&y1,&x2,&y2);
		if(type==1)
			++e;
		else
			--e;
		if(x1==x2){
			int x=x1-1,y=y1<y2?y1:y2;
			int l=findleft(y+1),r=findright(y);
			if(l&&r)
				update2(l,r,x,y);
			else
				modifya(1,1,n,y,x);
		}
		else if(type==1){
			int y=y1;
			int l=findleft(y),r=findright(y);
			if(l&&r)
				add3(l,y,r);
			else if(l)
				add2(l,y,y);
			else if(r)
				add2(y,r,y);
			else
				modifyb(1,1,n,y);
		}
		else{
			int y=y1;
			int l=findleft(y),r=findright(y);
			if(l&&r)
				del3(l,y,r);
			else if(l)
				del2(l,y,y);
			else if(r)
				del2(y,r,y);
			else
				modifyb(1,1,n,y);
			flag[y][0]=flag[y][1]=false;
		}
		printf("%d\n",e-onring);
	}
	return 0;
}
