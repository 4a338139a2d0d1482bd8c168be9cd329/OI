#include<bits/stdc++.h>
using namespace std;

const int maxn=2e5+10;
int n,a[maxn][2],b[maxn];

int main(){
	int seed;
	srand(seed=time(NULL)+clock()*clock()*clock());
	cerr<<seed<<endl;
	freopen("bridge.in","w",stdout);
	int n=50,m=1000;
	n-=rand()%n;
	m-=rand()%m;
//	n=m=2e5;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;++i)
		b[i]=1;
	for(int i=1;i<n;++i)
		a[i][0]=a[i][1]=1;
	while(m--){
		int x1=rand()%2+1,y1=rand()%n+1,x2,y2;
		if(rand()%3==0)
			x2=3-x1,y2=y1;
		else if(rand()%2==0)
			x2=x1,y2=y1-1;
		else
			x2=x1,y2=y1+1;
		if(y2==0||y2>n){
			++m;continue;
		}
		if(x1==x2){
			if(a[y1<y2?y1:y2][x1-1]^=1)
				printf("1 ");
			else
				printf("2 ");
		}
		else{
			if(b[y1]^=1)
				printf("1 ");
			else
				printf("2 ");
		}
		printf("%d %d %d %d\n",x1,y1,x2,y2);
	}
	return 0;
}
