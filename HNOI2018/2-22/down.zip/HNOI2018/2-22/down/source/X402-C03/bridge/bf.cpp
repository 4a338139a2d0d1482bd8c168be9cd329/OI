#include<bits/stdc++.h>
using namespace std;

const int maxn=2e5+10;
int n,m,e;
bool a[maxn][2],b[maxn];

int fa[maxn<<1];
int findfa(int x){
	if(fa[x]==x)return x;
	return fa[x]=findfa(fa[x]);
}
int calc(){
	for(int i=1;i<=2*n;++i)
		fa[i]=i;
	for(int i=1;i<n;++i)
		for(int j=0;j<2;++j)
			if(a[i][j])
				fa[findfa(i+j*n)]=findfa(i+1+j*n);
	for(int i=1;i<=n;++i)
		if(b[i])
			fa[findfa(i)]=findfa(i+n);
	int res=0;
	for(int i=1;i<=2*n;++i)
		if(findfa(i)==i)
			++res;
	return res;
}

int main(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.txt","w",stdout);
	scanf("%d%d",&n,&m);
	e=3*n-2;
	for(int i=1;i<n;++i)
		a[i][0]=a[i][1]=1;
	for(int i=1;i<=n;++i)
		b[i]=1;
	while(m--){
		int x1,y1,x2,y2;
		scanf("%*d%d%d%d%d",&x1,&y1,&x2,&y2);
		if(x1==x2)
			a[y1<y2?y1:y2][x1-1]^=1;
		else
			b[y1]^=1;
		int now=calc(),ans=0;
		for(int i=1;i<n;++i)
			for(int j=0;j<2;++j)
				if(a[i][j]){
					a[i][j]=false;
					if(calc()!=now)
						++ans;
					a[i][j]=true;
				}
		for(int i=1;i<=n;++i)
			if(b[i]){
				b[i]=false;
				if(calc()!=now)
					++ans;
				b[i]=true;
			}
		printf("%d\n",ans);
	}
	return 0;
}
