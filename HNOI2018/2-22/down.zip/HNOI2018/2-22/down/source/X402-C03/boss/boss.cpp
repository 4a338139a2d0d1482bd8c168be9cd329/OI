#include<bits/stdc++.h>
using namespace std;

const int maxn=1e3+5,maxa=1e3+5,inf=1e9;
int t,n,m,hp,mp,sp,dhp,dmp,dsp,x,a[maxn],n1,b[maxn],y[maxn],n2,c[maxn],z[maxn];
int days,dp[2][maxa][maxa],dpp[2][maxa];
int f1[maxn],f2[maxn],f[maxn];

inline int min_(int a,int b){return a<=b?a:b;}
inline int max_(int a,int b){return a>=b?a:b;}
inline void chkmin(int&a,int b){if(a>b)a=b;}
inline void chkmax(int&a,int b){if(a<b)a=b;}

void judge(){
	int blood=hp;
	for(int i=1;i<=n;++i){
		blood=min_(hp,blood+dhp);
		if(blood<=a[i]){
			puts("No");
			return;
		}
		blood-=a[i];
	}
	puts("Tie");
}
void work(){
	days=0;
	memset(f1,0,sizeof(f1));
	memset(dpp[0],0,sizeof(dpp[0]));
	for(int i=1;i<=n;++i){
		memset(dpp[i&1],0,sizeof(dpp[i&1]));
//	cerr<<f1[0]<<endl;
		for(int j=0;j<=sp;++j){
//	cerr<<f1[0]<<endl;
			chkmax(dpp[i&1][min_(j+dsp,sp)],dpp[i&1^1][j]+x);
			for(int k=1;k<=n2;++k)
				if(j>=c[k])
					chkmax(dpp[i&1][j-c[k]],dpp[i&1^1][j]+z[k]);
		}
		for(int j=0;j<=sp;++j)
			chkmax(f1[i],dpp[i&1][j]);
	}
	memset(f2,0,sizeof(f2));
	memset(dpp[0],0,sizeof(dpp[0]));
	for(int i=1;i<=n;++i){
		memset(dpp[i&1],0,sizeof(dpp[i&1]));
		for(int j=0;j<=mp;++j){
			chkmax(dpp[i&1][min_(j+dmp,mp)],dpp[i&1^1][j]);
			for(int k=1;k<=n1;++k)
				if(j>=b[k])
					chkmax(dpp[i&1][j-b[k]],dpp[i&1^1][j]+y[k]);
		}
		for(int j=0;j<=mp;++j)
			chkmax(f2[i],dpp[i&1][j]);
	}
	memset(f,0,sizeof(f));
	for(int i=1;i<=n;++i)
		for(int j=0;j<=i;++j)
			if(f1[j]+f2[i-j]>=m){
				days=i;
				return;
			}
	days=-1;
}

int main(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%d%d%d%d%d%d%d%d",&n,&m,&hp,&mp,&sp,&dhp,&dmp,&dsp,&x);
		for(int i=1;i<=n;++i)
			scanf("%d",&a[i]);
		scanf("%d",&n1);
		for(int i=1;i<=n1;++i)
			scanf("%d%d",&b[i],&y[i]);
		scanf("%d",&n2);
		for(int i=1;i<=n2;++i)
			scanf("%d%d",&c[i],&z[i]);
		work();
/*		for(int j=0;j<=mp;++j)
			for(int k=0;k<=sp;++k)
				dp[0][j][k]=inf;
		dp[0][mp][sp]=m;
		for(int i=1;i<=n;++i){
			for(int k=0;k<=mp;++k)
				for(int l=0;l<=sp;++l)
					dp[i&1][k][l]=inf;
			for(int k=0;k<=mp;++k)
				for(int l=0;l<=sp;++l)
					if(dp[i&1^1][k][l]<inf){
						chkmin(dp[i&1][k][min_(sp,l+dsp)],dp[i&1^1][k][l]-x);
						for(int w=1;w<=n1;++w)
							if(k>=b[w])
								chkmin(dp[i&1][k-b[w]][l],dp[i&1^1][k][l]-y[w]);
						for(int w=1;w<=n2;++w)
							if(l>=c[w])
								chkmin(dp[i&1][k][l-c[w]],dp[i&1^1][k][l]-z[w]);
						chkmin(dp[i&1][min_(mp,k+dmp)][l],dp[i&1^1][k][l]);
					}
			for(int k=0;k<=mp;++k)
				for(int l=0;l<=sp;++l)
					if(dp[i&1][k][l]<=0){
						days=i;
						goto done;
					}
		}
		judge();
		continue;
done:*/
		if(days==-1){
			judge();
			continue;
		}
		for(int i=0;i<=hp;++i)
			dpp[0][i]=0;
		for(int i=1;i<=n;++i){
			for(int j=0;j<=hp;++j)
				dpp[i&1][j]=0;
			for(int j=1;j<=hp;++j){
				chkmax(dpp[i&1][max_(0,j-a[i])],dpp[i&1^1][j]+1);
				chkmax(dpp[i&1][max_(0,min_(hp,j+dhp)-a[i])],dpp[i&1^1][j]);
			}
			for(int j=0;j<=hp;++j)
				if(dpp[i&1][j]>=days){
					days=i;
					goto donee;
				}
		}
		judge();
		continue;
donee:
		if(days<=n)
			printf("Yes %d\n",days);
		else
			judge();
	}
	return 0;
}
