#include<bits/stdc++.h>
using namespace std;

const int maxn=1e6+10,mod=1e9+7;
int n,k;
char s[maxn];
int dp[2][maxn<<1];

int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	scanf("%d%d%s",&n,&k,s);
	dp[0][0]=1;
	for(int i=0;i<n;++i){
		for(int j=0;j<=(k<<1);++j)
			dp[i&1^1][j]=0;
		if(s[i]!='W'){
			for(int j=0;j<k;++j)
				(dp[i&1^1][j+1]+=dp[i&1][j])%=mod;
			for(int j=k;j<k<<1;++j)
				(dp[i&1^1][k]+=dp[i&1][j])%=mod;
			(dp[i&1^1][k<<1]+=dp[i&1][k<<1])%=mod;
		}
		if(s[i]!='B'){
			for(int j=0;j<k;++j)
				(dp[i&1^1][0]+=dp[i&1][j])%=mod;
			for(int j=k;j<k<<1;++j)
				(dp[i&1^1][j+1]+=dp[i&1][j])%=mod;
			(dp[i&1^1][k<<1]+=dp[i&1][k<<1])%=mod;
		}
	}
	printf("%d\n",dp[n&1][k<<1]);
	return 0;
}
