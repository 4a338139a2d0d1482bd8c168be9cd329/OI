#include<cstdio>
#include<algorithm>
using namespace std;
const int mod=1000000007;
int n,k,ans=0,a[100012];
char s[100012];
int dp[2012][5][5][2012];

int check(){
	int okb=0,okw=0,num,pos=1;
	num=0;
	for (int i=1;i<=n;i++)
	{
	  if (s[i]=='B')
	    num++;
	  if (s[i]=='W')
	    num=0;
	  if (num>=k)
	  {
	  	okb=1;
	  	pos=i;
	  	break;
	  }
	}
	num=0;
	for (int i=pos+1;i<=n;i++)
	{
	  if (s[i]=='W')
	    num++;
	  if (s[i]=='B')
	    num=0;
	  if (num>=k)
	  {
	  	okw=1;
	  	break;
	  }
	}
	if (okb==1&&okw==1)
	  return 1;
	return 0;
}

void doing(int pos){
	if (pos==n+1)
	{
	  if (check())
	    ans++;
	  return ;
	}
	if (s[pos]!='X')
	{
	  doing(pos+1);
	  return ;
	}
	s[pos]='W';
	doing(pos+1);
	s[pos]='B';
	doing(pos+1);
	s[pos]='X';
}

int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	scanf("%d%d",&n,&k);
	scanf("%s",s+1);
	if (n<=100)
	{
	  doing(1);
	  printf("%d\n",ans);
	}
	else
	{
	  int w=k;
	for (int i=1;i<=n;i++)
	{
	  if (s[i]=='B')
	    a[i]=0;
	  if (s[i]=='W')
	    a[i]=1;
	  if (s[i]=='X')
	    a[i]=-1;
	}
	if (s[1]=='B')
	  dp[1][0][0][1]=1;
	if (s[1]=='W')
	  dp[1][0][1][1]=1;
	for (int i=1;i<=n-1;i++)
	  for (int j=0;j<=3;j++)
	    for (int k=0;k<=1;k++)
	      for (int l=1;l<=i;l++)
	      {
			if (l+1>=w)
			{
			  if (j+k+1<=3)
			  {
			    if (a[i+1]==k||a[i+1]==-1)
				  dp[i+1][j+k+1][k][l+1]=(dp[i+1][j+k+1][k][l+1]+dp[i][j][k][l])%mod;
			    if (a[i+1]==1-k||a[i+1]==-1)
				  dp[i+1][j+1][1-k][1]=(dp[i+1][j+1][1-k][1]+dp[i][j][k][l])%mod;
			  }
			  else
			  {
			    if (a[i+1]==k||a[i+1]==-1)
				  dp[i+1][j][k][l+1]=(dp[i+1][j][k][l+1]+dp[i][j][k][l])%mod;
			    if (a[i+1]==1-k||a[i+1]==-1)
				  dp[i+1][j][1-k][1]=(dp[i+1][j][1-k][1]+dp[i][j][k][l])%mod;
			  }
			}
			else
			{
			  if (a[i+1]==k||a[i+1]==-1)
			    dp[i+1][j][k][l+1]=(dp[i+1][j][k][l+1]+dp[i][j][k][l])%mod;
			  if (a[i+1]==1-k||a[i+1]==-1)
			    dp[i+1][j][1-k][1]=(dp[i+1][j][1-k][1]+dp[i][j][k][l])%mod;
			}
		  }
	for (int k=0;k<=1;k++)
	  for (int l=1;l<=n;l++)
	    printf("%d\n",dp[n][3][k][l]),ans=(ans+dp[n][3][k][l])%mod;
	printf("%d\n",ans);
	}
	return 0;
}
