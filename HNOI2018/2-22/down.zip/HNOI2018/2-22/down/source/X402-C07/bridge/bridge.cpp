#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;

int n,m;
bool q[6006][6006],f[6006][6006],vis[6012];
vector <int> vecx,vecy;

int g(int a,int b){
	if (a==1)
	  return b;
	if (a==2)
	  return n+b;
}

void add(int a,int b,int k){
	q[a][b]=k;
	f[b][a]=k;
}

void dfs1(int x,int y){
	if (vis[g(x,y)])
	  return ;
	vis[g(x,y)]=1;
	if (q[g(x,y)][g(3-x,y)])
	  dfs1(3-x,y);
	if (q[g(x,y)][g(x,y-1)])
	  dfs1(x,y-1);
	if (q[g(x,y)][g(x,y+1)])
	  dfs1(x,y+1);
	vecx.push_back(x);
	vecy.push_back(y);
}

void dfs2(int x,int y){
	if (vis[g(x,y)])
	  return ;
	vis[g(x,y)]=1;
	if (f[g(x,y)][g(3-x,y)])
	  dfs1(3-x,y);
	if (f[g(x,y)][g(x,y-1)])
	  dfs1(x,y-1);
	if (f[g(x,y)][g(x,y+1)])
	  dfs1(x,y+1);
}

int main(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	scanf("%d%d",&n,&m);
/*	for (int i=1;i<=n-1;i++)
	{
	  add(g(1,i),g(1,i+1),1);
	  add(g(2,i+1),(g(2,i),1);
	  add(g(1,i),g(2,i),1);
	  add(g(2,i),g(1,i),0);
	  fadd(g(1,i+1),g(1,i),1);
	  fadd(g(2,i),g(2,i+1),1);
	  fadd(g(2,i),g(1,i),1);
	  fadd(g(1,i),g(2,i),0);
	  a[i]=1,b[i]=1,c[i]=1;
	}
	c[n]=1;
	add(g(1,n),g(2,n),1);
	add(g(2,n),g(1,n),0);
	fadd(g(2,n),g(1,n),1);
	fadd(g(1,n),g(2,n),0);*/
	for (int i=1;i<=n-1;i++)
	{
	  q[g(1,i)][g(1,i+1)]=1;
	  q[g(2,i+1)][g(2,i)]=1;
	  q[g(1,i)][g(2,i)]=1;
	  f[g(1,i+1)][g(1,i)]=1;
	  f[g(2,i)][g(2,i+1)]=1;
	  f[g(2,i)][g(1,i)]=1;
	}
	q[g(1,n)][g(2,n)]=1;
	f[g(2,n)][g(1,n)]=1;
	q[g(1,1)][g(2,1)]=0;
	f[g(2,1)][g(1,1)]=0;
	q[g(2,1)][g(1,1)]=1;
	f[g(1,1)][g(2,1)]=1;
	for (int kace=1;kace<=m;kace++)
	{
	  int p;
	  scanf("%d",&p);
	  if (p==2)
	  {
	  	int x1,y1,x2,y2;
	    scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	    if (x1==2&&x2==1)
	      swap(x1,x2),swap(y1,y2);
	    if (x1==x2&&y1>y2)
	      swap(y1,y2);
	    int u=g(x1,y1),v=g(x2,y2);
	    if (x1==x2)
	    {
	      q[u][v]=0;
	      f[v][u]=0;
	      if (q[g(3-x2,y2)][g(3-x1,y1)]==1)
	      	if (q[g(1,y2)][g(2,y2)]==1)
	      	{
	      	  q[g(1,y2)][g(2,y2)]=0;
	      	  f[g(2,y2)][g(1,y2)]=0;
	      	  q[g(2,y2)][g(1,y2)]=1;
	      	  f[g(1,y2)][g(2,y2)]=1;
	        }
	    }
	    else
	    {
		  if (q[g(2,y1)][g(1,y1)]==1)
	      {
	      	int k=y1;
	      	for (k;k<=n;k++)
	      	{
	      	  if (q[g(1,k)][g(2,k)]==1)
	      	  {
	      	  	add(g(1,k),g(2,k),0);
	      	  	add(g(2,k),g(1,k),1);
	      	  }
	      	  if (q[g(2,k)][g(1,k)]==1)
	      	    break;
	      	}
	      }
	      add(u,v,0);
	    }
	  }
	  if (p==1)
	  {
	  	int x1,x2,y1,y2;
	  	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	  	if (x1==2&&x2==1)
	  	  swap(x1,x2),swap(y1,y2);
	  	if (x1==x2&&y1>y2)
	  	  swap(y1,y2);
	  	int u=g(x1,y1),v=g(x2,y2);
	  	if (x1==x2)
	  	{
	  	  if (x1==1)
	  	  {
	  	  	add(u,v,1);
	  	  	if (q[g(2,y2)][g(2,y1)]==1)
	  	  	{
	  	  	  if (q[g(2,y2)][g(1,y2)]==1)
	  	  	  {
				add(g(2,y2),g(1,y2),0);
				add(g(1,y2),g(2,y2),1);
			  }
			}
		  }
		  if (x1==2)
	  	  {
	  	  	add(v,u,1);
	  	  	if (q[g(1,y1)][g(1,y2)]==1)
	  	  	{
	  	  	  if (q[g(2,y2)][g(1,y2)]==1)
	  	  	  {
				add(g(2,y2),g(1,y2),0);
				add(g(1,y2),g(2,y2),1);
			  }
			}
		  }
		}
		else
		{
		  if (q[g(1,y1-1)][g(1,y1)]==1&&q[g(2,y1)][g(2,y1-1)]==1)
		  	add(g(1,y1),g(2,y1),1);
		  else
		  {
		  	add(g(2,y1),g(1,y1),1);
		  	for (int k=y1+1;k<=n;k++)
		  	{
		  	  if (q[g(1,k-1)][g(1,k)]==1&&q[g(2,k)][g(2,k-1)]==1)
		  	  	if (q[g(2,k)][g(1,k)]==1)
		  	  	{
		  	  	  add(g(2,k),g(1,k),0);
		  	  	  add(g(1,k),g(2,k),1);
		  	    }
		  	  if (q[g(1,k)][g(2,k)]==1)
		  	    break;
		  	}
		  }
		}
	  }
	  vecx.clear();
	  vecy.clear();
	  for (int i=1;i<=n*2;i++)
	    vis[i]=0;
	  for (int i=1;i<=2;i++)
	    for (int j=1;j<=n;j++)
	      if (!vis[g(i,j)])
	        dfs1(i,j);
	  for (int i=1;i<=n*2;i++)
	    vis[i]=0;
	  int ans=0;
	  for (int i=n*2-1;i>=0;i--)
	  {
	  	int x=vecx[i],y=vecy[i];
	  	if (!vis[g(x,y)])
		  dfs2(x,y),ans++;
	  }
	  ans--;
	  printf("%d\n",ans);
	}
	return 0;
}
