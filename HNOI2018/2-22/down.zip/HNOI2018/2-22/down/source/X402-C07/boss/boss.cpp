#include<cstdio>
#include<algorithm>
using namespace std;

int ans=1000000,okno=1,n,M,HP,MP,SP,dhp,dmp,dsp,x,b[100012],y[100012],c[100012],z[100012],a[100012];
int n1,n2,t;


void doing(int pos,int hp,int mp,int sp,int m){
	if (m<=0)
	{
	  ans=min(ans,pos-1);
	  return ;
	}
	if (hp<=0)
	  return ;
	if (pos==n+1)
	{
	  okno=0;
	  return ;
	}
	for (int i=1;i<=n1;i++)
	  if (mp>=b[i])
	    doing(pos+1,hp-a[pos],mp-b[i],sp,m-y[i]);
	for (int i=1;i<=n2;i++)
	  if (sp>=c[i])
	    doing(pos+1,hp-a[pos],mp,sp-c[i],m-z[i]);
	doing(pos+1,hp-a[pos],mp,min(SP,sp+dsp),m-x);
	doing(pos+1,min(HP,hp+dhp)-a[pos],mp,sp,m);
	doing(pos+1,hp-a[pos],min(MP,mp+dmp),sp,m);
}

int main(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
	  ans=1000000,okno=1;
	scanf("%d%d%d%d%d%d%d%d%d",&n,&M,&HP,&MP,&SP,&dhp,&dmp,&dsp,&x);
	for (int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
	scanf("%d",&n1);
	for (int i=1;i<=n1;i++)
	  scanf("%d%d",&b[i],&y[i]);
	scanf("%d",&n2);
	for (int i=1;i<=n2;i++)
	  scanf("%d%d",&c[i],&z[i]);
	doing(1,HP,MP,SP,M);
	if (ans!=1000000)
	{
	  printf("Yes %d\n",ans);
	  continue;
	}
	if (okno==1)
	{
	  printf("No\n");
	  continue;
	}
	printf("Tie\n");
	}
}
