#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
bool a[603060],b[603060];
int n,m,num,ans;
int dfn[6030],pre[6030],du[6060];
bool block[606060];
void Tarjan(int x,int fa)
{
	++num;
	dfn[x]=num; pre[x]=num;
	if (x!=n && x!=2*n && a[x] && x+1!=fa)
	{
		if (dfn[x+1]) pre[x]=min(pre[x],dfn[x+1]);
		else
		{
			Tarjan(x+1,x);
			pre[x]=min(pre[x],pre[x+1]);
			if (pre[x+1]>dfn[x]) ++ans,++du[x];
		}
	}
	if (x!=1 && x!=n+1 && a[x-1] && x-1!=fa)
	{
		if (dfn[x-1]) pre[x]=min(pre[x],dfn[x-1]);
		else
		{
			Tarjan(x-1,x);
			pre[x]=min(pre[x],pre[x-1]);
			if (pre[x-1]>dfn[x]) ++ans,++du[x];
		}
	}

	if (x<=n && b[x] && x+n!=fa)
	{
		if (dfn[x+n]) pre[x]=min(pre[x],dfn[x+n]);
		else
		{
			Tarjan(x+n,x);
			pre[x]=min(pre[x],pre[x+n]);
			if (pre[x+n]>dfn[x]) ++ans,++du[x];
		}
	}
	if (x>n && b[x-n] && x-n!=fa)
	{
		if (dfn[x-n]) pre[x]=min(pre[x],dfn[x-n]);
		else
		{
			Tarjan(x-n,x);
			pre[x]=min(pre[x],pre[x-n]);
			if (pre[x-n]>dfn[x]) ++ans,++du[x];
		}
	}
}
void left(int x)
{
	while (block[x])
	{
		if (b[x+1]) return;
		ans+=2;
		a[x]=0;
		a[x+n]=0;
		block[x]=0;
		--x;
	}
	if (b[x+1]) b[x+1]=0,++ans;
}
void right(int x)
{
	while (block[x])
	{
		if (b[x]) return;
		ans+=2;
		a[x]=0;
		a[x+n]=0;
		block[x]=0;
		++x;
	}
	if (b[x]) b[x]=0,++ans;
}
int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	memset(a,1,sizeof(a));
	memset(b,1,sizeof(b));
	scanf("%d%d",&n,&m);
	if (n<=3000 && m<=3000)
	{
		int t,x0,y0,x1,y1;
		for (int i=1;i<=m;++i)
		{
			scanf("%d%d%d%d%d",&t,&x0,&y0,&x1,&y1);
			t=2-t;
			if (y0==y1) b[y0]=t;
			else if (x0==1) a[min(y0,y1)]=t;
			else a[n+min(y0,y1)]=t;
			ans=0; num=0;

			memset(dfn,0,sizeof(dfn));
			memset(du,0,sizeof(du));
			for (int j=1;j<=2*n;++j)
				if (dfn[j]==0) 
					Tarjan(j,0);
			printf("%d\n",ans);
		}
	}
	else
	{
		ans=0;
		for (int i=1;i<n;++i)
			block[i]=1;
	//	memset(block,1,sizeof(block));
		int t,x0,x1,y0,y1;
		for (int i=1;i<=m;++i)
		{
			scanf("%d%d%d%d%d",&t,&x0,&y0,&x1,&y1);
			if (y0==y1)
			{
				int x=y0;
				if (b[x]==0)
				{
					--ans;
					printf("%d\n",ans);
					continue;
				}
			//	printf("aaa:%d\n",ans);
				b[x]=0;
				if (block[x]==0) left(x-1);
				if (block[x-1]==0) right(x);
				printf("%d\n",ans);
			}
			else 
			{
				int x=min(y0,y1);
				if (x0==1)
				{
					if (a[x]==0)
					{
						--ans;
						printf("%d\n",ans);
						continue;
					}
				}
				else
				{
					if (a[x+n]==0)
					{
						--ans;
						printf("%d\n",ans);
						continue;
					}
				}
		
				a[x]=0;
				a[x+n]=0;
				block[x]=0;
				++ans;
				left(x-1);
				right(x+1);
				printf("%d\n",ans);
			}
		}


	}
	return 0;
}
