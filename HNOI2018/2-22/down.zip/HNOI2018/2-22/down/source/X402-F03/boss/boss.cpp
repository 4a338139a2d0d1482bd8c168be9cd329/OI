#include<cstdio>
#include<iostream>
using namespace std;
const int inf=999999999;
int n,m,HP,MP,SP,d_hp,d_mp,D_sp,X;
int f[102][72][72][72];
int a[105];
void qmin(int &x,int y)
{
	if (y<x) x=y;
}
int a1,a2,b1,b2;
int main()
{
	int T;
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d%d",&n,&m);
		scanf("%d%d%d%d%d%d%d",&HP,&MP,&SP,&d_hp,&d_mp,&d_sp,&X);
		for (int i=1;i<=n;++i)
			scanf("%d",&a[i]);
		scanf("%d%d",&a1,&a2);
		scanf("%d%d",&b1,&b2);
		memset(f,0x3f3f3f3f,sizeof(f));
		f[1][HP][MP][SP]=m;
		for (int i=1;i<=n;++i)
		for (int hp=a[i-1]+1;hp<=HP;++hp)
			for (int mp=0;mp<=MP;++mp)
				for (int sp=0;sp<=SP;++sp)
				if (f[i][hp][mp][sp]<inf)
				{
					if (f[i][hp][mp][sp]<=0)
					{
						printf("Yes ");
						printf("%d\n",i-1);
					}
					qmin( f[i+1][min(HP,hp-a[i-1]+d_hp)][mp][sp] , f[i][hp][mp][sp] );
					qmin( f[i+1][hp-a[i-1]][min(MP,mp+d_mp)][sp] , f[i][hp][mp][sp] );
					qmin( f[i+1][hp-a[i-1]][mp][min(SP,sp+d_sp)] , f[i][hp][mp][sp] - X );
					if (

					


				}
	}
	return 0;
}
