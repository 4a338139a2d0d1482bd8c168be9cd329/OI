#include<cstdio>
#include<iostream>
using namespace std;
const int mod=1e9 +7;
int a[2010122];
char ch[2020202];
int n,k,ans;
void check()
{
	int id=1,s=0;
	while (s<k && id<=n)
	{
		if (a[id]==1) ++s;
		else s=0;
		++id;
	}
	if (s<k) return;
	s=0;
	while (s<k && id<=n)
	{
		if (a[id]==2) ++s;
		else s=0;
		++id;
	}
	if (s<k) return;
	++ans;
}
void dfs(int deep)
{
	if (deep>n)
	{
		check();
		return;
	}
	if (a[deep]!=0)
	{
		dfs(deep+1);
		return;
	}
	a[deep]=1;
	dfs(deep+1);
	a[deep]=2;
	dfs(deep+1);
	a[deep]=0;
}
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);

	scanf("%d%d",&n,&k);
	scanf("%s",ch+1);
	for (int i=1;i<=n;++i)
	{
		if (ch[i]=='B') a[i]=1;
		if (ch[i]=='W') a[i]=2;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
