#include<bits/stdc++.h>
#define mp make_pair
#define pi pair<int,int>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
}

const int maxn=2e5+10,maxm=1500000+10;
int a[maxn],n,m,ans;
int dfn[maxn],low[maxn],sum,clok;
int beg[maxm],tot,vis[maxm],fa[maxm];
bool flag[maxm];
struct edge{
    int to,next;
}e[maxm<<1];
map<pair<int,int>,int>flag1,flag2;

inline void add(int u,int v){
   	e[++tot].to=v;
   	e[tot].next=beg[u];
   	beg[u]=tot;
	flag2[mp(u,v)]=tot;
}

inline void dfs(int u){
    int child=0;
    dfn[u]=low[u]=++clok;
    vis[u]=sum;
    for(register int i=beg[u];i;i=e[i].next){
		if(flag[i])continue;
        int v=e[i].to;
        if(vis[v]!=sum){
            child++;
            fa[v]=u;
            dfs(v);
            low[u]=min(low[u],low[v]);
			if(low[v]>dfn[u])ans++;
        }
        else if(v!=fa[u])low[u]=min(low[u],dfn[v]);
    }
}

int main(){
	file();
	read(n);read(m);
	int cnt=0;
	For(i,1,2) For(j,1,n) flag1[mp(i,j)]=++cnt;
	For(i,1,n-1){
		int a,b,c,d;
		a=flag1[mp(1,i)];
        b=flag1[mp(1,i+1)];
        c=flag1[mp(2,i)];
        d=flag1[mp(2,i+1)];
		add(a,b),add(b,a);
		add(c,d),add(d,c);
		add(a,c),add(c,a);
	}
	add(flag1[mp(1,n)],flag1[mp(2,n)]);
	add(flag1[mp(2,n)],flag1[mp(1,n)]);
	For(i,1,n) if(!vis[i])
		fa[i]=-1,dfs(i);
	For(i,1,m){
		int q,x,y,xx,yy;
		read(q);read(x);read(y);read(xx);read(yy);
		if(q==1){
			if(!flag1.count(mp(x,y)))flag1[mp(x,y)]=++cnt;
			if(!flag1.count(mp(xx,yy)))flag1[pi(xx,yy)]=++cnt;
			add(flag1[mp(x,y)],flag1[mp(xx,yy)]);add(flag1[mp(xx,yy)],flag1[mp(x,y)]);
		}
		else if(q==2){
			flag[flag2[pi(flag1[pi(x,y)],flag1[pi(xx,yy)])]]=1;
			flag[flag2[pi(flag1[pi(xx,yy)],flag1[pi(x,y)])]]=1;
		}
        ++sum;
		ans=clok=0;
		For(j,1,cnt) if(vis[j]!=sum) 
			fa[j]=-1,dfs(j);
		printf("%d\n",ans);
    }
    return 0;
}
