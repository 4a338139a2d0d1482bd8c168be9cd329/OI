#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
}

const int maxn=2e5+10,N=3000+10;
int n,m,op,x,y,_x,_y,ans,tot,temp;
int gra[N<<1][N<<1],vis[N<<1];
int P(int x,int y) {return (x-1)*n+y;}

inline void Pre_(){
	For(i,1,n-1){
		gra[i][i+1]=gra[i+1][i]=1;
		gra[i+n][i]=gra[i][i+n]=1;
		gra[i+n][i+n+1]=gra[i+n+1][i+n]=1;
	}
	gra[n][n+n]=gra[n+n][n]=1;
}

int BFS(){
	memset(vis,0,sizeof(vis)),tot=0;
	For(i,1,n<<1){
		if(vis[i]==1) continue;
		tot++;
		queue<int> Q;
		Q.push(i);
		while(!Q.empty()){
			int t=Q.front();Q.pop();
			vis[t]=1;
			if(t-1>=1)if(gra[t][t-1]==1 && !vis[t-1]) Q.push(t-1);
			if(t+1<=(n<<1))if(gra[t][t+1]==1 && !vis[t+1]) Q.push(t+1);
			if(t+n<=(n<<1))if(gra[t][t+n]==1 && !vis[t+n]) Q.push(t+n);
			if(t-n>=1)if(gra[t][t-n]==1 && !vis[t-n]) Q.push(t-n);
		}
	}
	return tot;
}

inline void work(){
	For(t,1,(n<<1)){
		if(t-1>=1) if(gra[t][t-1]==1){
			gra[t][t-1]=gra[t-1][t]=0;
			int now=BFS();
			if(temp!=now) ans++;
			gra[t][t-1]=gra[t-1][t]=1;
		}
		if(t+1<=(n<<1)) if(gra[t][t+1]==1){
			gra[t][t+1]=gra[t+1][t]=0;
			int now=BFS();
			if(temp!=now) ans++;
			gra[t][t+1]=gra[t+1][t]=1;

		}
		if(t+n<=(n<<1)) if(gra[t][t+n]==1){
			gra[t][t+n]=gra[t+n][t]=0;
			int now=BFS();
			if(temp!=now) ans++;
			gra[t][t+n]=gra[t+n][t]=1;									
		}
		if(t-n>=1) if(gra[t][t-n]==1){
			gra[t][t-n]=gra[t-n][t]=0;
			int now=BFS();
			if(temp!=now) ans++;
			gra[t][t-n]=gra[t-n][t]=1;
		}
	}
}

inline void Solve(){
	read(n),read(m),Pre_();
	For(tt,1,m){
		read(op),ans=0;
		read(x),read(y),read(_x),read(_y);
		if(op==1){
			gra[P(x,y)][P(_x,_y)]=1;
			gra[P(_x,_y)][P(x,y)]=1;
		}else{
			gra[P(x,y)][P(_x,_y)]=0;
			gra[P(_x,_y)][P(x,y)]=0;
		}
		temp=BFS();
		work();
		printf("%d\n",ans>>1);
	}
}

int main(){
	file();
	Solve();
	return 0;
}

