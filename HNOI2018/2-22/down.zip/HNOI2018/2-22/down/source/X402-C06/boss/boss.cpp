#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
}

const int maxn=1e2+10,N=10+5;
int Case,n,m,hp,mp,sp,dhp,dmp,dsp,X;
int n1,n2,B[N],Y[N],C[N],Z[N];
int Hp,Mp,Sp,ans,Tie,A[maxn];

inline void Init(){
	scanf("%d%d%d%d%d%d%d%d%d",&n,&m,&hp,&mp,&sp,&dhp,&dmp,&dsp,&X);
	Hp=hp,Mp=mp,Sp=sp,ans=INT_MAX,Tie=0; 
	For(i,1,n) read(A[i]);
	read(n1);For(i,1,n1) read(B[i]),read(Y[i]);
	read(n2);For(i,1,n2) read(C[i]),read(Z[i]);
}

inline void dfs(int round,int now_hp,int now_mp,int now_sp,int mm){
	if(mm<=0){
		ans=min(ans,round-1);
		return;
	}
	if(now_hp<=0) return;
	if(round==n+1){
		Tie=1;
		return;
	}
	For(i,1,n1) if(now_mp-B[i]>=0)
		dfs(round+1,now_hp-A[round],now_mp-B[i],now_sp,mm-Y[i]);
	For(i,1,n2) if(now_sp-C[i]>=0)
		dfs(round+1,now_hp-A[round],now_mp,now_sp-C[i],mm-Z[i]);
	dfs(round+1,now_hp-A[round],now_mp,min(Sp,now_sp+dsp),mm-X);
	dfs(round+1,min(now_hp+dhp,Hp)-A[round],now_mp,now_sp,mm);
	dfs(round+1,now_hp-A[round],min(now_mp+dmp,Mp),now_sp,mm);
}

int main(){
	file(),read(Case);
	while(Case--){
		Init();
		dfs(1,hp,mp,sp,m);
		if(ans!=INT_MAX) printf("Yes %d\n",ans);
		else if(Tie) printf("Tie\n");
		else printf("No\n");
	}
	return 0;
}

