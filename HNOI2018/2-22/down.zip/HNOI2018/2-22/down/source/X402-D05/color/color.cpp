#include<bits/stdc++.h>
using namespace std;
const int maxn=1001000;
const long long md=1000000007;
char str[maxn];
string procstatus(){
	ifstream t("/proc/self/status");
	return string(istreambuf_iterator<char>(t),istreambuf_iterator<char>());
}
int n,k;
long long pw2[maxn];
void getarray(int *sm,long long *dp,char ban){
	static long long cnt[maxn];
	static int sum[maxn];
	for(int i=1;i<=n;i++)
		sum[i]=sum[i-1]+(str[i]!=ban);
	long long tot=0;
	for(int i=1;i<=n;i++){
		sm[i]=sm[i-1]+(str[i]=='X');
		if(i>k){
			if(str[i-k]=='X')
				tot=(tot*2+dp[i-k])%md;
			else
				tot=(tot+dp[i-k])%md;
		}
		if(i>=k&&sum[i]-sum[i-k]==k){
			dp[i]=(pw2[sm[i-k]]-(cnt[i-1]-cnt[i-k])+md)%md;
			dp[i]=(dp[i]-tot+md)%md;
		}
		else dp[i]=0;
		cnt[i]=(cnt[i-1]+dp[i])%md;
	}
}
long long solve(){
	static long long dp1[maxn],dp2[maxn];
	static int sum1[maxn],sum2[maxn];
	getarray(sum1,dp1,'W');
	reverse(str+1,str+n+1);
	getarray(sum2,dp2,'B');
	reverse(str+1,str+n+1);
	reverse(dp2+1,dp2+n+1);
	reverse(sum2+1,sum2+n+1);
	long long tot=0,res=0;
	for(int i=1;i<n;i++){
		if(str[i]=='X')
			tot=(tot*2+dp1[i])%md;
		else
			tot=(tot+dp1[i])%md;
		res=(res+tot*dp2[i+1])%md;
	}
	return res;
}
int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	scanf("%d%d",&n,&k);
	scanf("%s",str+1);
	pw2[0]=1;
	for(int i=1;i<=n;i++)
		pw2[i]=pw2[i-1]*2%md;
	printf("%lld\n",solve());
	return 0;
}
