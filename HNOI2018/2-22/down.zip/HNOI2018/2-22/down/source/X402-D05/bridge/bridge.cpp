#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
#define mid ((l+r)>>1)
int n,m;
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int b1[maxn],b2[maxn];
int tr[maxn<<2];
void Build_tree(int h,int l,int r){
	if(l==r){
		tr[h]=1;
		return;
	}
	Build_tree(h<<1,l,mid);
	Build_tree(h<<1|1,mid+1,r);
	tr[h]=tr[h<<1]+tr[h<<1|1];
}
int Query(int *b,int x){
	int res=0;
	while(x){
		res+=b[x];
		x-=x&(-x);
	}
	return res;
}
void Insert(int *b,int x,int v){
	while(x<=n){
		b[x]+=v;
		x+=x&(-x);
	}
}
void updata(int h,int l,int r,int p,int v){
	tr[h]+=v;
	if(l==r) return;
	if(p<=mid) updata(h<<1,l,mid,p,v);
	else updata(h<<1|1,mid+1,r,p,v);
}
int lower(int h,int l,int r,int p){
	if(!tr[h]) return 0;
	if(l==r) return l;
	if(p<=mid) return lower(h<<1,l,mid,p);
	else{
		int v=lower(h<<1|1,mid+1,r,p);
		if(v) return v;
		return lower(h<<1,l,mid,p);
	}
}
int upper(int h,int l,int r,int p){
	if(!tr[h]) return n+1;
	if(l==r) return l;
	if(p<=mid){
		int v=upper(h<<1,l,mid,p);
		if(v<=n) return v;
		return upper(h<<1|1,mid+1,r,p);
	}
	else return upper(h<<1|1,mid+1,r,p);
}
bool isconnect(int l,int r){
	if(l<=0||r>=n+1) return 0;
	return Query(b1,r)-Query(b1,l)==r-l&&Query(b2,r)-Query(b2,l)==r-l;
}
bool isbridgeL(int p){
	if(p==1) return 1;
	int l=lower(1,1,n,p-1);
	return !isconnect(l,p);
}
bool isbridgeR(int p){
	if(p==n) return 1;
	int r=upper(1,1,n,p+1);
	return !isconnect(p,r);
}
int main(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	int op,x,y,xx,yy;
	for(int i=2;i<=n;i++)
		Insert(b1,i,1),Insert(b2,i,1);
	Build_tree(1,1,n);
	int l,r;
	bool bo1,bo2;
	int ans=0;
	for(m=1;m<=M;m++){
		readl(op),readl(x),readl(y),readl(xx),readl(yy);
		if(y==yy){
			if(op==2) updata(1,1,n,y,-1);
			l=lower(1,1,n,y),r=upper(1,1,n,y);
			bo1=isconnect(l,y);
			bo2=isconnect(y,r);
			if(!bo1&&!bo2){
				if(op==2) ans--;
				else ans++;
			}
			else if(bo1&&!bo2){
				if(op==1) ans=ans-(y-l)*2;
				else ans=ans+(y-l)*2;

				if(isbridgeL(l)){
					if(op==1) ans--;
					else ans++;
				}
			}
			else if(!bo1&&bo2){
				if(op==1) ans=ans-(r-y)*2;
				else ans=ans+(r-y)*2;

				if(isbridgeR(r)){
					if(op==1) ans--;
					else ans++;
				}
			}
			if(op==1) updata(1,1,n,y,1);
		}
		else{
			if(y>yy) swap(y,yy);
			if(op==1){
				if(x==1) Insert(b1,yy,1);
				else Insert(b2,yy,1);
			}
			l=lower(1,1,n,y),r=upper(1,1,n,yy);
			if(isconnect(l,r)){
				if(op==1) ans-=(r-l)*2-1;
				else ans+=(r-l)*2-1;
				if(isbridgeL(l)){
					if(op==1) ans--;
					else ans++;
				}
				if(isbridgeR(r)){
					if(op==1) ans--;
					else ans++;
				}
			}
			else{
				if(op==1) ans++;
				else ans--;
			}
			if(op==2){
				if(x==1)Insert(b1,yy,-1);
				else Insert(b2,yy,-1);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
