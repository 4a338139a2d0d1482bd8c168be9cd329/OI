#include<bits/stdc++.h>
using namespace std;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
void chkmax(int &x,int y){
	x=x>y?x:y;
}
int Min(int x,int y){
	return x<y?x:y;
}
int a[1010];
struct node{
	int c,v;
}f[20],g[20];
int dp[1010][1010];
int sum1[1010],sum2[1010];
int main(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	int n,m,HP,MP,SP,D_HP,D_MP,D_SP,X;
	int T;
	scanf("%d",&T);
	int n1,n2;
	while(T--){
		scanf("%d%d%d%d%d%d%d%d%d",&n,&m,&HP,&MP,&SP,&D_HP,&D_MP,&D_SP,&X);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		scanf("%d",&n1);
		for(int i=1;i<=n1;i++)
			scanf("%d%d",&f[i].c,&f[i].v);
		scanf("%d",&n2);
		for(int i=1;i<=n2;i++)
			scanf("%d%d",&g[i].c,&g[i].v);
		memset(sum1,0,sizeof(sum1));
		memset(sum2,0,sizeof(sum2));
		for(int i=0;i<=n;i++)
			for(int j=0;j<=MP;j++)
				dp[i][j]=-1;
		dp[0][MP]=0;
		for(int i=1;i<=n;i++){
			for(int j=0;j<=MP;j++){
				if(dp[i-1][j]<0) continue;
				for(int k=1;k<=n1;k++)
					if(j>=f[k].c)
						chkmax(dp[i][j-f[k].c],dp[i-1][j]+f[k].v);
				chkmax(dp[i][Min(j+D_MP,MP)],dp[i-1][j]);
			}
			for(int j=0;j<=MP;j++)
				chkmax(sum1[i],dp[i][j]);
		}
		for(int i=0;i<=n;i++)
			for(int j=0;j<=SP;j++)
				dp[i][j]=-1;
		dp[0][SP]=0;
		for(int i=1;i<=n;i++){
			for(int j=0;j<=SP;j++){
				if(dp[i-1][j]<0) continue;
				for(int k=1;k<=n2;k++)
					if(j>=g[k].c)
						chkmax(dp[i][j-g[k].c],dp[i-1][j]+g[k].v);
				chkmax(dp[i][Min(j+D_SP,SP)],dp[i-1][j]+X);
			}
			for(int j=0;j<=SP;j++)
				chkmax(sum2[i],dp[i][j]);
		}
		int res=n+1;
		for(int i=0;i<=n;i++)
			for(int j=0;j<=n;j++)
				if(sum1[i]+sum2[j]>=m)
					chkmin(res,i+j);
		for(int i=0;i<=n;i++)
			for(int j=0;j<=HP;j++)
				dp[i][j]=-1;
		dp[0][HP]=0;
		int ans=n+1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=HP;j++){
				if(dp[i-1][j]<0) continue;
				if(dp[i-1][j]+1>=res){
					ans=i;
					break;
				}
				if(j>a[i]) chkmax(dp[i][j-a[i]],dp[i-1][j]+1);
				if(Min(j+D_HP,HP)>a[i])
					chkmax(dp[i][Min(j+D_HP,HP)-a[i]],dp[i-1][j]);
			}
			if(ans<=n) break;
		}
		if(ans<=n){
			printf("Yes %d\n",ans);
			continue;
		}
		int hp=HP;
		for(int i=1;i<=n;i++){
			hp=Min(HP,hp+D_HP);
			hp-=a[i];
			if(hp<=0){
				ans=0;
				break;
			}
		}
		if(ans==0)
			printf("No\n");
		else
			printf("Tie\n");
	}
	return 0;
}
