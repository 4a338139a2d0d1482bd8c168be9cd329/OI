#include<bits/stdc++.h>
using namespace std;

const int maxn=1000010;
int n, k;
char s[maxn];
int a[maxn], f[maxn][2];
int Next[maxn], ans;

int Max0[maxn], Max1[maxn];
bool check(){
	// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
	for(int i=n;i>=1;i--) if(a[i]==1) f[i][0]=f[i+1][0]+1, f[i][1]=0; else f[i][1]=f[i+1][1]+1, f[i][0]=0;
	for(int i=n;i>=1;i--) Max0[i]=max(Max0[i+1], f[i][0]), Max1[i]=max(Max1[i+1], f[i][1]);
	for(int i=1;i+k<=n;i++) if(f[i][1]>=k && Max0[i+k]>=k) return true;
	return false;
}
void dfs(int x){
	if(x>n){
		if(check()) ans++;
		return;
	}
	a[x]=1; dfs(Next[x]);
	a[x]=2; dfs(Next[x]);
}

int main(){
	freopen("color.in","r",stdin),freopen("color.out","w",stdout);

	scanf("%d%d", &n, &k);
	scanf("%s", s+1);
	int lst=0;
	for(int i=1;i<=n;i++) if(s[i]=='W') a[i]=1; else if(s[i]=='B') a[i]=2; else{
		Next[lst]=i; lst=i;
	}
	Next[lst]=n+1;
	dfs(Next[0]);
	printf("%d\n", ans);
	return 0;
}
