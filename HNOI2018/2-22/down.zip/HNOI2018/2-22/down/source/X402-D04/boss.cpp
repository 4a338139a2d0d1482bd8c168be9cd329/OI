#include<bits/stdc++.h>
using namespace std;

const int maxn=10010;
const int inf=1e9;
int n, m, c, c1, c2, d, d1, d2, x, b, y, C, z;
int a[maxn];

int ans;
void dfs(int now,int res,int m,int cc,int dd){
	// printf("m = %d\n", m);
	if(res<=0) return;
	if(m<=0) ans=min(ans, now-1);
	if(now>n){ return; }
	if(m<=x){ ans=min(ans, now); return; }
	if(m<=y && cc>=b){ ans=min(ans, now); return; }
	if(m<=z && dd>=C){ ans=min(ans, now); return; }

	dfs(now+1, res-a[now]+d, m, cc, dd);
	dfs(now+1, res-a[now], m, cc+d1, dd);
	dfs(now+1, res-a[now], m-x, cc, dd+d2);
	if(cc>=b) dfs(now+1, res-a[now], m-y, cc-b, dd);
	if(dd>=C) dfs(now+1, res-a[now], m-z, cc, dd-C);
}

int main(){
	freopen("boss.in","r",stdin),freopen("boss.out","w",stdout);

	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%d%d%d%d%d%d%d%d%d", &n, &m, &c, &c1, &c2, &d, &d1, &d2, &x);
		for(int i=1;i<=n;i++) scanf("%d", &a[i]);
		int tt=0;
		scanf("%d%d%d", &tt, &b, &y);
		scanf("%d%d%d", &tt, &C, &z);
		if(!m){ printf("Yes 1\n"); continue; }
		int t=c, f=1;
		for(int i=1;i<=n;i++){
			t+=d; t-=a[i];
			if(t<0){ puts("No"); f=0; break; }
		}
		if(!f) continue;
		ans=inf;
		// printf("%d %d %d %d %d\n", c, m, x, y, z);
		dfs(1, c, m, c1, c2);
		if(ans!=inf){
			printf("Yes %d\n", ans);
		}else puts("Tie");
	}
	return 0;
}
