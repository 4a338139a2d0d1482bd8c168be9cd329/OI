#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmin(int &x,int y){return (y<x)?(x=y,1):0;}
inline bool chkmax(int &x,int y){return (y>x)?(x=y,1):0;}
const int maxn=1000+10,inf=0x3f3f3f3f;
struct point{
	int x,y;
}b[maxn],c[maxn];
int dp[maxn][maxn],Day[maxn];
int n,m,hp,mp,sp,dhp,dmp,dsp;
void work2(int *f,point *a,int N,int li){
	REP(i,0,n)
		REP(j,0,li)
			dp[i][j]=-1;
	dp[0][li]=0;
	REP(i,0,n-1)
		REP(j,0,li)
			REP(k,1,N)
				if(j>=a[k].x)
					chkmax(dp[i+1][min(j-a[k].x,li)],dp[i][j]+a[k].y);
	REP(i,0,n) REP(j,0,li) chkmax(f[i],dp[i][j]);
}
int g[maxn],f[maxn];
int n1,n2;
int a[maxn];
bool work1(){
	memset(dp,inf,sizeof(dp));
	dp[0][hp]=0;
	REP(i,0,n-1) REP(j,a[i+1]+1,hp){
		chkmin(dp[i+1][j-a[i+1]],dp[i][j]);
		chkmin(dp[i+1][min(j-a[i+1]+dhp,hp)],dp[i][j]+1);
	}
	int ans=inf;
	REP(i,1,hp) chkmin(ans,dp[n][i]);
	if(ans==inf) return 1;
	memset(Day,inf,sizeof(Day));
	REP(i,1,n) REP(j,1,hp) if(dp[i][j]!=inf) chkmin(Day[i-dp[i][j]],i);
	DREP(i,n,1) chkmin(Day[i-1],Day[i]);
	return 0;
}
void putans(){
	if(f[0]+g[0]>=m){
		printf("Yes 1\n");
		return;
	}
	REP(i,1,n){
		if(Day[i-1]>n-1) break;
		REP(j,0,i)
			if(f[j]+g[i-j]>=m){
				printf("Yes %d\n",Day[i-1]+1);
				return;
			}
	}
	printf("Tie\n");
}
int main(){
	freopen("boss.in","r",stdin),freopen("boss.out","w",stdout);

	int T=read();
	while(T--){
		memset(f,0,sizeof(f));
		memset(g,0,sizeof(g));
		n=read(),m=read(),hp=read(),mp=read(),sp=read();
		dhp=read(),dmp=read(),dsp=read();
		int x=read();
		REP(i,1,n) a[i]=read();
		n1=read();
		REP(i,1,n1) b[i].x=read(),b[i].y=read();
		b[++n1]=(point){-dmp,0};
		n2=read();
		REP(i,1,n2) c[i].x=read(),c[i].y=read();
		c[++n2]=(point){-dsp,x};
		if(n>500){ puts("No"); continue; }
		if(work1()){
			printf("No\n");
			continue;
		}
		work2(g,b,n1,mp);
		work2(f,c,n2,sp);
		putans();
	}
	return 0;
}
