#include<bits/stdc++.h>
using namespace std;

typedef vector<int> :: iterator it;
const int maxn=400010;
const int maxm=3010;
int n, m;
int id[5][maxn];
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0', c=getchar();
}

int cnt, bridge;
int low[maxn], dfn[maxn];
int fa[maxn];

int find(int x){ return x==fa[x] ? x : fa[x]=find(fa[x]); }

void unoin(int x,int y){
	x=find(x), y=find(y);
	fa[x]=y;
}

void dfs(int x,int father){
	dfn[x]=low[x]=++cnt;
	for(int i=0;i<g[x].size();i++){ 
		int v=g[x][i]; if(v==father) continue;
		if(!dfn[v]){
			dfs(v, x); low[x]=min(low[x], low[v]);
			if(low[v]>dfn[x]){
				bridge++;
			}else{
				pre[v]=x;
				unoin(x, v);
			}
		}else low[x]=min(low[x], dfn[v]);
	}
}

void solve(){
	int x0, y0, x1, y1, op; 
	while(m--){
		// cerr<<m<<endl;
		read(op), read(x0), read(y0), read(x1), read(y1);
		int u=id[x0][y0], v=id[x1][y1];
		if(op==1){
			g[u].push_back(v); g[v].push_back(u);
		}else{
			// cerr<<u<<' '<<v<<endl;
			for(it it=g[u].begin();it!=g[u].end();it++){
				// cerr<<*it<<endl;
				if((*it)==v){ g[u].erase(it); break; }
			}
			// cerr<<x0<<' '<<y0<<' '<<x1<<' '<<y1<<endl;
			for(it it=g[v].begin();it!=g[v].end();it++){
				if((*it)==u){ g[v].erase(it); break; }
			}
		}
		cnt=0; bridge=0;
		for(int i=1;i<=n*2;i++) dfn[i]=low[i]=0;
		for(int i=1;i<=n*2;i++) if(!dfn[i]) dfs(i,0);
		printf("%d\n", bridge);
	}
}

int x[maxn], y[maxn];
int main(){
	freopen("bridge1.in","r",stdin),freopen("bridge.out","w",stdout);

	read(n), read(m);
	for(int i=1;i<=2;i++) for(int j=1;j<=n;j++) id[i][j]=++cnt;
	for(int i=1;i<=n;i++){
		int u=id[1][i], v=id[2][i];
		g[u].push_back(v); g[v].push_back(u);
	}
	for(int i=1;i<=2;i++) for(int j=1;j<n;j++){
		int u=id[i][j], v=id[i][j+1];
		g[u].push_back(v), g[v].push_back(u);
	}
	if(n<=3000 && m<=3000){
		solve();
		return 0;
	}
	int x0, y0, x1, y1, op; 
	for(int i=1;i<=m;i++){
		read(op); read(x0), read(y0), read(x1), read(y1);
		x[i]=id[x0][y0], y[i]=id[x1][y1];
		int u=x[i], v=y[i];
		for(it it=g[u].begin();it!=g[u].end();it++){
			if(*(it)==v) g[u].erase(it);
		}
		for(it it=g[v].begin();it!=g[v].end();it++){
			if(*it==u) g[v].erase(it);
		}
	}
	for(int i=m;i>=1;i--){
	}
	return 0;
}
