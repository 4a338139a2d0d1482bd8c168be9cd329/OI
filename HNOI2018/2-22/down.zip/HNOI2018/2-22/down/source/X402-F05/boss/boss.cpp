#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 1010;
const int oo = 1e9;
const size_t SZ = sizeof(int) * N * N;

void chkmin(int &x, int y) { x = x < y ? x : y; }
void chkmax(int &x, int y) { x = x > y ? x : y; }

int n;

void work_mp(int dp[N][N], int lim, int m, int *c, int *w) {
	memset(dp, 0, SZ);
	For(i, 1, n) {
		For(j, 0, lim) For(k, 1, m) 
			if (j >= c[k]) chkmax(dp[i][min(lim, j - c[k])], dp[i - 1][j] + w[k]);
		Forr(j, lim, 1) chkmax(dp[i][j - 1], dp[i][j]);
	}		
}

int dp[N][N], A[N];

void work_hp(int lim, int heal, int d) {
	memset(dp, 0x3f, SZ);
	dp[0][lim] = 0;

	if (d == 1) {
		puts("Yes 1");
		return;
	}

	bool tie = false;
	For(i, 1, n) {
		if (lim <= A[i]) break;
		For(j, A[i] + 1, lim) chkmin(dp[i][j - A[i]], dp[i - 1][j]);
		For(j, max(1, A[i] - heal + 1), lim) chkmin(dp[i][min(j + heal, lim) - A[i]], dp[i - 1][j] + 1);
		For(j, 1, lim) if (dp[i][j] <= i) {
			if (i == n) tie = true;
			else if (i - dp[i][j] >= d - 1) {
				printf("Yes %d\n", i + 1);
				return;
			}
		}
	}
	puts(tie ? "Tie" : "No");

}

int boss, hp, mp, sp, dhp, dmp, dsp, X;
int B[12], Y[12], nb;
int C[12], Z[12], nc;
int fmp[N][N], fsp[N][N];

int main() {

	freopen("boss.in", "r", stdin);
	freopen("boss.out", "w", stdout);

	int Case;
	scanf("%d", &Case);
	while (Case--) {

		scanf("%d%d%d%d%d%d%d%d%d", &n, &boss, &hp, &mp, &sp, &dhp, &dmp, &dsp, &X);
		For(i, 1, n) scanf("%d", &A[i]);
		
		scanf("%d", &nb);
		For(i, 1, nb) scanf("%d%d", &B[i], &Y[i]);
		B[++nb] = -dmp, Y[nb] = 0;

		scanf("%d", &nc);
		For(i, 1, nc) scanf("%d%d", &C[i], &Z[i]);
		C[++nc] = -dsp, Z[nc] = X;

		work_mp(fmp, mp, nb, B, Y);
		work_mp(fsp, sp, nc, C, Z);

		int day = n + 1;
		For(ans, 0, n) {
			bool flag = false;
			For(i, 0, ans) 
				if (fmp[i][0] + fsp[ans - i][0] >= boss) {
					flag = true;
					break;
				}
			if (flag) {
				day = ans;
				break;
			}
		}
		work_hp(hp, dhp, day);

	}

	return 0;
}
