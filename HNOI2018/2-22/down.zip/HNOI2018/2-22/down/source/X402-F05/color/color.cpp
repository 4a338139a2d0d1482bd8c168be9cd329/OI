#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

const int Mod = 1e9 + 7;
const int N = 1e6 + 10;

int n, k;
char S[N];

inline void add(int &x, int y) {
	x += y;
	if (x >= Mod) x -= Mod;
}

inline void minus(int &x, int y) {
	x -= y;
	if (x < 0) x += Mod;
}

int f[N], g[N];
int sumf, sumg;

int main() {

	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);

	scanf("%d%d%s", &n, &k, S + 1);

	int lstw = 0, lstb = 0, ans = 0;
	f[0] = sumf = 1;

	For(i, 1, n) {
		if (S[i] == 'B') {
			g[i] = sumg;
			For(j, lstb, i - 1) g[j] = 0;
			lstb = i;

			if (i >= k) {
				add(g[i], f[i - k]);
				minus(sumf, f[i - k]), add(sumg, f[i - k]);
				f[i - k] = 0;
			}

		} else if (S[i] == 'W') {
			f[i] = sumf;
			For(j, lstw, i - 1) f[j] = 0;
			lstw = i;

			if (i >= k) {
				add(ans, g[i - k]);
				minus(sumg, g[i - k]);
				g[i - k] = 0;
			}

		} else {
			add(f[i], sumf), add(g[i], sumg);
			add(sumf, sumf), add(sumg, sumg);
			add(ans, ans);
			
			if (i >= k) {
				add(g[i], f[i - k]);
				minus(sumf, f[i - k]), add(sumg, f[i - k]);
				f[i - k] = 0;
				
				add(ans, g[i - k]);
				minus(sumg, g[i - k]);
				g[i - k] = 0;
			}
		}
	}

	printf("%d\n", ans);

	return 0;
}
