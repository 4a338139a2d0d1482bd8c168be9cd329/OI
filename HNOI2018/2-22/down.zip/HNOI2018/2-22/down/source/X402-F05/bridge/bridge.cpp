#include <bits/stdc++.h>

#define x first
#define y second
#define mp make_pair
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef pair<bool, bool> edge;

const int N = 4e5 + 10;

void chkmin(int &x, int y) { x = x < y ? x : y; }

int n, m;

inline int ID(int x, int y) {
	return (x - 1) * n + y;
}

namespace BF{

	edge par[2][N], ver[N];
	int vis[2][N];
	int pre[2][N], low[2][N];
	int ans;

	void DFS(int x, int y, int fx, int fy, int id = 0) {
		static int clk = 0;
		vis[x][y] = id;
		pre[x][y] = ++clk, low[x][y] = clk;

		int stx[4], sty[4], c = 0;
		bool *f[4];
		if (ver[y].x) stx[++c] = x ^ 1, sty[c] = y, f[c] = &ver[y].y;
		if (y > 1 && par[x][y - 1].x) stx[++c] = x, sty[c] = y - 1, f[c] = &par[x][y - 1].y;
		if (y < n && par[x][y].x) stx[++c] = x, sty[c] = y + 1, f[c] = &par[x][y].y;

		For(i, 1, c) {
			int u = stx[i], v = sty[i];

			if (u == fx && v == fy) continue;
			if (vis[u][v] == id) {
				if (*f[i]) *f[i] = false, --ans;
				chkmin(low[x][y], pre[u][v]);
			} else {
				DFS(u, v, x, y, id);
				chkmin(low[x][y], low[u][v]);
				if (low[u][v] == pre[u][v]) {
					if (!*f[i]) *f[i] = true, ++ans;
				} else if (*f[i]) {
					*f[i] = false, --ans;
				}
			}
		}

	}

	void main() {
		memset(vis, -1, sizeof vis);

		For(i, 0, 1) For(j, 1, n - 1) par[i][j].x = true;
		For(i, 1, n) ver[i].x = true;
		For(i, 0, 1) For(j, 1, n) if (vis[i][j] != 0) DFS(i, j, i, j, 0);

		For(i, 1, m) {
			int op, x1, y1, x2, y2;
			scanf("%d%d%d%d%d", &op, &x1, &y1, &x2, &y2);
			--x1, --x2;
			if (y1 > y2) swap(y1, y2);

			edge *e;
			if (y1 == y2) e = &ver[y1];
			else e = &par[x1][y1];

			bool skip = false;

			if (op == 1) {
				e -> x = true;
			} else {
				e -> x = false;
				if (e -> y) e -> y = false, --ans, skip = true;
			}

			if (!skip) {
				DFS(x1, y1, x1, y1, i);
				if (vis[x2][y2] != i) DFS(x2, y2, x2, y2, i);
			}

			printf("%d\n", ans);
			
		}
	}

};

int main() {

	freopen("bridge.in", "r", stdin);
	freopen("bridge.out", "w", stdout);

	scanf("%d%d", &n, &m);
	BF::main();

	return 0;
}
