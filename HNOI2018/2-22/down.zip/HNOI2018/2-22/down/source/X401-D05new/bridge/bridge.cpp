#include<bits/stdc++.h>
using namespace std;
#define Temp template<typename T>
Temp inline void read(T &x) 
{
	x=0;char c=getchar();T f=1;
	while(!isdigit(c)) {if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

#define N 6050
struct A
{
	int to,last;
}E[N<<2];
int beg[N<<1],e;
void add(int u,int v)
{
	E[++e].to=v;E[e].last=beg[u];beg[u]=e;
}
int n,m;
int dfn[N],low[N];
int st[N],top,bs[N],cnt;
bool del[N][N];
void dfs(int dep,int u,int fa) 
{
	dfn[u]=low[u]=++dep;
	st[++top]=u;
	for(int i=beg[u];i;i=E[i].last)
	{
		int v=E[i].to;
		if(del[u][v]) continue;
		if(!dfn[v]) 
		{
			dfs(dep+1,v,u);
			low[u]=min(low[u],low[v]);
		}
		else if(fa!=v) low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u]) 
	{
		while(st[top+1]!=u)
		{
			bs[st[top]]=cnt;
			top--;
		}
		cnt++;
	}
}
void rset() {for(int i=1;i<=2*n;++i) dfn[i]=low[i]=0;cnt=0;}
void pian20()
{
	int x1,x2,y1,y2;
	for(int i=1;i<n;++i) add(i,i+1),add(i+1,i),add(i+n,i+n+1),add(i+n+1,i+n);
	for(int i=1;i<=n;++i) add(i,i+n),add(i+n,i);
	for(int i=1;i<=m;++i) 
	{
		int kk;
		read(kk);
		rset();
		if(kk==1) 
		{
			read(x1),read(x2),read(y1),read(y2);
			int xx,yy;
			xx=x1==2?x2+n:x2;yy=y1==2?x2+n:y2;
			del[xx][yy]=0;del[yy][xx]=0;
		}
		else if(kk==2) 
		{
			read(x1),read(x2),read(y1),read(y2);
			int xx,yy;
			xx=x1==2?x2+n:x2;yy=y1==2?y2+n:y2;
			del[xx][yy]=1;del[yy][xx]=1;
		}
		for(int j=1;j<=2*n;++j) if(!dfn[j]) dfs(0,j,j);
		printf("%d\n",cnt-1);
	}
}
struct B
{
	int x,y;
}f[200020];map<pair<int,int>,bool>py;
int ansn[200020];
void pian40()
{
	int x1,x2,y1,y2;
	for(int i=1;i<=m;++i) 
	{
		int kk;read(kk);
		read(x1),read(x2),read(y1),read(y2);
		int xx,yy;
		xx=x1==2?x2+n:x2;yy=y1==2?x2+n:y2;
		f[i].x=xx,f[i].y=yy;
		py[make_pair(xx,yy)]=1;
	}
	for(int i=1;i<n;++i) 
	{
		if(!py[make_pair(i,i+1)] && !py[make_pair(i+1,i)])add(i,i+1),add(i+1,i);
		if(!py[make_pair(i+n+1,i+n)] && !py[make_pair(i+n,i+n+1)])add(i+n,i+n+1),add(i+n+1,i+n);
	}
	for(int i=1;i<=n;++i) {if(!py[make_pair(i,i+n)] && !py[make_pair(i+n,i)])add(i,i+n),add(i+n,i);}
	for(int i=m;i>=1;--i) 
	{
		for(int j=1;j<=2*n;++j) if(!dfn[j]) dfs(0,j,j);
		ansn[i]=cnt-1;
		add(f[i].x,f[i].y),add(f[i].y,f[i].x);
		py[make_pair(f[i].x,f[i].y)]=0;		py[make_pair(f[i].y,f[i].x)]=0;
	}
	for(int i=1;i<=m;++i) printf("%d\n",ansn[i]);
}
int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	read(n),read(m);
	if(n<=3000 && m<=3000) pian20();
	else pian40();	
	return 0;
}
