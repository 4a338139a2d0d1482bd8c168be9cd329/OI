/**********************************************************
	File:color.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-22 08:42:29
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 1000010
#define mod 1000000007
int n,k;
char c[N],p[N];
int ans;
void dfs(int x,int f1,int f2,int s)
{
	if(x==n+1)
	{
		ans+=(f1&&f2);
//		fr(i,1,n)
//			printf("%c",p[i]);
//		putchar(10);
//		printf("%s\n",p+1);
		return;
	}
	if(f1&&f2)
	{
		if(c[x]=='X'||c[x]=='B')
		{
//			p[x]='B';
			dfs(x+1,1,1,s);
		}
		if(c[x]=='X'||c[x]=='W')
		{
//			p[x]='W';
			dfs(x+1,1,1,s);
		}
		return;
	}
	if(f1)
	{
		if(c[x]=='X'||c[x]=='W')
		{
			if(s+1==k)
			{
//				p[x]='w';
				dfs(x+1,1,1,0);
			}
			else
			{
//				p[x]='W';
				dfs(x+1,1,0,s+1);
			}
		}
		if(c[x]=='X'||c[x]=='B')
		{
//			p[x]='B';
			dfs(x+1,1,0,0);
		}
		return;
	}
	if(c[x]=='X'||c[x]=='B')
	{
		if(s+1==k)
		{
//			p[x]='b';
			dfs(x+1,1,0,0);
		}
		else
		{
//			p[x]='B';
			dfs(x+1,0,0,s+1);
		}
	}
	if(c[x]=='X'||c[x]=='W')
	{
//		p[x]='W';
		dfs(x+1,0,0,0);
	}
}
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	n=read();
	k=read();
	scanf("%s",c+1);
	dfs(1,0,0,0);
	printf("%d\n",ans);
	return 0;
}