/**********************************************************
	File:boss.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-22 09:40:17
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
namespace game
{
	#define N 110
	#define inf (1<<25)
	int n,m,hp,mp,sp,dhp,dmp,dsp,x,n1,n2,b[N],y[N],c[N],z[N],a[N],g[N][N],f[N][N][N],mi[N];
	int main()
	{
		n=read();m=read();
		hp=read();mp=read();sp=read();
		dhp=read();dmp=read();dsp=read();
		x=read();
		fr(i,1,n)a[i]=read();
		n1=read();
		fr(i,1,n1)
		{
			b[i]=read();
			y[i]=read();
		}
		n2=read();
		fr(i,1,n2)
		{
			c[i]=read();
			z[i]=read();
		}
		fr(i,1,n)mi[i]=inf;
		mi[1]=1;
		int k=hp;
		fr(i,1,n)
		{
			k=min(k+dhp,hp);
			k-=a[i];
			if(k<=0)
			{
				printf("No\n");
				return 0;
			}
		}
		fr(i,0,n)
			fr(j,0,hp)
				g[i][j]=-inf;
		g[0][hp]=0;
		fr(i,1,n-1)
			fr(j,1,hp)
			{
				if(j+a[i]<=hp)
					g[i][j]=g[i-1][j+a[i]]+1;
				if(j==hp-a[i])
					fr(k,hp-dhp,hp)
						g[i][j]=max(g[i][j],g[i-1][k]);
				if(j<hp-a[i]&&j>dhp-a[i])
					g[i][j]=max(g[i][j],g[i-1][j-dhp+a[i]]);
//				printf("%d%c",g[i][j]<0?0:g[i][j],j==hp?'\n':' ');
				if(g[i][j]>0)mi[g[i][j]+1]=min(mi[g[i][j]+1],i+1);
			}
//		fr(i,1,n)printf("%d%c",mi[i],i==n?'\n':' ');
		fr(i,0,n)
			fr(j,0,mp)
				fr(k,0,sp)
					f[i][j][k]=-inf;
		f[1][mp][sp]=x;
		fr(i,1,n1)
			if(b[i]<=mp)f[1][mp-b[i]][sp]=y[i];
		fr(i,1,n2)
			if(c[i]<=sp)f[1][mp][sp-c[i]]=z[i];
		fr(i,1,n)
			if(mi[i]>n)
				break;
			else
			{
				fr(j,0,mp)
					fr(k,0,sp)
					{
						if(f[i][j][k]>=m)
						{
							printf("Yes %d\n",mi[i]);
							return 0;
						}
						if(i==n)continue;
						f[i+1][j][min(k+dsp,sp)]=max(f[i+1][j][min(k+dsp,sp)],f[i][j][k]+x);
						f[i+1][min(j+dmp,mp)][k]=max(f[i+1][min(j+dmp,mp)][k],f[i][j][k]);
						fr(o,1,n1)
							if(b[o]<=j)
								f[i+1][j-b[o]][k]=max(f[i+1][j-b[o]][k],f[i][j][k]+y[o]);
						fr(o,1,n2)
							if(c[o]<=k)
								f[i+1][j][k-c[o]]=max(f[i+1][j][k-c[o]],f[i][j][k]+z[o]);
					}
			}
		printf("Tie\n");
		return 0;
	}
}
int t;
int main()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	t=read();
	while(t--)game::main();
	return 0;
}