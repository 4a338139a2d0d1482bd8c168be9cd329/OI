/**********************************************************
	File:bridge.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-22 10:35:38
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
namespace r
{
	#define N 2000010
	int n,t,begin[N],next[N],to[N],w[N],e,ans,vis[N],dfn[N],low[N];
	#define fo(i,a) for(int i=begin[a];i;i=next[i])
	void add(int u,int v)
	{
		e++;
		to[e]=v;
		w[e]=1;
		next[e]=begin[u];
		begin[u]=e;
	}
	void set(int u,int v,int ww)
	{
		fo(i,u)if(to[i]==v)w[i]=ww;
		fo(i,v)if(to[i]==u)w[i]=ww;
	}
	void tarjan(int u,int f)
	{
		e++;
		dfn[u]=e;
		low[u]=e;
		vis[u]=1;
//		printf("%d %d\n- ",u,f);
//		fo(i,u)
//			if(to[i]!=f)
//				printf("%d ",to[i]);
//		putchar(10);
		fo(i,u)if(w[i])
		{
			int v=to[i];
			if(v==f)continue;
			if(vis[v])
				low[u]=min(low[u],dfn[v]);
			else
			{
				tarjan(v,u);
				low[u]=min(low[u],low[v]);
			}
		}
		if(low[u]==dfn[u])
		{
			// printf("%d\n",u);
			ans++;
		}
	}
	int main()
	{
		freopen("bridge.in","r",stdin);
		freopen("bridge.out","w",stdout);
		n=read();t=read();
		fr(i,1,n-1)
		{
			add(i,i+1);add(i+1,i);
			add(i+n,i+n+1);add(i+n+1,i+n);
		}
		fr(i,1,n)
		{
			add(i,i+n);
			add(i+n,i);
		}
		while(t--)
		{
			int opt=read(),x=read(),y=read(),xx=read(),yy=read();
			set((x-1)*n+y,(xx-1)*n+yy,opt&1);
			ans=0;
			fr(i,1,n<<1)vis[i]=dfn[i]=low[i]=0;
			e=0;
			fr(i,1,n<<1)
				if(!vis[i])
				{
					tarjan(i,0);
					ans--;
				}
			printf("%d\n",ans);
		}
		return 0;
	}
}
int main(){return r::main();}