#define  REP(i, s, e) for(register int i = s; i <= e ;i++)
#define DREP(i, s, e) for(register int i = s; i >= e ;i--)

#define DEBUG fprintf(stderr, "Passing [%s] in LINE %d\n", __FUNCTION__, __LINE__)
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)

#include <bits/stdc++.h>

using namespace std;
const int maxn = 2010;

int m, n, k;
char s[maxn];

struct fenwick_tree
{
	int c[maxn];
	fenwick_tree() {memset(c, 0, sizeof(c));}
	inline void add(int x, int y)
	{
		while (x <= n)
		{
			c[x] += y;
			x += x & -x;
		}
	}
	inline int sum(int x)
	{
		int res = 0;
		while (x > 0)
		{
			res += c[x];
			x -= x & -x;
		}
		return res;
	}
}A, Z; 

const int mod = 1000000007 ;
int ans = 0;

int main()
{
	freopen("color.in", "r", stdin);
//	freopen("color.out", "w", stdout);
	scanf("%d %d\n%s", &n, &k, s + 1);	
	REP(i, 1, n)
		if (s[i] == 'W') A.add(i, 1);
		else if (s[i] == 'B') A.add(i, 2);
		else Z.add(i, 1);
	REP(i, 1, n - 1)if (i + k - 1 <= n)
	{
		int temp = A.sum(i + k - 1) - A.sum(i - 1);
		if (temp > k) continue;
		else if (temp == k)
		{
			REP(j, i + 1, n) if (j + k - 1 <= n) 
			{
				int tempj = A.sum(j + k - 1) - A.sum(j - 1);
				if (temp == k * 2)
				{
					ans = (ans + powerpow(2, Z.sum(n))) % MOD;
					break;
				}
				else if (temp 
			}
			else break;
		}
	}
	else break;
	cout << ans % MOD;
	return 0;
}
