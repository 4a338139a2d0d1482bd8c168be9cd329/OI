/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-22 08:59
#
# Filename: boss.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 75;

int N, M, HP, MP, SP, D_HP, D_MP, D_SP, X, N1, N2;
int a[maxn], B[maxn], C[maxn], Z[maxn], Y[maxn], ans;
bool flag;

void dfs(int x, int P1, int P2, int P3, int P4)
{
    P1 = min(P1, HP); P2 = min(P2, MP); P3 = min(P3, SP);
    if ( x > ans ) return ;
    if ( P4 <= 0 )
    {
        flag = true;
        ans = min(ans, x - 1);
        return ;
    }
    if ( P1 <= 0 ) return ;
    dfs(x + 1, P1 - a[x], P2, P3 + D_SP, P4 - X);
    REP(i, 1, N1)
        if ( B[i] <= P2 ) dfs(x + 1, P1 - a[x], P2 - B[i], P3, P4 - Y[i]);
    REP(i, 1, N2)
        if ( C[i] <= P3 ) dfs(x + 1, P1 - a[x], P2, P3 - C[i], P4 - Z[i]);
    dfs(x + 1, P1 - a[x] + D_HP, P2, P3, P4);
    dfs(x + 1, P1 - a[x], P2 + D_MP, P3, P4);
}

int main()
{
    freopen("boss.in", "r", stdin);
    freopen("boss.out", "w", stdout);
    int T;
    scanf("%d", &T);
    while ( T -- )
    {
        flag = false;
        scanf("%d%d%d%d%d%d%d%d%d", &N, &M, &HP, &MP, &SP, &D_HP, &D_MP, &D_SP, &X);
        ans = N;
        REP(i, 1, N)
            scanf("%d", &a[i]);
        scanf("%d", &N1);
        REP(i, 1, N1)
            scanf("%d%d", &B[i], &Y[i]);
        scanf("%d", &N2);
        REP(i, 1, N2)
            scanf("%d%d", &C[i], &Z[i]);
        dfs(1, HP, MP, SP, M);
        if ( flag == false )
            printf("Tie\n");
        else
            printf("Yes %d\n", ans);
    }
    return 0;
}

