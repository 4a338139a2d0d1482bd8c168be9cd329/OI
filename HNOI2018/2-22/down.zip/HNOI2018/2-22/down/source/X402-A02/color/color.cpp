/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-22 09:29
#
# Filename: color.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 110;

int n, k, a[maxn], ans;
int t[maxn];

bool pd()
{
    int sum = 0, s1 = 0, s2 = 0;
    mem(t);
    for ( int i = 1; i <= n; )
    {
        while ( a[i] == 1 && i <= n ) 
        {
            ++ s1;
            ++ i;
        }
        t[++ sum] = s1;
        s1 = 0;
        while ( a[i] == 2 && i <= n )
        {
            ++ s2;
            ++ i;
        }
        t[++ sum] = s2;
        s2 = 0;
    }
    for ( int i = 1; i <= sum; i += 2 )
    {
        for ( int j = i + 1; j <= sum; j += 2 )
        {
            int s = min(t[i], t[j]);
            if ( s >= k ) 
                return true;
        }
    }
    return false;
}

void dfs(int x)
{
    if ( x == n + 1 ) 
    {
        if ( pd() ) ++ ans;
        return ;
    }
    if ( a[x] ) dfs(x + 1);
    else {
        a[x] = 1;
        dfs(x + 1);
        a[x] = 2;
        dfs(x + 1);
        a[x] = 0;
    }
}

int main()
{
    freopen("color.in", "r", stdin);
    freopen("color.out", "w", stdout);
    scanf("%d%d", &n, &k);
    getchar();
    REP(i, 1, n)
    {
        char c;
        scanf("%c", &c);
        if ( c == 'X' ) a[i] = 0;
        if ( c == 'W' ) a[i] = 2;
        if ( c == 'B' ) a[i] = 1;
    }
    dfs(1);
    printf("%d\n", ans);
    return 0;
}

