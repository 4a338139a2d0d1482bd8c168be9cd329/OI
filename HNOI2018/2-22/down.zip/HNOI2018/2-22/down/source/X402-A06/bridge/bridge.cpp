#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int Begin[maxn], to[maxn], e = 1, Next[maxn], n, m, vis[maxn];

int link[6005][6005];

void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read(), m = read();
}

void pre_work(){
	For(i, 1, n-1) {
		add(i, i+1), add(i+1, i);
		link[i][i+1] = link[i+1][i] = e;

		add(i+n, i+1+n), add(i+1+n, i+n);
		link[i+n][i+1+n] = link[i+1+n][i+n] = e;
	}

	For(i, 1, n) {
		add(i, i+n), add(i+n, i);
		link[i][i+n] = link[i+n][i] = e;
	}
}

int pre[maxn], low[maxn], dfs_clock, Ans = 0;

void dfs(int h,int father){
	pre[h] = low[h] = ++ dfs_clock;
	for(int i = Begin[h];i ;i = Next[i]){
		int v = to[i];

		if(v == father || vis[i]) continue;
		if(!pre[v]){
			dfs(v, h);
			low[h] = min(low[h], low[v]);
		}
		else low[h] = min(low[h], pre[v]);
	}

	if(low[h] == pre[h] && father != -1) ++ Ans;
}

void solve_bf(){
	while(m--){
		int tp = read(), x0 = read(), y0 = read(), x1 = read(), y1 = read();
		int x = y0 + (x0-1) * n, y = y1 + (x1-1) * n;

		if(tp == 1) vis[link[x][y]] = 0, vis[link[x][y]^1] = 0;
		else vis[link[x][y]] = 1, vis[link[x][y]^1] = 1;
		
		Ans = 0;
		dfs_clock = 0; 
		For(i, 1, n * 2) pre[i] = 0;
		For(i, 1, n * 2) if(!pre[i]) dfs(i, -1);

		printf("%d\n", Ans);
	}
}

int main(){

	freopen("bridge.in", "r", stdin);
	freopen("bridge.out", "w", stdout);

	Get();
	pre_work();
	solve_bf();

	return 0;
}
