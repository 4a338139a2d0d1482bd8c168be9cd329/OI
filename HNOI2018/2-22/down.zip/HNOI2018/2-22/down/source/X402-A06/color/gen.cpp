#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int main(){
	
	srand(time(NULL));
	int n = rand() % 20 + 1, k = rand() % (n / 2) + 1;
	printf("%d %d\n", n, k);
	For(i, 1, n){
		int x = rand() % 5;
		if(x == 0) printf("W");
		else if(x == 1) printf("B");
		else printf("X");
	}

	return 0;
}
