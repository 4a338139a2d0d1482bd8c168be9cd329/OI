#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

char s[maxn];

int pos[maxn], cnt, n, k;

void Get(){
	n = read(), k = read();
	scanf("%s", s+1);
	For(i, 1, n) if(s[i] == 'X') pos[++cnt] = i;
}

void solve_bf(){
	int tmp = (1 << cnt) - 1, Ans = 0;
	For(i, 0, tmp){
		For(j, 1, cnt){
			if(i & (1 << j-1) ){
				s[pos[j]] = 'W';
			}
			else s[pos[j]] = 'B';
		}

		int loc = -1;
		For(i, 1, n - k + 1){
			bool flag = 0;
			For(j, i, i + k - 1){
				if(s[j] != 'B'){
					flag = 1;
					break;
				}
			}

			if(!flag) {loc = i; break;}
		}

		if(loc == -1) continue;

		For(i, loc+1, n - k + 1){
			bool flag = 0;
			For(j, i, i + k - 1){
				if(s[j] != 'W'){
					flag = 1;
					break;
				}
			}

			if(!flag) {++ Ans; break;}
		}
	}

	printf("%d\n", Ans);
}

int dp[2010][2010][2][2][2];

const int mod = 1e9 + 7;

void solve(){
	if(s[1] == 'B')	dp[1][1][1][(k==1)][0] = 1;
	else if(s[1] == 'W') dp[1][1][0][0][0] = 1;
	else{
		dp[1][1][1][(k==1)][0] = 1;
		dp[1][1][0][0][0] = 1;
	}
	
	For(i, 1, n - 1){
		For(j, 1, n - 1){
			For(d1, 0, 1){
				For(d2, 0, 1){
					For(d3, 0, 1){
						int now = 0;
						if( (now = dp[i][j][d1][d2][d3]) == 0) continue;

						if(s[i+1] == 'B'){
							if(d1 == 1){
								if(j >= k - 1){
									(dp[i+1][j+1][d1][1][d3] += now) %= mod;
								}
								else (dp[i+1][j+1][d1][d2][d3] += now) %= mod;
							}
							else{
								(dp[i+1][1][1][d2][d3] += now) %= mod;
							}
						}

						else if(s[i+1] == 'W'){
							if(d1 == 1){
								(dp[i+1][1][0][d2][d3] += now) %= mod;
							}
							else{
								if(j >= k - 1){
									bool w = (d2 || d3);
									(dp[i+1][j+1][d1][d2][w] += now) %= mod;
								}
								else (dp[i+1][j+1][d1][d2][d3] += now) %= mod;
							}
						}

						else{
							if(d1 == 1){
								if(j >= k - 1){
									(dp[i+1][j+1][d1][1][d3] += now) %= mod;
								}
								else (dp[i+1][j+1][d1][d2][d3] += now) %= mod;

								(dp[i+1][1][0][d2][d3] += now) %= mod;
							}
							else{
								if(j >= k - 1){
									bool w = (d2 || d3);
									(dp[i+1][j+1][d1][d2][w] += now) %= mod;
								}
								else (dp[i+1][j+1][d1][d2][d3] += now) %= mod;

								(dp[i+1][1][1][d2][d3] += now) %= mod;
							}
						}
					}
				}
			}
		}
	}

	int Ans = 0;
	For(i, 1, n){
		(Ans += dp[n][i][0][1][1]) %= mod;
		(Ans += dp[n][i][1][1][1]) %= mod;
	}

	printf("%d\n", Ans);
}

int main(){
	
	Get();
	solve_bf();

	return 0;
}
