#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int n, m, hp, mp, sp, dhp, dmp, dsp, x, n1, n2;

int a[maxn], b[maxn], y[maxn], c[maxn], z[maxn], Ans = inf;

bool flag = 0;

void dfs(int h, int HP, int MP, int SP, int boss){
	if(HP <= 0) return;
	if(h + 1 >= Ans) return;
	if(h == n){
		flag = 1;
		return;
	}

	if(boss <= x) {
		Ans = h + 1;
		return;
	}
	else dfs(h+1, HP - a[h+1], MP, min(sp, SP+dsp), boss - x);

	For(i, 1, n1){
		if(MP >= b[i]){
			if(boss - y[i] <= 0){
				Ans = h + 1;
				return;
			}
			else dfs(h+1, HP - a[h+1], MP - b[i], SP, boss - y[i]);
		}
	}

	For(i, 1, n2){
		if(SP >= c[i]){
			if(boss - z[i] <= 0){
				Ans = h + 1;
				return;
			}
			else dfs(h+1, HP - a[h+1], MP, SP - c[i], boss - z[i]);
		}
	}

	dfs(h+1, min(hp, HP + dhp) - a[h+1], MP, SP, boss);
	dfs(h+1, HP - a[h+1], min(mp, MP + dmp), SP, boss);
}

void solve_bf(){
	if(m == 0){
		printf("Yes 1\n");
		return;
	}

	flag = 0; Ans = inf;
	dfs(0, hp, mp, sp, m);

	if(Ans != inf) printf("Yes %d\n", Ans);
	else if(flag) printf("Tie\n");
	else printf("No\n");
}

int main(){
	
	freopen("boss.in", "r", stdin);
	freopen("boss.out", "w", stdout);

	int _ = read();
	while(_ --){
		n = read(), m = read();
		hp = read(), mp = read(), sp = read();
		dhp = read(), dmp = read(), dsp = read();
		x = read();

		For(i, 1, n) a[i] = read();
		
		n1 = read();
		For(i, 1, n1) b[i] = read(), y[i] = read();

		n2 = read();
		For(i, 1, n2) c[i] = read(), z[i] = read();

		solve_bf();
	}

	return 0;
}
