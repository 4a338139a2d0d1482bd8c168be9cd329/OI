
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int v[101][71][71][71],fg,sum=100000010,a[100010],b[100010],c[100010],y1[100010],z1[100010],n,m1,n1,n2,hp,mp,sp,dh,dm,ds,x1;
bool f[101][71][71][71];
void dfs(int d,int x,int y,int z,int ans){
	int i;
	if(ans>=m1){
		sum=min(sum,d);
		return;
	}
	if(d==n)return;
	if(v[d][x][y][z]>=ans && f[d][x][y][z])return;
	if(v[d][x+1][y][z]>=ans && f[d][x+1][y][z])return;
	if(v[d][x][y+1][z]>=ans && f[d][x][y+1][z])return;
	if(v[d][x][y][z+1]>=ans && f[d][x][y][z+1])return;
	if(d+1>=sum)return;
	v[d][x][y][z]=ans;
	f[d][x][y][z]=1;
	if(x>a[d]){
	    for(i=1;i<=n1;i++)
	        if(y>=b[i])dfs(d+1,x-a[d],y-b[i],z,ans+y1[i]);
	    for(i=1;i<=n2;i++)
	        if(z>=c[i])dfs(d+1,x-a[d],y,z-c[i],ans+z1[i]);
	    dfs(d+1,x-a[d],min(y+dm,mp),z,ans);
	    dfs(d+1,x-a[d],y,min(z+ds,sp),ans+x1);
    }
    if(x+dh>a[d]){
    	dfs(d+1,min(x+dh-a[d],hp),y,z,ans);
    }
}
int main(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	int i,j,k,t;
	scanf("%d",&t);
	while(t--){
		memset(v,0,sizeof(v));
		memset(f,0,sizeof(f));
	    scanf("%d%d%d%d%d%d%d%d%d",&n,&m1,&hp,&mp,&sp,&dh,&dm,&ds,&x1);
    	for(i=1;i<=n;i++)
        	 scanf("%d",&a[i]);
    	scanf("%d",&n1);
    	for(i=1;i<=n1;i++)
      	   scanf("%d%d",&b[i],&y1[i]);
    	scanf("%d",&n2);
    	for(i=1;i<=n2;i++)
     	    scanf("%d%d",&c[i],&z1[i]);
    	dfs(0,hp,mp,sp,0);
   		 if(sum==100000010){
    		int flag=hp;
    		for(i=1;i<=n;i++){
    	    	flag+=dh;
    	    	flag=min(flag,hp);
    	    	flag-=a[i];
    	    	if(flag<=0){printf("No\n");break;}
    		}
    		if(flag>0)printf("Tie\n");
    	}else printf("Yes %d\n",sum);
    	sum=100000010;
    }
	return 0;
}/*
1
90 9621 43 40 54 14 14 23 196
13 7 14 3 17 15 2 13 18 12 13 13 4 16 5 2 3 18 20 4 12 13 21 20 1 12 14 14 10 1 6 14 10 16 17 5 16 8 4 20 7 4 5 18 14 21 8 2 15 19 10 1 11 1 18 20 19 15 15 15 9 9 11 8 15 19 20 20 20 9 17 10 10 19 11 13 10 13 8 10 7 17 10 13 7 11 6 18 8 12 
4 8 896 12 1125 2 120 12 1017 
4 23 221 1 93 2 284 22 237 
*/
