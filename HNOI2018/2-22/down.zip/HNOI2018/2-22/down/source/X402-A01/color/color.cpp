#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int a[100010],n,k,ans;
int pd(){
	int i,j,g;
	for(i=1;i<=n;i++)
	    for(j=i+1;j<=n;j++){
	    	int flag=1;
	        for(g=1;g<=k;g++)
	             if(a[i+g-1]!=2 || a[j+g-1]!=1){
	             	flag=0;
	             	break;
	             }
	        if(flag)return 1;
	    }
	return 0;
}
void dfs(int x){
	int i;
	if(x==n+1){
		if(pd()){ans++;}
		ans%=1000000007;
		return;
	}
	if(a[x]==0){a[x]=1;dfs(x+1);a[x]=2;dfs(x+1);a[x]=0;}
	else dfs(x+1);
}
int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	int i,j,m;
	char c;
	scanf("%d %d",&n,&k);
	getchar();
	for(i=1;i<=n;i++){
	    scanf("%c",&c);
	    if(c=='W')a[i]=1;
	    if(c=='B')a[i]=2;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}

