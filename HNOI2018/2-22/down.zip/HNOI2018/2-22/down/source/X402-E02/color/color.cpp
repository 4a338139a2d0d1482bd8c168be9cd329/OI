#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int n,k,ans,c,y; char ch[200005];
void dfs(int x){
	if (x==n+1){
		c=0;
		For(i,1,n){
			if (ch[i]=='B') ++c; else c=0;
			if (c==k) {y=i+1; break;}
		}
		if (c<k) return; c=0;
		For(i,y,n){
			if (ch[i]=='W') ++c; else c=0;
			if (c==k) {++ans; break;}
		}
		return;
	}
	if (ch[x]=='X'){
		ch[x]='W'; dfs(x+1); ch[x]='B'; dfs(x+1); ch[x]='X';
	}
	else dfs(x+1);
}
int main(){
	freopen("color.in","r",stdin); freopen("color.out","w",stdout);
	n=read(),k=read();
	scanf("%s",ch+1);
	if (n<=20) dfs(1),printf("%d\n",ans);
	return 0;
}
