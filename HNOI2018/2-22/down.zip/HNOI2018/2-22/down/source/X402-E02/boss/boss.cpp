#include<bits/stdc++.h>
#define sol {an=2,ans=min(ans,l); return;}
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
short a[101][71][71][71]; int n1,n2,hp,mp,sp,n,m,dhp,dmp,dsp,x,q[105],an,ans;
struct no{
	int x,y;
}c[11],d[11];
bool cmd(no mo,no ha){
	return mo.x<ha.x;
}
void dfs2(int l,int h,int mm,int s,int h2){
	if (h<=0) return; if (l==n+1) {if (!an) an=1; return;}
	int e=h-q[l];
	if (h2-x<=0) sol
	dfs2(l+1,e,mm,min(sp,s+dsp),h2-x);
	if (mm>=c[1].x){
		if (h2-c[1].y<=0) sol
		dfs2(l+1,e,mm-c[1].x,s,h2-c[1].y);
	}
	if (s>=d[1].x){
		if (h2-d[1].y<=0) sol
		dfs2(l+1,e,mm,s-d[1].x,h2-d[1].y);
	}
	if (mm<mp) dfs2(l+1,e,min(mm+dmp,mp),s,h2);
	if (h<hp) dfs2(l+1,min(e+dhp,hp),mm,s,h2);
}
void dfs(int l,int h,int mm,int s,int h2){
	if (h<=0) return; if (ans<=l) return;
	if (l==n+1) {if (!an) an=1; return;}
	short &b=a[l][h][mm][s]; if (b!=0&&b<=h2) return; b=h2;
	int e=h-q[l],mo=0,ha=0;
	for(;mm>=c[mo+1].x;++mo); for(;s>=d[ha+1].x;++ha);
	if (h2-c[mo].y<=0||h2-d[ha].y<=0) sol
	for(int i=mo;i>=1;--i) dfs(l+1,e,mm-c[i].x,s,h2-c[i].y);
	for(int i=ha;i>=1;--i) dfs(l+1,e,mm,s-d[i].x,h2-d[i].y);
	if (h2-x<=0) sol
	dfs(l+1,e,mm,min(sp,s+dsp),h2-x);
	if (mm<mp) dfs(l+1,e,min(mm+dmp,mp),s,h2);
	if (h<hp) dfs(l+1,min(e+dhp,hp),mm,s,h2);
}
int main(){
	freopen("boss.in","r",stdin); freopen("boss.out","w",stdout);
	int _=read(); bool fl[11];
	while(_--){
		n=read(),m=read(),hp=read(),mp=read(),sp=read(),dhp=read(),dmp=read(),dsp=read(),x=read();
		For(i,1,n) q[i]=read();
		n1=read(); For(i,1,n1) c[i].x=read(),c[i].y=read();
		n2=read(); For(i,1,n2) d[i].x=read(),d[i].y=read();
		an=0,ans=10000;
		if (n<=10&&n1==1&&n2==1){
			dfs2(1,hp,mp,sp,m); if (!an) printf("No\n");
			else if (an==1) printf("Tie\n");
			else printf("Yes %d\n",ans); continue;
		}
		memset(fl,1,11);
		For(i,1,n1){
			if (c[i].y<=x) fl[i]=0;
			else For(j,1,n1){
				if (j==i) continue;
				if (c[i].x>=c[j].x&&c[i].y<=c[j].y) {fl[i]=0; break;}
			}
		}
		int z=n1; n1=0;
		For(i,1,z) if (fl[i]) c[++n1]=c[i];
		memset(fl,1,11);
		For(i,1,n2){
			if (d[i].y<=x) fl[i]=0;
			For(j,1,n2){
				if (j==i) continue;
				if (d[i].x>=d[j].x&&d[i].y<=d[j].y) {fl[i]=0; break;}
			}
		}
		z=n2,n2=0; memset(a,0,sizeof(a));
		For(i,1,z) if (fl[i]) d[++n2]=d[i];
		sort(c+1,c+1+n1,cmd); sort(d+1,d+1+n2,cmd); c[n1+1].x=d[n2+1].x=10000; c[0].y=d[0].y=0;
		dfs(1,hp,mp,sp,m); if (!an) printf("No\n");
		else if (an==1) printf("Tie\n");
		else printf("Yes %d\n",ans);
	}
	return 0;
}
