#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 2010;
const ll MOD = 1000000007;

int n, K, suf[MAXN];
char s[MAXN];
ll ans, dp[MAXN][MAXN][2];

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int main() {
	freopen("color.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j;
	scanf("%d%d", &n, &K);
	scanf("%s", s+1);
	suf[n] = s[n] == 'X';
	for(i = n-1; i >= 1; i--) suf[i] = suf[i+1]+(s[i] == 'X');
	dp[0][0][0] = 1;
	for(i = 0; i < n; i++) {
		for(j = 0; j < K-1; j++) {
			if(s[i+1] == 'B' || s[i+1] == 'X') update(dp[i+1][j+1][0], dp[i][j][0]);
			if(s[i+1] == 'W' || s[i+1] == 'X') update(dp[i+1][0][0], dp[i][j][0]);
		}
		if(s[i+1] == 'B' || s[i+1] == 'X') update(dp[i+1][0][1], dp[i][K-1][0]);
		if(s[i+1] == 'W' || s[i+1] == 'X') update(dp[i+1][0][0], dp[i][K-1][0]);
		for(j = 0; j < K; j++) {
			if(s[i+1] == 'B' || s[i+1] == 'X') update(dp[i+1][0][1], dp[i][j][1]);
			if(s[i+1] == 'W' || s[i+1] == 'X') update(dp[i+1][j+1][1], dp[i][j][1]);
		}
		update(ans, dp[i+1][K][1]*qpow(2, suf[i+2])%MOD);
	}
	printf("%lld\n", ans);
	return 0;
}
