#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 30;
const ll MOD = 1000000007;

int n, K, a[MAXN];
char s[MAXN];
ll ans;

void dfs(int u) {
	if(u == n+1) {
		int i, j;
		for(i = 1; i+K-1 <= n; i++) {
			for(j = 1; j <= K; j++) 
				if(a[i+j-1] != 1) break;
			if(j > K) break;
		}
		if(i+K-1 <= n) {
			for(i += K; i+K-1 <= n; i++) {
				for(j = 1; j <= K; j++)
					if(a[i+j-1] != 2) break;
				if(j > K) break;
			}
			if(i+K-1 <= n) ans++;
		}
		return;
	}
	if(a[u]) {
		dfs(u+1);
		return;
	}
	a[u] = 1;
	dfs(u+1);
	a[u] = 2;
	dfs(u+1);
	a[u] = 0;
}

int main() {
	freopen("color.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i;
	scanf("%d%d", &n, &K);
	scanf("%s", s+1);
	for(i = 1; i <= n; i++) {
		if(s[i] == 'W') a[i] = 2;
		else if(s[i] == 'B') a[i] = 1;
		else a[i] = 0;
	}
	dfs(1);
	printf("%lld\n", ans);
	return 0;
}
