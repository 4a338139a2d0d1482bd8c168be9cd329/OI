#include<bits/stdc++.h>
using namespace std;

const int MAXN = 3010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, cnt, dfn[MAXN<<1];
int low[MAXN<<1], ans;
bool g[2*MAXN][3];

void dfs(int u, int fa) {
	//printf("dfs(%d %d)\n", u, fa);
	int i;
	dfn[u] = low[u] = ++cnt;
	if(g[u][0]) {
		if(u-1 != fa) {
			if(dfn[u-1]) low[u] = min(low[u], dfn[u-1]);
			else {
				dfs(u-1, u);
				low[u] = min(low[u], low[u-1]);
				if(low[u-1] == dfn[u-1]) {
					//printf("%d %d %d %d\n", u, u-1, low[u-1], dfn[u-1]);
					ans++;
				}
			}
		}
	}
	if(g[u][1]) {
		if(u+1 != fa) {
			if(dfn[u+1]) low[u] = min(low[u], dfn[u+1]);
			else {
				dfs(u+1, u);
				low[u] = min(low[u], low[u+1]);
				if(low[u+1] == dfn[u+1]) {
					//printf("%d %d\n", u, u+1);
					ans++;
				}
			}
		}
	}
	if(g[u][2]) {
		int v = u > n ? u-n : u+n;
		if(v != fa) {
			if(dfn[v]) low[u] = min(low[u], dfn[v]);
			else {
				dfs(v, u);
				low[u] = min(low[u], low[v]);
				if(low[v] == dfn[v]) {
					//printf("%d %d\n", u, v);
					ans++;
				}
			}
		}
	}
}

int main() {
	freopen("bridge.in", "r", stdin);
	freopen("bridge.out", "w", stdout);

	int i;
	n = read(), m = read();
	for(i = 1; i <= n; i++) {
		g[i][0] = g[i][1] = g[i][2] = true;
		g[n+i][0] = g[n+i][1] = g[n+i][2] = true;
	}
	g[1][0] = g[n][1] = false;
	g[n+1][0] = g[n+n][1] = false;
	while(m--) {
		int op = read();
		int x0 = read(), y0 = read(), x1 = read(), y1 = read();
		if(op == 1) {
			if(x0 == x1) {
				if(y0 > y1) swap(y0, y1);
				g[(x0-1)*n+y0][1] = g[(x1-1)*n+y1][0] = true;
			}
			else {
				if(x0 > x1) swap(x0, x1);
				g[y0][2] = g[n+y0][2] = true;
			}
		}
		else {
			if(x0 == x1) {
				if(y0 > y1) swap(y0, y1);
				g[(x0-1)*n+y0][1] = g[(x1-1)*n+y1][0] = false;
			}
			else {
				if(x0 > x1) swap(x0, x1);
				g[y0][2] = g[n+y0][2] = false;
			}
		}
		memset(dfn, 0, sizeof(dfn));
		ans = cnt = 0;
		for(i = 1; i <= 2*n; i++) 
			if(!dfn[i]) dfs(i, 0);
		printf("%d\n", ans);
	}
	return 0;
}
