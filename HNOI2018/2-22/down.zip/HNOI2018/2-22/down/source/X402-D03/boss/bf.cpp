#include<bits/stdc++.h>
using namespace std;

const int MAXN = 20;
const int INF = 100000000;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmin(int &cur, int val) {
	if(val <= cur) cur = val;
}

int n, a[MAXN], B, Y, C, Z;
int HP, MP, SP, DHP, DMP, DSP, X;

inline int dfs(int cur, int hp, int mp, int sp, int m) {
	if(hp <= 0) return INF;
	if(cur == n+1) return n+1;
	int ans = INF;
	if(m <= X) return cur;
	else chkmin(ans, dfs(cur+1, hp-a[cur], mp, min(SP, sp+DSP), m-X));
	if(mp >= B) {
		if(m <= Y) return cur;
		else chkmin(ans, dfs(cur+1, hp-a[cur], mp-B, sp, m-Y));
	}
	if(sp >= C) {
		if(m <= Z) return cur;
		else chkmin(ans, dfs(cur+1, hp-a[cur], mp, sp-C, m-Z));
	}
	chkmin(ans, dfs(cur+1, min(hp+DHP, HP)-a[cur], mp, sp, m));
	chkmin(ans, dfs(cur+1, hp-a[cur], min(MP, mp+DMP), sp, m));
	return ans;
}

int m;

int main() {
	freopen("boss.in", "r", stdin);
	freopen("boss.out", "w", stdout);

	int T = read(), n1, n2;
	while(T--) {
		n = read(), m = read();
		HP = read(), MP = read(), SP = read();
		DHP = read(), DMP = read(), DSP = read();
		X = read();
		generate(a+1, a+n+1, read);
		n1 = read();
		B = read(), Y = read();
		n2 = read();
		C = read(), Z = read();
		int ans = dfs(1, HP, MP, SP, m);
		if(ans == INF) printf("No\n");
		else if(ans == n+1) printf("Tie\n");
		else printf("Yes %d\n", ans);
	}
	return 0;
}
