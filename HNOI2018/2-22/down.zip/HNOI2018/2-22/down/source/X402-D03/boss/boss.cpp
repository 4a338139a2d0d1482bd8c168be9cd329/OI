#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 110;
const int INF = 100000000;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmax(ll &cur, ll val) {
	if(val > cur) cur = val;
}

int n, a[MAXN], b[15], y[15], c[15], z[15];
int HP, MP, SP, DHP, DMP, DSP, X;
ll dp[110][110][110], ans[110];
int M;

int main() {
	freopen("boss.in", "r", stdin);
	freopen("boss.out", "w", stdout);

	int T = read(), n1, n2, i, j, k, l;
	while(T--) {
		n = read(), M = read();
		HP = read(), MP = read(), SP = read();
		DHP = read(), DMP = read(), DSP = read();
		X = read();
		generate(a+1, a+n+1, read);
		n1 = read();
		for(i = 1; i <= n1; i++) 
			b[i] = read(), y[i] = read();
		n2 = read();
		for(i = 1; i <= n2; i++)
			c[i] = read(), z[i] = read();
		int t = HP;
		for(i = 1; i <= n; i++) {
			t = min(HP, t+DHP);
			t -= a[i];
			if(t < 0) break;
		}
		if(i <= n) {
			printf("No\n");
			continue;
		}
		memset(dp, 0, sizeof(dp));
		memset(ans, 0, sizeof(ans));
		for(i = 0; i < n; i++) 
			for(j = 0; j <= MP; j++) {
				for(k = 0; k <= SP; k++) {
					chkmax(dp[i+1][j][min(SP, k+DSP)], dp[i][j][k]+X);
					for(l = 1; l <= n1; l++) {
						if(b[l] > j) continue;
						chkmax(dp[i+1][j-b[l]][k], dp[i][j][k]+y[l]);
					}
					for(l = 1; l <= n2; l++) {
						if(c[l] > k) continue;
						chkmax(dp[i+1][j][k-c[l]], dp[i][j][k]+z[l]);
					}
					chkmax(dp[i+1][min(MP, j+DMP)][k], dp[i][j][k]);
					chkmax(ans[i], dp[i][j][k]);
				}
			}
		ll sum = 0;
		for(i = 1; i <= n; i++) {
			int d = (sum-HP)/DHP+1;
			if(d > i) continue;
			if(ans[i-d] >= M) break;
			sum += a[i];
		}
		if(i <= n) printf("Yes %d\n", i);
		else printf("Tie\n");
	}
	return 0;
}
