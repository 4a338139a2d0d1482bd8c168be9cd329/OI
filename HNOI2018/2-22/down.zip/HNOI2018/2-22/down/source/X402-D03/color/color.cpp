#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 1000010;
const ll MOD = 1000000007;
const int CNT = (MAXN<<1)-1;

int n, K, suf[MAXN], f0, f1;
char s[MAXN];
ll ans, p2[MAXN];

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

inline ll Mod(ll val) {
	if(val >= MOD) val -= MOD;
	return val;
}

struct Seg_T {
#define ls (p<<1)
#define rs (p<<1|1)
#define mid ((l+r)>>1)
	ll sum[MAXN*7], tag[MAXN*7];
	inline void init() {
		memset(tag, -1, sizeof(tag));
	}
	inline void pushdown(int p, int l, int r) {
		if(tag[p] != -1) {
			tag[ls] = tag[rs] = tag[p];
			sum[ls] = tag[p]*(mid-l+1)%MOD;
			sum[rs] = tag[p]*(r-mid)%MOD;
			tag[p] = -1;
		}
	}
	inline void modify(int p, int l, int r, int x, int y, ll val) {
		if(l == x && r == y) {
			sum[p] = val*(r-l+1)%MOD;
			tag[p] = val;
			return;
		}
		pushdown(p, l, r);
		if(y <= mid) modify(ls, l, mid, x, y, val);
		else if(x > mid) modify(rs, mid+1, r, x, y, val);
		else {
			modify(ls, l, mid, x, mid, val);
			modify(rs, mid+1, r, mid+1, y, val);
		}
		sum[p] = Mod(sum[ls]+sum[rs]);
	}
	inline void modify(int p, int l, int r, int x, ll val) {
		if(l == r) {
			sum[p] = tag[p] = val;
			return;
		}
		pushdown(p, l, r);
		if(x <= mid) modify(ls, l, mid, x, val);
		else modify(rs, mid+1, r, x, val);
		sum[p] = Mod(sum[ls]+sum[rs]);
	}
	inline ll query(int p, int l, int r, int x, int y) {
		if(l == x && r == y) return sum[p];
		pushdown(p, l, r);
		if(y <= mid) return query(ls, l, mid, x, y);
		if(x > mid) return query(rs, mid+1, r, x, y);
		return Mod(query(ls, l, mid, x, mid)+query(rs, mid+1, r, mid+1, y));
	}
	inline ll query(int p, int l, int r, int x) {
		if(l == r) return sum[p];
		pushdown(p, l, r);
		if(x <= mid) return query(ls, l, mid, x);
		return query(rs, mid+1, r, x);
	}
}T0, T1;

ll val, sum;

int main() {
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);

	int i;
	scanf("%d%d", &n, &K);
	scanf("%s", s+1);
	suf[n] = s[n] == 'X';
	for(i = n-1; i >= 1; i--) suf[i] = suf[i+1]+(s[i] == 'X');
	p2[0] = 1;
	for(i = 1; i <= n; i++) p2[i] = Mod(p2[i-1]<<1);
	T0.init(), T1.init();
	f0 = f1 = MAXN;
	T0.modify(1, 1, CNT, f0, 1);
	for(i = 0; i < n; i++) {
		if(s[i+1] == 'B') {
			f0--;
			val = T0.query(1, 1, CNT, f0+K);
			sum = T1.query(1, 1, CNT, f1, f1+K-1);
			T1.modify(1, 1, CNT, f1, f1+K-1, 0);
			T1.modify(1, 1, CNT, f1, Mod(sum+val));
		}
		else if(s[i+1] == 'W') {
			f1--;
			val = T1.query(1, 1, CNT, f1+K);
			update(ans, val*p2[suf[i+2]]%MOD);
			sum = T0.query(1, 1, CNT, f0, f0+K-1);
			T0.modify(1, 1, CNT, f0, f0+K-1, 0);
			T0.modify(1, 1, CNT, f0, sum);
		}
		else {
			sum = T0.query(1, 1, CNT, f0, f0+K-1);
			f0--;
			T0.modify(1, 1, CNT, f0, sum);
			val = T0.query(1, 1, CNT, f0+K);
			sum = T1.query(1, 1, CNT, f1, f1+K-1);
			f1--;
			T1.modify(1, 1, CNT, f1, Mod(sum+val));
			val = T1.query(1, 1, CNT, f1+K);
			update(ans, val*p2[suf[i+2]]%MOD);
		}
	}
	printf("%lld\n", ans);
	//cerr << clock() << endl;
	return 0;
}
