#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=1000000+100;
int n,m;
int fb[maxn],fm[maxn],sum[maxn];
char s[maxn];

inline void file() {
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
}

int main() {
	file();
	scanf("%d%d",&n,&m);
	scanf("%s",s+1);
	int p1=n+1,p2=n+1;
	Forr (i,n,1) {
		if (s[i]=='B') p1=i;
		else if (s[i]=='W') p2=i;
		fb[i]=p2; fm[i]=p1;
	}
//	For (i,1,n) printf("%d ",fb[i]); cout << endl;
//	For (i,1,n) printf("%d ",fm[i]);
	For (i,1,n)
		if (s[i]=='X') sum[i]=sum[i-1]+1;
		else sum[i]=sum[i-1];
	For (k,m,n/2)
		For (i,1,n-2*k+1) {
			if (s[i]=='W') continue;
			if (fb[i]<=i+k-1) continue;
			if (i>1 && s[i-1]=='B') continue;
			if (s[i+k]=='B') continue;
			For (j,i+k,n-k+1) {
				if (i+k+1==j) continue;
				if (s[i]=='B') continue;
				if (fm[i]<=j+k-1) continue;
				if (s[j-1]=='W') continue;
				if (j+k<=n && s[j+k]=='W') continue;
				cout << i << " " << j << endl;
				if (i==1 && j+k==n) ans=(ans+P[j-i-k-1])%modd;
				else if (i==1) ans=(ans+P[j-i-k-1])%modd;
			}
		}
	return 0;
}
