#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=1000+10;
struct node {
	int step,h,m,s,b;
}a[maxn];
struct node1 {
	int x,y;
}a1[20],a2[20];
int n,m,hp,mp,sp,dhp,dmp,dsp,x,n1,n2,ans;
int s[maxn];

inline void file() {
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void bfs() {
	queue<node>q;
	node p1,p2;
	p1.step=0; p1.h=hp; p1.m=mp; p1.s=sp; p1.b=m;
	q.push(p1);
	int flag=0;
	while (!q.empty()) {
		p1=q.front(); q.pop();
		if (p1.h>hp || p1.h<=0 || p1.m>mp || p1.m<0 || p1.s>sp || p1.s<0 || p1.b>m) continue;
//		printf("%d %d %d %d %d\n",p1.step,p1.h,p1.m,p1.s,p1.b);
		if (p1.b<=0) {
			ans=p1.step;
			return ;
		}
		p1.h-=s[p1.step];
		if (p1.h>hp || p1.h<=0) continue;
		if (p1.step==n) { flag=1; continue; }
		p1.step++;
		p2=p1; p2.b-=x; p2.s+=dsp; q.push(p2);
		For (i,1,n1) {
			p2=p1; p2.m-=a1[i].x; p2.b-=a1[i].y; q.push(p2);
		}
		For (i,1,n2) {
			p2=p1; p2.s-=a2[i].x; p2.b-=a2[i].y; q.push(p2);
		}
		p2=p1; p2.h+=dhp; q.push(p2);
		p2=p1; p2.m+=dmp; q.push(p2);
	}
	if (!flag) ans=0;
	else ans=-1;
}

int main() {
	file();
	int tt; read(tt);
	while (tt--) {
		ans=0;
		read(n); read(m); read(hp); read(mp); read(sp);
		read(dhp); read(dmp); read(dsp); read(x);
		For (i,1,n) read(s[i]);
		read(n1); For (i,1,n1) read(a1[i].x),read(a1[i].y);
		read(n2); For (i,1,n2) read(a2[i].x),read(a2[i].y);
		bfs();
		if (!ans) printf("No\n");
		else if (ans==-1) printf("Tie\n");
		else printf("Yes %d\n",ans);
	}
	return 0;
}
