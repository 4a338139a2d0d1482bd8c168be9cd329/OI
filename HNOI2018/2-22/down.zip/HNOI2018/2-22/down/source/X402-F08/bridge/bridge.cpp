#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=10000+10;
struct node {
	int to,next;
}e[maxn<<1];
int n,m,cnt,tot,ans;
int head[maxn],pre[maxn];

inline void file() {
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void add(int from,int to) {
	tot++;
	e[tot].to=to; e[tot].next=head[from]; head[from]=tot;
}

inline void remove(int from,int to) {
	if (e[head[from]].to==to) {
		head[from]=e[head[from]].next;
		return ;
	}
	int last=0;
	for (int i=head[from];i!=0;i=e[i].next) {
		int v=e[i].to;
		if (v==to) {
			e[last].next=e[i].next;
			return ;
		}
		last=i;
	}
}

int dfs(int u,int fa) {
	int lowu;
	pre[u]=lowu=++cnt;
	for (int i=head[u];i!=0;i=e[i].next) {
		int v=e[i].to;
		if (!pre[v]) {
			int lowv=dfs(v,u);
			chkmin(lowu,lowv);
			if (lowv>pre[u]) ++ans;
		}
		else if (v!=fa) chkmin(lowu,pre[v]);
	}
	return lowu;
}

inline void print() {
	For (ii,1,2*n) {
		printf("%d:",ii);
		for (int jj=head[ii];jj!=0;jj=e[jj].next) printf("%d ",e[jj].to);
		cout << endl;
	}
	cout << endl;
}

int main() {
	file();
	read(n); read(m);
	For (i,1,n) {
		add(i,i+n); add(i+n,i);
		if (i<n) {
			add(i,i+1); add(i+1,i);
			add(i+n,i+n+1); add(i+n+1,i+n);
		}
	}
	For (i,1,m) {
		int w,x1,y1,x2,y2;
		read(w); read(x1); read(y1); read(x2); read(y2);
		int z1=(x1-1)*n+y1,z2=(x2-1)*n+y2;
		if (w==1) {
			add(z1,z2); add(z2,z1);
			Set(pre,0); ans=0; cnt=0;
			For (i,1,2*n)
				if (!pre[i]) dfs(i,0);
			printf("%d\n",ans);
		}
		else {
			remove(z1,z2); remove(z2,z1);
			Set(pre,0); ans=0; cnt=0;
			For (i,1,2*n)
				if (!pre[i]) dfs(i,0);
			printf("%d\n",ans);
		}
	}
	return 0;
}
