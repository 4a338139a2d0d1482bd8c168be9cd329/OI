#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=100;
int n,k,ans;
char s[maxn],ss[maxn];

inline void file() {
	freopen("bf.in","r",stdin);
	freopen("bf.out","w",stdout);
}

inline int check() {
	int cnt1=0,cnt2=0,flag=0;
	For (i,1,n) {
		if (ss[i]=='B') {
			if (flag) continue;
			if (cnt1==0) cnt1++;
			else {
				if (ss[i]==ss[i-1]) cnt1++;
				else cnt1=1;
			}
			if (cnt1>=k) flag=1;
		}
		else if (ss[i]=='W') {
			if (cnt2==0) cnt2++;
			else {
				if (ss[i]==ss[i-1]) cnt2++;
				else cnt2=1;
			}
			if (flag && cnt2>=k) return 1;
		}
	}
	return 0;
}

void dfs(int nn) {
	if (nn==n+1) {
		if (check()) ans++;
		return ;
	}
	if (s[nn]=='X') {
		ss[nn]='W'; dfs(nn+1);
		ss[nn]='B'; dfs(nn+1);
	}
	else {
		ss[nn]=s[nn]; dfs(nn+1);
	}
}

int main() {
	file();
	scanf("%d%d",&n,&k);
	scanf("%s",s+1);
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
