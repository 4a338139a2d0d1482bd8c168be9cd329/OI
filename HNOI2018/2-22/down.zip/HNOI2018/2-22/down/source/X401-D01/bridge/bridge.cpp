#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Sint static int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	x=x*w;
}
inline void File(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
}

const int maxn=200000+10;
int n,m,n3;
bool lin[maxn*3];


inline int getnum(int x1,int y1,int x2,int y2){
	int k1,k2;
	if(x1==1)k1=y1;
	else k1=y1+n;
	if(x2==1)k2=y2;
	else k2=y2+n;
	if(k1>k2)swap(k1,k2);
	if(k1<=n&&k2<=n)return k1;
	else return k1+n;
}
inline void do1(){
	for(Rint i=1;i<=m;i++){
		Sint opt,x1,y1,x2,y2;
		read(opt);read(x1);read(y1);read(x2);read(y2);
		Sint p=getnum(x1,y1,x2,y2);
	}
}
inline void do2(){}

int main(){
	File();
	read(n);read(m);n3=n*3;
	for(Rint i=1;i<=n3;i++)lin[i]=1;
	if(n<=3000&&m<=3000)do1();
	else do2();
	return 0;
}
