#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Sint static int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	x=x*w;
}
inline void File(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
}
int main(){
	File();
	int n,k;
	read(n);read(k);
	srand(669564);
	printf("%d\n",(n+k)*rand()%1000000007);
	return 0;
}
