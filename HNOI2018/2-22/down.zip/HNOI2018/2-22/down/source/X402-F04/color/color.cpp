//2018-2-22
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000000 + 5)
const int P = 1e9 + 7;

int n, m, f[N][2][3], sum[2][N];
char s[N];

inline void Get(int &a, int av){
	a += av;
	if(a < 0) a += P;
	else if(a >= P) a -= P;
}

int main(){
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);
	
	scanf("%d%d%s", &n, &m, s + 1);
	For(i, 1, n){
		sum[0][i] = sum[0][i - 1] + (s[i] == 'B');
		sum[1][i] = sum[1][i - 1] + (s[i] == 'W');
	}

	f[0][1][0] = 1;
	For(i, 1, n){
		if(i >= m){
			if(sum[0][i] == sum[0][i - m])
				Get(f[i][1][2], f[i - m][0][1]), Get(f[i][1][1], -f[i - m][0][1]);
			if(sum[1][i] == sum[1][i - m])
				Get(f[i][0][1], f[i - m][1][0]), Get(f[i][0][0], -f[i - m][1][0]);
		}

		if(s[i] != 'W') For(j, 0, 2)
			Get(f[i][0][j], f[i - 1][0][j]), Get(f[i][0][j], f[i - 1][1][j]);
			
		if(s[i] != 'B') For(j, 0, 2)
			Get(f[i][1][j], f[i - 1][0][j]), Get(f[i][1][j], f[i - 1][1][j]);			
	}

	int ans = f[n][0][2] + f[n][1][2];
	printf("%d\n", ans >= P? ans - P: ans);

	return 0;
}
