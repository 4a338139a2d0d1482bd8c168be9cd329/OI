//2018-2-22
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (200000 + 5)

int lest[N], rest[N];
int n, m, ans, upl[N], upr[N], downl[N], downr[N];
bool bri[4][N];

void Get(int x1, int y1, int x2, int y2, int &type, int &id){
	id = y1;
	if(x1 != x2) type = 3;
	else if(x1 == 1) type = 1;
	else type = 2;
}

void Solve_del(int o, int id){
	if(type < 3){
		ql = lest[id], qr = rest[id];
		bri[o].Modify(1, 1, n, );
	}else{
	}
}

int main(){
	freopen("bridge.in", "r", stdin);
	freopen("bridge.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) upl[i] = downl[i] = 1, upr[i] = downr[i] = n;
	
	int op, x1, y1, x2, y2;
	int o, id;

	while(m--){
		scanf("%d%d%d%d%d", &op, &x1, &y1, &x2, &y2);
		Get(x1, y1, x2, y2, o, id);

		if(op == 1){
		}else if(op == 2){
			if(bri[o][id]) --ans;	
			else Solve_del(o, id);
		}
	}

	return 0;
}
