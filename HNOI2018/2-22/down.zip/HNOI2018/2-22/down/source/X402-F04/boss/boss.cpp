//2018-2-22
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (1000 + 5)

struct node{
	int o, a, b, c;
	bool operator <(const node &rhs)const{
		if(o != rhs.o) return o < rhs.o;
		if(a != rhs.a) return a < rhs.a;
		if(b != rhs.b) return b < rhs.b;
		return c < rhs.c;
	}
};

struct rnode{
	int a, v;
	bool operator <(const rnode &rhs)const{
		return v == rhs.v? a < rhs.a: v < rhs.v;
	}
}b[N], c[N];

int mxg, Tot;
int n, m, hp, mp, sp, dhp, dmp, dsp, x, n1, n2, ans, attack[N];
map<node, int> ms;

void Dfs(int o, int nhp, int nmp, int nsp, int rem){
	node now = (node){o, nhp, nmp, nsp};
	if(ms.count(now) && ms[now] <= rem) return;
	ms[now] = rem;
	
	if(o - 1 >= ans) return;
	if(rem <= 0){
		ans = o - 1; return;
	}
	if(o > n || nhp <= 0) return;
	if(mxg * (n - o + 1) < rem) return;

	Dfs(o + 1, nhp - attack[o], nmp, nsp + dsp, rem - x);
	For(i, 1, n1)
		if(nmp >= b[i].a) Dfs(o + 1, nhp - attack[o], nmp - b[i].a, nsp, rem - b[i].v);
	For(i, 1, n2)
		if(nsp >= c[i].a) Dfs(o + 1, nhp - attack[o], nmp, nsp - c[i].a, rem - c[i].v);
	Dfs(o + 1, min(nhp + dhp, hp) - attack[o], nmp, nsp, rem);
	Dfs(o + 1, nhp - attack[o], min(nmp + dmp, mp), nsp, rem);
}

int main(){
	freopen("boss.in", "r", stdin);
	freopen("boss.out", "w", stdout);
	
	int T;

	scanf("%d", &T);
	while(T--){
		scanf("%d%d%d%d%d%d%d%d%d", &n, &m, &hp, &mp, &sp, &dhp, &dmp, &dsp, &x);
		For(i, 1, n) scanf("%d", &attack[i]);

		scanf("%d", &n1);
		For(i, 1, n1) scanf("%d%d", &b[i].a, &b[i].v);
		scanf("%d", &n2);
		For(i, 1, n2) scanf("%d%d", &c[i].a, &c[i].v);
		
		sort(b + 1, b + n1 + 1);
		sort(c + 1, c + n2 + 1);

		int tmp = hp;
		bool flag = false;

		mxg = max(x, max(b[1].v, c[1].v));
		For(i, 1, n){
			tmp = min(tmp + dhp, hp);
			tmp -= attack[i];
			if(tmp <= 0){
				puts("No"); flag = true; break;
			}
		}
		if(flag) continue;

		ans = n + 1; ms.clear(); Tot = 0;
		Dfs(1, hp, mp, sp, m);
		if(ans == n + 1) puts("Tie");
		else printf("Yes %d\n", ans);
	}

	return 0;
}
