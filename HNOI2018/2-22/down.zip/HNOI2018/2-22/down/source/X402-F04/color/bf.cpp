//2018-2-22
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (1000000 + 5)

int n, m, ans;
char s[N];

bool Check(){
	int a = 0, b = 0;
	int p = 0, tot;
	
	while(p < n){
		++p; tot = 1;
		char me = s[p];
		while(p < n && s[p + 1] == me) ++p, ++tot;

		if(me == 'B') a = max(a, tot);
		else if(a >= m) b = max(b, tot);
	}

	return a >= m && b >= m;
}

void Dfs(int i){
	if(i > n){
		if(Check()) ++ans;
		return;
	}

	if(s[i] != 'X') Dfs(i + 1);
	else{
		s[i] = 'W', Dfs(i + 1);
		s[i] = 'B', Dfs(i + 1);
		s[i] = 'X';
	}
}

int main(){
	freopen("color.in", "r", stdin);
	freopen("color2.out", "w", stdout);
	
	scanf("%d%d%s", &n, &m, s + 1);
	Dfs(1);
	printf("%d\n", ans);

	return 0;
}
