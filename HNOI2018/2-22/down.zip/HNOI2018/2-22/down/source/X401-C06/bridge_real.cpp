#include<bits/stdc++.h>
#define x first
#define y second
const int inf = 0x3f3f3f3f;
const int N = 1e5 + 10;
using namespace std;
int a[N], b[N], c[N];
int n, m;

struct node{
	int v,c;
	bool operator < (const struct node &d)const{
		return v<d.v;
	}
};

struct node d[N];
int sz=0;


set<node> s;
set<node>::iterator it,it1,it2;

namespace segT{
	#define l(x) (x<<1)	
	#define r(x) ((x<<1)|1)
	int ss[N];
	inline void mt(int x){
		ss[x]=ss[l(x)]+ss[r(x)];
	}
	inline void upd(int x,int l,int r,int p,int v){
		if(l==r) ss[x]=v;
		else{
			int mm=(l+r)>>1;
			if(p<=mm) upd(l(x),l,mm,p,v);
				 else upd(r(x),mm+1,r,p,v);
			mt(x);
		}
	}
	inline int qury(int x,int l,int r,int ql,int qr){
		if(ql<=l&&r<=qr) return ss[x]; 
		else{
			int ret=0,mm=(l+r)>>1;
			if(ql<=mm) ret+=qury(l(x),l,mm,ql,qr);
			 if(mm<qr) ret+=qury(r(x),mm+1,r,ql,qr);
			return ret;
		}
	}
}
using namespace segT;

bool single(int x){
	it = s.lower_bound((node){x,0});
	it1 = it2 = it;
	--it1; ++it2;

	if(it1->v != -inf){
		if(qury(1,1,n,it1->v,it->v-1)==(it->v-it1->v)) return 0;
	}

	if(it2->v != inf){
		if(qury(1,1,n,it->v,it2->v-1)==(it2->v-it->v)) return 0;
	}
	return 1;
}

bool le(int x){
	it = s.lower_bound((node){x,0});
	it1 = it;
	--it1;

	if(it1->v != -inf){
		if(qury(1,1,n,it1->v,it->v-1)==(it->v-it1->v)) return 1;
	}
	return 0;
}

int cl(int x){
	it = s.lower_bound((node){x,0});
	it1 = it;
	--it1;

	if(it1->v != -inf){
		if(qury(1,1,n,it1->v,it->v-1)==(it->v-it1->v)) return (it->v-it1->v+1)<<1;
	}
	return 0;
}

bool re(int x){
	it = s.lower_bound((node){x,0});
	it2 = it;
	++it2;

	if(it2->v != +inf){
		if(qury(1,1,n,it->v,it2->v-1)==(it2->v-it->v)) return 1;
	}
	return 0;
}

int cr(int x){
	it = s.lower_bound((node){x,0});
	it2 = it;
	++it2;

	if(it2->v != +inf){
		if(qury(1,1,n,it->v,it2->v-1)==(it2->v-it->v)) return (it2->v-it->v+1)<<1;
	}
	return 0;
}

bool un(int x){
	it = s.lower_bound((node){x,0});
	it1 = it2 = it;
	--it1;
	++it2;

	if(it1->v != -inf && it2->v != inf){
		if(qury(1,1,n,it1->v,it2->v-1)==(it2->v-it1->v)) return 1;
	}
	return 0;
}

namespace solver{
	void solve(){
		freopen("bridge.in","r",stdin);
		freopen("bridge.out","w",stdout);
		scanf("%d%d",&n,&m);
	
		int all=3*n-2;
		int t,x0,y0,x1,y1,flag=0,zg=0,sg=0;
		
		s.insert((node){-inf,0}); s.insert((node){+inf,0});
		for(int i=1; i<=n-1; ++i) a[i]=b[i]=c[i]=1;
		for(int i=1; i<=n-1; ++i) upd(1,1,n,i,a[i]&b[i]);
		for(int i=1; i<=n; ++i) s.insert((node){i,0});
		c[n] = 1;

		int ret = 0;
		for(int i=1; i<=m; ++i){
			scanf("%d%d%d%d%d",&t,&x0,&y0,&x1,&y1);
			sz=0; t%=2;

			if(t) all ++; else all--;
			if(x0==x1){
				if(y0>y1) swap(y0,y1);
			}
			if(y0==y1){
				if(x0>x1) swap(x0,x1);
			}
			flag=0;
			if(x0!=x1){
				c[y0]=t;
				if(t==0){
					zg--;
					if(single(y0)) sg--; else{
						if(!un(y0)) continue;
						if(le(y0)) ret-=cl(y0);
						if(re(y0)) ret-=cl(y0);
						
					}
				}
				else{
					zg++;
					if(single(y0)) sg++; else{
						if(!un(y0)) continue;
						if(le(y0)) ret+=cl(y0);
						if(re(y0)) ret+=cr(y0);
					}
				}
			}
			else if(x0==1) a[y0]=t,upd(1,1,n,y0,(bool)a[y0]&b[y0]); 
					  else b[y0]=t,upd(1,1,n,y0,(bool)a[y0]&b[y0]);
			printf("%d\n",all-ret-(zg-sg));
		}
	}
}

int main(){
	solver::solve();
}

