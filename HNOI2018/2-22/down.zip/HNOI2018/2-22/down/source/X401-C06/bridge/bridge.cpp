#include<bits/stdc++.h>
const int N = 1e5 + 10;
using namespace std;
int a[N], b[N], c[N];
int n, m;
namespace buf{
	int check(int x){
		int l = 1, r = 0, ret = 0, mxp = 0;
		while(l <= n){
			while((!c[l])) ++l;
			
			int r = l, mxp = l;
			while((b[r] && a[r])){
				++r;
				if(c[r]) mxp = r;
			}

			ret += (mxp-l)<<1;
			if(c[l] && c[mxp] && l < mxp) for(int g = l; g <= mxp; ++g) ret += c[g];
			l=r+1;
		}
		return ret;
	}
	void solve(){
		freopen("bridge.in","r",stdin);
		freopen("bridge.out","w",stdout);
		scanf("%d%d",&n,&m);
	
		int all=3*n-2;
		int t,x0,y0,x1,y1;
		
		for(int i=1; i<=n-1; ++i) a[i]=b[i]=c[i]=1;
		c[n] = 1;

		for(int i=1; i<=m; ++i){
			scanf("%d%d%d%d%d",&t,&x0,&y0,&x1,&y1);
			t %= 2;
			if(t) all ++; else all--;
			if(x0==x1){
				if(y0>y1) swap(y0,y1);
			}
			if(y0==y1){
				if(x0>x1) swap(x0,x1);
			}
			if(x0!=x1) c[y0]=t;
			  else if(x0==1) a[y0]=t; else b[y0]=t;

			printf("%d\n",all-check(i));
		}
	}
}

int main(){
	buf::solve();
}

