#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 110, INF = 0x3f3f3f3f;
template<class T>void read(T & x){
	x = 0; char c = getchar();
	while(!isdigit(c))c = getchar();
	while( isdigit(c))x = x * 10 + c - 48, c = getchar();
}
int dp[2][N][N][N], HP, MP, SP, n, M, A[N], N1, N2;
int B[N], C[N], Y[N], Z[N], Dh, Dm, Ds, X;
inline void file(){
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
}
void init(){
	read(n), read(M);
	read(HP), read(MP), read(SP);
	read(Dh), read(Dm), read(Ds), read(X);
	For(i, 1, n)read(A[i]);
	read(N1);
	For(i, 1, N1)read(B[i]), read(Y[i]);
	read(N2);
	For(i, 1, N2)read(C[i]), read(Z[i]);
}
int mi, pos;
void chmi(int &x, int y){
	x = min(x, y);
}
void solve(){
	int now = 0, pre = 1;
	memset(dp[0], INF, sizeof(dp[0]));
	dp[0][HP][MP][SP] = M;mi = M, pos = 0;
	For(i, 1, n){
		swap(now,pre);
		memset(dp[now], INF, sizeof(dp[0]));
		For(j, 1, HP)
			For(k, 0, MP)
				For(l, 0, SP)
					if(dp[pre][j][k][l]!=INF){
						int nsp, nhp = j - A[i], nmp = k;
						nsp = min(l + Ds, SP);
						if(nhp > 0)
							chmi(dp[now][nhp][k][nsp], dp[pre][j][k][l] - X);	
						if(dp[pre][j][k][l] - X <= 0){printf("Yes %d\n",i);return ;}
						nhp += Dh;
						if(nhp > 0)
							chmi(dp[now][min(nhp,HP)][k][l], dp[pre][j][k][l]);
						nhp -= Dh;
						nmp += Dm;
						if(nhp > 0)
							chmi(dp[now][nhp][min(nmp,MP)][l], dp[pre][j][k][l]);
						nmp -= Dm;
						For(r, 1, N1){
							nmp = k - B[r];
							if(nmp < 0)continue;
							if(nhp > 0)
								chmi(dp[now][nhp][nmp][l], dp[pre][j][k][l] - Y[r]);
							if(dp[pre][j][k][l] - Y[r] <= 0){
								printf("Yes %d\n",i);return ;
							}
						}
						For(r, 1, N2){
							nsp = l - C[r];
							if(nsp < 0)continue;
							if(nhp > 0)
								chmi(dp[now][nhp][k][nsp], dp[pre][j][k][l] - Z[r]);
							if(dp[pre][j][k][l] - Z[r] <= 0){
								printf("Yes %d\n",i);return ;
							}
						}
					}
	}
	For(i, 1, HP)
		For(j, 0, MP)
			For(k, 0, SP)
				if(dp[now][i][j][k] != INF)
					return void(puts("Tie"));
	puts("No");
}
int main(){
	file();
	int T=0;
	read(T);
	while(T--)init(),solve();
	return 0;
}
