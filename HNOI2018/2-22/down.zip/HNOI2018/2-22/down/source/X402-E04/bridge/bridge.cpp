#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i = Begin[u], v = to[i];i;i = Next[i], v = to[i])
#define pb push_back
#define ll long long 
using namespace std;
const int N = 400010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c = getchar();
	while( isdigit(c))x = x * 10 + c - 48, c = getchar();
}
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
#endif
}
int n, m, Begin[N], Next[N<<1], to[N<<1], e = 1;
struct opt{
	int tp,u,v;
}Q[N];
inline void add(int x,int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
namespace BF1{
	int low[N], pre[N], dfs_cnt, Ban[N<<1], cnt;
	void dfs(int u, int f){
		low[u] = pre[u] = ++dfs_cnt;
		Rep(i, u)if(!Ban[i] && v!=f){
			if(!pre[v])dfs(v, u), low[u] = min(low[u], low[v]);
			else low[u] = min(low[u], pre[v]);
			if(low[v] > pre[u]){
				cnt ++;
			}
		}
	}
	void solve(){
		For(i, 1, m){
			int op = Q[i].tp, u = Q[i].u, v = Q[i].v, edge;
			if(u > v)swap(u, v);
			if(v == u + 1) edge = u < n ? 2 * u : 2 * (u - 1);
			else edge = 2 * (u + 2 * n - 2);
			if(op == 1){
				Ban[edge] = Ban[edge ^ 1] = 0;
			}else 
				Ban[edge] = Ban[edge ^ 1] = 1;
			
			cnt = dfs_cnt = 0;
			For(j, 1, n * 2)pre[j] = 0;
			For(j, 1, n * 2)if(!pre[j])dfs(j, 0);
			printf("%d\n", cnt);
		}
	}
}

void init(){
	read(n), read(m);
	For(i, 1, m){
		read(Q[i].tp);
		int x, y;
		read(x), read(y);
		Q[i].u = (x - 1) * n + y;
		read(x), read(y);
		Q[i].v = (x - 1) * n + y;
	}
	For(i, 1, n - 1)add(i, i + 1), add(i + 1, i);
	For(i, n + 1, 2 * n - 1)add(i, i + 1), add(i + 1, i);
	For(i, 1, n)add(i, i + n), add(i + n, i);
}
void solve(){
	BF1::solve();
}
int main(){
	file();
	init();
	solve();
	return 0;
}
