#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const char ch[]={'B','X','W'};
int main(){
	freopen("color.in","w",stdout);
	srand(time(0));
	int n = rand()%25 + 10, K = rand() % 10 + 1;
	printf("%d %d\n", n, K);
	For(i, 1, n){
		printf("%c",ch[rand()%3]);
	}
	return 0;
}
