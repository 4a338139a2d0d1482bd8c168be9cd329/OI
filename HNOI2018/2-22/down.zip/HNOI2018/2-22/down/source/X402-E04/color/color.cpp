#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1000100, INF = 0x3f3f3f3f, Mod = 1e9 + 7;
template<class T>void read(T &x){
	x = 0; char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
}
int n, k;
char s[N];
int ans;
int cnt[3][N];
inline int ch(int x,int t){
	if(x - k + 1 <= 0)return 0;
	if(cnt[t^1][x] - cnt[t^1][x - k] > 0)return 0;
	return 1;
}

int p[N];
void init(){
	read(n),read(k);
	scanf("%s",s + 1);
	For(i, 1, n){
		cnt[0][i] = cnt[0][i - 1];
		cnt[1][i] = cnt[1][i - 1];
		cnt[2][i] = cnt[2][i - 1];
		p[i] = s[i] == 'X'? 2 : s[i] == 'B';
		cnt[p[i]][i] ++ ;
	}
}
ll f[N], g[N];
ll qpow(ll a, ll b){
	ll ret = 1;
	for(; b; b >>= 1, a = a * a % Mod)if(b & 1)ret = ret * a % Mod;
	return ret;
}
void solve(){
	f[0] = 0, g[0] = 0;
	if(2 * k > n)return void (puts("0"));
	For(i, 1, n){
		if(p[i] == 0)
			f[i] = f[i - 1];
		if(p[i] == 1){
			f[i] = f[i - 1];
			if(i - k > 0 && p[i - k] != 1)
				f[i] = (f[i] + (qpow(2, cnt[2][i - k - 1]) + Mod - f[i - k - 1])* ch(i, 1)) % Mod;
			if(i == k)
				f[i] = (f[i] + ch(i, 1)) % Mod;
		}
		if(p[i] == 2){
			f[i] = f[i - 1] * 2 % Mod;
			if(i - k > 0 && p[i - k] != 1)
				f[i] = (f[i] + (qpow(2, cnt[2][i - k - 1]) + Mod - f[i - k - 1])* ch(i, 1)) % Mod;
			if(i == k)
				f[i] = (f[i] + ch(i, 1)) % Mod;
		}
		if(p[i] == 1)
			g[i] = g[i - 1];
		else if(p[i] == 0){
			g[i] = g[i - 1];
			if(i - k > 0 && p[i - k] == 1)
				g[i] = (g[i] + (f[i - k] + Mod - g[i - k])* ch(i, 0)) % Mod;
			else if(i - k > 0 && p[i - k] == 2){
				g[i] = (g[i] + (f[i - k] + Mod - f[i - k - 1] + Mod - g[i - k - 1]) * ch(i, 0)) % Mod;
			}
		}else if(p[i] == 2){
			g[i] = g[i - 1] * 2 % Mod;
			if(i - k > 0 && p[i - k] == 1)
				g[i] = (g[i] + (f[i - k] + Mod - g[i - k])* ch(i, 0)) % Mod;
			else if(i - k > 0 && p[i - k] == 2){
				g[i] = (g[i] + (f[i - k] + Mod - f[i - k - 1] + Mod - g[i - k - 1]) * ch(i, 0)) % Mod;
			}
		}
	}
	printf("%lld\n",g[n]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}

