#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f, Mod = 1e9 + 7;
template<class T>void read(T &x){
	x = 0; char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("color.in","r",stdin);
	freopen("BF.out","w",stdout);
}
int n, k;
char s[N];
int p[N], ans;
int ch(int x,int t){
	For(i, x, x + k - 1)if(p[i] == (t^1))return 0;
	return 1;
}

inline bool check(){
	For(i, 1, n - k * 2 + 1)if(ch(i,1))
		For(j, i + k, n - k + 1)if(ch(j,0))return 1;
	return 0;
}
void dfs(int now){
	if(now > n)return void (ans += check());
	if(s[now - 1]!='X'){
		p[now] = s[now - 1] == 'B';
		dfs(now + 1);
		return ;
	}
	p[now] = 0;
	dfs(now + 1);
	p[now] = 1;
	dfs(now + 1);
}
void solve(){
	dfs(1);
	printf("%d\n",ans);
}
void init(){
	read(n),read(k);
	scanf("%s",s);
}
int main(){
	file();
	init();
	solve();
	return 0;
}

