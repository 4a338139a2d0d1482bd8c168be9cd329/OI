#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=1000000+10,Mod=1e9+7;
int n,k,sW[MAXN],sB[MAXN];
ll f[MAXN][4][3];
char s[MAXN];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void Getsum(int x)
{
	if(s[x]=='B')sB[x]=sB[x-1]+1,sW[x]=sW[x-1];
	if(s[x]=='W')sW[x]=sW[x-1]+1,sB[x]=sB[x-1];
	if(s[x]=='X')sW[x]=sW[x-1],sB[x]=sB[x-1];
}
inline void dpXB(int i)
{
	f[i][0][0]=(f[i-1][0][0]+f[i-1][0][1])%Mod;
	f[i][1][0]=(f[i-1][1][0]+f[i-1][1][1])%Mod;
	f[i][2][0]=(f[i-1][2][0]+f[i-1][2][1])%Mod;
	if(i<k)return ;
	f[i][0][0]=((f[i][0][0]-(sW[i]==sW[i-k]?f[i-k][0][1]:0))%Mod+Mod)%Mod;
	f[i][1][0]=(f[i][1][0]+(sW[i]==sW[i-k]?f[i-k][0][1]:0))%Mod;
}
inline void dpXW(int i)
{
	f[i][0][1]=(f[i-1][0][0]+f[i-1][0][1])%Mod;
	f[i][1][1]=(f[i-1][1][0]+f[i-1][1][1])%Mod;
	f[i][2][1]=(f[i-1][2][0]+f[i-1][2][1])%Mod;
	if(i<k)return ;
	f[i][1][1]=((f[i][1][1]-(sB[i]==sB[i-k]?f[i-k][1][0]:0))%Mod+Mod)%Mod;
	f[i][2][1]=(f[i][2][1]+(sB[i]==sB[i-k]?f[i-k][1][0]:0))%Mod;
}
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	read(n);read(k);
	scanf("%s",s+1);
	f[0][0][1]=1;
	for(register int i=1;i<=n;++i)
	{
		Getsum(i);
		if(s[i]!='B')dpXW(i);
		if(s[i]!='W')dpXB(i);
	}
	printf("%lld\n",(f[n][2][1]+f[n][2][0])%Mod);
	return 0;
}
