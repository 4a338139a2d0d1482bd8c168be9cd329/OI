#include<bits/stdc++.h>
using namespace std;
const int maxn=1e2+5,maxa=70+5,inf=1e9;
int t,n,m,hp,mp,sp,dhp,dmp,dsp,x,a[maxn],n1,b[maxn],y[maxn],n2,c[maxn],z[maxn];
int dp[2][maxa][maxa][maxa];
inline int min_(int a,int b){return a<=b?a:b;}
inline int max_(int a,int b){return a>=b?a:b;}
inline void chkmin(int&a,int b){if(a>b)a=b;}
inline void chkmax(int&a,int b){if(a<b)a=b;}
int main()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	scanf("%d",&t);
	while(t--)
{
		scanf("%d%d%d%d%d%d%d%d%d",&n,&m,&hp,&mp,&sp,&dhp,&dmp,&dsp,&x);
		for(int i=1;i<=n;++i)scanf("%d",&a[i]);
		scanf("%d",&n1);
		for(int i=1;i<=n1;++i)scanf("%d%d",&b[i],&y[i]);
		scanf("%d",&n2);
		for(int i=1;i<=n2;++i)scanf("%d%d",&c[i],&z[i]);
		for(int i=1;i<=hp;++i)
			for(int j=0;j<=mp;++j)
				for(int k=0;k<=sp;++k)dp[0][i][j][k]=inf;
		dp[0][hp][mp][sp]=m;
		for(int i=1;i<=n;++i)
		{
			for(int j=0;j<=hp;++j)
				for(int k=0;k<=mp;++k)
					for(int l=0;l<=sp;++l)dp[i&1][j][k][l]=inf;
			for(int j=1;j<=hp;++j)
				for(int k=0;k<=mp;++k)
					for(int l=0;l<=sp;++l)
						if(dp[i&1^1][j][k][l]<inf)
						{
							chkmin(dp[i&1][max_(0,j-a[i])][k][min_(sp,l+dsp)],dp[i&1^1][j][k][l]-x);
							for(int w=1;w<=n1;++w)
								if(k>=b[w])chkmin(dp[i&1][max_(0,j-a[i])][k-b[w]][l],dp[i&1^1][j][k][l]-y[w]);
							for(int w=1;w<=n2;++w)
								if(l>=c[w])chkmin(dp[i&1][max_(0,j-a[i])][k][l-c[w]],dp[i&1^1][j][k][l]-z[w]);
							chkmin(dp[i&1][max_(0,j-a[i])][min_(mp,k+dmp)][l],dp[i&1^1][j][k][l]);
							chkmin(dp[i&1][max_(0,min_(hp,j+dhp)-a[i])][k][l],dp[i&1^1][j][k][l]);
						}
			for(int j=0;j<=hp;++j)
				for(int k=0;k<=mp;++k)
					for(int l=0;l<=sp;++l)
						if(dp[i&1][j][k][l]<=0)
						{
							printf("Yes %d\n",i);
							goto done;
						}
		}
		for(int i=1;i<=hp;++i)
			for(int j=0;j<=mp;++j)
				for(int k=0;k<=sp;++k)
					if(dp[n&1][i][j][k]<inf)
					{
						puts("Tie");
						goto done;
					}
		puts("No");
done:
		;
	}
	return 0;
}
