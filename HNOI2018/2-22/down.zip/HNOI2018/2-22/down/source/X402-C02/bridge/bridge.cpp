#include<bits/stdc++.h>
using namespace std;
const int MAXN=200000+10;
int n,m,e=1,ans,beg[MAXN<<1],to[MAXN*6],nex[MAXN*6],w[MAXN*6],DFN[MAXN<<1],LOW[MAXN<<1],Visit_Num;
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline int id(int x,int y)
{
	return (x-1)*n+y;
}
inline void insert(int x,int y,int z)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}
inline void init()
{
	for(register int i=1;i<n;++i)insert(id(1,i),id(1,i+1),1),insert(id(1,i+1),id(1,i),1);
	for(register int i=1;i<n;++i)insert(id(2,i),id(2,i+1),1),insert(id(2,i+1),id(2,i),1);
	for(register int i=1;i<=n;++i)insert(id(1,i),id(2,i),1),insert(id(2,i),id(1,i),1);
}
inline void Tarjan(int x,int f)
{
	int ch=0;
	DFN[x]=LOW[x]=++Visit_Num;
	for(register int i=beg[x];i;i=nex[i])
		if(!w[i]||to[i]==f)continue;
		else if(!DFN[to[i]])
		{
			Tarjan(to[i],x);
			LOW[x]=min(LOW[x],LOW[to[i]]);
			if(LOW[to[i]]>DFN[x])ans++;
		}
		else LOW[x]=min(LOW[x],DFN[to[i]]);
}
int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	read(n);read(m);
	init();
	while(m--)
	{
		int opt,x1,y1,x2,y2;
		read(opt);read(x1);read(y1);read(x2);read(y2);
		if(x1==x2)w[((x1-1)*(n-1)*2)+(max(y1,y2)<<1)]=abs(opt-2),w[(((x1-1)*(n-1)*2)+(max(y1,y2)<<1))^1]=abs(opt-2);
		else w[(n-1)*4+(y1<<1)]=abs(opt-2),w[((n-1)*4+(y1<<1))^1]=abs(opt-2);
		ans=0;Visit_Num=0;
		memset(DFN,0,sizeof(DFN));
		memset(LOW,0,sizeof(LOW));
		for(register int i=1;i<=n*2;++i)
			if(!DFN[i])Tarjan(i,0);
		printf("%d\n",ans);
	}
	return 0;
}
