#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=1e9+7;
const int maxn=2e3+10;
int dp[maxn][maxn][2][3];
char a[maxn];
int lim,ans=0,n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
void dfs(int cur,int tot){
	if(cur>tot){
		int cnt=1,flag=0,i;
		for(i=2;i<=n;i++){
			if(a[i]==a[i-1]){
				cnt++;
				if(flag==0 && cnt>=lim && a[i]=='B')flag++;
				if(flag==1 && cnt>=lim && a[i]=='W')flag++;
			}
			else cnt=1;
		}
		if(flag==2)ans++;
		return;
	}
	if(a[cur]!='X')dfs(cur+1,tot);
	else{
		a[cur]='B';dfs(cur+1,tot);
		a[cur]='W';dfs(cur+1,tot);
		a[cur]='X';
	}
}
int main(){
	int i,j,k,l,m;
#ifndef ONLINE_JUDGE
	freopen("color.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	n=read();lim=read();
	scanf("%s",a+1);
	dfs(1,n);
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}

