#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
char c[]={'X','X','X','X','X','B','B','W','W'};
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k;
	freopen("gen.in","r",stdin);
	int rand_num=read();
	srand(time(0)+rand_num);
	freopen("boss.in","w",stdout);
	int T=5;
	printf("%d\n",T);
	while(T--){
		int n=1000,m=1000000+rand()%10000,HP=1000,MP=1000,SP=1000,DHP=rand()%100+20,DMP=rand()%100+20,DSP=rand()%100+20,X=rand()%1000;
		printf("%d %d %d %d %d %d %d %d %d\n",n,m,HP,MP,SP,DHP,DMP,DSP,X);
		for(i=1;i<=n;i++)printf("%d%c",rand()%20+10,i==n?'\n':' ');
		int n1=10;
		printf("%d ",n1);
		for(i=1;i<=n1;i++)printf("%d %d%c",rand()%200+50,rand()%8000+100,i==n?'\n':' ');
		int n2=10;
		printf("%d ",n2);
		for(i=1;i<=n2;i++)printf("%d %d%c",rand()%200+50,rand()%8000+100,i==n?'\n':' ');
	}
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	return 0;
}
