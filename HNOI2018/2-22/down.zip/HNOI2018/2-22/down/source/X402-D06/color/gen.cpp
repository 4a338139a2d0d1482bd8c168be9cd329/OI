#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
char c[]={'X','X','X','X','X','B','B','W','W'};
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n;
	freopen("gen.in","r",stdin);
	int rand_num=read();
	srand(time(0)+rand_num);
	freopen("color.in","w",stdout);
	n=25;k=rand()%4+2;
	printf("%d %d\n",n,k);
	for(i=1;i<=n;i++)printf("%c",c[rand()%9]);
	puts("");
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	return 0;
}
