#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e2+10;
const int maxN=10+10;
const int maxp=1e2+10;
inline void chkmax(int &a,int b){
	a=a>b?a:b;
}
int dp[maxn][maxp][maxp],Dp[maxn][maxp],a[maxn],b[maxN],c[maxN],y[maxN],z[maxN];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,s,T;
#ifndef ONLINE_JUDGE
	freopen("boss.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	T=read();
	while(T--){
		int HP,MP,SP,DHP,DMP,DSP,X,n1,n2;
		n=read();m=read();HP=read();MP=read();SP=read();DHP=read();DMP=read();DSP=read();X=read();
		for(i=1;i<=n;i++)a[i]=read();
		n1=read();
		for(i=1;i<=n1;i++)b[i]=read(),y[i]=read();
		n2=read();
		for(i=1;i<=n2;i++)c[i]=read(),z[i]=read();
		memset(dp,-63,sizeof(dp));
		dp[0][MP][SP]=0;
		int ans=n+1;
		for(i=0;i<=n;i++){
			if(ans<=n)break;
			for(j=0;j<=MP;j++){
				if(ans<=n)break;
				for(k=0;k<=SP;k++){
					if(dp[i][j][k]>=m){
						ans=i;
						break;
					}
					if(dp[i][j][k]<0)continue;
					int res=dp[i][j][k];
					chkmax(dp[i+1][j][min(SP,k+DSP)],res+X);
					for(s=1;s<=n1;s++)
						if(j>=b[s])chkmax(dp[i+1][j-b[s]][k],res+y[s]);
					for(s=1;s<=n2;s++)
						if(k>=c[s])chkmax(dp[i+1][j][k-c[s]],res+z[s]);
					chkmax(dp[i+1][min(MP,j+DMP)][k],res);
				}
			}
		}
		memset(Dp,-63,sizeof(Dp));
		Dp[1][HP]=1;
		int Ans=n+1;
		for(i=1;i<=n;i++){
			if(Ans<=n)break;
			for(j=0;j<=HP;j++){
				int res=Dp[i][j];
				if(Dp[i][j]<0)continue;
				if(Dp[i][j]>=ans){
					Ans=i;
					break;
				}
				if(j>a[i])chkmax(Dp[i+1][j-a[i]],res+1);
				if(min(j+DHP,HP)>a[i])chkmax(Dp[i+1][min(j+DHP,HP)-a[i]],res);
			}
		}
		if(Ans<=n){
			printf("Yes %d\n",Ans);
			cerr<<"Yes "<<Ans<<endl;
		}
		else{
			int flag=0;
			for(i=0;i<=HP;i++)
				if(Dp[n][i]>=0){
					flag=1;
					break;
				}
			if(!flag){
				puts("No");
				cerr<<"No"<<endl;
			}
			else{
				puts("Tie");
				cerr<<"Tie"<<endl;
			}
		}
	}
	return 0;
}

