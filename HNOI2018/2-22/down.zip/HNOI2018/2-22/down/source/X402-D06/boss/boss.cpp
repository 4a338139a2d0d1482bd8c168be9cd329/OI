#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e3+10;
const int maxN=10+10;
const int maxp=1e3+10;
inline void chkmax(int &a,int b){
	a=a>b?a:b;
}
int dp[maxn][maxp],Dp[maxn][maxp],a[maxn],b[maxN],c[maxN],y[maxN],z[maxN],MH[maxn],SH[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,s,T;
#ifndef ONLINE_JUDGE
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
#endif
	T=read();
	while(T--){
		int HP,MP,SP,DHP,DMP,DSP,X,n1,n2;
		n=read();m=read();HP=read();MP=read();SP=read();DHP=read();DMP=read();DSP=read();X=read();
		for(i=1;i<=n;i++)a[i]=read();
		n1=read();
		for(i=1;i<=n1;i++)b[i]=read(),y[i]=read();
		n2=read();
		for(i=1;i<=n2;i++)c[i]=read(),z[i]=read();
		memset(MH,-63,sizeof(MH));
		memset(SH,-63,sizeof(SH));
		memset(dp,-63,sizeof(dp));
		dp[0][MP]=0;
		for(i=0;i<=n;i++)
			for(j=0;j<=MP;j++){
				if(dp[i][j]<0)continue;
				int res=dp[i][j];
				for(k=1;k<=n1;k++)
					if(j>=b[k])chkmax(dp[i+1][j-b[k]],res+y[k]);
				chkmax(dp[i+1][min(MP,j+DMP)],res);
			}
		for(i=1;i<=n;i++)
			for(j=0;j<=MP;j++)
				chkmax(MH[i],dp[i][j]);
		memset(dp,-63,sizeof(dp));
		dp[0][SP]=0;
		for(i=0;i<=n;i++)
			for(j=0;j<=SP;j++){
				if(dp[i][j]<0)continue;
				int res=dp[i][j];
				for(k=1;k<=n2;k++)
					if(j>=c[k])chkmax(dp[i+1][j-c[k]],res+z[k]);
				chkmax(dp[i+1][min(SP,j+DSP)],res+X);
			}
		for(i=1;i<=n;i++)
			for(j=0;j<=SP;j++)
				chkmax(SH[i],dp[i][j]);
		int ans=n+1;
		for(i=1;i<=n;i++){
			if(ans<=n)break;
			for(j=0;j<=i;j++)
				if(SH[j]+MH[i-j]>=m){
					ans=i;
					break;
				}
		}
		memset(Dp,-63,sizeof(Dp));
		Dp[1][HP]=1;
		int Ans=n+1;
		for(i=1;i<=n;i++){
			if(Ans<=n)break;
			for(j=0;j<=HP;j++){
				int res=Dp[i][j];
				if(Dp[i][j]<0)continue;
				if(Dp[i][j]>=ans){
					Ans=i;
					break;
				}
				if(j>a[i])chkmax(Dp[i+1][j-a[i]],res+1);
				if(min(j+DHP,HP)>a[i])chkmax(Dp[i+1][min(j+DHP,HP)-a[i]],res);
			}
		}
		if(Ans<=n)printf("Yes %d\n",Ans);
		else{
			int flag=0;
			for(i=0;i<=HP;i++)
				if(Dp[n][i]>=0){
					flag=1;
					break;
				}
			if(!flag)puts("No");
			else puts("Tie");
		}
	}
	return 0;
}

