#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=1e9+7;
const int maxn=2e3+10;
int dp[maxn][maxn][2][3];
char a[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void Mod(int &x,int y){
	x+=y;
	if(x>=mod)x-=mod;
}
int main(){
	int i,j,k,l,m,n,lim;
#ifndef ONLINE_JUDGE
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
#endif
	n=read();lim=read();
	scanf("%s",a+1);
	dp[0][0][0][0]=1;
	for(i=1;i<=n;i++)
		for(j=0;j<i;j++)
			for(k=0;k<=1;k++)
				for(l=0;l<=2;l++){
					if(a[i]!='W'){
						int cnt=j,col=k;
						if(k==0)cnt++;
						else cnt=1,col^=1;
						if(col==l && cnt==lim)Mod(dp[i][cnt][col][l+1],dp[i-1][j][k][l]);
						else Mod(dp[i][cnt][col][l],dp[i-1][j][k][l]);
					}
					if(a[i]!='B'){
						int cnt=j,col=k;
						if(k==1)cnt++;
						else cnt=1,col^=1;
						if(col==l && cnt==lim)Mod(dp[i][cnt][col][l+1],dp[i-1][j][k][l]);
						else Mod(dp[i][cnt][col][l],dp[i-1][j][k][l]);
					}
				}
	int ans=0;
	for(i=1;i<=n;i++)
		for(j=0;j<=1;j++)
			Mod(ans,dp[n][i][j][2]);
	printf("%d\n",ans);
	return 0;
}

