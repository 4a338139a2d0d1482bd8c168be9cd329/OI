#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1005;
struct data{int x,y;}A[maxn],B[maxn];
int n,n1,n2,n3,m,hp,mp,sp,dhp,dmp,dsp,a[maxn];
int dp[maxn][maxn],Max0[maxn],Max1[maxn],Max2[maxn];
void work(){
	n=read(),m=read(),n3=1;
	hp=read(),mp=read(),sp=read();
	dhp=read(),dmp=read(),dsp=read();
	int x=read();
	REP(i,1,n)a[i]=read();
	n1=read();
	REP(i,1,n1)A[i].x=read(),A[i].y=read();
	A[++n1]=(data){-dmp,0};
	n2=read();
	REP(i,1,n2)B[i].x=read(),B[i].y=read();
	B[++n2]=(data){-dsp,x};
	memset(dp,-0x3f,sizeof(dp));
	memset(Max0,-0x3f,sizeof(Max0));
	dp[0][hp]=Max0[0]=0;
	REP(i,1,n){
		REP(j,1,hp){
			if(dp[i-1][j]>=0){
				if(j>a[i])chkmax(dp[i][j-a[i]],dp[i-1][j]+1);
				if(min(j+dhp,hp)>a[i])chkmax(dp[i][min(j+dhp,hp)-a[i]],dp[i-1][j]);
			}
		}
		REP(j,1,hp)chkmax(Max0[i],dp[i][j]);
		if(i<n)chkmax(n3,Max0[i]+1);
	}
	memset(dp,0,sizeof(dp));
	memset(Max1,0,sizeof(Max1));
	REP(i,1,n3){
		REP(j,0,mp)
			REP(k,1,n1)
				if(j>=A[k].x)
					chkmax(dp[i][min(j-A[k].x,mp)],dp[i-1][j]+A[k].y);
		REP(j,0,mp)
			chkmax(Max1[i],dp[i][j]);
	}
	memset(dp,0,sizeof(dp));
	memset(Max2,0,sizeof(Max2));
	REP(i,1,n3){
		REP(j,0,sp)
			REP(k,1,n2)
				if(j>=B[k].x)
					chkmax(dp[i][min(j-B[k].x,sp)],dp[i-1][j]+B[k].y);
		REP(j,0,sp)
			chkmax(Max2[i],dp[i][j]);
	}
	int ans=1e9;
	REP(i,1,n3){
		REP(j,0,i)
			if(Max1[j]+Max2[i-j]>=m)ans=i;
		if(ans!=1e9)break;
	}
	if(ans==1e9){
		puts(Max0[n]>=0?"Tie":"No");
		return;
	}
	REP(i,1,n)
		if(Max0[i-1]+1>=ans){
			printf("Yes ");
			write(i,'\n');
			break;
		}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
#endif
	int q_cnt=read();
	while(q_cnt--)work();
	return 0;
}
