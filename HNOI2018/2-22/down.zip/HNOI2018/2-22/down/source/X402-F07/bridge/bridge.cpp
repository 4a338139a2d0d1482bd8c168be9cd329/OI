#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=400005,dir[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
int n,m,ans=0;
int dfn[maxn],low[maxn],dfs_clock;
bool p[maxn][4];
int id(int x,int y){
	return (x-1)*n+y;
}
void dfs(int u,int x,int y,int fa){
	dfn[u]=low[u]=++dfs_clock;
	REP(k,0,3){
		if(!p[u][k])continue;
		int tx=x+dir[k][0],ty=y+dir[k][1],v=id(tx,ty);
		if(v==fa)continue;
		if(dfn[v])chkmin(low[u],dfn[v]);
		else dfs(v,tx,ty,u),chkmin(low[u],low[v]);
	}
	if(dfn[u]==low[u])++ans;
}
void solve(){
	dfs_clock=0,ans=0;
	REP(i,1,2*n)
		dfn[i]=low[i]=0;
	REP(i,1,2*n)
		if(!dfn[i])
			dfs(i,(i-1)/n+1,(i-1)%n+1,0),--ans;
	write(ans,'\n');
}
namespace solver{
	int ans[maxn],edge_cnt;
	struct Query{int u,v;}q[maxn];
	namespace link_cut_tree{
		bool rev[maxn<<1],tag[maxn<<1];
		int sum[maxn<<1],val[maxn<<1],ch[maxn<<1][2],fa[maxn<<1];
		bool isroot(int u){
			return (u!=ch[fa[u]][0])&&(u!=ch[fa[u]][1]);
		}
		void push_down(int p){
			int &u=ch[p][0],&v=ch[p][1];
			if(rev[p])
				rev[u]^=1,rev[v]^=1,rev[p]^=1,swap(u,v);
			if(tag[p]){
				tag[u]=1,val[u]=0,sum[u]=0;
				tag[v]=1,val[v]=0,sum[v]=0;
				tag[p]=0;
			}
		}
		void push_up(int p){
			sum[p]=sum[ch[p][0]]+sum[ch[p][1]]+val[p];
		}
		void push(int u){
			if(!isroot(u))push(fa[u]);
			push_down(u);
		}
		void rotate(int u){
			int p=fa[u],k=u==ch[p][1];
			if(!isroot(p))ch[fa[p]][p==ch[fa[p]][1]]=u;
			if(ch[u][k^1])fa[ch[u][k^1]]=p;
			ch[p][k]=ch[u][k^1],ch[u][k^1]=p;
			fa[u]=fa[p],fa[p]=u,push_up(p);
		}
		void splay(int u){
			push(u);
			while(!isroot(u)){
				int p=fa[u],g=fa[p];
				if(!isroot(p)){
					if((u==ch[p][1])^(p==ch[g][1]))rotate(p);
					else rotate(u);
				}rotate(u);
			}
			push_up(u);
		}
		void access(int u){
			int v=0;
			while(u){
				splay(u);
				ch[u][1]=v;
				u=fa[v=u];
			}
		}
		void set_root(int u){
			access(u),splay(u),rev[u]^=1;
		}
		void link(int u,int v){
			set_root(v),fa[v]=u;
		}
		bool check(int u,int v){
			set_root(u);
			while(fa[v])v=fa[v];
			return u==v;
		}
		int update(int u,int v){
			set_root(v),access(u),splay(u);
			int res=sum[u];
			tag[u]=1,val[u]=sum[u]=0;
			return res;
		}
	}
	using namespace link_cut_tree;
	void dfs(int u,int x,int y,int fa){
		dfn[u]=low[u]=++dfs_clock;
		REP(k,0,3){
			if(!p[u][k])continue;
			int tx=x+dir[k][0],ty=y+dir[k][1],v=id(tx,ty);
			if(v==fa)continue;
			if(dfn[v])chkmin(low[u],dfn[v]);
			else{
				dfs(v,tx,ty,u);
				chkmin(low[u],low[v]);
				val[++edge_cnt]=1;
				link(u,edge_cnt);
				link(v,edge_cnt);
			}
		}
		if(dfn[u]==low[u])++ans[m];
	}
	void solve(){
		dfs_clock=0,edge_cnt=2*n;
		REP(i,1,2*n)
			dfn[i]=low[i]=0;
		REP(i,1,2*n)
			if(!dfn[i])
				dfs(i,(i-1)/n+1,(i-1)%n+1,0),--ans[m];
	}
	void work(){
		REP(i,1,m){
			int type=read(),x1=read(),y1=read(),x2=read(),y2=read();
			q[i]=(Query){id(x1,y1),id(x2,y2)};
			if(x1>x2)swap(x1,x2);
			if(y1>y2)swap(y1,y2);
			if(x1==x2-1)p[id(x1,y1)][1]=p[id(x2,y2)][3]=type==1;
			else p[id(x1,y1)][0]=p[id(x2,y2)][2]=type==1;
		}
		solve();
		DREP(i,m,2){
			ans[i-1]=ans[i];
			int u=q[i].u,v=q[i].v;
			if(check(u,v)){
				ans[i-1]-=update(u,v);
			}else{
				val[++edge_cnt]=1;
				link(u,edge_cnt);
				link(v,edge_cnt);
				ans[i-1]++;
			}
		}
		REP(i,1,m)
			write(ans[i],'\n');
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n){
		if(i==1){
			p[i][0]=p[i][1]=1;
			p[n+i][0]=p[n+i][3]=1;
		}else if(i==n){
			p[i][2]=p[i][1]=1;
			p[n+i][2]=p[n+i][3]=1;
		}else{
			p[i][0]=p[i][1]=p[i][2]=1;
			p[n+i][0]=p[n+i][2]=p[n+i][3]=1;
		}
	}
	if((n>3000)&&(m>3000))solver::work();
	else{
		REP(i,1,m){
			int type=read(),x1=read(),y1=read(),x2=read(),y2=read();
			if(x1>x2)swap(x1,x2);
			if(y1>y2)swap(y1,y2);
			if(x1==x2-1)p[id(x1,y1)][1]=p[id(x2,y2)][3]=type==1;
			else p[id(x1,y1)][0]=p[id(x2,y2)][2]=type==1;
			solve();
		}
	}
	return 0;
}
