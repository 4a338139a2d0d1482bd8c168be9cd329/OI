#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1000005,mod=1e9+7;
int n,m,dp[maxn][2][3];
char s[maxn];
int sum[2][maxn];
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
	if(x<0)x+=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
#endif
	n=read(),m=read();
	scanf("%s",s+1);
	REP(i,1,n){
		sum[0][i]=sum[0][i-1]+(s[i]=='B');
		sum[1][i]=sum[1][i-1]+(s[i]=='W');
	}
	dp[0][1][0]=1;
	REP(i,1,n){
		if(s[i]!='W')
			REP(j,0,2){
				add(dp[i][0][j],dp[i-1][0][j]);
				add(dp[i][0][j],dp[i-1][1][j]);
			}
		if(s[i]!='B')
			REP(j,0,2){
				add(dp[i][1][j],dp[i-1][0][j]);
				add(dp[i][1][j],dp[i-1][1][j]);
			}
		if(i>=m){
			if(sum[1][i]==sum[1][i-m]){
				add(dp[i][0][1],dp[i-m][1][0]);
				add(dp[i][0][0],-dp[i-m][1][0]);
			}
			if(sum[0][i]==sum[0][i-m]){
				add(dp[i][1][2],dp[i-m][0][1]);
				add(dp[i][1][1],-dp[i-m][0][1]);
			}
		}
	}
	write((dp[n][0][2]+dp[n][1][2])%mod,'\n');
	return 0;
}
