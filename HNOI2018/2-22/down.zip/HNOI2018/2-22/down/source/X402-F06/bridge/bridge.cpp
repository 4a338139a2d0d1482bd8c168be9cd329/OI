#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=2e5+10;
int n;
int Up[maxn],Down[maxn],Middle[maxn];
void solve(){
	int pos=1,ans=0;
	while(pos<=n && (!Middle[pos] || !Up[pos] || !Down[pos])) ans+=Up[pos]+Down[pos]+Middle[pos],pos++; 
	int lst=pos;
	while(pos<=n){
		int st=pos;
		while(pos<=n && Up[pos] && Down[pos]){
			if(Middle[pos+1]) lst=pos+1;
			pos++;
		}
		if(pos>n) break;
		ans+=Up[lst]+Down[lst]+(st==lst && Middle[lst]);
		REP(i,lst+1,pos) ans+=Up[i]+Down[i]+Middle[i];
		++pos;
		while(pos<=n && (!Middle[pos] || !Up[pos] || !Down[pos])) ans+=Up[pos]+Down[pos]+Middle[pos],pos++; 
		lst=pos;
	}
	ans+=Up[lst]+Down[lst];
	REP(i,lst+1,n) ans+=Up[i]+Down[i]+Middle[i];
	printf("%d\n",ans);
}
int p1[maxn],p2[maxn],p3[maxn];
int solve1(int ty,int x){
	int res=0;
	if(ty==1 || ty==3){
		int l=x,r=x+1;
		while(!Middle[l]) p1[l]=p3[l]=1,l--;
		while(!Middle[r]) p1[r-1]=p3[r-1]=1,r++;
		p1[l]=p3[l]=p1[r-1]=p3[r-1]=1;
		if(l==1 || p1[l-1] || p3[l-1]) p2[l]=1;
		if(r==n || p1[r] || p3[r]) p2[r]=1;
		REP(i,l,r){
			if(i!=iend && p1[i] && Up[i]) res++;
			if(p2[i] && Middle[i]) res++;
			if(i!=iend && p3[i] && Down[i]) res++;
		}
		return res;
	}
	else if(ty==2){
		if(x==1 || p1[x-1] || p3[x-1]){
			int lst=x;
			while(!Middle[x]) p1[x]=p3[x]=1,++x;
			if(p1[x] || p3[x] || x==n) p2[x]=1;
			REP(i,lst,x){
				if(i!=iend && p1[i] && Up[i]) res++;
				if(p2[i] && Middle[i]) res++;
				if(i!=iend && p3[i] && Down[i]) res++;
			}
			return res;
		}
		if(x==n || p1[x] || p3[x]){
			int lst=x;
			while(!Middle[x]) p1[x-1]=p3[x-1]=1,--x;
			if(x==1 || p1[x-1] || p3[x-1]) p2[x]=1;
			REP(i,x,lst){
				if(i!=iend && p1[i] && Up[i]) res++;
				if(p2[i] && Middle[i]) res++;
				if(i!=iend && p3[i] && Down[i]) res++;
			}
			return res;
		}
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
#endif
	n=read();
	int m=read();
	REP(i,1,n-1) Up[i]=Down[i]=Middle[i]=1;
	Middle[n]=1;
	if(n>3000 && m>3000){
		int ans=0;
		while(m--){
			int ty=read(),x0=read(),y0=read(),x1=read(),y1=read();
			if(x0>x1 || (x0==x1 && y0>y1)) swap(x0,x1),swap(y0,y1);
			if(x0==1 && x1==1){
				Up[y0]^=1;
				if(p1[y0]) ans--;
				else ans+=solve1(1,y0);
			}
			else if(x0==2 && x1==2){
				Down[y0]^=1;
				if(p3[y0]) ans--;
				else ans+=solve1(3,y0);
			}
			else if(x0==1 && x1==2){
				Middle[y0]^=1;
				if(p2[y0]) ans--;
				else ans+=solve1(2,y0);
			}
			printf("%d\n",ans);
		}
		return 0;
	}
	while(m--){
		int ty=read(),x0=read(),y0=read(),x1=read(),y1=read();
		if(x0>x1 || (x0==x1 && y0>y1)) swap(x0,x1),swap(y0,y1);
		if(x0==1 && x1==1) Up[y0]^=1;
		else if(x0==2 && x1==2) Down[y0]^=1;
		else if(x0==1 && x1==2) Middle[y0]^=1;
		solve();
	}
	return 0;
}
