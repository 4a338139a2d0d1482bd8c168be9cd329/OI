#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e6+10,mod=1e9+7;
char s[maxn];
int dp[maxn][3][2];
int sum[2][maxn];
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
#endif
	int n=read(),k=read();
	scanf("%s",s+1);
	REP(i,1,n) sum[1][i]=sum[1][i-1]+(s[i]=='W'),sum[0][i]=sum[0][i-1]+(s[i]=='B');
	dp[0][0][1]=1;
	REP(i,1,n){
		if(s[i]!='W'){
			int tmp=0;
			REP(j,0,2) dp[i][j][0]=(dp[i-1][j][0]+dp[i-1][j][1])%mod;
			if(i-k>=0 && sum[1][i]-sum[1][i-k]==0) tmp=dp[i-k][0][1];
			add(dp[i][0][0],mod-tmp);
			add(dp[i][1][0],tmp);
		}
		if(s[i]!='B'){
			int tmp=0;
			REP(j,0,2) dp[i][j][1]=(dp[i-1][j][1]+dp[i-1][j][0])%mod;
			if(i-k>=0 && sum[0][i]-sum[0][i-k]==0) tmp=dp[i-k][1][0];
			add(dp[i][1][1],mod-tmp);
			add(dp[i][2][1],tmp);
		}
	}
	printf("%d\n",(dp[n][2][0]+dp[n][2][1])%mod);
	return 0;
}
