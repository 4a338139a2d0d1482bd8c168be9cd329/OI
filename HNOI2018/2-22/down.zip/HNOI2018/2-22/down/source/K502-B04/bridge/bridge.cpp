#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int N=2e5+5;
int sl[N],s[N][2];
int n,m,ans=0;
int lowbit(int x){
	return x&(-x);
}
void add1(int x,int k,int line){
	for (int i=x;i<=n;i+=lowbit(i))
		s[i][line]+=k;
}
void add2(int x,int k){
	for (int i=x;i<=n;i+=lowbit(i))
		sl[i]+=k;
}
int q1(int x,int line){
	int res=0;
	for (int i=x;i>=1;i-=lowbit(i))
		res+=s[i][line];
	return res;
}
int q2(int x){
	int res=0;
	for (int i=x;i>=1;i-=lowbit(i))
		res+=sl[i];
	return res;	
}
int find_l(int x,int line){
	int l=1,r=n;
	while (l<r){
		int mid=(l+r)>>1;
		int now=q1(mid,line);
		if (now<=x) l=mid+1;
		else r=mid;	
	}
	return r;
}
int find(int x){
	int l=1,r=n;
	while (l<r){
		int mid=(l+r)>>1;
		int now=q2(mid);
		if (now<=x) l=mid+1;
		else r=mid;	
	}
	return r;
}
int main(){
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	n=read();m=read();
	add1(1,1,0);add1(1,1,1);
	for (int i=1;i<=n;++i)
		add2(i,1);
	while (m--){
		/*for (int i=1;i<=n;++i)
			printf("%d ",q2(i));
		printf("\n");*/
		int type=read();
		int sx,sy,tx,ty;
		sx=read();sy=read();
		tx=read();ty=read();
		if (sx==tx){
			int x=--tx;
			if (ty<sy){
				++ty;
				--sy;	
			}
			if (type==2){
				add1(ty,1,x);
				if (q1(sy,x^1)!=q1(ty,x^1)){
					--ans;
					printf("%d\n",ans);
					continue;	
				}
				int c=q1(sy,x^1),c1=q1(sy,x),c2=c1+1;
				int l=find_l(c-1,x^1),r=find_l(c,x^1);
				int ll=find_l(c1-1,x),rr=find_l(c2,x);
				if (r!=n) --r;
				if (rr!=n) --rr;
				l=max(l,ll);r=min(r,rr);
				int k1=q2(sy),k2=k1+1;
				int pos1=find(k1-1),pos2=find(k2-1);
				if (pos1<l && pos2>r) ans-=2;
				if (pos1<l) pos1=sy;
				if (pos2>r) pos2=ty;
				ans+=(sy-pos1)*2+(pos2-ty)*2+1;
				//printf("%d %d\n",pos1,pos2);
				int cnt1=q2(sy)-q2(l-1),cnt2=q2(r)-q2(ty-1);
				if (cnt1+cnt2!=1 && (cnt1==1 || cnt2==1))
					ans+=(cnt1==1)+(cnt2==1);	
				printf("%d\n",ans);
			}else{
				if (q1(sy,x^1)!=q1(ty,x^1)){
					add1(ty,-1,x);
					++ans;
					printf("%d\n",ans);
					continue;	
				}
				int c=q1(sy,x^1),c1=q1(sy,x),c2=c1+1;
				int l=find_l(c-1,x^1),r=find_l(c,x^1);
				int ll=find_l(c1-1,x),rr=find_l(c2,x);
				if (r!=n) --r;
				if (rr!=n) --rr;
				l=max(l,ll);r=max(r,rr);
				int cnt1=q2(sy)-q2(l-1),cnt2=q2(r)-q2(ty-1);
				if (cnt1+cnt2!=1 && (cnt1==1 || cnt2==1))
					ans-=(cnt1==1)+(cnt2==1);	
				int k1=q2(sy),k2=k1+1;
				int pos1=find(k1-1),pos2=find(k2-1);
				if (pos1<l && pos2>r) ans+=2;
				if (pos1<l) pos1=sy;
				if (pos2>r) pos2=ty;
				ans-=(sy-pos1)*2+(pos2-ty)*2+1;
				add1(ty,-1,x);
				printf("%d\n",ans);
			}
		}else{
			if (type==2){
				int c1=q1(sy,0),c2=q1(sy,1);
				int l=find_l(c1-1,0),ll=find_l(c2-1,1);
				int r=find_l(c1,0),rr=find_l(c2,1);
				if (r!=n) --r;	
				if (rr!=n) --rr;
				l=max(l,ll);r=min(r,rr);
				int cnt1=q2(sy-1)-q2(l-1),cnt2=q2(r)-q2(sy);
				ans+=(cnt1+cnt2==1);
				if (cnt1==0 && cnt2==0) --ans;
				if (cnt1+cnt2==1){
					int k=q2(sy);
					int x=cnt1==1?find(k-2):find(k);	
					ans+=abs(x-sy)*2;
				}
				add2(sy,-1);
				printf("%d\n",ans);
			}else{
				add2(sy,1);
				int c1=q1(sy,0),c2=q1(sy,1);
				int l=find_l(c1-1,0),ll=find_l(c2-1,1);
				int r=find_l(c1,0),rr=find_l(c2,1);
				if (r!=n) --r;	
				if (rr!=n) --rr;
				l=max(l,ll);r=min(r,rr);
				int cnt1=q2(sy-1)-q2(l-1),cnt2=q2(r)-q2(sy);
				if (cnt1==0 && cnt2==0) ++ans;
				ans-=(cnt1+cnt2==1);
				if (cnt1+cnt2==1){
					int k=q2(sy);
					int x=cnt1==1?find(k):find(k-2);	
					ans-=abs(x-sy)*2;
				}
				printf("%d\n",ans);
			}
		}
	}
	return 0;
}

