#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<ctime>

namespace bf
{
	typedef long long ll;
	const int N=1010000,M=N*4,MOD=1000000007;
	inline void inc(int a,int &b){b=(a+b)%MOD;}

	struct segment_tree
	{
#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
		int w[M],tag[M];
		inline void down(int p,int L,int R)
		{
			if(tag[p])
			{
				inc(tag[p],tag[lt]);
				inc(tag[p],w[lt]);
				inc(tag[p],tag[rt]);
				inc(tag[p],w[rt]);
				tag[p]=0;
			}
		}
		void modify(int s,int t,int x,int p=1,int L=0,int R=N-1)
		{
			if(s>t)return;

			if(L>=s && R<=t){inc(x,tag[p]),inc(x,w[p]);return;}
			
			down(p,L,R);
			if(s<=mid)modify(s,t,x,lcq);
			if(t>mid)modify(s,t,x,rcq);
		}
		int ask(int x,int p=1,int L=0,int R=N-1)
		{
			if(L==R)return w[p];
			down(p,L,R);
			if(x<=mid)return ask(x,lcq);
			else return ask(x,rcq);
		}
	}f[4][2];

	std::vector<int> V0,V1;

	char s[N];
	int n,k;

	void initialize()
	{
		scanf("%d%d",&n,&k);
		scanf("%s",s+1);
		for(int i=1;i<=n;i++)
			if(s[i]=='W')V0.push_back(i);
			else if(s[i]=='B')V1.push_back(i);
		V0.push_back(n+1);
		V1.push_back(n+1);
	}

	void dp()
	{
		f[0][0].modify(0,0,1);f[0][1].modify(0,0,1);

		int ind0=0,ind1=0;

		for(int i=0;i<=n;i++)
			for(int S=0;S<4;S++)
			{
				if(S==1)continue;

				int v0=f[S][0].ask(i),v1=f[S][1].ask(i);
				int R0,R1;

				while(V0[ind0]<=i)ind0++;
				while(V1[ind1]<=i)ind1++;

				R0=V1[ind1];
				R1=V0[ind0];

				f[S][1].modify(i+1,std::min(i+k-1,R1-1),v0);
				f[S==3?S:2][1].modify(i+k,R1-1,v0);

				f[S][0].modify(i+1,std::min(i+k-1,R0-1),v1);
				f[S>=2?S|1:0][0].modify(i+k,R0-1,v1);
				
			}
	}

	void solve()
	{
		initialize();
		dp();

		int ans=(f[3][0].ask(n)+f[3][1].ask(n))%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	bf::solve();

	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
