#include<iostream>
#include<cstdio>
#include<cstring>
#include<set>

namespace many_many_segment_tree
{
	typedef std::set<int>::iterator sit;
	const int N=201000,M=N*4;

#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R

	struct ans_segment_tree
	{
		int w[M],sum[M],tag[M];
		inline void upd(int p){w[p]=w[lt]+w[rt];sum[p]=sum[lt]+sum[rt];}
		inline void down(int p)
		{
			if(tag[p]>0)
			{
				sum[lt]=w[lt];
				sum[rt]=w[rt];
				tag[lt]=tag[rt]=1;
				tag[p]=0;
			}
			if(tag[p]<0)
			{
				sum[lt]=sum[rt]=0;
				tag[lt]=tag[rt]=-1;
				tag[p]=0;
			}
		}
		void modify_w(int x,int y,int p=1,int L=1,int R=N-1)
		{
			if(L==R)
			{
				w[p]+=y;
				if(tag[p]>0)sum[p]=w[p];
				return;
			}
			down(p);
			if(x<=mid)modify_w(x,y,lcq);
			else modify_w(x,y,rcq);
			upd(p);
		}
		void modify(int s,int t,int x,int p=1,int L=1,int R=N-1)
		{
			if(L>=s && R<=t){sum[p]=x>0?w[p]:0;tag[p]=x;return;}
			down(p);
			if(s<=mid)modify(s,t,x,lcq);
			if(t>mid)modify(s,t,x,rcq);
			upd(p);
		}
		bool ask(int x,int p=1,int L=1,int R=N-1)
		{
			if(x<=0)return 0;
			if(L==R)return tag[p]>0;
			down(p);
			return (x<=mid?ask(x,lcq):ask(x,rcq));
		}
		inline int query(){return sum[1];}
	}RT,CT;

	struct line_segment_tree
	{
		int w[M];
		inline void upd(int p){w[p]=w[lt]+w[rt];}
		void modify(int x,int y,int p=1,int L=1,int R=N-1)
		{
			if(L==R){w[p]+=y;return;}
			if(x<=mid)modify(x,y,lcq);
			else modify(x,y,rcq);
			upd(p);
		}
		int query(int s,int t,int p=1,int L=1,int R=N-1)
		{
			if(L>=s && R<=t)return w[p];
			int ret=0;
			if(s<=mid)ret+=query(s,t,lcq);
			if(t>mid)ret+=query(s,t,rcq);
			return ret;
		}
		inline bool check(int s,int t){return query(s,t)==(t-s+1);}
	}T0,T1;

	std::set<int> S;

	int n,m;
	int cnt_edge;

	void initialize()
	{
		scanf("%d%d",&n,&m);
		cnt_edge=3*n-2;
		for(int i=1;i<=n;i++)
		{
			CT.modify_w(i,1);
			S.insert(i);
		}
		for(int i=1;i<n;i++)
		{
			RT.modify_w(i,2);
			T0.modify(i,1);
			T1.modify(i,1);
		}
		CT.modify(1,n,1);
		RT.modify(1,n-1,1);
	}

	void add_col(int x)
	{
		CT.modify_w(x,1);
		S.insert(x);

		if(CT.ask(x))return;

		sit it=S.lower_bound(x);

		if(it!=S.begin())
		{
			int dx=*(--it);

			if(T0.check(dx,x-1) && T1.check(dx,x-1))
			{
				CT.modify(dx,x,1);
				RT.modify(dx,x-1,1);
			}
		}

		it=S.upper_bound(x);
		if(it!=S.end())
		{
			int dx=*it;
			if(T0.check(x,dx-1) && T1.check(x,dx-1))
			{
				CT.modify(x,dx,1);
				RT.modify(x,dx-1,1);
			}
		}
	}
	void del_col(int x)
	{
		CT.modify_w(x,-1);
		S.erase(x);

		if(!CT.ask(x))return;
		if(RT.ask(x-1) && RT.ask(x))return;

		if(RT.ask(x-1))
		{
			int dx=*(--S.lower_bound(x)),L=dx;
			if(RT.ask(dx-1))L++;

			CT.modify(L,x,-1);
			RT.modify(dx,x-1,-1);
		}
		else 
		{
			int dx=*S.upper_bound(x),R=dx;

			if(RT.ask(dx))R--;

			CT.modify(x,R,-1);
			RT.modify(x,dx-1,-1);
		}
	}
	void add_row(int x,int y)
	{
		RT.modify_w(y,1);
		if(x==0)T0.modify(y,1);
		else T1.modify(y,1);

		sit pre=S.upper_bound(y),suc;

		if(pre==S.end() || pre==S.begin())return;

		suc=pre,pre--;
		int L=*pre,R=*suc;

		if(T0.check(L,R-1) && T1.check(L,R-1))
		{
			CT.modify(L,R,1);
			RT.modify(L,R-1,1);
		}
	}
	void del_row(int x,int y)
	{
		RT.modify_w(y,-1);
		if(x==0)T0.modify(y,-1);
		else T1.modify(y,-1);

		sit pre=S.upper_bound(y),suc;

		if(pre==S.end() || pre==S.begin())return;
		suc=pre,pre--;

		int L=*pre,R=*suc;

		if(RT.ask(L-1))L++;
		if(RT.ask(R))R--;

		if(L<=R)CT.modify(L,R,-1);

		RT.modify(*pre,*suc-1,-1);
	}

	void solve()
	{
		initialize();
		
		for(int ty,x0,x1,y0,y1;m--;)
		{
			scanf("%d%d%d%d%d",&ty,&x0,&y0,&x1,&y1);
			x0--,x1--;

			if(ty==1)cnt_edge++;
			else cnt_edge--;
			
			if(y0==y1)
			{
				if(ty==1)add_col(y0);
				else del_col(y0);
			}
			else 
			{
				int y=std::min(y0,y1);
				if(ty==1)add_row(x0,y);
				else del_row(x0,y);
			}

			printf("%d\n",cnt_edge-CT.query()-RT.query());
		}
	}
}

int main()
{
	freopen("bridge.in","r",stdin);
	freopen("bridge.out","w",stdout);
	many_many_segment_tree::solve();
	return 0;
}
