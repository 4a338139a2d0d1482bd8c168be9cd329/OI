#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<ctime>

namespace bf
{
	typedef long long ll;
	const int N=1010000,M=N*4,MOD=1000000007;
	inline void inc(int a,int &b){b=(a+b)%MOD;}

	struct segment_tree_is_too_slow
	{
		int w[N],end;
		void modify(int s,int t,int x)
		{
			if(s>t)return;
			inc(x,w[s]);inc(-x,w[t+1]);
		}
		int ask(int x)
		{
			for(;end<x;end++)
				inc(w[end],w[end+1]);
			return w[x];
		}
	}f[4][2];

	std::vector<int> V0,V1;

	char s[N];
	int n,k;

	void initialize()
	{
		scanf("%d%d",&n,&k);
		scanf("%s",s+1);
		for(int i=1;i<=n;i++)
			if(s[i]=='W')V0.push_back(i);
			else if(s[i]=='B')V1.push_back(i);
		V0.push_back(n+1);
		V1.push_back(n+1);
	}

	void dp()
	{
		f[0][0].modify(0,0,1);f[0][1].modify(0,0,1);

		int ind0=0,ind1=0;

		for(int i=0;i<=n;i++)
			for(int S=0;S<4;S++)
			{
				if(S==1)continue;

				int v0=f[S][0].ask(i),v1=f[S][1].ask(i);
				int R0,R1;

				while(V0[ind0]<=i)ind0++;
				while(V1[ind1]<=i)ind1++;

				R0=V1[ind1];
				R1=V0[ind0];

				f[S][1].modify(i+1,std::min(i+k-1,R1-1),v0);
				f[S==3?S:2][1].modify(i+k,R1-1,v0);

				f[S][0].modify(i+1,std::min(i+k-1,R0-1),v1);
				f[S>=2?S|1:0][0].modify(i+k,R0-1,v1);
				
			}
	}

	void solve()
	{
		initialize();
		dp();

		int ans=((f[3][0].ask(n)+f[3][1].ask(n))%MOD+MOD)%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	bf::solve();

//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
