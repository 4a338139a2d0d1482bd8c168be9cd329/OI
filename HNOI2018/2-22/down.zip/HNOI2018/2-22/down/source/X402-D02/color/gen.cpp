#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("color.in","w",stdout);//look at here

	int n=2000,k=rand()%(std::max(200,n/10000))+1;
	int hz=n/100;

	printf("%d %d\n",n,k);
	for(int i=1;i<=n;i++)
		if(rand()%hz)printf("X");
		else printf("%c",rand()%2?'W':'B');
	printf("\n");

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
