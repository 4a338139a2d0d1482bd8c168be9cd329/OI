#include<iostream>
#include<cstdio>
#include<cstring>

namespace bf
{
	const int N=2010,MOD=1000000007;
	inline void inc(int a,int &b){b=(a+b)%MOD;}

	char s[N];
	int n,k;

	int f[N][4][2];

	void dp()
	{
		f[0][0][0]=f[0][0][1]=1;
		for(int i=0;i<=n;i++)
			for(int S=0;S<4;S++)
			{
				int v0=f[i][S][0],v1=f[i][S][1];
				bool flag0=1,flag1=1;

				if(!v0 && !v1)continue;

				for(int j=i+1;j<=n && (flag0 || flag1);j++)
				{
					if(s[j]=='B')flag0=0;
					else if(s[j]=='W')flag1=0;

					bool h=(j-i)>=k;

					if(flag0)inc(v1,f[j][S|h][0]);
					if(flag1)inc(v0,f[j][S==3?S:(h?2:S)][1]);
				}
			}
	}

	void solve()
	{
		scanf("%d%d",&n,&k);
		scanf("%s",s+1);
		dp();

		int ans=(f[n][3][0]+f[n][3][1])%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("color.in","r",stdin);
	freopen("color.ans","w",stdout);
	bf::solve();
	return 0;
}
