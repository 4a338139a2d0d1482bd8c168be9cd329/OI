#include<iostream>
#include<cstdio>
#include<cstring>

inline void check_max(int a,int &b){if(a>b)b=a;}

namespace QwQ
{
	const int N=1020,K=12,INF=1000000007;

	int f[N][N],g[N][N],maxf[N],maxg[N],h[N];

	int n,m;
	int HP,MP,SP,DHP,DMP,DSP,X;

	int N1,N2;
	int A[N],B[K],C[K],Y[K],Z[K];

	void initialize()
	{
		scanf("%d%d%d%d%d%d%d%d%d",&n,&m,&HP,&MP,&SP,&DHP,&DMP,&DSP,&X);
		for(int i=1;i<=n;i++)scanf("%d",A+i);
		scanf("%d",&N1);
		for(int i=1;i<=N1;i++)scanf("%d%d",B+i,Y+i);
		scanf("%d",&N2);
		for(int i=1;i<=N2;i++)scanf("%d%d",C+i,Z+i);
	}

	void dp_for_get_h()
	{
		for(int i=0;i<=n;i++)for(int j=0;j<=MP;j++)f[i][j]=-INF;
		f[0][MP]=0;
		for(int i=0;i<n;i++)
			for(int j=0;j<=MP;j++)
			{
				int v=f[i][j];
				if(v<0)continue;

				check_max(v,f[i+1][std::min(j+DMP,MP)]);
				for(int k=1;k<=N1;k++)
					if(j>=B[k])check_max(v+Y[k],f[i+1][j-B[k]]);
			}
		for(int i=1;i<=n;i++)maxf[i]=0;
		for(int i=1;i<=n;i++)for(int j=0;j<=MP;j++)check_max(f[i][j],maxf[i]);

		for(int i=0;i<=n;i++)for(int j=0;j<=SP;j++)g[i][j]=-INF;
		g[0][SP]=0;
		for(int i=0;i<n;i++)
			for(int j=0;j<=SP;j++)
			{
				int v=g[i][j];
				if(v<0)continue;

				check_max(v+X,g[i+1][std::min(j+DSP,SP)]);
				for(int k=1;k<=N2;k++)
					if(j>=C[k])check_max(v+Z[k],g[i+1][j-C[k]]);
			}
		for(int i=1;i<=n;i++)maxg[i]=0;
		for(int i=1;i<=n;i++)for(int j=0;j<=SP;j++)check_max(g[i][j],maxg[i]);

		for(int i=1;i<=n;i++)h[i]=0;
		for(int i=1;i<=n;i++)
			for(int j=0;j<=i;j++)
				check_max(maxf[j]+maxg[i-j],h[i]);

	}
	void dp_for_ans()
	{
		for(int i=0;i<=n;i++)for(int j=0;j<=HP;j++)f[i][j]=-INF;
		f[0][HP]=0;
		for(int i=0;i<n;i++)
			for(int j=1;j<=HP;j++)
			{
				int v=f[i][j];
				if(v<0)continue;

				if(j+DHP>A[i+1])check_max(v,f[i+1][std::min(HP,j+DHP)-A[i+1]]);
				if(j>A[i+1])check_max(v+1,f[i+1][j-A[i+1]]);

				check_max(v+1,f[i+1][0]);
			}
		for(int i=1;i<=n;i++)maxf[i]=-INF;
		for(int i=1;i<=n;i++)for(int j=0;j<=HP;j++)check_max(f[i][j],maxf[i]);

	}
	int calc()
	{
		if(maxf[n]<0)return -1;

		int minday=INF;
		for(int i=1;i<=n;i++)
			if(h[i]>=m){minday=i;break;}

		for(int i=1;i<=n;i++)
			if(maxf[i]>=minday)return i;

		return -2;
	}

	void solve()
	{
		initialize();
		dp_for_get_h();
		dp_for_ans();

		int ans=calc();

		if(ans==-1)printf("No\n");
		else if(ans==-2)printf("Tie\n");
		else printf("Yes %d\n",ans);
	}
}

int main()
{
	freopen("boss.in","r",stdin);
	freopen("boss.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;QwQ::solve());
	return 0;
}
