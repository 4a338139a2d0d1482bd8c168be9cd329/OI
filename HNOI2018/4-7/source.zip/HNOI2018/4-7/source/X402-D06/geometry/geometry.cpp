#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const long long INF=1e15;
const long double eps=1e-9;
const double Pi=acos(-1.0);
const int N=10;
double dp[(1<<N)+10][(1<<N)+10][N<<1|1],dis[N+1][N+1];
bool G[N+10][N+10];
struct node{
	int x,y;
}a[N+5],b[N+5];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline double sqr(double val){
	return val*val;
}
int main(){
	int i,j,k,l,m,n;
#ifndef ONLINE_JUDGE
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
#endif
	n=read();
	for(i=1;i<=n;i++)a[i].x=read(),a[i].y=read();
	for(i=1;i<=n;i++)b[i].x=read(),b[i].y=read();
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++){
			bool flag=0;
			double Val1=atan2(b[j].y-a[i].y,b[j].x-a[i].x);
			double Val2=atan2(b[j+1].y-a[i].y,b[j+1].x-a[i].x);
			double Val3=atan2(b[j-1].y-a[i].y,b[j-1].x-a[i].x);
			double Val4=atan2(a[i+1].y-a[i].y,a[i+1].x-a[i].x);
			double Val5=atan2(a[i-1].y-a[i].y,a[i-1].x-a[i].x);
			if(Val5>0)Val5-=2*Pi;
			if(!(j==n || Val1<Val2))flag=1;
			if(!(j==1 || Val1>Val3))flag=1;
			if(!(i==n || Val1<Val4))flag=1;
			if(!(i==1 || Val1>Val5))flag=1;
			if(!flag)G[i][j]=1;
		}
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			dis[i][j]=sqrt(sqr(a[i].x-b[j].x)+sqr(a[i].y-b[j].y));
	for(i=0;i<(1<<n);i++)
		for(j=0;j<(1<<n);j++)
			for(k=1;k<=n<<1;k++)
				dp[i][j][k]=INF;
	for(i=1;i<=n;i++)dp[1<<(i-1)][0][i]=0;
	for(i=1;i<=n;i++)dp[0][1<<(i-1)][i+n]=0;
	long long lim=INF-5;
	for(i=0;i<(1<<n);i++)
		for(j=0;j<(1<<n);j++)
			for(k=1;k<=(n<<1);k++){
				if(dp[i][j][k]>lim)continue;
				if(k<=n){
					for(l=1;l<=n;l++){
						if((j & (1<<(l-1))) || !G[k][l])continue; 
						dp[i][j|(1<<(l-1))][l+n]=min(dp[i][j|(1<<(l-1))][l+n],dp[i][j][k]+dis[k][l]);
					}
				}
				else{
					k-=n;
					for(l=1;l<=n;l++){
						if((i & (1<<(l-1))) || !G[l][k])continue;
						dp[i|(1<<(l-1))][j][l]=min(dp[i|(1<<(l-1))][j][l],dp[i][j][k+n]+dis[l][k]);
					}
					k+=n;
				}
			}
	double ans=INF;
	for(i=1;i<=2*n;i++)ans=min(ans,dp[(1<<n)-1][(1<<n)-1][i]);
	printf("%.10lf\n",ans>lim?-1:ans);
	return 0;
}

