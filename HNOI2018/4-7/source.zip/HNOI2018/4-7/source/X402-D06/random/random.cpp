#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=998244353;
const int Inv2=499122177;
const int Inv=796898467;
const int N=10,M=20;
int id[M][2],Pm[M],to[M],nex[M],beg[N],dfn[N],low[N],ins[N],vis[N],stk[N],P[N][N];
int n,m,dfs_time,scccnt,top,e,ans=0;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int fpm(int a,int b){
	int res=1;
	while(b){
		if(b & 1)res=1ll*res*a%mod;
		a=1ll*a*a%mod;b/=2;
	}
	return res;
}
inline void add(int x,int y){
	to[++e]=y,nex[e]=beg[x],beg[x]=e;
}
void tarjan(int x){
	int i;
	dfn[x]=low[x]=++dfs_time;
	stk[++top]=x;ins[x]=vis[x]=1;
	for(i=beg[x];i;i=nex[i]){
		if(!vis[to[i]])tarjan(to[i]),low[x]=min(low[x],low[to[i]]);
		else if(ins[to[i]])low[x]=min(low[x],dfn[to[i]]);
	}
	if(low[x]==dfn[x]){
		++scccnt;
		while(true){
			int u=stk[top--];
			ins[u]=0;
			if(u==x)break;
		}
	}
}
void dfs(int cur,int tot,int sum){
	int i,j;
	if(cur>tot){
		for(i=1;i<=n;i++)beg[i]=dfn[i]=low[i]=vis[i]=ins[i]=0;
		e=dfs_time=scccnt=0;
		int cnt=0;
		for(i=1;i<=n;i++)
			for(j=i+1;j<=n;j++)
				if(Pm[++cnt])add(i,j);
				else add(j,i);
		for(i=1;i<=n;i++)if(!vis[i])tarjan(i);
		(ans+=1ll*sum*scccnt%mod)%=mod;
		return;
	}
	Pm[cur]=1;
	dfs(cur+1,tot,1ll*sum*P[id[cur][0]][id[cur][1]]%mod);
	Pm[cur]=0;
	dfs(cur+1,tot,1ll*sum*P[id[cur][1]][id[cur][0]]%mod);
}
int main(){
	int i,j,k;
#ifndef ONLINE_JUDGE
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
#endif
	n=read();m=read();
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			P[i][j]=Inv2;
	int cnt=0;
	for(i=1;i<=n;i++)
		for(j=i+1;j<=n;j++)
			id[++cnt][0]=i,id[cnt][1]=j;
	for(i=1;i<=m;i++){
		int x=read(),y=read();
		P[x][y]=1ll*read()*Inv%mod;
		P[y][x]=(1-P[x][y]+mod)%mod;
	}
	dfs(1,n*(n-1)/2,1);
	printf("%lld\n",1ll*ans*fpm(10000,n*(n-1))%mod);
	return 0;
}

