#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=2e9+10;
const long double eps=1e-9;
const int N=1e5+10,M=1e5+10;
struct node{
	int a,b,id;
}a[N],b[N];
bool cmp(const node &lhs,const node &rhs){
	return lhs.a<rhs.a;
}
int to[M<<1],nex[M<<1],beg[N],fa[N],vis[N],sz[N];
int e;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y){
	to[++e]=y,nex[e]=beg[x],beg[x]=e;
}
int find(int x){
	return fa[x] == x ? x : fa[x]=find(fa[x]);
}
int main(){
	int i,j,k,m,n,lim;
#ifndef ONLINE_JUDGE
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
#endif
	n=read();m=read();lim=read();
	for(i=1;i<=n;i++)a[i].a=read(),a[i].b=read(),a[i].id=i;
	for(i=1;i<=m;i++){
		int x=read(),y=read();
		add(x,y),add(y,x);
	}
	int ans=INF;
	sort(a+1,a+n+1,cmp);
	for(i=1;i<=n;i++){
		int Maxsz=1;
		for(j=1;j<=i-1;j++)if(a[i].b<b[j].b)break;
		int pos=j;
		for(j=i-1;j>=pos;j--)b[j+1]=b[j];b[pos]=a[i];
		for(j=1;j<=i;j++)fa[b[j].id]=b[j].id,sz[b[j].id]=1;
		for(j=1;j<=i;j++){
			int x=b[j].id;
			vis[x]=1;
			for(k=beg[x];k;k=nex[k]){
				if(!vis[to[k]])continue;
				int u=find(x),v=find(to[k]);
				if(u==v)continue;
				fa[u]=v;sz[v]+=sz[u];
				Maxsz=max(Maxsz,sz[v]);
			}
			if(Maxsz>=lim){
				ans=min(ans,a[i].a+b[j].b);
				break;
			}
		}
		for(j=1;j<=n;j++)vis[j]=0;
	}
	if(ans==INF)puts("no solution");
	else printf("%d\n",ans);
	return 0;
}

