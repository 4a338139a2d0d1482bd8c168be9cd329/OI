#include<bits/stdc++.h>
using namespace std;
const int inf=2000000001;
struct node
{
	int a,b,id;
}a[101050],b[105050];
int n,m,k,doe,ans;
int pre[200101],son[200101],now[101050];
int fa[105050],size[105050],aa[105050];

bool cmp1(node u,node w)
{
	return u.a<w.a;
}
bool cmp2(node u,node w)
{
	return u.b<w.b;
}
void add(int x,int y)
{
//	printf("%d %d\n",x,y);
	++doe;
	pre[doe]=now[x];
	now[x]=doe;
	son[doe]=y;
}
int find(int x)
{
	if (fa[x]==x) return x;
	fa[x]=find(fa[x]);
	return fa[x];
}
void merge(int x,int y)
{
	x=find(x); y=find(y);
	if (x==y) return;
	if (size[x]<size[y]) swap(x,y);
	fa[y]=x;
	size[x]+=size[y];
}	
int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	ans=inf;
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;++i)
		scanf("%d%d",&a[i].a,&a[i].b),b[i].a=a[i].a,b[i].b=a[i].b,b[i].id=i,aa[i]=a[i].a;
	int x,y;
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d",&x,&y);
		if (a[x].b>=a[y].b) add(x,y);
		if (a[x].b<=a[y].b) add(y,x);
	}
	sort(a+1,a+1+n,cmp1);
	sort(b+1,b+1+n,cmp2);
	for (int i=k;i<=n;++i)
	{
		cerr<<i<<endl;
		while (a[i].a==a[i+1].a) ++i;
		int limit=a[i].a;

		for (int j=1;j<=n;++j) fa[j]=j,size[j]=1;
	
		for (int j=1;j<=n;++j)
		{
			if (limit+b[j].b>=ans) break;
			if (b[j].a<=limit)
			{
				x=b[j].id;
//				printf("x%d\n",x);
				int p=now[x];
				while (p)
				{
					y=son[p];
//					printf("x:%d y:%d\n",x,y);
					if (aa[y]<=limit)
						merge(x,y);
					p=pre[p];
				}
				x=find(x);
//				printf("size:%d\n",size[x]);
				if (size[x]>=k)
				{
					ans=min(ans,limit+b[j].b);
					break;
				}
			}
		}
//		printf("ans%d\n",ans);
//		printf("============\n");
	}
	if (ans==inf) printf("-1\n");
	else printf("%d\n",ans);
	

	return 0;
}

