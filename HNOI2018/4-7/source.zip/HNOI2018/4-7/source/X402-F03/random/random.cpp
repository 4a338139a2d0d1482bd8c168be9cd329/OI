#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll mod = 998244353;
ll pi[22][22];
ll now=1,ans;
int n,m,num,deep;
bool nct[22][22];
int dfn[22],pre[22],id[22];
stack<int> st;
void Tarjan(int x)
{
    ++deep;
    dfn[x]=pre[x]=deep;
    st.push(x);
    for (int i=1;i<=n;++i)
	if (nct[x][i] && x!=i)
    {
        int y=i;
        if (!dfn[y])
        {
            Tarjan(y);
            pre[x]=min(pre[x],pre[y]);
        }
        else if(!id[y]) pre[x]=min(pre[x],dfn[y]);
    }
    int kkk;
    if (dfn[x]==pre[x]) 
    {
        ++num;
        while (1)
        {
            kkk=st.top();
            st.pop();
            id[kkk]=num;
            if (kkk==x) break;
        }
    }
        
}
void check()
{
	memset(dfn,0,sizeof(dfn));
	memset(pre,0,sizeof(pre));
	memset(id,0,sizeof(id));
	num=0;
	for (int i=1;i<=n;++i)
		if (dfn[i]==0) Tarjan(i);
	ans=(ans+num*now%mod)%mod;

}
void dfs(int x,int y)
{
	if (y>n)
	{
		check();
		return;
	}
	ll save=now;
	
	now=save*pi[x][y]%mod;
	nct[x][y]=1;
	if (y<n) dfs(x,y+1);
	else dfs(x+1,x+2);
	nct[x][y]=0;

	now=save*(10000-pi[x][y])%mod;
	nct[y][x]=1;
	if (y<n) dfs(x,y+1);
	else dfs(x+1,x+2);
	nct[y][x]=0;

}
int main()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<n;++i)
		for (int j=i+1;j<=n;++j)
			pi[i][j]=5000;
	int x,y,z;
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d%d",&x,&y,&z);
		pi[x][y]=z;
	}
	dfs(1,2);
	for (int i=1;i<=n*(n-1)/2;++i)
		ans=ans*10000%mod;
	printf("%lld\n",ans);
	return 0;
}
