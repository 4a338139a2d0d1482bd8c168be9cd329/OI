#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
long double X1,Y1,X2,Y2;
int n;
int main()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	scanf("%d",&n);
	scanf("%Lf%Lf%Lf%Lf",&X1,&Y1,&X2,&Y2);
	printf("%.14Lf\n",sqrt((X1-X2)*(X1-X2)+(Y1-Y2)*(Y1-Y2)));
	return 0;
}
