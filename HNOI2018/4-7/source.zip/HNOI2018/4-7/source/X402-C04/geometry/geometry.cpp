#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef pair<db,db> pr;
const db eps=1e-7;
const int N=1009;
const int M=N*N;
#define x first
#define y second

inline db sqr(db x){return x*x;}
inline db cross(pr a,pr b){return a.x*b.y-a.y*b.x;}
inline db dis(pr a,pr b){return sqrt(sqr(a.x-b.x)+sqr(a.y-b.y));}

inline pr operator - (pr a,pr b){return pr(a.x-b.x,a.y-b.y);}

inline bool intersect(pr s1,pr t1,pr s2,pr t2)
{
	return ((cross(t2-s2,t1-s2)>eps)^(cross(t2-s2,s1-s2)>eps)) && ((cross(t1-s1,t2-s1)>eps)^(cross(t1-s1,s2-s1)>eps));
}

int n;
pr up[N],dp[N];
int to[M<<1],nxt[M<<1],beg[N<<1],tot;
db w[M<<1],ans=1e18;
bool vis[N<<1];

inline void add(int u,int v,db c)
{
	to[++tot]=v;nxt[tot]=beg[u];beg[u]=tot;w[tot]=c;
}

inline void dfs(int u,db dis,int cnt)
{
	if(cnt==2*n)
	{
		ans=min(ans,dis);
		return;
	}

	vis[u]=1;
	if(u<=n)
	{
		for(int i=1;i<=u-2;i++)
			if(!vis[i+n]){vis[u]=0;return;}
		for(int i=beg[u];i;i=nxt[i])
			if(abs((to[i]-n)-u)<=1 && !vis[to[i]])
				dfs(to[i],dis+w[i],cnt+1);
	}
	else if(u>n)
	{
		for(int i=1;i<=u-n-2;i++)
			if(!vis[i]){vis[u]=0;return;}
		for(int i=beg[u];i;i=nxt[i])
			if(abs(to[i]-(u-n))<=1 && !vis[to[i]])
				dfs(to[i],dis+w[i],cnt+1);
	}	
	vis[u]=0;
}

int main()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&up[i].x,&up[i].y);
	up[0]=pr(up[1].x,1e18);
	up[n+1]=pr(up[n].x,1e18);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&dp[i].x,&dp[i].y);
	dp[0]=pr(dp[1].x,-1e18);
	dp[n+1]=pr(dp[n].x,-1e18);

	if(n==1)return printf("%.10f\n",dis(up[1],dp[1])),0;

	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		{
			for(int k=0;k<=n;k++)
				if(k!=i && k+1!=i && intersect(up[i],dp[j],up[k],up[k+1]))
					goto nxt;
			for(int k=0;k<=n;k++)
				if(k!=j && k+1!=j && intersect(up[i],dp[j],dp[k],dp[k+1]))
					goto nxt;

			add(i,j+n,dis(up[i],dp[j]));	
			add(j+n,i,dis(up[i],dp[j]));
			nxt:;
		}

	dfs(1,0,1);
	dfs(n+1,0,1);

	if(ans==1e18)
		puts("-1.0");
	else
		printf("%.10lf\n",ans);
	return 0;
}
