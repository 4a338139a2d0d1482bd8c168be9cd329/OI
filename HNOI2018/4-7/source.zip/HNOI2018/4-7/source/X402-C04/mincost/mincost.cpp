#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

typedef pair<int,int> pr;
const int N=200009;
const int M=500009;

int n,m,k,cnt,ans=2e9+1;
int a[N],b[N],dis[N];
int to[M<<1],nxt[M<<1],beg[N],tot;
int fa[N],siz[N],in[N],inq[N];
vector<int> tmpa,tmpb;
queue<int> q;

inline bool cmpa(int x,int y){return a[x]<a[y];}
inline bool cmpb(int x,int y){return b[x]<b[y];}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline int find(int x)
{
	return fa[x]=fa[x]==x?x:find(fa[x]);
}

inline void merge(int x,int y)
{
	if(find(x)==find(y))return;
	if(siz[find(y)]<siz[find(x)])swap(x,y);
	siz[find(y)]+=siz[find(x)];
	siz[find(x)]=0;
	fa[find(x)]=find(y);
}

inline void spfa()
{
	while(!q.empty())
	{
		int u=q.front();q.pop();inq[u]=0;
		for(int i=beg[u];i;i=nxt[i])
			if(dis[to[i]]>dis[u]+1)
			{
				if(in[to[i]] && dis[to[i]]==N+9)
					cnt++;
				dis[to[i]]=dis[u]+1;
				if(in[to[i]] && !inq[to[i]])
					q.push(to[i]),inq[to[i]]=1;
			}
	}
}

int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);

	n=read();m=read();k=read();
	for(int i=1;i<=n;i++)
		a[i]=read(),b[i]=read();
	for(int i=1,x,y;i<=m;i++)
	{
		x=read();y=read();
		add(x,y);add(y,x);
	}

	for(int i=1,p=0,cans;i<=n;i++,p=0)
	{
		if(ans<=a[i]+b[i])continue;
		for(int j=1;j<=n;j++)
			in[j]=0,inq[j]=0,dis[j]=N+9;
		in[i]=cnt=1;dis[i]=0;
		q.push(i);spfa();

		if(cnt>=k)
		{
			ans=a[i]+b[i];
			goto nxts;
		}

		tmpa.clear();
		for(int j=1;j<=n;j++)
			if(j!=i && a[j]<=a[i])
				tmpa.push_back(j);
		sort(tmpa.begin(),tmpa.end(),cmpb);

		for(;p<tmpa.size();p++)
		{
			if(b[tmpa[p]]>b[i])
				break;
			in[tmpa[p]]=1;
			if(dis[tmpa[p]]!=N+9)
				cnt++;
			q.push(tmpa[p]);spfa();
			if(cnt>=k)
			{
				ans=a[i]+b[i];
				goto nxts;
			}
		}

		if(p==tmpa.size())
		{
			if(cnt>=k)
				ans=a[i]+b[i];
			continue;
		}

		for(;p<tmpa.size();p++)
		{
			cans=a[i]+b[tmpa[p]];
			if(ans<=cans)break;
			in[tmpa[p]]=1;
			if(dis[tmpa[p]]!=N+9)
				cnt++;
			q.push(tmpa[p]);spfa();
			if(cnt>=k && dis[tmpa[p]]<=k)
			{
				ans=cans;
				break;
			}
		}
		nxts:;
	}

	if(ans==2e9+1)
		puts("no solution");
	else
		printf("%d\n",ans);
	return 0;
}

