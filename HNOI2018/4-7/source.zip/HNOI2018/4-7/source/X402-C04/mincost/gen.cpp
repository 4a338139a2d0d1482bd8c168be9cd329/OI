#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef double db;
typedef long long ll;

const int N=100009;
const int M=20;
const int C=3;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

set<pr> ha;

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("mincost.in","w",stdout);

	int n=5000,m=5000,k=rand()%n/2+1;
	printf("%d %d %d\n",n,m,k);
	for(int i=1;i<=n;i++)
		printf("%d %d\n",rand()%M+1,rand()%M+1);
	for(int i=1,u,v;i<=m;i++)
	{
		re:;u=rand()%n+1,v=rand()%n+1;
		if(u>v)swap(u,v);
		if(u==v || ha.count(pr(u,v)))goto re;
		printf("%d %d\n",u,v);
		ha.insert(pr(u,v));
	}
	return 0;
}
