#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

typedef pair<int,int> pr;
const int N=200009;
const int M=500009;

int n,m,k,ans=2e9+1;
int a[N],b[N],stk[N],top;
int to[M<<1],nxt[M<<1],beg[N],tot;
int fa[N],in[N];
vector<pr> e;

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline int find(int x)
{
	return fa[x]=fa[x]==x?x:find(fa[x]);
}

inline int judge()
{
	for(int i=1;i<=k;i++)
		fa[stk[i]]=stk[i];
	for(int u=1;u<=k;u++)
		for(int i=beg[stk[u]];i;i=nxt[i])
			if(in[to[i]] && find(to[i])!=find(stk[u]))
				fa[find(to[i])]=find(stk[u]);
	int cnt=0;
	for(int i=1;i<=k;i++)
		if(find(stk[i])==stk[i])
			cnt++;
	if(cnt>=2)return -1;
	int reta=-1,retb=-1;
	for(int i=1;i<=k;i++)
		reta=max(reta,a[stk[i]]),retb=max(retb,b[stk[i]]);
	return reta+retb;
}

inline void dfs(int u,int top)
{
	if(u==n+1)
	{
		if(top==k+1)
		{
			int tmp=judge();
			if(~tmp)ans=min(ans,tmp);
			/*
			if(tmp==25)
			{
				for(int i=1;i<=k;i++)
					printf("%d ",stk[i]);
				puts("");
			}
			*/
		}
		return;
	}

	in[stk[top]=u]=1;
	dfs(u+1,top+1);
	in[u]=0;
	dfs(u+1,top);
}

int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincosts.out","w",stdout);

	n=read();m=read();k=read();
	for(int i=1;i<=n;i++)
		a[i]=read(),b[i]=read();
	for(int i=1,x,y;i<=m;i++)
	{
		x=read();y=read();
		add(x,y);add(y,x);
		e.push_back(pr(x,y));
	}

	dfs(1,1);
	if(ans==2e9+1)return puts("no solution"),0;
	else return printf("%d\n",ans),0;
}
