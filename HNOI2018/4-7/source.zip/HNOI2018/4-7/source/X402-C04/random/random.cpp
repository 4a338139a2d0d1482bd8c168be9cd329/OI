#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=49;
const ll md=998244353;

int n,m,top;
int stk[N],low[N],pre[N],scc[N],scccnt,dfn;
ll f[N][N],inv,ans;
bool g[N][N];

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}

inline void tarjan(int u)
{
	low[u]=pre[u]=++dfn;
	stk[++top]=u;
	for(int i=1;i<=n;i++)
		if(g[u][i])
		{
			if(!pre[i])
			{
				tarjan(i);
				low[u]=min(low[u],low[i]);
			}
			else if(!scc[i])
				low[u]=min(low[u],pre[i]);
		}
	if(low[u]==pre[u])
	{
		scccnt++;
		do
			scc[stk[top]]=scccnt;
		while(stk[top--]!=u);
	}
}

inline ll calc()
{
	top=scccnt=0;
	for(int i=1;i<=n;i++)
		low[i]=pre[i]=scc[i]=0;
	for(int i=1;i<=n;i++)
		if(!scc[i])tarjan(i);
	return scccnt;
}

inline void dfs(int x,int y,ll per)
{
	if(per==0)return;
	if(x==n)
	{
		ll tmp;
		(ans+=calc()*per%md)%=md;
		return;
	}

	int nxtx=x,nxty=y+1;
	if(nxty>n)nxtx=x+1,nxty=nxtx+1;
	g[x][y]=1;
	dfs(nxtx,nxty,per*f[x][y]%md);
	g[x][y]=0;
	g[y][x]=1;
	dfs(nxtx,nxty,per*f[y][x]%md);
	g[y][x]=0;
}

int main()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);

	inv=qpow(10000,md-2);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(i!=j)
				f[i][j]=5000*inv%md;
	for(int i=1,u,v,w;i<=m;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		f[u][v]=w*inv%md;
		f[v][u]=(10000ll-w)*inv%md;
	}

	dfs(1,2,1);
	printf("%lld\n",ans*qpow(10000,n*(n-1))%md);
	return 0;
}
