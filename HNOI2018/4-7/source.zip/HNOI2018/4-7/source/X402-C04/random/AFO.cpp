#include<bits/stdc++.h>
using namespace std;

typedef double ll;
const int N=49;

int n,m,top;
int stk[N],low[N],pre[N],scc[N],scccnt,dfn;
ll f[N][N],inv,ans;
bool g[N][N];

inline ll qpow(ll a,int b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a;
		a=a*a;b>>=1;
	}
	return ret;
}

inline void tarjan(int u)
{
	low[u]=pre[u]=++dfn;
	stk[++top]=u;
	for(int i=1;i<=n;i++)
		if(g[u][i])
		{
			if(!pre[i])
			{
				tarjan(i);
				low[u]=min(low[u],low[i]);
			}
			else if(!scc[i])
				low[u]=min(low[u],pre[i]);
		}
	if(low[u]==pre[u])
	{
		scccnt++;
		do
			scc[stk[top]]=scccnt;
		while(stk[top--]!=u);
	}
}

inline ll calc()
{
	top=scccnt=0;
	for(int i=1;i<=n;i++)
		low[i]=pre[i]=scc[i]=0;
	for(int i=1;i<=n;i++)
		if(!scc[i])tarjan(i);
	return scccnt;
}

inline void dfs(int x,int y,ll per)
{
	if(x==n)
	{
		ll tmp;
		ans+=calc()*per;
		return;
	}

	int nxtx=x,nxty=y+1;
	if(nxty>n)nxtx=x+1,nxty=nxtx+1;
	g[x][y]=1;
	dfs(nxtx,nxty,per*f[x][y]);
	g[x][y]=0;
	g[y][x]=1;
	dfs(nxtx,nxty,per*f[y][x]);
	g[y][x]=0;
}

namespace minadp
{
	const int K=(1<<15)+9;
	ll dp[K],g[K];

	inline ll dfs(int state)
	{
		if(dp[state]!=-1)return dp[state];
		int cnt=__builtin_popcount(state);
		if(!cnt)return dp[state]=0;
		else if(cnt==1)return dp[state]=1;

		dp[state]=0;
		for(int i=state;i;i=(i-1)&state)
		{
			ll num=1;
			for(int j=1;j<=n;j++)
				if(i&(1<<j-1))
					for(int k=1;k<=n;k++)
						if((state^i)&(1<<k-1))
							num=num*f[j][k];
			dp[state]+=(((cnt-__builtin_popcount(i))&1)?-1:1)*num;
		}
		return dp[state];
	}

	inline ll dfs2(int state)
	{
		if(g[state]!=-1)return g[state];
		int cnt=__builtin_popcount(state);
		if(!cnt)return g[state]=0;
		else if(cnt==1)return g[state]=1;

		g[state]=0;
		for(int i=state;i;i=(i-1)&state)
		{
			ll num=(dfs2(i)+dfs2(state^i));
			for(int j=1;j<=n;j++)
				if(i&(1<<j-1))
					for(int k=1;k<=n;k++)
						if((state^i)&(1<<k-1))
							num=num*f[j][k];
			g[state]+=(((cnt-__builtin_popcount(i))&1)?-1:1)*num;
		}
		return g[state];
	}

	int mina()
	{
		for(int i=(1<<n)-1;i>=0;i--)dp[i]=g[i]=-1;
		dfs((1<<n)-1);
		for(int i=(1<<n)-1;i>=0;i--)
			printf("%d:%.3lf\n",i,dp[i]);

		printf("%.3lf\n",dfs2((1<<n)-1));
		return 0;
	}
}

int main()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);

	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(i!=j)
				f[i][j]=0.5;;
	for(int i=1,u,v,w;i<=m;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		f[u][v]=(ll)w/10000.0;
		f[v][u]=(10000.0-w)/10000.0;
	}

	dfs(1,2,1);
	printf("%.3lf\n",ans);
	//mina7::mina();
	minadp::mina();
	return 0;
}
