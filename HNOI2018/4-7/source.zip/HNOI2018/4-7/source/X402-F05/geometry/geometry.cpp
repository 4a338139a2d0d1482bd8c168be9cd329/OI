#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 22;
const double oo = 1e18, eps = 1e-9;

int n;
int X[N], Y[N];
double ls[N], rs[N], w[N][N];
bool G[N][N];

double slope(int i, int j) {
	if (X[i] == X[j]) return -oo;
	return 1.0 * (Y[j] - Y[i]) / (X[j] - X[i]);
}

double sqr(double x) { return x * x; }

double dis(int i, int j) {
	return sqrt(sqr(X[i] - X[j]) + sqr(Y[i] - Y[j]));
}

double dp[1 << 20][20];

void chkmin(double &x, double y) { x = x < y ? x : y; }

int main() {

	freopen("geometry.in", "r", stdin);
	freopen("geometry.out", "w", stdout);

	scanf("%d", &n);
	For(i, 0, 2 * n - 1) scanf("%d%d", &X[i], &Y[i]);

	ls[0] = -oo, rs[n - 1] = oo;
	For(i, 0, n - 2) rs[i] = ls[i + 1] = slope(i, i + 1);
	ls[n] = oo, rs[2 * n - 1] = -oo;
	For(i, n, 2 * n - 2) rs[i] = ls[i + 1] = slope(i, i + 1);

	For(i, 0, n - 1) For(j, n, 2 * n - 1) {
		if (X[i] == X[j]) {
			G[i][j] = G[j][i] = true;
			continue;
		}
		double s = slope(i, j);
		bool flag = false;
		if (X[i] < X[j]) flag = s < ls[j] && s < rs[i];
		else flag = s > rs[j] && s > ls[i];
		if (flag) G[i][j] = G[j][i] = true;
	}

	n *= 2;
	For(i, 0, n - 1) For(j, 0, n - 1) w[i][j] = dis(i, j);
	For(i, 0, (1 << n) - 1) For(j, 0, n - 1) 
		dp[i][j] = oo;
	For(i, 0, n - 1) dp[1 << i][i] = 0;
	For(i, 0, (1 << n) - 1) For(j, 0, n - 1) if (dp[i][j] < 1e17) {
		For(k, 0, n - 1) if (G[j][k] && !(i & (1 << k)))
			chkmin(dp[i | (1 << k)][k], dp[i][j] + w[j][k]);
	}

	double ans = oo;
	For(i, 0, n - 1) chkmin(ans, dp[(1 << n) - 1][i]);
	printf("%.12lf\n", ans > 1e17 ? -1 : ans);

	return 0;
}
