#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 40;
const int Mod = 998244353;

int n, m;
int G[N][N];

namespace BF {

	int ex[N], ey[N], e;
	bool adj[N][N];

	int dfn[N], low[N], clk, cnt;
	int bel[N], st[N], p;

	void Tarjan(int u) {
		low[u] = dfn[u] = ++clk;
		st[++p] = u;
		For(v, 1, n) if (adj[u][v]) {
			if (!dfn[v]) {
				Tarjan(v);
				low[u] = min(low[u], low[v]);
			} else if (!bel[v]) {
				low[u] = min(low[u], dfn[v]);
			}
		}
		if (low[u] == dfn[u]) {
			bel[u] = ++cnt;
			while (st[p] != u) bel[st[p--]] = cnt;
			--p;
		}
	}

	void main() {
		For(i, 1, n) For(j, i + 1, n) ex[++e] = i, ey[e] = j;

		int ans = 0;
		For(i, 0, (1 << e) - 1) {
			int coe = 1;
			For(j, 0, e - 1) {
				int u = ex[j + 1], v = ey[j + 1];
				if (i & (1 << j)) coe = 1ll * coe * G[u][v] % Mod, adj[u][v] = true, adj[v][u] = false;
				else coe = 1ll * coe * G[v][u] % Mod, adj[v][u] = true, adj[u][v] = false;
			}
			For(j, 1, n) dfn[j] = bel[j] = 0;
			clk = cnt = 0;
			For(j, 1, n) if (!dfn[j]) Tarjan(j);
			ans = (ans + 1ll * coe * cnt) % Mod;
		}

		For(i, 1, e) ans = 10000ll * ans % Mod;
		printf("%d\n", ans);

	}	

	/*
	int dp[1 << 15], f[1 << n];
	int coe[15][1 << 15];

	void main() {
		For(i, 0, n - 1)
			For(j, 0, (1 << n) - 1) {
				coe[i][j] = 1;
				For(k, 0, n - 1) if (j & (1 << k)) coe[i][j] = 1ll * coe[i][j] * G[i][k] % Mod;
			}

		dp[0] = 0;
		For(i, 0, (1 << n) - 1)
			for (int j = i; j; j = (j - 1) & i) {
				int val = 1ll * f[j] * dp[i ^ j] % Mod;
				For(k, 0, n - 1) if (j & (1 << k)) 
					val = 1ll * val * coe[k][i ^ j] % Mod;
				(dp[i] += val) %= Mod;
			}
		printf("%d\n", dp[(1 << n) - 1]);
	}
	*/

};

namespace Subtask3 {

	int C[N][N];
	int f[N], g[N];
	int dp[N][N];

	void main() {
		For(i, 0, n) {
			C[i][0] = 1;
			For(j, 1, i) C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % Mod;
			g[i] = 1;
			For(u, 1, i * (i - 1) / 2) g[i] = (g[i] << 1) % Mod;
		}
		f[0] = 1;
		For(i, 1, n) {
			f[i] = g[i];
			For(j, 1, i - 1) f[i] = (f[i] - 1ll * C[i][j] * f[j] % Mod * g[i - j] % Mod + Mod) % Mod;
		}
		dp[0][0] = 1;
		For(i, 1, n) For(j, 1, i) For(k, 1, i)
			dp[i][j] = (dp[i][j] + 1ll * C[i][k] * f[k] % Mod * dp[i - k][j - 1]) % Mod;
		
		int ans = 0;
		For(i, 1, n) ans = (ans + 1ll * dp[n][i] * i) % Mod;
		For(i, 1, n * (n - 1) / 2) ans = 10000ll * ans % Mod;
		For(i, 1, n * (n - 1) / 2) ans = 5000ll * ans % Mod;
		printf("%d\n", ans);

	}

};

int main() {

	freopen("random.in", "r", stdin);
	freopen("random.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) For(j, 1, n) G[i][j] = 5000;
	For(i, 1, m) {
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		G[u][v] = w, G[v][u] = 10000 - w;
	}

	if (n <= 6) BF::main();
	else if (m == 0) Subtask3::main();

	return 0;
}
