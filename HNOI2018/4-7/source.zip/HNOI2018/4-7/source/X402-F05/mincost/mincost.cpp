#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

int Read() {
	char c = getchar();
	while (c > '9' || c < '0') c = getchar();
	int x = c - '0' ; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 5e5 + 10;
const int oo = 2e9 + 10;

int Begin[N], Next[N << 1], to[N << 1], e;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n, m, k;
int A[N], B[N];

namespace BF {

	int rk[N];

	bool cmp(int x, int y) { return B[x] < B[y]; }

	int fa[N], sz[N];
	int find(int x) { return x == fa[x] ? x : fa[x] = find(fa[x]); }

	void main() {
		For(i, 1, n) rk[i] = i;
		sort(rk + 1, rk + n + 1, cmp);
		int ans = oo;

		For(j, 1, n) {
			int lim = A[j];
			For(i, 1, n) fa[i] = 0;
			For(i, 1, n) if (A[rk[i]] <= lim) {
				int o = rk[i];
				sz[o] = 1, fa[o] = o;
				for (int u = Begin[o]; u; u = Next[u])
					if (fa[to[u]]) {
						int v = find(to[u]);
						assert(v);
						if (o == v) continue;
						fa[v] = o, sz[o] += sz[v];
					}
				if (sz[o] >= k) {
					ans = min(ans, lim + B[o]);
					break;
				}
			}
		}

		if (ans == oo) puts("no solution");
		else printf("%d\n", ans);
	}

};

/*
namespace Cheat {

	int sz[N], fa[N];

	int find(int x) {
		return x == fa[x] ? x : find(fa[x]);
	}

	int rka[N], rkb[N];
	multiset<int, vector<int>, greater<int> > S;

	bool cmpa(int x, int y) { return A[x] < A[y]; }
	bool cmpb(int x, int y) { return B[x] < B[y]; }

	void add(int x) {}
	void del(int x) {}

	void main() {
		For(i, 1, n) rka[i] = i, rkb[i] = i;
		sort(rka + 1, rka + n + 1, cmpa);
		sort(rkb + 1, rkb + n + 1, cmpb);
		For(i, 1, n) sz[i] = 1, fa[i] = i;

		int j = 1, ans = oo;
		bool flag = false;
		Forr(i, n, 1) {
			int lim = A[rka[i]];
			if (rka[i] <= j) del(u);
			while (j <= n) {
				int u = rkb[j];
				if (A[u] > lim) continue;
				add(u);
				if (*S.begin() >= k) break;
			}
			ans = min(ans, B[rkb[j]]);
		}
		printf("%d\n", ans);

	}

};
*/

int main() {

	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);

	n = Read(), m = Read(), k = Read();
	For(i, 1, n) A[i] = Read(), B[i] = Read();
	For(i, 1, m) {
		int u = Read(), v = Read();
		add(u, v), add(v, u);
	}

	if (k == 1) {
		int ans = oo;
		For(i, 1, n) ans = min(ans, A[i] + B[i]);
		printf("%d\n", ans);
	}
	else if (n <= 5000 && m <= 5000) BF::main();
	//else Cheat::main();

	return 0;
}
