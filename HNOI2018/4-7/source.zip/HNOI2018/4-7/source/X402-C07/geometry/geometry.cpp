#include<cstdio>
#include<algorithm>
#include<vector>
#include<queue>
#include<cmath>
using namespace std;

int n,vis[2012];
long double x[2012],y[2012],dis[2012],ans;
vector<int> son[2012];

int sol(int a,int b,int c,int d){
	long double k1=(y[a]-y[b])/(x[a]-x[b]);
	long double b1=y[a]-k1*x[a];
	long double k2=(y[c]-y[d])/(x[c]-x[d]);
	long double b2=y[c]-k2*x[c];
	long double xx=(b2-b1)/(k1-k2);
	long double yy=(b1*k2-b2*k1)/(k2-k1);
	if ((x[a]<xx&&xx<x[b]||x[b]<xx&&xx<x[a])&&(y[a]<yy&&yy<y[b]||y[b]<yy&&yy<y[a]))
	  if ((x[c]<xx&&xx<x[d]||x[d]<xx&&xx<x[c])&&(y[c]<yy&&yy<y[d]||y[d]<yy&&yy<y[c]))
	    return 1;
	return 0;
}

int check(int a,int b){
	for (int i=1;i<=n-1;i++)
	  if (sol(a,b,i,i+1))
	    return 0;
	for (int i=n+1;i<=n*2-1;i++)
	  if (sol(a,b,i,i+1))
	    return 0;
	return 1;
}

long double d(int a,int b){
	return sqrt((x[a]-x[b])*(x[a]-x[b])+(y[a]-y[b])*(y[a]-y[b]));
}

void dfs(int x,int cnt,long double w){
	vis[x]=1;
	if (cnt==n*2)
	{
	  ans=min(ans,w);
	  vis[x]=0;
	  return ;
	}
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (!vis[s])
	    dfs(s,cnt+1,w+d(x,s));
	}
	vis[x]=0;
}

int main(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	  scanf("%Lf%Lf",&x[i],&y[i]);
	for (int i=n+1;i<=n*2;i++)
	  scanf("%Lf%Lf",&x[i],&y[i]);
	for (int i=1;i<=n;i++)
	  for (int j=n+1;j<=n*2;j++)
	    if (check(i,j))
		  son[i].push_back(j),son[j].push_back(i);//printf("%d %d\n",i,j);
	ans=2147483600;
	ans+=2147483600;
	for (int i=1;i<=n;i++)
	{
	  dfs(i,1,0);
	}
	/*queue<int> h;
	for (int i=0;i<=n*2;i++)
	{
	  dis[i]=2147483600;
	  dis[i]+=2147483600;
	  vis[i]=0;
	}
	h.push(1);
	dis[1]=0;
	vis[1]=1;
	while (!h.empty())
	{
	  int x=h.front();
	  h.pop();
	  for (int i=0;i<son[x].size();i++)
	  {
	    int s=son[x][i];
		//printf("%d %d  %Lf  %Lf\n",x,s,d(x,s),dis[s]);
		if (dis[x]+d(x,s)<dis[s])
		{
		  dis[s]=dis[x]+d(x,s);
		  if (!vis[s])
		  {
		    vis[s]=1;
			h.push(s);
		  }
		}
	  }
	  vis[x]=0;
	}
	long double ans=0;
	for (int i=1;i<=n*2;i++)
	{
	  if (dis[i]==dis[0])
	  {
	    printf("%d\n",-1);
		return 0;
	  }
	  ans=max(ans,dis[i]);
	}*/
	long double aa=2147483600;
	aa+=2147483600;
	long double bb=-1;
	if (ans==aa)
	  printf("%Lf\n",bb);
	else
	  printf("%.10Lf\n",ans);
	return 0;
}

