#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
vector<int> son[300012];
int n,m,k,vis[300012],ans=2147483600,a[300012],b[300012],h[300012],q[300012];
int soa[300012],sob[300012],tot;
void dfs(int x){
	vis[x]=1;
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (vis[s]||q[s]==0)
	    continue;
	  dfs(s);
	}
}

void check(int num){
	if (num!=k)
	  return ;
	for (int i=1;i<=n;i++)
	  vis[h[i]]=0;
	dfs(h[1]);
	int aa=0,bb=0;
	for (int i=1;i<=num;i++)
	{
	  if (vis[h[i]]==0)
	    return ;
	  aa=max(aa,a[h[i]]);
	  bb=max(bb,b[h[i]]);
	}
	ans=min(ans,aa+bb);
}
	

void doing(int pos,int num){
	if (num>k)
	  return ;
	if (pos==n+1)
	{
	  check(num);
	  return ;
	}
	q[pos]=1;
	h[num+1]=pos;
	doing(pos+1,num+1);
	q[pos]=0;
	doing(pos+1,num);
}

void fs(int x,int sa,int sb){
	vis[x]=1;
	tot++;
	if (tot>=k)
	  return ;
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (!vis[s]&&a[s]<=sa&&b[s]<=sb)
	  fs(s,sa,sb);
	}
}

int sol(int sa,int sb){
	for (int i=1;i<=n;i++)
	  vis[i]=0;
	for (int i=1;i<=n;i++)
	  if (!vis[i]&&a[i]<=sa&&b[i]<=sb)
	  {
	    tot=0;
	    fs(i,sa,sb);
		if (tot>=k)
		{
		  //for (int j=1;j<=n;j++)
		  //  printf("%d ",vis[j]);printf("\n");
		  return 1;
		}
	  }
	return 0;
}

int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++)
	{
	  scanf("%d%d",&a[i],&b[i]);
	  soa[i]=a[i];
	  sob[i]=b[i];
	}
	for (int i=1;i<=m;i++)
	{
	  int u,v;
	  scanf("%d%d",&u,&v);
	  son[u].push_back(v);
	  son[v].push_back(u);
	}
	if (n<=20)
	{
	  doing(1,0);
	  printf("%d\n",ans);
	  return 0;
	}
	ans=2147483600;
	sort(soa+1,soa+1+n);
	sort(sob+1,sob+1+n);
	int pos=n;
	int al=1,ar=n,ansa=2147483600;
	while (al<=ar)
	{
	  int mida=(al+ar)/2;
	  int bl=1,br=n,ansb=2147483600;
	  while (bl<=br)
	  {
	    int midb=(bl+br)/2;
		if (sol(soa[mida],sob[midb]))
		  ansb=min(ansb,sob[midb]),br=midb-1;
		else
		  bl=midb+1;
	  }
	  if (ansb!=2147483600)
	    ans=min(ans,soa[mida]+ansb),ar=mida-1;
	  else
	    al=mida+1;
	}
	int l=1,r=n,st=n;
	while (l<=r)
	{
	  int mid=(l+r)/2;
	  if (sol(soa[mid],sob[n]))
	    st=min(st,mid),r=mid-1;
	  else
	    l=mid+1;
	}
	for (int i=st;i<=n;i++)
	{
	  for (int j=pos;j>=1;j--)
	  {
	    pos=j;
		if (soa[i]+sob[j]>=ans)
		  continue;
		if (sol(soa[i],sob[j]))
		  ans=min(ans,soa[i]+sob[j]);
		else
		  break;
	  }
	}
	printf("%d\n",ans);
	return 0;
}
