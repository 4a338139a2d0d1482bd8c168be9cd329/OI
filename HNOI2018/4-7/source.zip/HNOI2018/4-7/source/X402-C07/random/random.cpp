#include<cstdio>
#include<algorithm>
using namespace std;
const int mod=998244353;
struct node{
	int a,b;
}w[10012];

int n,m;
int vis[112],a[112][112],tot,cnt=0;
long long q[112][112],ans,totans=0;
int h[112],t[112];
void dfs1(int x){
	vis[x]=1;
	for (int i=1;i<=n;i++)
	  if (a[x][i]==0&&!vis[i])
	    dfs1(i);
	h[++tot]=x;
}

void dfs2(int x){
	vis[x]=1;
	for (int i=1;i<=n;i++)
	  if (a[x][i]==1&&!vis[i])
	    dfs2(i);
}

void check(){
	long long p=1;
	for (int i=1;i<=cnt;i++)
	  if (t[i]==1)
	    a[w[i].a][w[i].b]=1,a[w[i].b][w[i].a]=0,p=p*q[w[i].a][w[i].b]%mod;
	  else
	    a[w[i].b][w[i].a]=1,a[w[i].a][w[i].b]=0,p=p*q[w[i].b][w[i].a]%mod;
	for (int i=1;i<=n;i++)
	  vis[i]=0;
	tot=0,ans=0;
	for (int i=1;i<=n;i++)
	  if (!vis[i])
	    dfs1(i);
	for (int i=1;i<=n;i++)
	  vis[i]=0;
	for (int i=tot;i>=1;i--)
	  if (!vis[h[i]])
	  {
	    ans++;
		dfs2(h[i]);
	  }
	totans=(totans+ans*p%mod)%mod;
}
	

void doing(int pos){
	if (pos==cnt+1)
	{
	  check();
	  return ;
	}
	t[pos]=1;
	doing(pos+1);
	t[pos]=0;
	doing(pos+1);
}

long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

int main(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	  for (int j=i+1;j<=n;j++)
	    cnt++,w[cnt].a=i,w[cnt].b=j,q[i][j]=5000*mi(10000,mod-2)%mod,q[j][i]=5000*mi(10000,mod-2)%mod;
	for (int i=1;i<=m;i++)
	{
	  int a,b,c;
	  scanf("%d%d%d",&a,&b,&c);
	  q[a][b]=c*mi(10000,mod-2)%mod,q[b][a]=(10000-c)*mi(10000,mod-2)%mod;
	}
	doing(1);
	printf("%lld\n",totans*mi(10000,n*(n-1))%mod);
	return 0;
}
