//2018-4-7
//miaomiao
//Read()
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (300000 + 5)
const int oo = 0x7f7f7f7f;

int n, m, rk, ap, bp, an, bn, ans, a[N], b[N], anum[N], bnum[N];

vector<int> G[N];
bool vis[N];

int Dfs(int now){
	if(vis[now] || a[now] > anum[ap] || b[now] > bnum[bp]) return 0;

	vis[now] = true;
	int ret = 1;
	For(i, 0, G[now].size() - 1) ret += Dfs(G[now][i]);

	return ret;
}

bool Solve(){
	For(i, 1, n) vis[i] = false;
	For(i, 1, n) if(!vis[i] && Dfs(i) >= rk) return true;
	return false;
}

void Check(){
	if(!Solve()) return;
	while(bp > 1){
		--bp;
		if(!Solve()){++bp; break;}
	}

	ans = min(ans, anum[ap] + bnum[bp]);
}

int main(){
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);
	
	int u, v;

	scanf("%d%d%d", &n, &m, &rk);
	For(i, 1, n) scanf("%d%d", &a[i], &b[i]), anum[i] = a[i], bnum[i] = b[i];
	For(i, 1, m){
		scanf("%d%d", &u, &v);
		G[u].pb(v); G[v].pb(u);
	}

	sort(anum + 1, anum + n + 1); sort(bnum + 1, bnum + n + 1);
	an = unique(anum + 1, anum + n + 1) - anum - 1;
	bn = unique(bnum + 1, bnum + n + 1) - bnum - 1;
	
	ans = oo; bp = bn;
	for(ap = 1; ap <= an; ++ap) Check();

	if(ans == oo) puts("no solution");
	else printf("%d\n", ans);

	return 0;
}
