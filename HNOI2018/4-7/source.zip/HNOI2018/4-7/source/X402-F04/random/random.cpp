//2018-4-7
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N 40
const int P = 998244353;

inline int Mod(int a){return a >= P? a - P: a;}
inline int Mul(int a, int b){return (long long)a * b % P;}

vector<int> g[N];
int n, m, G[N][N];

int dfn, scc_cnt;
int pre[N], low[N], sccno[N];
stack<int> st;

void Dfs(int now){
    pre[now] = low[now] = ++dfn;
    st.push(now);
    
    For(i, 0, g[now].size()-1){
        int v = g[now][i];
        
        if(!pre[v]){
            Dfs(v); low[now] = min(low[now], low[v]);
        }else if(!sccno[v]) low[now] = min(low[now], pre[v]);
    }
    
    if(low[now] == pre[now]){
        ++scc_cnt;
        while(true){
            int x = st.top(); st.pop();
            sccno[x] = scc_cnt;
            if(x == now) break;
        }
    }
}

int Solve(){
    dfn = scc_cnt = 0;
    Set(pre, 0); Set(sccno, 0);
    
    For(i, 1, n) if(!pre[i]) Dfs(i);
    return scc_cnt;
}

int main(){
	freopen("random.in", "r", stdin);
	freopen("random.out", "w", stdout);
	
	int u, v, w;

	scanf("%d%d", &n, &m);

	For(i, 1, n) For(j, i + 1, n) G[i][j] = G[j][i] = 5000;
	For(i, 1, m){
		scanf("%d%d%d", &u, &v, &w);
		G[u][v] = w; G[v][u] = 10000 - w;
	}

	For(i, 1, n) For(j, i + 1, n){
		G[i][j] = Mul(G[i][j], 10000);
		G[j][i] = Mul(G[j][i], 10000);
	}

	int ans = 0, nn = n * (n - 1) / 2;

	For(i, 0, (1 << nn) - 1){
		For(j, 1, n) g[j].clear();

		int id = 0, now = 1;
		For(x, 1, n) For(y, x + 1, n){
			++id;
			if(i & (1 << (id - 1))) g[x].pb(y), now = Mul(now, G[x][y]);
			else g[y].pb(x), now = Mul(now, G[y][x]);
		}

		now = Mul(now, Solve()); ans = Mod(ans + now);
	}
	printf("%d\n", ans);

	return 0;
}
