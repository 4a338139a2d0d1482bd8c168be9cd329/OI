//2018-4-7
//miaomiao
//
#include <bits/stdc++.h>
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

using namespace std;

#define N 21
const double oo = 1.0 * (1ll << 60), eps = 1e-9;

double Sqr(double x){return x * x;}
void Get(double &x, double y){x = x < y ? x : y; }

int n, x[N], y[N];
double ls[N], rs[N], w[N][N], f[1 << N][N];
bool vis[N][N];

inline double Slope(int i, int j) {
	if (x[i] == x[j]) return -oo;
	return 1.0 * (y[j] - y[i]) / (x[j] - x[i]);
}

inline double Dis(int i, int j) {
	return sqrt(Sqr(x[i] - x[j]) + Sqr(y[i] - y[j]));
}

int main() {
	freopen("geometry.in", "r", stdin);
	freopen("geometry.out", "w", stdout);

	scanf("%d", &n);
	For(i, 0, 2 * n - 1) scanf("%d%d", &x[i], &y[i]);

	ls[0] = rs[2 * n - 1] = -oo, rs[n - 1] = ls[n] = oo;
	For(i, 0, n - 2) rs[i] = ls[i + 1] = Slope(i, i + 1);
	For(i, n, 2 * n - 2) rs[i] = ls[i + 1] = Slope(i, i + 1);

	For(i, 0, n - 1) For(j, n, 2 * n - 1){
		if(x[i] == x[j]){vis[i][j] = vis[j][i] = true; continue;}
		double s = Slope(i, j);
		
		if(x[i] < x[j]){
			if(s < ls[j] && s < rs[i]) vis[i][j] = vis[j][i] = true;
		}else{
			if(s > rs[j] && s > ls[i]) vis[i][j] = vis[j][i] = true;
		}
	}

	n *= 2;
	int ed = (1 << n) - 1;

	For(i, 0, n - 1) For(j, 0, n - 1) w[i][j] = Dis(i, j);
	For(i, 0, ed) For(j, 0, n - 1) f[i][j] = oo;
	For(i, 0, n - 1) f[1 << i][i] = 0;

	For(i, 0, ed) For(j, 0, n - 1) if(f[i][j] < oo) {
		For(k, 0, n - 1) if(vis[j][k] && !(i & (1 << k)))
			Get(f[i | (1 << k)][k], f[i][j] + w[j][k]);
	}

	double ans = oo;
	For(i, 0, n - 1) Get(ans, f[ed][i]);
	printf("%.11lf\n", ans >= oo ? -1 : ans);

	return 0;
}
