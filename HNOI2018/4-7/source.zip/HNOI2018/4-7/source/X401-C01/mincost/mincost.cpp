#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
typedef long long LL;
template<typename T>inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
inline void File(){
    freopen("mincost.in","r",stdin);
    freopen("mincost.out","w",stdout);
}

const int maxn=5000+10,inf=0x3f3f3f3f;
int n,m,k;
int a[maxn],b[maxn];
int e,beg[maxn],nex[maxn<<1],to[maxn<<1];
int ans=inf;

/*
struct node{
	int x,y;
	inline bool operator <(const node &p)const{
		return 
	}
};
#include<queue>
priority_queue<node> q;
*/
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
#include<queue>
inline void Work(int x){
	int A=a[x],B=b[x];
	queue<int> q;
	bool vis[maxn]={0};
	vis[x]=1;
	q.push(x);
	for(Rint i=beg[x];i;i=nex[i])vis[to[i]]=1;
	while(q.size()<k){
		int a1,b1,p=0,c=inf;
		for(Rint i=1;i<=n;i++){
			if(!vis[i]||i==x)continue;
			a1=max(A,a[i]);b1=max(B,b[i]);
			if(a1+b1-(A+B)<=c)p=i,c=(a1+b1-(A+B));
		}
		q.push(p);
		A=max(A,a[p]);B=max(B,b[p]);
		if(A+B>=ans)break;
		for(Rint i=beg[p];i;i=nex[i]){
			int v=to[i];
			vis[v]=1;
		}
	}
	ans=min(ans,A+B);
}

int main(){
    File();
    read(n);read(m);read(k);
	for(Rint i=1;i<=n;i++)read(a[i]),read(b[i]);
	for(Rint i=1;i<=m;i++){
		int x,y;
		read(x);read(y);
		add(x,y);add(y,x);
	}
	for(Rint i=1;i<=n;i++){
		Work(i);
	}
	printf("%d\n",ans);
    return 0;
}

