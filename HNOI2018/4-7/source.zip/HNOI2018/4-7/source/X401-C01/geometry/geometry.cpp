#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
typedef long long LL;
template<typename T>inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
inline void File(){
    freopen("geometry.in","r",stdin);
    freopen("geometry.out","w",stdout);
}

const int maxn=1000+10;
int n;
int X1[maxn],Y1[maxn],X2[maxn],Y2[maxn];
long double ans;

#include<cmath>

int main(){
    File();
    read(n);
	for(Rint i=1;i<=n;i++)read(X1[i]),read(Y1[i]);
	for(Rint i=1;i<=n;i++)read(X2[i]),read(Y2[i]);
	for(Rint i=1;i<=n;i++){
		int x=X1[i]-X2[i],y=Y1[i]-Y2[i];
		ans+=(long double)sqrt(x*x+y*y);
	}
	printf("%.14Lf\n",ans);
    return 0;
}

