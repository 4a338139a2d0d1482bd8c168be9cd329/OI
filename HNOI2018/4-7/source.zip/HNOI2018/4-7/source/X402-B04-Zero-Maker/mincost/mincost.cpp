/*
Author: CNYALI_LK
LANG: C++
PROG: mincost.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
int a[102424],b[102424],u[102424],v[102424],ha[102424],fa[102424];
int find(int x){
	return x==fa[x]?x:fa[x]=find(fa[x]);
}
int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	int n,m,k;
	n=read();m=read(),k=read();
	for(int i=1;i<=n;++i)a[i]=read(),b[i]=read();
	for(int i=1;i<=m;++i){
		u[i]=read();v[i]=read();
	}
	int t=1<<n,ans=0x3f3f3f3f;
	for(int j=0;j<t;++j)if(__builtin_popcount(j)==k){
		int mx=0;
		int as=0,bs=0,ok=1;
		for(int i=0;i<n;++i){
			if(j&(1<<i)){
				ha[i+1]=1;
				fa[i+1]=i+1;
				chkmax(as,a[i+1]);
				chkmax(bs,b[i+1]);
				mx=i+1;
			}
		}		
		for(int i=1;i<=m;++i)if(ha[u[i]]&&ha[v[i]]){fa[find(u[i])]=find(v[i]);}
		for(int i=1;i<=n;++i)if(ha[i]&&find(i)!=find(mx))ok=0;
		if(ok)chkmin(ans,as+bs);
	}
	printf("%d\n",ans);
	return 0;
}

