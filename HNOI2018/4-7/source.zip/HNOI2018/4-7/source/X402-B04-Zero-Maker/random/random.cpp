/*
Author: CNYALI_LK
LANG: C++
PROG: random.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
const ll p=998244353;
ll a[1024][1024];
ll have[1024][1024];
ll n,m,u,v,w,ans;	
ll dfn[1024],low[1024],t,cnt,ins[1024],stk[1024],top;
void _dfs(ll x){
	dfn[x]=low[x]=++t;
	ins[stk[++top]=x]=1;
	for(ll i=1;i<=n;++i){
		if(have[x][i]){
			if(dfn[i])if(ins[i])chkmin(low[x],dfn[i]);
			else;
			else{_dfs(i);chkmin(low[x],low[i]);}
		}
	}
	if(dfn[x]==low[x]){
		do{ins[stk[top]]=0;}while(stk[(--top)+1]!=x);
		++cnt;
	}
}


ll getans(){
	for(ll i=1;i<=n;++i)dfn[i]=low[i]=0;
	t=cnt=0;
	for(ll i=1;i<=n;++i)if(!dfn[i])_dfs(i);
	return cnt;
} 
void dfs(ll x,ll y,ll wp){
	have[x][y]=1;
	if(y==n){
		if(x==n-1)ans=(ans+(wp*a[x][y]%p)*getans())%p;
		else dfs(x+1,x+2,wp*a[x][y]%p);
	}else dfs(x,y+1,wp*a[x][y]%p);
	have[y][x]=1;have[x][y]=0;
	if(y==n){
		if(x==n-1)ans=(ans+(wp*a[y][x]%p)*getans())%p;	
		else dfs(x+1,x+2,wp*a[y][x]%p);
	}else dfs(x,y+1,wp*a[y][x]%p);
	have[y][x]=0;
}

int main(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	n=read();m=read();
	for(ll i=1;i<=n;++i)for(ll j=i+1;j<=n;++j)a[i][j]=a[j][i]=50000000;
	while(m){
		--m;u=read();v=read();w=read()*10000;
		a[u][v]=w;
		a[v][u]=100000000-w;
	}
	dfs(1,2,1);
	printf("%lld\n",ans);
	return 0;
}

