#include <bits/stdc++.h>

typedef long long LL;
typedef std::pair<int, int> PII;

#define x first
#define y second

inline int read(int Num = 0, int Flag = 1)
{
	char ch = getchar();
	for (; !isdigit(ch); ch = getchar()) 
		if (ch == '-')
			Flag = -1;
	for (;  isdigit(ch); ch = getchar())
		Num = Num * 10 + ch - '0';
	return Num *= Flag;
}

template <typename T> bool chkmax(T &a, T b) { return a < b? a = b, true : false; }
template <typename T> bool chkmin(T &a, T b) { return a > b? a = b, true : false; }

const int MAXN = 20 + 5;
const int MAXS = (1 << 20) + 5;
const int inf = 0x3f3f3f3f;

PII operator - (PII A, PII B)
{
	return PII(A.x - B.x, A.y - B.y);
}
LL cross(PII A, PII B)
{
	return (LL)A.x * B.y - (LL)A.y * B.x;
}

bool check(PII A, PII B, PII C, PII D)
{
	int f1 = cross(B - A, D - A);
	int f2 = cross(B - A, C - A);
	int f3 = cross(D - C, A - C);
	int f4 = cross(D - C, B - C);
	if (f1 == 0 || f2 == 0 || f3 == 0 || f4 == 0) return false;
	return ((f1 > 0) != (f2 > 0)) && ((f3 > 0) != (f4 > 0));
}

int N;
PII P0[MAXN], P1[MAXN];

bool ban[MAXN][MAXN];
double dp[MAXS][MAXN];
double dis[MAXN][MAXN];

int main()
{
	freopen("geometry.in", "r", stdin);
	freopen("geometry.out", "w", stdout);

	N = read();
	for (int i = 1; i <= N; ++i) {
		P0[i].x = read(), P0[i].y = read();
	}
	for (int i = 1; i <= N; ++i) {
		P1[i].x = read(), P1[i].y = read();
	}

	P0[0] = PII(P0[1].x, +inf); P0[N + 1] = PII(P0[N].x, +inf);
	P1[0] = PII(P1[1].x, -inf); P1[N + 1] = PII(P1[N].x, -inf);

	for (int i = 1; i <= N; ++i) {
		for (int j = 1; j <= N; ++j) {
			dis[i][j + N] = dis[j + N][i] = sqrt(1.0*(P0[i].x-P1[j].x)*(P0[i].x-P1[j].x) +1.0*(P0[i].y-P1[j].y)*(P0[i].y-P1[j].y));
			for (int k = 1; k < N; ++k) {
				if (check(P0[i], P1[j], P0[k], P0[k+1])) {
					ban[i][j + N] = ban[j + N][i] = true; break;
				}
				if (check(P0[i], P1[j], P1[k], P1[k+1])) {
					ban[i][j + N] = ban[j + N][i] = true; break;
				}
			}
		}
	}

	for (int s = 1; s < (1 << (N * 2)); ++s)
		for (int i = 1; i <= N << 1; ++i) {
			if (__builtin_popcount(s) != 1) dp[s][i] = 1e18;
		}

	double ans = 1e18;
	for (int s = 1; s < (1 << (N * 2)); ++s) {
		for (int i = 1; i <= N << 1; ++i) {
			if ((s & (1 << (i-1))) == 0) continue;
			if (dp[s][i] >= inf) continue;
			for (int j = 1; j <= N; ++j) {
				int _j = j + (i<=N) * N;
				if (s & (1 << (_j-1))) continue;
				if (ban[i][_j]) continue;
				chkmin(dp[s ^ (1<<(_j-1))][_j], dp[s][i] + dis[i][_j]);
			}

			if (s == (1<<(2*N)) - 1) chkmin(ans, dp[s][i]);
		}
	}

	if (ans >= 1e18) 
		printf("%lf\n", -1.0);
	else 
		printf("%.10lf\n", ans);

	return 0;
}

