#include <bits/stdc++.h>

typedef std::pair<int, int> PII;

#define a first
#define b second

inline int read(int Num = 0, int Flag = 1)
{
	char ch = getchar();
	for (; !isdigit(ch); ch = getchar()) 
		if (ch == '-')
			Flag = -1;
	for (;  isdigit(ch); ch = getchar())
		Num = Num * 10 + ch - '0';
	return Num *= Flag;
}

template <typename T> bool chkmax(T &a, T b) { return a < b? a = b, true : false; }
template <typename T> bool chkmin(T &a, T b) { return a > b? a = b, true : false; }

const int MAXN = 5e3 + 5;
const int inf = 2e9 + 5;

int N, M, K;
PII P[MAXN];

int e, begin[MAXN];
struct Edge
{
	int to, next;
}E[MAXN << 1];

void Add_edge(int u, int v)
{
	E[++e] = (Edge) {v, begin[u]}; begin[u] = e;
}

bool inq[MAXN];
int val_b[MAXN], cnt;

int block_sz;
std::vector<int> bound[MAXN];

void DFS_find(int u, int Mxa, int Mxb)
{
	int next_p = cnt + 1;
	for (int k = begin[u]; k; k = E[k].next) {
		int v = E[k].to;
		if (inq[v] || P[v].a > Mxa)
			continue;
		else if (P[v].b > Mxb) {
			chkmin(next_p, P[v].b); 
			continue;
		}

		inq[v] = true;
		block_sz ++;
		DFS_find(v, Mxa, Mxb);
	}
	if (next_p <= cnt) 
		bound[next_p].push_back(u);
}

int main()
{
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);

	N = read(), M = read(), K = read();

	for (int i = 1; i <= N; ++i) {
		P[i].a = read();
		P[i].b = read();
		val_b[++cnt] = P[i].b;
	}
	for (int i = 1; i <= M; ++i) {
		int u = read(), v = read();
		Add_edge(u, v);
		Add_edge(v, u);
	}

	std::sort(P + 1, P + N + 1);
	std::sort(val_b + 1, val_b + cnt + 1);
	cnt = std::unique(val_b + 1, val_b + cnt + 1) - val_b - 1;

	for (int i = 1; i <= N; ++i) {
		P[i].b = std::lower_bound(val_b + 1, val_b + cnt + 1, P[i].b) - val_b;
	}

	int ans = inf;
	for (int i = 1; i <= N; ++i) {
		bound[P[i].b].push_back(i);
		inq[i] = true;
		block_sz = 1;

		if (P[i].a + P[i].b >= ans) continue;

		for (int cur = P[i].b; cur <= cnt; ++cur) {
			for (int j = 0; j < (int)bound[cur].size(); ++j) {
				int u = bound[cur][j];
				DFS_find(u, P[i].a, cur);
			}

			if (block_sz >= K) {
				chkmin(ans, P[i].a + val_b[cur]);
				break;
			}
		}

		block_sz = 0;
		memset(inq, 0, sizeof inq);
	}

	if (ans >= inf) {
		puts("no solution");
		return 0;
	}
	printf("%d\n", ans);

	return 0;
}

