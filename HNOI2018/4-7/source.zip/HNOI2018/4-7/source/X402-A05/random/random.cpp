#include <bits/stdc++.h>

typedef long long LL;

inline int read(int Num = 0, int Flag = 1)
{
	char ch = getchar();
	for (; !isdigit(ch); ch = getchar()) 
		if (ch == '-')
			Flag = -1;
	for (;  isdigit(ch); ch = getchar())
		Num = Num * 10 + ch - '0';
	return Num *= Flag;
}

template <typename T> bool chkmax(T &a, T b) { return a < b? a = b, true : false; }
template <typename T> bool chkmin(T &a, T b) { return a > b? a = b, true : false; }

const int MAXN = 50 + 5;
const int mod = 998244353;
const int base = 1e4;

int fpm(int x, int e)
{
	int ret = 1;
	for (; e; e >>= 1) {
		if (e & 1) 
			ret = (LL)ret * x % mod;
		x = (LL)x * x % mod;
	}
	return ret;
}

int N, M, mul_num;
int G[MAXN][MAXN];

namespace SubTask_1
{

int dfs_clock;
int low[MAXN], dfn[MAXN];
int edge[MAXN][MAXN];
int sccid[MAXN], scc_cnt;
int stk[MAXN], top;

inline void clear()
{
	dfs_clock = 0;
	scc_cnt = 0;
	for (int i = 1; i <= N; ++i) {
		low[i] = dfn[i] = 0;
		sccid[i] = 0;
	}
}

void Tarjan(int u)
{
	stk[++top] = u;
	low[u] = dfn[u] = ++dfs_clock;

	for (int v = 1; v <= N; ++v) if (edge[u][v]) {
		if (!low[v]) {
			Tarjan(v);
			chkmin(low[u], low[v]);
		}
		else if (!sccid[v]) {
			chkmin(low[u], low[v]);
		}
	}

	if (low[u] == dfn[u]) {
		for (scc_cnt ++;;) {
			int x = stk[top--];
			sccid[x] = scc_cnt;
			if (x == u) break;
		}
	}
}

int ans;

void DFS_calc(int x, int y, int p)
{
	if (x > N) {
		clear();
		for (int i = 1; i <= N; ++i)
			if (!low[i]) Tarjan(i);
		ans = (ans + (LL)scc_cnt * p % mod) % mod;
		return ;
	}

	if (y > N) {
		DFS_calc(x + 1, x + 2, p);
		return ;
	}

	edge[x][y] = 1;
	edge[y][x] = 0;
	DFS_calc(x, y + 1, (LL)p * G[x][y] % mod);
	edge[x][y] = 0;
	edge[y][x] = 1;
	DFS_calc(x, y + 1, (LL)p * G[y][x] % mod);
}

void main()
{
	DFS_calc(1, 2, 1);
	ans = (LL)ans * mul_num % mod;
	printf("%d\n", ans);
}

}

namespace SubTask_2
{
const int MAXN = 15 + 5;
const int MAXS = 1 << 15;

int all_to[MAXN][MAXS];
int have[MAXS][MAXN];
int len[MAXS];

int scc[MAXS], g[MAXS];

void main()
{
	for (int s = 0; s < 1 << N; ++s) {
		for (int i = 1; i <= N; ++i)
			if (s & (1 << (i-1))) have[s][++len[s]] = i;
	}

	for (int i = 1; i <= N; ++i) {
		for (int s = 0; s < 1 << N; ++s) {
			all_to[i][s] = 1;
			for (int j = 1; j <= len[s]; ++j) 
				all_to[i][s] = (LL)all_to[i][s] * G[i][have[s][j]] % mod;
		}
	}

	for (int s = 0; s < 1 << N; ++s) {
		scc[s] = 1;
		for (int s0 = (s-1) & s; s0; s0 = (s0-1) & s) {
			int p = 1;
			for (int i = 1; i <= len[s0]; ++i)
				p = (LL)p * all_to[have[s0][i]][s ^ s0] % mod;
			scc[s] = (scc[s] - (LL)scc[s0] * p % mod + mod) % mod;
		}
	}

	for (int s = 0; s < 1 << N; ++s) {
		for (int s0 = s; s0; s0 = (s0-1) & s) {
			int p = 1;
			for (int i = 1; i <= len[s0]; ++i)
				p = (LL)p * all_to[have[s0][i]][s ^ s0] % mod;
			g[s] = (g[s] + (LL)(g[s ^ s0] + 1) * scc[s0] % mod * p % mod) % mod;
		}
	}

	printf("%lld\n", (LL)g[(1<<N) - 1] * mul_num % mod);
}

}

namespace SubTask_3
{

int C[MAXN][MAXN];
int f[MAXN];
int g[MAXN][MAXN];

void main()
{
	for (int i = 0; i < MAXN; ++i) C[i][0] = 1;
	for (int i = 1; i < MAXN; ++i) {
		for (int j = 1; j <= i; ++j)
			C[i][j] = (C[i-1][j-1] + C[i-1][j]) % mod;
	}
	for (int i = 1; i <= N; ++i) {
		f[i] = fpm(2, C[i][2]);
		for (int j = 1; j < i; ++j)
			f[i] = (f[i] - (LL)C[i][j] * fpm(2, C[i-j][2]) % mod * f[j] % mod + mod) % mod;
	}

	g[0][0] = 1;
	for (int i = 1; i <= N; ++i) {
		for (int j = 0; j < i; ++j)
			for (int k = 1; k <= i; ++k)
				g[i][k] = (g[i][k] + (LL)g[j][k-1] * f[i-j] % mod * C[i][i-j] % mod) % mod;
	}

	int ans = 0;
	for (int i = 1; i <= N; ++i) ans = (ans + (LL)g[N][i] * i % mod) % mod;
	ans = (LL)ans * fpm(fpm(2, C[N][2]), mod - 2) % mod;

	printf("%lld\n", (LL)ans * mul_num % mod);
}

}

int main()
{
	freopen("random.in", "r", stdin);
	freopen("random.out", "w", stdout);

	N = read(), M = read();
	mul_num = fpm(base, N * (N-1));

	for (int i = 1; i <= N; ++i) {
		for (int j = 1; j <= N; ++j) if (i != j) {
			G[i][j] = fpm(2, mod - 2);
		}
	}

	for (int i = 1; i <= M; ++i) {
		int u = read(), v = read(), w = read();

		G[u][v] = (LL)w * fpm(base, mod - 2) % mod;
		G[v][u] = mod + 1 - G[u][v];
	}

	if (N <= 6) 
		SubTask_1 :: main();
	else if (N <= 15) 
		SubTask_2 :: main();
	else 
		SubTask_3 :: main();

//	fprintf(stderr, "%.8lf\n", 1.0 * clock()/CLOCKS_PER_SEC);

	return 0;
}

