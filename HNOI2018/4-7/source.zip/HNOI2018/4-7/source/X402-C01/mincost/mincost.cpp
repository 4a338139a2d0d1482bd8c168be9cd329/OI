/************************************************
 * Au: Hany01
 * Prob: mincost bf    > Remember to think about a better sort method than O(nlog_2n)
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define File(a) freopen(a".in", "r", stdin), freopen(a".out", "w", stdout)
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define x first
#define y second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

const int maxn = 300005, maxm = 1000005;

int n, m, k, Ans, beg[maxn], v[maxm], nex[maxm], e, pos[maxn], fa[maxn], sz[maxn];

struct Node
{
	int a, b, id;
	inline bool operator < (const Node& A) const { return a < A.a; };
}p[maxn];

inline bool cmp(const Node& A, const Node& B) { return A.b < B.b; }

inline void add(int uu, int vv) { v[++ e] = vv, nex[e] = beg[uu], beg[uu] = e; }

int find(int x) { return fa[x] == x ? x : fa[x] = find(fa[x]); }

int main()
{
	File("mincost");

	static int uu, vv;

	n = read(), m = read(), k = read();
	For(i, 1, n) p[i].a = read(), p[i].b = read(), p[i].id = i;
	sort(p + 1, p + 1 + n);
	For(i, 1, m) uu = read(), vv = read(), add(uu, vv), add(vv, uu);

	Ans = INF1;
	int lasa = 0;
	sort(p + 1, p + 1 + k - 1, cmp);
	For(i, k, n)
	{
		cerr << i << endl;
		while (i < n && p[i + 1].a == p[i].a) ++ i;
		register int nowa = p[i].a;

		int poss = 0;
		For(j, 1, i - 1)
			if (p[i].b < p[j].b) {
				poss = j; break;
			}
		if (poss) {
			Node tmp = p[i];
			Fordown(j, i, poss + 1) p[j] = p[j - 1];
			p[poss] = tmp;
		}
		For(j, 1, i) pos[p[j].id] = j;

		For(j, 1, i) fa[j] = j, sz[j] = 1;

		register int flag = 0;
		For(j, 1, i)
		{
			register int u = p[j].id, fu = find(j);
			for (int l = beg[u]; l; l = nex[l])
				if (pos[v[l]]) {
					register int fv = find(pos[v[l]]);
					if (fu == fv) continue;
					fa[fv] = fu;
					if ((sz[fu] += sz[fv]) >= k) {
						flag = 1;
						chkmin(Ans, p[j].b + nowa);
						break;
					}
				}
			if (flag) break;
		}
	}

	printf("%d\n", Ans);

    return 0;
}
