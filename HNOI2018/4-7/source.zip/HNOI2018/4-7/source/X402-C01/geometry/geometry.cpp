/************************************************
 * Au: Hany01
 * Prob: geometry bf
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define File(a) freopen(a".in", "r", stdin), freopen(a".out", "w", stdout)
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define x first
#define y second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

const int maxn = 1005;

int n, a[maxn][maxn], vis[2][maxn];
long double Ans;

const long double eps = 1e-6;
inline int dcmp(long double x) {
	if (fabs(x) < eps) return 0;
	return x > 0 ? 1 : -1;
}
struct Point
{
	long double x, y;
	Point(long double x = 0, long double y = 0): x(x), y(y) {}
}A[maxn], B[maxn];
typedef Point Vector;
inline Vector operator + (Vector A, Vector B) { return Vector(A.x + B.x, A.y + B.y); }
inline Vector operator - (Vector A, Vector B) { return Vector(A.x - B.x, A.y - B.y); }
inline Vector operator * (Vector A, long double d) { return Vector(A.x * d, A.y * d); }
inline long double Dot(Vector A, Vector B) { return A.x * B.x + A.y * B.y; }
inline long double Cross(Vector A, Vector B) { return A.x * B.y - A.y * B.x; }
inline long double Angle(Vector A) { return atan2(A.y, A.x); }
inline long double Distance(Vector A) { return sqrt(Dot(A, A)); }
inline long double Solve(Vector A) { return A.y / A.x; }
inline Point GetLineIntersection(Point P, Vector v, Point Q, Vector w) {
	Vector u = P - Q;
	long double t = Cross(w, u) / Cross(v, w);
	return P + v * t;
}
inline bool isonline(Point T, Point P, Vector v)
{
	if (dcmp(Cross(P - T, v))) return 0;
	Point Q = P + v;
	long double a = Q.x, b = P.x;
	if (a > b) swap(a, b);
	if (dcmp(T.x - a) <= 0 || dcmp(T.x - b) >= 0) return 0;
	a = Q.y, b = P.y;
	if (a > b) swap(a, b);
	if (dcmp(T.y - a) <= 0 || dcmp(T.y - b) >= 0) return 0;
	return 1;
}
inline bool chk(Point P, Vector v, Point Q, Vector w)
{
	Point T = GetLineIntersection(P, v, Q, w);
	return isonline(T, P, v) && isonline(T, Q, w);
}

void dfs(int ty, int u, int fns, long double sum)
{
	if (fns == 2 * n - 1) {
		chkmin(Ans, sum);
		return ;
	}
	if (ty == 0)
	{
		For(i, 1, n) if (!vis[1][i] && a[u][i])
		{
			vis[1][i] = 1;
			dfs(1, i, fns + 1, sum + Distance(A[u] - B[i]));
			vis[1][i] = 0;
		}
	} else
	{
		For(i, 1, n) if (!vis[0][i] && a[i][u])
		{
			vis[0][i] = 1;
			dfs(0, i, fns + 1, sum + Distance(A[i] - B[u]));
			vis[0][i] = 0;
		}
	}
}

int main()
{
#ifdef hany01
	File("geometry");
#endif

	n = read();
	For(i, 1, n) A[i].x = read(), A[i].y = read();
	For(i, 1, n) B[i].x = read(), B[i].y = read();

	if (n == 1) {
		printf("%.10lf\n", Distance(A[1] - B[1]));
		return 0;
	}

	A[0].x = A[1].x, A[0].y = 1000000001;
	A[n + 1].x = A[n].x, A[n + 1].y = 1000000001;
	B[0].x = B[1].x, B[0].y = -1000000001;
	B[n + 1].x = B[n].x, B[n + 1].y = -1000000001;


	For(i, 1, n)
		For(j, 1, n) {
			int mark = 1;
			For(k, 0, n) if (chk(A[k], A[k + 1] - A[k], A[i], B[j] - A[i])) { mark = 0; break; }
			if (mark) For(k, 0, n) if (chk(B[k], B[k + 1] - B[k], A[i], B[j] - A[i])) {
				mark = 0; break;
			}
			a[i][j] = mark;
		}

	Ans = 9999999999999999ll;

	For(i, 0, 1) For(j, 1, n) dfs(i, j, 0, 0);

	if (!dcmp(Ans -9999999999999999ll)) {
		puts("-1");
	} else printf("%.15Lf\n", Ans);

    return 0;
}
