/************************************************
 * Au: Hany01
 * Prob: random bf
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define File(a) freopen(a".in", "r", stdin), freopen(a".out", "w", stdout)
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define x first
#define y second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (998244353)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline LL Pow(LL a, LL b)
{
	LL Ans = 1;
	for ( ; b; b >>= 1, (a *= a) %= Mod) if (b & 1) (Ans *= a) %= Mod;
	return Ans;
}

const int maxn = 40, maxm = 40 * 40 * 2;

int n, m, e, tim, sccs, stk[maxn], top, isin[maxn], dir[maxn][maxn], beg[maxn], nex[maxm], v[maxm], low[maxn], dfn[maxn];
LL inv2, inv1e4, pr[maxn][maxn], Ans;

inline void add(int uu, int vv) { v[++ e] = vv, nex[e] = beg[uu], beg[uu] = e; }

void dfs(int u)
{
	dfn[u] = low[u] = ++ tim, stk[++ top] = u, isin[u] = 1;
	for (register int i = beg[u]; i; i = nex[i])
		if (!dfn[v[i]]) dfs(v[i]), chkmin(low[u], low[v[i]]);
		else if (isin[v[i]]) chkmin(low[u], dfn[v[i]]);
	if (dfn[u] == low[u]) {
		++ sccs;
		do isin[stk[top]] = 0; while (stk[top --] != u);
	}
}

inline void check(LL Pr)
{
	e = tim = sccs = 0, Set(beg, 0), Set(dfn, 0);
	For(i, 1, n - 1) For(j, i + 1, n)
		if (dir[i][j]) add(i, j); else add(j, i);

	For(i, 1, n) if (!dfn[i]) dfs(i);
	(Ans += sccs * Pr % Mod) %= Mod;
}

void dfs(int u, int v, LL Pr)
{
	if (u == n + 1) { check(Pr); return ; }
	if (v == n + 1) { dfs(u + 1, u + 2, Pr); return ; }
	dir[u][v] = 1, dfs(u, v + 1, Pr * pr[u][v] % Mod),
	dir[u][v] = 0, dfs(u, v + 1, Pr * (Mod + 1 - pr[u][v]) % Mod);
}

int main()
{
	File("random");

	static int ui, vi;

	n = read(), m = read();
	inv2 = Pow(2, Mod - 2), inv1e4 = Pow(10000, Mod - 2);
	For(i, 1, n - 1) For(j, i + 1, n) pr[i][j] = inv2;
	For(i, 1, m) ui = read(), vi = read(), pr[ui][vi] = (LL)read() * inv1e4 % Mod;

	dfs(1, 2, 1);

	printf("%lld\n", Ans /** Pow(10000, n * (n - 1)) % Mod*/);

    return 0;
}
