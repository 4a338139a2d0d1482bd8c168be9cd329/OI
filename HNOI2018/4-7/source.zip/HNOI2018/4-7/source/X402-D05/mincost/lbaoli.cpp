#include<bits/stdc++.h>
using namespace std;
const int maxn=500100;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
void chkmin(int &x,int y){
	x=x<y?x:y;
}
int n,m,k;
int f[maxn];
int fa(int x){
	if(f[x]==x) return x;
	return f[x]=fa(f[x]);
}
struct node{
	int x,y;
}a[maxn];
int stk[maxn],top;
int ans=INT_MAX;
void check(){
	int v=fa(stk[1]);
	for(int i=1;i<=top;i++)
		if(fa(stk[i])!=v)
			return;
	int mxx=0,mxy=0;
	for(int i=1;i<=top;i++)
		chkmax(mxx,a[stk[i]].x),chkmax(mxy,a[stk[i]].y);
	chkmin(ans,mxx+mxy);
}
void dfs(int p,int res){
	if(res==0){
		check();
		return;
	}
	if(p>n) return;
	stk[++top]=p;
	dfs(p+1,res-1);
	top--;
	dfs(p+1,res);
}
int main(){
	freopen("mincost.in","r",stdin);
	freopen("lbaoli.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a[i].x,&a[i].y);
		f[i]=i;
	}
	int s,t;
	for(int i=1;i<=n;i++){
		scanf("%d%d",&s,&t);
		f[fa(s)]=fa(t);
	}
	dfs(1,k);
	printf("%d\n",ans);
	return 0;
}
