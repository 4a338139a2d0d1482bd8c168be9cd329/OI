#include<bits/stdc++.h>
using namespace std;
const int maxn=500100;
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
void chkmin(int &x,int y){
	x=x<y?x:y;
}
void chkmax(int &x,int y){
	x=x>y?x:y;
}
struct node{
	int x,y;
}a[maxn];
struct Edge{
	int s,t,x,y;
}w[maxn];
int f[maxn],siz[maxn],mxsiz;
int fa(int x){
	if(f[x]==x) return x;
	return f[x]=fa(f[x]);
}
void Link(int x,int y){
	x=fa(x),y=fa(y);
	siz[y]+=siz[x];
	f[x]=y;
	chkmax(mxsiz,siz[y]);
}
int main(){
	freopen("mincost1.in","r",stdin);
	int n,m,k;
	int s,t;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		readl(a[i].x),readl(a[i].y);
	for(int i=1;i<=m;i++){
		readl(w[i].s),readl(w[i].t);
		w[i].a=a[i].x,w[i].b=a[i].y;
	}
	int ans=INT_MAX;
	if(ans==INT_MAX)
		printf("no solution\n");
	else
		printf("%d\n",ans);
	return 0;
}
