#include<bits/stdc++.h>
using namespace std;
const int maxn=500100;
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
void chkmin(int &x,int y){
	x=x<y?x:y;
}
void chkmax(int &x,int y){
	x=x>y?x:y;
}
int Max(int x,int y){
	return x>y?x:y;
}
struct node{
	int x,y;
}a[maxn];
struct Edge{
	int s,t,x,y;
}w[maxn];
bool cmp(const Edge &A,const Edge &B){
	return A.y<B.y;
}
int f[maxn],siz[maxn],mxsiz;
int b[maxn];
int fa(int x){
	if(f[x]==x) return x;
	return f[x]=fa(f[x]);
}
void Link(int x,int y){
	x=fa(x),y=fa(y);
	if(x==y) return;
	siz[y]+=siz[x];
	f[x]=y;
	chkmax(mxsiz,siz[y]);
}
int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		readl(a[i].x),readl(a[i].y);
	for(int i=1;i<=m;i++){
		readl(w[i].s),readl(w[i].t);
		w[i].x=Max(a[w[i].s].x,a[w[i].t].x);
		w[i].y=Max(a[w[i].s].y,a[w[i].t].y);
	}
	sort(w+1,w+m+1,cmp);

	for(int i=1;i<=n;i++)
		b[i]=a[i].x;
	sort(b+1,b+n+1);

	int ans=INT_MAX;
	if(k==1){
		for(int i=1;i<=n;i++)
			chkmin(ans,a[i].x+a[i].y);
	}
	else{
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)
				f[j]=j,siz[j]=1;
			mxsiz=1;
			for(int j=1;j<=m;j++){
				if(w[j].x>b[i]) continue;
				Link(w[j].s,w[j].t);
				if(mxsiz>=k){
					chkmin(ans,b[i]+w[j].y);
					break;
				}
			}
		}
	}
	if(ans==INT_MAX)
		printf("no solution\n");
	else
		printf("%d\n",ans);
	return 0;
}
