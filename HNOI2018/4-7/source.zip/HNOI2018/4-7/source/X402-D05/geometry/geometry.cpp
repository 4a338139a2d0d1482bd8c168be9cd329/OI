#include<bits/stdc++.h>
using namespace std;
struct node{
	double x,y;
}a[100],b[100];
node operator - (const node &A,const node &B){
	return (node){A.x-B.x,A.y-B.y};
}
double cross(const node &A,const node &B){
	return A.x*B.y-A.y*B.x;
}
double pf(double x){
	return x*x;
}
double getdis(const node &A,const node &B){
	return sqrt(pf(A.x-B.x)+pf(A.y-B.y));
}
double d[100][100];
double dp[1<<20][20];
void chk(double &x,double y){
	if(x<-0.5) x=y;
	else if(y<0.5) return;
	else x=x<y?x:y;
}
void print(const node &A){
	fprintf(stderr,"(%.3f %.3f)\n",A.x,A.y);
}
int main(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&a[i].x,&a[i].y);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&b[i].x,&b[i].y);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			d[i-1][j+n-1]=-1.0;
			d[j+n-1][i-1]=-1.0;
			if(i>1){
				if(cross(b[j]-a[i],a[i-1]-a[i])>0)
					continue;
			}
			if(i<n){
				if(cross(b[j]-a[i],a[i+1]-a[i])<0)
					continue;
			}
			if(j>1){
				if(cross(a[i]-b[j],b[j-1]-b[j])<0)
					continue;
			}
			if(j<n){
				if(cross(a[i]-b[j],b[j+1]-b[j])>0)
					continue;
			}
			d[i-1][j+n-1]=getdis(a[i],b[j]);
			d[j+n-1][i-1]=getdis(a[i],b[j]);
		}
	}
	for(int i=0;i<(1<<(n*2));i++)
		for(int j=0;j<n*2;j++)
			dp[i][j]=-1.0;
	for(int i=0;i<n*2;i++)
		dp[1<<i][i]=0;
	for(int i=0;i<(1<<(n*2));i++){
		for(int j=0;j<n*2;j++){
			if(!(i&(1<<j))) continue;
			if(dp[i][j]<-0.5) continue;
			for(int k=0+(j<n?n:0);k<n+(j<n?n:0);k++){
				if(d[j][k]<-0.5) continue;
				if(i&(1<<k)) continue;
				chk(dp[i|(1<<k)][k],dp[i][j]+d[j][k]);
			}
		}
	}
	double ans=-1.0;
	for(int i=0;i<n*2;i++)
		chk(ans,dp[(1<<(n*2))-1][i]);
	printf("%.10f\n",ans);
	return 0;
}
