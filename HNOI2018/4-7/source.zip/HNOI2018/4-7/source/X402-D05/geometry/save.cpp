#include<bits/stdc++.h>
using namespace std;
struct node{
	double x,y;
}a[100],b[100];
double pf(double x){
	return x*x;
}
double getdis(const node &A,const node &B){
	return sqrt(pf(A.x-B.x)+pf(A.y-B.y));
}
int main(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&a[i].x,&a[i].y);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&b[i].x,&b[i].y);
	double ans=0;
	for(int i=1;i<=n;i++){
		ans=ans+getdis(a[i],b[i]);
		if(i<n)
			ans=ans+getdis(a[i],b[i+1]);
	}
	printf("%.10f\n",ans);
	return 0;
}
