#include<bits/stdc++.h>
using namespace std;
const int md=998244353;
int a[20][20];
int d[20][1<<15];
int dp[1<<15];
int mp[1<<15];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int main(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	int s,t,v;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			if(i!=j)
				a[i][j]=powd(2,md-2);
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&s,&t,&v);
		s--,t--;
		a[s][t]=v*powd(10000,md-2)%md;
		a[t][s]=(10000-v)*powd(10000,md-2)%md;
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<(1<<n);j++){
			d[i][j]=1;
			for(int k=0;k<n;k++)
				if(j&(1<<k))
					d[i][j]=d[i][j]*(long long)a[i][k]%md;
		}
	}
	for(int i=0;i<n;i++)
		mp[1<<i]=i;
	int ans=0,sum,val;
	for(int i=1;i<(1<<n);i++){
		v=((1<<n)-1)^i;
		sum=0;
		for(int j=i&(i-1);j;j=i&(j-1)){
			val=1;
			for(int k=j;k;k-=k&(-k))
				val=val*(long long)d[mp[k&(-k)]][i^j]%md;
			sum=(sum+val*(long long)dp[j])%md;
		}
		sum=(1-sum+md)%md;
		dp[i]=sum;
		sum=0;
		for(int j=v;;j=v&(j-1)){
			val=1;
			for(int k=j;k;k-=k&(-k))
				val=val*(long long)d[mp[k&(-k)]][((1<<n)-1)^j]%md;
			for(int k=i;k;k-=k&(-k))
				val=val*(long long)d[mp[k&(-k)]][((1<<n)-1)^j^i]%md;
			sum=(sum+val)%md;
			if(j==0) break;
		}
		ans=(ans+dp[i]*(long long)sum)%md;
	}
	printf("%lld\n",ans*powd(10000,n*(n-1))%md);
	return 0;
}
