#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=998244353;
const int N=45;
const int M=19;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int head[N],cnt=0;
struct node
{
	int to,next;
}e[M<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
}

struct pip
{
	int x,y,w;
	pip(int x=0,int y=0,int w=0):x(x),y(y),w(w) { }
};
pip E[M<<1];
int n,m,dfn[N],low[N],clk=0,stk[N],top=0,scc=0,id[N][N],tot=0;
bool instk[N];

void tarjan(int u)
{
	dfn[u]=low[u]=++clk;
	stk[++top]=u; instk[u]=1;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(!dfn[v]) tarjan(v),low[u]=min(low[u],low[v]);
		else if(instk[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		scc++;
		while(stk[top]!=u) instk[stk[top]]=0,top--;
		instk[stk[top]]=0; top--;
	}
}

namespace m0
{
	int fac[N],finv[N],h[N],f[N],g[N];
	inline int C(int a,int b)
	{
		if(a<0||b<0||a<b) return 0;
		return 1ll*fac[a]*finv[b]%mod*finv[a-b]%mod;
	}
	void solve()
	{
		fac[0]=1;
		for(int i=1;i<=n;++i) fac[i]=1ll*fac[i-1]*i%mod;
		finv[n]=qpow(fac[n],mod-2);
		for(int i=n-1;i>=0;--i) finv[i]=1ll*finv[i+1]*(i+1)%mod;

		for(int i=0;i<=n;++i) h[i]=qpow(2,i*(i-1)/2);
		g[1]=1;
		for(int i=2;i<=n;++i)
		{
			g[i]=h[i];
			for(int j=1;j<i;++j) g[i]=(g[i]-1ll*C(i,j)*g[j]%mod*h[i-j]%mod+mod)%mod;
		}
		f[0]=0;
		for(int i=1;i<=n;++i) for(int j=1;j<=i;++j)
			f[i]=(f[i]+1ll*C(i,j)*g[j]%mod*(f[i-j]+h[i-j])%mod)%mod;
		printf("%lld\n",1ll*f[n]*qpow(mod+1>>1,n*(n-1)/2)%mod
		*qpow(10000,n*(n-1))%mod);
	}
}

void wj()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=1;i<=n;++i) for(int j=i+1;j<=n;++j) 
		id[i][j]=++tot,E[tot]=pip(i,j,(mod+1)>>1);

	for(int i=1;i<=m;++i) 
	{
		int x=read(),y=read(),w=read();
		w=1ll*w*qpow(10000,mod-2)%mod;
		E[id[x][y]].w=w;
	}
	if(!m) {m0::solve();return 0;}
	m=n*(n-1)/2;
	int tot=1<<m,ans=0;
	for(int s=0;s<tot;++s)
	{
		int p=1;
		cnt=0;
		for(int i=1;i<=n;++i) head[i]=0;
		for(int i=1;i<=m;++i) 
			if(s&(1<<i-1)) add(E[i].x,E[i].y),p=1ll*p*E[i].w%mod;
			else add(E[i].y,E[i].x),p=1ll*p*(1-E[i].w+mod)%mod;

		for(int i=1;i<=n;++i) dfn[i]=0,instk[i]=0;
		clk=0; top=0; scc=0;
		for(int i=1;i<=n;++i) if(!dfn[i]) tarjan(i);
		ans=(ans+1ll*p*scc)%mod;
	}
	//cerr<<1ll*n*qpow(10000,n*(n-1))%mod<<endl;
	//cerr<<1ll*ans*qpow(2,m)%mod<<endl;
	printf("%lld\n",1ll*ans*qpow(10000,n*(n-1))%mod);
	return 0;
}
