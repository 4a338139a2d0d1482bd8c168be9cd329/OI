#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=300050;
const int M=500050;
const int inf=0x7fffffff;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[M<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int n,m,k;
pii p[N];

queue<int>q;
int stk[N],top=0;
bool vis[N];
int check(int s,int lim)
{
	q.push(s); vis[s]=1; top=0;
	while(!q.empty())
	{
		int u=q.front(); q.pop();
		stk[++top]=u;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(p[v].fi<=p[s].fi&&p[v].se<=lim&&!vis[v]) q.push(v),vis[v]=1;
		}
	}
	for(int i=1;i<=top;++i) vis[stk[i]]=0;
	return top;
}

int buca[N],tota=0,bucb[N],totb=0;

void wj()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); k=read();
	for(int i=1;i<=n;++i)
	{
		p[i].fi=read(); p[i].se=read();
		buca[++tota]=p[i].fi; bucb[++totb]=p[i].se;
	}
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read();
		add(x,y);
	}
	sort(buca+1,buca+1+tota);
	tota=unique(buca+1,buca+1+tota)-(buca+1);
	for(int i=1;i<=n;++i) p[i].fi=lower_bound(buca+1,buca+1+tota,p[i].fi)-buca;
	sort(bucb+1,bucb+1+totb);
	totb=unique(bucb+1,bucb+1+totb)-(bucb+1);
	for(int i=1;i<=n;++i) p[i].se=lower_bound(bucb+1,bucb+1+totb,p[i].se)-bucb;

	int ans=inf;
	for(int s=1;s<=n;++s)
	{
		int l=p[s].se,r=totb;
		while(l<r)
		{
			int mid=l+r>>1;
			if(check(s,mid)>=k) r=mid;
			else l=mid+1;
		}
		if(check(s,l)>=k) ans=min(ans,buca[p[s].fi]+bucb[l]);
		//cerr<<s<<' '<<ans<<endl;
	}
	if(ans==inf) puts("no solution");
	else printf("%d\n",ans);
	return 0;
}
