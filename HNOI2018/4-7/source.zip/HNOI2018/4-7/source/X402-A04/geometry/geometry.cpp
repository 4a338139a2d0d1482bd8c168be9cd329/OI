#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<fstream>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

const int N=105;
const db eps=1e-7;
const db inf=1e14;

struct point
{
	db x,y;
	point(db x=0,db y=0):x(x),y(y) { }
};
point operator + (point a,point b) {return point(a.x+b.x,a.y+b.y);}
point operator - (point a,point b) {return point(a.x-b.x,a.y-b.y);}
point operator * (point a,db k) {return point(a.x*k,a.y*k);}
point operator / (point a,db k) {return point(a.x/k,a.y/k);}
inline db dot(point a,point b) {return a.x*b.x+a.y*b.y;}
inline db cross(point a,point b) {return a.x*b.y-b.x*a.y;}
inline db length(point a) {return sqrt(dot(a,a));}
inline int dcmp(db x)
{
	if(fabs(x)<eps) return 0;
	return x<0?-1:1;
}
inline bool intersect(point a,point b,point c,point d)
{
	return dcmp(cross(b-a,c-a)*cross(b-a,d-a))<0&&dcmp(cross(d-c,a-c)*cross(d-c,b-c))<0;
}

int head[N<<1],cnt=0;
struct node
{
	int to,next; db w;
}e[N*N];
inline void add(int x,int y,db w)
{
	//cerr<<x<<' '<<y<<endl;
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],w};head[y]=cnt;
}
int n;
point p[N<<1];
db f[1<<20|1][21];

string stat()
{
	ifstream t("/proc/self/status");
	return string(istreambuf_iterator<char>(t),istreambuf_iterator<char>());
}

void wj()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) scanf("%lf%lf",&p[i].x,&p[i].y);
	for(int i=n+1;i<=(n<<1);++i) scanf("%lf%lf",&p[i].x,&p[i].y);
	
	for(int i=1;i<=n;++i) for(int j=n+1;j<=(n<<1);++j)
	{
		bool can=1;
		for(int k=1;k<n;++k) if(intersect(p[i],p[j],p[k],p[k+1])) {can=0;break;}
		if(!can) continue;
		for(int k=n+1;k<(n<<1);++k) if(intersect(p[i],p[j],p[k],p[k+1])) {can=0;break;}
		if(!can) continue;
		if(!intersect(p[i],p[j],p[1],point(p[1].x,p[1].y+inf)) 
		&&!intersect(p[i],p[j],p[n],point(p[n].x,p[n].y+inf))
		&&!intersect(p[i],p[j],p[n+1],point(p[n+1].x,p[n+1].y-inf))
		&&!intersect(p[i],p[j],p[n<<1],point(p[n<<1].x,p[n<<1].y-inf)))
			add(i,j,length(p[j]-p[i]));
	}

	int tot=1<<(2*n);
	for(int s=0;s<tot;++s) for(int i=1;i<=(n<<1);++i) f[s][i]=inf;
	for(int i=1;i<=(n<<1);++i) f[1<<i-1][i]=0;

	for(int s=0;s<tot;++s) for(int u=1;u<=(n<<1);++u) if(f[s][u]!=inf)
	{
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(!(s&(1<<v-1))) f[s|(1<<v-1)][v]=min(f[s|(1<<v-1)][v],f[s][u]+e[i].w);
		}
	}
	db ans=inf;
	for(int i=1;i<=n;++i) ans=min(ans,f[tot-1][i]);
	printf("%.14lf\n",ans==inf?-1.0:ans);
	return 0;
}
