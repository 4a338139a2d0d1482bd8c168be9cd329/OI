#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int w,h,n;
int cnt;
int px[200005], py[200005];
bool used[200005];
int maxx, minx, maxy, miny;
int maxans = 0;
inline void dfs(int dep){
	cnt++;
	if(cnt>=10000000-1000)return ;
	if (dep == n + 1){
		if (2 * (maxx - minx + maxy - miny) > maxans){
			maxans = 2 * (maxx - minx + maxy - miny);
		}
	}
	else
    F(i,1,n){
		if (!used[i]){
			used[i] = true;
			F(j,1,4){
				if (j == 1){
					int tmp = maxx;
					maxx = min(px[i], maxx);
					dfs(dep + 1);
					maxx = tmp;
				}
				if (j == 2){
					int tmp = minx;
					minx = max(minx, px[i]);
					dfs(dep + 1);
					minx = tmp;
				}
				if (j == 3){
					int tmp = maxy;
					maxy = min(py[i], maxy);
					dfs(dep + 1);
					maxy = tmp;
				}
				if (j == 4){
					int tmp = miny;
					miny = max(miny, py[i]);
					dfs(dep + 1);
					miny = tmp;
				}
			}
			used[i] = false;
		}
	}
}
int main () {
#ifndef ONLINE_JUDGE
file("paint");
#endif
    w=read();
	h=read();
	n=read();
	Set(used,0);
	maxx = w, maxy = h;
	F(i,1,n)px[i]=read(),py[i]=read();
	dfs(1);
	cout << maxans << endl;
    return 0;
}
