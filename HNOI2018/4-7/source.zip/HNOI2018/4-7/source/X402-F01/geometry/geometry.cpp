#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n;
struct node{
   int x,y;
}up[10005],down[10005];
int main () {
#ifndef ONLINE_JUDGE
file("geometry");
#endif
   n=read();
   F(i,1,n)down[i].x=read(),down[i].y=read();
   F(i,1,n)up[i].x=read(),up[i].y=read();
   if(n==1)printf("%.10lf",sqrt((up[1].x-down[1].x)*(up[1].x-down[1].x)+(up[1].y-down[1].y)*(up[1].y-down[1].y)));
   return 0;
}
