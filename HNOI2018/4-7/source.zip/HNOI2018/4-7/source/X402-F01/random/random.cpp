#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n;
int m;
const int mod = 998244353;
int sum[1<<20];
bool can[45][45];
int dis[45][45];
int st[45][2];
int inv10000,tot10000,t;
long long qpow(long long x,long long y){
     long long res=1;
     while(y){
	    if(y&1)res=res*x%mod;
		x=x*x%mod;
		y>>=1;
	 }
	 return res;
}
namespace sub1{
	int col[45][45];
    void solve(){
	   long long ans=qpow(10000,n*(n-1)/2);
       F(i,0,n){
	      col[i][0]=1;
		   F(j,1,i-1){
		      col[i][j]=(col[i-1][j-1]+col[i-1][j])%mod;
		  }
		   col[i][i]=1;
	   }
	   F(i,1,n-1){
	       ans=(ans+col[n][i]*qpow(5000,i*(n-i))%mod*qpow(10000,n*(n-1)/2-i*(n-i)))%mod;
	   }
	   printf("%lld\n",ans*qpow(10000,n*(n-1)/2)%mod);
	} 
};
namespace sub2{
	long long a[1<<16];
	void solve(){
		F(i,0,(1<<n)-1){
			a[i]=1;
			F(j,1,n){
				F(k,j+1,n){
					if((i&(1<<(j-1)))&&(i&(1<<(k-1))))a[i]=a[i]*10000%mod;
					if((i&(1<<(j-1)))&&!(i&(1<<(k-1))))a[i]=a[i]*dis[k][j]%mod;
					if(!(i&(1<<(j-1)))&&(i&(1<<(k-1))))a[i]=a[i]*dis[j][k]%mod;
					if(!(i&(1<<(j-1)))&&!(i&(1<<(k-1))))a[i]=a[i]*10000%mod;
				}
			}
		}
			long long ans=qpow(10000,n*(n-1)/2);
			F(i,1,(1<<n)-2){
				ans=(ans+a[i])%mod;
			}
			printf("%lld\n",ans*qpow(10000,n*(n-1)/2)%mod);
	}
};
int main () {
#ifndef ONLINE_JUDGE
file("random");
#endif
    n=read();
	m=read();
    inv10000=qpow(10000,mod-2);
	tot10000=qpow(10000,n*(n-1));
   if(m==0){sub1::solve();return 0;}
	F(i,1,n){
	  F(j,1,n)dis[i][j]=5000;
	}
	F(i,1,m){
	   int x=read(),y=read(),z=read();
	   dis[x][y]=z;
	   dis[y][x]=10000-z;
	}
    if(n<=15&&m<=15){sub2::solve();return 0;}
	return 0;
}
