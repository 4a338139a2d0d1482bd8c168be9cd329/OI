#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int he[200005],to[200005],ne[200005],e;
int a[200005][5];
int fa[200005];
int n,l,q;
void add(int x,int y){
   to[++e]=y;
   ne[e]=he[x];
   he[x]=e;
}
int f[100005][6];
void dfs(int x){
    F(i,1,l)f[x][i]=-2107483648;
	long long res=0;
	for(int i=he[x];i;i=ne[i]){
	     int v=to[i];
		if(i!=fa[x])res+=f[v][0];
	}
    f[x][1]=res;
	for(int i=he[x];i;i=ne[i]){
		int v=to[i];
	   F(j,2,l){
	      chkmax(f[x][j],res-f[v][0]+f[v][j-1]);
	   }
	}
	f[x][0]=-2107483648;
	F(i,1,l){
	    f[x][i]+=a[x][i];
		chkmax(f[x][0],f[x][i]);
	}
}
int main () {
#ifndef ONLINE_JUDGE
file("decompose");
#endif
   n=read();
   q=read();
   l=read();
   F(i,2,n){
       int x=read();
	   add(x,i);
	   add(i,x);
	   fa[i]=x;
   }
   F(i,1,n){
      F(j,1,l){
	      a[i][j]=read();
	  }
   }
   while(q--){
       int x=read();
	   F(i,1,l)a[x][i]=read();
	   f(i,n,1)dfs(i);
      printf("%d\n",f[1][0]);
   }
    return 0;
}
