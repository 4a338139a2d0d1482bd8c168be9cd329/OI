#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("geometry.in", "r", stdin);
	freopen ("geometry.out", "w", stdout);
}

const int N = 1010;
int n;

struct Point {
	double x, y;
} a[N], b[N];

#define pow2(x) ((x) * (x))
inline double Dis(Point a, Point b) {
	return sqrt(pow2(a.x - b.x) + pow2(a.y - b.y));
}

int main () {
	File();
	n = read();
	For (i, 1, n) cin >> a[i].x >> a[i].y;
	For (i, 1, n) cin >> b[i].x >> b[i].y;
	printf ("%.15lf\n", Dis(a[1], b[1]));
    return 0;
}
