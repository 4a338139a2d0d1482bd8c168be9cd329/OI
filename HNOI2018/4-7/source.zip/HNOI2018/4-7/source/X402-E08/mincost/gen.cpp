#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

const int Mod = 1e9;
//int n = 500, m = 5000, k = 100;
int n = 5000, m = 5000, k = 100;
//int n = 15, m = 100, k = 10;
int main () {
	srand(time(0));
	freopen ("mincost.in", "w", stdout);
	printf ("%d %d %d\n", n, m, k);
	For (i, 1, n)
		printf ("%d %d\n", rand() % Mod + 1, rand() % Mod + 1);
	For (i, 1, m)
		printf ("%d %d\n", rand() % n + 1, rand() % n + 1);
    return 0;
}
