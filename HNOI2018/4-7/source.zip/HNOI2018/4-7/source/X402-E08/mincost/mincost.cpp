#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("mincost.in", "r", stdin);
	freopen ("mincost.out", "w", stdout);
}

int n, m, na, nb, k;
const int N = 101000, inf = 0x7f7f7f7f, M = N << 1;

int a[N], b[N], Hasha[N], Hashb[N], ans = inf;
int Head[N], Next[M], to[M], e = 0;

void add_edge(int u, int v) { to[++ e] = v; Next[e] = Head[u]; Head[u] = e; }
void Add(int u, int v) { add_edge(u, v); add_edge(v, u); }

int fa[N], sz[N];

int find(int x) { return fa[x] == x ? x : find(fa[x]); }

inline bool Union(int x, int y) {
	int rta = find(x), rtb = find(y);
	if (rta == rtb) return false;
	if (sz[rta] < sz[rtb]) swap(rta, rtb);
	fa[rtb] = rta;
	//cout << rtb << ' ' << rta << ' ' << sz[rta] << ' ' << sz[rtb] << endl;
	if ((sz[rta] += sz[rtb]) >= k) {
	//	cout << "Correct!!!" << endl;
		return true; 
	}
	else return false;
}

int Id[N];
inline bool Cmpb(int x, int y) { return b[x] < b[y]; }

int main () {
	File();
	n = read(); m = read(); k = read();
	For (i, 1, n) {
		a[i] = read(); b[i] = read(); swap(a[i], b[i]);
		Hasha[i] = a[i], Hashb[i] = b[i], Id[i] = i;
	}
	sort(Id + 1, Id + 1 + n, Cmpb);
	//For (j, 1, n) cout << b[Id[j]] << ' ';

	For (i, 1, m) { int u = read(), v = read(); Add(u, v); }
	sort(Hasha + 1, Hasha + 1 + n);
	na = unique(Hasha + 1, Hasha + 1 + n) - Hasha - 1;
	For (i, 1, na) {
		int vala = Hasha[i];
		For (j, 1, n) fa[j] = j, sz[j] = 1;
		bool flag = false;
		For (j, 1, n) if (a[Id[j]] <= vala) {
			int valb = b[Id[j]];
			if (vala + valb >= ans) break;
			int u = Id[j], v;
			for (int k = Head[u]; k; k = Next[k]) {
				v = to[k];
				if (a[v] > vala || b[v] > valb) continue ;
				if (Union(u, v)) { ans = vala + valb; flag = true; break; }
			}
			if (flag) break;
		}
	}
	if (ans == inf) puts("no solution");
	else printf ("%d\n", ans);
	cerr << (double) clock() / CLOCKS_PER_SEC << endl;
    return 0;
}
