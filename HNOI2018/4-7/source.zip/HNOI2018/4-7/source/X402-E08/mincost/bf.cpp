#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("mincost.in", "r", stdin);
	freopen ("bf.out", "w", stdout);
}

int n, m, nn;
const int N = 21, NN = (1 << 20) - 1;
int a[N], b[N];

vector<int> G[N];
int nowsta;
void Dfs(int u, int sta) {
	if ((nowsta & (1 << (u - 1))) || !(sta & (1 << (u - 1)))) return ;
	nowsta |= (1 << (u - 1));
	For (i, 0, G[u].size() - 1) { int v = G[u][i]; Dfs(v, sta); }
}

const int inf = 0x7f7f7f7f;
int k, ans = inf, maxva, maxvb;
bool flag = true;
int main () {
	File();
	n = read(); m = read(); k = read();
	For (i, 1, n)
		a[i] = read(), b[i] = read();
	For (i, 1, m) {
		int u = read(), v = read();
		G[u].push_back(v);
		G[v].push_back(u);
	}
	nn = (1 << n) - 1;
	For (i, 0, nn)
		if (__builtin_popcount(i) == k) {
			nowsta = 0; maxva = maxvb = 0;
			For (j, 1, n)
				if (i & (1 << (j - 1))) { chkmax(maxva, a[j]); chkmax(maxvb, b[j]); if (!nowsta) Dfs(j, i), flag = nowsta == i; }
			if (flag) chkmin(ans, maxva + maxvb);
		}
	if (ans == inf) puts("no solution");
	else printf ("%d\n", ans);
    return 0;
}
