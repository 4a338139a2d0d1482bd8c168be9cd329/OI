#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("mincost.in", "r", stdin);
	freopen ("bf.out", "w", stdout);
}

int n, m, na, nb, k;
const int N = 5050, inf = 0x7f7f7f7f, M = N << 1;

int a[N], b[N], Hasha[N], Hashb[N], ans;
int Head[N], Next[M], to[M], e = 0;

void add_edge(int u, int v) { to[++ e] = v; Next[e] = Head[u]; Head[u] = e; }
void Add(int u, int v) { add_edge(u, v); add_edge(v, u); }

int maxvb = 0, cnt = 0;
bitset<N> vis;

void Dfs(int u, int nowa, int nowb) {
	if (a[u] > nowa || b[u] > nowb || vis[u]) return ; 
	++ cnt; vis[u] = true;
	for (int i = Head[u]; i; i = Next[i])
		if (!vis[to[i]]) Dfs(to[i], nowa, nowb);
}

inline bool Check(int nowa, int nowb) {
	vis.reset();
	For (i, 1, n)
		if (a[i] <= nowa && b[i] <= nowb) if (!vis[i]) {
			cnt = 0; Dfs(i, nowa, nowb); if (cnt >= k) return true;
		}
	return false;
}

int main () {
	File();
	n = read(); m = read(); k = read();
	For (i, 1, n)
		Hasha[i] = a[i] = read(), Hashb[i] = b[i] = read();
	For (i, 1, m) { int u = read(), v = read(); Add(u, v); }
	sort (Hasha + 1, Hasha + 1 + n);
	sort (Hashb + 1, Hashb + 1 + n);
	na = unique(Hasha + 1, Hasha + 1 + n) - Hasha - 1;
	nb = unique(Hashb + 1, Hashb + 1 + n) - Hashb - 1;
	ans = inf;
	int tot = 0;
	For (i, 1, na) {
	//	cerr << i << ' ' << na << endl;
		int pos = lower_bound(Hashb + 1, Hashb + 1 + nb, ans - Hasha[i])- Hashb - 1;
		if (pos <= 0) break;
		int l = 1, r = pos, res = inf;
		while (l <= r) {
			int mid = (l + r) >> 1;
			if (Check(Hasha[i], Hashb[mid])) res = Hasha[i] + Hashb[mid], r = mid - 1;
			else l = mid + 1;
			++ tot;
		}
		chkmin(ans, res);
	}
	//printf ("tot = %d;\n", tot);
	if (ans == inf) puts("no solution");
	else printf ("%d\n", ans);
	//cerr << (double)clock() / CLOCKS_PER_SEC << endl;
    return 0;
}
