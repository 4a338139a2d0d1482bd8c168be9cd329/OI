#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("random.in", "r", stdin);
	freopen ("random.out", "w", stdout);
}

const int N = 7;
int G[N][N], n, m;
int scc_cnt, sccno[N], dfn[N], lowlink[N], clk;
int sta[N], top;

void Tarjan(int u) {
	lowlink[u] = dfn[u] = ++ clk; sta[++ top] = u;
	For (v, 1, n) if (G[u][v]) {
		if (!dfn[v]) Tarjan(v), chkmin(lowlink[u], lowlink[v]);
		else if (!sccno[v]) chkmin(lowlink[u], dfn[v]);
	}
	if (lowlink[u] == dfn[u]) {
		++ scc_cnt;
		for (;;) {
			int x = sta[top --];
			sccno[x] = scc_cnt;
			if (x == u) break;
		}
	}
}

typedef long long ll;
const ll Mod = 998244353;

struct edge {
	int u, v;
	ll num;
} lt[N * N];
int cnt = 0;

ll fpm(ll x, int power) {
	ll res = 1;
	for (; power; power >>= 1, (x *= x) %= Mod)
		if (power & 1) (res *= x) %= Mod;
	return res;
}

ll ans = 0, Pow10;
void Calc(ll prob) {
	scc_cnt = 0; Set(dfn, 0); Set(sccno, 0); Set(lowlink, 0);
	For (i, 1, n) if(!dfn[i]) Tarjan(i);
	(ans += 1ll * scc_cnt * prob % Mod) %= Mod;
}

void Dfs(int dep, ll prob) {
	if (dep == cnt + 1) { Calc(prob); return ; }
	int u = lt[dep].u, v = lt[dep].v; ll w = lt[dep].num;
	G[u][v] = true; G[v][u] = false;
	Dfs(dep + 1, prob * w % Mod);
	G[u][v] = false; G[v][u] = true;
	Dfs(dep + 1, prob * (10000 - w) % Mod);
}

bool E[N][N];
int main () {
	File();
	n = read(); m = read();
	For (i, 1, m) {
		int u = read(), v = read(), num = read();
		lt[++ cnt] = (edge) {u, v, (ll)num};
		E[u][v] = E[v][u] = true;
	}
	For (i, 1, n)
		For (j, i + 1, n) if (!E[i][j])
			lt[++ cnt] = (edge) {i, j, (ll)5000};
	Dfs(1, 1);
	Pow10 = fpm(10000, n * (n - 1) / 2);
	(ans *= Pow10) %= Mod;
	printf ("%lld\n", ans);
    return 0;
}
