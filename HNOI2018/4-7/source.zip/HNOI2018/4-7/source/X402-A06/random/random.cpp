#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

const int maxn = 100010;

int read() {
	
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum<<1) + (sum<<3) + c-'0', c = getchar();

	return sum * fg;
}

const int inf = 1e9 + 7;

const int mod = 998244353;

struct node{
	int x, y, val;
}edge[maxn];

int n, m, link[50][50];

int cnt = 0;

int ksm(int x,int k) {
	int s = 1;
	while(k) {
		if(k&1) s = 1ll * x * s % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}
	return s;
}

void Get() {
	n = read(), m = read();
	For(i, 1, m) {
		int x = read(), y = read(), z = read();
		link[x][y] = 1;
		link[y][x] = 1;
		edge[++cnt].x = x, edge[cnt].y = y, edge[cnt].val = z;
	}
}

void pre_work() {
	For(i, 1, n) {
		For(j, i+1, n) {
			if(!link[i][j]) {
				link[i][j] = 1;
				++ cnt;
				edge[cnt].x = i, edge[cnt].y = j, edge[cnt].val = 5000;
			}
		}
	}
}

int Begin[maxn], to[maxn], e, Next[maxn], dfs_clock, pre[maxn], low[maxn], st[maxn], top, circle[maxn], tot;

void add(int x,int y) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void dfs(int h) {
	st[++top] = h;
	pre[h] = low[h] = ++ dfs_clock;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];

		if(!pre[v]) {
			dfs(v);
			low[h] = min(low[h], low[v]);
		}
		else if(!circle[v]) low[h] = min(low[h], pre[v]);
	}

	if(pre[h] == low[h]) {
		++ tot;
		while(1) {
			int now = st[top--];
			circle[now] = 1;
			if(now == h) break;
		}
	}
}

void solve() {
	pre_work();
	int mp = (1 << cnt) - 1;
	int Ans = 0;
	For(i, 0, mp) {
		top = 0; tot = 0; dfs_clock = 0; e = 0;
		For(j, 1, n) pre[j] = 0;
		For(j, 1, n) low[j] = 0;
		For(j, 1, n) Begin[j] = 0;
		For(j, 1, n) circle[j] = 0;

		int ans = 1;
		For(j, 1, cnt) {
			if(i & (1 << j-1)) {
				add(edge[j].x, edge[j].y);
				ans = 1ll * ans * edge[j].val % mod * ksm(10000, mod-2) % mod;
			}
			else {
				add(edge[j].y, edge[j].x);
				ans = 1ll * ans * (10000 - edge[j].val) % mod * ksm(10000, mod-2) % mod;
			}
		}

		For(j, 1, n) if(!pre[j]) dfs(j);

		(Ans += 1ll * ans * tot % mod) %= mod;
	}

	Ans = 1ll * Ans * ksm(10000, n * (n - 1) ) % mod;
	printf("%d\n", Ans);
}

int main() {

	freopen("random.in", "r", stdin);
	freopen("random.out", "w", stdout);

	Get();
	solve();

	return 0;
}
