#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

const int maxn = 100010;

int read() {
	
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum<<1) + (sum<<3) + c-'0', c = getchar();

	return sum * fg;
}

const int inf = 1e9 + 7;

int n, m, K;

void Get() {
	
}

int main() {
	
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);

	puts("no solution");
	return 0;

	Get();

	return 0;
}
