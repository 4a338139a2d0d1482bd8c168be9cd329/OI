#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=50000+100;
int n,m,k,id;
int f[50][50];
int to[maxn<<1],ne[maxn<<1],po[maxn];
int vis[50];
int a[50],a1[50];
int A[50],B[50];
int ans;
queue<int> q;
struct node
{
	int x,y;
} c[maxn];
bool cmp(node aa,node bb)
{
	return aa.y<bb.y;
}
int fa[maxn],sz[maxn];
int gf(int x)
{
	if (fa[x]==x) return x;
	fa[x]=gf(fa[x]);
	return fa[x];
}
void add(int x,int y)
{
	id++;
	to[id]=y;ne[id]=po[x];po[x]=id;
}
bool check()
{
	for (int i=1;i<=k;i++) vis[a[i]]=0;
	while (!q.empty()) q.pop();
	q.push(a[1]);vis[a[1]]=1;
	while (!q.empty())
	{
		int u,v;
		u=q.front();q.pop();
		for (int i=po[u];i;i=ne[i])
		{
			v=to[i];
			if (a1[v]&&!vis[v])
			{
				vis[v]=1;
				q.push(v);
			}
		}
	}
	for (int i=1;i<=k;i++) if (!vis[a[i]]) return false;
	return true;
}
void dfs(int x,int Maxa,int Maxb,int last)
{
	if (Maxa+Maxb>ans) return;
	if (x==k+1)
	{
		if (!check()) return;
		qmin(ans,Maxa+Maxb);
		return;
	}
	for (int i=last+1;i<=n;i++)
	{
		if (x!=1&&!f[last][i]) continue;
		a[x]=i;
		a1[i]=1;
		dfs(x+1,max(Maxa,A[i]),max(Maxb,B[i]),i);
		a1[i]=0;
	}
}
void work1()
{
	ans=2e9;
	int X,Y;
	for (int i=1;i<=n;i++) A[i]=read(),B[i]=read();
	for (int i=1;i<=m;i++)
	{
		X=read();Y=read();
		add(X,Y);add(Y,X);
		f[X][Y]=1;f[Y][X]=1;
	}
	for (int l=1;l<=n;l++)
		for (int i=1;i<=n;i++)
			for (int j=1;j<=n;j++)
			{
				if (f[i][l]&&f[l][j]) f[i][j]|=1;
			}
	dfs(1,0,0,0);
	if (ans==(int)2e9) printf("no solution"); else 
	printf("%d\n",ans);
}
int Vis[maxn];
int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	n=read();m=read();k=read();
	if (n<=20)
	{
		work1();
		return 0;
	}	
	for (int i=1;i<=n;i++) c[i].x=read(),c[i].y=read();
	sort(c+1,c+n+1,cmp);
	int ans=2e9;
	int X,Y;
	for (int i=1;i<=m;i++)
	{
		X=read();Y=read();
		add(X,Y);add(Y,X);
	}
	for (int i=1;i<=n;i++)
	{
		for (int j=1;j<=n;j++) fa[j]=j,sz[j]=1;
		memset(Vis,0,sizeof(Vis));
		Vis[i]=1;
		for (int j=1;j<=n;j++)
		{
			if (j==i) continue;
			if (c[j].x>c[i].x) continue;
			if (c[i].x+c[j].y>ans) break;
			Vis[j]=1;
			for (int l=po[j];l;l=ne[l])
			{
				if (!Vis[to[l]]) continue;
				X=gf(to[l]),Y=gf(j);
				fa[X]=Y;sz[Y]+=sz[X];sz[X]=0;
				break;
			}
			if (sz[gf(j)]>=k)
			{
				qmin(ans,c[i].x+c[j].y);
				break;
			}
		}
	}
	if (ans==(int)2e9) printf("no solution"); else 
	printf("%lld\n",ans);
	return 0;
}
