#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const ll mod=998244353;
ll ksm(ll x,int y,ll Mod)
{
	ll sum=1;
	x%=Mod;
	while (y)
	{
		if (y&1) sum=sum*x%Mod;
		x=x*x%Mod;
		y>>=1;
	}
	return sum;
}
int n,m,X,Y;
ll ny,Z;
ll f[15][15];
int to[100],ne[100],po[100],id;
void add(int x,int y)
{
	id++;
	to[id]=y;ne[id]=po[x];po[x]=id;
}
//for (int i=1;i<=n;i++) for (int j=i+1;j<=n;j++)
int dfn[15],low[15],dfs_time,scc[15],sccid;
stack<int> S;
void tarjan(int x,int fa)
{
	dfn[x]=low[x]=++dfs_time;
	S.push(x);
	for (int i=po[x];i;i=ne[i])
	{
		if (dfn[to[i]]==0)
		{
			tarjan(to[i],x);
			qmin(low[x],low[to[i]]);
		} else
		if (scc[to[i]]==0) qmin(low[x],dfn[to[i]]);
	}
	if (low[x]==dfn[x])
	{
		sccid++;
		while (S.top()!=x)
		{
			scc[S.top()]=sccid;
			S.pop();
		}
		scc[S.top()]=sccid;S.pop();
	}
}
int check()
{
	dfs_time=0;sccid=0;
	for (int i=0;i<=n;i++) dfn[i]=low[i]=0,scc[i]=0;
	while (!S.empty()) S.pop();
	for (int i=1;i<=n;i++)
	{
		if (dfn[i]==0)
		{
			tarjan(i,0);
		}
	}
	return sccid;
}
int main()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	n=read();m=read();
	memset(f,-1,sizeof(f));
	ny=ksm(10000,(int)mod-2,mod);
	for (int i=1;i<=m;i++)
	{
		X=read();Y=read();Z=read();
		f[X][Y]=Z*ny%mod;
		f[Y][X]=(ll)(10000-Z)*ny%mod;
	}
	m=n*(n-1)/2;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
		if (f[i][j]==-1) f[i][j]=(ll)5000*ny%mod;
	ll ans=0;
	for (int x=0;x<(1<<m);x++)
	{
		int d=-1;
		ll s=1;
		id=0;
		memset(po,0,sizeof(po));
		for (int i=1;i<=n;i++)
			for (int j=i+1;j<=n;j++)
			{
				d++;
				if (x&(1<<d)) 
				{
					s=s*f[i][j]%mod;
					add(i,j);
				} else 
				{
					s=s*f[j][i]%mod;
					add(j,i);
				}
			}
		ans+=s*check()%mod;	
		ans%=mod;
	}
	ll n1=n*(n-1)%(mod-1);
	n1=ksm(10000,n1,mod);
	ans=ans*n1%mod;
	printf("%lld\n",ans);
	return 0;
}
