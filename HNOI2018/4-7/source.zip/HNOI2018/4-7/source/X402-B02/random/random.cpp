#include<bits/stdc++.h>
#define mo mod
#define ll long long
const int N=1e5+10;
const int mod=998244353;
using namespace std;

int n,m,e,tim,ti;
int bgn[N],to[N],low[N],nxt[N],pre[N],sccno[N];
stack<int> s;

namespace rd{
	struct node {
		int x,y,z;
		node(int x=0,int y=0,int z=0):x(x),y(y),z(z){}
	};
	struct node p[N];
	inline ll fpm(ll x,ll y){
		ll s=1;
		while(y){
			if(y&1) s=s*x%mo;
			y>>=1; x=x*x%mo;
		}
		return s;
	}
	inline void add(int x,int y){
		to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e;
	}
	inline ll rev(ll x){
		return fpm(x,mo-2);
	}

	void dfs(int x){
		s.push(x);
		low[x]=pre[x]=++ti;
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(!low[y]) dfs(y),low[x]=min(low[x],low[y]);
				else if(!sccno[y]) low[x]=min(low[x],pre[y]);
		}
		if(low[x]==pre[x]){
			++tim;
			sccno[x]=tim;
			while(s.top()!=x){
				sccno[s.top()]=tim;
				s.pop();
			}
			s.pop();
		}
	}

	void solve(){
		scanf("%d%d",&n,&m);
		int x=0,y=0,z=0;
		for(int i=1; i<=m; ++i){
			scanf("%d%d%d",&x,&y,&z);
			p[i]=node(x,y,z);
		}

		int cc=n*(n-1)/2-m;

		long long ret=fpm(10000,n*(n-1)),gg=0,ans=0;

		for(int i=0;i<(1<<m);++i){
			ti=0;
			for(int j=1;j<=n;++j) bgn[j]=0,low[j]=0,pre[j]=0,sccno[j]=0;
			tim=0; e=0; gg=1;
			for(int j=0;j<m;++j) if((1<<j)&i){
				add(p[j+1].x,p[j+1].y);
				gg=gg*p[j+1].z%mo*rev(10000)%mo;
			}

			else{
				add(p[j+1].y,p[j+1].x);
				gg=gg*(10000-p[j+1].z)%mo*rev(10000)%mo;
			}
		
			for(int j=1;j<=cc;++j) gg=gg*1ll*5000%mo*rev(10000)%mo;
			for(int j=1;j<=n;++j) if(!low[j]) dfs(j);
			ans+=1ll*tim*ret%mo*gg%mo;
			ans%=mo;
		}
		printf("%lld\n",ans);
	}
}

int main(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	rd::solve();
}
