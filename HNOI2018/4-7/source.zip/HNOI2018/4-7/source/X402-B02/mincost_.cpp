#include<bits/stdc++.h>
#define mk make_pair
#define pii pair<int,int>
#define x first
#define pb push_back
#define y second
#define f fa
#define getchar getchar_unlocked
const int N=1e5+10;
const int E=5e3+10;
using namespace std;
int vis[N],idx;
int fa[N],cnt=0,n,m,k,szz,mxsz;
int sz[N],a[N],b[N],id[N],e,re[N],c[N],d[N];
int bgn[N],to[N],nxt[N],ans=0x3f3f3f3f;
pii va[N],vb[N];
bool g[E][E];

namespace mc{
	inline int read(){
		char ch=getchar(); int x=0;
		while(ch>'9'||ch<'0')ch=getchar();
		while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
		return x;
	}
	void add(int x,int y){
		to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e;
	}
	void dfs(int x){
		if(vis[x]==idx)return; vis[x]=idx; 
		id[++cnt]=x; re[x]=cnt;
		for(int i=bgn[x]; i; i=nxt[i]) dfs(to[i]);
	}
	void gfs(int x){
		if(vis[x]==idx) return; vis[x]=idx; ++szz;
		for(int i=1;i<=cnt;++i) if(g[x][i]) gfs(i);
	}
	int mx(){
		++idx; mxsz=0;
		for(int i=1;i<=cnt;++i){
			szz=0; gfs(i); mxsz=max(mxsz,szz);
		}
		return mxsz;
	}
	void work(int x){
		cnt=0;dfs(x);
		for(int i=1;i<=cnt;++i)fa[i]=i,sz[i]=0,c[i]=a[id[i]],d[i]=b[id[i]];
		for(int i=1;i<=cnt;++i)va[i]=mk(c[i],i);
		for(int i=1;i<=cnt;++i)vb[i]=mk(d[i],i);
		sort(va+1,va+cnt+1);
		sort(vb+1,vb+cnt+1);
		int p=cnt;
		for(int i=1;i<=cnt;++i){
			int ni=i;
			while(va[i].x==va[ni].x&&ni<=cnt) ++ni;--ni;
			for(int j=i;j<=ni;++j){
				for(int k=bgn[id[j]]; k; k=nxt[k]){	
					if(a[re[to[k]]]<=va[i].x){
						g[j][re[to[k]]]=1;
						g[re[to[k]]][j]=1;
					}
				}
			}
			while(p&&mx()>=k){
				ans=min(ans,va[i].x+vb[p].x);
				for(int j=1;j<=cnt;++j) g[j][p]=g[p][j]=0;
				--p;
			}
			i=ni;
		}
	}
	void solve(){
		n=read(); m=read(); k=read();
		int x=0,y=0;
		for(int i=1; i<=n; ++i){
			a[i]=read(); b[i]=read();
		}
		for(int i=1; i<=m; ++i){
			x=read(); y=read();
			add(x,y); add(y,x);
		}
		for(int i=1; i<=n; ++i) if(!vis[i]) ++idx,work(i);
		if(ans==0x3f3f3f3f) puts("no solution"); else printf("%d\n",ans);
	}
}

int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	mc :: solve();	
}
