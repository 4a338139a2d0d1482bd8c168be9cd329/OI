#include<bits/stdc++.h>
using namespace std;
const int N=1e3+10;

double ans;
int n;

struct node{
	int x,y;
	node(int x=0,int y=0):x(x),y(y){}
};
double spr(double x){return x*x;};
struct node p[N],q[N];

int main(){
	freopen("geometry.in", "r", stdin);
	freopen("geometry.out", "w", stdout);
	scanf("%d",&n);
	
	if(n==1){
		for(int i=1;i<=n;++i){
			scanf("%d%d",&p[i].x,&p[i].y);
		}
		for(int i=1;i<=n;++i){
			scanf("%d%d",&q[i].x,&q[i].y);
		}
		printf("%.2lf\n",sqrt(spr(p[1].x-q[1].x)+spr(p[1].y-q[1].y)));
	}

}
