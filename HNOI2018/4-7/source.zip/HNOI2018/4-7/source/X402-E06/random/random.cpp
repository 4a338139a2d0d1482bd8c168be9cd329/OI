#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 40;
const int mo = 998244353;

int fpm(int x, int y) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1)
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

const int inv2 = (mo + 1) >> 1;
const int inv = fpm(10000, mo - 2);

struct edge { int u, v, w; };

int n, m;
edge e[N + 5];
vector<int> G[N + 5], V;

int pw[N * N + 5] = {1};
int vis[N + 5], id[N + 5], scnt = 0;
int f[N + 5][N + 5], g[N + 5][N + 5];

void dfs(int u) {
    vis[u] = scnt;
    id[u] = V.size(); V.pb(u);

    for(int i = 0; i < (int) G[u].size(); ++i) {
        int v = G[u][i];
        if(!vis[v]) dfs(v);
    }
}

void calc() {
    int all = 1 << (int) V.size();
    for(int s = 0; s < all; ++ s) {
        int res = 1;
        for(int i = 1; i <= m; ++i) {
            int u = e[i].u, v = e[i].v;

            if(vis[u] != scnt) continue;
            if((s >> id[u] & 1) != (s >> id[v] & 1)) {
                res = ll(res << 1) * ((s >> id[u] & 1) ? e[i].w : (1 - e[i].w + mo)) % mo;
            }
        }
        (g[scnt][__builtin_popcount(s)] += res) %= mo;
    }
}

int main() {
    freopen("random.in", "r", stdin);
    freopen("random.out", "w", stdout);
    
    read(n), read(m);
    for(int i = 1; i <= n * n; ++i) pw[i] = 1ll * pw[i-1] * inv2 % mo;
    for(int i = 1; i <= m; ++i) {
        read(e[i].u);
        read(e[i].v);
        read(e[i].w), e[i].w = 1ll * e[i].w * inv % mo;

        G[e[i].u].pb(e[i].v), G[e[i].v].pb(e[i].u);
    }

    for(int i = 1; i <= n; ++i) if(!vis[i]) {
        ++ scnt;
        V.clear(); dfs(i); calc();
    }

    f[0][0] = 1;
    for(int i = 1; i <= scnt; ++i) {
        for(int j = 0; j <= n; ++j) {
            for(int k = 0; k <= j; ++k) {
                f[i][j] = (f[i][j] + 1ll * f[i-1][j - k] * g[i][k]) % mo;
            }
        }
    }

    int ans = 0;
    for(int i = 1; i <= n; ++i) {
        ans = (ans + 1ll * f[scnt][i] * pw[i * (n - i)]) % mo;
    }

    ans = 1ll * ans * fpm(10000, n * (n - 1)) % mo; 
    printf("%d\n", ans);

    return 0;
}
