#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 300000;

int n, m, k;
vector<int> G[N + 5];
int a[N + 5], b[N + 5], id[N + 5];

bool cmp(const int& x, const int& y) {
    return a[x] < a[y];
}

bool mark[N + 5];
int fa[N + 5], sz[N + 5];

int find(int x) {
    return (fa[x] == x) ? x : fa[x] = find(fa[x]);
}

vector<pii> vec;
int solve(int x) {
    vec.pb(mp(b[x], x));
    std::sort(vec.begin(), vec.end());

    for(int i = 1; i <= n; ++i) fa[i] = i, sz[i] = 1, mark[i] = 0;
    for(int i = 0; i < (int) vec.size(); ++i) {
        int u = vec[i].snd, tu = find(u);
        mark[u] = true;
        for(int j = 0; j < (int) G[u].size(); ++j) {
            int v = G[u][j];

            if(mark[v]) {
                v = find(v);

                if(v != tu) {
                    fa[v] = tu;
                    if((sz[tu] += sz[v]) >= k) return vec[i].fst;
                }
            }
        }
    }
    return INT_MAX;
}

int main() {
    freopen("mincost.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n), read(m), read(k);
    for(int i = 1; i <= n; ++i) {
        read(a[i]), read(b[i]), id[i] = i;
    }
    for(int i = 1; i <= m; ++i) {
        static int u, v;
        read(u), read(v);
        G[u].pb(v), G[v].pb(u);
    }
    std::sort(id + 1, id + n + 1, cmp);

    ll ans = INT_MAX;
    for(int i = 1; i <= n; ++i) {
        chkmin(ans, (ll) a[id[i]] + solve(id[i]));
    }

    if(ans == INT_MAX) {
        puts("no solution");
    } else {
        printf("%lld\n", ans);
    }

    return 0;
}
