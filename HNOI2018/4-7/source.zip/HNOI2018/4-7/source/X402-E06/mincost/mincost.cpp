#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 300000;

int n, m, k;
vector<int> G[N + 5];

namespace SEG {

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    const int SZ = N << 2;

    bool mark[N + 5];
    int fa[N + 5], sz[N + 5];

    int find(int x) {
        return (x == fa[x]) ? x : find(fa[x]); 
    }

    vector<pii> stk;
    bool merge(int u, int v) {
        u = find(u), v = find(v);
        if(u == v) return false;
        if(sz[u] > sz[v]) std::swap(u, v);

        fa[u] = v;
        sz[v] += sz[u];
        stk.pb(mp(u, v));

        return true;
    }

    void back() {
        int u = stk.back().fst;
        int v = stk.back().snd; 
        stk.pop_back();

        fa[u] = u;
        sz[v] -= sz[u];
    }

    vector<int> V[SZ + 5];

    void modify(int u, int l, int r, int x, int y, int v) {
        if(x <= l && r <= y) { V[u].pb(v); return; }

        if(x <= mid) 
            modify(lc, l, mid, x, y, v);
        if(mid < y) 
            modify(rc, mid+1, r, x, y, v);
    }

    bool dfs(int u, int l, int r) {

        int tot = 0;
        for(int i = 0; i < (int) V[u].size(); ++i) {
            int v = V[u][i]; mark[v] = true;

            for(int j = 0; j < (int) G[v].size(); ++j) {
                int w = G[v][j]; 

                if(mark[w]) {
                    tot += merge(w, v);
                    if(sz[find(v)] >= k) return true;
                }
            }
        }

        if(l != r && (dfs(lc, l, mid) || dfs(rc, mid + 1, r))) return true; 

        while(tot--) back();
        for(int i = 0; i < (int) V[u].size(); ++i) {
            int v = V[u][i]; 
            mark[v] = false;
        } 
        return false;
    }

    void clear() {
        stk.clear();
        for(int i = 1; i < SZ; ++i) V[i].clear();
        for(int i = 1; i <= n; ++i) fa[i] = i, sz[i] = 1, mark[i] = 0;
    }

    bool chk() { return dfs(1, 1, n); }
#undef mid
}

struct node {
    int a, b, u;

    bool operator < (const node& rhs) const {
        return a < rhs.a;
    }
};

node t[N + 5];
int a[N + 5], b[N + 5];

bool chk(int mid) {
    SEG::clear();
    for(int i = 1; i <= n; ++i) {
        int ed = std::upper_bound(t + 1, t + n + 1, (node) { mid - t[i].b, -oo, 0}) - t - 1; 
        if(i <= ed) SEG::modify(1, 1, n, i, ed, t[i].u);
    }
    return SEG::chk();
}

int main() {
    freopen("mincost.in", "r", stdin);
    freopen("mincost.out", "w", stdout);

    read(n), read(m), read(k);
    for(int i = 1; i <= n; ++i) read(a[i]), read(b[i]), t[i] = (node) { a[i], b[i], i };
    for(int i = 1; i <= m; ++i) {
        static int u, v;
        read(u), read(v);
        G[u].pb(v), G[v].pb(u);
    }
    std::sort(t + 1, t + n + 1);

    int l = 0, r = INT_MAX;
    while(l < r) {
        int mid = l + ((r-l) >> 1);
        if(chk(mid)) r = mid; else l = mid + 1;
    }

    if(l == INT_MAX) {
        puts("no solution");
    } else {
        printf("%d\n", l);
    }

    return 0;
}
