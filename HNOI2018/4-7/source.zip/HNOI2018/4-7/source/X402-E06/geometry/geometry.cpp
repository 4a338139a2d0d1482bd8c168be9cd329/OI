#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 2000;

struct Point {
    ll x, y;

    Point() { }
    Point(ll _x, ll _y): x(_x), y(_y) { } 
};

Point P[N + 5];
double dis(const Point& a, const Point& b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

ll cross(const Point& a, const Point& b) { 
    return a.x * b.y - a.y * b.x;
}

Point operator + (const Point& a, const Point& b) { return Point(a.x + b.x, a.y + b.y); }
Point operator - (const Point& a, const Point& b) { return Point(a.x - b.x, a.y - b.y); }

int n;
bool chk(int x, int y) {
    if(P[x].x == P[y].x) return true;
    if(P[x].x < P[y].x) {
        return (x == n || cross(P[y] - P[x], P[x + 1] - P[x]) > 0) && (y == n + 1 || cross(P[x] - P[y], P[y - 1] - P[y]) > 0);
    } else {
        return (x == 1 || cross(P[x - 1] - P[x], P[y] - P[x]) > 0) && (y == 2 * n || cross(P[y + 1] - P[y], P[x] - P[y]) > 0);
    }
}

bool vis[N + 5];
double ans = DBL_MAX;
 
void go(int u, double dist, int lst) {
    if(dist >= ans) return;
    if(u == n*2) {
        chkmin(ans, dist);
        return;
    }

    if(u & 1) {
        int v = -1;
        for(int i = n + 1; i <= 2 * n; ++i) if(!vis[i] && chk(lst, i)) {
            if(v == -1 || dis(P[lst], P[i]) < dis(P[lst], P[v])) {
                v = i;
            }
        }
        if(v == -1) return;
        vis[v] = true;
        go(u + 1, dist + dis(P[v], P[lst]), v);
        vis[v] = false;
    } else {
        int v = -1;
        for(int i = 1; i <= n; ++i) if(!vis[i] && chk(i, lst)) {
            if(v == -1 || dis(P[lst], P[i]) < dis(P[lst], P[v])) {
                v = i;
            }
        }
        if(v == -1) return;
        vis[v] = true;
        go(u + 1, dist + dis(P[v], P[lst]), v);
        vis[v] = false;
    }
}
 
void dfs(int u, double dist, int lst = 0) {
    if(dist >= ans) return;
    if(u == n * 2) {
        chkmin(ans, dist);
        return;
    }

    if(u & 1) {
        for(int i = 1; i <= n; ++i) if(!vis[i] && (lst ? chk(i, lst) : 1)) {
            vis[i] = true;
            dfs(u + 1, dist + (lst ? dis(P[i], P[lst]) : 0), i);
            vis[i] = false;
        }
    } else {
        for(int i = n + 1; i <= 2 * n; ++i) if(!vis[i] && (lst ? chk(lst, i) : 1)) {
            vis[i] = true;
            dfs(u + 1, dist + (lst ? dis(P[i], P[lst]) : 0), i);
            vis[i] = false;
        }
    }
}

int main() {
    freopen("geometry.in", "r", stdin);
    freopen("geometry.out", "w", stdout);

    read(n); 
    for(int i = 1; i <= 2 * n; ++i) read(P[i].x), read(P[i].y);

    if(n <= 10) {
        dfs(0, 0.0);
        printf("%.10lf\n", ans == DBL_MAX ? -1.0 : ans);
    } else {
        for(int i = 1; i <= n; ++i) vis[i] = true, go(1, 0.0, i), vis[i] = false;
        printf("%.10lf\n", ans == DBL_MAX ? -1.0 : ans);
    }

    return 0;
}
