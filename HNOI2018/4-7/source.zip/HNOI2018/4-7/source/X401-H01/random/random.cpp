#include<iostream>
#include<cstdio>
#include<cstring>
#define in(x,S) (((S)>>(x-1))&1)
#define up(x,y) x=(x+(y))%mod
#define ll long long
using namespace std;
const int mod=998244353; 
int n,m;
ll f[33000],g[33000],h[33000],mp[40][40],I1e4;
ll ksm(ll a,int b){ll r=1;for(;b;b>>=1){if(b&1)r=r*a%mod;a=a*a%mod;}return r;}
ll cal_P(ll S,ll T)
{
	ll P=1;
	for(int i=1;i<=n;i++)
		if(in(i,S))
			for(int j=1;j<=n;j++)
				if(in(j,T)) P=P*mp[i][j]%mod;
	//cout<<"in:"<<S<<' '<<T<<' '<<P*10000%mod<<endl;			
	return P;			
}
int main()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	I1e4=ksm(10000,mod-2);
//	cout<<49*ksm(32,mod-2)%mod<<endl;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			mp[i][j]=5000;
	for(int i=1;i<=m;i++)
	{
		int x,y,w;
		scanf("%d%d%d",&x,&y,&w);
		mp[x][y]=w;
	}
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			mp[i][j]=mp[i][j]*I1e4%mod,mp[j][i]=(1-mp[i][j]+mod)%mod;
//	for(int i=1;i<=n;i++,puts(""))
//		for(int j=1;j<=n;j++)
//			cout<<mp[i][j]*10000%mod<<' ';		
	f[0]=1;
	for(int s=1;s<(1<<n);s++)
	{
		f[s]=1;
		for(int t=(s-1)&s;t;t=(t-1)&s)
			up(f[s],mod-f[t]*cal_P(t,s^t)%mod);
		//cout<<"f:"<<s<<' '<<f[s]*10000%mod<<endl;
	}
	g[0]=0;
	for(int s=1;s<(1<<n);s++)
	{
		for(int t=s;t;t=(t-1)&s)
			up(g[s],f[t]*(g[s^t]+1)%mod*cal_P(t,s^t));//cout<<"up:"<<s<<' '<<t<<' '<<f[t]*10000%mod<<' '<<cal_P(t,s^t)*10000%mod<<endl;
		//cout<<"g:"<<s<<' '<<g[s]*10000%mod<<endl;			
	}
	//cout<<g[(1<<n)-1]%mod<<endl;
	ll ans=g[(1<<n)-1]*ksm(10000,n*(n-1))%mod;		
	printf("%lld",ans);
	return 0;
}
/*2 1
1 2 4096

3 3
1 2 4000
2 3 6000
1 3 3000

6 15
1 2 10000
1 3 0
1 4 10000
1 5 10000
1 6 10000
2 3 10000
2 4 10000
2 5 10000
2 6 10000
3 4 10000
3 5 10000
3 6 10000
4 5 10000
4 6 0
5 6 10000

4 0

4 4
1 2 4194
1 3 9971
2 4 7191
1 4 1102*/
