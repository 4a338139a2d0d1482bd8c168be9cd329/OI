#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 300010
using namespace std;
int n,m,K,a[N],b[N],z[N],fa[N],sz[N],ans;
int read()
{
	int x=0,f=1;char ch=getchar();
	for(;ch<'0'||ch>'9';ch=getchar()) if(ch=='-') f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}
struct edge
{
	int t;
	edge *next;
}*con[N];
bool cmp(int x,int y)
{
	return b[x]<b[y];
}
void ins(int x,int y)
{
	edge *p=new edge;
	p->t=y;
	p->next=con[x];
	con[x]=p;
}
int getfa(int v)
{
	if(fa[v]==v) return v;
	return (fa[v]=getfa(fa[v]));
} 
int check(int d)
{
	for(int i=1;i<=n;i++)
		fa[i]=i,sz[i]=1;	
	for(int i=1;i<=n;i++)
		if(a[z[i]]<=d)
			for(edge *p=con[z[i]];p;p=p->next)
				if(a[p->t]<=d&&b[p->t]<=b[z[i]]&&getfa(z[i])!=getfa(p->t))
					{
						sz[fa[z[i]]]+=sz[fa[p->t]];
						//cout<<"add:"<<fa[z[i]]<<' '<<sz[fa[p->t]]<<' '<<z[i]<<' '<<p->t<<endl;
						fa[fa[p->t]]=fa[z[i]];
						if(sz[fa[z[i]]]>=K) {return b[z[i]]+d;}
					}
	return 2e9;				
}
int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	n=read();m=read();K=read();
	for(int i=1;i<=n;i++)
		a[i]=read(),b[i]=read(),z[i]=i;
	sort(z+1,z+n+1,cmp);
//	for(int i=1;i<=n;i++)
//		cout<<z[i]<<' ';
//	puts("");	
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
		ins(x,y);
		ins(y,x);
	}
	ans=2e9;
	for(int i=1;i<=n;i++)
		ans=min(ans,check(a[i]));
	printf("%d",ans);	
	return 0;
}
/*5 7 3
1 2
2 1
2 2
1 1
1 2
1 3
4 5
2 3
5 1
4 2
1 4
3 4*/
