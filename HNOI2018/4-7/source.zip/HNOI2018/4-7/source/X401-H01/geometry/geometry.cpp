#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n;
struct pt
{
	double x,y;
}a[1010],b[1010];
double ans;
double dis(int p,int q)
{
	return sqrt((a[p].x-b[q].x)*(a[p].x-b[q].x)+(a[p].y-b[q].y)*(a[p].y-b[q].y));
}
int main()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&a[i].x,&a[i].y);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&b[i].x,&b[i].y);
	double cal1=0,cal2=0;
	for(int i=1;i<n;i++)
		cal1+=dis(i,i)+dis(i,i+1);
	cal1+=dis(n,n);
	for(int i=1;i<n;i++)
		cal2+=dis(i,i)+dis(i+1,i);
	cal2+=dis(n,n);
	printf("%.12lf",min(cal1,cal2));			
	return 0;
}
/*3
0 2
1 1
2 2
0 -2
1 -1
2 -2

2 
-2 2
1 5
-2 2
-1 -4

3 
-2 1
1 2
2 6
-3 -1
-2 -1
-1 -2*/
