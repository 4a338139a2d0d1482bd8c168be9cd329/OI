#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=2010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
}
int n,G[N][N],vis[N];
double ans,dis[N][N];
struct node
{
	LL x,y;
	node(){}
	node(LL x,LL y):x(x),y(y){}
}a[N],b[N];
inline node operator-(const node&A,const node&B){return node(A.x-B.x,A.y-B.y);}
inline LL Cross(const node&A,const node&B){return A.x*B.y-A.y*B.x;}
inline int sgn(LL x){return x>0?1:x==0?0:-1;}
inline bool check(node X1,node Y1,node X2,node Y2)
{
	return sgn(Cross(Y2-X1,Y1-X1))*sgn(Cross(Y1-X1,X2-X1))>0
		 &&sgn(Cross(Y1-X2,Y2-X2))*sgn(Cross(Y2-X2,X1-X2))>0;
}
inline double Get_dis(int x,int y)
{
	return sqrt(1.0*(a[x].x-b[y].x)*(a[x].x-b[y].x)+
				1.0*(a[x].y-b[y].y)*(a[x].y-b[y].y));
}
inline void dfs(int u,double sum,int cnt)
{
	if(cnt==n<<1)
	{
		if(ans<0.0)ans=sum;
		else chkmin(ans,sum);
		return;
	}
	For(v,1,n*2)
	if(G[u][v]&&!vis[v])
	{
		vis[v]=1;
		dfs(v,sum+dis[u][v],cnt+1);
		vis[v]=0;
	}
}
int main()
{
	int x,y;
	file();
	read(n);
	For(i,1,n)read(x),read(y),a[i]=node(x,y);
	a[0]=node(a[1].x,inf);
	a[n+1]=node(a[n].x,inf);
	For(i,1,n)read(x),read(y),b[i]=node(x,y);
	b[0]=node(b[1].x,-inf);
	b[n+1]=node(b[n].x,-inf);
	For(i,1,n)For(j,1,n)
	{
		int flag=1;
		For(k,0,n)if(check(a[i],b[j],a[k],a[k+1]))flag=0;
		For(k,0,n)if(check(a[i],b[j],b[k],b[k+1]))flag=0;
		if(flag==1)
		{
			G[i][j+n]=G[j+n][i]=1;
			dis[i][j+n]=dis[j+n][i]=Get_dis(i,j);
		}
	}
	ans=-1.0;
	For(i,1,n<<1)
	{
		vis[i]=1;
		dfs(i,0.0,1);
		vis[i]=0;
	}
	printf("%.10lf\n",ans);
	return 0;
}
