#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ft first
#define sd second
#define ALL(x) x.begin(),x.end()
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=300010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
}
int n,m,K,ans,Max;
int fa[N],sz[N],vis[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
vector<pii>G;
struct node
{
	int x,y,id;
	node(){}
	node(int x,int y,int id):x(x),y(y),id(id){}
}a[N];
inline bool operator<(const node&A,const node&B){return A.y<B.y;}
inline bool cmp(const node&A,const node&B){return A.x<B.x;}
inline int find(int x){return fa[x]==x?x:fa[x]=find(fa[x]);}
inline void Combine(int x,int y)
{
	if((x=find(x))!=(y=find(y))){fa[x]=y;sz[y]+=sz[x];chkmax(Max,sz[y]);}
}
inline void Add(int u)
{
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if(!vis[v=to[i]])continue;
		Combine(u,v);
	}
}
inline void Solve(int p)
{
	Max=1;
	For(i,0,SZ(G)-1)
	{
		int u=G[i].sd;
		vis[u]=1;fa[u]=u;sz[u]=1;Add(u);
		if(Max>=K){chkmin(ans,a[p].x+G[i].ft);break;}
	}
	For(i,1,p)vis[G[i].sd]=0;
	return;
}
int main()
{
	int x,y;
	file();
	read(n),read(m),read(K);
	For(i,1,n)read(x),read(y),a[i]=node(x,y,i);
	For(i,1,m)read(x),read(y),add_edge(x,y),add_edge(y,x);
	ans=inf<<1;
	sort(a+1,a+n+1,cmp);
	For(i,1,n)
	{
		pii now=pii(a[i].y,a[i].id);
		G.insert(lower_bound(ALL(G),now),now);
		Solve(i);
	}
	if(ans==inf<<1)puts("no solution");
	else printf("%d\n",ans);
	return 0;
}
