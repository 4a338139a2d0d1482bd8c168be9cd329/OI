#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define inv(x) qpow(x,mod-2)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=40;
const int inf=0x3f3f3f3f;
const LL mod=998244353;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
}
int n,m;
LL G[N][N],d[20][1<<20];
LL f[1<<20],g[1<<20],C[N][N];
inline void Add(LL&x,LL y){x=x+y<mod?x+y:x+y-mod;}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline LL Get(int x,int y)
{
	LL ret=1;
	For(i,1,n)if(x&(1<<(i-1)))ret=ret*d[i][y]%mod;
	//printf("%d %d:%lld\n",x,y,ret);
	return ret;
}
inline void init()
{
	For(i,1,n)
	For(x,1,(1<<n)-1)
	{
		d[i][x]=1;
		For(j,1,n)
			if(x&(1<<(j-1)))
				d[i][x]=d[i][x]*G[i][j]%mod;
	}
}
inline void Solve()
{
	init();
	For(x,1,(1<<n)-1)
	{
		f[x]=1;g[x]=0;
		for(int y=(x-1)&x;y;y=(y-1)&x)
		{
			LL ret=f[y]*Get(y,x^y)%mod;
			Add(f[x],mod-ret);
			Add(g[x],ret*(g[x^y]+1)%mod);
		}
		Add(g[x],f[x]);
		//printf("%d: f:%lld g:%lld\n",x,f[x],g[x]);
	}
	printf("%lld\n",g[(1<<n)-1]*qpow(10000,n*(n-1))%mod);
}
inline void Solve1()
{
	C[0][0]=1;
	For(i,1,n)For(j,0,i)Add(C[i][j]=C[i-1][j],(j?C[i-1][j-1]:0));
	For(i,1,n)
	{
		f[i]=1;
		For(j,1,i-1)
		{
			LL ret=C[i][j]*f[j]%mod*qpow(inv(2),j*(i-j))%mod;
			Add(f[i],mod-ret);
			Add(g[i],ret*(g[i-j]+1)%mod);
		}
		Add(g[i],f[i]);
		//printf("%d: f:%lld g:%lld\n",i,f[i],g[i]);
	}
	printf("%lld\n",g[n]*qpow(10000,n*(n-1))%mod);
}
int main()
{
	int x,y,z;
	file();
	read(n),read(m);
	For(i,1,n)For(j,1,n)if(i^j)G[i][j]=inv(2);
	LL Inv=inv(10000);
	For(i,1,m)
	{
		read(x),read(y),read(z);
		G[x][y]=z*Inv%mod;
		G[y][x]=(10000-z)*Inv%mod;
	}
	if(m==0)Solve1();
	else Solve();
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
