#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=300005;
int n,m,lim;
vector<int>E[maxn];
int fa[maxn],sz[maxn],Min[maxn];
bool vis[maxn];
int find_fa(int x){
	return x==fa[x]?x:fa[x]=find_fa(fa[x]);
}
bool merge(int x,int y){
	x=find_fa(x),y=find_fa(y);
	if(x==y)return 0;
	fa[y]=x;
	chkmax(Min[x],Min[y]);
	return (sz[x]+=sz[y])>=lim;
}
struct data{
	int a,b,id;
}p[maxn],q[maxn];
bool cmpa(const data &A,const data &B){
	return A.a<B.a;
}
bool cmpb(const data &A,const data &B){
	return A.b<B.b;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
#endif
	n=read(),m=read(),lim=read();
	REP(i,1,n)p[i]=(data){read(),read(),i};
	REP(i,1,m){
		int u=read(),v=read();
		E[u].pb(v),E[v].pb(u);
	}
	sort(p+1,p+1+n,cmpa);
	int ans=2e9;
	if(n<=5000){
		REP(i,1,n){
			REP(j,1,i)q[j]=p[j];
			REP(j,1,i)fa[q[j].id]=q[j].id,sz[q[j].id]=1,vis[q[j].id]=0;
			sort(q+1,q+1+i,cmpb);
			REP(j,1,i){
				REP(k,0,E[q[j].id].size()-1)
					if(vis[E[q[j].id][k]])if(merge(q[j].id,E[q[j].id][k]))chkmin(ans,p[i].a+q[j].b);
				vis[q[j].id]=1;
			}
		}
		write(ans,'\n');
	}else{
		srand(time(0));
		while(1.0*clock()<=(3-(m==n-1))*CLOCKS_PER_SEC-200000){
			int i=rand()%n+1;
			REP(j,1,i)q[j]=p[j];
			sort(q+1,q+1+i,cmpb);
			REP(j,1,n)fa[j]=j,sz[j]=1,vis[j]=0,Min[q[j].id]=q[j].a;
			int Mincost=0;
			REP(j,1,i){
				chkmax(Mincost,q[j].a);
				REP(k,0,E[q[j].id].size()-1)
					if(vis[E[q[j].id][k]])if(merge(q[j].id,E[q[j].id][k]))chkmin(ans,Min[find_fa(q[j].id)]+q[j].b);
				vis[q[j].id]=1;
			}
		}
		write(ans,'\n');
	}
	return 0;
}
