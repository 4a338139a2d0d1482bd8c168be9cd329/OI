#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=40,mod=998244353;
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1ll*res*x%mod;
		x=1ll*x*x%mod,y>>=1;
	}return res;
}
int n,m,all,p[maxn][maxn],f[1<<15];
int p1[1<<15][maxn],p2[1<<15][maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n)
		REP(j,1,n)
			p[i][j]=(mod+1)/2;
	int inv=ksm(10000,mod-2);
	REP(i,1,m){
		int u=read(),v=read();
		p[u][v]=1ll*read()*inv%mod;
		p[v][u]=(mod+1-p[u][v])%mod;
	}
	all=(1<<n)-1;
	REP(i,0,all)
		REP(j,1,n){
			if(i&(1<<j-1))continue;
			p1[i][j]=p2[i][j]=1;
			REP(k,1,n)if(i&(1<<k-1))p1[i][j]=1ll*p1[i][j]*p[j][k]%mod,p2[i][j]=1ll*p2[i][j]*p[k][j]%mod;
		}
	REP(i,1,all){
		f[i]=1;
		for(int j=(i-1)&i;j;j=(j-1)&i){
			int t=1;
			REP(k,1,n)if(j&(1<<k-1))t=1ll*t*p1[i^j][k]%mod;
			(f[i]+=mod-1ll*f[j]*t%mod)%=mod;
		}
	}
	int ans=0;
	REP(i,0,all){
		if(!f[i])continue;
		int s=i^all,sum=0;
		for(int j=s;;j=(j-1)&s){
			int t=1;
			REP(k,1,n)if(i&(1<<k-1))t=1ll*t*p1[s^j][k]%mod;
			REP(k,1,n)if(j&(1<<k-1))t=1ll*t*p1[i][k]%mod*p1[s^j][k]%mod;
			(sum+=t)%=mod;
			if(j==0)break;
		}
		(ans+=1ll*f[i]*sum%mod)%=mod;
	}
	REP(i,1,n*(n-1))ans=10000ll*ans%mod;
	write(ans,'\n');
	return 0;
}
