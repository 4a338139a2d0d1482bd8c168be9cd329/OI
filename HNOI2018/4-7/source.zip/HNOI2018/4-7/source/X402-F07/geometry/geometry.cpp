#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=25;
int n,all;
struct point{
	ll x,y;
	point operator - (const point &A) const {
		return (point){x-A.x,y-A.y};
	}
}p[maxn];
ll cross(const point &A,const point &B){
	return A.x*B.y-A.y*B.x;
}
lf dis(const point &A,const point &B){
	return sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y));
}
lf dp[1<<20][maxn];
bool pd[maxn][maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
#endif
	n=read();
	REP(i,1,2*n)
		p[i].x=read(),p[i].y=read();
	REP(i,1,2*n)
		REP(j,1,2*n){
			if((i<=n)==(j<=n))continue;
			pd[i][j]=1;
			REP(l,1,2*n-1){
				if(l==n)continue;
				bool tmp=0;
				ll k1=cross(p[l+1]-p[l],p[i]-p[l]),k2=cross(p[l+1]-p[l],p[j]-p[l]);
				tmp|=(((k1>=0)&&(k2>=0))||((k1<=0)&&(k2<=0)));
				k1=cross(p[j]-p[i],p[l]-p[i]),k2=cross(p[j]-p[i],p[l+1]-p[i]);
				tmp|=(((k1>=0)&&(k2>=0))||((k1<=0)&&(k2<=0)));
				pd[i][j]&=tmp;
			}
		}
	all=(1<<2*n)-1;
	REP(i,0,all)
		REP(j,1,2*n)
			dp[i][j]=1e18;
	REP(i,1,2*n)
		dp[1<<i-1][i]=0;
	REP(i,0,all)
		REP(j,1,2*n){
			if(dp[i][j]==1e18)continue;
			cout<<i<<' '<<j<<' '<<dp[i][j]<<endl;
			REP(k,(j<=n)*n+1,(j<=n)*n+n){
				if((i&(1<<k-1))||(dp[i^(1<<k-1)][k]<=dp[i][j]+dis(p[j],p[k]))||(!pd[j][k]))continue;
				dp[i^(1<<k-1)][k]=dp[i][j]+dis(p[j],p[k]);
			}
		}
	lf ans=1e18;
	REP(i,1,2*n)chkmin(ans,dp[all][i]);
	printf("%.10lf\n",ans==1e18?-1:ans);
	return 0;
}
