#include<bits/stdc++.h>
using namespace std;

const int maxn=300010;
const int inf=1e9+10;
int n, m, k;
int a[maxn], b[maxn];
vector<int> g[maxn];
int ans;
int cnt1, cnt2;
int num1[maxn], num2[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(int& x,int y){ if(x>y) x=y; }
void chkmax(int& x,int y){ if(x<y) x=y; }

int use[maxn], vis[maxn], cnt;
void check(int X,int y,int s){
	cnt=0;
	queue<int> q;
	q.push(s), vis[s]=1;
	while(!q.empty()){
		int x=q.front(); q.pop();
		cnt++;
		for(int i=0;i<g[x].size();i++){
			int v=g[x][i]; if(vis[v] || a[v]>num1[X] || b[v]>num2[y]) continue;
			q.push(v), vis[v]=1;
		}
	}
}

int calc(int x,int y){
	int ret=0;
	for(int i=1;i<=n;i++) vis[i]=0;
	for(int i=1;i<=n;i++) if(!vis[i] && a[i]<=num1[x] && b[i]<=num2[y]) check(x,y,i), chkmax(ret, cnt);
	return ret;
}

void solve(){
	for(int i=cnt1;i>=1;i--){
		int l=1, r=cnt2, ret=-1;
		while(l<=r){
			int mid=(l+r)>>1;
			if(calc(i,mid)>=k) ret=mid, r=mid-1; else l=mid+1;
		}
		if(~ret) chkmin(ans, num1[i]+num2[ret]);
		// cerr<<num1[i]<<' '<<num2[ret]<<' '<<ans<<endl;
		if(ret==-1) break;
	}
}

int main(){
	freopen("mincost.in","r",stdin),freopen("mincost.out","w",stdout);

	read(n), read(m), read(k);
	for(int i=1;i<=n;i++) read(a[i]), read(b[i]), num1[i]=a[i], num2[i]=b[i];
	int u, v;
	for(int i=1;i<=m;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
	}
	ans=2*inf;
	cnt1=n, cnt2=n;
	sort(num1+1,num1+1+cnt1), sort(num2+1,num2+1+cnt2);
	cnt1=unique(num1+1,num1+1+cnt1)-num1-1;
	cnt2=unique(num2+1,num2+1+cnt2)-num2-1;
	solve();
	if(ans>=2*inf) puts("no solution");
	else printf("%d\n", ans);
	return 0;
}
