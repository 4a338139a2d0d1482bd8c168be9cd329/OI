#include<bits/stdc++.h>
using namespace std;

const int maxn=300010;
const int inf=1e9+10;
int n, m, k;
int a[maxn], b[maxn];
vector<int> g[maxn];
int ans;

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(int& x,int y){ if(x>y) x=y; }
void chkmax(int& x,int y){ if(x<y) x=y; }

int use[maxn], vis[maxn];
bool check(){
	int ret=0;
	queue<int> q;
	int s=0;
	for(int i=1;i<=n;i++) vis[i]=0;
	for(int i=1;i<=n;i++) if(use[i]){ s=i; break; }
	q.push(s), vis[s]=1;
	while(!q.empty()){
		int x=q.front(); q.pop();
		ret++;
		for(int i=0;i<g[x].size();i++){
			int v=g[x][i]; if(!use[v] || vis[v]) continue;
			q.push(v), vis[v]=1;
		}
	}
	return ret==k;
}

int calc(){
	int ret1=0, ret2=0;
	for(int i=1;i<=n;i++) if(use[i]) chkmax(ret1, a[i]), chkmax(ret2, b[i]);
	return ret1+ret2;
}

int main(){
	freopen("mincost.in","r",stdin),freopen("mincost.out","w",stdout);

	read(n), read(m), read(k);
	for(int i=1;i<=n;i++) read(a[i]), read(b[i]);
	int u, v;
	for(int i=1;i<=m;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
	}
	ans=2*inf;
	for(int i=0;i<(1<<n);i++){
		if(__builtin_popcount(i)!=k) continue;
		for(int j=1;j<=n;j++) if(i & (1<<(j-1))) use[j]=1; else use[j]=0;
		if(!check()) continue;
		chkmin(ans, calc());
	}
	printf("%d\n", ans);
	return 0;
}
