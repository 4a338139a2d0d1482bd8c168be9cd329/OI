#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef long long ll;
typedef pair<int,int> pii;
const int maxn=40;
const int maxm=maxn*maxn;
const int mod=998244353;
int n, m;
int mp[maxn][maxn];
int cnt;
pii a[maxm];
vector<int> g[maxn];
ll ans;

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

int tot, dfn[maxn], low[maxn], bel[maxn], scc;
stack<int> st;
void dfs(int x){
	dfn[x]=low[x]=++tot;
	st.push(x);
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i];
		if(!dfn[v]) dfs(v), low[x]=min(low[x], low[v]);
		else if(!bel[v]) low[x]=min(low[x], dfn[v]);
	}
	if(low[x]>=dfn[x]){
		bel[x]=++scc;
		while(st.top()!=x) bel[ st.top() ]=scc, st.pop();
		st.pop();
	}
}

ll calc(int x){
	ll ret=1;
	for(int i=1;i<=cnt;i++){
		int u=a[i].fi, v=a[i].se;
		if(x & (1<<(i-1))) ret=ret*mp[u][v]%mod; else ret=ret*mp[v][u]%mod;
	}
	return ret;
}

ll base;
int T[maxn];

ll c[maxn][maxn];
void solve(){
	c[0][0]=1;
	for(int i=1;i<=n;i++){
		c[i][0]=1;
		for(int j=1;j<=i;j++) c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
	}
	ll inv=Pow(10000,mod-2);
	for(int i=1;i<=n;i++){
		ans=(ans+1ll*c[n][i]*Pow(1ll*5000*inv%mod,i*(n-i))%mod*Pow(1ll*10000*inv%mod,n*(n-1)/2-i*(n-i))%mod)%mod;
	}
	printf("%lld\n", ans*Pow(1000, n*(n-1))%mod);
}

int main(){
	freopen("random.in","r",stdin),freopen("random.out","w",stdout);

	scanf("%d%d", &n, &m);
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) if(i!=j) mp[i][j]=5000;
	int u, v, z;
	for(int i=1;i<=m;i++){
		scanf("%d%d%d", &u, &v, &z);
		mp[u][v]=z, mp[v][u]=10000-z;
	}
	if(!m && n>6){ solve(); return 0; }
	for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) a[++cnt]=make_pair(i, j);
	base=1;
	for(int i=1;i<=cnt;i++) base=base*10000%mod;
	for(int i=0;i<(1<<cnt);i++){
		for(int j=1;j<=n;j++) g[j].clear();
		for(int j=1;j<=cnt;j++){
			int u=a[j].fi, v=a[j].se;
			if(i & (1<<(j-1))) g[u].push_back(v);
			else g[v].push_back(u);
		}
		for(int j=1;j<=n;j++) dfn[j]=low[j]=bel[j]=0;
		tot=scc=0;
		for(int j=1;j<=n;j++) if(!dfn[j]) dfs(j);
		// printf("%d\n", scc);
		T[scc]++;
		(ans+=calc(i)*scc%mod)%=mod;
	}
	// for(int i=1;i<=n;i++) printf("%d ", T[i]); puts("");
	printf("%lld\n", ans*base%mod);
	return 0;
}
