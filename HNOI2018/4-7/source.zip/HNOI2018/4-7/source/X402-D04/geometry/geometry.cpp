#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
const double inf=1e12;
const double eps=1e-9;
int n;
struct point{ double x, y; }a[maxn], b[maxn];
point operator -(point A, point B){ return (point){A.x-B.x, A.y-B.y}; }
double operator *(point A, point B){ return A.x*B.y-A.y*B.x; } 

double pw(double x){ return x*x; }
double dis(int i,int j){ return sqrt(pw(a[i].x-b[j].x)+pw(a[i].y-b[j].y)); }
double calc(point A,point C,point D){ return (C-A)*(D-A); }
bool check(point A,point B,point C,point D){ return calc(A,C,D)*calc(B,C,D)<0 && calc(C,A,B)*calc(D,A,B)<0; }

int p[maxn], q[maxn];
bool check1(point A,point B){
	for(int i=0;i<=n;i++) if(check(A,B,a[i],a[i+1])) return false;
	for(int i=0;i<=n;i++) if(check(A,B,b[i],b[i+1])) return false;
	return true;
}
bool pd(){
	for(int i=1;i<=n;i++){
		if(!check1(a[ p[i] ],b[ q[i] ])) return false;
		if(i>1 && !check1(a[ p[i] ],b[ q[i-1] ])) return false;
	}
	return true;
}

double ans;
void solve(){
	ans=inf;
	int tot=1;
	for(int i=1;i<=n;i++) p[i]=i, tot*=i;
	while(tot--){
		int cnt=1;
		for(int i=1;i<=n;i++) q[i]=i, cnt*=i;
		while(cnt--){
			double t=0;
			if(!pd()){
				next_permutation(q+1,q+1+n);
				continue;
			}
			// for(int i=1;i<=n;i++) printf("%d %d\n", p[i], q[i]); puts("");
			for(int i=1;i<=n;i++){
				t+=dis(p[i],q[i]);
				if(i>1) t+=dis(p[i],q[i-1]);
			}
			if(t<ans) ans=t;
			next_permutation(q+1,q+1+n);
		}
		next_permutation(p+1,p+1+n);
	}
}

int main(){
	freopen("geometry.in","r",stdin),freopen("geometry.out","w",stdout);

	scanf("%d", &n);
	for(int i=1;i<=n;i++) scanf("%lf%lf", &a[i].x, &a[i].y);
	for(int i=1;i<=n;i++) scanf("%lf%lf", &b[i].x, &b[i].y);
	a[0]=(point){a[1].x,1e9}, a[n+1]=(point){a[n].x,1e9};
	b[0]=(point){b[1].x,-1e9}, b[n+1]=(point){b[n].x,-1e9};
	if(n==1){
		printf("%.14lf\n", dis(1,1)); return 0;
	}
	solve();
	swap(a,b);
	solve();
	printf("%.14lf\n", ans>=inf-eps ? -1.0 : ans); return 0;
	return 0;
}
