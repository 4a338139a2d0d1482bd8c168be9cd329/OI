#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
int n;
struct node{ double x, y; }a[maxn], b[maxn];

double pw(double x){ return x*x; }
double dis(int i,int j){
	return sqrt(pw(a[i].x-b[j].x)+pw(a[i].y-b[j].y));
}

int p[maxn], q[maxn];
void solve(){
	int tot=1;
	for(int i=1;i<=n;i++) p[i]=i, tot*=i;
	while(tot--){
		int cnt=1;
		for(int i=1;i<=n;i++) q[i]=i, cnt*=i;
		while(cnt--){
			
		}
		next_permutation(p+1,p+1+tot);
	}
}

int main(){
	freopen("geometry.in","r",stdin),freopen("geometry.out","w",stdout);

	scanf("%d", &n);
	for(int i=1;i<=n;i++) scanf("%lf%lf", &a[i].x, &a[i].y);
	for(int i=1;i<=n;i++) scanf("%lf%lf", &b[i].x, &b[i].y);
	if(n==1){
		printf("%.9lf\n", dis(1,1)); return 0;
	}else if(n<=5){
		solve();
	}
	return 0;
}
