#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=3e5+10,maxm=5e5+10,inf=0x3f3f3f3f;
inline bool chkmin(int &x,int y){return (y<x)?(x=y,1):0;}
int Begin[maxn],to[maxm<<1],Next[maxm<<1],e;
void add_edge(int x,int y){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
}
struct point{
	int x,y,id;
}a[maxn],b[maxn];
bool cmpx(point A,point B){
	return A.x<B.x;
}
bool cmpy(point A,point B){
	return A.y<B.y;
}
int fa[maxn],sz[maxn];
int find(int x){
	if(fa[x]==x) return x;
	return fa[x]=find(fa[x]);
}
bool p[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
#endif
	int n=read(),m=read(),K=read();
	REP(i,1,n) a[i].x=read(),a[i].y=read(),a[i].id=i;
	REP(i,1,m){
		int x=read(),y=read();
		add_edge(x,y),add_edge(y,x);
	}
	sort(a+1,a+n+1,cmpx);
	int ans=inf*2;
	REP(i,1,n) fa[i]=i,sz[i]=1,p[i]=0;
	REP(i,1,K-1) b[i]=a[i];
	REP(i,K,n){
		b[i]=a[i];
		sort(b+1,b+i+1,cmpy);
//		cerr<<i<<endl;
		REP(j,1,i){
			int x=b[j].id;p[x]=1;
			for(int k=Begin[x];k;k=Next[k]){
				if(!p[to[k]]) continue;
				int u=find(x),v=find(to[k]);
				if(u==v) continue;
				fa[v]=u;
				sz[u]+=sz[v];
				if(sz[u]>=K) break;
			}
			if(sz[find(x)]>=K){
//				cerr<<find(x)<<endl;
				chkmin(ans,a[i].x+b[j].y);
				break;
			}
		}
		REP(k,1,i) fa[b[k].id]=b[k].id,sz[b[k].id]=1,p[b[k].id]=0;
	}
	if(ans==inf*2) printf("no solution\n");
	else printf("%d\n",ans);
	return 0;
}
