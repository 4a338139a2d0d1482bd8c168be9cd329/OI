#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmin(int &x,int y){return (y<x)?(x=y,1):0;}
const int maxn=40,mod=998244353;
int n,m;
namespace Subtask1{
	int G[maxn][maxn],p[maxn][maxn];
	int id[maxn][maxn],pre[maxn],sccno[maxn],low[maxn];
	int dfs_clock,scc_cnt;
	stack<int> S;
	void tarjan(int x){
		pre[x]=low[x]=++dfs_clock;
		S.push(x);
		REP(i,1,n) if(p[x][i]){
			if(!pre[i]){
				tarjan(i);
				chkmin(low[x],low[i]);
			}
			else if(!sccno[i])
				chkmin(low[x],pre[i]);
		}
		if(pre[x]==low[x]){
			++scc_cnt;
			while(!S.empty()){
				int u=S.top();S.pop();
				sccno[u]=scc_cnt;
				if(u==x) return;
			}
		}
	}
	void work(){
		int tmp=0;
		REP(i,1,n) REP(j,i+1,n) G[i][j]=G[j][i]=5000,id[i][j]=++tmp;
		REP(i,1,m){
			int x=read(),y=read(),z=read();
			G[x][y]=z;
			G[y][x]=10000-z;
		}
		int ans=0;
		REP(i,0,(1<<tmp)-1){
			int num=1;
			REP(j,1,n) REP(k,j+1,n)
				if(i&(1<<id[j][k]-1)){
					num=1ll*num*G[j][k]%mod;
					p[j][k]=1;p[k][j]=0;
				}
				else{
					num=1ll*num*G[k][j]%mod;
					p[k][j]=1;p[j][k]=0;
				}
			dfs_clock=scc_cnt=0;
			REP(j,1,n) pre[j]=low[j]=sccno[j]=0;
			REP(j,1,n) if(!pre[j]) tarjan(j);
			ans=(ans+1ll*scc_cnt*num%mod)%mod;
		}
		REP(i,1,tmp) ans=1ll*ans*10000%mod;
		printf("%d\n",ans);
	}
}
namespace Subtask3{
	int C[maxn][maxn],f[maxn],g[maxn];
	int ksm(int x,int y){
		int res=1;
		while(y){
			if(y&1) res=1ll*res*x%mod;
			x=1ll*x*x%mod;
			y>>=1;
		}
		return res;
	}
	void work(){
		int ans=0;
		REP(i,1,n){
			C[i][i]=C[i][0]=1;
			REP(j,1,i-1) C[i][j]=(C[i-1][j-1]+C[i-1][j])%mod;
		}
		REP(i,1,n){
			g[i]=ksm(2,i*(i-1)/2);
			f[i]=g[i];
			REP(j,1,i-1) f[i]=(f[i]+mod-1ll*g[i-j]*f[j]%mod*C[i][j]%mod)%mod;
		}
		printf("%d\n",f[n]);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
#endif
	n=read(),m=read();
	Subtask1::work();
	return 0;
}
