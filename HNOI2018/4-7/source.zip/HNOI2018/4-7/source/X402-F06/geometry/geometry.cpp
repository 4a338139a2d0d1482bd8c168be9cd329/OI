#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e3+10;
const double inf=1e15;
struct point{
	double x,y;
}a[maxn],b[maxn];
double ans;
int n;
inline double pf(double x){
	return x*x;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
#endif
	ans=inf;
	n=read();
	REP(i,1,n) scanf("%lf%lf",&a[i].x,&a[i].y);
	REP(i,1,n) scanf("%lf%lf",&b[i].x,&b[i].y);
	if(n==1){
		printf("%.15lf",sqrt(pf(a[1].x-b[1].x)+pf(a[1].y-b[1].y)));
		return 0;
	}
	return 0;
}
