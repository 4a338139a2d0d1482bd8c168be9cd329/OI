#include<bits/stdc++.h>
#define For(i,a,b) for(register int i=a;i<=b;++i)
#define FOR(i,a,b) for(register int i=a;i>=b;--i)
#define next Next
#define inf (0x3f3f3f3f)
#define go(x,i) for(register int i=head[x];i;i=next[i])

using namespace std;

#define tt template<typename T>

tt inline bool chkmax(T &a,T b){return a<b?a=b,1:0;}
tt inline bool chkmin(T &a,T b){return a>b?a=b,1:0;}

tt inline void read(T &_)
{
	T __=1;_=0;char ___=getchar();
	while(!isdigit(___))
	{
		if(___=='-')
			__=-1;
		___=getchar();
	}
	while(isdigit(___))
	{
		_=(_<<3)+(_<<1)+___^'0';
		___=getchar();
	}
	_*=__;
}

inline void file()
{
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
}

int main()
{

	return 0;
}
