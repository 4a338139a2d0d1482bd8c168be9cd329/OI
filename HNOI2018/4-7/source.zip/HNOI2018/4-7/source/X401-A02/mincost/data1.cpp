#include<bits/stdc++.h>

using namespace std;
const int mod=1e9;
int mp[21][21];


int main()
{
	srand(int(time(0)));
	freopen("mincost.in","w",stdout);
	int n=10,m=30;
	cout<<n<<' '<<m<<' '<<rand()%n+1<<endl;
	for(int i=1;i<=n;++i)
		cout<<rand()%mod+1<<' '<<rand()%mod+1<<endl;
	while(m!=0)
	{
		int x=rand()%n+1,y=rand()%n+1;
		if(x!=y&&!mp[x][y]){
			mp[x][y]=mp[y][x]=1;
			cout<<x<<' '<<y<<endl;
			--m;
		}
	}
	return 0;
}
