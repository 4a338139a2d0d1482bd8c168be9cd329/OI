#include<bits/stdc++.h>
#define For(_,__,___) for(register int _=__;_<=___;++_)
#define FOR(_,__,___) for(register int _=__;_>=___;--_)
#define next Next
#define inf (0x3f3f3f3f)
#define go(_,__) for(register int __=head[_];__;__=next[__])
#define MAX(_,__) (_>__?_:__)
#define MIN(_,__) (_<__?_:__)

using namespace std;
typedef long long ll;
#define tt template<typename T>

tt inline bool chkmax(T &_,T __){return _<__?_=__,1:0;}
tt inline bool chkmin(T &_,T __){return _>__?_=__,1:0;}

tt inline void read(T &_)
{
	T __=1;_=0;char ___=getchar();
	while(!isdigit(___))
	{
		if(___=='-')
			__=-1;
		___=getchar();
	}
	while(isdigit(___))
	{
		_=(_<<3)+(_<<1)+(___^'0');
		___=getchar();
	}
	_*=__;
}

inline void file()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost1.out","w",stdout);
}

const int maxn=23,maxm=103;
int n,m,k,vis[maxn],e;
int a[maxn],b[maxn];
int head[maxn],next[maxm<<1],to[maxm<<1],v[maxm<<1];
int ans=inf<<1;

inline void add(int x,int y)
{
	to[++e]=y;next[e]=head[x];head[x]=e;
	to[++e]=x;next[e]=head[y];head[y]=e;
}

inline void dfs(int x,int maxa,int maxb,int s)
{
//	cout<<x<<endl;
	if(s==k)
	{
//		puts("");
		chkmin(ans,maxa+maxb);
		return;
	}
	vis[x]=1;
	go(x,i)
		if(!vis[to[i]]&&MAX(maxa,a[to[i]])+MAX(maxb,b[to[i]])<ans)
			dfs(to[i],MAX(maxa,a[to[i]]),MAX(maxb,b[to[i]]),s+1);
	vis[x]=0;
}

int main()
{
	double ovo=clock();
	file();
	int x,y;
	read(n);read(m);read(k);
	For(i,1,n)
		read(a[i]),read(b[i]);
	For(i,1,m)
	{
		read(x);read(y);
		add(x,y);
	}
	For(i,1,n)
		dfs(i,a[i],b[i],1);
	cerr<<(clock()-ovo)/CLOCKS_PER_SEC;
	if(ans==inf<<1)
		printf("no solution");
	else
		printf("%d\n",ans);
	return 0;
}

