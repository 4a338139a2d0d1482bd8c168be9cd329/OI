#include<bits/stdc++.h>
#define For(_,__,___) for(register int _=__;_<=___;++_)
#define FOR(_,__,___) for(register int _=__;_>=___;--_)
#define next Next
#define inf (0x3f3f3f3f)
#define go(_,__) for(register int __=head[_];__;__=next[__])
#define MAX(_,__) (_>__?_:__)
#define MIN(_,__) (_<__?_:__)

using namespace std;
typedef long long ll;
#define tt template<typename T>

tt inline bool chkmax(T &_,T __){return _<__?_=__,1:0;}
tt inline bool chkmin(T &_,T __){return _>__?_=__,1:0;}

tt inline void read(T &_)
{
	T __=1;_=0;char ___=getchar();
	while(!isdigit(___))
	{
		if(___=='-')
			__=-1;
		___=getchar();
	}
	while(isdigit(___))
	{
		_=(_<<3)+(_<<1)+(___^'0');
		___=getchar();
	}
	_*=__;
}

inline void file()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
}

int main(void)
{
	file();
	int n;
	read(n);
	if(n==1)
	{
		double x1,x2,y1,y2;
		cin>>x1>>y1>>x2>>y2;
		printf("%.10f",sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)));	
	}
}

