#include<bits/stdc++.h>
#define For(i,a,b) for(register int i=a;i<=b;++i)
#define FOR(i,a,b) for(register int i=a;i>=b;--i)
#define next Next
#define inf (0x3f3f3f3f)
#define go(x,i) for(register int i=head[x];i;i=next[i])

using namespace std;
typedef long long ll;
#define tt template<typename T>

tt inline bool chkmax(T &a,T b){return a<b?a=b,1:0;}
tt inline bool chkmin(T &a,T b){return a>b?a=b,1:0;}

tt inline void read(T &_)
{
	T __=1;_=0;char ___=getchar();
	while(!isdigit(___))
	{
		if(___=='-')
			__=-1;
		___=getchar();
	}
	while(isdigit(___))
	{
		_=(_<<3)+(_<<1)+(___^'0');
		___=getchar();
	}
	_*=__;
}

inline void file()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
}

const int mod=998244353;
const int maxn=8;
int a[maxn][maxn];
int n,m,inva,invb,ans;

inline int qpow(int _,int __)
{
	int ___=1;
	while(__)
	{
		if(__&1)
			___=(1ll*___*_)%mod;
		__>>=1;
		_=(1ll*_*_)%mod;
	}
	return ___;
}

pair<int,int> q[maxn*maxn/2];
int cnt=0;

int b[maxn][maxn];

inline void judge(int gailv)
{
	int vis[maxn]={0};
}

inline void dfs(int x,int gailv)
{
	if(gailv==0)
		return;
	if(x>n*(n-1)/2)
	{
		judge(gailv);
		return;
	}
	b[q[x].first][q[x].second]=1;
	dfs(x+1,int(1ll*a[q[x].first][q[x].second]*gailv%mod));
	b[q[x].first][q[x].second]=0;
	b[q[x].second][q[x].first]=1;
	dfs(x+1,int(1ll&a[q[x].second][q[x].first]*gailv%mod));
}

int main()
{
	int x,y,z;
	file();
	read(n);read(m);
	inva=qpow(10000,mod-2);
	invb=qpow((qpow(10000,(n-1)*n)),mod-2);
	For(i,1,n)
		For(j,1,n)
			if(i!=j)
				a[i][j]=1ll*5000*inva%mod;
	For(i,1,m)
	{
		read(x);read(y);read(z);
		a[x][y]=1ll*z*inva%mod;
		a[y][x]=1ll*(10000-z)*inva%mod;
	}
	For(i,1,n)
		For(j,i+1,n)
			q[++cnt]=make_pair(i,j);
	dfs(1,1);
	return 0;
}
