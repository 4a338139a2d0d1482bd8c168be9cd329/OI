#include<bits/stdc++.h>
#define N 3100
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
long long ans;
long long n,m;
long long cnt,to[N],beg[N],nex[N];
long long mapp[50][50],s[50][50];
long long e;
long long inv;
long long ksm(long long x,long long mc)
{
	long long tmp=x%mod;
	long long res=1;
	while(mc)
	{
		if(mc&1ll)res=res*tmp%mod;
		tmp=tmp*tmp%mod;
		mc>>=1ll;
	}
	return res;
}
long long to1[N],beg1[N],nex1[N];
void add(long long x,long long y)
{
	to[++cnt]=y;
	nex[cnt]=beg[x];
	beg[x]=cnt;
}
void add1(long long x,long long y)
{
	to1[++e]=y;
	nex1[e]=beg1[x];
	beg1[x]=e;
}
long long vis[N];
long long tot;
vector<long long>ss;
void dfs1(long long x)
{
    vis[x]=1;
    for(long long i=beg[x];i;i=nex[i])
        if(!vis[to[i]])dfs1(to[i]);
    ss.push_back(x);
}
void dfs2(long long x)
{
    vis[x]=1;
    for(long long i=beg1[x];i;i=nex1[i])
        if(!vis[to1[i]])dfs2(to1[i]);
}
long long kosaraju()
{
	memset(vis,0,sizeof vis);
	ss.clear();
	for(long long i=1;i<=n;i++)	
		if(!vis[i])dfs1(i);
	memset(vis,0,sizeof vis);
	tot=0;
	for(long long i=ss.size()-1;i>=0;i--)
		if(!vis[ss[i]])tot++,dfs2(ss[i]);
	return tot%mod;
}
void dfs(long long x,long long y,long long gl)
{
	if(x==n&&y==n+1)
	{
		cnt=0;
		memset(beg,0,sizeof beg);
		e=0;
		memset(beg1,0,sizeof beg1);
		for(long long i=1;i<=n;i++)
			for(long long j=1;j<=n;j++)
				if(s[i][j])add(i,j),add1(j,i);
		(ans+=kosaraju()*gl%mod)%=mod;
		return ;
	}
	s[x][y]=1;
	if(y<n)dfs(x,y+1,gl%mod*mapp[x][y]%mod*inv%mod);
	else dfs(x+1,x+2,gl%mod*mapp[x][y]%mod*inv%mod);
	s[x][y]=0;
	s[y][x]=1;
	if(y<n)dfs(x,y+1,gl%mod*mapp[y][x]%mod*inv%mod);
	else dfs(x+1,x+2,gl%mod*mapp[y][x]%mod*inv%mod);
	s[y][x]=0;
}
int main()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	read(n);read(m);
	inv=ksm(10000,mod-2);
	for(long long i=1;i<=m;i++)
	{
		static long long x,y,z;
		read(x);read(y);read(z);
		mapp[x][y]=z;mapp[y][x]=10000-z;
	}
	for(long long i=1;i<=n;i++)
		for(long long j=i+1;j<=n;j++)
			if(!mapp[i][j]&&!mapp[j][i])mapp[i][j]=mapp[j][i]=5000;
	dfs(1,2,1);
	printf("%lld\n",ans*ksm(10000,n*(n-1))%mod);
	return 0;
}
