#include<bits/stdc++.h>
#define N 300100
#define M 1000010
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n,m,k;
int e;
int to[M],beg[N],nex[M];
void add(int x,int y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
struct node
{
	int a,b;
}val[N];
int S[N],vis[N],viss[N];
int ans=0x7f7f7f7f;
map<int,bool>bj;
int flag;
void pd(int st,int en)
{
	if(flag){viss[st]=0;return ;}
	if(st==en){flag=1;return ;}
	viss[st]=1;
	for(int i=beg[st];i;i=nex[i])
	{
		int y=to[i];
		if(viss[y])continue;
		if(!bj.count(y))continue;
		pd(y,en);
	}
	viss[st]=0;
}
void dfs(int x,int last,int maxa,int maxb)
{
	if(x==k+1)
	{
		for(int i=1;i<=k;i++)
			for(int j=i+1;j<=k;j++)
			{
				flag=0;
				pd(S[i],S[j]);
				if(!flag)return ;
			}
		ans=min(ans,maxa+maxb);
		return ;
	}
	for(int i=last+1;i<=n;i++)
	{
		if(!vis[i])
		{
			vis[i]=1;
			bj[i]=1;
			S[x]=i;
			dfs(x+1,i,max(maxa,val[i].a),max(maxb,val[i].b));
			bj.erase(i);
			vis[i]=0;
			S[x]=0;
		}
	}
}
int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	read(n);read(m);read(k);
	for(int i=1;i<=n;i++)read(val[i].a),read(val[i].b);
	for(int i=1;i<=m;i++)
	{
		static int x,y;
		read(x);read(y);
		add(x,y);add(y,x);
	}
	dfs(1,0,0,0);
	if(ans!=0x7f7f7f7f)printf("%d\n",ans);
	else puts("no solution");
	return 0;
}
