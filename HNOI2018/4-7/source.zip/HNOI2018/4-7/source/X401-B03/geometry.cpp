#include<bits/stdc++.h>
#define N 3000
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n;
struct node
{
	double x,y;
	double operator -(const node &ss)const
	{
		return sqrt((x-ss.x)*(x-ss.x)+(y-ss.y)*(y-ss.y));
	}
}up[N],down[N];
double ans;
int vis[N],viss[N];
bool xj1(int x,int y,int xx,int yy)
{
    double kk,b;
    kk=(down[y].y-up[x].y)/(down[y].x-up[x].x);
    b=-kk*up[x].x+up[x].y;
    double kk1,b1;
    kk1=(up[yy].y-up[xx].y)/(up[yy].x-up[xx].x);
    b1=-kk1*up[xx].x+up[xx].y;
    static double s,t;
	s=(b1-b)/(kk-kk1);t=kk*s+b;
    double minx=min(up[x].x,down[y].x),maxx=max(up[x].x,down[y].x);
    double miny=min(up[x].y,down[y].y),maxy=max(up[x].y,down[y].y);
    double minx1=min(up[xx].x,up[yy].x),maxx1=max(up[xx].x,up[yy].x);
    double miny1=min(up[xx].y,up[yy].y),maxy1=max(up[xx].y,up[yy].y);
    if(s>=minx&&s<=maxx&&t>=miny&&t<=maxy&&s>=minx1&&s<=maxx1&&t>=miny1&&t<=maxy1)return 1;
    return 0;
}
bool xj2(int x,int y,int xx,int yy)
{
    double kk,b;
    kk=(down[y].y-up[x].y)/(down[y].x-up[x].x);
    b=-kk*up[x].x+up[x].y;
    double kk1,b1;
    kk1=(down[yy].y-down[xx].y)/(down[yy].x-down[xx].x);
    b1=-kk1*down[xx].x+down[xx].y;
    static double s,t;
	s=(b1-b)/(kk-kk1);t=kk*s+b;
    double minx=min(up[x].x,down[y].x),maxx=max(up[x].x,down[y].x);
    double miny=min(up[x].y,down[y].y),maxy=max(up[x].y,down[y].y);
    double minx1=min(down[xx].x,down[yy].x),maxx1=max(down[xx].x,down[yy].x);
    double miny1=min(down[xx].y,down[yy].y),maxy1=max(down[xx].y,down[yy].y);
    if(s>=minx&&s<=maxx&&t>=miny&&t<=maxy&&s>=minx1&&s<=maxx1&&t>=miny1&&t<=maxy1)return 1;
    return 0;
}
bool pd(int x,int y,int flag)
{
	double kk,b;
	kk=(up[y].y-down[x].y)/(up[y].x-down[x].x);
	b=-kk*down[x].x+down[x].y;
	double maxx=max(down[x].x,up[y].x),maxy=max(down[x].y,up[y].y);
	double minx=min(down[x].x,up[y].x),miny=min(down[x].y,up[y].y);
	if(down[1].x*kk+b<down[1].y&&down[1].x>minx&&down[1].x<maxx||down[n].x*kk+b<down[n].y&&down[n].x>minx&&down[n].x<maxx)return 0;
	if(up[1].x*kk+b>up[1].y&&up[1].x>minx&&up[1].x<maxx||up[n].x*kk+b>up[n].y&&up[n].x>minx&&up[n].x<maxx)return 0;
	return 1;
}
void dfs(int x,double sum,bool flag,int last)
{
	if(sum>ans)return ;
	if(x==2*n+1)
	{
		ans=sum;
		return ;
	}
	if(!flag)
	{
		for(int i=1;i<=n;i++)
		{
			if(!vis[i])
			{
				if(!pd(i,last,flag))continue;
				vis[i]=1;
				dfs(x+1,sum+(down[i]-up[last]),1,i);
				vis[i]=0;
			}
		}
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			if(!viss[i])
			{
				if(!pd(i,last,flag))continue;
				viss[i]=1;
				dfs(x+1,sum+(up[i]-down[last]),0,i);
				viss[i]=0;
			}
		}
	}
}
int main()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&down[i].x,&down[i].y);
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&up[i].x,&up[i].y);
	if(n==1)return printf("%.10lf\n",down[1]-up[1]),0;
	if(n<=5)
	{
		ans=2100000000.0;
		dfs(1,0,0,0);
		memset(vis,0,sizeof vis);
		memset(viss,0,sizeof viss);
		dfs(1,0,1,0);
		if(ans!=2100000000.0)printf("%.10lf\n",ans);
		else puts("-1");
	}
	puts("-1");
	return 0;
}
