#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	fprintf(stderr,"%d\n",seed);
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("mincost.in","w",stdout);
	int n=f(1,20),m=f(1,100),k=f(1,n);
//	n=5e3;m=5e3;k=f(1,n);
	printf("%d %d %d\n",n,m,k);
	for(int i=1;i<=n;++i)
		printf("%d %d\n",f(1,1e2),f(1,1e2));
	for(int i=1;i<=m;++i)
		printf("%d %d\n",f(1,n),f(1,n));
	return 0;
}
