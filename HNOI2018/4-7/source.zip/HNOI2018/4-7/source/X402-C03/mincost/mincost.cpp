#include<bits/stdc++.h>
using namespace std;

const int maxn=3e5+10,maxm=5e5+10,inf=2e9+1;
int n,m,k,a[maxn],b[maxn],ans=inf;
int fa[maxn],size[maxn];
vector<int> g[maxn];
pair<int,int> ordb[maxn];

int findfa(int x){
	if(fa[x]==x)return x;
	return fa[x]=findfa(fa[x]);
}

int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i){
		scanf("%d%d",&a[i],&b[i]);
		ordb[i]=make_pair(b[i],i);
	}
	if(k==1){
		for(int i=1;i<=n;++i)
			if(ans>a[i]+b[i])
				ans=a[i]+b[i];
		printf("%d\n",ans);
		return 0;
	}
	for(int i=1,u,v;i<=m;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	sort(ordb+1,ordb+n+1);
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			fa[j]=j;
			size[j]=1;
		}
		for(int j=1,u;j<=n;++j)if(a[u=ordb[j].second]<=a[i])
			for(int x=0,v;x<g[u].size();++x)
				if(a[v=g[u][x]]<=a[i]&&b[v]<=b[u]&&findfa(u)!=findfa(v)){
					size[findfa(v)]+=size[findfa(u)];
					fa[findfa(u)]=findfa(v);
					if(size[findfa(v)]>=k){
						if(ans>a[i]+b[u])
							ans=a[i]+b[u];
						goto xxx;
					}
				}
xxx:
		;
	}
	if(ans==inf)
		puts("no solution");
	else
		printf("%d\n",ans);
	return 0;
}
