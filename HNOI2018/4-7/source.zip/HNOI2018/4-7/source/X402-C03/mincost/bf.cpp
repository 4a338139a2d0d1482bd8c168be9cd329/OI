#include<bits/stdc++.h>
using namespace std;

const int maxn=3e5+10,maxm=5e5+10;
int n,m,k,a[maxn],b[maxn],u[maxn],v[maxn],ans=-1;
bool vis[maxn];
int fa[maxn];

int findfa(int x){
	if(fa[x]==x)return x;
	return fa[x]=findfa(fa[x]);
}
bool judge(){
	for(int i=1;i<=n;++i)
		if(vis[i])
			fa[i]=i;
	for(int i=1;i<=m;++i)
		if(vis[u[i]]&&vis[v[i]])
			fa[findfa(u[i])]=findfa(v[i]);
	for(int i=1;i<=n;++i)
		if(vis[i]){
			for(int j=i+1;j<=n;++j)
				if(vis[j])
					if(findfa(i)!=findfa(j))
						return false;
			return true;
		}
}
void dfs(int pos,int chosen,int maxa,int maxb){
	if(chosen>=k){
		if(judge())
			if(ans==-1||ans>maxa+maxb)
				ans=maxa+maxb;
		return;
	}
	if(pos>n)
		return;
	dfs(pos+1,chosen,maxa,maxb);
	vis[pos]=true;
	dfs(pos+1,chosen+1,max(maxa,a[pos]),max(maxb,b[pos]));
	vis[pos]=false;
}

int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.txt","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i)
		scanf("%d%d",&a[i],&b[i]);
	for(int i=1;i<=m;++i)
		scanf("%d%d",&u[i],&v[i]);
	dfs(1,0,0,0);
	if(ans==-1)
		puts("no solution");
	else
		printf("%d\n",ans);
	return 0;
}
