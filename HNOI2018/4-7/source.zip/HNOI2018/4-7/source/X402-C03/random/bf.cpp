#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=38+10,mod=998244353;
int n,m,p[maxn][maxn];
bool g[maxn][maxn];
ll ans;

inline ll fpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a%mod)
		if(n&1ll)
			res=res*a%mod;
	return res;
}
int dfn,pre[maxn],low[maxn],stk[maxn],top,scc[maxn],scccnt;
void dfs(int pos){
	pre[pos]=low[pos]=++dfn;
	stk[top++]=pos;
	for(int i=1;i<=n;++i)
		if(g[pos][i])
			if(!pre[i]){
				dfs(i);
				if(low[i]<low[pos])
					low[pos]=low[i];
			}
			else if(!scc[i]){
				if(pre[i]<low[pos])
					low[pos]=pre[i];
			}
	if(low[pos]>=pre[pos]){
		++scccnt;
		do{
			--top;
			scc[stk[top]]=scccnt;
		}
		while(stk[top]!=pos);
	}
}
int calc(){
	dfn=0;top=0;scccnt=0;
	for(int i=1;i<=n;++i)
		pre[i]=0,scc[i]=0;
	for(int i=1;i<=n;++i)
		if(!pre[i])
			dfs(i);
	return scccnt;
}
void dfs(int u,int v,ll nowp){
	if(v>n)
		u=u+1,v=u+1;
	if(v>n){
		(ans+=nowp*calc())%=mod;
		return;
	}
	g[u][v]=true;g[v][u]=false;
	dfs(u,v+1,nowp*p[u][v]%mod);
	g[u][v]=false;g[v][u]=true;
	dfs(u,v+1,nowp*(10000-p[u][v])%mod);
}

int main(){
	freopen("random.in","r",stdin);
	freopen("random.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			p[i][j]=5000;
	for(int i=1,u,v,w;i<=m;++i){
		scanf("%d%d%d",&u,&v,&w);
		p[u][v]=w;
	}
	dfs(1,2,1);
	printf("%lld\n",ans*fpow(10000,n*(n-1)/2)%mod);
	return 0;
}
