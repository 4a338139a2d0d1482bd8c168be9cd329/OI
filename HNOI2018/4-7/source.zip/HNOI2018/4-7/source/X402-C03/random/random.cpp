#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=38+10,mod=998244353,inv2=499122177;
int n,m;
int u[maxn],v[maxn],w[maxn],type[maxn];
int fa[maxn],size[maxn],stka[maxn],stkb[maxn],top;
ll ans;
ll powinv2[10000];

inline ll fpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a%mod)
		if(n&1ll)
			res=res*a%mod;
	return res;
}
int findfa(int x){
	if(fa[x]==x)return x;
	return findfa(fa[x]);
}
inline void link(int u,int v){
	u=findfa(u);v=findfa(v);
	stka[top]=u;stkb[top]=v;
	if(u!=v)
		size[v]+=size[u],fa[u]=v;
	++top;
}
inline void cut(){
	--top;
	if(stka[top]!=stkb[top])
		size[stkb[top]]-=size[stka[top]],fa[stka[top]]=stka[top];
}

void dfs(int pos,ll now){
	if(pos>m){
		static int f[maxn];
		int a=findfa(n+1),b=findfa(n+2);
		if(a==b)
			return;
		for(int i=0;i<=n;++i)
			f[i]=0;
		f[size[a]]=1;
		for(int i=1;i<=n;++i)
			if(fa[i]==i&&a!=i&&b!=i)
				for(int j=n;j>=size[i];--j)
					f[j]+=f[j-size[i]];
		for(int i=0;i<=n;++i)
			if(f[i])
				ans=(ans+f[i]*now%mod*powinv2[(n-i)*i])%mod;
		return;
	}
	type[pos]=0;
	link(u[pos],v[pos]);
	dfs(pos+1,now);
	cut();
	type[pos]=1;
	link(u[pos],n+1),link(v[pos],n+2);
	dfs(pos+1,now*w[pos]%mod*2%mod);
	cut(),cut();
	type[pos]=2;
	link(u[pos],n+2),link(v[pos],n+1);
	dfs(pos+1,now*(1-w[pos]+mod)%mod*2%mod);
	cut(),cut();
}

int main(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	powinv2[0]=1;
	for(int i=1;i<10000;++i)
		powinv2[i]=powinv2[i-1]*inv2%mod;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i){
		scanf("%d%d%d",&u[i],&v[i],&w[i]);
		w[i]=w[i]*fpow(10000,mod-2)%mod;
	}
	for(int i=1;i<=n+2;++i)
		fa[i]=i,size[i]=i<=n;
	dfs(1,1);
	printf("%lld\n",(ans+mod-1)%mod*fpow(10000,n*(n-1))%mod);
	return 0;
}
