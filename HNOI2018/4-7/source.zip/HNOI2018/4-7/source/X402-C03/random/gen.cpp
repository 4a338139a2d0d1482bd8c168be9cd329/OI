#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	fprintf(stderr,"%d\n",seed);
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

bool g[100][100];
vector<pair<int,int> > vec;

int main(){
	init();
	freopen("random.in","w",stdout);
	int n=f(1,6),m=f(0,min(n*(n-1)/2,19));
	printf("%d %d\n",n,m);
	for(int i=1;i<=m;++i){
		int u=1,v=1;
		while(u>=v||g[u][v])
			u=f(1,n),v=f(1,n);
		g[u][v]=true;
		vec.push_back(make_pair(u,v));
	}
	for(int i=0;i<m;++i)
		printf("%d %d %d\n",vec[i].first,vec[i].second,f(0,1e4));
	return 0;
}
