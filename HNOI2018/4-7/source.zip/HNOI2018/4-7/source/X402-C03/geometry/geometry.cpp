#include<bits/stdc++.h>
using namespace std;

double a,b,c,d;

int main(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	scanf("%*d%lf%lf%lf%lf",&a,&b,&c,&d);
	printf("%.10f\n",sqrt((a-c)*(a-c)+(b-d)*(b-d)));
	return 0;
}
