#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define MREP(i,x) for(register int i=beg[x];i;i=E[i].last)
#define ll long long
#define inf (0x3f3f3f3f)
void File(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
}
template<typename T>void chckmax(T &_,T __){_=_>__ ? _ : __;}
template<typename T>void chckmin(T &_,T __){_=_<__ ? _ : __;}
const int maxn=3e5+10;
const int maxm=5e5+10;
int n,m,k,a[maxn],b[maxn],beg[maxn],cnt;
struct edge{
	int to;
	int last;
}E[maxm*2];
void add(int u,int v){
	++cnt;
	E[cnt].to=v;
	E[cnt].last=beg[u];
	beg[u]=cnt;
}
bool chos[maxn];
int stac[maxn],fa[maxn],size[maxn],ans=inf;
int find(int x){return fa[x]==x ? x : fa[x]=find(fa[x]);}
bool judge(){
	REP(i,1,k)fa[stac[i]]=stac[i],size[stac[i]]=1;
	REP(i,1,k){
		int u=stac[i];
		MREP(j,u){
			int v=E[j].to;
			if(!chos[v])continue;
			if(find(v)==find(u))continue;
			size[find(u)]+=size[find(v)];
			fa[find(v)]=find(u);
		}
	}
	return size[find(stac[1])]==k;
}
void dfs(int now,int fro,int Maxa,int Maxb){
	if(k-now>n-fro)return;
	if(now>k){
		if(judge())chckmin(ans,Maxa+Maxb);
		return;
	}
	REP(i,fro,n){
		stac[now]=i;
		chos[i]=1;
		dfs(now+1,i+1,Maxa>a[i] ? Maxa : a[i],Maxb>b[i] ? Maxb : b[i]);
		chos[i]=0;
	}
}
bool vis[maxn];
void sub2(int u,int Maxa,int Maxb){
	chckmin(ans,Maxa+Maxb);
	vis[u]=1;
	MREP(i,u){
		int v=E[i].to;
		if(vis[v])continue;
		sub2(v,Maxa>a[i] ? Maxa : a[i],Maxb>b[i] ? Maxb : b[i]);
	}
	vis[u]=0;
}
int main(){
	File();
	scanf("%d%d%d",&n,&m,&k);
	REP(i,1,n)scanf("%d%d",&a[i],&b[i]);
	REP(i,1,m){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	if(n<=20 && m<=100){
		dfs(1,1,0,0);
		if(ans!=inf)printf("%d\n",ans);
		else printf("no solution\n");
		return 0;
	}
	if(n<=5000 && m<=5000){
		return 0;
	}
	return 0;
}
