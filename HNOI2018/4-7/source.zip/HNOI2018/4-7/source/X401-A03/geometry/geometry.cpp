#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define y1 fuck
using namespace std;
void File(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
}
int n;
double x1,x2,y1,y2;
int main(){
	File();
	scanf("%d",&n);
	scanf("%lf%lf%lf%lf",&x1,&y1,&x2,&y2);
	printf("%.10lf\n",sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)));
	return 0;
}
