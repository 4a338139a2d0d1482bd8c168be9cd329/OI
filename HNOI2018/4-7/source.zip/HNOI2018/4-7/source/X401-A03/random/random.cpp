#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
}
template<typename T>void chckmax(T &_,T __){_=_>__ ? _ : __;}
template<typename T>void chckmin(T &_,T __){_=_<__ ? _ : __;}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define MREP(i,x) for(register int i=beg[x];i;i=E[i].last)
#define ll long long
#define inf (0x3f3f3f3f)
#define mod (998244353)
#define inv(x) qpow(x,mod-2)
const int maxn=40+10;
const int maxm=20+10;
int n,m;
ll p[maxn][maxn];
ll qpow(ll x,int b){
	ll ret=1ll,base=x;
	while(b){
		if(b&1)ret=ret*base%mod;
		base=base*base%mod;
		b>>=1;
	}
	return ret;
}
int dis[maxn][maxn],tot;
ll ans,Inv=inv(10000);
struct Tarjan{
	int stac[maxn],dfn[maxn],low[maxn],cnt,top;
	bool vis[maxn],in[maxn];
	void dfs(int u){
		vis[u]=in[u]=1;
		dfn[u]=low[u]=++cnt;
		stac[++top]=u;
		REP(i,1,n){
			int v=i;
			if(!dis[u][v])continue;
			if(in[v])chckmin(low[u],low[v]);
			else if(!vis[v]){
				dfs(v);
				chckmin(low[u],low[v]);
			}
		}
		if(dfn[u]==low[u]){
			++tot;
			while(stac[top]!=u){
				in[stac[top]]=0;
				--top;
			}
			in[u]=0;
			--top;
		}
	}
	void mem(){
		memset(vis,0,sizeof(vis));
		memset(in,0,sizeof(in));
		top=cnt=0;
	}	
}T;
void dfs(int u,int v,ll pp){
	if(u==n){
		tot=0;
		T.mem();
		REP(i,1,n)if(!T.vis[i])
			T.dfs(i);
		ans=(ans+tot*pp%mod)%mod;
		return;
	}
	if(v!=n){
		dis[u][v]=1;
		dfs(u,v+1,pp*p[u][v]%mod);
		dis[u][v]=0;
		dis[v][u]=1;
		dfs(u,v+1,pp*p[v][u]%mod);
		dis[v][u]=0;
	}
	else{
		dis[u][v]=1;
		dfs(u+1,u+2,pp*p[u][v]%mod);
		dis[u][v]=0;
		dis[v][u]=1;
		dfs(u+1,u+2,pp*p[v][u]%mod);
		dis[v][u]=0;
	}
}
int main(){
	File();
	scanf("%d%d",&n,&m);
	REP(i,1,m){
		int u,v;
		ll w;
		scanf("%d%d%lld",&u,&v,&w);
		p[u][v]=w*Inv%mod;
		p[v][u]=(10000-w)*Inv%mod;
	}
	REP(i,1,n)REP(j,1,n)if(!p[i][j] && !p[j][i] && i!=j){
		p[i][j]=p[j][i]=5000*Inv%mod;
	}
	dfs(1,2,1ll);
	REP(i,1,n*(n-1))ans=ans*10000%mod;
	cout<<ans<<endl;
	return 0;
}
