#include<cstdio>
#include<iostream>
#include<algorithm>

using namespace std;

#define fr(i,a,b) for(register int i=a;i<=b;i++)
#define travel(i,a,b) for(register int i=head[a],b=e[i].to;i!=0;i=e[i].next,b=e[i].to)
#define fmin(a,b) ((a)<(b)?(a):(b))
#define fmax(a,b) ((a)>(b)?(a):(b))

struct node{
	int x,y,id;
}a[300010];
struct edge{
	int to,next;
}e[1000010];
int n,m,k,amx,amn,cnt,ans,siz,q[300010],head[300010],fa[300010],size[300010],now[300010];
bool flag,b[300010];

inline int v_in(){
	char ch=getchar();int sum=0,f=1;
	while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
	while(isdigit(ch)) sum=(sum<<3)+(sum<<1)+(ch^48),ch=getchar();
	return sum*f;
}

inline void add(int u,int v){
	e[++cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;
}

bool cmp(const node &a,const node &b){return a.y<b.y;}

void inpt(){
	ans=amn=2000000000;
	n=v_in(),m=v_in(),k=v_in();
	fr(i,1,n) a[i].id=i,a[i].x=v_in(),a[i].y=v_in(),amx=fmax(amx,a[i].x),amn=fmin(amn,a[i].x);
	sort(a+1,a+n+1,cmp);
	fr(i,1,n) now[a[i].id]=i;
	fr(i,1,m){
		int x=now[v_in()],y=now[v_in()];
		add(x,y),add(y,x);
	}
}

int bfs(int x){
	int ans=1;
	b[x]=true;
	q[1]=x;
	int hd=0,tl=1;
	while(hd!=tl){
		if(++hd>n) hd=1;
		int u=q[hd];
		travel(i,u,v) if(!b[v]){
			b[v]=true;
			if(++tl>n) tl=1;
			q[tl]=v;
			ans++;
		}
	}
	return ans;
}

int found(int x){
	if(fa[x]==x) return x;
	return fa[x]=found(fa[x]);
}

int getans(int x){
	fr(i,1,n) fa[i]=i,b[i]=false,size[i]=1;
	fr(u,1,n) if(a[u].x<=x){
		b[u]=true;
		travel(i,u,v) if(b[v]){
			int fx=found(v),fy=found(u);
			if(fx!=fy){
				fa[fy]=fx;
				size[fx]+=size[fy];
				if(size[fx]>=k) return a[u].y;
			}
		}
	}
	return 2000000000-x;
}

void three_split(){
	int l=amn,r=amx;
	while(l<r){
		if(l>=r-2){
			int x=getans(l),y=getans(r),z=getans(l+1);
			ans=fmin(ans,x+l);
			ans=fmin(ans,y+r);
			ans=fmin(ans,l+1+z);
			return;
		}
		long long xcc=((long long)l+(long long)l+(long long)r)/3;
		int lmid=xcc,rmid=l+r-lmid;
		int x=getans(lmid),y=getans(rmid);
		ans=fmin(ans,x+lmid);
		ans=fmin(ans,y+rmid);
		if(x+lmid<y+rmid) r=rmid;
		else l=lmid;
	}
}

int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	inpt();
	fr(i,1,n) if(!b[i]){
		int x=bfs(i);
		siz=fmax(siz,x);
	}
	if(siz<k){
		printf("no solution\n");
		return 0;
	}
	three_split();
	printf("%lld\n",ans);
	return 0;
}
