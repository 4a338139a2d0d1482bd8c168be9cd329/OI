#include<cstdio>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

#define fr(i,a,b) for(register int i=a;i<=b;i++)
#define fmin(a,b) ((a)<(b)?(a):(b))
#define fmax(a,b) ((a)>(b)?(a):(b))

int n,x[2010],y[2010];

inline int v_in(){
	char ch=getchar();int sum=0,f=1;
	while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
	while(isdigit(ch)) sum=(sum<<3)+(sum<<1)+(ch^48),ch=getchar();
	return sum*f;
}

double dist(int a,int b){
	return sqrt((x[a]-x[b])*(x[a]-x[b])+(y[a]-y[b])*(y[a]-y[b]));
}

void inpt(){
	n=v_in();
	fr(i,1,n) x[i]=v_in(),y[i]=v_in();
	fr(i,n+1,n+n) x[i]=v_in(),y[i]=v_in();
}

int main(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	inpt();
	if(n==1){
		printf("%.12lf\n",dist(1,2));
		return 0;
	}
	else{
		printf("-1.0\n");
		return 0;
	}
}
