#include<bits/stdc++.h>
using namespace std;

int n,m,k;

namespace Work{

typedef long long ll;
const int maxn=1010,oo=2.1e9;
int G[maxn][maxn];
int a[maxn],b[maxn],t[maxn],vis[maxn],tag[maxn];
int ans=oo;

bool chk(bool flag=0){
	queue<int> Q;
	memset(tag,0,sizeof tag);
	int sz=0;
	Q.push(t[1]);tag[t[1]]=1;
	for(int u;!Q.empty();){
		u=Q.front();Q.pop();
		++sz;
		for(int i=1;i<=n;++i)
			if(G[u][i]!=oo&&vis[i]&&!tag[i]){
				tag[i]=1;
				Q.push(i);
			}
	}
	if(sz<k)return 0;
	return 1;
}

void dfs(int x,int ls){
	if(x>k){
		if(!chk())return;
		int A=0,B=0;
		for(int i=1;i<=k;++i){
			A=max(a[t[i]],A);
			B=max(b[t[i]],B);
		}
		if(ans>A+B){
			ans=A+B;
		}
		return;
	}
	for(int i=ls+1;i<=n;++i){
		t[x]=i;
		vis[i]=1;
		dfs(x+1,i);
		vis[i]=0;
	}
}

void work(){
	for(int i=1;i<=n;++i){
		scanf("%d%d",a+i,b+i);
	}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			G[i][j]=oo;
	for(int i=1,u,v;i<=m;++i){
		scanf("%d%d",&u,&v);
		G[u][v]=G[v][u]=1;
	}
	dfs(1,0);
	if(ans==oo)puts("no solution");
	else printf("%d\n",ans);
	//err<<ans<<endl;
}

}

namespace WORK{
	const int maxn=3e5+10;
struct data{
	int a,b,id;
}p[maxn];
bool cmpa(data A,data B){
	if(A.a!=B.a)return A.a<B.a;
	return A.b<B.b;
}
bool cmpb(data A,data B){
	if(A.b!=B.b)return A.b<B.b;
	return A.a<B.a;
}

const int oo=2.1e9;

int f[maxn],ans=oo;
int A[maxn],B[maxn],sz[maxn];
int id[maxn];

vector<int> G[maxn];

int F(int x){
	if(f[x]==x)return x;
	else return f[x]=F(f[x]);
}

bool Mrg(int u,int v){
	int x=F(u),y=F(v);
	if(x==y)return 0;

	sz[y]+=sz[x];
	A[y]=max(A[y],A[x]);
	B[y]=max(B[y],B[x]);

	f[x]=y;
	
	return sz[y]>=k;
}

void chk(int x){
	int u=F(x);
	//ans=min(ans,A[u]+B[u]);
	if(ans>A[u]+B[u]){
		ans=A[u]+B[u];
		
		/*for(int i=1;i<=n;++i){
			if(F(i)==u)cerr<<i<<" ";
		}
		//cerr<<u<<" "<<sz[u]<<endl;

		cerr<<endl;*/
	}
}

void solve(){
	//scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i){
		scanf("%d%d",&p[i].a,&p[i].b);
		p[i].id=i;
	}
	for(int i=1,u,v;i<=m;++i){
		scanf("%d%d",&u,&v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	sort(p+1,p+n+1,cmpa);
	for(int i=1;i<=n;++i){
		f[i]=i;
		sz[i]=1;
		A[p[i].id]=p[i].a;
		B[p[i].id]=p[i].b;
		id[p[i].id]=i;
	}
	for(int i=2,ii;ii=p[i].id,i<=n;++i)
		for(int j=0;j<G[ii].size();++j)
			if(id[G[ii][j]]<i)
				if(Mrg(G[ii][j],ii))chk(ii);
	sort(p+1,p+n+1,cmpb);
	for(int i=1;i<=n;++i){
		f[i]=i;
		sz[i]=1;
		A[p[i].id]=p[i].a;
		B[p[i].id]=p[i].b;
		id[p[i].id]=i;
	}
	for(int i=2,ii;ii=p[i].id,i<=n;++i)
		for(int j=0;j<G[ii].size();++j)
			if(id[G[ii][j]]<i)
				if(Mrg(G[ii][j],ii))chk(ii);

	if(ans==oo)puts("no solution");
	else cout<<ans<<endl;
}
}
void solve(){
	scanf("%d%d%d",&n,&m,&k);
	if(n<=20){
		Work::work();
		return;
	}
	WORK::solve();
}
int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
