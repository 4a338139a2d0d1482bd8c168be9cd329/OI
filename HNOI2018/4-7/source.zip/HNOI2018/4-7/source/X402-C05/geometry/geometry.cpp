#include<bits/stdc++.h>
using namespace std;
int n;
double X1,X2,Y1,Y2;
void solve(){
	scanf("%d",&n);
	if(n==1){
		scanf("%lf%lf",&X1,&Y1);
		scanf("%lf%lf",&X2,&Y2);
		X1-=X2;
		Y1-=Y2;
		printf("%.14lf\n",sqrt(X1*X1+Y1*Y1));
	}
}
int main(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
