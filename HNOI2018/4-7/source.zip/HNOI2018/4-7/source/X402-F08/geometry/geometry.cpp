#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=1000+10;
struct node {
	ll x,y;
}a[maxn],b[maxn];
int n;
dd ans;

inline void file() {
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
}

inline void read(ll &x) {
	x=0;
	ll p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

dd dist(node &aa,node &bb) {
	return sqrt((dd)(aa.x-bb.x)*(aa.x-bb.x)+(dd)(aa.y-bb.y)*(aa.y-bb.y));
}

int main() {
	file();
	scanf("%d",&n);
	For (i,1,n) read(a[i].x),read(a[i].y);
	For (i,1,n) read(b[i].x),read(b[i].y);
	For (i,1,n) ans+=dist(a[i],b[i]);
	For (i,1,n-1) ans+=dist(a[i],b[i+1]);
	printf("%.13lf\n",ans);
	return 0;
}
