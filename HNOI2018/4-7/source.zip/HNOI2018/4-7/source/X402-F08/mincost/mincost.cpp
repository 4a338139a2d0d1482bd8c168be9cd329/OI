#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=50;
const ll inf=1e15;
int n,m,k;
int N;
ll ans=inf;
int vis[maxn],s[maxn][maxn];
ll a[maxn],b[maxn];

inline void file() {
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

void dfs(int u) {
	vis[u]++;
	For (i,0,n-1)
		if (s[u][i]) {
			if (vis[i]!=1) continue;
			dfs(i);
		}
}

int main() {
	file();
	read(n); read(m); read(k);
	For (i,1,n) scanf("%lld%lld",&a[i-1],&b[i-1]);
	For (i,1,m) {
		int x,y; read(x); read(y); --x; --y;
		s[x][y]=s[y][x]=1;
	}
	N=1<<n;
	For (i,0,N-1)
		if (__builtin_popcount(i)==k) {
			Set(vis,0);
			int k=0;
			ll aa=0,bb=0;
			For (j,0,n-1) if (i&(1<<j))
			{ chkmax(aa,a[j]); chkmax(bb,b[j]); k=j; vis[j]=1; }
			dfs(k);
			int flag=1;
			For(j,0,n-1) if (vis[j]==1) { flag=0; break; }
			if (flag) chkmin(ans,aa+bb);
		}
	if (ans==inf) printf("no solution");
	else printf("%lld",ans);
	return 0;
}
