#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<stack>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=100;
const ll modd=998244353;
struct edge {
	int from,to,val,next;
}e[maxn];
int n,m,M;
int tot,cnt,dfs_cnt;
ll Inv,ans;
int head[maxn],vis[maxn],pre[maxn],low[maxn],scc[maxn],s[maxn][maxn];
stack<int>st;

inline void file() {
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void add(int from,int to,int val) {
	tot++; e[tot].from=from;
	e[tot].to=to; e[tot].val=val; e[tot].next=head[from]; head[from]=tot;
}

inline ll quick(ll aa,ll bb) {
	aa%=modd;
	ll ss=1;
	while (bb) {
		if (bb%2) ss=ss*aa%modd;
		aa=aa*aa%modd; bb/=2;
	}
	return ss%modd;
}

void dfs(int u) {
	st.push(u);
	pre[u]=low[u]=++dfs_cnt;
	for (int i=head[u];i!=0;i=e[i].next) {
		if (!vis[i]) continue;
		int v=e[i].to;
		if (!pre[v]) {
			dfs(v);
			low[u]=min(low[u],low[v]);
		}
		else if (!scc[v]) low[u]=min(low[u],pre[v]);
	}
	if (pre[u]==low[u]) {
		cnt++;
		while (1) {
			int p=st.top(); st.pop();
			scc[p]=cnt;
			if (u==p) break;
		}
	}
}

int main() {
	file();
	read(n); read(m);
	For (i,0,m-1) {
		int x,y,z; read(x); read(y); read(z);
		s[x][y]=s[y][x]=1;
		add(x,y,z); add(y,x,10000-z);
	}
	For (i,1,n)
		For (j,i+1,n)
			if (!s[i][j]) {
				add(i,j,5000); add(j,i,5000);
				m++;
				s[i][j]=s[j][i]=1;
			}
	Inv=quick(10000,modd-2);
	M=(1<<m);
	For (i,0,M-1) {
		dfs_cnt=0; cnt=0;
		Set(vis,0); Set(pre,0); Set(low,0); Set(scc,0);
		while (st.size()) st.pop();
		ll p=1;
		For (j,0,m-1)
			if (i&(1<<j)) {
				vis[2*j+1]=1; p=p*e[2*j+1].val%modd*Inv%modd;
			}
			else {
				vis[2*j+2]=1; p=p*e[2*j+2].val%modd*Inv%modd;
			}
		For (i,1,n)
			if (!pre[i]) dfs(i);
//		cout << cnt << " " << p << endl;
		(ans+=p*cnt)%=modd;
	}
	printf("%lld\n",ans*quick(10000,n*(n-1))%modd);
	return 0;
}
