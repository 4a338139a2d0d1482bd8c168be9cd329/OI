#include<bits/stdc++.h>
#define Travel(i, u) for(register int i = beg[u], v = to[i]; i; i = nex[i], v = to[i])
#define mem(a, b) memset(a, b, sizeof(a))
#define For(i, j, k) for(register int i = (j); i <= (k); ++i)
#define Forr(i, j, k) for(register int i = (j); i >= (k); --i)
using namespace std;

template <typename T>
inline void read(T &x){
	T p = 1, c = getchar();
	x = 0;
	while(!isdigit(c)){
		if(c == '-') p = -1;
		c = getchar();
	}
	while(isdigit(c)){
		x = (x << 1) + (x << 3) + (c ^ 48);
		c = getchar();
	}
	x *= p;
}

template<typename T> inline bool chkmin(T &a, T b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }

inline void File(){
#ifndef ONLINE_JUDGE
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);
#endif
}

const int N = 5e3 + 10, M = 5e3 + 10;
int e = 1, beg[M], nex[M << 1], to[M << 1];
int n, m, k, ans = INT_MAX;
int A[N], B[N], tag[N], vis[N];
int Q[N], cnt, maxa, maxb;

inline void add_edge(int x, int y){
	to[++e] = y, nex[e] = beg[x], beg[x] = e;
}

inline void Input(){
	read(n), read(m), read(k);
	For(i, 1, n) read(A[i]), read(B[i]);
	For(i, 1, m){
		int x, y;
		read(x), read(y);
		add_edge(x, y);
		add_edge(y, x);
	}
}

namespace Subtask1{

	void Do(int u){
		Travel(i, u){
			if(vis[v] || !tag[v]) continue;
			Q[++cnt] = v;
			vis[v] = 1;
			Do(v);
		}
	}

	bool check(){
		cnt = 1; 
		For(i, 1, n) vis[i] = 0;
		For(i, 1, n) if(tag[i]) {
			Q[1] = i, vis[Q[1]] = 1; 
			break;
		}
		Do(Q[1]);
		
		For(i, 1, n) if(tag[i] && !vis[i]) return false;
		return true;
	}

	void dfs(int x, int pos){
		if(x == k + 1){
			if(check()){
				maxa = maxb = 0;
				For(i, 1, cnt){
					chkmax(maxa, A[Q[i]]);
					chkmax(maxb, B[Q[i]]);
				}
				chkmin(ans, maxa + maxb);
			}
			return ;
		}
		For(i, pos, n){
			tag[i] = 1;
			dfs(x + 1, i + 1);
			tag[i] = 0;
		}
	}

}

namespace Subtask2{

	void find(int i){

		cnt = 1, Q[1] = i, mem(vis, 0);
		queue<int> que;
		vis[i] = 1, que.push(i);
		while(!que.empty()){
			int u = que.front();
			que.pop(); ++cnt;
			
			Travel(i, u){
				if(vis[v]) continue;
				vis[v] = 1, que.push(v);
				Q[cnt] = v;
				if(cnt == k){
					//cout<<maxa + maxb<<endl;
					For(i, 1, cnt){
						chkmax(maxa, A[Q[i]]);
						chkmax(maxb, B[Q[i]]);
					}

					chkmin(ans, maxa + maxb);
					return ;
				}
			}

		}

	}

	inline void Solve(){
		For(i, 1, n){
			maxa = maxb = 0;
			find(i);
		}
		printf("%d\n", ans);
	}

}

int main(){
	File();
	Input();
	if(n <= 20 && m <= 100){
		Subtask1::dfs(1, 1);
		printf("%d\n", ans);
		return 0;
	}
	Subtask2::Solve();
	return 0;
}

