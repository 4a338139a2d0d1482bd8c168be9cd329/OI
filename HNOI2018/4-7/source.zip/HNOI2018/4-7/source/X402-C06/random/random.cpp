#include<bits/stdc++.h>
#define mem(a, b) memset(a, b, sizeof(a))
#define For(i, j, k) for(register int i = (j); i <= (k); ++i)
#define Forr(i, j, k) for(register int i = (j); i >= (k); --i)
using namespace std;

template <typename T>
inline void read(T &x){
	T p = 1, c = getchar();
	x = 0;
	while(!isdigit(c)){
		if(c == '-') p = -1;
		c = getchar();
	}
	while(isdigit(c)){
		x = (x << 1) + (x << 3) + (c ^ 48);
		c = getchar();
	}
	x *= p;
}

template<typename T> inline bool chkmin(T &a, T b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }

inline void File(){
#ifndef ONLINE_JUDGE
	freopen("random.in", "r", stdin);
	freopen("random.out", "w", stdout);
#endif
}

typedef long long ll;
const int N = 38 + 5;
const ll mod = 998244353;
int n, m;
int G[N][N], tot;
ll ans, inv, S[N][N];

ll ksm(ll a, ll b){
	ll res = 1;
	while(b){
		if(b & 1) (res *= a) %= mod;
		(a *= a) %= mod;
		b >>= 1;
	}
	return res;
}

namespace Tarjan{
	int Sta[N], dfn[N], low[N], cnt, top, v;
	bool vis[N], in[N];
	
	inline void Clear(){
		top = cnt = 0;
		mem(vis, 0), mem(in, 0);
	}	

	void dfs(int x){
		vis[x] = in[x] = 1, ++cnt;
		Sta[++top] = x;
		low[x] = dfn[x] = cnt;
	
		For(i, 1, n){
			if(!G[x][i]) continue ;
			if(in[i]) chkmin(low[x], low[i]);
			else if(!vis[i]){
				dfs(i);
				chkmin(low[x],low[i]);
			}
		}
	
		if(dfn[x] == low[x]){
			++tot;
			while(Sta[top] != x){
				in[Sta[top]] = 0;
				--top;
			}
			--top, in[x] = 0;
		}
	}
}

inline void Input(){
	read(n), read(m);
	inv = ksm(10000, mod - 2);
	For(x, 1, n - 1) For(y, x + 1, n)
		S[x][y] = S[y][x] =	1ll * 5000 * inv % mod; 
	For(i, 1, m){
		int x, y, z;
		read(x), read(y), read(z);
		S[x][y] = 1ll * z * inv % mod;
		S[y][x] = 1ll * (10000 - z) * inv % mod; 
	}
}

void dfs(int x, int y, ll val){
	if(x == n){
		tot = 0, Tarjan::Clear();
		For(i, 1, n) if(!Tarjan::vis[i]) Tarjan::dfs(i);
		(ans += 1ll * tot * val % mod) %= mod;
		return ;
	}
	if(y != n){
		G[x][y] = 1;
		dfs(x, y + 1, val * S[x][y] % mod);
		G[x][y] = 0;

		G[y][x] = 1;
		dfs(x, y + 1, val * S[y][x] % mod);
		G[y][x] = 0;
	}
	else{
		G[x][y] = 1;
		dfs(x + 1, x + 2, val * S[x][y] % mod);
		G[x][y] = 0;

		G[y][x] = 1;
		dfs(x + 1, x + 2, val * S[y][x] % mod);
		G[y][x] = 0;
	}
}

int main(){
	File();
	Input();	
	dfs(1, 2, 1);
	(ans *= ksm(10, 1ll * 4 * n * (n - 1))) %= mod;
	printf("%lld\n", ans);
	return 0;
}

