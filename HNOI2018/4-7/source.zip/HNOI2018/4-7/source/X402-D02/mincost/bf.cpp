#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define x first
#define y second

inline void check_max(int a,int &b){if(a>b)b=a;}
inline void check_min(int a,int &b){if(a<b)b=a;}
inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace orzmyy
{
	typedef std::pair<int,int> pii;
	const int N=100010,INF=2147483647;

	struct dus
	{
		int q[N],siz[N];
		void reset(int n){for(int i=1;i<=n;i++)q[i]=i,siz[i]=1;}
		int ask(int p){return p==q[p]?p:q[p]=ask(q[p]);}
		bool uni(int u,int v){return ask(u)==ask(v);}
		void link(int u,int v)
		{
			if(uni(u,v))return;
			u=ask(u),v=ask(v);
			siz[v]+=siz[u];
			q[u]=v;
		}
		int query(int p)
		{
			return siz[ask(p)];
		}
	}d;

	int begin[N],next[N*2],to[N*2];
	int A[N],B[N];
	int n,m,k,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	
	pii s[N];
	void initialize()
	{
		read(n),read(m),read(k);
		for(int i=1;i<=n;i++)
			read(A[i]),read(B[i]),s[i]=pii(A[i],i);
		for(int i=1,u,v;i<=m;i++)
			read(u),read(v),add(u,v);
		std::sort(s+1,s+n+1);
	}

	bool vis[N];
	pii t[N];

	int calc(int l)
	{
		memset(vis,0,sizeof(vis));
		for(int i=1;i<=l;i++)
			t[i]=pii(B[s[i].y],s[i].y);

		std::sort(t+1,t+l+1);
		d.reset(n);
		for(int o=1;o<=l;o++)
		{
			int p=t[o].y;
			vis[p]=1;
			for(int i=begin[p],q;i;i=next[i])
				if(vis[q=to[i]])d.link(p,q);
			if(d.query(p)>=k)
			{
//				fprintf(stderr,"o = %d ,ret = %d ,233 , i : %d\n",o,t[o].x,s[l].x);
				return t[o].x;
			}
		}
		return -1;
	}

	void solve()
	{
		initialize();
		int ans=INF;
		for(int i=1;i<=n;i++)
		{
			int tmp=s[i].x,ret=calc(i);
			if(ret!=-1)check_min(tmp+ret,ans);
		}
		if(ans==INF)printf("no solution\n");
		else printf("%d\n",ans);
	}
}

int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.ans","w",stdout);
	orzmyy::solve();
	
	fprintf(stderr,"bf : time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
