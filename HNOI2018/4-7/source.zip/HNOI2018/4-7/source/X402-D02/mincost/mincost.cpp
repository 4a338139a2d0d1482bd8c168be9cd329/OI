#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<set>
#include<queue>
#include<cassert>
#define x first
#define y second

inline void check_max(int a,int &b){if(a>b)b=a;}
inline void check_min(int a,int &b){if(a<b)b=a;}
inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace NanXieTi_orz
{
	typedef std::pair<int,int> pii;
	const int N=301000,M=500100,INF=2147483647;
	
	struct LincolnTree
	{
#define L(p) (st[p][0])
#define R(p) (st[p][1])
#define F(p) (fa[p])
#define P(p) (st[fa[p]][1]==p)
		pii w[N+M];
		int st[N+M][2],fa[N+M];
		int siz[N+M],a[N+M],b[N+M],c[N+M];

		pii maxc[N+M],ds[N+M];
		std::multiset<pii> S[N+M];

		bool rev[N+M];

		inline bool isr(int p){return L(F(p))!=p && R(F(p))!=p;}
		inline void upd(int p)
		{
			siz[p]=siz[L(p)]+siz[R(p)]+a[p];
			w[p]=std::max(w[L(p)],w[R(p)]);
			w[p]=std::max(w[p],pii(b[p],p));

			maxc[p]=std::max(maxc[L(p)],maxc[R(p)]);
			maxc[p]=std::max(maxc[p],pii(c[p],p));
			maxc[p]=std::max(maxc[p],ds[p]);
//			if(!S[p].empty())maxc[p]=std::max(maxc[p],*(--S[p].end()));
		}
		inline void down(int p)
		{
			if(rev[p])
			{
				std::swap(L(p),R(p));
				rev[L(p)]^=1;
				rev[R(p)]^=1;
				rev[p]=0;
			}
		}
		void Down(int p)
		{
			if(!isr(p))Down(F(p));
			down(p);
		}
		void rot(int p)
		{
			register int f=F(p),h=F(f),i=P(p),j=P(f),s=st[p][i^1];
			if(isr(f))fa[p]=h;
			else st[fa[p]=h][j]=p;
			st[fa[f]=p][i^1]=f;
			st[fa[s]=f][i]=s;
			upd(f);
		}
		void splay(int p)
		{
			Down(p);
			for(int f;!isr(p);rot(p))
				if(isr(f=F(p)));else if(P(p)^P(f))rot(p);
				else rot(f);
			upd(p);
		}
		void access(int p)
		{
			splay(p);
			a[p]+=siz[R(p)];
			if(R(p))
			{
				S[p].insert(maxc[R(p)]);
				ds[p]=*(--S[p].end());
			}
			R(p)=0,upd(p);

			for(register int f;(f=F(p))!=0;rot(p),upd(p))
			{
				splay(f);

				a[f]-=siz[p];
				a[f]+=siz[R(f)];

				S[f].erase(S[f].find(maxc[p]));
				if(R(f))S[f].insert(maxc[R(f)]);

				if(S[f].empty())ds[f]=pii(0,0);
				else ds[f]=*(--S[f].end());

				R(f)=p;
			}
		}
		inline void setrt(int p)
		{
			access(p);
			rev[p]=1;
		}
		inline void link(int u,int v)
		{
			setrt(u),access(v);
			fa[u]=v;

			a[v]+=siz[u];

			S[v].insert(maxc[u]);
			ds[v]=*(--S[v].end());

			upd(v);
		}
		inline void cut(int u,int v)
		{
			setrt(v),access(u);
			if(L(u)!=v)return;
			L(u)=F(v)=0,upd(u);
		}
		inline int query(int p)
		{
			access(p);
			return siz[p];
		}
		inline int query_max(int u,int v)
		{
			setrt(v),access(u);
			return w[u].y;
		}
		inline int query_max_in_tree(int p)
		{
//			access(p);
			while(F(p))p=F(p);
			return maxc[p].y;
		}
		inline bool uni(int u,int v)
		{
			while(F(u))u=F(u);
			while(F(v))v=F(v);
			return u==v;
//			setrt(u);
//			access(v);
//			while(L(v))v=L(v);
//			return u==v;
		}
#undef L
#undef R
#undef F
#undef P
	}T;

	int mw[N];

	pii E[M];
	int begin[N],next[M*2],to[M*2],w[M];
	int A[N],B[N];

	int n,m,Lim,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	void initialize()
	{
		static pii tmp[N];
		read(n),read(m),read(Lim),e=1;
		for(int i=1;i<=n;i++)
			read(A[i]),read(B[i]),tmp[i]=pii(B[i],i);

		std::sort(tmp+1,tmp+n+1);
		for(int i=1;i<=n;i++)
			mw[i]=tmp[i].x,B[tmp[i].y]=i;

		for(int i=1,u,v;i<=m;i++)
		{
			read(u),read(v);
			add(u,v);
			E[i]=pii(u,v);
			w[i]=std::max(B[u],B[v]);
		}

		for(int i=1;i<=n;i++)T.a[i]=1,T.b[i]=0,T.c[i]=B[i];
		for(int i=n+1;i<=n+m;i++)T.a[i]=0,T.b[i]=w[i-n],T.c[i]=0;
		for(int i=1;i<=n+m;i++)T.upd(i);
	}

	bool vis[N];

	void add_edge(int id)
	{
		register int p=id+n,u=E[id].x,v=E[id].y;
		if(!T.uni(u,v)){T.link(p,u),T.link(p,v);return;}

		register int q=T.query_max(u,v),qid=q-n,qu=E[qid].x,qv=E[qid].y;
		if(w[qid]<w[id])return;
		T.cut(q,qu),T.cut(q,qv);
		T.link(p,u),T.link(p,v);
	}
	inline void del_edge(int id)
	{
		register int p=id+n,u=E[id].x,v=E[id].y;
		if(!vis[u] || !vis[v])return;
		T.cut(p,u),T.cut(p,v);
	}
	inline void del(int p)
	{
//		printf("rm -> %d\n",p);
		for(int i=begin[p];i;i=next[i])
			del_edge(i/2);
		vis[p]=0;
	}

	int ans;

	void fuckit()
	{
		static pii s[N];

		for(int i=1;i<=n;i++)s[i]=pii(A[i],i);
		std::sort(s+1,s+n+1);

		for(int o=1;o<=n;o++)
		{
//			if(o%10000==0)fprintf(stderr,"o = %d\n",o);
			register int p=s[o].y;

			vis[p]=1;
			for(int i=begin[p];i;i=next[i])
				if(vis[to[i]])add_edge(i/2);

			while(vis[p] && T.query(p)>=Lim)
			{
				int q=T.query_max_in_tree(p);
				check_min(mw[B[q]]+s[o].x,ans);
				del(q);
			}
		}
	}

	void solve()
	{
		initialize();

		ans=INF,fuckit();

		if(ans==INF)printf("no solution\n");
		else printf("%d\n",ans);
	}
}

int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	NanXieTi_orz::solve();
//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
