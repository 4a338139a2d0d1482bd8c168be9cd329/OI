#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<set>

FILE* seed,in;

typedef std::pair<int,int> pii;
std::set<pii> S;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("mincost.in","w",stdout);//look at here

	int n=300000,m=500000,lim=rand()%std::min(n,2333333)+1,w=1000000;

	n=3000,m=5000;

	printf("%d %d %d\n",n,m,lim);
	for(int i=1;i<=n;i++)
		printf("%d %d\n",rand()%w+1,rand()%w+1);

	for(int i=2;i<=n;i++)
	{
		int u=rand()%(i-1)+1,v=i;
		printf("%d %d\n",u,v);
		S.insert(pii(u,v)),S.insert(pii(v,u));
	}

	m-=n-1;
	for(int i=1;i<=m;i++)
	{
		int u=rand()%n+1,v=rand()%n+1;
		while(u==v || S.count(pii(u,v)))u=rand()%n+1,v=rand()%n+1;
		printf("%d %d\n",u,v);
		S.insert(pii(u,v)),S.insert(pii(v,u));
	}

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());

	fprintf(stderr,"gen time = %lf\n",(double)clock()/CLOCKS_PER_SEC);

	return 0;
}
