#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
#endif
}
static int n;
namespace subtask1
{
	static long long x,y,u,v;
	int main()
	{
		read(x);read(y);read(u);read(v);
		return printf("%.14lf\n",sqrt((x-u)*(x-u)+(y-v)*(y-v))),0;
	}
}
const int MAXN=1111;
static struct node
{
	int x,y;
}p[MAXN],q[MAXN];
static double w[MAXN<<1][MAXN<<1];
#define dis(a,b) sqrt(1.0*(p[a].x-q[b].x)*(p[a].x-q[b].x)+1.0*(p[a].y-q[b].y)*(p[a].y-q[b].y))
#define Chkmin(a,b) a=a<b?a:b
inline long long cross(int x,int y,int u,int v)
{return 1ll*x*v-1ll*y*u;}
const double MAX=DBL_MAX/1.1;
namespace subtask2
{
	static double dp[1<<21][21],ans=DBL_MAX;
	int main()
	{
		Rep(i,1,n)Rep(j,1,n)
		{
			if(p[i].x<=q[j].x)
			{
				if(i==n||p[i+1].x>=q[j].x)w[i][j+n]=dis(i,j);
				else if(cross(p[i+1].x-p[i].x,p[i+1].y-p[i].y,q[j].x-p[i].x,q[j].y-p[i].y)<0)
					w[i][j+n]=dis(i,j);
				else w[i][j+n]=MAX+1;
			}
			else
			{
				if(i==1||p[i-1].x<=q[j].x)w[i][j+n]=dis(i,j);
				else if(cross(p[i].x-p[i-1].x,p[i].y-p[i-1].y,p[i].x-q[j].x,p[i].y-q[j].y)>0)
					w[i][j+n]=dis(i,j);
				else w[i][j+n]=MAX+1;
			}
			w[j+n][i]=w[i][j+n];
		}
		Rep(i,1,n)Rep(j,1,n)w[i][j]=w[i+n][j+n]=MAX+1;
		n<<=1;
		Rep(i,0,(1<<n)-1)Rep(j,1,n)dp[i][j]=MAX+1;
		Rep(i,1,n)dp[1<<i-1][i]=0;
		Rep(i,1,(1<<n)-1)Rep(j,1,n)if(dp[i][j]<MAX)
			Rep(k,1,n)if(w[j][k]<MAX&&!(i&(1<<k-1)))
				Chkmin(dp[i^(1<<k-1)][k],dp[i][j]+w[j][k]);
		Rep(i,1,n)Chkmin(ans,dp[(1<<n)-1][i]);
		printf("%.14lf\n",ans>1e11?-1.0:ans);
		return 0;
	}
}
int main()
{
	file();
	read(n);
	if(n==1)return subtask1::main();
	Rep(i,1,n)read(p[i].x),read(p[i].y);
	Rep(i,1,n)read(q[i].x),read(q[i].y);
	if(n<=10)return subtask2::main();
	return 0;
}

