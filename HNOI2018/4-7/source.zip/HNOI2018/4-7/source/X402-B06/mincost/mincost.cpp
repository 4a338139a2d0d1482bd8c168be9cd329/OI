#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
#define Chkmax(a,b) a=a>b?a:b
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
#endif
}
const int MAXN=3e5+7;
static struct node
{
	int a,b,id;
	friend bool operator<(node a,node b)
	{return a.a^b.a?a.a<b.a:a.b<b.b;}
}p[MAXN];
static vector<int>ed[MAXN];
static int n,m,k,ans;
static int rt[MAXN],b1[MAXN],tt1,b2[MAXN],tt2;
#define Find(x) lower_bound(b1+1,b1+tt1+1,x)-b1
#define Fid(x) lower_bound(b2+1,b2+tt2+1,x)-b2
bool cmp(int a,int b){return p[a].b<p[b].b;}
static int fa[MAXN],w[MAXN];

struct INT
{
	int x;
	friend bool operator<(INT a,INT b){return p[a.x].b>p[b.x].b;}
};
priority_queue<INT,vector<INT>,less<INT> >G;

bool has;
int find(int a)
{return fa[a]==a?a:fa[a]=find(fa[a]);}
void merge(int a,int b)
{if((a=find(a))^(b=find(b)))fa[a]=b,w[b]+=w[a];if(w[b]>=k)has=true;}

int main()
{
	file();
	read(n);read(m);read(k);
	if(k>n)return puts("no solution"),0;
	Rep(i,1,n)read(p[i].a),read(p[i].b),p[i].id=i,b1[i]=p[i].a,b2[i]=p[i].b;
	if(n==1)
	{
		if(!k)return puts("0"),0;
		if(k==1)return printf("%d\n",p[1].a+p[1].b),0;
	}
	sort(b1+1,b1+n+1);tt1=unique(b1+1,b1+n+1)-b1-1;
	sort(b2+1,b2+n+1);tt2=unique(b2+1,b2+n+1)-b2-1;
	static int u,v;
	sort(p+1,p+n+1);
	Rep(i,1,m){read(u);read(v);if(p[u].b<p[v].b)swap(u,v);ed[u].push_back(v);}
	ans=2e9+7;
	Rep(i,1,tt1)
	{
		if(ans<=b1[i])break;
		Rep(j,1,n)
		{
			if(p[j].a>b1[i])break;
			G.push((INT){j});
		}
		memset(fa,0,sizeof fa);memset(w,0,sizeof w);
		Rep(j,1,tt2)
		{
			if(ans<=b1[i]+b2[j])break;
			has=false;
			while(!G.empty())
			{
				u=G.top().x;
				if(p[u].b>b2[j])break;
				u=p[u].id;
				w[u]=1;fa[u]=u;G.pop();
				for(auto v:ed[u])
				{
					cerr<<u<<' '<<v<<' '<<p[v].a<<endl;
					if(p[v].a<=b1[i])merge(v,u);
				}
			}
			if(has)ans=b1[i]+b2[j];
			Rep(t,1,n)cerr<<w[t]<<' ';cerr<<endl;
			Rep(t,1,n)cerr<<fa[t]<<' ';cerr<<endl;
			cerr<<endl;
		}
	}
	if(ans>=2e9)puts("no solution");
	else printf("%d\n",ans);
	return 0;
}

