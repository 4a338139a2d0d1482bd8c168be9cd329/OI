#include<bits/stdc++.h>
using namespace std;
const int maxn=6010;
int fst[maxn],lst[maxn],to[maxn],e;
inline void add(int x,int y){
	to[++e]=y,lst[e]=fst[x],fst[x]=e;
	to[++e]=x,lst[e]=fst[y],fst[y]=e;
}
int vis[maxn],p[maxn];
int n,m,k,ans=2147483647,a[maxn],b[maxn];
inline bool findpath(int x){
	memset(vis,0,sizeof(vis));
	queue<int>q;
	q.push(x);
	vis[x]=1;
	while(!q.empty()){
		int u=q.front();q.pop();
		for(register int i=fst[u];i;i=lst[i]){
			int v=to[i];
			if(vis[v]||!p[v])continue;
			vis[v]=1;
			q.push(v);
		}
	}
	//for(register int i=1;i<=n;++i)printf("|%d",vis[i]);
	//cout<<endl;
	for(register int i=1;i<=n;++i){
		if(!p[i])continue;
		if(!vis[i])return false;
	}return true;
}
inline int check(){
	int tmp=0;
	for(register int i=1;i<=n;++i){
		if(!p[i])continue;
		++tmp;
	}if(k!=tmp)return 2147483647;
	//for(register int i=1;i<=n;++i)printf("%d ",p[i]);
	//cout<<endl;
	for(register int i=1;i<=n;++i){
		if(p[i]){
			tmp=i;
			break;
		}
	}
	if(!findpath(tmp))return 2147483647;
	int tmp1=-2147483647,tmp2=-2147483647;
	for(register int i=1;i<=n;++i){
		if(!p[i])continue;
		tmp1=max(tmp1,a[i]);
		tmp2=max(tmp2,b[i]);
	}return tmp1+tmp2;
}
inline void dfs(int x){
	if(x>n){
		ans=min(ans,check());
		return;
	}p[x]=1;
	dfs(x+1);
	p[x]=0;
	dfs(x+1);
}
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<1)+(x<<3)+ch-48;
	return x*f;
}
int main(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	n=read(),m=read(),k=read();
	if(n>25){
		printf("no solution\n");
		return 0;
	}
	int x,y;
	for(register int i=1;i<=n;++i)a[i]=read(),b[i]=read();
	for(register int i=1;i<=m;++i)x=read(),y=read(),add(x,y);
	dfs(1);
	if(ans==2147483647)printf("no solution\n");
	else cout<<ans<<endl;
	return 0;
}
