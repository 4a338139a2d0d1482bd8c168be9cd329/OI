#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	int n;
	double a,b,c,d;
	cin>>n;
	scanf("%lf%lf%lf%lf",&a,&b,&c,&d);
	scanf("%.10lf\n",sqrt((a-c)*(a-c)+(b-d)*(b-d)));
	return 0;
}
