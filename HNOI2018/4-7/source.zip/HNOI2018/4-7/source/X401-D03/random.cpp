#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=550,maxm=50050;
const ll mod=998244353,inv=796898467;
ll f[maxn][maxn];
int g[maxn][maxn],r[maxn][maxn];
ll ans;
int n,m,low[maxn],dfn[maxn],vis[maxn],cnt,cnt1;
int s[maxn],top;
inline void add(int x,int y,int z){
	f[x][y]=z*inv%mod;
	f[y][x]=(1-f[x][y]+mod)%mod;
}
ll Pow(ll x,ll y){
	ll ans=1;
	for(;y;y>>=1){
		if(y&1)ans=ans*x%mod;
		x=x*x%mod;
	}return ans;
}
inline void tarjan(int x){
	dfn[x]=low[x]=++cnt1;
	s[++top]=x;
	vis[x]=1;
	for(register int i=1;i<=n;++i){
		if(g[x][i]){
			if(vis[i])low[x]=min(low[x],dfn[i]);
			else if(!dfn[i])tarjan(i),low[x]=min(low[i],low[x]);
		}
	}
	if(low[x]==dfn[x]){
		++cnt;
		vis[x]=0;
		while(s[top+1]!=x)vis[s[top]]=0,top--;
	}
}
inline ll getans(){
	memset(dfn,0,sizeof(dfn));
	memset(s,0,sizeof(s));
	memset(vis,0,sizeof(vis));
	memset(low,0,sizeof(low));
	cnt1=cnt=top=0;
	for(register int i=1;i<=n;++i)if(!dfn[i])tarjan(i);
	return cnt;
}
inline void dfs(int x,int y,ll p){
	if(x>n){
		ans+=getans()*p%mod;
		ans%=mod;
		return;
	}g[x][y]=1,g[y][x]=0;
	if(y+1==x)dfs(x+1,1,p*f[x][y]%mod);
	else dfs(x,y+1,p*f[x][y]%mod);
	g[y][x]=1,g[x][y]=0;
	if(y+1==x)dfs(x+1,1,p*f[y][x]%mod);
	else dfs(x,y+1,p*f[y][x]%mod);
}
int main(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	cin>>n>>m;
	int x,y;ll z;
	for(register int i=1;i<=m;++i)scanf("%d%d%lld",&x,&y,&z),add(x,y,z),r[x][y]=r[y][x]=1;
	for(register int i=1;i<=n;++i){
		for(register int j=i+1;j<=n;++j){
			if(r[i][j])continue;
			add(i,j,5000);
		}
	}
	dfs(2,1,1);
	cout<<ans*Pow(10000,(ll)n*(n-1))%mod<<endl;
	return 0;
}
