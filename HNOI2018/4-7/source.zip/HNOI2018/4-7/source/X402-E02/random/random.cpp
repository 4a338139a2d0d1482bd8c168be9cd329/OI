#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MOD = 998244353;
const int MAXN = 40, MAXM = 20;

struct edge_inf
{
	int u, v, w;

	edge_inf() { }
	edge_inf(int _u, int _v, int _w): u(_u), v(_v), w(_w) { }
}E[MAXM + 5];

struct edge
{
	int adj, nxt;

	edge() { }
	edge(int _adj, int _nxt): adj(_adj), nxt(_nxt) { }
};

edge e[MAXM * 2 + 5];
int st[MAXN + 5], edge_cnt = 0;

inline void add_edge(int u, int v) { e[edge_cnt] = edge(v, st[u]), st[u] = edge_cnt++; }

int n, m;

inline int fpm(int x, int y)
{
	int res = 1;
	for(x %= MOD; y; y >>= 1, x = LL(x) * x % MOD) if(y & 1) res = LL(res) * x % MOD;
	return res;
}

inline void input()
{
	n = read<int>(), m = read<int>();

	memset(st, -1, sizeof st), edge_cnt = 0;
	const int inv0 = fpm(int(1e4), MOD - 2);
	for(int i = 0; i < m; ++i)
	{
		int u = read<int>(), v = read<int>(), w = LL(read<int>()) * inv0 % MOD;
		E[i] = edge_inf(u, v, w);
		add_edge(u, v), add_edge(v, u);
	}
}

int vis[MAXN + 5], cur;
int dfn[MAXN + 5];

vector<int> V;

inline void dfs(int u)
{
	vis[u] = cur, dfn[u] = SZ(V), V.push_back(u);

	for(int i = st[u]; ~i; i = e[i].nxt)
	{
		int v = e[i].adj;
		if(!vis[v]) dfs(v);
	}
}

int g[MAXN + 5][MAXN + 5];

inline void calc_single()
{
	for(int S = 0; S < 1 << SZ(V); ++S)
	{
		int res = 1;
		for(int i = 0; i < m; ++i)
			if(vis[E[i].u] == cur && vis[E[i].v] == cur && ((S >> dfn[E[i].u]) & 1) ^ ((S >> dfn[E[i].v]) & 1))
				res = LL(res) * 2 * ((S >> dfn[E[i].u]) & 1 ? E[i].w : (1 - E[i].w + MOD) % MOD) % MOD;
		(g[cur][__builtin_popcount(S)] += res) %= MOD;
	}
}

inline void solve()
{
	memset(vis, 0, sizeof vis), cur = 0;

	for(int i = 1; i <= n; ++i)
		if(!vis[i])
		{
			++cur, V.clear(), dfs(i);
			calc_single();
		}

	static int f[MAXN + 5][MAXN + 5] = {0};

	f[0][0] = 1;
	for(int i = 1; i <= cur; ++i)
		for(int j = 0; j <= n; ++j)
			for(int k = 0; k <= j; ++k)
				(f[i][j] += LL(f[i - 1][k]) * g[i][j - k] % MOD) %= MOD;

	static int inv2_pow[MAXN * MAXN + 5];
	const int inv2 = (MOD + 1) / 2;
	inv2_pow[0] = 1;
	for(int i = 1; i <= n * n; ++i) inv2_pow[i] = LL(inv2_pow[i - 1]) * inv2 % MOD;

	int ans = 0;
	for(int i = 1; i <= n; ++i) (ans += LL(f[cur][i]) * inv2_pow[i * (n - i)] % MOD) %= MOD;
	printf("%lld\n", LL(ans) * fpm(int(1e4), n * (n - 1)) % MOD);
}

int main()
{
	freopen("random.in", "r", stdin);
	freopen("random.out", "w", stdout);

	input();
	solve();

	return 0;
}

