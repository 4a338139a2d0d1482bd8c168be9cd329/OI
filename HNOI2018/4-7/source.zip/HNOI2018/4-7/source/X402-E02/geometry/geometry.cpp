#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = int(20);

namespace GEO
{
	const double eps = 1e-10;

	struct point
	{
		double x, y;
		
		point() { }
		point(double _x, double _y): x(_x), y(_y) { }
	};

	inline double sqr(const double &val) { return val * val; }
	inline double dist(const point &u, const point &v) { return sqrt(sqr(u.x - v.x) + sqr(u.y - v.y)); }
}

using namespace GEO;

int n;

point a[MAXN + 5];

inline void input()
{
	n = read<int>();
	for(int i = 0; i < 2 * n; ++i) scanf("%lf%lf", &a[i].x, &a[i].y);
}

bool g[MAXN + 5][MAXN + 5];

inline void build_graph()
{
	for(int i = 1; i < n - 1; ++i)
		for(int j = n + 1; j < n + n - 1; ++j)
			g[i][j] = g[j][i] = 1;

	g[0][n] = g[n][0] = 1, g[n - 1][2 * n - 1] = g[2 * n - 1][n - 1] = 1;
	int p = a[0].x > a[n].x ? 0 : n;
	int q = a[n - 1].x < a[2 * n - 1].x ? n - 1 : 2 * n - 1;

	if((p < n && q >= n) || (p >= n && q < n)) g[p][q] = g[q][p] = 1;
	if(p == 0) for(int i = n + 1; i < n + n - 1; ++i) g[p][i] = g[i][p] = 1;
	else for(int i = 1; i < n - 1; ++i) g[p][i] = g[i][p] = 1;
	if(q == n - 1) for(int i = n + 1; i < n + n - 1; ++i) g[q][i] = g[i][q] = 1;
	else for(int i = 1; i < n - 1; ++i) g[q][i] = g[i][q] = 1;

	if(abs(a[0].x - a[n].x) < eps)
	{
		p = 0;
		for(int i = n + 1; i < n + n - 1; ++i) g[p][i] = g[i][p] = 1;
		p = n;
		for(int i = 1; i < n - 1; ++i) g[p][i] = g[i][p] = 1;
	}
	if(abs(a[n - 1].x - a[2 * n - 1].x) < eps)
	{
		q = n - 1;
		for(int i = n + 1; i < n + n - 1; ++i) g[q][i] = g[i][q] = 1;
		q = 2 * n - 1;
		for(int i = 1; i < n - 1; ++i) g[q][i] = g[i][q] = 1;
	}

	if(abs(a[n - 1].x - a[2 * n - 1].x) < eps)
	{
		q = n - 1;
		if(abs(a[0].x - a[n].x) < eps)
		{
			if(q >= n) g[0][q] = 1, g[q][0] = 1;
			if(q < n) g[n][q] = 1, g[q][n] = 1;
		}
		else g[p][q] = g[q][p] = 1;
		q = 2 * n - 1;
		if(abs(a[0].x - a[n].x) < eps)
		{
			if(q >= n) g[0][q] = 1, g[q][0] = 1;
			if(q < n) g[n][q] = 1, g[q][n] = 1;
		}
		else g[p][q] = g[q][p] = 1;
	}
}

inline void solve()
{
	build_graph();

	static double f[MAXN + 5][1 << MAXN];
	for(int S = 0; S < 1 << (2 * n); ++S)
		for(int i = 0; i < 2 * n; ++i)
			f[i][S] = DBL_MAX / 2;

	for(int i = 0; i < 2 * n; ++i) f[i][1 << i] = 0;
	for(int S = 1; S < 1 << (2 * n); ++S)
		for(int i = 0; i < 2 * n; ++i) if(f[i][S] < DBL_MAX / 3)
			for(int j = 0; j < 2 * n; ++j)
				if(!((S >> j) & 1) && g[i][j])
					chkmin(f[j][S | (1 << j)], f[i][S] + dist(a[i], a[j]));

	double ans = DBL_MAX;
	for(int i = 0; i < 2 * n; ++i) chkmin(ans, f[i][(1 << (2 * n)) - 1]);
	printf("%.9lf\n", ans);
}

int main()
{
	freopen("geometry.in", "r", stdin);
	freopen("geometry.out", "w", stdout);

	input();
	solve();

	return 0;
}

