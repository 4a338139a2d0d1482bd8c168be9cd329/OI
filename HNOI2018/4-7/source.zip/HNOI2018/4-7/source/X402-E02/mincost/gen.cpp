#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

int main()
{
	freopen("seed.txt", "r", stdin);
	srand(time(0) ^ read<int>());

	freopen("mincost.in", "w", stdout);
	int n = int(300), m = int(300), k = rand() % n + 1, MAXV = int(300);
	printf("%d %d %d\n", n, m, k);
	for(int i = 1; i <= n; ++i) printf("%d %d\n", rand() % MAXV + 1, rand() % MAXV + 1);

	set<pii> edge;
	while(m--)
	{
		int u, v;
		while(1)
		{
			u = rand() % n + 1, v = rand() % n + 1;
			if(u > v) swap(u, v);
			if(u != v && !edge.count(mp(u, v))) break;
		}
		edge.insert(mp(u, v)), printf("%d %d\n", u, v);
	}

	freopen("seed.txt", "w", stderr);
	fprintf(stderr, "%d\n", rand());

	return 0;
}

