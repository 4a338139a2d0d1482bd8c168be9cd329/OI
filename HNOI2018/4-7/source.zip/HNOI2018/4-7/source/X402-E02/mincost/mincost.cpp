#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = int(3e5), MAXM = int(5e5);

struct edge
{
	int adj, nxt;

	edge() { }
	edge(int _adj, int _nxt): adj(_adj), nxt(_nxt) { }
};

edge e[MAXM + 5];
int st[MAXN + 5], edge_cnt = 0;

inline void add_edge(int u, int v) { e[edge_cnt] = edge(v, st[u]), st[u] = edge_cnt++; }

int n, m, k;

pii val[MAXN + 5], E[MAXM + 5];

inline void input()
{
	n = read<int>(), m = read<int>(), k = read<int>();
	for(int i = 1; i <= n; ++i) val[i].fst = read<int>(), val[i].snd = read<int>();
	memset(st, -1, sizeof st), edge_cnt = 0;
	for(int i = 0; i < m; ++i) E[i].fst = read<int>(), E[i].snd = read<int>();
}

namespace SET
{
	int fa[MAXN + 5], size[MAXN + 5];

	inline void init(int MAX_SIZE) { for(int i = 1; i <= MAX_SIZE; ++i) fa[i] = i, size[i] = 1; }
	inline int get_fa(int u) { return u == fa[u] ? u : fa[u] = get_fa(fa[u]); }
	inline bool link(int u, int v)
	{
		int fu = get_fa(u), fv = get_fa(v);
		if(fu == fv) return 0;
		if(size[fu] < size[fv]) swap(fu, fv);
		size[fu] += size[fv], fa[fv] = fu;
		return size[fu] >= k;
	}
}

int seq[MAXN + 5];

inline int calc(const int &aval)
{
	static bool vis[MAXN + 5];
	memset(vis, 0, sizeof vis);

	SET::init(n);
	for(int i = 1; i <= n; ++i)
	{
		int u = seq[i];
		if(val[u].fst <= aval)
		{
			vis[u] = 1;
			for(int j = st[u]; ~j; j = e[j].nxt)
			{
				int v = e[j].adj;
				if(vis[v] && SET::link(u, v)) return aval + val[u].snd;
			}
		}
	}
	return INT_MAX;
}

inline bool cmp(const int &u, const int &v) { return val[u].snd < val[v].snd; }

inline void solve()
{
	static int fst_val[MAXN + 5], L;
	for(int i = 1; i <= n; ++i) fst_val[++L] = val[i].fst;
	sort(fst_val + 1, fst_val + L + 1), L = unique(fst_val + 1, fst_val + L + 1) - (fst_val + 1);

	for(int i = 1; i <= n; ++i) seq[i] = i;
	sort(seq + 1, seq + n + 1, cmp);

	static int pos[MAXN + 5];
	for(int i = 1; i <= n; ++i) pos[seq[i]] = i;

	for(int i = 0; i < m; ++i)
	{
		if(pos[E[i].fst] < pos[E[i].snd]) swap(E[i].fst, E[i].snd);
		add_edge(E[i].fst, E[i].snd);
	}

	int ans = INT_MAX;
	for(int i = 1; i <= L; ++i) chkmin(ans, calc(fst_val[i]));
	if(ans < INT_MAX) printf("%d\n", ans);
	else puts("no solution");
}

int main()
{
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);

	input();
	solve();

	return 0;
}

