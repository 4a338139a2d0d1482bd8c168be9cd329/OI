#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = int(5e3), MAXM = int(5e3);

int n, m, k;

pii val[MAXN + 5], E[MAXN + 5];

inline void input()
{
	n = read<int>(), m = read<int>(), k = read<int>();
	for(int i = 1; i <= n; ++i) val[i].fst = read<int>(), val[i].snd = read<int>();
	for(int i = 0; i < m; ++i) E[i].fst = read<int>(), E[i].snd = read<int>();
}

namespace SET
{
	int fa[MAXN + 5], size[MAXN + 5];

	inline void init(const int &MAX_SIZE) { for(int i = 1; i <= MAX_SIZE; ++i) fa[i] = i, size[i] = 1; }
	inline int get_fa(const int &u) { return u == fa[u] ? u : fa[u] = get_fa(fa[u]); }
	inline bool link(int u, int v)
	{
		int fx = get_fa(u), fy = get_fa(v);
		if(fx == fy) return 0;
		size[fx] += size[fy], fa[fy] = fx;
		return size[fx] >= k;
	}
	inline bool p(int u, int v) { return get_fa(u) == get_fa(v); }
}

inline void solve()
{
	int ans = INT_MAX;
	for(int p = 1; p <= n; ++p)
		for(int q = 1; q <= n; ++q)
		{
			static bool vis[MAXN + 5];
			memset(vis, 0, sizeof vis);

			for(int i = 1; i <= n; ++i)
				if(val[i].fst <= val[p].fst && val[i].snd <= val[q].snd)
					vis[i] = 1;

			SET::init(n);
			bool fg = 0;
			for(int i = 0; i < m; ++i)
				if(vis[E[i].fst] && vis[E[i].snd]) if(!SET::p(E[i].fst, E[i].snd))
					if(SET::link(E[i].fst, E[i].snd)) { fg = 1; break; }
			if(fg) chkmin(ans, val[p].fst + val[q].snd);
		}
	if(ans == INT_MAX) puts("no solution");
	else printf("%d\n", ans);
}

int main()
{
	freopen("mincost.in", "r", stdin);
	freopen("mincost.ans", "w", stdout);

	input();
	solve();

	return 0;
}

