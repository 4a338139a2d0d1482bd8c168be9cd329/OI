#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1000+5;
template<typename T>bool cmax(T &a,T b){return (a<b)?a=b,1:0;}
template<typename T>bool cmin(T &a,T b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("geometry.in","r",stdin);
      freopen("geometry.out","w",stdout);
  #endif
}
int n;
struct node
{
	double x,y;
}a[N],b[N];
void input()
{
	n=read<int>();
	For(i,1,n)scanf("%lf%lf",&a[i].x,&a[i].y);
	For(i,1,n)scanf("%lf%lf",&b[i].x,&b[i].y);
}
double sqr(double x){return x*x;}
double dis(int i,int j){return sqrt(sqr(a[i].x-b[j].x)+sqr(a[i].y-b[j].y));}
namespace sub1
{
	void solve()
	{
		printf("%.10lf\n",dis(1,1));
	}
}
namespace sub2
{
	double ans=-1.0;
	void cal()
	{
		double res=0.0,num1=0.0,num2=0.0;
		For(i,1,n)res+=dis(i,i);
		For(i,1,n-1)num1+=dis(i,i+1);
		For(i,1,n-1)num2+=dis(i+1,i);
		res+=min(num1,num2);
		if(ans==-1.0||ans>res)ans=res;
	}
	void solve()
	{
		int pos;
		For(i,1,10000)
		{
			cal();
			pos=rand()%(n-1)+1;
			swap(a[pos],a[pos+1]);
		}
		printf("%.10lf\n",ans);
	}
}
void work()
{
	if(n==1)sub1::solve();
	else sub2::solve();
}
int main()
{
	srand(20020406);
	file();
	input();
	work();
	return 0;
}
