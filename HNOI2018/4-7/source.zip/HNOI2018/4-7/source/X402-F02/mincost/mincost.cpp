#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=5000+5;
template<typename T>bool cmax(T &a,T b){return (a<b)?a=b,1:0;}
template<typename T>bool cmin(T &a,T b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("mincost.in","r",stdin);
      freopen("mincost.out","w",stdout);
  #endif
}
int n,m,k;
int a[N],b[N];
struct edge
{
	int u,v,a,b;
}e[N];
void input()
{
	int u,v;
	n=read<int>(),m=read<int>(),k=read<int>();
	For(i,1,n)a[i]=read<int>(),b[i]=read<int>();
	For(i,1,m)
	{
		u=read<int>(),v=read<int>();
		e[i]=(edge){u,v,max(a[u],a[v]),max(b[u],b[v])};	
	}
}
bool cmpa(edge x,edge y){return x.a==y.a?x.b<y.b:x.a<y.a;}
bool cmpb(edge x,edge y){return x.b==y.b?x.a<y.a:x.b<y.b;}
namespace sub1
{
	int ans,fa[N],size[N];
	int find(int x){return x==fa[x]?x:fa[x]=find(fa[x]);}
	void link(int x,int y)
	{
		int xx=find(x),yy=find(y);
		size[xx]+=size[yy],fa[yy]=xx;
	}
	bool check(int id,int B)
	{
		For(i,1,n)fa[i]=i,size[i]=1;
		For(i,1,id)if(e[i].b<=B)
		{
			if(find(e[i].u)!=find(e[i].v))
			{
				link(e[i].u,e[i].v);
				if(size[find(e[i].u)]>=k)return true;
			}
		}
		return false;
	}
	void solve()
	{
		ans=2000000000;
		sort(e+1,e+m+1,cmpa);
		int max_b=*max_element(b+1,b+n+1),min_b=*min_element(b+1,b+n+1);
		int l,r,mid,res;
		For(i,1,n)
		{
			if(e[i].a==e[i+1].a)continue;
			l=min_b,r=max_b,res=1000000000;
			while(l<=r)
			{
				mid=(l+r)>>1;
				if(check(i,mid))res=mid,r=mid-1;
				else l=mid+1;
			}
			cmin(ans,e[i].a+res);
		}
		write(ans,'\n');
	}
}
void work()
{
	if(n<=5000&&m<=5000)sub1::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
