#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
template<typename T>bool cmax(T &a,T b){return (a<b)?a=b,1:0;}
template<typename T>bool cmin(T &a,T b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("random.in","r",stdin);
      freopen("random.out","w",stdout);
  #endif
}
int n,m,mp[10][10];
struct edge
{
	int u,v,nex;
}e[20];
int head[10],tt;
void add(int x,int y)
{
	e[++tt]=(edge){x,y,head[x]},head[x]=tt;
}
int u[20],v[20],w[20];
void input()
{
	n=read<int>(),m=read<int>();
	For(i,1,m)
	{
		u[i]=read<int>(),v[i]=read<int>(),w[i]=read<int>();
		mp[u[i]][v[i]]=1;
	}
}
const int mo=998244353;
ll power(ll x,int y)
{
	ll res=1;
	for(;y;x=x*x%mo,y>>=1)if(y&1)res=res*x%mo;
	return res;
}
ll inv;
namespace sub1
{
	int p[20],ans;
	int dfn[10],low[10],scc[10],dfs_clock,id,l[10],top;
	void reset()
	{
		memset(head,0,sizeof head);tt=0;
		memset(dfn,0,sizeof dfn);
		memset(low,0,sizeof low);
		memset(scc,0,sizeof scc);
		dfs_clock=id=top=0;
	}
	#define rg register
	void Tarjan(int u)
	{
		int v;
		low[u]=dfn[u]=++dfs_clock;
		l[++top]=u;
		for(rg int i=head[u];i;i=e[i].nex)
		{
			v=e[i].v;
			if(!dfn[v])
			{
				Tarjan(v);
				cmin(low[u],low[v]);
			}
			else if(!scc[v])cmin(low[u],dfn[v]);
		}
		if(dfn[u]==low[u])
		{
			++id;
			int k;
			do
			{
				k=l[top--];
				scc[k]=id;
			}while(k^u);
		}
	}
	int cal()
	{
		For(i,1,n)if(!scc[i])Tarjan(i);
		return id;
	}
	void solve()
	{
		For(i,1,n)For(j,i+1,n)if(!mp[i][j])
		{
			++m;u[m]=i,v[m]=j,w[m]=5000;
		}
		p[1]=1;For(i,2,m)p[i]=p[i-1]<<1;
		inv=power(10000,mo-2);
		int s=(1<<m)-1,res;	 
		For(i,0,s)
		{
			res=1;
			reset();
			For(j,1,m)
			{
				if(i&p[j])res=1ll*res*w[j]%mo*inv%mo,add(u[j],v[j]);
				else res=1ll*res*(10000-w[j])%mo*inv%mo,add(v[j],u[j]);
			}
			ans=(ans+1ll*cal()*res%mo)%mo;	
		}
		write(1ll*ans*power(10000,n*(n-1))%mo,'\n');
	}
}
namespace sub2
{
	int ans,C[N][N],inv;
	void solve()
	{
		inv=power(10000,mo-2);
		For(i,0,n)C[i][0]=C[i][i]=1;
		For(i,2,n)For(j,1,i-1)C[i][j]=(C[i-1][j-1]+C[i-1][j])%mo;
		For(i,1,n)
		{
			ans=(ans+1ll*C[n][i]*power(1ll*5000*inv%mo,i*(n-i))%mo*power(1ll*10000*inv%mo,n*(n-1)/2-i*(n-i))%mo)%mo;
		}
		write(1ll*ans*power(10000,(n-1)*n)%mo,'\n');
	}
}
void work()
{
	if(m)
		sub1::solve();
	else 
		sub2::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
