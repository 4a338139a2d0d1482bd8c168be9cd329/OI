#include<bits/stdc++.h>
#define ll long long
#define db double
#define ld long double
const int MAXN=1000+10;
int n;
struct node{
	int x,y;
};
node point[2][MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline ld dist(node a,node b)
{
	return sqrt((ld)((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)));
}
inline void cheat()
{
	ld ans=0;
	for(register int i=n;i>1;--i)ans+=dist(point[1][n],point[0][n])+dist(point[0][n],point[1][n-1]);
	ans+=dist(point[1][1],point[0][1]);
	printf("%Lf\n",ans);
}
int main()
{
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	read(n);
	for(register int i=0;i<=1;++i)
		for(register int j=1;j<=n;++j)read(point[i][j].x),read(point[i][j].y);
	if(n==1)printf("%Lf\n",dist(point[0][1],point[1][1]));
	else if(n<=5)dfs();
	else cheat();
	return 0;
}
