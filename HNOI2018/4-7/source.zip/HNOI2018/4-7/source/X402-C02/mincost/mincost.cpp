#include<bits/stdc++.h>
#define ll long long
#define db double
#define ld long double
const int MAXN=300000+10,MAXM=500000+10,inf=0x3f3f3f3f;
int A[MAXN],B[MAXN],n,m,k,vis[MAXN],chance[MAXN],e,to[MAXM<<1],nex[MAXM<<1],beg[MAXN],mA,mB;
std::queue<int> q;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline void insert(int x,int y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
inline void bfs(int s)
{
	mA=-inf,mB=-inf;
	for(register int i=1;i<=n;++i)vis[i]=0;
	q.push(s);
	vis[s]=1;
	while(!q.empty())
	{
		int x=q.front();
		chkmax(mA,A[x]);
		chkmax(mB,B[x]);
		q.pop();
		for(register int i=beg[x];i;i=nex[i])
			if(chance[to[i]]&&!vis[to[i]])
			{
				vis[to[i]]=1;
				q.push(to[i]);
			}
	}
}
inline int dfs()
{
	int res=inf;
	for(register int i=0,limit=(1<<n);i<limit;++i)
	{
		if(__builtin_popcount(i)!=k)continue;
		int bg=0;
		for(register int j=0;j<n;++j)
			if(i&(1<<j))bg=j+1,chance[j+1]=1;
			else chance[j+1]=0;
		bfs(bg);
		for(register int j=1;j<=n;++j)
			if(chance[i]&&(!vis[i]))continue;
		chkmin(res,mA+mB);
	}
	return res;
}
inline void subt1()
{
	int res=dfs();
	if(res==inf)puts("no solution");
	else write(res,'\n');
}
int main()
{
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
	read(n);read(m);read(k);
	for(register int i=1;i<=n;++i)read(A[i]),read(B[i]);
	for(register int i=1;i<=m;++i)
	{
		int u,v;
		read(u);read(v);
		insert(u,v);insert(v,u);
	}
	subt1();
	return 0;
}
