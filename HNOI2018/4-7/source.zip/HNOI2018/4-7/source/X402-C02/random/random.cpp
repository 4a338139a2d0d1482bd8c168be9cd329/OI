#include<bits/stdc++.h>
#define ll long long
#define db double
#define ld long double
const int MAXN=40,MAXM=20,inf=0x3f3f3f3f,Mod=998244353;
int n,m,P[MAXN][MAXN],DFN[MAXN],LOW[MAXN],Visit_Num,Stack_Num,In_Stack[MAXN],Stack[MAXN],e,to[MAXN*MAXN],nex[MAXN*MAXN],beg[MAXN],cnt;
ll sum,inv;
struct node{
	int u,v,p;
};
node side[MAXN*MAXN/2];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
inline void insert(int x,int y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
inline void Tarjan(int x)
{
	DFN[x]=LOW[x]=++Visit_Num;
	Stack[++Stack_Num]=x;
	In_Stack[x]=1;
	for(register int i=beg[x];i;i=nex[i])
		if(!DFN[to[i]])
		{
			Tarjan(to[i]);
			chkmin(LOW[x],LOW[to[i]]);
		}
		else if(In_Stack[to[i]]&&DFN[to[i]]<LOW[x])LOW[x]=DFN[to[i]];
	if(DFN[x]==LOW[x])
	{
		sum++;
		int temp;
		do{
			temp=Stack[Stack_Num--];
			In_Stack[temp]=0;
		}while(temp!=x);
	}
}
inline void subt1()
{
	ll res=0;
	for(register int i=0,limit=(1<<cnt);i<limit;++i)
	{
		ll pnow=1;
		e=0,memset(beg,0,sizeof(beg));
		sum=0;
		for(register int j=1;j<=n;++j)
		{
			DFN[j]=LOW[j]=0;
			Visit_Num=0;
		}
		for(register int j=0;j<cnt;++j)
			if(i&(1<<j))insert(side[j+1].u,side[j+1].v),(pnow*=side[j+1].p)%=Mod;
			else insert(side[j+1].v,side[j+1].u),(pnow*=(10000-side[j+1].p))%=Mod;
		for(register int j=1;j<=n;++j)
			if(!DFN[j])Tarjan(j);
		(res+=sum*pnow%Mod)%=Mod;
	}
	write(res*inv%Mod,'\n');
}
int main()
{
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
	read(n);read(m);
	inv=qexp(10000,n*(n-1)/2);
	for(register int i=1;i<=n;++i)
		for(register int j=i+1;j<=n;++j)P[i][j]=5000;
	for(register int i=1;i<=m;++i)
	{
		int u,v;
		read(u);read(v);
		read(P[u][v]);
	}
	for(register int i=1;i<=n;++i)
		for(register int j=i+1;j<=n;++j)side[++cnt].u=i,side[cnt].v=j,side[cnt].p=P[i][j];
	subt1();
	return 0;
}
