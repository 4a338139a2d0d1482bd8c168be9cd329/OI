#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=21,maxm=110;

int n;

struct point{
    int x,y;
} a[maxn],b[maxn];

double f[1<<10][1<<10][maxn];

long long cross(int x1,int y1,int x2,int y2){
    return 1ll*x1*y2-1ll*x2*y1;
}

double dis(point p1,point p2){
    return sqrt(1.*(p1.x-p2.x)*(p1.x-p2.x)+1.*(p1.y-p2.y)*(p1.y-p2.y));
}

int head[maxn],nxt[maxm<<1],to[maxm<<1],e;
double w[maxm<<1];
void ae(int x,int y,double c){
    to[++e]=y; nxt[e]=head[x]; head[x]=e; w[e]=c;
}

void write(int s){
    for(int i=0;i<n;i++)
        if((s>>i)&1) printf("1");
        else printf("0");
}

int main(){
    freopen("geometry.in","r",stdin);
    freopen("geometry.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++) read(a[i].x),read(a[i].y);
    for(int i=1;i<=n;i++) read(b[i].x),read(b[i].y);

    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){
            bool flag1=(i==1||cross(a[i-1].x-a[i].x,a[i-1].y-a[i].y,b[j].x-a[i].x,b[j].y-a[i].y)>0);
            bool flag2=(i==n||cross(b[j].x-a[i].x,b[j].y-a[i].y,a[i+1].x-a[i].x,a[i+1].y-a[i].y)>0);
            bool flag3=(j==1||cross(a[i].x-b[j].x,a[i].y-b[j].y,b[j-1].x-b[j].x,b[j-1].y-b[j].y)>0);
            bool flag4=(j==n||cross(b[j+1].x-b[j].x,b[j+1].y-b[j].y,a[i].x-b[j].x,a[i].y-b[j].y)>0);
            if(flag1&&flag2&&flag3&&flag4) ae(i,n+j,dis(a[i],b[j])),ae(n+j,i,dis(a[i],b[j]));
        }

    for(int s1=0;s1<(1<<n);s1++)
        for(int s2=0;s2<(1<<n);s2++)
            for(int i=1;i<=n*2;i++) f[s1][s2][i]=1.*LLONG_MAX;

    for(int i=1;i<=n*2;i++)
        if(i<=n) f[1<<(i-1)][0][i]=0;
        else f[0][1<<(i-n-1)][i]=0;

    for(int s1=0;s1<(1<<n);s1++)
        for(int s2=0;s2<(1<<n);s2++)
            for(int i=1;i<=n*2;i++){
                if(f[s1][s2][i]==1.*LLONG_MAX) continue;
                if(i<=n){
                    for(int j=head[i];j;j=nxt[j]){
                        int v=to[j];
                        if(!((s2>>(v-n-1))&1)) chkmin(f[s1][s2|(1<<(v-n-1))][v],f[s1][s2][i]+w[j]);
                    }
                }

                else{
                    for(int j=head[i];j;j=nxt[j]){
                        int v=to[j];
                        if(!((s1>>(v-1))&1)) chkmin(f[s1|(1<<(v-1))][s2][v],f[s1][s2][i]+w[j]);
                    }
                }
            }

    double ans=1.*LLONG_MAX;
    for(int i=1;i<=n*2;i++) chkmin(ans,f[(1<<n)-1][(1<<n)-1][i]);
    printf("%.12lf\n",ans==1.*LLONG_MAX?-1:ans);

    return 0;
}
