#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=300010,maxm=500010,INF=0x7fffffff;

int n,m,k,ans=INF;

struct data{
    int a,b,id,bid;

    bool operator < (const data& rhs) const{
        return a==rhs.a?b<rhs.b:a<rhs.a;
    }
} t[maxn];

inline bool cmp(data x,data y){
    return x.b<y.b;
}

int head[maxn],nxt[maxm<<1],to[maxm<<1],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}

int f[maxn],sz[maxn];
bool vis[maxn];
int book[maxn];

int getf(int v){
    return f[v]=f[v]==v?v:getf(f[v]);
}

int main(){
    freopen("mincost.in","r",stdin);
    freopen("mincost.out","w",stdout);

    read(n); read(m); read(k);
    for(int i=1;i<=n;i++) read(t[i].a),read(t[i].b),t[i].id=i;
    for(int i=1;i<=m;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ae(v,u);
    }

    sort(t+1,t+n+1,cmp);
    for(int i=1;i<=n;i++) t[i].bid=i;

    sort(t+1,t+n+1);

    for(int i=1;i<=n;i++){
        int w=t[i].a;
        book[t[i].bid]=i;
        for(int j=1;j<=i;j++){
            f[t[j].id]=t[j].id;
            sz[t[j].id]=1; vis[t[j].id]=0;
        }
        bool flag=0;
        for(int j=1;j<=n;j++) if(book[j]){
            int u=t[book[j]].id;
            for(int l=head[u];l;l=nxt[l]){
                int v=to[l];
                if(!vis[v]) continue;
                int fu=getf(u),fv=getf(v);
                sz[fv]+=sz[fu]; f[fu]=fv;
            }
            vis[u]=1;
            if(sz[getf(u)]>=k){ w+=t[book[j]].b; flag=1; break; }
        }
        if(flag) chkmin(ans,w);
    }

    if(ans==INF) puts("no solution");
    else printf("%d\n",ans);

    return 0;
}
