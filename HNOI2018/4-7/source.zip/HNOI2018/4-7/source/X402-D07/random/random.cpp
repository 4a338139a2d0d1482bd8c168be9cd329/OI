#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=50,mo=998244353;

int Inv,Pw;
int n,m,ans;
int P[maxn][maxn];
bool G[maxn][maxn];

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

int sccno[maxn],cnt,cur,dfn[maxn],low[maxn];
stack<int> s;

void tarjan(int u){
    dfn[u]=low[u]=++cur;
    s.push(u);
    for(int v=1;v<=n;v++) if(G[u][v]){
        if(!dfn[v]) tarjan(v),chkmin(low[u],low[v]);
        else if(!sccno[v]) chkmin(low[u],dfn[v]);
    }
    if(low[u]==dfn[u]){
        ++cnt; int x;
        do{
            x=s.top(); s.pop();
            sccno[x]=cnt;
        } while(x!=u);
    }
}

void dfs(int u,int v,int p){
    if(u==n){
        cnt=cur=0;
        memset(sccno,0,sizeof sccno);
        memset(dfn,0,sizeof dfn);
        memset(low,0,sizeof low);
        for(int i=1;i<=n;i++) if(!dfn[i]) tarjan(i);
        (ans+=1ll*p*cnt%mo*Pw%mo)%=mo;
        return;
    }

    int tu=u,tv=v+1;
    if(tv==n+1) tu++,tv=tu+1;
    int bak=p;
    G[u][v]=1; p=1ll*p*P[u][v]%mo*Inv%mo;
    dfs(tu,tv,p);
    G[u][v]=0; p=bak;
    G[v][u]=1; p=1ll*p*(10000-P[u][v])%mo*Inv%mo;
    dfs(tu,tv,p);
    G[v][u]=0; p=bak;
}

int main(){
    freopen("random.in","r",stdin);
    freopen("random.out","w",stdout);

    read(n); read(m);
    Inv=fpm(10000,mo-2);
    Pw=fpm(10000,n*(n-1));
    for(int i=1;i<=n;i++)
        for(int j=i+1;j<=n;j++) P[i][j]=5000;
    for(int i=1;i<=m;i++){
        int u,v;
        read(u); read(v); read(P[u][v]);
    }
    dfs(1,2,1);
    printf("%d\n",ans);

    return 0;
}
