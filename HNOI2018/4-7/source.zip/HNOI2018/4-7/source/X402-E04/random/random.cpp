#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 16, INF = 0x3f3f3f3f, Mod = 998244353, M = 50;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("random.in","r",stdin);
	freopen("random.out","w",stdout);
}
int f[1<<N], pw[M * M];
int n, m;
ll qpow(ll a, ll b){
	ll ret = 1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
struct edge{
	int x, y, z;
}E[M];
inline int bit(int x){
	return (1<<(x-1));
}
void init(){
	read(n), read(m);
	For(i, 1, m){
		int x, y, z;
		read(x), read(y), read(z);
		z = z * qpow(10000, Mod - 2) % Mod;
		E[i].x = x, E[i].y = y, E[i].z = z;
	}
	pw[0] = 1;
	For(i, 1, n * n)
		pw[i] = pw[i - 1] * qpow(2, Mod - 2) % Mod;
}
int g[1<<N];
#define bitc __builtin_popcount
inline int lowbit(int x){
	return x & (-x);
}
#define Rep(i, u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
void solve(){
	f[0] = 0;
	int all = (1<<n) - 1;
	For(s, 1, all){
		f[s] = 1;
		g[s] = 0;
		for(int t = s; t; t = (t - 1) & s){
			if(t == s)continue;
			ll ret = 1, cnt = bitc(s ^ t) * bitc(t);
			For(i, 1, m){
				int x = E[i].x, y = E[i].y, z = E[i].z;
				if(bit(x) & (s ^ t))swap(x, y), z = (1 + Mod - z) % Mod;
				if(!(bit(x) & t) || !(bit(y) & (s ^ t)))continue;
				ret = ret * z % Mod; cnt--;
			}	
			ret = ret * pw[cnt] % Mod;

			f[s] = (f[s] + Mod - f[t] * ret % Mod) % Mod;
			g[s] = (g[s] + f[t] * ret % Mod * (g[s ^ t] + 1) % Mod) % Mod;
		}
		g[s] = (g[s] + f[s]) % Mod;
	}
	printf("%lld\n", g[all] * qpow(10000, n * (n - 1)) % Mod);
}
namespace BF{
	const int N = 50;
	int f[N], g[N], C[N][N], G[N];
	void solve(){
		C[0][0] = 1;
		For(i, 1, n){
			C[i][0] = 1;
			For(j, 1, i)
				C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % Mod;
		}

		For(i, 0, n)g[i] = qpow(2, C[i][2]);
		For(i, 1, n){
			f[i] = g[i];
			For(j, 1, i - 1)
				f[i] = (f[i] + Mod - 1ll * f[j] * g[i - j] % Mod * C[i][j] % Mod) % Mod;
		}
		For(i, 1, n)f[i] = f[i] * qpow(g[i], Mod - 2) % Mod;

		For(i, 1, n){
			G[i] = 0;
			For(j, 1, i)
				G[i] = (G[i] + 1ll * f[j] * C[i][j] % Mod * (G[i - j] + 1) % Mod * pw[(i - j) * j] % Mod) % Mod; 
		}
		printf("%lld\n", G[n] * qpow(10000, n * (n - 1) % Mod) % Mod);
	} 
}
void solve1(){
	BF::solve();
}
int main(){
	file();
	init();
	if(m > 0)solve();
	else solve1();
	return 0;
}
