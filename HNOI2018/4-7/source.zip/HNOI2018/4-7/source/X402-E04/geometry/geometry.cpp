#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define ll long long 
using namespace std;
const int N = 1010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();int f = 0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
struct node{
	int x, y;
}P[N], Q[N];
int main(){
	int n;
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	read(n);
	For(i, 1, n)
		read(P[i].x), read(P[i].y);
	For(i, 1, n)
		read(Q[i].x), read(Q[i].y);
	if(n == 1){
		printf("%.9lf\n",  sqrt((P[1].x - Q[1].x) * (P[1].x - Q[1].x) + (P[1].y - Q[1].y) * (P[1].y - Q[1].y)));
	}
	return 0;
}
