#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 300010, INF = 0x3f3f3f3f, M = 500010;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))c=getchar(),f|=(c=='-');
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("mincost.in","r",stdin);
	freopen("mincost.out","w",stdout);
}
int n, m, k;
int Begin[N], Next[M << 1], to[M << 1], e;
struct node{
	int x, y, id;
	bool operator <(const node & r)const {
		return x < r.x || (x == r.x && y < r.y);
	}
}P[N];
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
void init(){
	read(n), read(m), read(k);
	For(i, 1, n)read(P[i].x), read(P[i].y), P[i].id = i;
	For(i, 1, m){
		int x, y;
		read(x), read(y);
		add(x, y), add(y, x);
	}
	sort(P + 1, P + n + 1);

}
inline bool cmp(node a, node b){
	return a.y < b.y || (a.y == b.y && a.x < b.x);
}
int vis[N];
int f[N], sz[N];
inline int find(int x){
	return x == f[x] ? x : f[x] = find(f[x]);
}
inline void link(int x, int y){
	x = find(x), y = find(y);
	if(x ^ y){
		f[x] = y;
		sz[y] += sz[x];
	}
}
#define Rep(i, u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
void solve(){
	int ans = INF * 2;
	For(i, 1, n){
		int A = P[i].x, pos = i;

		Forr(j, i - 1, 0)if(cmp(P[j], P[i])){pos = j + 1;break;}
		node ret = P[i];
		Forr(j, i, pos + 1)P[j] = P[j - 1];
		P[pos] = ret;
		For(j, 1, n)vis[j] = 0, f[j] = j, sz[j] = 1;
		For(j, 1, i){
			int u = P[j].id;
			Rep(l, u)if(vis[v])link(u, v);
			if(sz[find(u)] >= k){
				ans = min(ans, A + P[j].y);
				break;
			}
			vis[u] = 1;
		}
	}
	if(ans != INF * 2)printf("%d\n", ans);
	else puts("no solution");
}
int main(){
	file();
	init();
	solve();
	return 0;
}
