#include<bits/stdc++.h>
using namespace std;

#define fst first
#define snd second
#define mkp make_pair
typedef pair<int, int> pii;
typedef long long ll;
const int MAXN = 100010, MAXM = 100010;
const ll INF = 1LL<<50;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], to[MAXM<<1];
int nxt[MAXM<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

namespace LCT {
#define ls(p) (ch[(p)][0])
#define rs(p) (ch[(p)][1])
#define rel(p) (rs(fa[p]) == p)
	int sz[MAXN], ms[MAXN];
	int fa[MAXN], ch[MAXN][2];
	inline void rotate(int x) {
		int y = fa[x], f = rel(x), z = ch[x][f^1];
		fa[x] = fa[y];
		if(!isroot(y)) ch[fa[y]][rel(y)] = x;
		ch[fa[z] = y][f] = z;
		ch[fa[y] = x][f^1] = y;
		update(y);
	}
}

int n, m, K;
struct Point {
	int a, b, id;
	bool operator < (const Point &rhs) const {
		return a < rhs.a;
	}
}p[MAXN];
set<pii> s;
set<pii>::iterator it;
bool in[MAXN];
ll ans;
bool flag;

int main() {
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);

	int i, j;
	n = read(), m = read(), K = read();
	for(i = 1; i <= n; i++) {
		p[i].a = read(), p[i].b = read();
		p[i].id = i;
	}
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
	}
	sort(p+1, p+n+1), ans = INF;
	for(j = 1; j <= n; j++) {
		if(!flag) {
			s.insert(mkp(p[j].snd, p[j].id));
			in[p[j].id] = true;
			int u = p[j].id;
			for(i = st[u]; i; i = nxt[i]) {
				int v = to[i];
				if(!in[v]) continue;
				LCT::link(v, u);
			}
			if(LCT::size(u) < K) continue;
			it = s.end(), it--;
			flag = true;
		}
		else {
			pii t = mkp(p[j].snd, p[j].id);
			if(t > *it) {
				s.insert(mkp(p[j].snd, p[j].id));
				continue;
			}
			s.insert(mkp(p[j].snd, p[j].id));
			in[p[j].id] = true;
			int u = p[j].id;
			for(i = st[u]; i; i = nxt[i]) {
				int v = to[i];
				if(!in[v]) continue;
				LCT::link(v, u);
			}
		}
		while(check()) {
			int u = it->snd;
			in[u] = false;
			for(i = st[u]; i; i = nxt[i]) {
				int v = to[i];
				if(!in[v]) continue;
				LCT::cut(v, u);
			}
			it--;
		}
	}
	return 0;
}
