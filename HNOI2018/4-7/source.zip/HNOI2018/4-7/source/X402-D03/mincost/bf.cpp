#include<bits/stdc++.h>
using namespace std;

#define fst first
#define snd second
#define mkp make_pair
typedef pair<int, int> pii;
typedef long long ll;
const int MAXN = 100010, MAXM = 100010;
const ll INF = 1LL<<50;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], to[MAXM<<1];
int nxt[MAXM<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int n, m, K;
struct Point {
	int a, b, id;
	bool operator < (const Point &rhs) const {
		return a < rhs.a;
	}
}p[MAXN];
set<pii> s;
set<pii>::iterator it;
bool in[MAXN];
int fa[MAXN], size[MAXN];
ll ans;

int find(int x) {
	return fa[x] = fa[x] == x ? x : find(fa[x]);
}

int main() {
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);

	int i, j;
	n = read(), m = read(), K = read();
	for(i = 1; i <= n; i++) {
		p[i].a = read(), p[i].b = read();
		p[i].id = i;
	}
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
	}
	sort(p+1, p+n+1);
	ans = INF;
	for(i = 1; i <= n; i++) {
		s.insert(mkp(p[i].b, p[i].id));
		for(j = 1; j <= n; j++) fa[j] = j, size[j] = 1;
		memset(in, false, sizeof(in));
		for(it = s.begin(); it != s.end(); it++) {
			int u = it->snd;
			in[u] = true;
			for(j = st[u]; j; j = nxt[j]) {
				int v = to[j];
				if(!in[v]) continue;
				int x = find(u), y = find(v);
				if(x == y) continue;
				fa[x] = y, size[y] += size[x];
				if(size[y] >= K) break;
			}
			if(j) break;
		}
		if(it != s.end()) 
			ans = min(ans, (ll)p[i].a+it->fst);
	}
	if(ans == INF) printf("no solution\n");
	else printf("%lld\n", ans);
	return 0;
}
