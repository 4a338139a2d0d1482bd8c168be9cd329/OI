#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;
const int MAXN = 40;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

ll g[MAXN][MAXN], ans;
bool c[MAXN][MAXN];
int dfn[MAXN], low[MAXN], dfs_clock;
int sccno[MAXN], S[MAXN], top, sccn;

int n, m;

void tarjan(int u) {
//	printf("%d\n", u);
	low[u] = dfn[u] = ++dfs_clock;
	S[++top] = u;
	int v;
	for(v = 1; v <= n; v++) {
		if(!c[u][v]) continue;
		if(!dfn[v]) {
			tarjan(v);
			low[u] = min(low[u], low[v]);
		}
		else if(!sccno[v]) 
			low[u] = min(low[u], dfn[v]);
	}
//	printf("%d:%d\n", u, low[u]);
	if(dfn[u] == low[u]) {
		sccn++;
		while(S[top] != u) 
			sccno[S[top--]] = sccn;
		sccno[S[top--]] = sccn;
	}
}

inline void dfs(int x, int y, ll P) {
	if(P == 0) return;
	if(y == n+1) x++, y = x+1;
//	printf("dfs(%d %d) %lld %lld %lld\n", x, y, P, g[x][y], g[y][x]);
	if(x == n) {
		int i;
		memset(dfn, 0, sizeof(dfn));
		memset(low, 0, sizeof(low));
		memset(sccno, 0, sizeof(sccno));
		top = dfs_clock = sccn = 0;
		//for(i = 1; i <= n; i++) {
		//	for(int j = 1; j <= n; j++)
		//		printf("%d ", c[i][j]);
		//	printf("\n");
		//}
		for(i = 1; i <= n; i++) {
//			printf("!%d\n", dfn[i]);
			if(!dfn[i]) tarjan(i);
		}
//		printf("%lld %d\n", P, sccn);
		ans = (ans+P * sccn % MOD)%MOD;
		return;
	}
	c[x][y] = true;
	dfs(x, y+1, P*g[x][y]%MOD);
	c[x][y] = false, c[y][x] = true;
	dfs(x, y+1, P*g[y][x]%MOD);
	c[y][x] = false;
}

int main() {
	freopen("random.in", "r", stdin);
	freopen("random.out", "w", stdout);

	int i, j;
	n = read(), m = read();
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++) 
			if(j != i) g[i][j] = 5000;
	for(i = 1; i <= m; i++) {
		int u = read(), v = read(), w = read();
		g[u][v] = w, g[v][u] = 10000-g[u][v];
	}
//	for(i = 1; i <= n; i++) {
//		for(j = 1; j <= n; j++)
//			printf("%lld ", g[i][j]);
//		printf("\n");
//	}
	dfs(1, 2, 1);
	ans = ans*qpow(10000, (n*(n-1))>>1)%MOD;
	printf("%lld\n", ans);
	return 0;
}
