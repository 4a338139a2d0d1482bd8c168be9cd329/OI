#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const double eps=1e-12;
int main(){
	freopen("geometry.in","r",stdin); freopen("geometry.out","w",stdout);
	int n=read(); double a,b,c,d;
	if (n==1){
		scanf("%lf%lf%lf%lf",&a,&b,&c,&d);
		if (fabs(a-c)<=eps) printf("-1\n");
		else printf("%.15lf\n",sqrt((a-c)*(a-c)+(b-d)*(b-d)));
	}
	return 0;
}
