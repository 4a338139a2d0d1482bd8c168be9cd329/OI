#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=100005;
struct node{
	int x,y,id;
	friend bool operator < (node n,node m){
		return (n.y^m.y)?n.y<m.y:n.x<m.x;
	}
}a[N],f;
bool cmd(node n,node m){
	return (n.x^m.x)?n.x<m.x:n.y<m.y;
}
multiset<node> st;
multiset<node>::iterator it,tt;
int e,head[N],nex[N<<1],to[N<<1];
void add(int x,int y){
	to[++e]=y; nex[e]=head[x]; head[x]=e;
}
int q[N],l,fa[N],siz[N]; bool fl[N];
int find(int x){
	return fa[x]==x?x:fa[x]=find(fa[x]);
}
int main(){
	freopen("mincost.in","r",stdin); freopen("mincost.out","w",stdout);
	int n=read(),m=read(),k=read(),x,y,ans=21e8,inf=21e8;
	For(i,1,n) a[i].x=read(),a[i].y=read(),a[i].id=i;
	For(i,1,m) x=read(),y=read(),add(x,y),add(y,x);
	if (k==1){
		For(i,1,n) ans=min(ans,a[i].x+a[i].y); printf("%d\n",ans),exit(0);
	}
	sort(a+1,a+1+n,cmd);
	For(i,1,k-1) st.insert(a[i]); it=st.end();
	For(i,k,n){
		memset(fl,0,sizeof(fl)); st.insert(a[i]); if (i%200==0) cerr<<i<<' '<<clock()<<endl;
		For(j,1,n) fa[j]=j,siz[j]=1; it=st.begin(); fl[(*it).id]=1; ++it;
		while(it!=st.end()){
			f=*it; x=f.id; fl[x]=1;
			for(int j=head[x];j;j=nex[j])
				if (fl[to[j]]){
					y=to[j];
					if (find(y)!=x) siz[x]+=siz[fa[y]],fa[fa[y]]=x;
				}
			if (siz[x]>=k) {ans=min(ans,a[i].x+f.y); break;} ++it;
		}
	}
	if (ans==inf) printf("no solution\n");
	else printf("%d\n",ans);
	return 0;
}
