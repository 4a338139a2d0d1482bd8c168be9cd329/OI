#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=1e9;
int main(){
	srand(time(0));
	freopen("sj.in","w",stdout);
	int n=5000; printf("%d %d 10\n",n,n);
	For(i,1,n) printf("%d %d\n",rand()%mo+1,rand()%mo+1);
	For(i,2,n) printf("%d %d\n",i,rand()%(i-1)+1); printf("%d %d\n",n,n-1);
	return 0;
}
