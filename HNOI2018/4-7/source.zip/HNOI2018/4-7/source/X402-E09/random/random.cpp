#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=998244353,N=1e4;
typedef long long ll;
int b[7][7],ans,fa[7],cnt,n,m; bool a[7][7],fl[7][7];
int find(int x){
	return fa[x]==x?x:fa[x]=find(fa[x]);
}
int f(){
	memcpy(fl,a,49); cnt=n;
	For(k,1,n)
		For(i,1,n)
			For(j,1,n) if (fl[i][k]&&fl[k][j]&&i!=j) fl[i][j]=1;
	For(i,1,n) fa[i]=i;
	For(i,1,n-1)
		For(j,i+1,n)
			if (fl[i][j]&&fl[j][i]) if (find(i)!=find(j)) fa[fa[i]]=fa[j],--cnt;
	return cnt;
}
void dfs(int x,int y,ll z){
	if (x==n){
		ans+=z*f()%mo; if (ans>=mo) ans-=mo; return;
	}
	int xx=x,yy=y+1; if (y==n) ++xx,yy=xx+1;
	a[x][y]=1,dfs(xx,yy,z*b[x][y]%mo),a[x][y]=0;
	a[y][x]=1,dfs(xx,yy,z*(N-b[x][y])%mo),a[y][x]=0;
}
int main(){
	freopen("random.in","r",stdin); freopen("random.out","w",stdout);
	n=read(),m=read(); int x,y; ll rc=1;
	For(i,1,n-1)
		For(j,i+1,n) b[i][j]=5000;
	For(i,1,m) x=read(),y=read(),b[x][y]=read();
	y=n*(n-1)/2; For(i,1,y) rc=rc*N%mo;
	dfs(1,2,1); printf("%lld\n",rc*ans%mo);
	return 0;
}
