#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for (int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define x first
#define y second
#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

typedef long long LL;

const int oo = 0x3f3f3f3f;

const int maxabs = 1e9;

const int maxn = 1010;

int n;
pair<int, int> a[maxn + 5];
pair<int, int> b[maxn + 5];

set<pair<int, int> > allp;

set<int> allx;

inline bool legal(const pair<int, int> &x)
{
	if (allx.count(x.x)) return 0;
	if (allp.count(x)) return 0;
	set<pair<int, int> > allv;
	for (auto p : allp)
	{
		int u = x.x - p.x, v = x.y - p.y;
		if (u < 0 || (!u && v < 0)) u = -u, v = -v;
		int g = abs(__gcd(u, v));
		u /= g, v /= g;
		if (allv.count(mp(u, v))) return 0;
		allv.insert(mp(u, v));
	}
	return 1;
}

inline void add(const pair<int, int> &x)
{
	allx.insert(x.x);
	allp.insert(x);
}

inline LL cross(const pair<int, int> &x, const pair<int, int> &y, const pair<int, int> &z)
{
	return (LL)(y.x - x.x) * (z.y - x.y) - (LL)(y.y - x.y) * (z.x - x.x);
}

int wax, way, wbx, wby;

inline void gen_hull(pair<int, int> *ans, int goal, int wx, int wy)
{
	static pair<int, int> ret[maxn + 5];
	int m = 2;
	ret[0] = mp(-maxabs - 1, 0);
	ret[1] = mp(maxabs + 1, 0);
	while (m < goal + 2)
	{
		int tmp = rnd.wnext(-maxabs, maxabs, wx);
		int p = 0;
		while (ret[p + 1].x <= tmp) ++p;
		if (ret[p].x == tmp) continue;
		int down = max(((LL)ret[p + 1].y * (tmp - ret[p].x) + (LL)ret[p].y * (ret[p + 1].x - tmp)) / (ret[p + 1].x - ret[p].x) + 1, 1LL);
		LL up = maxabs;
		if (p >= 1) chkmin(up, ((LL)ret[p].y * (tmp - ret[p - 1].x) + (LL)ret[p - 1].y * (ret[p].x - tmp) - 1) / (ret[p].x - ret[p - 1].x));
		if (p + 2 < m) chkmin(up, ((LL)ret[p + 2].y * (tmp - ret[p + 1].x) + (LL)ret[p + 1].y * (ret[p + 2].x - tmp) - 1) / (ret[p + 2].x - ret[p + 1].x));
		if (down <= up)
		{
			pair<int, int> newp = mp(tmp, rnd.wnext(down, (int)up, wy));
			if (!legal(newp)) continue;
			add(newp);
			ret[m++] = newp;
			rotate(ret + p + 1, ret + m - 1, ret + m);
		}
	}
	REP(i, 1, m - 1) ans[i - 1] = mp(ret[i].x, maxabs - ret[i].y + 1);
}

int main(int argc, char *argv[])
{
    registerGen(argc, argv, 1);
	n = atoi(argv[1]);
	wax = rnd.next(-10, 10);
	way = rnd.next(-10, 10);
	wbx = rnd.next(-10, 10);
	wby = rnd.next(-10, 10);
	allx.clear(), allp.clear();
	gen_hull(a, n, wax, way);
	gen_hull(b, n, wbx, wby);
	REP(i, 0, n) b[i].y = -b[i].y;
	printf("%d\n", n);
	REP(i, 0, n) printf("%d %d\n", a[i].x, a[i].y);
	REP(i, 0, n) printf("%d %d\n", b[i].x, b[i].y);
	return 0;
}
