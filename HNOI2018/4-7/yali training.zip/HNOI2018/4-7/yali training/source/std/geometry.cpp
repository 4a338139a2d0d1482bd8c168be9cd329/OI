#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for (int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define x first
#define y second
#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

typedef long long LL;

const double inf = 1. / 0.;
const int oo = 0x3f3f3f3f;

const int maxn = 1010;

int n;
pair<int, int> a[maxn + 5];
pair<int, int> b[maxn + 5];

double ans;

bool ok[maxn + 5][2][2];
double dis[maxn + 5][2][2];

double le[maxn + 5], ri[maxn + 5];

inline bool check(int up, int down)
{
	if (up >= n || down >= n) return 0;
	REP(u, 0, n)
	{
		if (u != up && (a[u].x > a[up].x) == (a[u].x < b[down].x))
		{
			if (((LL)(a[u].x - a[up].x) * b[down].y + (LL)(b[down].x - a[u].x) * a[up].y > (LL)a[u].y * (b[down].x - a[up].x)) ^ (a[up].x > b[down].x)) return 0;
		}
	}
	REP(u, 0, n)
	{
		if (u != down && (b[u].x > a[up].x) == (b[u].x < b[down].x))
		{
			if (((LL)(b[u].x - a[up].x) * b[down].y + (LL)(b[down].x - b[u].x) * a[up].y < (LL)b[u].y * (b[down].x - a[up].x)) ^ (a[up].x > b[down].x)) return 0;
		}
	}
	return 1;
}

class RedemptionOfMatthew99
{
	public:
		double bestTraversal(vector<int> X1, vector<int> Y1, vector<int> X2, vector<int> Y2)
		{
			n = SZ(X1);
			REP(i, 0, n) a[i] = mp(X1[i], Y1[i]);
			REP(i, 0, n) b[i] = mp(X2[i], Y2[i]);
			REP(i, 0, n) REP(j, 0, 2) REP(k, 0, 2) if (j + k < 2)
			{ 
				int up = i + j, down = i + k;
				ok[i][j][k] = check(up, down);
				if (ok[i][j][k])
				{
					dis[i][j][k] = sqrt((LL)(a[up].x - b[down].x) * (a[up].x - b[down].x) + (LL)(a[up].y - b[down].y) * (a[up].y - b[down].y));
				}
				else dis[i][j][k] = inf;
			}

			le[0] = dis[0][0][0];
			REP(i, 0, n - 1)
			{
				le[i + 1] = le[i] + dis[i][0][1] + dis[i][1][0];
			}

			ri[n - 1] = dis[n - 1][0][0];
			for (int i = n - 2; i >= 0; --i)
			{
				ri[i] = ri[i + 1] + dis[i][0][1] + dis[i][1][0];
			}

			ans = min(le[n - 1], ri[0]);
			REP(i, 0, n - 1)
			{
				double path0 = dis[i][0][1], path1 = dis[i][1][0];
				for (int j = i + 1; j < n; ++j)
				{
					chkmin(ans, le[i] + min(path0, path1) + ri[j]);
					path0 += dis[j][0][0];
					path1 += dis[j][0][0];
					path0 += dis[j][0][1];
					path1 += dis[j][1][0];
				}
			}

			if (ans >= inf) return -1;
			return ans;
		}
};

int main()
{
	freopen("geometry.in", "r", stdin);
	freopen("geometry.out", "w", stdout);
	static int _n;
	static pair<int, int> _a[maxn + 5], _b[maxn + 5];
	scanf("%d", &_n);
	REP(i, 0, _n) scanf("%d%d", &_a[i].x, &_a[i].y);
	REP(i, 0, _n) scanf("%d%d", &_b[i].x, &_b[i].y);	
	vector<int> X1, Y1, X2, Y2;
	REP(i, 0, _n) X1.pb(_a[i].x), Y1.pb(_a[i].y), X2.pb(_b[i].x), Y2.pb(_b[i].y);

	RedemptionOfMatthew99 tmp;
	printf("%.15f\n", tmp.bestTraversal(X1, Y1, X2, Y2));

	return 0;
}
