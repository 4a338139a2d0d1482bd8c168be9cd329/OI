#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <cctype>
#include <cassert>
#include <ctime>
#include <climits>

#define REP(i, a, b) for (int i = (a), _end_ = (b); i != _end_; ++i)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#ifdef __WIN32
#define LLFORMAT I64
#define Rand() ((rand() << 15) | rand())
#else
#define LLFORMAT ll
#define Rand() rand()
#endif
#define mp make_pair
#define x first
#define y second

using namespace std;

typedef long long LL;

const int maxn = 300000, maxm = 500000;

int n, m, k;
pair<int, int> e[maxm + 5];

int wa[maxm + 5], wb[maxm + 5];

int a[maxn + 5], b[maxn + 5];

int pos0[maxm + 5], pos1[maxm + 5];

bool cmpa(const int &x, const int &y) { return wa[x] < wa[y]; }
bool cmpb(const int &x, const int &y) { return wb[x] < wb[y]; }

bool cmp(const int &x, const int &y)
{
	if (x == -1) return 0;
	if (y == -1) return 1;
	return b[x] < b[y];
}

struct node
{
	node *p;
	node *c[2];
	int id;
	int Max;
	int sz_chain, sz_tree;
	int val;
	bool rev;

	node(): p(NULL), Max(-1), sz_chain(1), sz_tree(0), val(0), rev(0) { memset(c, 0, sizeof c); }
	
	void update()
	{
		sz_chain = 1;
		sz_tree = val;
		Max = id;
		REP(i, 0, 2) if (c[i]) sz_chain += c[i]->sz_chain, sz_tree += c[i]->sz_tree, Max = max(Max, c[i]->Max, cmp);
	}

	void flag_rev()
	{
		rev ^= 1;
		swap(c[0], c[1]);
	}

	void push_down()
	{
		if (rev)
		{
			REP(i, 0, 2) if (c[i]) c[i]->flag_rev();
			rev = 0;
		}
	}

	int get_pos()
	{
		if (!this || !p) return 2;
		REP(i, 0, 2) if (p->c[i] == this) return i;
		return 2;
	}

	bool is_root()
	{
		return get_pos() >= 2;
	}

	void setc(node *u, const int &kind)
	{
		if (this && kind < 2) c[kind] = u;
		if (u) u->p = this;
	}

	void rotate()
	{
		node *p = this->p;
		bool mark = get_pos();
		p->p->setc(this, p->get_pos());
		p->setc(c[mark ^ 1], mark);
		setc(p, mark ^ 1);
		p->update();
	}

	void relax()
	{
		if (!is_root()) p->relax();
		push_down();
	}

	void splay()
	{
		relax();
		for ( ; !is_root(); rotate())
			if (!p->is_root()) (p->get_pos() == get_pos() ? p : this)->rotate();
		update();
	}

	node *access()
	{
		node *u = this, *v = NULL;
		for ( ; u; v = u, u = u->p)
		{
			u->splay();
			if (u->c[1]) u->val += u->c[1]->sz_chain + u->c[1]->sz_tree;
			if (v) u->val -= v->sz_chain + v->sz_tree;
			u->setc(v, 1);
			u->update();
		}
		splay();
		return v;
	}

	void be_root()
	{
		access();
		flag_rev();
	}

	void print();

};

node nd[maxn + 5];

void node::print()
{
	if (!this) return;
	push_down();
	c[0]->print();
	debug("%d ", this - nd);
	c[1]->print();
}

int tot = 0;

void link(const int &x, const int &y)
{
	node *u = nd + x, *v = nd + y;
	u->be_root();
	v->access();
	if (u->p)
	{
		if (v->Max == x) return;
		node *tmp = nd + v->Max;
		tmp->splay();
		if (tmp->c[0]) tmp->c[0]->p = NULL;
		tmp->setc(NULL, 0);
		tmp->update();
		u->splay();
		v->splay();
		v->setc(u, 1);
		v->update();
	}
	else
	{
		int sz0 = u->sz_chain + u->sz_tree;
		int sz1 = v->sz_chain + v->sz_tree;
		if (sz0 >= k) --tot;
		if (sz1 >= k) --tot;
		if (sz0 + sz1 >= k) ++tot;
		v->val += u->sz_chain + u->sz_tree;
		u->p = v;
		u->access();
	}
}

bool cut(const int &x, const int &y)
{
	if (!tot) return 0;
	node *u = nd + x, *v = nd + y;
	u->be_root();
	v->access();
	if (!u->p) return 1;
	if (v->c[0] != u || v->c[0]->sz_chain != 1) return 1;
	int tot = v->sz_tree + v->sz_chain;
	int left = u->sz_tree + u->sz_chain;
	int right = tot - left;
	bool ok = tot < k || left >= k || right >= k || ::tot >= 2;
	if (ok)
	{
		if (tot >= k) --::tot;
		if (left >= k) ++::tot;
		if (right >= k) ++::tot;
		u->p = NULL;
		v->setc(NULL, 0);
		v->update();
	}
	return ok;
}

int main()
{
	freopen("mincost.in", "r", stdin);
	freopen("mincost.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	REP(i, 0, n) scanf("%d%d", a + i, b + i), nd[i].id = i;
	if (k == 1)
	{
		int ans = INT_MAX;
		REP(i, 0, n) ans = min(ans, a[i] + b[i]);
		printf("%d\n", ans);
		return 0;
	}
	REP(i, 0, m)
	{
		pos0[i] = pos1[i] = i;
		static int x, y;
		scanf("%d%d", &x, &y), --x, --y;
		e[i] = mp(x, y);
		wa[i] = max(a[x], a[y]);
		wb[i] = max(b[x], b[y]);
	}
	sort(pos0, pos0 + m, cmpa);
	sort(pos1, pos1 + m, cmpb);
	int j = m - 1;
	int ans = -1;
	REP(i, 0, m)
	{
		if (tot && wb[pos0[i]] >= wb[pos1[j]]) continue;
		link(e[pos0[i]].x, e[pos0[i]].y);
		while (j > 0 && cut(e[pos1[j]].x, e[pos1[j]].y)) --j;
		if (tot && (ans == -1 || wa[pos0[i]] + wb[pos1[j]] < ans)) ans = wa[pos0[i]] + wb[pos1[j]];
	}
	if (ans == -1) printf("no solution\n");
	else printf("%d\n", ans);
	return 0;
}
