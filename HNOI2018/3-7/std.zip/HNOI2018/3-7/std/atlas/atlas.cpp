#include<bits/stdc++.h>
using namespace std;
 
#define CLZ(x) __builtin_clz(x)
#define CTZ(x) __builtin_ctz(x)
typedef unsigned int ui;
typedef long long ll;
const int BUF = 72000000;
 
char Buf[BUF],*buf=Buf;
inline int read() {
	int x = 0;
	char ch = *buf++;
	for(; !isdigit(ch); ch = *buf++);
	for(; isdigit(ch); ch = *buf++) x = x*10+(ch^48);
	return x;
}
 
int n, m, K, f[3010];
int st[100010], a[3010][3010];
bool g[3010][3010];
struct bitset {
    ui b[(3000>>5)+5];
    inline bool at(int x) {
        return (b[x>>5]>>(x&31))&1U;
    }
    inline void change(int x) {
        int pre = -1, nxt = -1, i, y = x>>5;
        b[y] ^= 1U<<(x&31);
        for(i = (x&31)-1; ~i; i--) if((b[y]>>i)&1U) {pre = i|(y<<5); break; }
        for(i = (x&31)+1; i < 32; i++) if((b[y]>>i)&1U) {nxt = i|(y<<5); break; }
        if(!(~pre)) 
            for(i = y-1; ~i; i--) if(b[i]) { pre = (31-CLZ(b[i]))|(i<<5); break; }
        if(!(~nxt)) {
            for(i = y+1; ; i++) if(b[i]) { nxt = CTZ(b[i])|(i<<5); break; }
        }
        int l = max(x-K+1, pre+1), r = min(x, nxt-K);
        if(l > r) return;
        if(at(x)) f[l]++, f[r+1]--;
        else f[l]--, f[r+1]++;
    }
}b[100010];
 
int ans1;
ll ans2;
 
inline void update() {
    int i, sum = 0;
    for(i = 1; i+K-1 <= m; i++) {
        sum += f[i];
        ans1 = max(ans1, sum);
        ans2 += sum;
    }
}
 
int main() {
 
	freopen("atlas.in", "r", stdin);
	freopen("atlas.out", "w", stdout);
    int i, j;
	fread(Buf,1,BUF,stdin);
	n = read(), m = read(), K = read();
    for(i = 1; i <= n; i++)
        for(j = 1; j <= m; j++) a[i][j] = read();
    for(i = 1; i <= 100000; i++) {
        b[i].b[0] = 1;
        b[i].b[(m+1)>>5] |= 1U<<((m+1)&31);
    }
    for(j = 1; j <= m; j++) {
        for(i = 1; i <= n; i++) {
            if(st[a[i][j]]) 
                g[st[a[i][j]]][j] = i-st[a[i][j]] > K;
            st[a[i][j]] = i;
        }
        for(i = 1; i <= n; i++) {
            if(st[a[i][j]]) {
                g[st[a[i][j]]][j] = true;
                st[a[i][j]] = 0;
            }
        }
    }
    for(i = 1; i <= K; i++) 
        for(j = 1; j <= m; j++) 
            if(!b[a[i][j]].at(j)) b[a[i][j]].change(j);
    for(update(), i = K+1; i <= n; i++, update()) {
        for(j = 1; j <= m; j++)
            if(!b[a[i][j]].at(j)) b[a[i][j]].change(j);
        for(j = 1; j <= m; j++)
            if(g[i-K][j]) b[a[i-K][j]].change(j);
    }
    printf("%d %lld\n", ans1, ans2);
    return 0;
}
