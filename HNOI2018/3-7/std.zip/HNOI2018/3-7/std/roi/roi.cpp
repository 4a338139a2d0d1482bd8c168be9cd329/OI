#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 1000010;
const ll MOD = 1000000007;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int mu[MAXN], n, m;
ll f[MAXN], F[MAXN], invf[MAXN];
ll ans, invF[MAXN];
int p[MAXN], cnt;
bool np[MAXN];

inline void update(ll &cur, ll val) {
	cur = cur * val % MOD;
}

inline void getprime() {
	register int i, j, x;
	mu[1] = 1;
	for(i = 2; i <= 1000000; i++) {
		if(!np[i]) {
			p[++cnt] = i;
			mu[i] = -1;
		}
		for(j = 1; j <= cnt && (x=p[j]*i) <= 1000000; j++) {
			np[x] = true;
			if(i % p[j]) mu[x] = -mu[i];
			else {
				mu[x] = 0;
				break;
			}
		}
	}
	for(i = 0; i <= 1000000; i++) F[i] = invF[i] = 1;
	for(i = 1; i <= 1000000; i++) 
		for(j = 1; (x = j * i) <= 1000000; j++) {
			if(mu[j] == 1) update(F[x], f[i]), update(invF[x], invf[i]);
			else if(mu[j] == -1) update(F[x], invf[i]), update(invF[x], f[i]);
		}
	for(i = 1; i <= 1000000; i++) {
		F[i] = F[i-1]*F[i]%MOD;
		invF[i] = invF[i-1]*invF[i]%MOD;
	}
}

int main() {
	freopen("roi.in", "r", stdin);
	freopen("roi.out", "w", stdout);

	int i, j, T = read();
	f[1] = invf[1] = 1;
	for(i = 2; i <= 1000000; i++) {
		f[i] = f[i-1]+f[i-2];
		if(f[i] >= MOD) f[i] -= MOD;
		invf[i] = qpow(f[i], MOD-2);
	}
	getprime();

	/*for(i = 1; i <= 5; i++) printf("%lld ", F[i]);
	printf("\n");*/
	//printf("%lld %lld %lld\n", F[2], invF[1], f[2]);
	while(T--) {
		n = read(), m = read();
		if(n > m) swap(n, m);
		ans = 1;
		for(i = 1; i <= n; i = j+1) {
			j = min(n/(n/i), m/(m/i));
			//cerr << i << endl;
			ans = ans*qpow(F[j]*invF[i-1]%MOD, (ll)(n/i)*(m/i)%(MOD-1))%MOD;
		}
		printf("%lld\n", ans);
	}
	return 0;
}
