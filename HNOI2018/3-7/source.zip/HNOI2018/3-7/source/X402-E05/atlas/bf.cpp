#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define lc p<<1
#define rc p<<1|1
#define ls l,mid
#define rs mid+1,r
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=3010;
const int M=100010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("atlas.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,m,K,vis[M],cnt;
int a[N][N],s[N][N],len;
inline int Get(int xl,int xr,int yl,int yr)
{
	int ret=0;
	For(i,xl,xr)
	For(j,yl,yr)
	{
		if(!vis[a[i][j]])ret++;
		vis[a[i][j]]++;
	}
	For(i,xl,xr)For(j,yl,yr)vis[a[i][j]]--;
	return ret;
}
int main()
{
	int Max=0,ans=0;
	file();
	read(n),read(m),read(K);
	For(i,1,n)For(j,1,m)read(a[i][j]);
	For(i,1,n-K+1)
		For(j,1,m-K+1)
		{
			int x=Get(i,i+K-1,j,j+K-1);
			ans+=x;
			chkmax(Max,x);
		}
	printf("%d %d\n",Max,ans);
	return 0;
}
