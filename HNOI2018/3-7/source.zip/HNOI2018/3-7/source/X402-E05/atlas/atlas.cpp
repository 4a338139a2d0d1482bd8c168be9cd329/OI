#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define lc p<<1
#define rc p<<1|1
#define ls l,mid
#define rs mid+1,r
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=3010;
const int M=100010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("atlas.in","r",stdin);
	freopen("atlas.out","w",stdout);
}
int n,m,K,vis[M],cnt,S;
int a[N][N],s[N][N],len;
inline void Solve1()
{
	//cerr<<1<<endl;
	printf("%lld %lld\n",1ll*K*K,1ll*K*K*(n-K+1)*(m-K+1));
}
inline int Sum(int x0,int y0,int x1,int y1){return s[x1][y1]-s[x1][y0]-s[x0][y1]+s[x0][y0];}
inline void Solve2()
{
	//cerr<<2<<endl;
	For(i,1,n)
	{
		For(j,1,m)s[i][j]=s[i][j-1]+(a[i][j]==a[1][1]);
		For(j,1,m)s[i][j]+=s[i-1][j];
	}
	int Max=0,ans=0;
	For(i,0,n-K)
	For(j,0,m-K)
	{
		int x=Sum(i,j,i+K,j+K);
		int cnt=1+(x!=K*K&&x!=0);
		chkmax(Max,cnt);
		ans+=cnt;
	}
	printf("%d %d\n",Max,ans);
}
struct Segment_Tree
{
	int t[N<<3],Add[N<<3];
	inline void Add_node(int p,int l,int r,int x){Add[p]+=x,t[p]+=x;}
	inline void pushdown(int p,int l,int r)
	{
		if(Add[p]^0)
		{
			int mid=(l+r)>>1;
			Add_node(lc,ls,Add[p]);
			Add_node(rc,rs,Add[p]);
			Add[p]=0;
		}
	}
	inline void Add_tree(int l,int r,int p,int x,int y,int z)
	{
		if(x<=l&&r<=y){Add[p]+=z,t[p]+=z;return;}
		int mid=(l+r)>>1;pushdown(p,l,r);
		if(x<=mid)Add_tree(ls,lc,x,y,z);
		if(y> mid)Add_tree(rs,rc,x,y,z);
		t[p]=max(t[lc],t[rc]);
	}
}ST;
vector<int>c[M];
vector<int>::iterator it;
inline void Add(vector<int>&X,int pos)
{
	int l=max(pos-K+1,1),r=min(pos,len);
	it=lower_bound(X.begin(),X.end(),pos);
	if(it!=X.end())chkmin(r,(*it)-K);
	if(it!=X.begin())--it,chkmax(l,(*it)+1);
	X.insert(lower_bound(X.begin(),X.end(),pos),pos);
	if(l<=r)ST.Add_tree(1,len,1,l,r,1),S+=(r-l+1);
}
inline void Del(vector<int>&X,int pos)
{
	int l=max(pos-K+1,1),r=min(pos,len);
	X.erase(lower_bound(X.begin(),X.end(),pos));
	it=lower_bound(X.begin(),X.end(),pos);
	if(it!=X.end())chkmin(r,(*it)-K);
	if(it!=X.begin())--it,chkmax(l,(*it)+1);
	if(l<=r)ST.Add_tree(1,len,1,l,r,-1),S-=(r-l+1);
}
inline void Solve()
{
	//cerr<<3<<endl;
	len=m-K+1;
	//cerr<<len<<endl;
	int Max=0;
	LL ans=0;
	For(i,1,K-1)For(j,1,m)Add(c[a[i][j]],j);
	For(i,K,n)
	{
		if(i-K>0){For(j,1,m)Del(c[a[i-K][j]],j);}
		For(j,1,m)Add(c[a[i][j]],j);
		chkmax(Max,ST.t[1]);
		ans+=S;
	}
	printf("%d %lld\n",Max,ans);
}
int main()
{

	int flag=1;
	file();
	read(n),read(m),read(K);
	For(i,1,n)For(j,1,m)
	{
		read(a[i][j]);
		if(vis[a[i][j]])flag=0;
		else vis[a[i][j]]=1,cnt++;
	}
	if(flag)Solve1();
	else if(cnt<=2)Solve2();
	else Solve();
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
