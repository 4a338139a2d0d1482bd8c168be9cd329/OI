#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const LL mod=1e9+7;
const int N=1000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
}
int T,n,m;
int mu[N],pr[N],p[N],cnt;
LL Mu[N],ans,f[N],F[N];
inline void Add(LL&x,LL y){x=x+y<mod?x+y:x+y-mod;}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void init(int n)
{
	f[0]=0,f[1]=1,F[1]=F[0]=1;
	For(i,2,n)f[i]=(f[i-1]+f[i-2])%mod;
	For(i,2,n)F[i]=F[i-1]*f[i]%mod;
	mu[1]=1;
	For(i,2,n)
	{
		if(!p[i])pr[++cnt]=i,mu[i]=-1;
		for(int j=1;j<=cnt&&i*pr[j]<=n;++j)
		{
			p[i*pr[j]]=1;
			if(i%pr[j]==0)break;
			mu[i*pr[j]]=-mu[i];
		}
	}
	For(i,1,n)Mu[i]=Mu[i-1]+mu[i];
}
inline LL Get(int n,int m)
{
	LL ret=0;
	for(int l=1,r;l<=n;l=r+1)
	{
		r=min(n/(n/l),m/(m/l));
		ret+=(Mu[r]-Mu[l-1])*(n/l)*(m/l);
	}
	return ret%(mod-1);
}
int main()
{
	file();
	read(T);
	init(1000000);
	while(T--)
	{
		read(n),read(m);
		if(n>m)swap(n,m);
		ans=1;
		for(int l=1,r;l<=n;l=r+1)
		{
			r=min(n/(n/l),m/(m/l));
			ans=ans*qpow(F[r]*qpow(F[l-1],mod-2)%mod,Get(n/l,m/l))%mod;
		}
		printf("%lld\n",ans);
	}
	cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
