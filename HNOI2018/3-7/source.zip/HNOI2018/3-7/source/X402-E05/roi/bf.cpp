#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const LL mod=1e9+7;
const int N=1000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("roi.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int T,d[N],n,m;
LL ans,f[N];
inline void Add(LL&x,LL y){x=x+y<mod?x+y:x+y-mod;}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void init(int n)
{
	f[0]=0,f[1]=1;
	For(i,2,n)
	{
		f[i]=(f[i-1]+f[i-2])%mod;
	}
}
int main()
{
	file();
	read(T);
	init(100000);
	while(T--)
	{
		read(n),read(m);
		if(n>m)swap(n,m);
		ans=1;
		For(i,1,n)For(j,1,m)d[__gcd(i,j)]++;
		For(i,1,n)ans=ans*qpow(f[i],d[i])%mod,d[i]=0;
		printf("%lld\n",ans);
	}
	return 0;
}
