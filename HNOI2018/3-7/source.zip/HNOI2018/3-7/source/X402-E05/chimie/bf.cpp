#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define lc p<<1
#define rc p<<1|1
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=200010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("chimie.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,Q;
int a[N],t[N<<3];
inline void Solve_BF()
{
	int type,x,y,z;
	while(Q--)
	{
		read(type),read(x),read(y);
		if(type==3)
		{
			int ret=0;
			For(i,x,y)chkmax(ret,a[i]);
			printf("%d\n",ret);
		}
		if(type==2){read(z);For(i,x,y)a[i]|=z;}
		if(type==1){read(z);For(i,x,y)a[i]&=z;}
	}
}
inline void Build(int l,int r,int p)
{
	if(l==r){t[p]=a[l];return;}
	int mid=(l+r)>>1;
	Build(ls,lc),Build(rs,rc);
	t[p]=max(t[lc],t[rc]);
}
inline int Query(int l,int r,int p,int x,int y)
{
	if(x<=l&&r<=y)return t[p];
	int mid=(l+r)>>1,ret=0;
	if(x<=mid)chkmax(ret,Query(ls,lc,x,y));
	if(y> mid)chkmax(ret,Query(rs,rc,x,y));
	return ret;
}
inline void Modify(int l,int r,int p,int x,int y)
{
	if(l==r){t[p]=y;return;}
	int mid=(l+r)>>1;
	x<=mid?Modify(ls,lc,x,y):Modify(rs,rc,x,y);
	t[p]=max(t[lc],t[rc]);
}
inline void Solve()
{
	int type,x,y,z;
	Build(1,n,1);
	while(Q--)
	{
		read(type),read(x),read(y);
		if(type==3)printf("%d\n",Query(1,n,1,x,y));
		if(type==2)read(z),a[x]|=z,Modify(1,n,1,x,a[x]);
		if(type==1)read(z),a[x]&=z,Modify(1,n,1,x,a[x]);
	}
}
int main()
{
	file();
	read(n),read(Q);
	For(i,1,n)read(a[i]);
	Solve_BF();
	return 0;
}
