#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int main() {

	freopen("roi.in", "w", stdout);
	
	int Case = 1000, mx = 1e6;
	printf("%d\n", Case);
	while (Case--) printf("%d %d\n", rand() % mx + 1, rand() % mx + 1);

	return 0;
}
