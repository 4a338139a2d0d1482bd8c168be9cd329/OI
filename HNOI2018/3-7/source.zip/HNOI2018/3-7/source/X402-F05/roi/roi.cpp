#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int Mod = 1e9 + 7;
const int N = 1e6 + 10, M = 4000;

int val[M + 5][M + 5];

int gcd(int x, int y) {
	if (val[x][y]) return val[x][y];
	return val[x][y] = (!y ? x : gcd(y, x % y));
}

int Pow(int x, LL e) {
	int ret = 1;
	while (e) {
		if (e & 1) ret = 1ll * ret * x % Mod;
		x = 1ll * x * x % Mod;
		e >>= 1;
	}
	return ret;
}

int prm[N], mu[N], tot;

void init(int n) {
	mu[1] = 1;
	For(i, 2, n) {
		if (!prm[i]) prm[++tot] = i, mu[i] = -1;
		for (int j = 1; j <= tot && i * prm[j] <= n; ++j) {
			int x = i * prm[j];
			prm[x] = true;
			if (i % prm[j]) mu[x] = -mu[i];
			else break;
		}
	}
	For(i, 2, n) mu[i] += mu[i - 1];
}

int f[N], inv[N];
int pre[M + 5][M + 5];

LL S(int n, int m) {
	if (n <= M && m <= M) return pre[n][m];
	if (1ll * n * m <= 1e9) {
		int ret = 0;
		for (int i = min(n, m), nxt; i; i = nxt) {
			nxt = max(n / (n / i + 1), m / (m / i + 1));
			ret += (mu[i] - mu[nxt]) * (n / i) * (m / i);
		}
		return ret;
	} else {
		LL ret = 0;
		for (int i = min(n, m), nxt; i; i = nxt) {
			nxt = max(n / (n / i + 1), m / (m / i + 1));
			ret += 1ll * (mu[i] - mu[nxt]) * (n / i) * (m / i);
		}
		return ret;
	}
}

int main () {

	freopen("roi.in", "r", stdin);
	freopen("roi.out", "w", stdout);
	
	int lim = 1e6;
	f[0] = 0, f[1] = 1;
	For(i, 1, M) For(j, 1, M) 
		pre[i][j] = pre[i - 1][j] + pre[i][j - 1] - pre[i - 1][j - 1] + (gcd(i, j) == 1);
	For(i, 2, lim) f[i] = (f[i - 1] + f[i - 2]) % Mod;
	For(i, 2, lim) f[i] = 1ll * f[i] * f[i - 1] % Mod;
	inv[0] = 1;
	For(i, 1, lim) inv[i] = Pow(f[i], Mod - 2);
	init(lim);

	int Case;
	scanf("%d", &Case);
	while (Case--) {

		int n, m;
		scanf("%d%d", &n, &m);

		int ans = 1;
		for (int i = min(n, m), nxt; i; i = nxt) {
			nxt = max(n / (n / i + 1), m / (m / i + 1));
			ans = 1ll * ans * Pow(1ll * f[i] * inv[nxt] % Mod, S(n / i, m / i)) % Mod;
		}
		printf("%d\n", ans);

	}

	return 0;
}
