#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("chimie.in", "w", stdout);

	srand(time(0));

	int n = 50000, q = 50000;
	printf("%d %d\n", n, q);
	For(i, 1, n) printf("%d%c", randint(0, (1 << 20) - 1), i == n ? '\n' : ' ');
	For(i, 1, q) {
		int op = randint(1, 3), l = randint(1, n), r = randint(1, n);
		if (l > r) std::swap(l, r);
		if (op <= 2) printf("%d %d %d %d\n", op, l, r, randint(0, (1 << 20) - 1));
		else printf("%d %d %d\n", op, l, r);
	}
	
	return 0;
}
