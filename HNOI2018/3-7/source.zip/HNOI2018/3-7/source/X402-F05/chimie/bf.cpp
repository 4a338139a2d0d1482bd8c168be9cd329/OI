#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

int Read() {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 2e5 + 10, mx = (1 << 20) - 1;

int A[N];
int n, q;

int main() {

	freopen("chimie.in", "r", stdin);
	freopen("chimie.ans", "w", stdout);	
	
	n = Read(), q = Read();
	For(i, 1, n) A[i] = Read();

	For(id, 1, q) {
		int op = Read(), l = Read(), r = Read(), x = 0;
		if (op == 1) {
			x = Read();
			For(i, l, r) A[i] &= x;
		} else if (op == 2) {
			x = Read();
			For(i, l, r) A[i] |= x;
		} else {
			For(i, l, r) x = max(x, A[i]);
			printf("%d\n", x);
		}
	}

	return 0;
}

