#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

int Read() {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 2e5 + 10, mx = (1 << 20) - 1;

int A[N];
int line;

struct Segment_Tree {

	int val[N << 2], same[N << 2];
	int Max[N << 2];
	int setv[N << 2];

	#define lc (o << 1)
	#define rc (o << 1 | 1)
	#define M ((L + R) >> 1)

	void pushup(int o) {
		same[o] = (same[lc] & same[rc]) & (mx ^ (val[lc] ^ val[rc]));
		val[o] = same[o] & val[lc];
	//	assert((same[o] & val[lc]) == (same[o] & val[rc]));
		Max[o] = max(Max[lc], Max[rc]);
	}

	void pushdown(int o, int L, int R) {
		if (setv[o]) {
			set(lc, L, M, L, M, setv[o], val[o] & setv[o]);
			set(rc, M + 1, R, M + 1, R, setv[o], val[o] & setv[o]);
		}
		setv[o] = 0;
	}

	void build(int o, int L, int R) {
		if (L == R) {
			same[o] = mx;
			val[o] = Max[o] = A[L];
		} else {
			build(lc, L, M), build(rc, M + 1, R);
			pushup(o);
		}
	}

	void set(int o, int L, int R, int l, int r, int mask, int w) {
		if (l <= L && R <= r) {
			if ((mask | same[o]) == same[o]) {
				int dt = mask & (w ^ val[o]);
				val[o] ^= dt, Max[o] ^= dt;
				setv[o] |= mask;
				return;
			}
		}
		// assert(L < R);
		pushdown(o, L, R);
		if (l <= M) set(lc, L, M, l, r, mask, w);
		if (r > M) set(rc, M + 1, R, l, r, mask, w);
		pushup(o);
	}

	int qmax(int o, int L, int R, int l, int r) {
		if (l <= L && R <= r) return Max[o];

		pushdown(o, L, R);
		int ans = 0;
		if (l <= M) ans = qmax(lc, L, M, l, r);
		if (r > M) ans = max(ans, qmax(rc, M + 1, R, l, r));
		return ans;
	}

}T;

int n, q;

int main() {

	freopen("chimie.in", "r", stdin);
	freopen("chimie.out", "w", stdout);	
	
	n = Read(), q = Read();
	For(i, 1, n) A[i] = Read();
	T.build(1, 1, n);

	For(id, 1, q) {
		int op = Read(), l = Read(), r = Read(), x;
		if (op == 1) {
			x = Read();
			int mask = 0;
			For(i, 0, 19) if (!(x & (1 << i))) mask |= 1 << i;
			if (mask) T.set(1, 1, n, l, r, mask, 0);
		} else if (op == 2) {
			x = Read();
			int mask = 0;
			For(i, 0, 19) if (x & (1 << i)) mask |= 1 << i;
			if (mask) T.set(1, 1, n, l, r, mask, mask);
		} else {
			++line;
			printf("%d\n", T.qmax(1, 1, n, l, r));
		}
	}

	return 0;
}

