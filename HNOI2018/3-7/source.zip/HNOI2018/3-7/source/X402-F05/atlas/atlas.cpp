#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

int Read() {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 3010, M = 1e5 + 10;

int n, m, k;
int A[N][N];

namespace BF {

	int cnt[M], now;

	inline void del(int x) {
		--cnt[x];
		if (!cnt[x]) --now;
	}

	inline void add(int x) {
		++cnt[x];
		if (cnt[x] == 1) ++now;
	}

	void main() {
		long long sum = 0;
		int ans = 0;
		For(i, 1, k) For(j, 1, k) add(A[i][j]);

		For(j, 1, m - k + 1) {
			int r = n - k + 1;
			if (j & 1) {
				if (j != 1) {
					For(x, 1, k) del(A[x][j - 1]), add(A[x][j + k - 1]);
				}
				ans = max(ans, now);
				sum += now;
				For(i, 1, r - 1) {
					For(y, j, j + k - 1) del(A[i][y]), add(A[i + k][y]);
					ans = max(ans, now);
					sum += now;
				}
			} else {
				For(x, r, n) del(A[x][j - 1]), add(A[x][j + k - 1]);
				ans = max(ans, now);
				sum += now;
				Forr(i, r - 1, 1) {
					For(y, j, j + k - 1) del(A[i + k][y]), add(A[i][y]);
					ans = max(ans, now);
					sum += now;
				}
			}
		}
		printf("%d %lld\n", ans, sum);
	}


};

namespace Subtask5 {
	
	int ans[N][N], c[N][N];

	void main() {
		For(w, 1, 2) {
			For(i, 1, n) For(j, 1, m) 
				c[i][j] = c[i - 1][j] + c[i][j - 1] - c[i - 1][j - 1] + (A[i][j] == w);
			For(i, k, n) For(j, k, m)
				ans[i][j] += bool(c[i][j] - c[i - k][j] - c[i][j - k] + c[i - k][j - k]);
		}
		int mx = 0;
		long long sum = 0;
		For(i, 1, n) For(j, 1, m) mx = max(mx, ans[i][j]), sum += ans[i][j];
		printf("%d %lld\n", mx, sum);
	}
};


int main() {

	freopen("atlas.in", "r", stdin);
	freopen("atlas.out", "w", stdout);

	n = Read(), m = Read(), k = Read();
	For(i, 1, n) For(j, 1, m) A[i][j] = Read();

	if (n * m <= 300000) BF::main();
	else Subtask5::main();
	
	return 0;
}
