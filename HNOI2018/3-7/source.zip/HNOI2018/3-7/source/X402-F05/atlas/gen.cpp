#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("atlas.in", "w", stdout);
	int n = 3000, m = 100, k = 50;
	printf("%d %d %d\n", n, m, k);
	For(i, 1, n) For(j, 1, m) printf("%d%c", randint(1, 100000), j == m ? '\n' : ' ');

	srand(time(0));

	return 0;
}
