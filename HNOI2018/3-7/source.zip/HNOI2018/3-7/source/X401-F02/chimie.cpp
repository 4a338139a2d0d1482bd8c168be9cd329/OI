#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}
const int maxn=5e3+5;

int X[maxn];

void awy(int l,int r,int x){
	for(int i=l;i<=r;i++)
		X[i]&=x;
}

void awh(int l,int r,int x){
	for(int i=l;i<=r;i++)
		X[i]|=x;
}

int qiumx(int l,int r){
	int maxx=0;
	for(int i=l;i<=r;i++)
		maxx=max(maxx,X[i]);
	return maxx;
}

int main()
{
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
	int n,q;
	read(n),read(q);
	for(int i=1;i<=n;i++)
		read(X[i]);
	for(int i=1;i<=q;i++){
		int op,l,r,x;
		read(op),read(l),read(r);
		if(op!=3) read(x);
		if(op==1) awy(l,r,x);
		if(op==2) awh(l,r,x);
		if(op==3) printf("%d\n",qiumx(l,r));
	}
    return 0;
}
