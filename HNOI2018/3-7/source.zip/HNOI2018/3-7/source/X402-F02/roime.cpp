#include<bits/stdc++.h>
const int N=1e6+10;
const int mod=1000000007;
			
#define ll long long
using namespace std;

int n,m;
int f[N+10],mu[N+10],p[N+10],pnt;
bool vis[N+10];
ll smu[N+10];
ll a[N+10],b[N+10];

int gcd(int a,int b){
	if(!b) return a;
	return gcd(b,a%b);
}

void init(){
	mu[1]=1;
	for(int i=2; i<=N; ++i){
		if(!vis[i]) p[++pnt]=i,mu[i]=-1;
		for(int j=1; 1ll*i*p[j]<=N; ++j){
			vis[i*p[j]]=1;
			if(i%p[j]==0) break;
			mu[i*p[j]]=mod-mu[i];
		}
	}
	for(int i=1; i<=N; ++i) smu[i]=(mod+smu[i-1]+mu[i])%mod;
}

ll fpm(ll x,ll y){
	ll s=1;
	while(y){
		if(y&1)s=s*x%mod;
		y>>=1;x=x*x%mod;
	}
	return s;
}

int main(){
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
	int T;
	scanf("%d",&T);
	f[0]=0;f[1]=1;
	for(int i=2; i<=N; ++i) f[i]=(f[i-1]+f[i-2])%mod;
	a[0]=1;
	for(int i=1; i<=N; ++i) a[i]=a[i-1]*f[i]%mod;
	b[0]=1;
	for(int i=1; i<=N; ++i) b[i]=b[i-1]*fpm(f[i],mod-2)%mod;

	init();
	long long ans=0;

	while(T--){
		scanf("%d%d",&n,&m);
		ans=1;
		if(n>m) swap(n,m);
		for(int i=1,nii; i<=n; i=nii+1){
			ll ret=0;
			nii=(n/(n/i));
			int gn=n/i,gm=m/i;
			for(int j=1,ni; j<=gn; j=ni+1){
				ni=min(gn/(gn/j),gm/(gm/j));
				ret=(mod+ret+1ll*(mod+smu[ni]-smu[j-1])%mod*((gn/j))%mod*((gm/j))%mod)%mod;
				ret%=mod;
			}
			//ans=ans*fpm(f[i],ret)%mod;
			ans=1ll*ans*fpm(1ll*(a[nii]*b[i-1]%mod),ret)%mod;
		}
		printf("%lld\n",ans);
	}
}
