#include<bits/stdc++.h>
using namespace std;

int n,m;
int f[100];

int gcd(int a,int b){
	if(!b) return a;
	return gcd(b,a%b);
}

int main(){
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);

	int T;
	scanf("%d",&T);
	int ans=1;

	while(T--){
		scanf("%d%d",&n,&m);
		ans=1;
		f[0]=0; f[1]=1;
		for(int i=2; i<=10; ++i) f[i]=f[i-1]+f[i-2];
		int cnt=0;
		for(int j=1; j<=n; ++j)
			for(int k=1; k<=m; ++k)
				if(f[gcd(j,k)]){
					ans*=f[gcd(j,k)];
				}
		printf("%d\n",ans);
		//printf("!%d\n",ans);
	}

	/*	g[0]=0;
	g[1]=1;
	for(int i=2; i<=30; ++i) g[i]=g[i-1]+g[i-2];
	
	for(int i=0; i<=20; ++i) if(g[i]<1000010) f[g[i]]=1;
	for(int i=1; i<=300; ++i){
		printf("%d:",i);puts("");
		for(int j=1; i*j<=300; ++j) if(f[i*j]) printf("%d ",i*j);
		puts("");
	}*/
}
