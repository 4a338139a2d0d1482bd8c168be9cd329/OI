#include<bits/stdc++.h>
#define reg register 
#define ll long long
#define getchar getchar_unlocked
using namespace std;
const int N=3e3+10;

int n,m,k,c;
int a[N][N];
int b[N][N];
int d[100000+10];

namespace solver{
	void upd(int x,int y){
		if(y==1){
			if(!d[x]) ++c;
			++d[x];
		}
		if(y==-1){
			--d[x];
			if(!d[x]) --c;
		}
	}
	inline int read(){
		char ch=getchar();
		int x=0;
		while(ch>'9'||ch<'0')ch=getchar();
		while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
		return x;
	}
	void solve(){
		freopen("atlas.in","r",stdin);
		freopen("atlas.out","w",stdout);
		n=read(); m=read(); k=read();
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=m; ++j)
				a[i][j]=read(),d[a[i][j]]=1;
		int ck=0;
		for(int i=0; i<=100000; ++i) ck+=(bool)(d[i]==1);
		if(n*m==ck){
			long long ret=1ll*k*k*(n-k+1)*(m-k+1);
			int mx=k*k;
			printf("%d %lld\n",mx,ret);
			return;
		}
		for(int v=1; v+k-1<=n; ++v){
			for(int i=0; i<=100000; ++i) d[i]=0;
			c=0;
			for(int i=1; i<=k; ++i)
				for(int j=1; j<=k; ++j)
					upd(a[v+i-1][j],1);
			b[v][1]=c;
			for(int i=2; i+k-1<=m; ++i){
				for(int j=1; j<=k; ++j)upd(a[v+j-1][i-1],-1);
				for(int j=1; j<=k; ++j)upd(a[v+j-1][i+k-1],1);
				b[v][i]=c;
			}
		}
		long long ans=0;
		int mx=0;
		for(int i=1; i<=n; ++i)for(int j=1;j<=m;++j) ans+=b[i][j],
			mx=b[i][j]>mx?b[i][j]:mx;
		printf("%d %lld\n",mx,ans);
	}
}

int main(){
	solver::solve();
}
