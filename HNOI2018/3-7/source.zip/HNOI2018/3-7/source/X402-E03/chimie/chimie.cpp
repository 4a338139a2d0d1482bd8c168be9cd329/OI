#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 2e5+5 ;
int n, m, s[maxn], tree[maxn*4], taga[maxn*4], tago[maxn*4] ;
int AND ( int &a, int b ) {
	if (b >= 0) {
		if (a >= 0) a &= b ;
		else a = b ;
	}
	return a ;
}
int OR ( int &a, int b ) {
	if (b >= 0) {
		if (a >= 0) a |= b ;
		else a = b ;
	}
	return a ;
}
void push_up ( int h ) {
	tree[h] = max(tree[h<<1], tree[h<<1|1]) ;
}
void push_down ( int h ) {
	if (taga[h] >= 0) {
		AND(taga[h<<1], taga[h]) ;
		AND(taga[h<<1|1], taga[h]) ;
		if (tago[h<<1] >= 0) AND(tago[h<<1], taga[h]) ;
		if (tago[h<<1|1] >= 0) AND(tago[h<<1|1], taga[h]) ;
	}
	if (tago[h] >= 0) {
		if (taga[h<<1] >= 0) OR(taga[h<<1], tago[h]) ;
		if (taga[h<<1|1] >= 0) OR(taga[h<<1|1], tago[h]) ;
		OR(tago[h<<1], tago[h]) ;
		OR(tago[h<<1|1], tago[h]) ;
	}
	taga[h] = tago[h] = -1 ;
}
void create ( int h, int l, int r ) {
	taga[h] = tago[h] = -1 ;
	if (l == r) {
		tree[h] = s[l] ;
		return ;
	}
	int mid = (l+r)>>1 ;
	create(h<<1, l, mid), create(h<<1|1, mid+1, r) ;
	push_up(h) ;
}
void Updatea ( int h, int l, int r, int x, int y, int v ) {
	if (x <= l && r <= y) {
		AND(taga[h], v) ;
		return ;
	}
	push_down(h) ;
	int mid = (l+r)>>1 ;
	if (y <= mid) Updatea(h<<1, l, mid, x, y, v) ;
	else if (x > mid) Updatea(h<<1|1, mid+1, r, x, y, v) ;
	else {
		Updatea(h<<1, l, mid, x, mid, v) ;
		Updatea(h<<1|1, mid+1, r, mid+1, y, v) ;
	}
	push_up(h) ;
}
void Updateo ( int h, int l, int r, int x, int y, int v ) {
	if (x <= l && r <= y) {
		OR(tago[h], v) ;
		return ;
	}
	push_down(h) ;
	int mid = (l+r)>>1 ;
	if (y <= mid) Updateo(h<<1, l, mid, x, y, v) ;
	else if (x > mid) Updateo(h<<1|1, mid+1, r, x, y, v) ;
	else {
		Updateo(h<<1, l, mid, x, mid, v) ;
		Updateo(h<<1|1, mid+1, r, mid+1, y, v) ;
	}
	push_up(h) ;
}
int Query ( int h, int l, int r, int x ) {
	//printf ( "[%d,%d] taga=%d tago=%d\n", l, r, taga[h], tago[h] ) ;
	if (l == r) {
		AND(s[l], taga[h]) ;
		OR(s[l], tago[h]) ;
		taga[h] = tago[h] = -1 ;
		return s[l] ;
	}
	int mid = (l+r)>>1 ;
	push_down(h) ;
	if (x <= mid) return Query(h<<1, l, mid, x) ;
	else return Query(h<<1|1, mid+1, r, x) ;
}
int Query  ( int h, int l, int r, int x, int y ) {
	if (x <= l && r <= y) return tree[h] ;
	int mid = (l+r)>>1 ;
	if (y <= mid) return Query(h<<1, l, mid, x, y) ;
	else if (x > mid) return Query(h<<1|1, mid+1, r, x, y) ;
	return max(Query(h<<1, l, mid, x, mid), Query(h<<1|1, mid+1, r, mid+1, y)) ;
}
void check() {
	for ( int i = 1 ; i <= n ; i ++ )
		printf ( "%d ", Query(1, 1, n, i) ) ;
	puts("") ;
}
struct node {
	int op, l, r, v ;
} q[maxn] ;
void solve1() {
	int i, j, x ;
	for ( i = 1 ; i <= m ; i ++ ) {
		if (q[i].op == 1) for ( j = q[i].l ; j <= q[i].r ; j ++ )
			s[j] &= q[i].v ;
		if (q[i].op == 2) for ( j = q[i].l ; j <= q[i].r ; j ++ )
			s[j] |= q[i].v ;
		if (q[i].op == 3) {
			for ( x = -1, j = q[i].l ; j <= q[i].r ; j ++ )
				x = max(x, s[j]) ;
			printf ( "%d\n", x ) ;
		}
	}
}
void solve4() {
	create(1, 1, n) ;
	for ( int i = 1 ; i <= m ; i ++ )
		printf ( "%d\n", Query(1, 1, n, q[i].l, q[i].r) ) ;
}
int main() {
	freopen ( "chimie.in", "r", stdin ) ;
	freopen ( "chimie.out", "w", stdout ) ;
	memset (taga, -1, sizeof taga) ;
	memset (tago, -1, sizeof tago) ;
	int i ;
	Read(n), Read(m) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(s[i]) ;
	bool is4 = 1 ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(q[i].op), Read(q[i].l) ;
		Read(q[i].r) ;
		if (q[i].op ^ 3) {
			Read(q[i].v) ;
			is4 = 0 ;
		}
	}
	if (is4) solve4() ;
	else solve1() ;
	return 0 ;
}
