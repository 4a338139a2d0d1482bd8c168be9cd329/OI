#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
void chkmax ( int &a, int b ) { a = a>b? a:b ; }
const int maxn = 205, maxv = 1e5+5 ;
int t, tree[maxv*4], ct[maxv*4] ;
int g[3005][3005], n, m, k, b[9000005] ;
void push_up ( int h ) {
	tree[h] = tree[h<<1] + tree[h<<1|1] ;
	ct[h] = ct[h<<1] + ct[h<<1|1] ;
}
void Update ( int h, int l, int r, int x, int v ) {
	if (l == r) {
		tree[h] += v ;
		ct[h] = (tree[h]!=0) ;
		return ;
	}
	int mid = (l+r)>>1 ;
	if (x <= mid) Update(h<<1, l, mid, x, v) ;
	else Update(h<<1|1, mid+1, r, x, v) ;
	push_up(h) ;
}
int s[3005][3005][2] ;
void solve2() {
	int i, j, v, Max = -1, Sum = 0 ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= m ; j ++ ) {
			s[i][j][0] = s[i][j - 1][0] + s[i - 1][j][0] - s[i - 1][j - 1][0] ;
			s[i][j][1] = s[i][j - 1][0] + s[i - 1][j][1] - s[i - 1][j - 1][1] ;
			++s[i][j][g[i][j]-1] ;
		}
	for ( i = k ; i <= n ; i ++ )
		for ( j = k ; j <= m ; j ++ ) {
			v = (s[i][j][0]-s[i-k][j][0]-s[i][j-k][0]+s[i-k][j-k][0]!=0) ;
			v += (s[i][j][1]-s[i-k][j][1]-s[i][j-k][1]+s[i-k][j-k][1]!=0) ;
			chkmax(Max, v), Sum += v ;
		}
	printf ( "%d %d\n", Max, Sum ) ;
}
int Find ( int x ) {
	int l = 1, r = t, mid ;
	while (l <= r) {
		mid = (l+r)>>1 ;
		if (b[mid] == x) return mid ;
		else if (b[mid] > x) r = mid-1 ;
		else l = mid+1 ;
	}
	return -1 ;
}
void solve4() {
	printf ( "%d %lld\n", k*k, (LL)(n-k+1)*(m-k+1)*k*k ) ;
}
int main() {
	freopen ( "atlas.in", "r", stdin ) ;
	freopen ( "atlas.out", "w", stdout ) ;
	Read(n), Read(m), Read(k) ;
	int i, j, l, r, v, Max = -1, limi, limh ;
	register LL Sum = 0 ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= m ; j ++ ) {
			Read(g[i][j]) ;
			b[++t] = g[i][j] ;
		}
	sort(b+1, b+t+1) ;
	if (b[t] == 2) {
		solve2() ;
		return 0 ;
	}
	if (n <= 500 && m <= 500) {
		t = unique(b+1, b+t+1)-b-1 ;
		for ( i = 1 ; i <= n ; i ++ )
			for ( j = 1 ; j <= m ; j ++ )
				g[i][j] = Find(g[i][j]) ;
		for ( i = 1, limi = n-k+1 ; i <= limi ; i ++ ) {
			memset (tree, 0, sizeof tree) ;
			memset (ct, 0, sizeof ct) ;
			limh = i+k-1 ;
			for ( j = 1 ; j <= k ; j ++ )
				for ( l = i ; l <= limh ; l ++ )
					Update(1, 1, t, g[l][j], 1) ;
			v = ct[1] ;
			chkmax(Max, v), Sum += v ;
			for ( r = k+1 ; r <= m ; r ++ ) {
				for ( j = i ; j <= limh ; j ++ ) {
					Update(1, 1, t, g[j][r-k], -1) ;
					Update(1, 1, t, g[j][r], 1) ;
				}
				v = ct[1] ;
				chkmax(Max, v) ;
				Sum += v ;
			}
		}
		printf ( "%d %lld\n", Max, Sum ) ;
		//cerr << (double)haha*log(t)/log(2.0)/1e8 << endl ;
		//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	} else solve4() ;
	return 0 ;
}
