#include <bits/stdc++.h>
using namespace std ;
int main() {
	freopen ( "atlas.in", "w", stdout ) ;
	int i, j, n, m, k, v ;
	n = 200, m = n-1 ;
	v = min(100, min(n, m)) ;
	k = rand()%v+1 ;
	v = 1e5 ;
	printf ( "%d %d %d\n", n, m, k ) ;
	for ( i = 1 ; i <= n ; i ++, puts("") )
		for ( j = 1 ; j <= m ; j ++ )
			printf ( "%d ", rand()%v+1 ) ;
	return 0 ;
}
