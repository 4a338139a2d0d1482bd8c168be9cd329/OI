#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=3005;
int n,m,K,a[maxn][maxn];
namespace solver_1{
	int vis[100005];
	void work(){
		int Maxans=0;
		ll totans=0;
		REP(i,1,n-K+1){
			int res=0;
			REP(j,i,i+K-1)
				REP(k,1,K)
					if(++vis[a[j][k]]==1)++res;
			chkmax(Maxans,res),totans+=res;
			REP(k,2,m-K+1){
				REP(j,i,i+K-1){
					if(--vis[a[j][k-1]]==0)--res;
					if(++vis[a[j][k+K-1]]==1)++res;
				}
				chkmax(Maxans,res),totans+=res;
			}
			REP(j,i,i+K-1)
				REP(k,m-K+1,m)
					if(--vis[a[j][k]]==0)--res;
		}
		write(Maxans,' '),write(totans,'\n');
	}
}
namespace solver_2{
	int sum[maxn][maxn];
	int calc(int x1,int y1,int x2,int y2){
		return sum[x2][y2]+sum[x1-1][y1-1]-sum[x1-1][y2]-sum[x2][y1-1];
	}
	void work(){
		int Maxans=1,totans=0;
		REP(i,1,n)
			REP(j,1,m)
				if(a[i][j]==1)
					sum[i][j]=1;
		REP(i,1,n)
			REP(j,1,m)
				sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
		REP(i,1,n-K+1)
			REP(j,1,m-K+1){
				int tmp=calc(i,j,i+K-1,j+K-1);
				if((tmp==0)||(tmp==K*K))totans+=1;
				else chkmax(Maxans,2),totans+=2;
			}
		write(Maxans,' '),write(totans,'\n');
	}
}
namespace solver_3{
	void work(){
		write(K*K,' ');
		write(1ll*(n-K+1)*(m-K+1)*K*K,'\n');
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("atlas.in","r",stdin);
	freopen("atlas.out","w",stdout);
#endif
	n=read(),m=read(),K=read();
	int Maxval=0;
	REP(i,1,n)
		REP(j,1,m){
			a[i][j]=read();
			chkmax(Maxval,a[i][j]);
		}
	if((n<=500)&&(m<=500))solver_1::work();
	else if(Maxval<=2)solver_2::work();
	else solver_3::work();
	return 0;
}
