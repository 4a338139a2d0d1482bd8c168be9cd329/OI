#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1000005,mod=1e9+7;
bool isprime[maxn];
int prime[maxn],tot,mu[maxn];
int n,m;
int f[maxn],invf[maxn];
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1ll*res*x%mod;
		x=1ll*x*x%mod,y>>=1;
	}return res;
}
void init(){
	int n=1000000;
	mu[1]=1;
	memset(isprime,1,sizeof(isprime));
	REP(i,2,n){
		if(isprime[i])
			prime[++tot]=i,mu[i]=-1;
		REP(j,1,tot){
			if(i*prime[j]>n)break;
			isprime[i*prime[j]]=0;
			mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				break;
			}
		}
	}
	REP(i,1,n)mu[i]+=mu[i-1];
	f[1]=1;
	REP(i,2,n)
		f[i]=(f[i-2]+f[i-1])%mod;
	invf[0]=invf[1]=1;
	REP(i,2,n){
		f[i]=1ll*f[i]*f[i-1]%mod;
		invf[i]=ksm(f[i],mod-2);
	}
}
void add(int &x,const int &y,const int &mod){
	x+=y;
	if(x>=mod)x-=mod;
	if(x<0)x+=mod;
}
int solve(int n,int m){
	int ans=1;
	REP(i,1,min(n,m)){
		int n1=n/i,m1=m/i,t=min(n/n1,m/m1),res=0;
		REP(j,1,min(n1,m1)){
			int n2=n1/j,m2=m1/j,k=min(n1/n2,m1/m2);
			add(res,1ll*(mu[k]-mu[j-1])*n2%(mod-1)*m2%(mod-1),mod-1);
			j=k;
		}
		ans=1ll*ans*ksm(1ll*f[t]*invf[i-1]%mod,res)%mod;
		i=t;
	}
	return ans;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
#endif
	init();
	int q_cnt=read();
	while(q_cnt--){
		n=read(),m=read();
		if(n>m)swap(n,m);
		write(solve(n,m),'\n');
	}
	return 0;
}
