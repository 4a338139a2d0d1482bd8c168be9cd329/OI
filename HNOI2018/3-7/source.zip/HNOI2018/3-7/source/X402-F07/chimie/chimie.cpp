#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=200005;
struct Query{
	int type,l,r,x;
	void input(){
		type=read();
		l=read(),r=read();
		if(type<=2)x=read();
	}
}q[maxn];
int n,m,tot,a[maxn];
namespace solver_1{
	void work(){
		REP(i,1,m){
			int l=q[i].l,r=q[i].r;
			if(q[i].type==1){
				REP(j,l,r)a[j]&=q[i].x;
			}else if(q[i].type==2){
				REP(j,l,r)a[j]|=q[i].x;
			}else{
				int ans=0;
				REP(j,l,r)
					chkmax(ans,a[j]);
				write(ans,'\n');
			}
		}
	}
}
namespace solver_2{
	int tot,tag[20];
	struct trie{
		int ch[maxn*20][2];
		void merge(int &x,int &y){
			if(!x)swap(x,y);
			if(!y)return;
			merge(ch[x][0],ch[y][0]);
			merge(ch[x][1],ch[y][1]);
			y=0;
		}
		void insert(int x){
			int p=1;
			DREP(i,19,0){
				if(!ch[p][(x>>i)&1])ch[p][(x>>i)&1]=++tot;
				p=ch[p][(x>>i)&1];
			}
		}
		int query(int p,int dep){
			if(dep==-1)return 0;
			if(tag[dep]!=-1){
				merge(ch[p][0],ch[p][1]);
				return (tag[dep]<<dep)|query(ch[p][0],dep-1);
			}else{
				if(ch[p][1])return (1<<dep)|query(ch[p][1],dep-1);
				else return query(ch[p][0],dep-1);
			}
		}
	}T;
	void work(){
		tot=1;
		REP(i,1,n)
			T.insert(a[i]);
		memset(tag,-1,sizeof(tag));
		REP(i,1,m){
			int x=q[i].x,type=q[i].type-1;
			if(type<=1){
				REP(i,0,19)
					if(((x>>i)&1)==q[i].type-1)
						tag[i]=q[i].type-1;
			}else{
				write(T.query(1,19),'\n');
			}
		}
	}
}
namespace solver_3{
	struct seg_tree{
		int tag[maxn<<2];
		void init(){
			memset(tag,-1,sizeof(tag));
		}
		void push_down(int p,int u,int v){
			if(tag[p]!=-1)
				tag[u]=tag[v]=tag[p],tag[p]=-1;
		}
		void update(int p,int l,int r,int L,int R,int x){
			if((L<=l)&&(R>=r)){tag[p]=x;return;}
			int mid=(l+r)>>1,u=p<<1,v=u+1;
			push_down(p,u,v);
			if(L<=mid)update(u,l,mid,L,R,x);
			if(R>mid)update(v,mid+1,r,L,R,x);
		}
		int query(int p,int l,int r,int pos){
			if(l==r)return tag[p];
			int mid=(l+r)>>1,u=p<<1,v=u+1;
			push_down(p,u,v);
			if(pos<=mid)return query(u,l,mid,pos);
			else return query(v,mid+1,r,pos);
		}
	}T[20];
	void work(){
		REP(i,0,19)
			T[i].init();
		REP(i,1,n)
			REP(j,0,19)
				T[j].update(1,1,n,i,i,(a[i]>>j)&1);
		REP(i,1,m){
			int type=q[i].type-1,l=q[i].l,r=q[i].r;
			if(type<=1){
				REP(j,0,19)
					if(((q[i].x>>j)&1)==type)
						T[j].update(1,1,n,l,r,type);
			}else{
				int ans=0;
				DREP(j,19,0)
					ans=(ans<<1)|T[j].query(1,1,n,q[i].l);
				write(ans,'\n');
			}
		}
	}
}
namespace solver_4{
	struct seg_tree{
		int Max[maxn<<2];
		void create_tree(int p,int l,int r){
			if(l==r){Max[p]=a[l];return;}
			int mid=(l+r)>>1,u=p<<1,v=u+1;
			create_tree(u,l,mid);
			create_tree(v,mid+1,r);
			Max[p]=max(Max[u],Max[v]);
		}
		int query(int p,int l,int r,int L,int R){
			if((L<=l)&&(R>=r))return Max[p];
			int mid=(l+r)>>1,u=p<<1,v=u+1,res=0;
			if(L<=mid)chkmax(res,query(u,l,mid,L,R));
			if(R>mid)chkmax(res,query(v,mid+1,r,L,R));
			return res;
		}
	}T;
	void work(){
		T.create_tree(1,1,n);
		REP(i,1,m)write(T.query(1,1,n,q[i].l,q[i].r),'\n');
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n)a[i]=read();
	bool f1=1,f2=1,f3=1;
	REP(i,1,m){
		q[i].input();
		f1&=(q[i].l==1)&&(q[i].r==n);
		f2&=(q[i].type!=3)||(q[i].l==q[i].r);
		f3&=(q[i].type==3);
	}
	if((n<=5000)&&(m<=5000))solver_1::work();
	else if(f1)solver_2::work();
	else if(f2)solver_3::work();
	else if(f3)solver_4::work();
	return 0;
}
