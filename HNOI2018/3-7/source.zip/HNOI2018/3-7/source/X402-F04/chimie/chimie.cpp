//2018-3-7
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define LOG 20
#define N (200000 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

int n, Q, a[N];

struct Qus{
	int op, l, r, x;
}qus[N];

void Bf(){
	int op, l, r, x, ans;

	For(i, 1, Q){
		Read(op), Read(l), Read(r);

		if(op == 3){
			ans = 0;
			For(j, l, r) ans = max(ans, a[j]);
			printf("%d\n", ans); continue;
		}

		Read(x);
		if(op == 1) For(j, l, r) a[j] &= x;
		if(op == 2) For(j, l, r) a[j] |= x;
	}
}

int f[N][LOG], Log[N];
void Cheat0(){
	For(i, 1, n) f[i][0] = a[i];
	For(j, 1, 19) for(int i = 1; i + (1 << j) - 1 <= n; ++i)
		f[i][j] = max(f[i][j - 1], f[i + (1 << (j - 1))][j - 1]);
	For(i, 2, n) Log[i] = Log[i >> 1] + 1;

	int l, r, k;
	For(i, 1, Q){
		l = qus[i].l, r = qus[i].r;
		k = Log[r - l + 1];
		printf("%d\n", max(f[l][k], f[r - (1 << k) + 1][k]));
	}
}

int ql, qr;

struct SegTree{
	int tag[N << 2];

#define lc (o << 1)
#define rc (o << 1 | 1)
#define mid ((L + R) >> 1)
	
	void Pushdown(int o){
		if(!tag[o]) return;
		tag[lc] = tag[rc] = tag[o]; tag[o] = 0;
	}

	void Modify(int o, int L, int R, int v){
		if(ql <= L && qr >= R){
			tag[o] = v; return;
		}

		Pushdown(o);
		if(ql <= mid) Modify(lc, L, mid, v);
		if(qr > mid) Modify(rc, mid + 1, R, v);
	}

	int Query(int o, int L, int R, int p){
		if(L == R) return tag[o];

		Pushdown(o);
		if(p <= mid) return Query(lc, L, mid, p);
		return Query(rc, mid + 1, R, p);
	}

#undef lc
#undef rc
#undef mid
}t[21];

void Cheat1(){
	For(i, 1, n) For(j, 0, 19){
		ql = qr = i;
		if(a[i] & (1 << j)) t[j].Modify(1, 1, n, 2);
		else t[j].Modify(1, 1, n, 1);
	}

	int x;
	For(i, 1, Q){
		ql = qus[i].l, qr = qus[i].r, x = qus[i].x;

		if(qus[i].op == 1){
			For(j, 0, 19) if(!(x & (1 << j))) t[j].Modify(1, 1, n, 1);
		}else if(qus[i].op == 2){
			For(j, 0, 19) if(x & (1 << j)) t[j].Modify(1, 1, n, 2);
		}else{
			int ans = 0;
			For(j, 0, 19) if(t[j].Query(1, 1, n, ql) == 2) ans |= 1 << j;
			printf("%d\n", ans);
		}
	}
}

int main(){
	freopen("chimie.in", "r", stdin);
	freopen("chimie.out", "w", stdout);

	Read(n); Read(Q);
	For(i, 1, n) Read(a[i]);
	
	if(n <= 5000){Bf(); return 0;}
	
	bool flag0 = true, flag1 = true;

	int op, l, r, x;
	For(i, 1, Q){
		Read(op), Read(l), Read(r);
		if(op < 3) Read(x);
		qus[i] = (Qus){op, l, r, x};
		
		if(op == 3 && l < r) flag1 = false;
		if(op != 3) flag0 = false;
	}
	
	if(flag0){Cheat0(); return 0;}
	if(flag1){Cheat1(); return 0;}

	return 0;
}
