//2018-3-7
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (3000 + 5)
#define M (100000 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

LL sum;
int n, m, now, d, mx, a[N][N], tot[M];
bool vis[M];

inline void Add(int v, int ad){
	tot[v] += ad;
	if(!tot[v] && ad == -1) --now;
	if(tot[v] == 1 && ad == 1) ++now;
}

inline void Update(){
	mx = max(mx, now); sum += now;
}

void Cheat0(){
	int tmp0 = d * d, tmp = (n - d + 1) * (m - d + 1);
	printf("%d %lld", tmp0, 1ll * tmp0 * tmp);
}

int sum1[N][N], sum2[N][N];

void Cheat1(){
	For(i, 1, n) For(j, 1, m){
		sum1[i][j] = sum1[i - 1][j] + sum1[i][j - 1] - sum1[i - 1][j - 1] + (a[i][j] == 1);
		sum2[i][j] = sum2[i - 1][j] + sum2[i][j - 1] - sum2[i - 1][j - 1] + (a[i][j] == 2);
	}

	int nv;
	For(i, d, n) For(j, d, m){
		nv = 0;
		if(sum1[i][j] - sum1[i - d][j] - sum1[i][j - d] + sum1[i - d][j - d]) ++nv;
		if(sum2[i][j] - sum2[i - d][j] - sum2[i][j - d] + sum2[i - d][j - d]) ++nv;
		sum += nv; mx = max(mx, nv);
	}

	printf("%d %lld\n", mx, sum);
}

int main(){
	freopen("atlas.in", "r", stdin);
	freopen("atlas.out", "w", stdout);

	bool flag0 = true, flag1 = true;

	Read(n); Read(m); Read(d);
	For(i, 1, n) For(j, 1, m){
		Read(a[i][j]);

		if(a[i][j] > 2) flag1 = false;
		if(vis[a[i][j]]) flag0 = false;
		vis[a[i][j]] = true;
	}

	if(flag0){Cheat0(); return 0;}
	if(flag1){Cheat1(); return 0;}

	For(i, 1, d - 1) For(j, 1, d) Add(a[i][j], 1);
	int o = 1;

	For(i, d, n){
		o ^= 1;

		if(!o){
			For(j, 1, d) Add(a[i - d][j], -1), Add(a[i][j], 1);
			Update();

			For(j, d + 1, m){
				For(k, i - d + 1, i) Add(a[k][j - d], -1), Add(a[k][j], 1);
				Update();
			}
		}else{
			For(j, m - d + 1, m) Add(a[i - d][j], -1), Add(a[i][j], 1);
			Update();

			Forr(j, m - d, 1){
				For(k, i - d + 1, i) Add(a[k][j + d], -1), Add(a[k][j], 1);
				Update();
			}
		}
	}

	printf("%d %lld\n", mx, sum);

	return 0;
}
