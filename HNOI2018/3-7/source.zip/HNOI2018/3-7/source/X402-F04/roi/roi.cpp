//2018-3-7
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (1000000 + 5)
const int P = 1e9 + 7;

LL Pow(LL a, LL anum){
	LL ret = 1;
	while(anum){
		if(anum & 1) ret = ret * a % P;
		a = a * a % P; anum >>= 1;
	}
	return ret;
}

LL fib[N];

void init(){
	fib[0] = 0, fib[1] = 1;
	For(i, 2, 1000000) fib[i] = (fib[i - 1] + fib[i - 2]) % P;
}

int n, m;

LL f[N];

void Solve(){
	scanf("%d%d", &n, &m);
	For(i, 1, n) f[i] = (LL)(n / i) * (m / i);
	Forr(i, n, 1)
		for(int j = 2; (i * j) <= n; j++) f[i] -= f[i * j];

	LL ans = 1;
	For(i, 2, n) ans = ans * Pow(fib[i], f[i]) % P;
	printf("%lld\n", ans);
}

int main(){
	freopen("roi.in", "r", stdin);
	freopen("roi.out", "w", stdout);
	
	int T;
	init();

	scanf("%d", &T);
	while(T --) Solve();
	
	return 0;
}
