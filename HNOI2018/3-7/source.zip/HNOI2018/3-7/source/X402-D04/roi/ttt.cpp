#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long giant;
int read() {
    int x=0,f=1;
    char c=getchar();
    for (;!isdigit(c);c=getchar()) if (c=='-') f=-1;
    for (;isdigit(c);c=getchar()) x=x*10+c-'0';
    return x*f;
}
const int maxn=1e6+1;
const int q=1e9+7;
int f[maxn],g[maxn],iv[maxn],ig[maxn];
int multi(int x,int y) {
    return (giant)x*y%q;
}
int Plus(int x,int y) {
    return ((giant)x+y)%q;
}
int mi(int x,int y) {
    int ret=1;
    for (;y;y>>=1,x=multi(x,x)) if (y&1) ret=multi(ret,x);
    return ret;
}
int inv(int x) {
    return mi(x,q-2);
}
int pre[maxn],ipre[maxn];
int main() {
#ifndef ONLINE_JUDGE
    freopen("roi.in","r",stdin);
#endif
    iv[1]=1;
    for (int i=2;i<maxn;++i) iv[i]=q-multi(iv[q%i],q/i);
    f[0]=0,f[1]=g[1]=ig[1]=1;
    for (int i=2;i<maxn;++i) {
        f[i]=Plus(f[i-1],f[i-2]);
        int &in=ig[i]=1;
        for (int j=1;j*j<=i;++j) if (i%j==0) {
            in=multi(in,ig[j]);
            if (j*j!=i) in=multi(in,ig[i/j]);
        }
        g[i]=multi(f[i],in);
        in=inv(g[i]);
    }
    pre[0]=ipre[0]=1;
    for (int i=1;i<maxn;++i) ipre[i]=inv(pre[i]=multi(pre[i-1],g[i]));
	printf("%lld\n", ipre[100000]);
    int T=read();
    while (T--) {
        int ret=1,n=read(),m=read();
        if (n>m) swap(n,m);
        for (int l=1,r,c;l<=n;l=r+1) {
            r=min(n/(n/l),m/(m/l));
            int up=(giant)(n/l)%(q-1)*(m/l)%(q-1);
            ret=multi(ret,mi(multi(pre[r],ipre[l-1]),up));
        }
        printf("%d\n",ret);
    }
    return 0;
}
