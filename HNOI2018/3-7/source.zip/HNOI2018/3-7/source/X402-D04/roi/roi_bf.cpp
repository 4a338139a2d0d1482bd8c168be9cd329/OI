#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1000010;
const int mod=1e9+7;
int n, m;

ll f[maxn];
int mu[maxn], prime[maxn], isprime[maxn], cnt;
void init(){
	mu[1]=1;
	for(int i=2;i<maxn;i++){
		if(!isprime[i]) prime[++cnt]=i, mu[i]=-1;
		for(int j=1;j<=cnt && 1ll*i*prime[j]<maxn;j++){
			isprime[i*prime[j]]=1; mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				break;
			}
		}
	}
	f[0]=0, f[1]=1;
	for(int i=2;i<maxn;i++) f[i]=(f[i-1]+f[i-2])%mod;
	// for(int i=1;i<=10;i++) printf("%lld ", f[i]); puts("");
}

int gcd(int x,int y){ return !y ? x : gcd(y,x%y); }

int main(){
	freopen("roi.in","r",stdin),freopen("roi.out","w",stdout);

	init();
	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%d%d", &n, &m);
		ll ans=1;
		for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) ans=ans*f[gcd(i,j)]%mod;
		printf("%lld\n", ans);
	}
	return 0;
}
