#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1000010;
const int mod=1e9+7;
ll n, m;

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

ll f[maxn], g[maxn], fm[maxn][5], fac[maxn], inv[maxn];
int mu[maxn], prime[maxn], isprime[maxn], cnt;
void init(){
	mu[1]=1;
	for(int i=2;i<maxn;i++){
		if(!isprime[i]) prime[++cnt]=i, mu[i]=-1;
		for(int j=1;j<=cnt && 1ll*i*prime[j]<maxn;j++){
			isprime[i*prime[j]]=1; mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				break;
			}
		}
	}
	// for(int i=1;i<=20;i++) printf("%d ", mu[i]); puts("");
	f[0]=0, f[1]=1;
	for(int i=2;i<maxn;i++) f[i]=(f[i-1]+f[i-2])%mod;
	// for(int i=1;i<=10;i++) printf("%lld ", f[i]); puts("");
	for(int i=1;i<maxn;i++) fm[i][0]=Pow(f[i],mod-2), fm[i][1]=1, fm[i][2]=f[i];
	// printf("%lld\n", fm[3][1]);
	for(int i=1;i<maxn;i++) g[i]=1;
	for(int k=1;k<maxn;k++){
		for(int p=k;p<maxn;p+=k) g[p]=g[p]*fm[k][ mu[p/k]+1 ]%mod;
	}
	fac[0]=1; inv[0]=1;
	for(int i=1;i<maxn;i++) fac[i]=fac[i-1]*g[i]%mod;
	inv[maxn-1]=Pow(fac[maxn-1],mod-2);
	for(int i=maxn-2;i>=0;i--) inv[i]=1ll*inv[i+1]*g[i+1]%mod;
	return;
}

int gcd(int x,int y){ return !y ? x : gcd(y,x%y); }

int main(){
	freopen("roi.in","r",stdin),freopen("roi.out","w",stdout);

	init();
	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%lld%lld", &n, &m);
		if(n>m) swap(n, m);
		ll ans=1;
		for(ll l,r,p=1;p<=n;p=r+1){
			l=p,r=min(n/(n/l),m/(m/l));
			// printf("l = %d r = %d\n", l, r);
			ans=ans*Pow(1ll*fac[r]*inv[l-1]%mod, 1ll*(n/p)*(m/p)%(mod-1))%mod;
		}
		printf("%lld\n", ans);

		/*
		ans=1;
		for(int p=1;p<=min(n,m);p++){
			ll tot=1;
			for(int k=1;k<=p;k++) if(p%k==0){
				// printf("%d %d\n", p/k, mu[p/k]);
				tot=tot*Pow(f[k], mu[p/k])%mod;
			}
			// printf("tot = %lld %d %d\n", tot, m/p, n/p);
			ans=ans*Pow(tot,(m/p)*(n/p)%mod);
		}
		printf("%lld\n", ans);

		ans=1;
		for(int k=1;k<=n;k++){
			ll tot=0;
			for(int d=1;d<=n/k;d++) (tot+=mu[d]*(n/k/d) * (m/k/d)%mod)%=mod;
			tot=(tot+mod)%mod;
			ans=ans*Pow(f[k],tot)%mod;
		}
		printf("%lld\n\n", ans);
		*/
	}
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
