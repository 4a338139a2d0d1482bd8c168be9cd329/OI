#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 1000000;
const int mo = 1e9 + 7;

int mu[N + 5];
bool notprime[N + 5];
int prime[N + 5], pcnt;

int fpm(int x, int y) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1)
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

void sieve() {
    mu[1] = 1;
    for(int i = 2; i <= N; ++i) {
        if(!notprime[i]) {
            mu[i] = -1;
            prime[pcnt++] = i;
        }

        static ll x;
        for(int j = 0; j < pcnt && (x = 1ll * i * prime[j]) <= N; ++j) {
            notprime[x] = true;
            if(i % prime[j] == 0) break;
            mu[x] = -mu[i];
        }
    }
}

int T, n, m;
int f[N + 5], inv_f[N + 5];

void init() {
    sieve();

    inv_f[1] = f[1] = 1;
    for(int i = 2; i <= N; ++i) {
        f[i] = (f[i-1] + f[i-2]) % mo;
        inv_f[i] = 1;
    }

    for(int i = 1; i <= N; ++i) {
        int inv = fpm(f[i], mo - 2);
        for(int j = 1; i*j <= N; ++j) if(mu[j]) {
            inv_f[i*j] = 1ll * inv_f[i*j] * (mu[j] > 0 ? f[i] : inv) % mo; 
        }
    }

    f[0] = inv_f[0] = 1;
    for(int i = 1; i <= N; ++i) f[i] = 1ll * f[i-1] * inv_f[i] % mo;
    for(int i = 1; i <= N; ++i) inv_f[i] = fpm(f[i], mo - 2);
}

int main() {
    freopen("roi.in", "r", stdin);
    //freopen("roi.out", "w", stdout);

    init();

    read(T);
    while(T--) {
        read(n), read(m);
        if(n > m) std::swap(n, m);

        int ans = 1;
        for(int x = 1, nxt; x <= n; x = nxt + 1) {
            nxt = std::min(n / (n / x), m / (m / x));
            ans = 1ll * ans * fpm(1ll * f[nxt] * inv_f[x-1] % mo, 1ll * (n/x) * (m/x) % (mo - 1)) % mo;
        }
        printf("%d\n", ans);
    }

    return 0;
}
