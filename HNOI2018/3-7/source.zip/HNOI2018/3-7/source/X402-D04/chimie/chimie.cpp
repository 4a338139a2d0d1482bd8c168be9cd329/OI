#include<bits/stdc++.h>
using namespace std;

const int maxn=200010;
int n, q;
int a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

struct Segment_Tree{
	int all[maxn<<2];
	void pushdown(int o){
		if(~all[o]){
			all[o<<1]=all[o<<1|1]=all[o];
			all[o]=-1;
		}
	}
	void build(int o,int l,int r,int id){
		all[o]=-1;
		if(l==r){
			all[o]=a[l] & (1<<id); return;
		}
		int mid=(l+r)>>1;
		build(o<<1,l,mid,id); build(o<<1|1,mid+1,r,id);
	}
	void modify(int o,int l,int r,int ql,int qr,int x){
		if(ql<=l && qr>=r){ all[o]=x; return; }
		pushdown(all[o]);
		int mid=(l+r)>>1;
		if(ql<=mid) modify(o<<1,l,mid,ql,qr,x); if(qr>mid) modify(o<<1|1,mid+1,r,ql,qr,x);
	}
	int query(int o,int l,int r,int pos){
		if(l==r) return all[o];
		pushdown(o);
		int mid=(l+r)>>1;
		if(pos<=mid) return query(o<<1,l,mid,pos); else return query(o<<1|1,mid+1,r,pos);
	}
}T[25];

int qt[maxn], ql[maxn], qr[maxn], qx[maxn];

void BF(){
	for(int i=1;i<=q;i++){
		int op, l, r, x;
		read(op); read(l), read(r);
		if(op<=2) read(x);
		if(op==1){
			for(int j=l;j<=r;j++) a[j]&=x;
		}else if(op==2) for(int j=l;j<=r;j++) a[j]|=x;
		else{
			int x=0;
			for(int j=l;j<=r;j++) x=max(x,a[j]);
			printf("%d\n", x);
		}
	}
}

void solve2(){
	int ans=0;
	for(int i=1;i<=n;i++) ans=max(ans, a[i]);
	for(int i=1;i<=q;i++){
		if(qt[i]==1) ans|=qx[i];
		else if(qt[i]==2) ans&=qx[i];
		else printf("%d\n", ans);
	}
}

void solve3(){
	for(int i=0;i<20;i++) T[i].build(1,1,n,i);
	for(int i=1;i<=q;i++){
		if(qt[i]==1){
			for(int j=0;j<20;j++) if(!(qx[i] & (1<<j)) ) T[j].modify(1,1,n,ql[i],qr[i],0);
		}else if(qt[i]==2){
			for(int j=0;j<20;j++) if(qx[i] & (1<<j) ) T[j].modify(1,1,n,ql[i],qr[i],1);
		}else{
			int ans=0;
			for(int j=0;j<20;j++) ans |= T[j].query(1,1,n,j) ? 0 : (1<<j);
		}
	}
}

int Max[maxn][25], Log[maxn];
int query(int l,int r){
	int t=Log[r-l];
	// if(!t) printf("%d %d %d\n", l, r, Max[l][t]);
	return max(Max[l][t], Max[r-(1<<t)+1][t]);
}
void solve4(){
	for(int i=2;i<=n;i++) Log[i]=Log[i>>1]+1;
	for(int i=1;i<=n;i++) Max[i][0]=a[i];
	for(int j=1;j<=20;j++) for(int i=1;i<=n;i++) Max[i][j]=max(Max[i][j-1], Max[i+(1<<(j-1))][j-1]);
	for(int i=1;i<=q;i++){
		int ans=0;
		printf("%d\n", query(ql[i],qr[i]));
	}
}

int main(){
	freopen("chimie.in","r",stdin),freopen("chimie.out","w",stdout);

	read(n), read(q);
	for(int i=1;i<=n;i++) read(a[i]);
	if(n<=5000 && q<=5000){ BF(); return 0; }
	int f1=1, f2=1, f3=1, f4=1;
	for(int i=1;i<=q;i++){
		read(qt[i]), read(ql[i]), read(qr[i]);
		if(qt[i]<=2) read(qx[i]);
		f2 &= ql[i]==1 && qr[i]==n;
		if(qt[i]==3) f3 &= ql[i]==qr[i];
		f4 &= qt[i]==3;
	}
	if(f2){ solve2(); return 0; }
	if(f3){ solve3(); return 0; }
	if(f4){ solve4(); return 0; }
	return 0;
}
