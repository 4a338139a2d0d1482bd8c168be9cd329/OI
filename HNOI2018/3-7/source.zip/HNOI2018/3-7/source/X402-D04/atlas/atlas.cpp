#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=3010;
const int maxm=100010;
int n, m, k;
int a[maxn][maxn];
int sum[maxm];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

ll ans;
void add(int x,int y){
	if(!sum[ a[x][y] ]) ans++;
	sum[ a[x][y] ]++;
}
void del(int x,int y){
	if(sum[ a[x][y] ]==1) ans--;
	sum[ a[x][y] ]--;
}
ll tot, Max;

int main(){
	freopen("atlas.in","r",stdin),freopen("atlas.out","w",stdout);

	read(n), read(m), read(k);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) read(a[i][j]);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) add(i,k);
	if(ans==1ll*n*m){
		printf("%lld %lld\n", 1ll*k*k, 1ll*(n-k+1)*(m-k+1)*k*k);
		return 0;
	}
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) del(i,k);
	for(int i=1;i<=k;i++) for(int j=1;j<=k;j++) add(i,j);
	/*
	puts("sum");
	for(int j=1;j<=5;j++) printf("%d ", sum[j]); puts("");
	*/
	for(int i=1;i+k-1<=n;i++){
		for(int j=1;j+k-1<=m;j++){
			// for(int p=1;p<=5;p++) printf("%d ", sum[p]); puts("");
			// printf("[ %d ][ %d ] = %lld\n", i, j, ans);
			tot+=ans; Max=max(Max, ans);
			if(j+k-1<m) for(int l=i;l<=i+k-1;l++) del(l,j);
			if(j+k-1<m) for(int l=i;l<=i+k-1;l++) add(l,j+k);
		}
		for(int l=i;l<=i+k-1;l++){
			for(int j=m-k+1;j<=m;j++){
				// printf("del %d %d\n", l, j);
				del(l,j);
			}
		}
		/*
		puts("sum");
		for(int j=1;j<=5;j++) printf("%d ", sum[j]); puts("");
		*/
		for(int l=i+1;l<=i+k;l++){
			for(int j=1;j<=k;j++){
				// printf("add %d %d\n", l, j);
				add(l,j);
			}
		}
	}
	printf("%lld %lld\n", Max, tot);
	return 0;
}
