#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=200010;

int n,q,a[maxn];

int Max[maxn][20],Lg[maxn];

void RMQ_init(){
    int cur=2;
    for(int i=1;i<=n;i++){
        Lg[i]=Lg[i-1];
        if(i==cur) ++Lg[i],cur*=2;
    }
    for(int i=1;i<=n;i++) Max[i][0]=a[i];
    for(int j=1;j<=Lg[n];j++)
        for(int i=1;i+(1<<j)-1<=n;i++)
            Max[i][j]=max(Max[i][j-1],Max[i+(1<<(j-1))][j-1]);
}

int query(int L,int R){
    int k=Lg[R-L+1];
    return max(Max[L][k],Max[R-(1<<k)+1][k]);
}

int main(){
    freopen("chimie.in","r",stdin);
    freopen("chimie.out","w",stdout);

    read(n); read(q);
    for(int i=1;i<=n;i++) read(a[i]);

    if(n<=5000&&q<=5000){
        for(int i=1;i<=q;i++){
            int op,l,r;
            read(op); read(l); read(r);
            if(op!=3){
                int x; read(x);
                for(int j=l;j<=r;j++) (op==1)?(a[j]&=x):(a[j]|=x);
            }
            else{
                int ans=0;
                for(int j=l;j<=r;j++) chkmax(ans,a[j]);
                printf("%d\n",ans);
            }
        }
    }

    else{
        RMQ_init();
        while(q--){
            int op,l,r;
            read(op); read(l); read(r);
            printf("%d\n",query(l,r));
        }
    }

    return 0;
}
