#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=1000000,mo=1e9+7;

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

int n,m,f[maxn+5],ans;
int cnt[maxn+5];

int main(){
    freopen("roi.in","r",stdin);
    freopen("roi.out","w",stdout);

    int _; read(_);

    f[1]=f[2]=1;
    for(int i=3;i<=maxn;i++) f[i]=(f[i-1]+f[i-2])%mo;

    while(_--){
        read(n); read(m);

        ans=1; int lim=min(n,m);

        for(int i=lim;i>=3;i--){
            int cntL=(i<=n)?(n-i)/i+1:0;
            int cntR=(i<=m)?(m-i)/i+1:0;
            cnt[i]=1ll*cntL*cntR%mo;
            for(int j=2*i;j<=lim;j+=i) cnt[i]=((cnt[i]-cnt[j])+mo)%mo;
            ans=1ll*ans*fpm(f[i],cnt[i])%mo;
        }

        printf("%d\n",ans);
    }

    return 0;
}
