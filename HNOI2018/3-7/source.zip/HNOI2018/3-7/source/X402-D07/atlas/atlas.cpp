#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=3010,lim=100000;

int n,m,K,A[maxn][maxn];
int Max;
long long sum;

namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    int T[lim<<2];

    void pushup(int h,int l,int r){
        T[h]=0;
        if(l==mid) T[h]+=T[ls]?1:0;
        else T[h]+=T[ls];
        if(mid+1==r) T[h]+=T[rs]?1:0;
        else T[h]+=T[rs];
    }

    void update(int h,int l,int r,int p,int x){
        if(l==r) return void(T[h]+=x);
        if(p<=mid) update(ls,lc,p,x);
        else update(rs,rc,p,x);
        pushup(h,l,r);
    }
}

using namespace SGT;

int main(){
    freopen("atlas.in","r",stdin);
    freopen("atlas.out","w",stdout);

    read(n); read(m); read(K);

    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++) read(A[i][j]);

    if(n<=500&&m<=500){
        for(int i=1;i<=K;i++)
            for(int j=1;j<=K;j++) update(1,1,lim,A[i][j],1);

        int x=1,y=1,op=1;

        while(1){
            chkmax(Max,T[1]); sum+=T[1];
            if(x==n-K+1&&(y==(((n-K)&1)?1:m-K+1))) break;

            if(op==1){
                if(y<m-K+1){
                    for(int i=x;i<=x+K-1;i++) update(1,1,lim,A[i][y],-1);
                    for(int i=x;i<=x+K-1;i++) update(1,1,lim,A[i][y+K],1);
                    y++;
                }
                else op=2;
            }

            if(op==3){
                if(y>1){
                    for(int i=x;i<=x+K-1;i++) update(1,1,lim,A[i][y+K-1],-1);
                    for(int i=x;i<=x+K-1;i++) update(1,1,lim,A[i][y-1],1);
                    y--;
                }
                else op=2;
            }

            if(op==2){
                for(int j=y;j<=y+K-1;j++) update(1,1,lim,A[x][j],-1);
                for(int j=y;j<=y+K-1;j++) update(1,1,lim,A[x+K][j],1);
                x++; op=(y==1?1:3);
            }
        }

        printf("%d %lld\n",Max,sum);
    }

    else printf("%d %lld\n",K*K,1ll*K*K*(n-K+1)*(m-K+1));

    return 0;
}
