#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;

int n, m;
int a[N + 5];

namespace SEG {
#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    const int SZ = N << 2;

    int mx[SZ + 5];

    void build(int u, int l, int r) {
        if(l == r) { mx[u] = a[l]; return; }

        build(lc, l, mid);
        build(rc, mid+1, r);

        mx[u] = std::max(mx[lc], mx[rc]);
    }

    int query(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return -oo;
        if(x <= l && r <= y) return mx[u];
        return std::max(query(lc, l, mid, x, y), query(rc, mid+1, r, x, y));
    }
}

int main() {
    freopen("chimie.in", "r", stdin);
    freopen("chimie.out", "w", stdout);

    read(n); read(m);
    for(int i = 1; i <= n; ++i) read(a[i]);

    if(n <= 5000 && m <= 5000) {
        for(int i = 1; i <= m; ++i) {
            static int op, x, y, z;
            read(op), read(x), read(y);
            if(op <= 2) read(z);

            if(op == 1) for(int j = x; j <= y; ++j) a[j] &= z;
            if(op == 2) for(int j = x; j <= y; ++j) a[j] |= z;
            if(op == 3) {
                int ans = -oo;
                for(int j = x; j <= y; ++j) chkmax(ans, a[j]);
                printf("%d\n", ans);
            }
        }
    } else {
        SEG::build(1, 1, n);
        for(int i = 1; i <= m; ++i) {
            static int op, x, y, z;
            read(op), read(x), read(y);
            if(op <= 2) read(z);
            if(op == 3) printf("%d\n", SEG::query(1, 1, n, x, y));
        }
    }

    return 0;
}
