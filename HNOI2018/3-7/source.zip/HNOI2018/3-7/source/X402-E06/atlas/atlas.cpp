#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 3000;
const int M = 100000;

int n, m, k, lima;
int a[N + 5][N + 5], s[N + 5][N + 5], sum[M + 5];

void solve1() {
    ll ans0 = 0, ans1 = 0, tot = 0;

    for(int i = 1; i <= n - k + 1; ++i) {

        tot = 0;
        memset(sum, 0, sizeof sum);
        for(int x = 1; x <= k; ++x) {
            for(int y = 1; y <= k; ++y) {
                if(!(sum[a[x+i-1][y]] ++)) tot++;
            }
        }

        chkmax(ans0, tot), ans1 += tot;
        for(int j = 2; j <= m - k + 1; ++j) {
            for(int x = 1; x <= k; ++x) if(!(--sum[a[x+i-1][j-1]])) -- tot;
            for(int x = 1; x <= k; ++x) if(!(sum[a[x+i-1][j+k-1]] ++)) ++ tot;
            chkmax(ans0, tot), ans1 += tot;
        }
    }
    printf("%lld %lld\n", ans0, ans1);
}

void solve2() {
    ll ans0 = 0, ans1 = 0, tot = 0;

    for(int i = 1; i <= m; ++i) 
        for(int j = 1; j <= n; ++j) s[i][j] = (s[i][j-1] + (a[j][i] == 1));

    for(int i = 1; i <= n - k + 1; ++i) {

        tot = 0;

        for(int x = 1; x <= k; ++x) {
            tot += s[x][i+k-1] - s[x][i-1];
        }

        chkmax(ans0, ll(tot == k*k ? 1 : 2)), ans1 += (tot == k*k ? 1 : 2);

        for(int j = 2; j <= m - k + 1; ++j) {
            tot -= s[j-1][i+k-1] - s[j-1][i-1];
            tot += s[j+k-1][i+k-1] - s[j+k-1][i-1];
            chkmax(ans0, ll(tot == k*k ? 1 : 2)), ans1 += (tot == k*k ? 1 : 2);
        }
    }
    printf("%lld %lld\n", ans0, ans1);
}

int main() {
    freopen("atlas.in", "r", stdin);
    freopen("atlas.out", "w", stdout);

    read(n), read(m), read(k);
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= m; ++j) read(a[i][j]), chkmax(lima, a[i][j]);

    if(n <= 500 && m <= 500) 
        solve1();
    else if(lima <= 2) 
        solve2();
    else 
        printf("%lld %lld\n", 1ll * k * k, 1ll * (n - k + 1) * (m - k + 1) * k * k);

    return 0;
}
