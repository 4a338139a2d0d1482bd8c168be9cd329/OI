#include<bits/stdc++.h>
using namespace std;
const long long md=1000000007;
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int f[1010];
int cnt[1010][1001];
long long dp[1010];
int main(){
	freopen("roi.in","r",stdin);
	int T;
	f[0]=0,f[1]=1;
	for(int i=2;i<=1000;i++){
		for(int j=2;j<=1000;j++){
			f[j]=(f[j-1]+f[j-2])%i;
//			if(i==999&&f[j]==0) cerr<<j<<endl;
			if(f[j]==0)
				cnt[i][j]=cnt[i][j-1]+1;
			else
				cnt[i][j]=cnt[i][j-1];
		}
	}
	scanf("%d",&T);
	while(T--){
		int n,m;
		scanf("%d%d",&n,&m);
		long long ans=1;
		for(int i=2;i<=1000;i++){
			dp[i]=cnt[i][n]*cnt[i][m];
		}
		cerr<<dp[666]<<endl;
		for(int i=1000;i>=2;i--){
			for(int k=i+i;k<=1000;k+=i)
			{
//				if(i==333&&T==0) cerr<<dp[i]<<" "<<k<<endl;
				dp[i]-=dp[k];
			}
			if(dp[i]<0) exit(0);
		}
		for(int i=2;i<=1000;i++)
			ans=ans*powd(i,dp[i])%md;
//		printf("%lld\n",ans);
	}
	return 0;
}
