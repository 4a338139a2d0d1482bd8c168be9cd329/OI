#include<bits/stdc++.h>
using namespace std;
const long long md=1000000007;
int cnt[1010][1010];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
bool check(int x){
	for(int i=2;i<=x;i++){
		if(x%i==0){
			while(x%i==0) x/=i;
			break;
		}
	}
	return x==1;
}
int test(int x){
	for(int i=2;i<=x;i++)
		if(x%i==0) return i;
	return 0;
}
int f[1010],t[1010];
int F[1010];
int dp[1010];
int main(){
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
	int T;
	scanf("%d",&T);
	int n,m;
	f[0]=0,f[1]=1;
	for(int i=2;i<=1000;i++){
		if(!check(i)) continue;
		t[i]=test(i);
		for(int j=2;j<=1000;j++){
			f[j]=(f[j-1]+f[j-2])%i;
			cnt[i][j]=cnt[i][j-1]+(f[j]==0);
		}
	}
	F[0]=0,F[1]=1;
	for(int i=2;i<=1000;i++)
		F[i]=(F[i-1]+F[i-2])%md;
	while(T--){
		scanf("%d%d",&n,&m);
		for(int i=2;i<=1000;i++)
			dp[i]=cnt[i][n]*cnt[i][m]-min(cnt[i][n],cnt[i][m]);
		for(int i=2;i<=1000;i++){
			if(!t[i]) continue;
			int st=i*t[i];
			while(st<=1000){
				dp[i]-=dp[st];
				st=st*t[i];
			}
		}
		long long ans=1;
		for(int i=1;i<=1000;i++)
			ans=ans*powd(i,dp[i])%md;
		for(int i=1;i<=n&&i<=m;i++)
			ans=ans*F[i]%md;
		printf("%lld\n",ans);
	}
	return 0;
}
