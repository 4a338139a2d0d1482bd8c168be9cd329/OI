#include<bits/stdc++.h>
using namespace std;
const long long md=1000000007;
long long f[1010];
int cnt[1010];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int main(){
	freopen("roi.in","r",stdin);
//	freopen("roi.out","w",stdout);
	int T;
	scanf("%d",&T);
	int n,m;
	while(T--){
		for(int i=0;i<=1000;i++)
			cnt[i]=0;
		scanf("%d%d",&n,&m);
		f[0]=0,f[1]=1;
		for(int i=2;i<=n||i<=m;i++)
			f[i]=f[i-1]+f[i-2];
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				cnt[__gcd(f[i],f[j])]++;
		long long ans=1;
		for(int i=1;i<=1000;i++)
			ans=ans*powd(i,cnt[i])%md;
		printf("%lld\n",ans);
	}
	return 0;
}
