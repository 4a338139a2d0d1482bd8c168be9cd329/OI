#include<bits/stdc++.h>
using namespace std;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int a[3010][3010];
int cnt[100100],num;
int n,m,k;
void Add(int x){
	if(!cnt[x]) num++;
	cnt[x]++;
}
void Del(int x){
	cnt[x]--;
	if(!cnt[x]) num--;
}
bool out(int x,int y){
	if(x<1||x>n-k+1) return 1;
	if(y<1||y>m-k+1) return 1;
	return 0;
}
void solve(){
	long long ans=0;
	int mx=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			a[i][j]=a[i-1][j]+a[i][j-1]-a[i-1][j-1]+a[i][j];
	for(int i=k;i<=n;i++){
		for(int j=k;j<=m;j++){
			num=0;
			if(a[i][j]-a[i-k][j]-a[i][j-k]+a[i-k][j-k])
				num++;
			if(a[i][j]-a[i-k][j]-a[i][j-k]+a[i-k][j-k]<k*k)
				num++;
			ans+=num;
			chkmax(mx,num);
		}
	}
	printf("%d %lld\n",mx,ans);
}
int main(){
	freopen("atlas.in","r",stdin);
	freopen("atlas.out","w",stdout);
	bool bo=1;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			readl(a[i][j]);
			if(a[i][j]>2) bo=0;
		}
	if(bo){
		solve();
		return 0;
	}
	if((n-k+1)*(m-k+1)*(long long)k>100000000){
		printf("%d %lld\n",k*k,k*k*(long long)(n-k+1)*(m-k+1));
		return 0;
	}
	long long ans=0;
	int mx=0;
	for(int i=1;i<=k;i++)
		for(int j=1;j<=k;j++)
			Add(a[i][j]);
	ans+=num,chkmax(mx,num);
	int dr=1;
	int x=1,y=1;
	while(x<=n-k+1){
		y+=dr;
		if(out(x,y)){
			if(x+k>n) break;
			y=y-dr;
			for(int i=y;i<=y+k-1;i++)
				Add(a[x+k][i]);
			for(int i=y;i<=y+k-1;i++)
				Del(a[x][i]);
			x++;
			ans+=num,chkmax(mx,num);
			dr=-dr;
		}
		else{
			if(dr==1){
				for(int i=x;i<=x+k-1;i++)
					Add(a[i][y+k-1]);
				for(int i=x;i<=x+k-1;i++)
					Del(a[i][y-1]);
			}
			else{
				for(int i=x;i<=x+k-1;i++)
					Add(a[i][y]);
				for(int i=x;i<=x+k-1;i++)
					Del(a[i][y+k]);
			}
			ans+=num,chkmax(mx,num);
		}
	}
	printf("%d %lld\n",mx,ans);
	return 0;
}
