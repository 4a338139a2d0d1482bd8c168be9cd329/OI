#include<bits/stdc++.h>
using namespace std;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int a[3010][3010];
int cnt[100100],num;
int n,m,k;
void Add(int x){
	if(!cnt[x]) num++;
	cnt[x]++;
}
void Del(int x){
	cnt[x]--;
	if(!cnt[x]) num--;
}
bool out(int x,int y){
	if(x<1||x>n-k+1) return 1;
	if(y<1||y>m-k+1) return 1;
	return 0;
}
int main(){
	freopen("atlas1.in","r",stdin);
//	freopen("atlas.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			readl(a[i][j]);
	long long ans=0;
	int mx=0;
	for(int i=1;i<=n-k+1;i++)
		for(int j=1;j<=m-k+1;j++){
			for(int p=0;p<k;p++)
				for(int q=0;q<k;q++)
					Add(a[i+p][j+q]);
			ans+=num,chkmax(mx,num);
			for(int p=0;p<k;p++)
				for(int q=0;q<k;q++)
					Del(a[i+p][j+q]);
		}
	printf("%d %lld\n",mx,ans);
	return 0;
}
