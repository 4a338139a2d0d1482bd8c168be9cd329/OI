#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
int Max(int x,int y){
	return x>y?x:y;
}
int cnt;
#define mid ((l+r)>>1)
int n,m;
int tg[20][maxn<<2];
int tr[maxn<<2];
int yg[20][maxn<<2];
int va[maxn<<2],vb[maxn<<2];//va:& vb:|
int a[maxn];
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
void clearp(int h,int p){
	if(yg[p][h]==1) vb[h]^=1<<p;
	else if(yg[p][h]==0) va[h]^=1<<p;
	yg[p][h]=-1;
}
void setp(int h,int p,int v){
	clearp(h,p);
	if(v==1) vb[h]^=1<<p;
	else va[h]^=1<<p;
	yg[p][h]=v;
}
void push_up(int h,int v){
	tr[h]=Max(tr[h<<1],tr[h<<1|1]);
	tr[h]|=vb[h];
	tr[h]&=va[h];
	if(tg[v][h<<1]==tg[v][h<<1|1])
		tg[v][h]=tg[v][h<<1];
	else
		tg[v][h]=-1;
}
void push_down(int h,int p);
void Set(int h,int p,int v){
	cnt++;
	if(tg[p][h]!=-1){
		setp(h,p,v);
		tg[p][h]=v;
		if(v) tr[h]|=1<<p;
		else tr[h]&=((1<<20)-1)^(1<<p);
		return;
	}
	else{
		setp(h,p,v);
		push_down(h,p);
		push_up(h,p);
	}
}
void push_down(int h,int p){
	if(yg[p][h]!=-1){
		Set(h<<1,p,yg[p][h]);
		Set(h<<1|1,p,yg[p][h]);
		clearp(h,p);
	}
}
void Set(int h,int l,int r,int s,int t,int p,int v){
	if(s<=l&&r<=t){
		Set(h,p,v);
		return;
	}
	if(t<=mid) Set(h<<1,l,mid,s,t,p,v);
	else if(s>mid) Set(h<<1|1,mid+1,r,s,t,p,v);
	else{
		Set(h<<1,l,mid,s,mid,p,v);
		Set(h<<1|1,mid+1,r,mid+1,t,p,v);
	}
}
void push_down(int h,int l,int r,int s,int t){
	if(s<=l&&r<=t) return;
	for(int i=0;i<20;i++)
		push_down(h,i);
	if(t<=mid) push_down(h<<1,l,mid,s,t);
	else if(s>mid) push_down(h<<1|1,mid+1,r,s,t);
	else{
		push_down(h<<1,l,mid,s,mid);
		push_down(h<<1|1,mid+1,r,mid+1,t);
	}
}
void push_up(int h,int l,int r,int s,int t){
	if(s<=l&&r<=t)
		return;
	if(t<=mid) push_up(h<<1,l,mid,s,t);
	else if(s>mid) push_up(h<<1|1,mid+1,r,s,t);
	else{
		push_up(h<<1,l,mid,s,mid);
		push_up(h<<1|1,mid+1,r,mid+1,t);
	}
	for(int i=0;i<20;i++)
		push_up(h,i);
}
void Build_tree(int h,int l,int r){
	for(int i=0;i<20;i++)
		yg[i][h]=-1,va[h]=(1<<20)-1,vb[h]=0;
	if(l==r){
		tr[h]=a[l];
		for(int i=0;i<20;i++)
			tg[i][h]=(a[l]>>i)&1;
		return;
	}
	Build_tree(h<<1,l,mid);
	Build_tree(h<<1|1,mid+1,r);
	for(int i=0;i<20;i++)
		push_up(h,i);
}
int Query(int h,int l,int r,int s,int t){
	if(s<=l&&r<=t)
		return tr[h];
	for(int i=0;i<20;i++)
		push_down(h,i);
	if(t<=mid) return Query(h<<1,l,mid,s,t);
	else if(s>mid) return Query(h<<1|1,mid+1,r,s,t);
	else
		return Max(Query(h<<1,l,mid,s,mid),Query(h<<1|1,mid+1,r,mid+1,t));
}
int main(){
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	for(int i=1;i<=n;i++)
		readl(a[i]);
	int op,l,r,x;
	Build_tree(1,1,n);
	for(m=1;m<=M;m++){
		readl(op);
		readl(l),readl(r);
		if(op==1){
			readl(x);
			push_down(1,1,n,l,r);
			for(int i=0;i<20;i++)
				if(!(x&(1<<i)))
					Set(1,1,n,l,r,i,0);
			push_up(1,1,n,l,r);
		}
		else if(op==2){
			readl(x);
			push_down(1,1,n,l,r);
			for(int i=0;i<20;i++)
				if(x&(1<<i))
					Set(1,1,n,l,r,i,1);
			push_up(1,1,n,l,r);
		}
		else
			printf("%d\n",Query(1,1,n,l,r));
	}
	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
	return 0;
}
