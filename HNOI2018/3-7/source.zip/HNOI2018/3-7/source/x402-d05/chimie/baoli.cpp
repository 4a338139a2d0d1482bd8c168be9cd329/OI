#include<bits/stdc++.h>
using namespace std;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
const int maxn=200100;
int n,m;
int a[maxn];
int main(){
	freopen("chimie.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	int op,l,r,x;
	for(m=1;m<=M;m++){
		scanf("%d%d%d",&op,&l,&r);
		if(op==1){
			scanf("%d",&x);
			for(int i=l;i<=r;i++)
				a[i]&=x;
		}
		else if(op==2){
			scanf("%d",&x);
			for(int i=l;i<=r;i++)
				a[i]|=x;
		}
		else{
			int ans=0;
			for(int i=l;i<=r;i++)
				chkmax(ans,a[i]);
			printf("%d\n",ans);
		}
//		for(int i=1;i<=n;i++)
//			cerr<<a[i]<<" ";
//		cerr<<endl;
	}
	return 0;
}
