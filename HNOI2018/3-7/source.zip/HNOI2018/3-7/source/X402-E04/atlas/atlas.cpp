#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 3010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("atlas.in","r",stdin);
	freopen("atlas.out","w",stdout);
}
int n, m, a[N][N], K, vis[100010];
namespace BF1{
	ll cur = 0;
	void Build(int x, int y){
		cur = 0;
		For(i, x, x + K - 1)
			For(j, y, y + K - 1){
				if(!vis[a[i][j]])cur ++;
				vis[a[i][j]] ++ ;
			}
	}
	void Clear(int x, int y){
		For(i, x, x + K - 1)
			For(j, y, y + K - 1)
				vis[a[i][j]] = 0;
	}
	void Add(int x, int y){
		For(i, x, x + K - 1){
			if(!vis[a[i][y]])cur++;
			vis[a[i][y]]++;
		}
	}
	void Del(int x, int y){
		For(i, x, x + K - 1)
			if(!(--vis[a[i][y]]))cur--;
	}
	void solve(){
		ll Sum = 0, Max = 0;
		For(i, 1, n - K + 1){
			Build(i, 1);	
			For(j, 1, m - K + 1){
				Sum += cur, Max = max(Max, cur);
				Del(i, j);
				if(j + K - 1<=m)Add(i, j + K);
			}
			Clear(i, m - K + 1);
		}
		printf("%lld %lld\n", Max, Sum);
	}
}
void init(){
	read(n), read(m), read(K);
	For(i, 1, n)
		For(j, 1, m)read(a[i][j]);
}
namespace BF2{
	void solve(){
		ll Sum = 1ll * (n - K + 1) * (m - K + 1) * K * K, Max = K * K;
		printf("%lld %lld\n", Max, Sum);
	}
}
namespace BF3{
	int dp[N][N][3];
	void solve(){
		For(i, 1, n)
			For(j, 1, m){
				For(k, 1, 2)
					dp[i][j][k] = dp[i-1][j][k] + dp[i][j-1][k] - dp[i-1][j-1][k];
				if(a[i][j]<=2)dp[i][j][a[i][j]] ++;
			}
		ll Sum = 0, Max = 0;
		For(i, K, n)
			For(j, K, m){
				int x = i - K, y = j - K;ll ret = 0;
				For(k, 1, 2)
					ret += (dp[i][j][k] - dp[x][j][k] - dp[i][y][k] + dp[x][y][k]) > 0;
				Max = max(Max, ret), Sum += ret;
			}
		printf("%lld %lld\n", Max, Sum);
	}
}
inline bool check(){
	For(i, 1, n)
		For(j, 1, m){
			if(!vis[a[i][j]])vis[a[i][j]]=1;
			else {return 0;}
		}
	return 1;
}
void solve(){
	if(n<=500 && m<=500)BF1::solve();
	else if(check())BF2::solve();
	else BF3::solve();
}
int main(){
	file();
	init();
	solve();
	return 0;
}
