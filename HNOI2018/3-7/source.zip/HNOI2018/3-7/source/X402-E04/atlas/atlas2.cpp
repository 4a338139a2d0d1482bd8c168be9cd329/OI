#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 3010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("atlas.in","r",stdin);
	freopen("atlas1.out","w",stdout);
}
int A[N][N], n, m, K;
void init(){
	read(n), read(m), read(K);
	For(i, 1, n)
		For(j, 1, m)
			read(A[i][j]);
}
int vis[100010];
int solve(int x, int y){
	int ret = 0;
	For(i, x, x + K - 1)
		For(j, y, y + K - 1)
			if(!vis[A[i][j]])ret++, vis[A[i][j]] = 1;
	For(i, x, x + K - 1)
		For(j, y, y + K - 1)
			vis[A[i][j]] = 0;
	return ret;
}
void solve(){
	ll Sum = 0, Max = 0;
	For(i, 1, n - K + 1)
		For(j, 1, m - K + 1){
			ll ret = solve(i, j);
			Sum += ret, Max = max(Max, ret);
		}
	printf("%lld %lld\n", Max, Sum);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
