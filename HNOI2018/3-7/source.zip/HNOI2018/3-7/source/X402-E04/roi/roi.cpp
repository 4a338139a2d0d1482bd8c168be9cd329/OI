#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1000100, INF = 0x3f3f3f3f, Mod = 1e9 + 7;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
}
ll qpow(ll a, ll b){
	ll ret = 1;
	for(;b; b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
ll fib[N], ifib[N];
int mu[N], pri[N], tot, vis[N];
ll S[N];
void get_pri(int n){
	mu[1] = 1;
	For(i, 2, n){
		if(!vis[i])pri[++tot] = i, mu[i] = -1;
		for(ll j=1,v;j<=tot&&(v=pri[j]*i)<=n;++j){
			vis[v] = 1;
			if(i % pri[j] == 0)break;
			mu[v] = - mu[i];
		}
	}
	For(i, 1, n)
		S[i] = S[i-1] + mu[i];
}
void init(){
	fib[0] = 0 , fib[1] = 1;
	ifib[0] = ifib[1] = 1;
	For(i, 2, N - 100)
		fib[i] = (fib[i - 1] + fib[i - 2]) % Mod;
	For(i, 2, N - 100)
		fib[i] = fib[i] * fib[i - 1] % Mod, ifib[i] = qpow(fib[i], Mod - 2);
	get_pri(N - 100);
}
int n, m;

ll G(int d){
	int x = n / d, y = m / d;
	ll ret = 0;
	for(ll l = 1, r; l <= x; l = r + 1){
		r = min(x / (x / l), y / (y / l));
		ret = ret + (S[r] - S[l-1]) * (x / l) * (y / l);
	}	
	return (ret%(Mod - 1) + Mod - 1) % (Mod - 1);
}

void solve(){
	read(n), read(m);
	if(n > m)swap(n, m);
	ll ans = 1;
	for(int l = 1, r; l <= n; l = r + 1){
		r = min(n / (n / l), m / (m / l));
		ans = ans * qpow(fib[r] * ifib[l - 1] % Mod, G(l)) % Mod;
	}
	printf("%lld\n" ,ans);
}
int main(){
	file();
	init();
	int T = 0;
	read(T);
	while(T--)solve();
	return 0;
}
