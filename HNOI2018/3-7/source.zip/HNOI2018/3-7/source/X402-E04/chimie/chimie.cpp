#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 200010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
}
int a[N], n, Q;
void init(){
	read(n), read(Q);
	For(i, 1, n)read(a[i]);
}
void BF_solve(){
	while(Q--){
		int tp, L, R, x;
		read(tp), read(L), read(R);
		if(tp == 1){
			read(x);
			For(i, L, R)a[i] = a[i] & x;
		}else if(tp == 2){
			read(x);
			For(i, L, R)a[i] = a[i] | x;
		}else {
			int Max = 0;
			For(i, L, R)Max = max(Max, a[i]);
			printf("%d\n", Max);
		}
	}
}
namespace BF{
	struct Segment_tree{
		#define Mid ((l+r)>>1)
		#define lc h<<1
		#define rc h<<1|1
		#define Lc lc,l,Mid
		#define Rc rc,Mid+1,r
		int Max[N<<2];
		inline void Pushup(int h){
			Max[h] = max(Max[lc], Max[rc]);
		}
		void Modify(int h, int l, int r, int p, int v,int tp){
			if(l == r){
				if(tp == 1)Max[h] &= v;
				else Max[h] |= v;
				return ;
			}
			if(p <= Mid)Modify(Lc, p, v, tp);
			else Modify(Rc, p, v, tp);
			Pushup(h);
		}
		int Query(int h, int l, int r, int L, int R){
			if(L <= l && r <= R)return Max[h];
			int mx = 0;
			if(L <= Mid)mx = max(mx, Query(Lc, L, R));
			if(R > Mid)mx = max(mx, Query(Rc, L, R));
			return mx;
		}
	}t;
	void solve(){
		For(i, 1, n)t.Modify(1, 1, n, i, a[i], 2);
		while(Q--){
			int tp, l, r, x;
			read(tp), read(l), read(r);
			if(tp <= 2){
				read(x);
				For(i, l, r)t.Modify(1, 1, n, i, x, tp);
			}else {
				printf("%d\n", t.Query(1, 1, n, l, r));
			}
		}
	}
}
int main(){
	file();
	init();
	if(n<=5000&&Q<=5000)BF_solve();
	else BF::solve();
	return 0;
}
