#include <bits/stdc++.h>

inline bool chkmax(int &a, int b)
{
	return a < b? a = b, true : false;
}
int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int N = 2e5;

int n, m;
int A[N + 5];

struct AskQueue
{
	int ty, l, r, x;
	void Input()
	{
		ty = read();
		l = read(), r = read();
		if (ty <= 2) x = read();
	}
}q[N + 5];

namespace SubTask1
{
	void Exec()
	{
		for (int o = 1; o <= m; ++o) {
			int ty = q[o].ty, l = q[o].l, r = q[o].r;
			if (ty == 3) {
				int Mx = 0;
				for (int i = l; i <= r; ++i) chkmax(Mx, A[i]);
				printf("%d\n", Mx);
			}
			else if (ty <= 2) {
				int x = q[o].x;
				for (int i = l; i <= r; ++i) {
					if (ty & 1) A[i] &= x;
					else A[i] |= x;
				}
			}
		}
	}
}

namespace SubTask2
{
	struct MaxTree
	{
		#define lc (h << 1)
		#define rc (lc | 1)
		#define mid ((l + r) >> 1)
		int Mx[N << 2];
		void Insert(int h, int l, int r, int u, int v)
		{
			chkmax(Mx[h], v);
			if (l == r) return ;
			u <= mid? Insert(lc, l, mid, u, v) : Insert(rc, mid + 1, r, u, v);
		}
		int query(int h, int l, int r, int ql, int qr)
		{
			if (ql <= l && r <= qr) return Mx[h];
			return std::max((ql <= mid? query(lc, l, mid, ql, qr) : 0),
					(qr > mid? query(rc, mid + 1, r, ql, qr) : 0));
		}
		#undef lc
		#undef rc
		#undef mid
	}T;

	void Exec()
	{
		for (int i = 1; i <= n; ++i) T.Insert(1, 1, n, i, A[i]);
		for (int o = 1; o <= m; ++o) {
			printf("%d\n", T.query(1, 1, n, q[o].l, q[o].r));
		}
	}
}

namespace SubTask3
{
	struct BitTree
	{
		#define lc (h << 1)
		#define rc (lc | 1)
		#define mid ((l + r) >> 1)
		int sum[N << 2];
		int tag[N << 2];
		inline void push_down(int h, int l, int r)
		{
			if (tag[h] != -1) {
				sum[lc] = (mid - l + 1) * tag[h];
				sum[rc] = (r - mid) * tag[h];
				tag[lc] = tag[rc] = tag[h];
				tag[h] = -1;
			}
		}

		void cover(int h, int l, int r, int ql, int qr, int v)
		{
			if (ql <= l && r <= qr) {
				tag[h] = v;
				sum[h] = (r - l + 1) * v;
			}
			else {
				push_down(h, l, r);
				if (ql <= mid) cover(lc, l, mid, ql, qr, v);
				if (qr > mid) cover(rc, mid+1, r, ql, qr, v);
				sum[h] = sum[lc] + sum[rc];
			}
		}

		int query(int h, int l, int r, int u)
		{
			if (!sum[h]) return 0;
			if (l == r) return sum[h];
			push_down(h, l, r);
			return u <= mid? query(lc, l, mid, u) : query(rc, mid + 1, r, u);
		}
		#undef lc
		#undef rc
		#undef mid
	}T[20 + 5];

	void Exec()
	{
		for (int i = 1; i <= n; ++i) {
			for (int j = 0; j <= 20; ++j)
				if (A[i] & (1<<j))
					T[j].cover(1, 1, n, i, i, 1);
		}
		for (int o = 1; o <= m; ++o) {
			int ty = q[o].ty, l = q[o].l, r = q[o].r;
			if (ty == 3) {
				int cur = 0;
				for (int i = 0; i <= 20; ++i) {
					cur |= T[i].query(1, 1, n, l) << i;
				}
				printf("%d\n", cur);
			}
			else if (ty <= 2) {
				int x = q[o].x;
				for (int i = 0; i <= 20; ++i) {
					bool f = (x>>i) & 1;
					if (f != (ty & 1))
						T[i].cover(1, 1, n, l, r, f);
				}
			}
		}
	}
}

int Init()
{
	n = read(); m = read();
	for (int i = 1; i <= n; ++i) A[i] = read();
	bool flag = 1;
	for (int i = 1; i <= m; ++i) {
		q[i].Input();
		if (q[i].ty == 3) { 
			flag &= (q[i].l == q[i].r);
//			q[i].l = q[i].r;
		}
//		q[i].ty = 3;
	}
	if (n <= 5000) return 1;
	return 2 + flag;
}

int main()
{
	freopen("chimie.in", "r", stdin);
	freopen("chimie.out", "w", stdout);

	int TaskNum = Init();
//	TaskNum = 2;
	if (TaskNum == 1) {
		SubTask1 :: Exec();
	}
	else if (TaskNum == 2) {
		SubTask2 :: Exec();
	}
	else if (TaskNum == 3) {
		SubTask3 :: Exec();
	}
	else {
		//yyckjm
	}

	return 0;
}
