#include <bits/stdc++.h>

typedef long long LL;

inline bool chkmax(int &a, int b)
{
	return a < b? a = b, true : false;
}
int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int N = 2e3;
const int M = 1e5;

int n, m, k;
int A[N + 5][N + 5];

int Max = 0;
LL Sum = 0;
int num[M + 10];

inline void chkans(int tot)
{
	Sum += tot;
	chkmax(Max, tot);
}

namespace SubTask1
{
	void Exec()
	{
		for (int i = 1; i <= n-k+1; ++i){
			for (int j = 1; j <= m-k+1; ++j){
				int tot = 0;
				for (int x = i; x < i + k; ++x)
					for (int y = j; y < j + k; ++y){
						if (!num[A[x][y]]){
							num[A[x][y]] ++;
							tot ++;
						}
					}
				chkans(tot);
				for (int x = i; x < i + k; ++x)
					for (int y = j; y < j + k; ++y){
						if (num[A[x][y]])
							num[A[x][y]] --;
					}
			}
		}
		printf("%d %lld\n", Max, Sum);
	}
}

namespace SubTask2
{
	void Exec()
	{
		for (int i = 1; i <= n-k+1; ++i){
			int tot = 0;
			for (int x = i; x < i+k; ++x){
				for (int y = 1; y <= k; ++y){
					int &cur = num[A[x][y]];
					if (!cur) tot ++;
					cur ++;
				}
			}
			chkans(tot);
			//del which line
			for (int y = 1; y < m-k+1; ++y){
				for (int x = i; x < i+k; ++x){
					int &cur = num[A[x][y]];
					cur --;
					if (!cur) tot --;
				}
				for (int x = i; x < i+k; ++x){
					int &cur = num[A[x][y+k]];
					if (!cur) tot ++;
					cur ++;
				}
				chkans(tot);
			}
			for (int x = i; x < i+k; ++x){
				for (int y = m-k+1; y <= m; ++y)
					num[A[x][y]] --;
			}
		}
		printf("%d %lld\n", Max, Sum);
	}
}

namespace SubTask3
{
	void Exec()
	{
		Max = k * k;
		for (int i = 1; i <= n-k+1; ++i)
			for (int j = 1; j <= m-k+1; ++j)
				Sum += k * k;
		printf("%d %lld\n", Max, Sum);
	}
}

namespace SubTask4
{
	struct MaxTree{
		#define lc (h << 1)
		#define rc (lc | 1)
		#define mid ((l + r) >> 1)
		int Mn[N << 2];
		void Insert(int h, int l, int r, int u, int v)
		{
			if (!Mn[h]) Mn[h] = v;
			else Mn[h] = std::min(Mn[h], v);
			if (l == r) return ;
			u <= mid? Insert(lc, l, mid, u, v) : Insert(rc, mid + 1, r, u, v);
		}
		int query(int h, int l, int r, int ql, int qr)
		{
			if (ql <= l && r <= qr) return Mn[h];
			return std::min((ql <= mid? query(lc, l, mid, ql, qr) : 0),
					(qr > mid? query(rc, mid + 1, r, ql, qr) : 0));
		}
		#undef lc
		#undef rc
		#undef mid
	}row[N + 5];
	//Tree
	int down[N + 5][N + 5];

	void Exec()
	{
		for (int j = 1; j <= m; ++j) down[n][j] = 1;
		for (int i = n-1; i >= 1; --i){
			for (int j = 1; j <= m; ++j){
				if (A[i][j] == A[i+1][j]) 
					down[i][j] = down[i + 1][j] + 1;
				else 
					down[i][j] = 1;
				printf ("down[%d][%d] = %d\n", i, j, down[i][j]);
			}
		}
		for (int i = 1; i <= n; ++i){
			for (int j = 1; j <= m; ++j)
				row[i].Insert(1, 1, m, j, down[i][j]);
		}

		Max = 1;
		for (int i = 1; i <= n-k+1; ++i){
			for (int j = 1; j <= m-k+1; ++j){
				if (row[i].query(1, 1, m, j, j+k-1) >= k)
					Sum ++;
				else {
					Sum += 2; Max = 2;
				}
			}
		}
		printf("%d %lld\n", Max, Sum);
	}
}

int Init()
{
	static int chk[M + 5], tot, Mxval;
	n = read(); m = read(), k = read();
	for (int i = 1; i <= n; ++i){
		for (int j = 1; j <= m; ++j){
			A[i][j] = read();
			chkmax(Mxval, A[i][j]);
			if (!chk[A[i][j]]){
				tot ++;
				chk[A[i][j]] = 1;
			}
		}
	}
	if (Mxval <= 2) return 4;
	if (tot == n*m) return 3;
	if (n <= 100 && m <= 100) return 1;
	return 2;
}

int main()
{
	freopen("atlas.in", "r", stdin);
	freopen("atlas.out", "w", stdout);

	int Task_num = Init();
	if (Task_num <= 2) {
		SubTask2 :: Exec();
	}
	else if (Task_num == 3) {
		SubTask3 :: Exec();
	}
	else {
		SubTask4 :: Exec();
	}

	return 0;
}
