#include <bits/stdc++.h>
using namespace std;

const int N = 1e6;
const int mod = 1e9 + 7;

int fpm(int x, int e)
{
	int ret = 1;
	for (; e; e >>= 1) {
		if (e & 1)
			ret = 1ll*ret*x%mod;
		x = 1ll*x*x%mod;
	}
	return ret;
}

int fib[N + 5];
void FibInit()
{
	fib[1] = 1;
	for (int i = 2; i <= N; ++i) {
		fib[i] = (fib[i-1] + fib[i-2]) % mod;
	}
}

bool NotPrime[N + 5];
int prime[N + 5], tot;
int mu[N + 5];
int smu[N + 5];

void PrimeInit()
{
	mu[1] = 1;
	for (int i = 2; i <= N; ++i) {
		if (!NotPrime[i]){
			prime[++tot] = i;
			mu[i] = -1;
		}
		for (int j = 1; j <= tot && 1ll*prime[j]*i <= N; ++j) {
			NotPrime[prime[j] * i] = true;
			if (i % prime[j] == 0) {
				mu[i * prime[j]] = 0; break;
			}
			else {
				mu[i * prime[j]] = -mu[i];
			}
		}
	}
	for (int i = 1; i <= N; ++i) {
		smu[i] = (smu[i-1] + mu[i] + mod) % mod;
	}
}

//n = n/x m = m/x
int calc_sqrt(int len, int n, int m)
{
	int ret = 0;
	for (int l = 1, r = 0; l <= len; l = r + 1) {
		r = min(n/(n/l), m/(m/l));
		ret = (ret + 1ll * (smu[r] - smu[l-1]) * (n/l) % mod * (m/l) % mod) % mod;
	}
	return (ret + mod) % mod;
}

int main()
{
	freopen("roi.in", "r", stdin);
	freopen("roi.out", "w", stdout);

	FibInit(); PrimeInit();

	int T; scanf("%d", &T);
	while (T--) {
		int n, m; scanf("%d%d", &n, &m);
		int ans = 1, lstcnt = 0;
		for (int i = 1; i <= std::min(n, m); ++i) {
			int cnt = 0;
			if (i != 1 && (n/i) == n/(i-1) && (m/i) == m/(i-1))
				cnt = lstcnt;
			else
				cnt = calc_sqrt(min(n, m)/i, n/i, m/i);
			ans = 1ll * ans * fpm(fib[i], cnt) % mod;
			lstcnt = cnt;
		}
		printf("%d\n", ans);
	}
//	std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;

	return 0;
}
