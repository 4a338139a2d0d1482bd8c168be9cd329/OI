#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m, K, a[3010][3010], vis[maxn], max_val, min_val;

void Get() {
	min_val = inf; max_val = 0;
	n = read(), m = read(), K = read();
	For(i, 1, n) For(j, 1, m){
		a[i][j] = read();
		max_val = max(max_val, a[i][j]);
		min_val = min(min_val, a[i][j]);
	}
}

void Task1() {
	int Ans = 0, Max_Ans = 0;
	For(i, 1, n - K + 1) For(j, 1, m - K + 1) {
		int Max = 0, tot = 0;
		For(u, i, i + K - 1) For(v, j, j + K - 1) {
			if(!vis[a[u][v]]) {
				++ tot;
				vis[a[u][v]] = 1;
				Max = max(Max, a[u][v]);
			}
		}

		Max_Ans = max(Max_Ans, tot);
		Ans += tot;

		For(o, 1, Max) vis[o] = 0;
	}

	printf("%d %d\n", Max_Ans, Ans);
}

int ans, maxx;

ll all;

void add(int x) {
	if( (++ vis[x]) == 1) ++ ans;
}

void remove(int x) {
	if( (-- vis[x]) == 0) -- ans;
}

void Task2_3() {
	For(i, 1, K) For(j, 1, K) add(a[i][j]);
	For(i, 1, n - K + 1) {
		if(i & 1) {
			if(i != 1) For(j, 1, K) remove(a[i-1][j]), add(a[i+K-1][j]);
			all += ans; maxx = max(maxx, ans);

			For(j, 2, m - K + 1) {
				For(o, i, i + K - 1) remove(a[o][j-1]), add(a[o][j+K-1]);
				all += ans; maxx = max(maxx, ans);
			}
		}
		else {
			rep(j, m, m - K + 1) remove(a[i-1][j]), add(a[i+K-1][j]);
			all += ans; maxx = max(maxx, ans);

			rep(j, m - 1, K) {
				For(o, i, i + K - 1) remove(a[o][j+1]), add(a[o][j-K+1]);
				all += ans, maxx = max(maxx, ans);
			}
		}
	}

	printf("%d %lld\n", maxx, all);
}

void Task4() {
	printf("%d %lld\n", K * K, 1ll * (n - K + 1) * (m - K + 1) * K * K);
}

int sum[3010][3010][2];

void Task5() {
	if(min_val == max_val) {
		printf("%d %lld\n", 1, 1ll * (n - K + 1) * (m - K + 1) );
		return;
	}
	
	For(i, 1, n) For(j, 1, m) {
		sum[i][j][0] = sum[i][j-1][0] - sum[i-1][j-1][0] + sum[i-1][j][0];
		sum[i][j][1] = sum[i][j-1][1] - sum[i-1][j-1][1] + sum[i-1][j][1];
		++ sum[i][j][a[i][j]-1];
		if(i >= K && j >= K) {
			int cnt1 = sum[i][j][0] - sum[i-K][j][0] - sum[i][j-K][0] + sum[i-K][j-K][0];
			int cnt2 = sum[i][j][1] - sum[i-K][j][1] - sum[i][j-K][1] + sum[i-K][j-K][1];
			if(cnt1 > 0 && cnt2 > 0) {
				maxx = 2;
				all += 2;
			}
			else all += 1;
		}
	}

	printf("%d %lld\n", maxx, all);
}

int main() {

	freopen("atlas.in", "r", stdin);
	freopen("atlas.out", "w", stdout);

	Get();

	if(max_val <= 2) Task5();
	else if(n <= 500 && m <= 500) Task2_3();
	else Task4();

	return 0;
}
