#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

unsigned ll f[maxn];

void Get() {
	
}

void pre_work() {
	f[0] = 0, f[1] = 1;
	For(i, 2, 100){
		f[i] = f[i-1] + f[i-2];
		printf("%llu\n", f[i]);
	}
}

int main() {
	
	freopen("roi.in", "r", stdin);
	freopen("roi.out", "w", stdout);

	Get();
	pre_work();

	return 0;
}
