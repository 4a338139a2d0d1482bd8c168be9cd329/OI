#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int n, q, a[maxn];

void Get() {
	n = read(), q = read();
	For(i, 1, n) a[i] = read();
}

void Task1() {
	while(q--) {
		int tp = read();
		int l = read(), r = read();
		if(tp == 1) {
			int x = read();
			For(i, l, r) a[i] = (a[i] & x);
		}
		else if(tp == 2) {
			int x = read();
			For(i, l, r) a[i] = (a[i] | x);
		}
		else {
			int Ans = 0;
			For(i, l, r) Ans = max(Ans, a[i]);
			printf("%d\n", Ans);
		}
	}
}

struct node{
	int tp, l, r, x;
}Q[maxn];

bool pd[4];

int Max[maxn][22];

void Task4() {
	For(i, 1, n) Max[i][0] = a[i];
	For(j, 1, 20) {
		For(i, 1, n) {
			if(i + (1 << j - 1) > n) break;
			Max[i][j] = max(Max[i][j-1], Max[i+(1<<j-1)][j-1]);
		}
	}

	For(i, 1, q) {
		int l = Q[i].l, r = Q[i].r;
		int k = log2(r - l + 1);
		printf("%d\n", max(Max[l][k], Max[r-(1<<k)+1][k]) );
	}
}

void Task5() {
	
}

int tree[maxn << 2], tag[maxn << 2];

void build(int h,int l,int r) {
	if(l == r) {
		tree[h] = a[l];
		return;
	}

	int mid = l+r >> 1;
	build(h<<1, l, mid);
	build(h<<1|1, mid+1, r);

	tree[h] = max(tree[h<<1], tree[h<<1|1]);
}

void pushdown(int h,int l,int r) {
	if(tag[h] == 0) return;
	tree[h] |= tag[h];
	if(l == r) {
		tag[h] = 0;
		return;
	}

	tag[h<<1] |= tag[h];
	tag[h<<1|1] |= tag[h];
	tag[h] = 0;
}

void pushup(int h,int l,int r) {
	int mid = l+r >> 1;
	if(tag[h<<1] != 0) pushdown(h<<1, l, mid);
	if(tag[h<<1|1] != 0) pushdown(h<<1|1, mid+1, r);
	tree[h] = max(tree[h<<1], tree[h<<1|1]);
}

void updada(int h,int l,int r,int s,int e,int val) {
	pushdown(h, l, r);
	if(l == s && r == e) {
		tag[h] |= val;
		pushdown(h, l, r);
		return;
	}

	int mid = l+r >> 1;
	if(e <= mid) updada(h<<1, l, mid, s, e, val);
	else if(s > mid) updada(h<<1|1, mid+1, r, s, e, val);
	else updada(h<<1, l, mid, s, mid, val), updada(h<<1|1, mid+1, r, mid+1, e, val);

	pushup(h, l, r);
}

int query(int h,int l,int r,int s,int e) {
	pushdown(h, l, r);
	if(l == s && r == e) {
		return tree[h];
	}

	int mid = l+r >> 1, ans = 0;
	if(e <= mid) ans = query(h<<1, l, mid, s, e);
	else if(s > mid) ans = query(h<<1|1, mid+1, r, s, e);
	else ans = max(query(h<<1, l, mid, s, mid), query(h<<1|1, mid+1, r, mid+1, e) );

	pushup(h, l, r);
	return ans;
}

void Task6() {
	build(1, 1, n);
	For(i, 1, q) {
		int l = Q[i].l, r = Q[i].r, x = Q[i].x;
		if(Q[i].tp == 2) {
			updada(1, 1, n, l, r, x);
		}
		else{
			printf("%d\n", query(1, 1, n, l, r) );
		}
	}
}

void Task_other() {
	For(i, 1, q) {
		Q[i].tp = read(), Q[i].l = read(), Q[i].r = read();
		if(Q[i].tp != 3) Q[i].x = read();
		pd[Q[i].tp] = 1;
	}

	if(!pd[1] && !pd[2]) {
		Task4();
	}
	else if(!pd[2]) {
		Task5();
	}
	else if(!pd[1]) {
		Task6();
	}
}

int main() {

	freopen("chimie.in", "r", stdin);
	freopen("chimie.out", "w", stdout);

	Get();
	if(n <= 5000 && q <= 5000) Task1();
	else Task_other();

	return 0;
}
