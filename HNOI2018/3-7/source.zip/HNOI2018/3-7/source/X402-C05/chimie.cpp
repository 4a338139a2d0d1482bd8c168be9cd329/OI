#include<bits/stdc++.h>
using namespace std;
template<typename T>T read(){
	T x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
	return x*f;
}
const int maxn=2e5+10;
int n,Q,a[maxn];
int main(){
	freopen("chimie.in","r",stdin);freopen("chimie.out","w",stdout);
	n=read<int>();
	Q=read<int>()+1;
	for(int i=1;i<=n;++i)a[i]=read<int>();
	for(int op,l,r,x,ans;--Q;){
		op=read<int>(),l=read<int>(),r=read<int>();
		if(op==1){
			x=read<int>();
			for(int i=l;i<=r;++i){
				a[i]&=x;
			}
		}
		else if(op==2){
			x=read<int>();
			for(int i=l;i<=r;++i){
				a[i]|=x;
			}
		}
		else{
			ans=a[l];
			for(int i=l+1;i<=r;++i){
				ans=max(ans,a[i]);
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
