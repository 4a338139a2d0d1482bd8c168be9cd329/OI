#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7,maxn=1e6,mo=mod-1;
typedef long long ll;
int f[maxn+10],mu[maxn+10];
ll fpm(ll a,ll b){
	ll res=1ll;
	for(;b>0;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
int calc(int n,int m){
	int ans=0,lim=min(n,m);
	for(int l=1,r;l<=lim;l=r+1){
		r=min(n/(n/l),m/(m/l));
		ans=(ans+1ll*(mu[r]-mu[l-1]+mo)%mo*(n/l)%mo*(m/l)%mo)%mo;
	}
	return ans;
}
//int calc1(int n,int m){
//	int ans=0,lim=min(n,m);
//	for(int i=1;i<=lim;++i){
//		ans=ans+1ll*(mu[i]-mu[i-1])*(n/i)*(m/i);
//	}
//	return ans;
//}
bool np[maxn];
vector<int> p;
void init(){
	f[0]=0;f[1]=1;
	mu[0]=0;mu[1]=1;
	for(int i=2;i<=maxn;++i){
		if(!np[i]){
			p.push_back(i);
			mu[i]=-1;
		}
		for(int j=0;j<p.size()&&i*p[j]<=maxn;++j){
			np[i*p[j]]=1;
			if(i%p[j]==0)break;
			mu[i*p[j]]=-mu[i];
		}
		f[i]=(f[i-1]+f[i-2])%mod;
	}
	
	for(int i=2;i<=maxn;++i){
		f[i]=1ll*f[i]*f[i-1]%mod;
		mu[i]+=mu[i-1];
	}
	mu[0]=0;
}
void solve(){
	init();
	int T;scanf("%d",&T);
	for(int n,m,ans,lim;T--;){
		scanf("%d%d",&n,&m);
		ans=1ll;lim=min(n,m);
		for(int l=3,r,x;l<=lim;l=r+1){
			r=min(n/(n/l),m/(m/l));
			x=1ll*f[r]*fpm(f[l-1],mod-2)%mod;
			ans=1ll*ans*fpm(x,calc(n/l,m/l))%mod;
		}
//		for(int i=3,x;i<=lim;++i){
//			x=1ll*f[i]*fpm(f[i-1],mod-2)%mod;
//			ans=1ll*ans*fpm(x,calc1(n/i,m/i))%mod;
//		}
		printf("%d\n",ans);
	}
}
int main(){
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
	solve();
	
	return 0;
}
