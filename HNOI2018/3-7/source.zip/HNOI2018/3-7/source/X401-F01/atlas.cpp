#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
int mx;
int main()
{
	int n=read(),m=read(),k=read();
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			mx=max(mx,read());
	printf("%d %d\n",k*k,mx*k*k);
	return 0;
}
