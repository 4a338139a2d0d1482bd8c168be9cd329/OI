#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
#define lc (o<<1)
#define rc (o<<1|1)
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=5e3+10;
int n,m,a[MAXN];
int main()
{
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i)a[i]=read();
	while(m--)
	{
		int op=read(),l=read(),r=read();
		if(op==1)
		{
			int x=read();
			for(int j=l;j<=r;++j)a[j]&=x;
		}
		else if(op==2)
		{
			int x=read();
			for(int j=l;j<=r;++j)a[j]|=x;
		}
		else
		{
			int ans=0;
			for(int j=l;j<=r;++j)ans=max(ans,a[j]);
			printf("%d\n",ans);
		}
	}
	return 0;
}
