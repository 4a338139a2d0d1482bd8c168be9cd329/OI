#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=3050;
const int M=100050;
int val[N][N],cnt[M],n,m,K;
int sumv[3][N][N];
inline int getsum(int k,int u1,int v1,int u2,int v2)
{
	return sumv[k][u2][v2]-sumv[k][u2][v1-1]-sumv[k][u1-1][v2]+sumv[k][u1-1][v1-1];
}

void wj()
{
	freopen("atlas.in","r",stdin);
	freopen("atlas.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); K=read();
	int maxv=0;
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) 
		val[i][j]=read(),maxv=max(maxv,val[i][j]);
	//cerr<<1ll*(n-K+1)*(m-K+1)*2;
	if(n<=500&&m<=500)
	{
		int maxn=0,now=0; ll sum=0;
		for(int cas=1;cas<=n-K+1;++cas)
		{
			now=0;
			for(int i=cas;i<=cas+K-1;++i) for(int j=1;j<=K;++j) 
				now+=cnt[val[i][j]]==0,cnt[val[i][j]]++;
			maxn=max(maxn,now); sum+=now;
			for(int j=K+1;j<=m;++j)
			{
				for(int i=cas;i<=cas+K-1;++i) 
					cnt[val[i][j-K]]--,now-=cnt[val[i][j-K]]==0;
				for(int i=cas;i<=cas+K-1;++i) 
					now+=cnt[val[i][j]]==0,cnt[val[i][j]]++;
				maxn=max(maxn,now); sum+=now;
			}
			for(int i=cas;i<=cas+K-1;++i) for(int j=m-K+1;j<=m;++j)
				cnt[val[i][j]]--;
		}
		printf("%d %lld\n",maxn,sum);
		return 0;
	}
	if(maxv>2)
	{
		printf("%d %lld\n",K*K,1ll*K*K*(n-K+1)*(m-K+1));
		return 0;
	}
	int maxn=0; ll sum=0;

	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) sumv[val[i][j]][i][j]++;
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) 
		sumv[1][i][j]+=sumv[1][i-1][j]+sumv[1][i][j-1]-sumv[1][i-1][j-1];
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j)
		sumv[2][i][j]+=sumv[2][i-1][j]+sumv[2][i][j-1]-sumv[2][i-1][j-1];

	for(int i=1;i<=n-K+1;++i) for(int j=1;j<=m-K+1;++j) 
	{
		int hav1=getsum(1,i,j,i+K-1,j+K-1),hav2=getsum(2,i,j,i+K-1,j+K-1);
		if(hav1&&hav2) maxn=max(maxn,2),sum+=2;
		else if(hav1&&!hav2) maxn=max(maxn,1),sum++;
		else if(!hav1&&hav2) maxn=max(maxn,1),sum++;
	}
	printf("%d %lld\n",maxn,sum);
	return 0;
}
