#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1000050;
const int mod=1e9+7;
inline int gcd(int a,int b)
{
	while(b) {int t=a%b; a=b; b=t;}
	return a;
}
int f[N];
void init()
{
	int n=N-50;
	f[0]=0; f[1]=1;
	for(int i=2;i<=n;++i) f[i]=(f[i-1]+f[i-2])%mod;
}

void wj()
{
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
}
int main()
{
	wj();
	init();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		int n=read(),m=read();
		int mul=1;
		for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) mul=1ll*mul*f[gcd(i,j)]%mod;
		printf("%d\n",mul);
	}
	return 0;
}
