#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1000051;
const int mod=1e9+7;
ll qpow(ll a,ll n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int f[N],finv[N],prime[N],cnt=0,mu[N],g[N];
bool isnotprime[N];
void init()
{
	int n=N-50;
	f[0]=0; f[1]=1;
	for(int i=2;i<=n;++i) f[i]=(f[i-1]+f[i-2])%mod;
	for(int i=1;i<=n;++i) finv[i]=qpow(f[i],mod-2);

	isnotprime[1]=1; mu[1]=1;
	for(int i=2;i<=n;++i)
	{
		if(!isnotprime[i]) prime[++cnt]=i,mu[i]=-1;
		for(int j=1;j<=cnt&&i*prime[j]<=n;++j)
		{
			isnotprime[i*prime[j]]=1;
			if(!(i%prime[j])) break;
			mu[i*prime[j]]=-mu[i];
		}
	}
	
	for(int i=0;i<=n;++i) g[i]=1;
	for(int i=1;i<=n;++i) for(int j=i;j<=n;j+=i)
	{
		int x=mu[j/i];
		if(x==1) g[j]=1ll*g[j]*f[i]%mod;
		else if(x==-1) g[j]=1ll*g[j]*finv[i]%mod;
	}
	for(int i=1;i<=n;++i) g[i]=1ll*g[i]*g[i-1]%mod;
}

void wj()
{
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	init();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		int n=read(),m=read();
		int mm=min(n,m),ans=1;
		for(int i=1,j;i<=mm;i=j+1)
		{
			j=min(n/(n/i),m/(m/i));
			ans=ans*qpow(g[j]*qpow(g[i-1],mod-2)%mod,1ll*(n/i)*(m/i))%mod;
		}
		printf("%d\n",ans);
	}
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
