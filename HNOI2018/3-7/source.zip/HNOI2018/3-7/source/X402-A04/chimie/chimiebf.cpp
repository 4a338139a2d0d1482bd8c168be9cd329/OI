#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
int n,Q,a[N];

void wj()
{
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
}
int main()
{
	wj();
	n=read(); Q=read();
	for(int i=1;i<=n;++i) a[i]=read();
	for(int cas=1;cas<=Q;++cas)
	{
		int opt=read(),l=read(),r=read();
		if(opt==1) 
		{
			int x=read();
			for(int i=l;i<=r;++i) a[i]&=x;
		}
		else if(opt==2)
		{
			int x=read();
			for(int i=l;i<=r;++i) a[i]|=x;
		}
		else
		{
			int x=0;
			for(int i=l;i<=r;++i) x=a[i]>x?a[i]:x;
			printf("%d\n",x);
		}
		//for(int i=1;i<=n;++i) cerr<<a[i]<<' '; cerr<<endl;
	}
	return 0;
}
