#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
int n,Q;

#define lc (o<<1)
#define rc (o<<1|1)
int andv[N<<2|1],orv[N<<2|1],maxv[N<<2|1],a[N],add[N<<2|1];
inline void maintain(int o)
{
	andv[o]=andv[lc]&andv[rc];
	orv[o]=orv[lc]|orv[rc];
	maxv[o]=max(maxv[lc],maxv[rc]);
}
void build(int o,int l,int r)
{
	if(l==r) {andv[o]=orv[o]=maxv[o]=a[l];return ;}
	int mid=l+r>>1;
	build(lc,l,mid); build(rc,mid+1,r);
	maintain(o);
}
inline void pushdown(int o)
{
	if(add[o])
	{
		add[lc]+=add[o]; add[rc]+=add[o];
		maxv[lc]+=add[o]; maxv[rc]+=add[o];
		andv[lc]+=add[o]; andv[rc]+=add[o];
		orv[lc]+=add[o]; orv[rc]+=add[o];
		add[o]=0;
	}
}
inline void update0(int o,int l,int r,int x,int y,int k)
{
	if(!(orv[o]&k)) return ;
	if(x<=l&&r<=y)
	{
		if(andv[o]&k)
		{
			add[o]-=k;
			maxv[o]-=k;
			orv[o]-=k;
			andv[o]-=k;
			return ;
		}
	}
	pushdown(o);
	int mid=l+r>>1;
	if(x<=mid) update0(lc,l,mid,x,y,k);
	if(y>mid) update0(rc,mid+1,r,x,y,k);
	maintain(o);
}
inline void update1(int o,int l,int r,int x,int y,int k)
{
	if(andv[o]&k) return ;
	if(x<=l&&r<=y)
	{
		if(!(orv[o]&k))
		{
			add[o]+=k;
			maxv[o]+=k;
			orv[o]+=k;
			andv[o]+=k;
			return ;
		}
	}
	pushdown(o);
	int mid=l+r>>1;
	if(x<=mid) update1(lc,l,mid,x,y,k);
	if(y>mid) update1(rc,mid+1,r,x,y,k);
	maintain(o);
}
inline int query(int o,int l,int r,int x,int y)
{
	if(x<=l&&r<=y) return maxv[o];
	pushdown(o);
	int mid=l+r>>1,ans=0;
	if(x<=mid) ans=query(lc,l,mid,x,y);
	if(y>mid) ans=max(ans,query(rc,mid+1,r,x,y));
	return ans;
}

void wj()
{
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	n=read(); Q=read();
	for(int i=1;i<=n;++i) a[i]=read();
	build(1,1,n);
	for(int cas=1;cas<=Q;++cas)
	{
		int opt=read(),l=read(),r=read();
		if(opt==1)
		{
			int x=read();
			for(int i=0;i<20;++i) if(!(x&1<<i)) update0(1,1,n,l,r,1<<i);
		}
		else if(opt==2)
		{
			int x=read();
			for(int i=0;i<20;++i) if(x&1<<i) update1(1,1,n,l,r,1<<i);
		}
		else printf("%d\n",query(1,1,n,l,r));
		//for(int i=1;i<=n;++i) cerr<<query(1,1,n,i,i)<<' '; cerr<<endl;
	}
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
