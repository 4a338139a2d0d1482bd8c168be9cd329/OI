#include<bits/stdc++.h>
using namespace std;

const int N=1000;
const int M=1000;

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("atlas.in","w",stdout);
	int n=60,m=60,k=20;
	printf("%d %d %d\n",n,m,k);

	int tot=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			printf("%d ",++tot);

	return 0;
}
