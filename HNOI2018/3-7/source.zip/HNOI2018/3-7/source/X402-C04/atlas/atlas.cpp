#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=3009;
const int M=1e5+9;

int n,m,k,cans,fl;
int a[N][N],cnt[M];

inline void chkmax(int &a,int b){if(a<b)a=b;}

inline void add(int c,int v)
{
	cnt[c]+=v;
	if(v==1 && cnt[c]==1)cans++;
	else if(v==-1 && cnt[c]==0)cans--;
}

namespace mao888
{
}

namespace cat
{
	int main()
	{
		int ans=0,sum=0;
		for(int i=1;i+k-1<=n;i++)
		{
			cans=0;
			memset(cnt,0,sizeof(cnt));
			for(int j=1;j<=k;j++)
				for(int l=1;l<=k;l++)
					add(a[i+j-1][l],1);
			chkmax(ans,cans);sum+=cans;
			for(int l=2;l+k-1<=m;l++)
			{
				for(int j=1;j<=k;j++)
				{
					add(a[i+j-1][l-1],-1);
					add(a[i+j-1][l+k-1],1);
				}
				chkmax(ans,cans);sum+=cans;
			}
		}
		printf("%d %d\n",ans,sum);
		return 0;
	}
}

namespace mao
{
	inline int query(int lx,int ly,int rx,int ry)
	{
		return a[rx][ry]-a[lx-1][ry]-a[rx][ly-1]+a[lx-1][ly-1];
	}

	int main()
	{
		int ans=0,sum=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				a[i][j]+=a[i-1][j]+a[i][j-1]-a[i-1][j-1];
		for(int i=k;i<=n;i++)
			for(int j=k;j<=m;j++)
			{
				int v=query(i-k+1,j-k+1,i,j);
				if(v && v!=k*k)v=2;
				else if(!v || v==k*k)v=1;
				else v=0;
				chkmax(ans,v);sum+=v;
			}
		printf("%d %d\n",ans,sum);
		return 0;
	}
}

namespace cat888
{
	int main()
	{
		int ans=0,sum=0;
		ans=k*k,sum=(n-k+1)*(m-k+1)*k*k;
		printf("%d %d\n",ans,sum);
		return 0;
	}
}

int main()
{
	freopen("atlas.in","r",stdin);
	freopen("atlas.out","w",stdout);

	n=read();m=read();k=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			a[i][j]=read();
			if(a[i][j]>2)
				fl=1;
		}
	if(n<=500 && m<=500)
		return cat::main();
	if(!fl)
		return mao::main();
	return cat888::main();

	return 0;
}
