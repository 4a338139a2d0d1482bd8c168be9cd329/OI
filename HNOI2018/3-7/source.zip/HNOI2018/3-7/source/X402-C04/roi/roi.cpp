#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int F=50;
const int M=1e6+9;
const ll md=1e9+7;

int T,n,m;
ll f[M];

inline void init()
{
	f[0]=0,f[1]=1;
	for(int i=2;i<F;i++)
		f[i]=f[i-1]+f[i-2];
}

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}

namespace cat
{
	int pri[M>>1],ptop;
	ll mu[M],fib[M];
	bool npri[M];

	inline void init()
	{
		fib[0]=0,fib[1]=1;
		for(int i=2;i<M;i++)
			fib[i]=(fib[i-1]+fib[i-2])%md;
		for(int i=2;i<M;i++)
			fib[i]=fib[i-1]*fib[i]%md;
		mu[1]=1;
		for(int i=2;i<M;i++)
		{
			if(!npri[i])
			{
				pri[++ptop]=i;
				mu[i]=-1;
			}
			for(int j=1;j<=ptop && i*pri[j]<M;j++)
			{
				npri[i*pri[j]]=1;
				if(i%pri[j])
					mu[i*pri[j]]=-mu[i];
				else
				{
					mu[i*pri[j]]=0;
					break;
				}
			}
			(mu[i]+=mu[i-1])%=md;
		}
	}

	inline ll getcc(ll n,ll m)
	{
		ll ret=0;
		for(int i=1,j=0;i<=n;i=j+1)
		{
			j=min(n/(n/i),m/(m/i));
			(ret+=(mu[j]-mu[i-1])%md*(n/i)%md*(m/i)%md)%=md;
		}
		return (ret+md)%md;
	}

	inline int calc(int n,int m)
	{
		if(n>m)swap(n,m);
		ll ans=0;
		for(int i=1,j;i<=n;i=j+1)
		{
			j=min(n/(n/i),m/(m/i));
			(ans+=qpow(fib[j]*qpow(fib[i-1],md-2)%md,getcc((n/i),(m/i))))%=md;
		}
		return ans;
	}
}

inline ll mao(int n,int m)
{
	ll ans=1;
	for(ll x=2;x<=4000;x++)
	{
		ll facs=0;
		for(ll p=1;p*x<=f[n];p++)
			if((*lower_bound(f,f+F,p*x))==p*x)
				for(ll q=1;q*x<=f[m];q++)
					if((*lower_bound(f,f+F,q*x))==q*x)
						facs+=(__gcd(p,q)==1);
		(ans*=qpow(x,facs))%=md;
	}
	return ans;
}

int main()
{
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);

	init();
	scanf("%d",&T);
/*	
	for(n=1;n<=9;n++,puts(""))
		for(m=1;m<=9;m++)
			printf("%9lld ",mao(n,m));
*/
	cat::init();
	while(T--)
	{
		scanf("%d%d",&n,&m);
		printf("%lld %lld\n",mao(n,m));//,cat::calc(n,m));
	}

	return 0;
}
