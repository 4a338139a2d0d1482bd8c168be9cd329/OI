#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void chkmax(int &a,int b){if(a<b)a=b;}
inline int maxx(int a,int b){if(a>b)return a;return b;}

const int N=2e5+9;

int n,q;
int a[N];

struct query
{
	int ty,l,r,x;
}qu[N];

namespace cat
{
	int main()
	{
		for(int i=1;i<=q;i++)
		{
			int ty=read(),l=read(),r=read(),x;
			if(ty==1 || ty==2)x=read();
			if(ty==1)
				for(int i=l;i<=r;i++)
					a[i]&=x;
			else if(ty==2)
				for(int i=l;i<=r;i++)
					a[i]|=x;
			else
			{
				int ret=0;
				for(int i=l;i<=r;i++)
					chkmax(ret,a[i]);
				printf("%d\n",ret);
			}
		}
		return 0;
	}

}

namespace mao
{
	struct segt
	{
		int t[N<<2],tag[N<<2];
		
		inline void mark(int x,int v)
		{
			t[x]=tag[x]=v;
		}

		inline void push(int x)
		{
			if(~tag[x])
			{
				mark(x<<1,tag[x]);
				mark(x<<1|1,tag[x]);
				tag[x]=-1;
			}
		}

		inline void build(int x,int l,int r,int ty)
		{
			tag[x]=-1;
			if(l==r)
			{
				if(ty==-1)
					t[x]=a[l];
				else
					t[x]=(a[l]>>ty)&1;
				return;
			}
			int mid=l+r>>1;
			build(x<<1,l,mid,ty);
			build(x<<1|1,mid+1,r,ty);
			t[x]=maxx(t[x<<1],t[x<<1|1]);
		}

		inline void re(int x,int l,int r,int ty)
		{
			if(l==r){a[l]|=t[x]<<ty;return;}
			push(x);int mid=l+r>>1;
			re(x<<1,l,mid,ty);re(x<<1|1,mid+1,r,ty);
		}

		inline void modify(int x,int l,int r,int dl,int dr,int v)
		{
			if(dl==l && r==dr){mark(x,v);return;}
			int mid=l+r>>1;push(x);
			if(dr<=mid)modify(x<<1,l,mid,dl,dr,v);
			else if(mid<dl)modify(x<<1|1,mid+1,r,dl,dr,v);
			else modify(x<<1,l,mid,dl,mid,v),modify(x<<1|1,mid+1,r,mid+1,dr,v);
			t[x]=maxx(t[x<<1],t[x<<1|1]);
		}

		inline int query(int x,int l,int r,int dl,int dr)
		{
			if(dl==l && r==dr)return t[x];
			int mid=l+r>>1;push(x);
			if(dr<=mid)return query(x<<1,l,mid,dl,dr);
			if(mid<dl)return query(x<<1|1,mid+1,r,dl,dr);
			return maxx(query(x<<1,l,mid,dl,mid),query(x<<1|1,mid+1,r,mid+1,dr));
		}
	};

	int main9()
	{
		segt t;t.build(1,1,n,-1);
		for(int i=1;i<=q;i++)
		{
			int ty=qu[i].ty,l=qu[i].l,r=qu[i].r;
			printf("%d\n",t.query(1,1,n,l,r));
		}
		return 0;
	}

	int main16()
	{
		segt t[21];
		for(int i=0;i<20;i++)
			t[i].build(1,1,n,i);
		for(int i=1;i<=q;i++)
		{
			int ty=qu[i].ty,l=qu[i].l,r=qu[i].r,x;
			if(ty==1||ty==2)x=qu[i].x;
			if(ty==1)
			{
				for(int j=0;j<20;j++)
					if(!(x>>j&1))
						t[j].modify(1,1,n,l,r,0);
			}
			else if(ty==2)
			{
				for(int j=0;j<20;j++)
					if(x>>j&1)
						t[j].modify(1,1,n,l,r,1);
			}
			if(ty==3)
			{
				int ans=0;
				for(int j=0;j<20;j++)
					ans|=(t[j].query(1,1,n,l,l)<<j);
				printf("%d\n",ans);
			}
		}
	}

	bool ban[26];
	int ans=0;
	int main14()
	{
		segt t[22];
		for(int i=0;i<20;i++)
			ban[i]=0,t[i].build(1,1,n,i);
		for(int i=1;i<=n;i++)
			ans=maxx(ans,a[i]);

		for(int i=1;i<=q;i++)
		{
			int ty=qu[i].ty,l=qu[i].l,r=qu[i].r,x;
			if(ty==1 || ty==2)x=qu[i].x;
	
			if(ty==1 || ty==2)
			{
				for(int j=0;j<20;j++)
					if(!ban[j])
					{
						if(ty==1 && ((x>>j)&1)==0)
							goto cond1;
						else if(ty==2 && ((x>>j)&1)==1)
							goto cond1;
					}
				goto cond2;
			}
			if(0)
			{
				cond1:;
				ans=0;
				if(ty==1)
				{
					for(int j=0;j<20;j++)
						t[j].re(1,1,n,j);
					for(int j=1;j<=n;j++)
						a[j]&=x;
					for(int j=1;j<=n;j++)
						ans=maxx(ans,a[j]);
					for(int j=0;j<20;j++)
						if(!((x>>j)&1))
							ban[j]=1;
					for(int j=0;j<20;j++)
						t[j].build(1,1,n,j);
				}
				else
				{
					for(int j=0;j<20;j++)
						t[j].re(1,1,n,j);
					for(int j=1;j<=n;j++)
						a[j]|=x;
					for(int j=1;j<=n;j++)
						ans=maxx(ans,a[j]);
					for(int j=0;j<20;j++)
						if(!((x>>j)&1))
							ban[j]=1;
					for(int j=0;j<20;j++)
						t[j].build(1,1,n,j);
				}
			}
			if(0)
			{
				cond2:;
				if(ty==1)
				{
					for(int j=0;j<20;j++)
						if(!(x>>j&1))
							t[j].modify(1,1,n,l,r,0);
					ans&=x;
				}
				else if(ty==2)
				{
					for(int j=0;j<20;j++)
						if(x>>j&1)
							t[j].modify(1,1,n,l,r,1);
					ans|=x;
				}
			}

			if(ty==3)
				printf("%d\n",ans);
		}
	}

}

int main()
{
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);

	n=read();q=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	if(n<=5000)
		return cat::main();

	bool fl16=0,fl9=0,fl14=0;
	for(int i=1;i<=q;i++)
	{
		qu[i].ty=read();
		qu[i].l=read();
		qu[i].r=read();
		if(qu[i].ty==3 && qu[i].l!=qu[i].r)fl16=1;
		if(qu[i].l!=1 || qu[i].r!=n)fl14=1;
		if(qu[i].ty!=3)fl9=1;
		if(qu[i].ty==1 || qu[i].ty==2)
			qu[i].x=read();
	}
	if(!fl16)
		return mao::main16();
	if(!fl9)
		return mao::main9();
	if(!fl14)
		return mao::main14();
	return 0;
}
