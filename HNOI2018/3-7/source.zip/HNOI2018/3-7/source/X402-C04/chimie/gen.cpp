#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef long long ll;
set<pr> ha;

const int N=1000;
const int M=1000;

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("chimie.in","w",stdout);
	int n=30,q=20;
	printf("%d %d\n",n,q);
	for(int i=1;i<=n;i++)
		printf("%d ",urand()%12000);
	for(int i=1;i<=q;i++)
	{
		int ty=rand()%3+1,l,r;

		l=1,r=n;
		if(l>r)swap(l,r);

		if(ty==1 || ty==2)
			printf("%d %d %d %d\n",ty,l,r,urand()%10021);
		if(ty==3)
			printf("%d %d %d\n",ty,l,r);
	}

	return 0;
}
