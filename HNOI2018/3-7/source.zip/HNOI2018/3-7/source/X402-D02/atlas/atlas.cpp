#include<iostream>
#include<cstdio>
#include<cstring>

namespace bf
{
	typedef long long ll;
	const int N=510,M=100010;

	int s[N][N],cnt[M];

	int n,m,k,res;

	void insert(int x)
	{
		if(!cnt[x])res++;
		cnt[x]++;
	}
	void del(int x)
	{
		cnt[x]--;
		if(!cnt[x])res--;
	}

	void solve()
	{
		scanf("%d%d%d",&n,&m,&k);

		if(n>=N || m>=N)
		{
			printf("%d %lld\n",k*k,(ll)(n-k+1)*(m-k+1)*k*k);
			return;
		}

		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				scanf("%d",&s[i][j]);

		for(int i=1;i<=k;i++)
			for(int j=1;j<=k;j++)
				insert(s[i][j]);

		int x=1,y=1;
		int max=0,sum=0;
		while(1)
		{
//			printf("%d %d , %d\n",x,y,res);
//			for(int i=1;i<=4;i++)printf("%d ",cnt[i]);
//			printf("\n---------------\n");

			max=std::max(max,res);
			sum+=res;
			if(x+k-1==n && (((x&1) && y+k-1==m) || (!(x&1) && y==1)))break; 

			if(x&1)
			{
				if(y+k-1==m)
				{
					for(int i=1;i<=k;i++)
						del(s[x][y+i-1]);
					for(int i=1;i<=k;i++)
						insert(s[x+k][y+i-1]);
					x++;
				}
				else
				{
					for(int i=1;i<=k;i++)
						del(s[x+i-1][y]);
					for(int i=1;i<=k;i++)
						insert(s[x+i-1][y+k]);
					y++;
				}
			}
			else
			{
				if(y==1)
				{
					for(int i=1;i<=k;i++)
						del(s[x][y+i-1]);
					for(int i=1;i<=k;i++)
						insert(s[x+k][y+i-1]);
					x++;
				}
				else
				{
					for(int i=1;i<=k;i++)
						del(s[x+i-1][y+k-1]);
					for(int i=1;i<=k;i++)
						insert(s[x+i-1][y-1]);
					y--;
				}
			}
		}

		printf("%d %d\n",max,sum);
	}
}

int main()
{
	freopen("atlas.in","r",stdin);
	freopen("atlas.out","w",stdout);
	bf::solve();
	return 0;
}
