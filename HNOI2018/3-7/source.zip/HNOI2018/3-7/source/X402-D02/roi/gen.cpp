#include<iostream>
#include<cstdio>
#include<cstring>

int main()
{
	freopen("roi.in","w",stdout);
	srand(time(0));

	int T=5,n=1000000,m=1000000;

	for(printf("%d\n",T);T--;)
	{
		n-=rand()%20,m-=rand()%20;
		printf("%d %d\n",n,m);
	}
	
	return 0;
}
