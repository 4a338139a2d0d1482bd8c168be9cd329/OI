#include<iostream>
#include<cstdio>
#include<cstring>

typedef long long ll;

const int N=1000010,MOD=1000000007;

ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

ll fib[N];

void initialize()
{
	fib[0]=0,fib[1]=1;
	for(int i=2;i<N;i++)
		fib[i]=(fib[i-1]+fib[i-2])%MOD;
}

int n,m;

ll f[N];

void solve()
{
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		f[i]=(ll)(n/i)*(m/i);
	for(int i=n;i;i--)
		for(int j=2;(i*j)<=n;j++)
			f[i]-=f[i*j];

	ll ans=1;
	for(int i=2;i<=n;i++)
		ans=ans*qpow(fib[i],f[i])%MOD;
	printf("%lld\n",ans);
}

int main()
{
	freopen("roi.in","r",stdin);
	freopen("roi.ans","w",stdout);
	int T;
	initialize();
	for(scanf("%d",&T);T--;solve());
	return 0;
}
