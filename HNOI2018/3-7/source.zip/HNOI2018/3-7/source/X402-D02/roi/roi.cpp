#include<iostream>
#include<cstdio>
#include<cstring>
#define x first
#define y second

namespace NanYiFenXiFuZaDu
{
	typedef std::pair<int,int> pii;
	typedef long long ll;


	const int M=5000000,Base=1926817;
	struct hasher
	{
		int begin[Base],next[M];
		ll to[M];
		int w[M];

		int e;
		inline void add(pii A,int b)
		{
			ll y=(ll)A.x*M+A.y;
			int x=y%Base;

			to[++e]=y;
			next[e]=begin[x];
			begin[x]=e;
			w[e]=b;
		}
		inline int check(pii A)
		{
			ll y=(ll)A.x*M+A.y;
			int x=y%Base;
			for(int i=begin[x];i;i=next[i])
				if(to[i]==y)return w[i];
			return -1;
		}
	}H;

	const int N=1000010,MOD=1000000007,PHI=MOD-1;
	ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

	bool isit[N];
	int miu[N],pri[N/5],tot;

	int F[N],fib[N],ifib[N];

	void initialize()
	{
		miu[1]=1;
		for(int i=2;i<N;i++)
		{
			if(!isit[i])pri[++tot]=i,miu[i]=-1;
			for(int j=1,x;(x=i*pri[j])<N;j++)
			{
				isit[x]=1;
				if(i%pri[j])miu[x]=-miu[i];
				else break;
			}
		}
		for(int i=1;i<N;i++)miu[i]+=miu[i-1];

		F[0]=0,F[1]=1;
		for(int i=2;i<N;i++)
			F[i]=(F[i-1]+F[i-2])%MOD;

		fib[0]=1;
		for(int i=1;i<N;i++)
			fib[i]=(ll)fib[i-1]*F[i]%MOD;
		ifib[N-1]=inv(fib[N-1]);
		for(int i=N-1;i;i--)
			ifib[i-1]=(ll)ifib[i]*F[i]%MOD;
	}

	int h(int n,int m)
	{
		register int ret=H.check(pii(n,m));
		if(ret>=0)return ret;

		ret=0;
		for(register int i=1,j,x,y;i<=n && i<=m;i=j+1)
		{
			x=n/i,y=m/i,j=std::min(n/x,m/y);
			ret=(ret+(ll)(miu[j]-miu[i-1])*x%PHI*y%PHI)%PHI;
		}

		ret=(ret+PHI)%PHI+PHI;
		H.add(pii(n,m),ret);
		return ret;
	}

	int n,m;
	void solve()
	{
		scanf("%d%d",&n,&m);
		register int ans=1;
		for(register int i=1,j,x,y,pi;i<=n && i<=m;i=j+1)
		{
			x=n/i,y=m/i,j=std::min(n/x,m/y);
			pi=(ll)fib[j]*ifib[i-1]%MOD;
			ans=(ll)ans*qpow(pi,h(x,y))%MOD;
		}
		ans=(ans+MOD)%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("roi.in","r",stdin);
	freopen("roi.out","w",stdout);
	NanYiFenXiFuZaDu::initialize();
	int T;
	for(scanf("%d",&T);T--;NanYiFenXiFuZaDu::solve());
//		if(T%100==0)fprintf(stderr,"T = %d\n",T);
//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
