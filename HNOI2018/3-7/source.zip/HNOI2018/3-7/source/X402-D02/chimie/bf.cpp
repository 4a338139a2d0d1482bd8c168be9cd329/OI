#include<iostream>
#include<cstdio>
#include<cstring>

const int N=5010;

int s[N];

int n,m;

int main()
{
	freopen("chimie.in","r",stdin);
	freopen("chimie.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",s+i);
	int ty,l,r,x;
	while(m--)
	{
		scanf("%d%d%d",&ty,&l,&r);
		if(ty==1)
		{
			scanf("%d",&x);
			for(int i=l;i<=r;i++)
				s[i]&=x;
		}
		else if(ty==2)
		{
			scanf("%d",&x);
			for(int i=l;i<=r;i++)
				s[i]|=x;
		}
		else 
		{
			int ans=0;
			for(int i=l;i<=r;i++)
				ans=std::max(ans,s[i]);
			printf("%d\n",ans);
		}
	}
	return 0;
}
