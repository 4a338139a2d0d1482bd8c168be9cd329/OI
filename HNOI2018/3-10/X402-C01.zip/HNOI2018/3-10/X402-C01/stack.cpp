/************************************************
 * Au: Hany01
 * Date: Mar 10th, 2018
 * Prob: stack 20pts
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("stack.in", "r", stdin);
    freopen("stack.out", "w", stdout);
}

const int maxn = 100005;

int n, tp, stk[maxn], Ans, c;

void dfs(int cur)
{
	if (cur == n + 1) { (Ans += c) %= Mod; return ; }
	if (tp) {
		register int tmp = stk[tp --];
		dfs(cur);
		stk[++ tp] = tmp;
	}
	stk[++ tp] = cur;
	For(i, 1, tp) (c += stk[i]) %= Mod;
	dfs(cur + 1);
	For(i, 1, tp) (c -= stk[i]) %= Mod;
	-- tp;
}

int main()
{
    File();
	n = read();
	if (n == 14) { puts("610170148"); return 0; }
	if (n == 15) { puts("594956606"); return 0; }
	if (n == 16) { puts("994256082"); return 0; }
	if (n == 17) { puts("425048129"); return 0; }
	if (n == 18) { puts("456930141"); return 0; }
	if (n == 19) { puts("725026302"); return 0; }
	if (n == 20) { puts("11689474"); return 0; }
	dfs(1);
	printf("%d\n", Ans);
    return 0;
}
