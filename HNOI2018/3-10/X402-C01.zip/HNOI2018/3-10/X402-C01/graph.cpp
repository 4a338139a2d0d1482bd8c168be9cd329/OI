/************************************************
 * Au: Hany01
 * Date: Mar 10th, 2018
 * Prob: graph 连暴力分都拿不到的辣鸡代码 20-40pts
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("graph.in", "r", stdin);
    freopen("graph.out", "w", stdout);
}

inline LL Pow(int a, int b)
{
	LL Ans = 1;
	for ( ; b; b >>= 1, a = a * a % Mod) if (b & 1) (Ans *= a) %= Mod;
	return Ans;
}

const int maxn = 35;

int a[maxn][maxn], n, m;
LL Ans;

inline void check()
{
	int flag, tot = 0;
	For(i, 1, n) {
		flag = 0;
		For(j, 1, m) if (a[i][j]) { flag = 1; break; }
		if (!flag) return ;
	}
	For(i, 1, m) {
		flag = 0;
		For(j, 1, n) if (a[j][i]) { flag = 1; break; }
		if (!flag) return ;
	}
	For(i, 1, n) For(j, 1, m) tot += a[i][j];
	if (tot == m) return;
	/*For(i, 1, n) {
		For(j, 1, m) cout << a[i][j];
		cout << endl;
	}
	cout << endl;*/
	(Ans += Pow(2, tot)) %= Mod;
}

void dfs(int x, int y)
{
	if (y == m + 1) { dfs(x + 1, 1); return ; }
	if (x == n + 1) { check(); return ; }
	a[x][y] = 0, dfs(x, y + 1),
	a[x][y] = 1, dfs(x, y + 1);
}

int main()
{
    File();
	for (register int T = read(); T --; ) {
		n = read(), m = read();
		if (n > m) swap(n, m);
		if (n == 1) { printf("%lld\n", Pow(2, m)); continue; }
		Ans = 0, dfs(1, 1);
		printf("%lld\n", Ans);
	}
    return 0;
}
