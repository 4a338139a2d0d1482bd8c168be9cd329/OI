/************************************************
 * Au: Hany01
 * Date: Mar 10th, 2018
 * Prob: math 10pts
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register unsigned int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register unsigned int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register unsigned int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline unsigned int read()
{
	register unsigned int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("math.in", "r", stdin);
    freopen("math.out", "w", stdout);
}

const int maxm = 50000000;

int mu[2000005], beg[10000007], e, nex[maxm];
unsigned int v[maxm], w[maxm], mx;

inline void getmu(unsigned int n)
{
	static unsigned int pr[1000005], cnt;
	static bool np[2000005];

	mu[1] = 1;
	for (register unsigned int i = 2; i <= n; ++ i) {
		if (!np[i]) pr[++ cnt] = i, mu[i] = -1;
		for (register unsigned int j = 1; j <= cnt && i * pr[j] <= n; ++ j) {
			np[i * pr[j]] = 1;
			if (i % pr[j] == 0) { mu[i * pr[j]] = 0; break; }
			mu[i * pr[j]] = -mu[i];
		}
	}
	For(i, 2, n) mu[i] += mu[i - 1];
}

inline void add(int uu, unsigned int vv, unsigned int ww) { v[++ e] = vv, w[e] = ww, nex[e] = beg[uu], beg[uu] = e; }

unsigned int djshai(unsigned int n)
{
	if (n <= mx) return mu[n];
	int id = n % 10000007;
	for (register int i = beg[id]; i; i = nex[i]) if (v[i] == n) return w[i];
	register unsigned int Ans = 1;
	for (register unsigned int i = 2, j; i <= n; i = j + 1) {
		j = n / (n / i);
		Ans -= djshai(n / i) * (j - i + 1);
	}
	add(id, n, Ans);
	return Ans;
}

inline void Solve(unsigned int n)
{
	static unsigned int Ans = n * n;
	for (register unsigned int i = 1, j; i <= n; i = j + 1)
		j = n / (n / i), Ans -= (djshai(j) - djshai(i - 1)) * (n / i) * (n / i);
	printf("%u\n", Ans);
}

LL c;
unsigned int Ans, s, n, m, k;

unsigned int gcd(unsigned int x, unsigned int y) { return y ? gcd(y, x % y) : x; }

unsigned int minD(unsigned int x)
{
	for (register unsigned int i = 2; i * i <= x; ++ i)
		if (x % i == 0) return i;
	return x;
}

int main()
{
    File();
	n = read(), k = read();
	if (!k) {
		mx = min(n, 2000000u);
		getmu(mx);
		Solve(n);
		return 0;
	}
	For(i, 1, n) For(j, 1, n) {
		s = gcd(i, j);
		if (s == 1) continue;
		s /= minD(s);
		c = 1;
		For(kk, 1, k) c *= s;
		Ans += c;
	}
	printf("%u\n", Ans);
    return 0;
}
