#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;

int main(){
	freopen("qdt20.in","w",stdout);
	//freopen("qdt.out","w",stdout);
	srand(time(0));
	int n, M = 100000000;
	printf("%d\n",rand()%M + 400000000);
	return 0;
}
