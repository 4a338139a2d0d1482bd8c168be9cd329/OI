#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define ll long long 
using namespace std;

int main(){
	srand(time(0));
	int T = 5;
	freopen("graph20.in","w",stdout);
	printf("%d\n", T);
	int M = 21;
	while(T--){
		printf("%d %d\n",rand()%M+80,rand()%M+80);
	}
	return 0;
}
