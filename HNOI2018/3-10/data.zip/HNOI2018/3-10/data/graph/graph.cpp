#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=110,INF=0x3f3f3f3f;
const int Mod=1e9+7;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){

}
int n,m;
int dp[N][N],C[N][N],pw[N*N];
void init(){
	n=100,m=100;
	C[0][0]=1;
	For(i,1,100){
		C[i][0]=1;
		For(j,1,i)
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%Mod;
	}
	pw[0]=1;
	For(i,1,n*m)pw[i]=pw[i-1]*3ll%Mod;
	dp[0][1]=1;dp[1][0]=1;
	For(i,1,n)
		For(j,1,m){
			dp[i][j]=pw[i*j];
			For(k,1,i)
				For(l,0,j){
					if(k==i&&l==j)break;
					ll t=1ll*dp[k][l]*C[i-1][k-1]%Mod*C[j][l]%Mod*pw[(i-k)*(j-l)]%Mod;
					dp[i][j]=(dp[i][j]+Mod-t)%Mod;
				}
		}
}
void solve(){
	int T;
	read(T);
	while(T--)read(n), read(m),printf("%d\n",dp[n][m]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
