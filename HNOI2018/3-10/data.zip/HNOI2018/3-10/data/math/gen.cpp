#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;i--)
#define ll long long 
using namespace std;

int main(){
	freopen("math20.in","w",stdout);
	int M = 1000, K = 20;
	srand(time(0));
	printf("%d %d\n",rand()%M+999999001, rand()%K + 31);
	return 0;
}
