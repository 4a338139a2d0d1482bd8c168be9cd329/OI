#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define For(i,j,k) for(uint i=j;i<=k;++i)
#define Forr(i,j,k) for(uint i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1000100;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
} 
inline void file(){
#ifndef ONLINE_JUDGE
	//freopen("math.in","r",stdin);
	//freopen("math.out","w",stdout);
#endif
}
typedef unsigned int uint;
uint pri[N],tot,vis[N];
uint phi[N];
void get_pri(uint n=N-100){
	phi[1]=1;
	For(i, 2, n){
		if(!vis[i])pri[++tot] = i, phi[i] = i - 1;
		for(uint j = 1, v;j <= tot && (v = pri[j] * i) <= n; ++ j){
			vis[v] = 1;
			if(i % pri[j] == 0){
				phi[v] = phi[i] * pri[j];
				break;
			}
			phi[v] = phi[i] * (pri[j] - 1);
		}
	}
	For(i, 2 ,n)phi[i] = phi[i-1] + phi[i] ;
}
uint qpow(uint a, uint b){
	uint ret = 1;
	for(; b; b >>= 1, a = a * a)if(b & 1)ret = ret * a ;
	return ret;
}
inline uint sum(uint n){
	return n%2?(n+1)/2*n:n/2*(n+1);
}
namespace DJS{
	tr1::unordered_map<int, uint>M;
	uint Phi(int n){
		if(n <= N - 100)return phi[n];
		else if(M.count(n))return M[n];
		uint ans = sum(n);
		for(int l = 2, r; l <= n; l = r + 1){
			r = n / (n / l);
			ans -= (r - l + 1) * Phi(n / l);
		}
		return M[n] = ans;
	}
}
uint n;
uint k;
uint val[100];
struct num{
	uint x;int c;
	num(uint X = 1, int C = 0):x(X), c(C){}
	num operator / (const num & r)const {
		return num(x * qpow(r.x, (1ll<<31) - 1), c - r.c);
	}
	num operator * (const num & r)const {
		return num(x * r.x, c + r.c);
	}
	inline uint V(){return x<<c;}
}fac;
num get(uint x){
	int C = 0;
	while(x % 2 == 0)x >>= 1, C++;
	return num(x, C);
}
uint Sum(uint x){
	if(k == 1) return x;
	if(x <= k) return val[x];
	num S ;
	uint ans = 0;
	For(i, 0, k)S = S * get(x - i);
	S = S / fac;
	For(i, 1, k){
		S = S  * get(k + 1 - i) / get(i);
		num ret = S / get(x - i);
		if((k - i) & 1)ans -= ret.V() * val[i];
		else ans += ret.V() * val[i];
	}
	return ans ;
}
namespace EES{
	uint A[N], Ak[N], B[N], Bk[N], G[N], G_[N], m;
	void solve(){
		m = (uint) sqrt(n);
		For(i, 1, m)
			A[i] = i - 1, B[i] = n / i - 1,
			Ak[i] = Sum(i) - 1, Bk[i] = Sum(n / i) - 1;
		For(p, 2, m){
			if(A[p] == A[p - 1])continue;
			uint d = A[p - 1], dk = Ak[p - 1], pk = qpow(p, k - 1);
			uint mid = m / p;
			For(i, 1, mid){
				G_[i] += Bk[i * p] - dk;
				Bk[i] -= (Bk[i * p] - dk) * pk;
				B[i] -= B[i * p] - d;
			}
			uint to = min(m, n / p / p), j = n / p;
			For(i, mid + 1, to){
				G_[i] += Ak[j / i] - dk;
				Bk[i] -= (Ak[j / i] - dk) * pk;
				B[i] -= A[j / i] - d;
			}
			Forr(i, m, p * p){
				G[i] += Ak[i / p] - dk;
				Ak[i] -= (Ak[i / p] - dk) * pk;
				A[i] -= A[i / p] - d;
			}
		}
	}
}
void init(){
	get_pri();
	read(n), read(k);
	k++;
	For(i, 1, k)val[i] = qpow(i, k - 1) + val[i - 1];
	For(i, 1, k)fac = fac * get(i);
}
void solve(){
	using namespace EES;
	using namespace DJS;
	EES::solve();
	uint ans = 0, last = 0,now;
	for(uint l = 2, r;l <= n;l = r + 1){
		r = n / (n / l);
		now = r > m ? G_[n / l] + B[n / l]: G[r] + A[r];
		ans += (now - last) * (2 * Phi(n / l) - 1);
		last = now;
	}
	printf("%u\n", ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}

