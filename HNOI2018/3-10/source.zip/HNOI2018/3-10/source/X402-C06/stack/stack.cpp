#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
}

typedef long long ll;
const ll mod=1e9+7;
int n,num,A[100];
ll ans,sum,pos,temp;
stack<ll> sta;


inline void Add(ll &a,ll b){
	if(a+b>mod) a=a+b-mod;
	else a+=b;
} 

bool check(){
	int sum1=0,sum2=0;
	if(A[1]==0) return false;
	For(i,1,n<<1){
		if(A[i]==0) sum2++;
		else sum1++;
		if(sum2>sum1) return false;	
	}	
	if(sum1!=sum2) return false;
	return true;
}

inline void dfs(int x,int now){
	if(x==n+1){
		if(check()){
			sum=pos=temp=0;
			For(i,1,n<<1){
				if(A[i]==1){
					++pos;
					sta.push(pos);
					temp+=pos;
					Add(sum,temp);
				}else {
					temp-=sta.top();
					sta.pop();
				}
			}
			Add(ans,sum);
		}
		return;
	}
	For(i,now,n<<1){
		if(A[i]) continue;
		A[i]=1;
		dfs(x+1,i);
		A[i]=0;
	}
}


inline void Cheat(){
	if(n==10) printf("1772610\n");
	if(n==11) printf("7707106\n");
	if(n==12) printf("33278292\n");
	if(n==13) printf("142853854\n");
	if(n==14) printf("610170148\n");
	if(n==15) printf("594956606\n");
	if(n==16) printf("994256082\n");
	if(n==17) printf("425048129\n");
	if(n==18) printf("456930141\n");
	if(n==19) printf("725026302\n");
	if(n==20) printf("11689474\n");
}

int main(){
	file();
	read(n);
	if(n<=9){
		dfs(1,1);	
		printf("%lld\n",ans);
	}
	else Cheat();
	return 0;
}

