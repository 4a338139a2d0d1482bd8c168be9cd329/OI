#include<bits/stdc++.h>
#define mem(a,b) memset(a,b,sizeof(a))
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
}

typedef long long ll;
const ll mod=1e9+7;
const int N=20;
int n,m,Case,A[N][N];
int X[N],Y[N];
ll ans,cnt;

ll ksm(ll a,ll b){
	ll res=1;
	while(b){
		if(b&1) (res*=a)%=mod;
		(a*=a)%=mod;
		b>>=1;
	}
	return res;
}

bool check(){	
	cnt=0;
	mem(X,0),mem(Y,0);
	For(i,1,n) For(j,1,m) 
		if(A[i][j]==1) X[i]++,Y[j]++,cnt++; 
	For(i,1,n) if(!X[i]) return false;
	For(i,1,m) if(!Y[i]) return false;
	return true;
}

inline void dfs(int x,int y){
	if(y==m+1){
		dfs(x+1,1);
		return;
	}
	if(x==n+1){
		if(check()) (ans+=ksm(2,cnt))%=mod;	
		return;
	}
	A[x][y]=0;
	dfs(x,y+1);
	A[x][y]=1;
	dfs(x,y+1);
	
}

int main(){
	file();
	read(Case);
	while(Case--){
		read(n),read(m);
		if(n==1 || m==1){
			ll X=(ll)m*(ll)n;
			printf("%lld\n",ksm(2,X));
			continue;
		}
		ans=0;
		dfs(1,1);
		printf("%lld\n",ans-ksm(2,n+m-1)*m);
	}
	return 0;
}

