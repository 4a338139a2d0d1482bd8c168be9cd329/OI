#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
}
typedef long long ll;
const ll mod=4294967296;
int n,k;
ll ans;

ll ksm(ll a,ll b){
	ll res=1;
	while(b){
		if(b&1) (res*=a)%=mod;
		(a*=a)%=mod;
		b>>=1;
	}
	return res;
}

ll Gcd(ll x,ll y){
	if(x%y==0) return y;
	return Gcd(y%x,x);
}

int main(){
	file();
	read(n),read(k);	
	For(i,1,n) For(j,1,n){
		ll x=1ll*i,y=1ll*j,c=2;
		ll X=Gcd(x,y);
		if(X==1) continue;
		while(X%c!=0) c++;
		(ans+=ksm((X/c),k))%=mod;		
	}
	printf("%lld\n",ans);
	return 0;
}

