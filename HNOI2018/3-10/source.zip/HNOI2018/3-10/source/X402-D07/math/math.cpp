#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef unsigned int uint;

const int maxn=910;

int n,m;
int s[maxn];

uint ans;

uint fpm(uint x,int k){
    uint ret=1;
    for(;k;k>>=1,x*=x)
        if(k&1) ret*=x;
    return ret;
}

int main(){
    freopen("math.in","r",stdin);
    freopen("math.out","w",stdout);

    read(n); read(m);

    for(int i=2;i<=n;i++)
        for(int j=i-1;j;j--) if(i%j==0){ s[i]=j; break; }

    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++) ans+=fpm(s[__gcd(i,j)],m);

    printf("%u\n",ans);

    return 0;
}
