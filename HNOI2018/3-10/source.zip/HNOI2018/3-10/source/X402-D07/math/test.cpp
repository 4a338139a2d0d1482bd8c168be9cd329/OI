#include<bits/stdc++.h>

using namespace std;

#define debug(...) fprintf(stderr,__VA_ARGS__)

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef unsigned int uint;

const int maxn=1000010;

int n,m;

int prime[maxn],cnt;
int mu[maxn];
bool vis[maxn];
uint sum[maxn],ans;

uint fpm(uint x,int k){
    uint ret=1;
    for(;k;k>>=1,x*=x)
        if(k&1) ret*=x;
    return ret;
}

void init(){
    mu[1]=1;
    for(int i=2;i<=n;i++){
        if(!vis[i]) prime[++cnt]=i,mu[i]=-1;
        for(int j=1;j<=cnt&&i*prime[j]<=n;j++){
            vis[i*prime[j]]=1;
            mu[i*prime[j]]=-mu[i];
            if(i%prime[j]==0){ mu[i*prime[j]]=0; break; }
        }
    }
    for(int i=1;i<=n;i++) mu[i]+=mu[i-1];
    for(int i=1;i<=n;i++) sum[i]=sum[i-1]+fpm(i,m);
}

int main(){
    freopen("math.in","r",stdin);
    freopen("math.out","w",stdout);

    read(n); read(m);

    init();

    for(int i=1;i<=cnt;i++)
        for(uint s=prime[i];s<=n;s++){
            uint lim=n/prime[i]/s;
            if(!lim) break;
            uint sr=(n/prime[i])/lim;
            uint base=sum[sr]-sum[s-1],tot=0;
            for(uint d=1;d<=lim;d++){
                uint dr=lim/(lim/d);
                tot+=(uint)(mu[dr]-mu[d-1])*(lim/d)*(lim/d);
                d=dr;
            }
            tot*=base; ans+=tot;
            s=sr;
        }

    for(int j=1;j<=cnt;j++){
        uint i=prime[j];
        uint lim=n/i;
        uint tot=0;
        for(uint d=1;d<=lim;d++){
            uint dr=lim/(lim/d);
            tot+=(uint)(mu[dr]-mu[d-1])*(lim/d)*(lim/d);
            d=dr;
        }
        ans+=tot;
    }

    printf("%u\n",ans);

    return 0;
}
