#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int mo=1e9+7,maxn=5;

int n,m;

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}

int ans,A[maxn][maxn],cnt;

bool check0(int x,int y){
    bool flag=0;
    for(int i=1;i<=n;i++) if(i!=x&&A[i][y]){ flag=1; break; }
    if(!flag) return 0;
    flag=0;
    for(int i=1;i<=m;i++) if(i!=y&&A[x][i]){ flag=1; break; }
    if(!flag) return 0;
    flag=0;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++) if(i!=x&&j!=y&&A[i][j]){ flag=1; break; }
    if(!flag) return 0;
    return 1;
}

bool check1(int x,int y){
    for(int i=1;i<=n;i++) if(i!=x&&A[i][y]) return 1;
    for(int j=1;j<=m;j++) if(j!=y&&A[x][j]) return 1;
    return 0;
}

bool check(){
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++){
            if(!A[i][j]&&!check0(i,j)) return 0;
            if(A[i][j]&&!check1(i,j)) return 0;
        }
    return 1;
}

void dfs(int x,int y){
    if(x==n+1){
        if(check()) Add(ans,fpm(2,cnt));
        return;
    }
    
    int nx=x,ny=y+1;
    if(ny>m) nx=x+1,ny=1;

    A[x][y]=1; ++cnt;
    dfs(nx,ny);
    A[x][y]=0; --cnt;
    dfs(nx,ny);
}

int main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);

    int _; read(_);
    while(_--){
        read(n); read(m);
        if(n==1||m==1) printf("%d\n",fpm(2,max(n,m)));
        else dfs(1,1),printf("%d\n",ans);
    }

    return 0;
}
