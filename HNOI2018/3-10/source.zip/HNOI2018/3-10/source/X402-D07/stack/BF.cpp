#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=12;

int n,ans,a[maxn];

bool vis[maxn];
int stk[maxn],top,sum;

int check(){
    int ret=0;
    int cur=1; top=sum=0;
    for(int i=1;i<=n;i++){
        stk[++top]=i; sum+=i; ret+=sum;
        while(top&&stk[top]==a[cur]) sum-=stk[top--],cur++;
    }
    return top?0:ret;
}

void dfs(int u){
    if(u==n+1) return void(ans+=check());
    for(int i=1;i<=n;i++) if(!vis[i]){
        a[u]=i; vis[i]=1;
        dfs(u+1); vis[i]=0;
    }
}

int main(){
    freopen("stack.in","r",stdin);
    freopen("BF.out","w",stdout);

    read(n); dfs(1);

    printf("%d\n",ans);

    return 0;
}
