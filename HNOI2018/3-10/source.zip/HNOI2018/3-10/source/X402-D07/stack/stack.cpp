#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=20,mo=1e9+7;

int n;
int f[maxn+5][1<<maxn][2];

void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}

int main(){
    freopen("stack.in","r",stdin);
    freopen("stack.out","w",stdout);

    read(n);

    f[1][0][0]=1;

    for(int i=1;i<=n;i++)
        for(int s=0;s<(1<<(i-1));s++){
            int sum=0;
            for(int j=1;j<=i;j++) if(!((s>>(j-1))&1)) sum+=j;
            int w=(1ll*f[i][s][0]*sum%mo+f[i][s][1])%mo;

            Add(f[i+1][s][0],f[i][s][0]);
            Add(f[i+1][s][1],w);

            int ns=s;

            for(int j=i;j;j--) if(!((ns>>(j-1))&1)){
                ns|=1<<(j-1);
                Add(f[i+1][ns][0],f[i][s][0]);
                Add(f[i+1][ns][1],w);
            }
        }

    printf("%d\n",f[n+1][(1<<n)-1][1]);

    return 0;
}
