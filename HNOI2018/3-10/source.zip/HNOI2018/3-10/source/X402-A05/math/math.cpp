#include <bits/stdc++.h>

using std :: __gcd;

typedef unsigned int ui;

const int N = 5e6;

ui n, k;

ui fpm(ui x, ui e)
{
	if (x == 0) return 0;
	ui ret = 1;
	for (; e; e >>= 1) {
		if (e & 1)
			ret = ret*x;
		x = x*x;
	}
	return ret;
}

ui mu[N + 5];
int prime[N + 5], tot;
bool notPrime[N + 5];

void muInit()
{
	mu[1] = 1;
	for (int i = 2; i <= N; ++i) {
		if (!notPrime[i]) {
			notPrime[i] = true;
			prime[++tot] = i;
			mu[i] = -1;
		}
		for (int j = 1; j <= tot && i * prime[j] <= N; ++j) {
			notPrime[prime[j] * i] = true;
			if (i % prime[j] == 0) break;
			else 
				mu[prime[j] * i] = -mu[i];
		}
	}
	for (int i = 2; i <= N; ++i)
		mu[i] = mu[i-1] + mu[i];
}

ui calc(ui x)
{
	if (x <= N) return mu[x];

	ui ret = 1;
	for (ui l = 2, r = 0; l <= x; l = r + 1) {
		r = x/(x/l);
		ret = ret - (r-l+1) * calc(x/l);
	}
	return ret;
}

int main()
{
	freopen("math.in", "r", stdin);
	freopen("math.out", "w", stdout);

	scanf("%u%u", &n, &k);

	if (!k) {
		muInit();

		static ui lst, cur;
		ui ans = n * n;
//		for (ui i = 1; i <= n; ++i) {
//			ans -= (n/i) * (n/i) * mu[i];
//			std::cout << ans << std::endl;
//		}
		for (ui l = 1, r = 0; l <= n; l = r + 1) {
			cur = calc(r = n/(n/l));
			ans -= (cur - lst) * (n/l) * (n/l);
			lst = cur;
		}
		std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;
		printf("%u\n", ans);
		return 0;
	}

	const int bfN = 2400;
	static ui smax[bfN], ans;

	for (ui i = 2; i <= n; ++i) {
		for (ui j = 2; j <= i; ++j)
			if (i % j == 0) {
				smax[i] = i / j;
				break;
			}
		if (!smax[i]) smax[i] = i;
	}
	for (ui i = 1; i <= n; ++i) {
		for (ui j = 1; j <= n; ++j)
			ans += fpm(smax[__gcd(i, j)], k);
	}

	printf("%u\n", ans);

	return 0;
}
//F@uck you
