#include <bits/stdc++.h>

const int mod = 1e9 + 7;

int fpm(int x, int e)
{
	int ret = 1;
	for (; e; e >>= 1) {
		if (e & 1) 
			ret = 1ll*x*ret%mod;
		x = 1ll*x*x%mod;
	}
	return ret;
}

int main()
{
	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);

	int T; scanf("%d", &T);
	while (T--) {
		int n, m;
		scanf("%d%d", &n, &m);
		if (n > m) std::swap(n, m);
		if (n == 1) {
			printf("%d\n", fpm(2, m));
		}
		else puts("f@uckyou");
	}
	
	return 0;
}
