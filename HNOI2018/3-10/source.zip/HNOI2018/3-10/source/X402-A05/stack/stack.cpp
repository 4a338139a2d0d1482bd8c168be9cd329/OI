#include <bits/stdc++.h>

const int mod = 1e9 + 7;

void Inc(int &a, int b)
{
	a += b;
	if (a >= mod) a -= mod;
}

int n;

namespace SubTask1
{
	const int N = 20;
	const int S = 1 << N;

	int dp[S + 5], rev[S + 5];
	int sum[S + 5], Max[S + 5];
	int way[S + 5];

	void main()
	{
		for (int s = 0; s < (1 << n); ++s) {
			Max[s] = -1;
			for (int i = n-1; i >= 0; --i)
				if (s & (1 << i)) {
					sum[s] += i + 1;
					if (Max[s] < 0) Max[s] = i;
				}
		}
		for (int s = 0; s < (1 << n); ++s)
			rev[s] = s ^ ((1<<n)-1);
		way[0] = 1;
		for (int s = 0; s < (1 << n); ++s) {
			for (int i = 0; i < n; ++i) {
				if (s & (1<<i)) continue;
				if (Max[s] > i && !(s & (1 << (i+1)))) continue;
				Inc(dp[s^(1<<i)], 
						(dp[s] + 1ll*way[s]*(sum[((1<<i)-1) & rev[s]] + (i+1)) % mod) % mod);
				Inc(way[s^(1<<i)], way[s]);
			}
		}
		printf("%d\n", dp[(1<<n)-1]);
	}
}

int main()
{
	freopen("stack.in", "r", stdin);
	freopen("stack.out", "w", stdout);

	scanf("%d", &n);
	if (n <= 20) {
		SubTask1 :: main();
	}

	return 0;
}
