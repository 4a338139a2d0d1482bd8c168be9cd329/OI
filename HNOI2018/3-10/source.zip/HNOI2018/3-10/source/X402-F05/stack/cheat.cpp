#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e3 + 10;
const int Mod = 1e9 + 7;

void add(int &x, int y) {
	x += y;
	if (x >= Mod) x -= Mod;
}

int n;
int f[N][N];

int main() {

	freopen("ans.txt", "w", stdout);

	n = 1000;
	f[0][0] = 1;
	For(i, 0, n) For(j, 0, i) {
		if (j != i) add(f[i][j + 1], f[i][j]);
		add(f[i + 1][j], f[i][j]);
	}

	for (n = 501; n <= 1000; ++n) {
		cerr << n << endl;
		int ans = 0;
		For(i, 1, n) For(j, 0, i) For(k, 0, n - i) 
			ans = (ans + 1ll * i * (k + 1) * f[i - 1][j] % Mod * f[k][k] % Mod * f[n - k - j - 1][n - k - i]) % Mod;
		printf("%d,%c", ans, n % 50 == 0 ? '\n' : ' ');
	}

	return 0;
}
