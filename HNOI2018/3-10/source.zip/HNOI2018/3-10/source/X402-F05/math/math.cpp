#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef unsigned int uint;

const int N = 3e6 + 10, M = 1e5 + 10;

uint phi[N], f[N];
int prm[N], tot;

void init(int n) {
	phi[1] = 1;
	For(i, 2, n) {
		if (!prm[i]) prm[++tot] = i, phi[i] = i - 1, f[i] = 1;
		for (int j = 1; j <= tot && 1ll * i * prm[j] <= n; ++j) {
			int x = i * prm[j];
			prm[x] = true, f[x] = i;
			if (i % prm[j]) phi[x] = phi[i] * (prm[j] - 1);
			else {
				phi[x] = phi[i] * prm[j];
				break;
			}
		}
	}
	For(i, 2, n) phi[i] += phi[i - 1];
}

int n, k;
int num[M], m;

int main() {

	freopen("math.in", "r", stdin);
	freopen("math.out", "w", stdout);

	int lim = N - 5;
	init(lim);
	scanf("%d%d", &n, &k);

	if (n < lim) {
		uint ans = 0;
		For(d, 1, n) {
			uint coe = 1;
			For(j, 1, k) coe *= f[d];
			if (!f[d]) coe = 0;
			ans += coe * (phi[n / d] * 2 - 1);
		}
		printf("%u\n", ans);
		return 0;
	}

	if (!k) {
		map<int, uint> F;
		for (int i = n, nxt; i; i = nxt)
			num[++m] = i, nxt = n / (n / i + 1);
		reverse(num + 1, num + m + 1);
		For(i, 1, m) {
			int x = num[i];
			if (x < lim) F[x] = phi[x];
			else {
				uint ret = 1ll * x * (x + 1) / 2;
				for (int j = x, nxt; j >= 1; j = nxt) {
					nxt = n / (n / j + 1);
					ret -= (j - nxt) * F[x / j];
				}
				F[x] = ret;
			}
		}
		printf("%u\n", uint(n) * uint(n) - (F[num[m]] * 2 - 1));
	}

	return 0;
}
