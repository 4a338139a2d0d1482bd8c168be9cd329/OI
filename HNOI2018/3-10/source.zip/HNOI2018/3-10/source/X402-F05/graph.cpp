#include<bits/stdc++.h>  
using namespace std;  
const int MOD=1e9+7;  
long long a[101],dp[11][11];  
int c[11][11];  
int main(){  
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
    int n,m;  
    for(int i=0;i<=10;i++)  
        c[i][0]=1;  
    for(int i=1;i<=10;i++)  
        for(int j=1;j<=i;j++)  
            c[i][j]=c[i-1][j-1]+c[i-1][j];  
    a[0]=1;  
    for(int i=1;i<=100;i++)  
    	a[i]=a[i-1]*3%MOD;  
    while(scanf("%d%d",&n,&m)!=EOF){  
        memset(dp,0,sizeof(dp));  
        dp[1][0]=1;  
        for(int i=1;i<=n;i++)  
            for(int j=1;j<=m;j++){  
                dp[i][j]=a[i*j];  
                for(int x=1;x<=i;x++)  
                    for(int y=0;y<=j;y++){  
                        if(i==x&&j==y)  
                            continue;  
                        dp[i][j]=((dp[i][j]-dp[x][y]*c[i-1][x-1]*c[j][y]%MOD*a[(i-x)*(j-b)]%MOD)%MOD+MOD)%MOD;  
                    }  
            }  
        printf("%lld\n",dp[n][m]);  
    }  
    return 0;  
}  
