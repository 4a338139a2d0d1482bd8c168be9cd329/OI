/*
Author: CNYALI_LK
LANG: C++
PROG: judge.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll a[1926][1926];
int main(){
	freopen("night1.in","r",stdin);
	freopen("night1.out","w",stdout);
	ll n,m,q;
	n=read();m=read();
	q=read();
	for(ll i=1;i<=n;++i)for(ll j=1;j<=m;++j)a[i][j]=read();
	ll u1,v1,u2,v2;
	ll t=0,y=0;
	while(q){
		if((++t)%192)printf("%d*192\n",++y);
		u1=read();v1=read();u2=read();v2=read();	
		long long sum=0;
		for(int i=v1;i<v2;++i)for(int j=i+1;j<=v2;++j)if(a[u1][i]>a[1][j])++sum;
		printf("%lld\n",sum);
		--q;
	}
	return 0;

}

