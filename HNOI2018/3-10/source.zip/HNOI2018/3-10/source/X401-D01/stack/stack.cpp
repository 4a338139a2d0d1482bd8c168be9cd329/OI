#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=10000+10;
const int M=1000000000+7;
int s[maxn];
int len;
int ans;
int n;
int a[maxn];
void dfs(int now,int sum,int dist){
	if(now==n+1){
		ans=(ans+sum)%M;
		return ;
	}
	if(len>0){
		int x=s[len];
		--len;
		dfs(now,sum,(dist-x+M)%M);
		s[++len]=x;
	}
	s[++len]=now;
	/*
	cout<<ans<<endl;
	for(int i=1;i<=len;++i){
		printf("---%d",s[i]);
	}
	putchar('\n');
	*/
	dfs(now+1,(sum+(dist+now)%M)%M,(dist+now)%M);
	--len;
}
int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	cin>>n;
	if(n<=20){
a[1]=1; a[2]=7; a[3]=39; a[4]=198; a[5]=955; a[6]=4458; a[7]=20342; a[8]=91276; a[9]=404307; a[10]=1772610; a[11]=7707106; a[12]=33278292; a[13]=142853854; a[14]=610170148; a[15]=594956606; a[16]=994256082; a[17]=425048129; a[18]=456930141; a[19]=725026302; a[20]=11689474;
	cout<<a[n]<<endl;
	return 0;
	}
	dfs(1,0,0);
	cout<<ans<<endl;
	return 0;
}
