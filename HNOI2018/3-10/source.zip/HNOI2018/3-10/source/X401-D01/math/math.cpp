#include<iostream>
#include<cstdio>
using namespace std;
const long long M=4294967296;
int gcd(int a,int b){
	if(!b) return a;
	return gcd(b,a%b);
}
long long f(long long x,int k){
	long long s=1;
	while(k){
		if(k&1) s=s*x%M;
		x=x*x%M;
		k/=2;
	}
	return s;
}
int main(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	int n,k;
	cin>>n>>k;
	long long ans=0;
	for(int i=1;i<=n;++i)
		for(int j=1;j<i;++j){
			int z=gcd(i,j);
			--z;
			while(z>0){
				if(i%z==0 && j%z==0) break;
				--z;
			}
			ans=(ans+f(z,k))%M;
		}
	long long ans2=0;
	for(int i=1;i<=n;++i){
		for(int j=i-1;j>=1;--j)
			if(i%j==0) {
				ans2=(ans2+f(j,k))%M;
				break;
			}
	}
	cout<<(ans*2%M+ans2)%M;
	return 0;
}
