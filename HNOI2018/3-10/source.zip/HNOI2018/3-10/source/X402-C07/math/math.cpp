#include<cstdio>
#include<algorithm>
using namespace std;

long long n,k,ans=0,w;
long long mod,q[100012];
long long mi(long long a,long long b){
	if (a==0)
	  return 0;
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

long long gcd(long long a,long long b){
	if (b==0)
	  return a;
	return gcd(b,a%b);
}

int main(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	mod=(1LL<<32);
	scanf("%lld%lld",&n,&w);
	for (long long i=1;i<=n;i++)
	  for (long long j=1;j<=n;j++)
	  {
	    long long a=min(i,j),b=max(i,j),tot=0;
		if (gcd(a,b)==1)
		{
		  //printf("%lld %lld\n",a,b);
		  continue;
		}
		for (long long k=1;k*k<=a;k++)
	    {
	      if (a%k==0)
	      {
		    if (b%k==0)
			  q[++tot]=k;
		    if (k*k!=a&&a%(a/k)==0&&b%(a/k)==0)
		      q[++tot]=a/k;
		  }
	    }
	    sort(q+1,q+1+tot);
		//printf("%d %d %d\n",i,j,q[tot-1]);
	    ans=(ans+mi(q[tot-1],w))%mod;
	  }
	printf("%lld\n",ans);
}
