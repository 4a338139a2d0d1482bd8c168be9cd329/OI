#include<cstdio>
#include<algorithm>
using namespace std;

int a[1000012],q[1000012],ans=0,n;
const int mod=1e9+7;


void check(){
	int tot=0,now=0,top=0;
	for (int i=1;i<=n*2;i++)
	{
	  if (a[i]==0)
	  {
	  	top--;
	  	if (top<0)
	  	  return ;
	  }
	  else
	  {
	  	q[++top]=++now;
	  	if (now>n)
	  	  return ;
	    for (int i=1;i<=top;i++)
	      tot+=q[i];
	  }
	  tot%=mod;
	}
	ans+=tot;
	ans%=mod;
	//for (int i=1;i<=n*2;i++)
	//  printf("%d ",a[i]);printf("\n");
}

void doing(int pos,int u,int v){
	if (pos==n*2+1)
	{
	  check();
	  return ;
	}
	if (u<v)
	{
	  a[pos]=0;
	  doing(pos+1,u+1,v);
	}
	if (v<n)
	{
	  a[pos]=1;
	  doing(pos+1,u,v+1);
	}
}
int c[1012][1012];
void init(){
	c[0][0]=1;
	for (int i=1;i<=20;i++)
	{
	  c[i][0]=c[i][i]=1;
	  for (int j=1;j<=i-1;j++)
	    c[i][j]=c[i-1][j-1]+c[i-1][j];
	}
}

int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	//scanf("%d",&n);
//	init();
//	for (int i=1;i<=20;i++)
//	{
//	n=i;
//	ans=0;
//	doing(1,0,0);
//	printf("%d %d\n",i,ans);
//	printf("%d\n",c[2*n][n]-c[2*n][n-1]);
//
//	}
a[1]=1;
a[2]=7;
a[3]=39;
a[4]=198;
a[5]=955;
a[6]=4458;
a[7]=20342;
a[8]=91276;
a[9]=404307;
a[10]=1772610;
a[11]=7707106;
a[12]=33278292;
a[13]=142853854;
a[14]=610170148;
a[15]=594956606;
a[16]=994256082;
a[17]=425048129;
a[18]=456930141;
	scanf("%d",&n);
	printf("%d\n",a[n]);
	return 0;
}
