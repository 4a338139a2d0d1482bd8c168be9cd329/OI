#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,q[1012][1012],ans=0;
const int mod=1e9+7;

long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

void check(){
	int okj=1,oko=1;
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=m;j++)
	    if (q[i][j]==0)
	    {
	      if ((i+j)%2==1)
	        okj=0;
	      else
	        oko=0;
	    }
	//  for (int i=1;i<=n;i++,printf("\n"))
	//    for (int j=1;j<=m;j++)
	//      printf("%d",q[i][j]);printf("\n");
	if (okj==1||oko==1)
	{
	  long long tot=0;
	  for (int i=1;i<=n;i++)
	    for (int j=1;j<=m;j++)
	      tot+=q[i][j];
	  ans+=mi(2,tot);
	  //printf("okll\n");
	  //for (int i=1;i<=n;i++,printf("\n"))
	  //  for (int j=1;j<=m;j++)
	  //    printf("%d",q[i][j]);printf("\n");
	  return ;
	}
	for (int i=1;i<=n;i++)
	{
	  int ok=1;
	  for (int j=1;j<=m;j++)
	    if (q[i][j]!=0)
	      ok=0;
	  if (ok==1)
	    return ;
	}
	for (int i=1;i<=m;i++)
	{
	  int ok=1;
	  for (int j=1;j<=n;j++)
	    if (q[j][i]!=0)
	      ok=0;
	  if (ok==1)
	    return ;
	}
	long long tt=0;
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=m;j++)
	    tt+=q[i][j];
	if (tt>=n*m/2+1)
	{
	  ans+=mi(2,tt);
	  return ;
	}
	int okh=0,okl=0;
	for (int i=1;i<=n;i++)
	{
	  int ok=1;
	  for (int j=1;j<=m;j++)
	    if (q[i][j]==0)
	    {
		  ok=0;
		  break;
		}
	  if (ok==1)
	  {
	    okh=1;
	    break;
	  }
	}
	if (okh==0)
	  return ;
	for (int i=1;i<=m;i++)
	{
	  int ok=1;
	  for (int j=1;j<=n;j++)
	    if (q[j][i]==0)
	    {
		  ok=0;
		  break;
		}
	  if (ok==1)
	  {
	    okl=1;
	    break;
	  }
	}
	if (okl==0)
	  return ;
	long long tot=0;
	//printf("ok\n");
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=m;j++)
	  {
	//    printf("%d",q[i][j]);
		tot+=q[i][j];
	  }
	//  printf("\n");
	ans+=mi(2,tot);
}

void doing(int a,int b){
	if (b==m+1)
	{
	  doing(a+1,1);
	  return ;
	}
	if (a==n+1)
	{
	  check();
	  return ;
	}
	q[a][b]=0;
	doing(a,b+1);
	q[a][b]=1;
	doing(a,b+1);
}

int main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	int t;
	scanf("%d",&t);
	while (t--)
	{
	  ans=0;
	  scanf("%d%d",&n,&m);
	  if (n>m)
	    swap(n,m);
	  if (n==1)
	  {
	  	printf("%lld\n",mi(2,m));
	  	continue;
	  }
	  doing(1,1);
	  printf("%lld\n",ans-mi(2,m+1));
	}
	return 0;
}
