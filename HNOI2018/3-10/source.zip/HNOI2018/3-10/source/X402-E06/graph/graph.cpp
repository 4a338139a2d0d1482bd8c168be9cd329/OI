#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;
const int mo = 1e9 + 7;

int fpm(int x, int y) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1)
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

int fac[N + 5], inv[N + 5];

inline int binom(int n, int k) {
    if(n < k) return 0;
    return 1ll * fac[n] * inv[k] % mo * inv[n-k] % mo;
}

void init() {
    fac[0] = 1;
    for(int i = 1; i <= N; ++i) fac[i] = 1ll * fac[i-1] * i % mo;
    inv[N] = fpm(fac[N], mo - 2);
    for(int i = N; i >= 1; --i) inv[i-1] = 1ll * inv[i] * i % mo;
}

int T, n, m;
int a[15][15];

bool chk(int x) {
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) a[i][j] = x & 1; x >>= 1; 
    }

    for(int i = 0; i < n; ++i) {
        bool flag = true;
        for(int j = 0; j < m; ++j) if(a[i][j]) flag = false;
        if(flag) return false;
    }

    for(int i = 0; i < m; ++i) {
        bool flag = true;
        for(int j = 0; j < n; ++j) if(a[j][i]) flag = false;
        if(flag) return false;
    }

    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) {
            bool flag = true;

            for(int ni = 0; ni < n; ++ni) if(ni ^ i) { if(a[ni][j]) flag = false; }
            for(int nj = 0; nj < m; ++nj) if(nj ^ j) { if(a[i][nj]) flag = false; }

            if(flag) return false;
        }
    }
    return true;
}

int main() {
    freopen("graph.in", "r", stdin);
    freopen("graph.out", "w", stdout);

    init();
    read(T);
    while(T--) {
        read(n), read(m);
        if(n > m) std::swap(n, m);

        if(n <= 4 && m <= 4) {
            int ans = 0;
            for(int s = 0; s < (1 << (n*m)); ++s) 
                if(chk(s)) ans = (ans + fpm(2, __builtin_popcount(s))) % mo;
            printf("%d\n", ans);
            continue;
        }
        if(n == 1) {
            printf("%d\n", fpm(2, m));
            continue;
        } 

        int ans = fpm(fpm(3, m) - 1, n);
        for(int i = 1; i <= m; ++i) {
            ans = (ans + ll((i & 1) ? -1 : +1) * binom(m, i) * fpm(fpm(3, m - i) - 1, n)) % mo;
        }

        printf("%d\n", ans);
    }

    return 0;
}
