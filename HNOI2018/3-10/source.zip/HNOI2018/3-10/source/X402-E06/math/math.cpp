#include <bits/stdc++.h>
#include <tr1/unordered_map>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

typedef unsigned int uint;

const int N = 1000000;

uint fpm(uint a, uint b) {
    if(!a && !b) return 0;

    uint res = 1;
    for(; b > 0; b >>= 1) {
        if(b & 1)
            res *= a;
        a *= a;
    }
    return res;
}

bool notprime[N + 5];
uint phi[N + 5], mn[N + 5], prime[N + 5], pcnt;

void sieve() {
    phi[1] = 1;
    for(uint i = 2; i <= N; ++i) {
        if(!notprime[i]) {
            mn[i] = i;
            phi[i] = i-1;
            prime[pcnt++] = i;
        }
        static ll x;
        for(uint j = 0; j < pcnt && (x = 1ll * i * prime[j]) <= N; ++j) {
            notprime[x] = true;
            mn[x] = std::min(mn[i], prime[j]);

            if(i % prime[j] == 0) {
                phi[x] = phi[i] * prime[j];
                break;
            }
            phi[x] = phi[i] * (prime[j] - 1);
        }
    }
    for(uint i = 1; i <= N; ++i) {
        phi[i] += phi[i-1];
        mn[i] = (i == 1 ? 0 : i / mn[i]);
    }
}

std::tr1::unordered_map<uint, uint> mp;

uint get_phi(uint n) {
    if(n <= N) return phi[n];
    if(mp.count(n)) return mp[n];
    
    uint res = uint(1ll * n * (n + 1) / 2);
    for(uint d = 2, nxt; d <= n; d = nxt + 1) {
        nxt = n / (n / d);
        res -= (nxt-d+1) * get_phi(n/d);
    }
    return mp[n] = res;
}

uint n, k;
int main() {
    freopen("math.in", "r", stdin);
    freopen("math.out", "w", stdout);

    sieve();
    read(n), read(k);

    if(k == 0) {
        printf("%u\n", n*n - 2*get_phi(n) + 1);
        return 0;
    }

    uint ans = 0;
    for(uint d = 1; d <= n; ++ d) {
        ans += fpm(mn[d], k) * (2*phi[n/d]-1);
    }
    printf("%u\n", ans);

    return 0;
}
