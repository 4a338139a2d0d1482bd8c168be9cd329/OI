#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c =='-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n;

void Get() {
	n = read();
}

int a[maxn], vis[maxn];

int calc(int x){
	int Ans = 0;
	For(i, 1, x) vis[i] = 0;
	For(i, 1, x) {
		For(j, 1, a[i]) {
			if(!vis[j]) {
				Ans += j;
			}
		}
		vis[a[i]] = 1;
	}
	return Ans;
}

int Max[maxn];

void solve_bf() {

	int Ans = 0;
	For(i, 1, n) a[i] = i;
	do{
		For(i, 1, n) vis[i] = 0;
		bool flag = 0;

		For(i, 1, n) {
			int pos = 0;
			rep(j, n, a[i]) {
				if(vis[j]) {pos = j; break;}
			}

			if(pos) {
				For(j, a[i]+1, pos-1) {
					if(!vis[j]) {
						flag = 1;
						break;
					}
				}
			}

			if(flag) break;

			vis[a[i]] = 1;
		}

		if(flag) continue;

		For(i, 1, n) vis[i] = 0;

		For(i, 1, n) {
			For(j, 1, a[i]) {
				if(!vis[j]) {
					Ans += j;
				}
			}
			vis[a[i]] = 1;
		}
	}while(next_permutation(a+1, a+n+1) );
	printf("%d\n", Ans);
}

int main() {
	
	freopen("stack.in", "r", stdin);
	freopen("stack.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
