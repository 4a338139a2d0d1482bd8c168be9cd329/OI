#include<bits/stdc++.h>

#define ll unsigned int
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c =='-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 5000010;

const int maxm = 5000000;

int n, K;

void Get() {
	n = read(), K = read();
}

int prime[maxn], cnt;

bool vis[maxn];

int Max[maxn], miu[maxn], oula[maxn], ans[maxn], sum[maxn];

void pre_work() {
	miu[1] = 1;
	oula[1] = 1;
	For(i, 2, maxm) {
		if(!vis[i]) {
			vis[i] = 1;
			Max[i] = i;
			prime[++cnt] = i;
			miu[i] = -1;
			oula[i] = i-1;
		}

		for(int j = 1;j <= cnt && 1ll * prime[j] * i <= 1ll * maxm; ++j) {
			int k = i * prime[j];
			vis[k] = 1;
			Max[k] = prime[j];

			if(i % prime[j] == 0){
				oula[k] = oula[i] * prime[j];
				miu[k] = 0;
				break;
			}

			miu[k] = -miu[i];
			oula[k] = oula[i] * (prime[j] - 1);
		}
	}

	ans[1] = 1ll;
	For(i, 2, maxm) {
		ans[i] = ans[i-1] + oula[i] * 2ll;
	}

	For(i, 1, maxm) sum[i] = sum[i-1] + oula[i];
}

ll ksm(ll x, ll k) {
	ll s = 1ll;
	while(k) {
		if(k & 1) s = s * x;
		x = x * x;
		k >>= 1;
	}
	return s;
}

void solve_bf() {
	pre_work();
	ll Ans = 0;
	For(i, 2, n) {
		ll now = ksm(i / Max[i], K);
		Ans += now * (ll)ans[n / i];
	}
	printf("%u\n", Ans);
}

int gcd(int x,int y) {return !y ? x : gcd(y, x%y);}

void bf() {
	pre_work();
	ll Ans = 0;
	For(i, 1, n) {
		For(j, 1, n) {
			ll now = 0;
			if(gcd(i, j) != 1) now = ksm(gcd(i, j) / Max[gcd(i, j)], K );
			Ans += now;
		}
	}
	printf("%u\n", Ans);
}

map<ll , ll> q;

ll calc(ll x) {
	if(x <= maxm) return sum[x];
	if(q.find(x) != q.end()) return q[x];

	ll Ans = 0, ans = 0;

	if(x & 1) Ans = (x + 1) / 2 * x;
	else Ans = x / 2 * (x + 1);

	for(ll i = 2; i <= x; ++i) {
		ll tmp = (x / (x / i) );
		ll now = 0;
		now = (tmp - i + 1);

		ans += now * calc(x / i);
		i = tmp;
	}

	return q[x] = (Ans - ans);
}

void solve_spe() {
	ll Ans = 0;
	Ans = n * n;
	pre_work();
	Ans -= calc(n) * 2 - 1;
	printf("%u\n", Ans);
}

int main() {

	freopen("math.in", "r", stdin);
	freopen("math.out", "w", stdout);

	Get();

	if(K == 0) solve_spe();
	else solve_bf();

	return 0;
}
