#include<bits/stdc++.h>
#define ll long long
#define ui unsigned int
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
int n,k;
ui sum,ss;
ui mi[10000];
int a[910][910][2];
int s[910];
void chai(int x)
{
	int X=x;
	for (int i=2;i*i<=x;i++)
	{
		if (X%i==0)
		{
			s[x]++;
			a[x][s[x]][0]=i;
			while (X%i==0)
			{
				a[x][s[x]][1]++;
				X/=i;
			}
		}
		if (X==1) break;
	}
	if (X!=1) 
	{
		s[x]++;
		a[x][s[x]][0]=X;
		a[x][s[x]][1]++;
	}
}
int b[1000];
int gcd(int x,int y)
{
	if (y==0) return x;
	return gcd(y,x%y);
}
int main()
{
#ifdef ylx
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
#endif
	n=read();k=read();
	for (int i=1;i<=n;i++)
	{
		ss=1;
		for (int j=1;j<=k;j++) ss*=(ui)i;
		mi[i]=ss;
		chai(i);
		a[i][1][1]--;
		a[i][0][0]=1;
		a[i][0][1]=1;
	}
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
		{
			int x=gcd(i,j);
			if (x==1) continue;
			bool flag=false;
			ss=1;
			for (int l=0;l<=s[x];l++)
			{
				for (int cnt=1;cnt<=a[x][l][1];cnt++)
				{
					ss*=a[x][l][0];
				}
			}
			ss=mi[ss];
			sum+=ss;
		}
	cout<<sum;
	return 0;
}
