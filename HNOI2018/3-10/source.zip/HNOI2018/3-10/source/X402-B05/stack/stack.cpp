#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
ll a[100];
int n;
/*
const ll mod=1e9+7;
int n;
int a[30],top;
ll ans;
ll sum,s,ss,s1;
int c[30],qaq;
void sc(int x)
{
	printf("%d ：%lld %lld = ",x,s,sum);
	for (int i=1;i<=top;i++)
	{
		printf("%d ",sum);
	}
	printf("\n");
}
void dfs(int x)//x not in stack
{
	if (x==n+1)
	{
//		for (int i=1;i<=qaq;i++)
//		{
//			printf("%d ",c[i]);
//		}
//		for (int i=top;i>=1;i--)
//		{
//			printf("%d ",a[i]);
//		}
//		cout<<"--"<<sum<<endl;
		s1++;
//		if (s1==1) cerr<<sum<<" \n";
		if (s1%10000000==0) cerr<<s1<<" ";
		ans+=sum;
		ans%=mod;
		return;
	}
	top++;a[top]=x;s+=x;sum+=s;
	dfs(x+1);
	top--;sum-=s;s-=x;

	if (top==0) return;
	int X=a[top];
	top--;s-=X;
	c[++qaq]=X;
	dfs(x);
	--qaq;
	top++;s+=X;a[top]=X;
}*/
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	a[1]=1;
	a[2]=7;
	a[3]=39;
	a[4]=198;
	a[5]=955;
	a[6]=4458;
	a[7]=20342;
	a[8]=91276;
	a[9]=404307;
	a[10]=1772610;
	a[11]=7707106;
	a[12]=33278292;
	a[13]=142853854;
	a[14]=610170148;
	a[15]=594956606;
	a[16]=994256082;
	a[17]=425048129;
	a[18]=456930141;
	a[19]=725026302;
	a[20]=11689474;
	n=read();
	printf("%lld\n",a[n]);
/*
#ifdef ylx1
//	n=read();
	for (n=1;n<=20;n++)
	{
		ans=0;
		sum=0;cerr<<n<<"---------------------\n";
		dfs(1);
		ans=(ans%mod+mod)%mod;
		printf("%lld\n",ans);
		cerr<<ans<<endl;
	}
#endif
*/
	return 0;
}
