#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const ll mod=1e9+7;
ll n,m,T,ans;
ll ksm(ll x,ll y)
{
	ll sum=1;
	while (y)
	{
		if (y%2==1) sum=sum*x%mod;
		x=x*x;
		y/=2;
	}
	return sum;
}
int main()
{
#ifdef ylx
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
#endif
	T=read();
	while (T--)
	{
		n=read();
		m=read();
		if (m<n) swap(n,m);
		if (n==1)
		{
			ans=ksm(2,m);
			printf("%lld\n",ans);
		}
	}
	return 0;
}
