#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 21;
const int mo = 1e9 + 7;

int n, ans = 0;
int sum[(1 << N) + 5];
int dp[N + 5][(1 << N) + 5], f[N + 5][(1 << N) + 5];

int main() {
    freopen("stack.in", "r", stdin);
    freopen("stack.out", "w", stdout);

    read(n);
    for(int i = 1; i < (1 << n); ++i) {
        int x = __builtin_ctz(i);
        sum[i] = sum[i ^ (1 << x)] + x + 1;
    }

    dp[0][0] = 1;
    for(int i = 0; i <= n; ++i) {
        for(int j = (1 << n)-1; j >= 0; --j) if(dp[i][j]) {

            if(j > 0) {
                int y = __builtin_clz(j);
                (f[i][j ^ (1 << (31 - y))] += f[i][j]) %= mo;
                (dp[i][j ^ (1 << (31 - y))] += dp[i][j]) %= mo;
            }
            (dp[i+1][j | (1 << i)] += dp[i][j]) %= mo;
            f[i+1][j | (1 << i)] = (dp[i+1][j | (1 << i)] + f[i][j] + 1ll * dp[i][j] * sum[j|(1<<i)]) % mo;
        }
    }
    printf("%d\n", f[n][0] % mo);

    return 0;
}

