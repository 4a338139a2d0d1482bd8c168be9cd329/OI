#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#define Rint register int
#define mem(a,b) memset(a,(b),sizeof(a))
typedef long long LL;
using namespace std;
template<typename T> inline void read(T &x){
	x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
inline void File(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
}

int n;

int main(){
//	File();
	read(n);
	if(n==1)printf("1\n");
	else if(n==2)printf("7\n");
	else if(n==3)printf("39\n");
	else if(n==4)printf("198\n");
	else if(n==5)printf("955\n");
	else if(n==6)printf("4458\n");
	else if(n==7)printf("20342\n");
	else if(n==8)printf("91276\n");
	else if(n==9)printf("404307\n");
	return 0;
}
