#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#define Rint register int
#define mem(a,b) memset(a,(b),sizeof(a))
typedef long long LL;
using namespace std;
template<typename T> inline void read(T &x){
	x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
inline void File(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
}
const int maxn=1e6+10;
int n,k;
int sum;

inline int gcd(int a,int b){
	if(b==0)return a;
	return gcd(b,a%b);
}
inline int sgcd(int x,int y){
	int p=gcd(x,y);
	if(p==1)return 0;
	for(Rint i=2;i<=p;i++){
		if(p%i==0)return p/i;
	}
}
inline int qpow(int a,int p){
	int ans=1;
	while(p){
		if(p&1)ans*=a;
		a*=a;
		p>>=1;
	}
	return ans;
}

int main(){
	File();
	read(n);read(k);
	if(k==0){
		printf("%d\n",n*n);
		return 0;
	}
	for(Rint i=1;i<=n;i++){
		for(Rint j=1;j<=n;j++){
			sum+=qpow(sgcd(i,j),k);
		}
	}
	printf("%d\n",sum);
	return 0;
}
