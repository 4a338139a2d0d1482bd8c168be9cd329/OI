#include<bits/stdc++.h>
using namespace std;

const int maxn=110;
int n, m;
int a[maxn][maxn], ans;
int tx[maxn][maxn], ty[maxn][maxn];
bool vis[maxn][maxn];

void DFS(int x,int now){
	if(vis[x][now]) return;
	vis[x][now]=1;
	if(now==0){
		for(int i=1;i<=m;i++) if(tx[x][i]) DFS(i,now^1);
	}else for(int i=1;i<=n;i++) if(ty[x][i]) DFS(i,now^1);
}
bool check(){
	// for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=m;j++) printf("%d ", a[i][j]);
	// puts("");
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) if(a[i][j]) tx[i][j]=1, ty[j][i]=1;
	else tx[i][j]=ty[j][i]=0;
	for(int i=1;i<=max(n,m);i++) vis[i][0]=vis[i][1]=0;
	DFS(1,0);
	for(int i=1;i<=n;i++) if(!vis[i][0]) return false;
	for(int i=1;i<=m;i++) if(!vis[i][1]) return false;
	return true;
}
void dfs(int x,int y){
	if(y==m+1){
		if(x==n){
			if(check()) ans++;
			return;
		}
		dfs(x+1,1);
		return;
	}
	a[x][y]=0; dfs(x,y+1);
	a[x][y]=1; dfs(x,y+1);
	a[x][y]=2; dfs(x,y+1);
}

int main(){
	freopen("graph.in","r",stdin),freopen("graph.out","w",stdout);

	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%d%d", &n, &m);
		if(n==1 || m==1){ puts("1"); continue; }
		ans=0;
		dfs(1,1);
		printf("%d\n", ans);
	}
	return 0;
}
