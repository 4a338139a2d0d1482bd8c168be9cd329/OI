#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=110;
const int mod=1e9+7;
int n, m;
int a[maxn][maxn], ans;
int tx[maxn][maxn], ty[maxn][maxn];
bool vis[maxn][maxn];

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; } 
	return ret;
}

void DFS(int x,int now){
	if(vis[x][now]) return;
	vis[x][now]=1;
	if(now==0){
		for(int i=1;i<=m;i++) if(tx[x][i]) DFS(i,now^1);
	}else for(int i=1;i<=n;i++) if(ty[x][i]) DFS(i,now^1);
}
bool check(){
	// for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=m;j++) printf("%d ", a[i][j]);
	// puts("");
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) if(a[i][j]) tx[i][j]=1, ty[j][i]=1;
	else tx[i][j]=ty[j][i]=0;
	for(int i=1;i<=max(n,m);i++) vis[i][0]=vis[i][1]=0;
	DFS(1,0);
	for(int i=1;i<=n;i++) if(!vis[i][0]) return false;
	for(int i=1;i<=m;i++) if(!vis[i][1]) return false;
	return true;
}
void dfs(int x,int y){
	if(y==m+1){
		if(x==n){
			if(check()) ans++;
			return;
		}
		dfs(x+1,1);
		return;
	}
	a[x][y]=0; dfs(x,y+1);
	a[x][y]=1; dfs(x,y+1);
	a[x][y]=2; dfs(x,y+1);
}

int c[maxn][maxn];
ll dp[maxn][maxn], pw[maxn*maxn];
void init(){
	c[0][0]=1;
	for(int i=1;i<maxn;i++){
		c[i][0]=1;
		for(int j=1;j<=i;j++) c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
	}
	for(int i=0;i<=10000;i++) pw[i]=Pow(3,i);
}

void solve(){
	for(int i=1;i<=n;i++) for(int j=0;j<=m;j++){
		dp[i][j]=pw[i*j];
		for(int k=1;k<=i;k++) for(int l=0;l<=j;l++){
			if(k==i && l==j) continue;
			dp[i][j]=(dp[i][j]-dp[k][l]*c[i-1][k-1]%mod*c[j][l]%mod*pw[(i-k)*(j-l)]%mod+mod)%mod;
		}
	}
	// printf("%lld\n", dp[1][1]);
}

int main(){
	freopen("graph.in","r",stdin),freopen("graph.out","w",stdout);

	int T;
	scanf("%d", &T);
	init();
	n=100, m=100;
	solve();
	while(T--){
		scanf("%d%d", &n, &m);
		printf("%lld\n", dp[n][m]);
	}
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
