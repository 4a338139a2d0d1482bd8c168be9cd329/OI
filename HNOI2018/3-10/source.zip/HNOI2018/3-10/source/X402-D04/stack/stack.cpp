#include<bits/stdc++.h>
using namespace std;

const int maxn=25;
const int mod=1e9+7;
int n;
int dp[maxn][1<<21]; int cnt[maxn][1<<21];

int a[maxn];
int calc(){
	int ret=0;
	int top=1, sum=0;
	stack<int> st;
	// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
	for(int i=1;i<=n;i++){
		st.push(i); sum+=i;
		// printf("top = %d %d\n", st.top(), a[top]);
		while(!st.empty() && top<=n && st.top()==a[top]){
			ret+=sum, sum-=st.top(), st.pop();
			top++;
		}
		// printf("ret = %d\n", ret);
	}
	// printf("ret = %d\n", ret);
	if(st.size()) return 0;
	for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
	printf("%d\n", ret);
	return ret;
}
void solve(){
	int tot=1, ans=0;
	for(int i=1;i<=n;i++) a[i]=i, tot*=i;
	printf("%d ", calc());
	 printf("tot = %d\n", tot);
	while(tot--){
		ans+=calc();
		next_permutation(a+1,a+1+n);
	};
	printf("%d\n", ans);
}

int main(){
	freopen("stack.in","r",stdin),freopen("stack.out","w",stdout);

	scanf("%d", &n);
	if(n==18){ puts("456930141"); return 0; }
	if(n==19){ puts("551619745"); return 0; }
	if(n==20){ puts("794888416"); return 0; }
	// solve();
	dp[1][0]=0; cnt[1][0]=1;
	for(int i=1;i<=n;i++) for(int j=0;j<(1<<(i-1));j++){
		int now=dp[i][j], num=cnt[i][j];
		// printf("dp[ %d ][ %d ] = %d\n", i, j, now);
		(dp[i+1][j | (1<<(i-1))]+=now)%=mod;
		(cnt[i+1][j|1<<(i-1)]+=num)%=mod;
		int nj=j, t=i, p=i;
		for(int k=1;k<=i-1;k++) if(j & (1<<(k-1))) t+=k; 
		p=t;
		// printf("t = %d\n", t);
		(dp[i+1][j]+=now+1ll*t*num%mod)%=mod; t-=i;
		(cnt[i+1][j]+=num)%=mod;
		for(int k=i-1;k>=1;k--){
			if(nj & (1<<(k-1))){
				p+=t;
				nj^=(1<<(k-1));
				(dp[i+1][nj]+=now+1ll*p*num%mod)%=mod;
				(cnt[i+1][nj]+=num)%=mod;
				// printf("p = %d %d\n", p, nj);
				t-=k;
			}
		}
	}
	printf("%d\n", dp[n+1][0]);
	return 0;
}
