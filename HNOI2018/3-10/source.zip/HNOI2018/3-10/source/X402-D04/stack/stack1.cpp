#include<bits/stdc++.h>
using namespace std;

const int maxn=25;
const int mod=1e9+7;
int n;
int dp[maxn][1<<21];

int main(){
	freopen("stack.in","r",stdin),freopen("stack.out","w",stdout);

	scanf("%d", &n);
	dp[1][0]=0;
	for(int i=1;i<=n;i++) for(int j=0;j<(1<<(i-1));j++){
		int now=dp[i][j];
		printf("dp[ %d ][ %d ] = %d\n", i, j, now);
		(dp[i+1][j | (1<<(i-1))]+=now)%=mod;
		int nj=j, t=i, p=i;
		for(int k=1;k<=i-1;k++) if(j & (1<<(k-1))) t+=k; 
		p=t;
		printf("t = %d\n", t);
		(dp[i+1][j]+=now+t)%=mod; t-=i;
		for(int k=i-1;k>=1;k--){
			if(nj & (1<<(k-1))){
				p+=t;
				nj^=(1<<(k-1));
				(dp[i+1][nj]+=now+p)%=mod;
				printf("p = %d %d\n", p, nj);
				t-=k;
			}
		}
	}
	printf("%d\n", dp[n+1][0]);
	return 0;
}
