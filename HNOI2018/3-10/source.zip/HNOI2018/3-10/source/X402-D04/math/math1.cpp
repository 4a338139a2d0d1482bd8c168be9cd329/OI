#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned int ui;
const int maxn=1000010;
int n, k;
ui Pow[maxn];
int prime[maxn], isprime[maxn], Min[maxn], mu[maxn], cnt;
void init(){
	mu[1]=1;
	for(int i=2;i<maxn;i++){
		if(!isprime[i]) prime[++cnt]=i, mu[i]=-1;
		for(int j=1;j<=cnt && 1ll*i*prime[j]<maxn;j++){
			isprime[i*prime[j]]=1; Min[i*prime[j]]=i; mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				break;
			}
		}
	}
	Pow[1]=(1u<<31)+30;
	printf("%u\n", Pow[1]);
	for(int i=1;i<maxn;i++){
		Pow[i]=1;
		for(int j=1;j<=k;j++) Pow[i]=Pow[i]*i;
	}
	for(int i=1;i<=10;i++) if(!isprime[i]) printf("%d ", i); puts("");
	for(int i=1;i<=10;i++) printf("%u ", Pow[i]); puts("");
}

int gcd(int x,int y){ return !y ? x : gcd(y,x%y); }
ui g(int x,int y){
	int t=gcd(x, y);
	// cerr<<t<<' '<<isprime[t]<<endl;
	// printf("%d %d\n", t, isprime[t]);
	if(t==1) return 0;
	if(!isprime[t]) return 1;
	return t/Min[t];
}

ui ans;

int main(){
	freopen("math.in","r",stdin),freopen("math.out","w",stdout);

	scanf("%d%d", &n, &k);
	init();
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++){
		// cerr<<g(i,j)<<endl;
		ans+=Pow[g(i,j)];
		// cerr<<ans<<endl;
		//printf("g[%d %d] = %d %lld\n", i, j, g(i,j), ans);
	}
	printf("%u\n", ans);
	return 0;
}
