#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned int ui;
const int maxn=1000010;
int n, k;
ui Pow[maxn];
int prime[maxn], isprime[maxn], Min[maxn], mu[maxn], cnt;
ui f[maxn];
map<int,int> mp;
void init(){
	mu[1]=1;
	for(int i=2;i<maxn;i++){
		if(!isprime[i]) prime[++cnt]=i, mu[i]=-1;
		for(int j=1;j<=cnt && 1ll*i*prime[j]<maxn;j++){
			isprime[i*prime[j]]=1; Min[i*prime[j]]=prime[j]; mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				break;
			}
		}
	}
	for(int i=1;i<maxn;i++){
		Pow[i]=1;
		for(int j=1;j<=k;j++) Pow[i]=Pow[i]*i;
	}
	for(int i=1;i<maxn;i++) f[i]=f[i-1]+mu[i];
	return;
	for(int i=1;i<=10;i++) if(!isprime[i]) printf("%d ", i); puts("");
	for(int i=1;i<=10;i++) printf("%u ", Pow[i]); puts("");
}

int gcd(int x,int y){ return !y ? x : gcd(y,x%y); }
ui g(int x,int y){
	int t=gcd(x, y);
	// cerr<<t<<' '<<isprime[t]<<endl;
	// printf("%d %d\n", t, isprime[t]);
	if(t==1) return 0;
	if(!isprime[t]) return 1;
	return t/Min[t];
}

ui ans;

ui S(int x){
	if(!x) return 0;
	if(x<maxn) return f[x];
	if(mp[x]) return mp[x];
	ui ret=1;
	for(int l,r,i=2;i<=x;i=r+1){
		l=i, r=x/(x/i);
		ret-=(r-l+1)*S(x/i);
		// printf("ret = %u\n", ret);
	}
	return mp[x]=ret;
}

void solve(){
	ui ret=1u*n*n;
	for(int l,r,i=1;i<=n;i=r+1){
		l=i, r=n/(n/i);
		ret-=(S(r)-S(l-1))*(n/i)*(n/i);
	}
	printf("%u\n", ret);
}

int main(){
	freopen("math.in","r",stdin),freopen("math.out","w",stdout);

	scanf("%d%d", &n, &k);
	init();
	if(k==0){ solve(); return 0; }
	ans=0;
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++){
		// cerr<<g(i,j)<<endl;
		ans+=Pow[g(i,j)];
		// cerr<<ans<<endl;
		// if(g(i,j)) printf("%d %d %u\n", i, j, g(i,j));
		//printf("g[%d %d] = %d %lld\n", i, j, g(i,j), ans);
	}
	printf("%u\n", ans);
	/*
	ans=0;
	for(int i=1;i<=n;i++){
		ui tot=0;
		for(int l=1;l<=cnt && 1ll*i*prime[l]<=n;l++){
			for(int d=1;d<=n/i/prime[l];d++){
				tot+=1u*mu[d]*(n/i/prime[l]/d)*(n/i/prime[l]/d);
				// printf("%u\n", tot);
			}
		}
		ans+=tot*Pow[i];
	}
	printf("%u\n", ans);
	*/
	return 0;
}
