#include<bits/stdc++.h>
using namespace std;
const long long md=1e9+7;
const int drx[8]={-1,-1,0,1,1,1,0,-1};
const int dry[8]={0,1,1,1,0,-1,-1,-1};
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int n,m,T;
int id(int x,int y){
	return x*m+y;
}
bool ok(int zt,int x,int y){
	if(x>=n||x<0) return 0;
	if(y>=m||y<0) return 0;
	if(zt&(1<<id(x,y)))
		return 1;
	return 0;
}
int main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	scanf("%d",&T);
	int x,y;
	while(T--){
		scanf("%d%d",&n,&m);
		if(n==1)
			printf("%lld\n",powd(2,m));
		else if(m==1)
			printf("%lld\n",powd(2,n));
		else{
			int ans=0,st;
			for(int i=0;i<(1<<(n*m));i++){
				st=i;
				while(1){
					bool bo=0;
					for(int j=0;j<n*m;j++){
						if(st&(1<<j)) continue;
						x=j/m,y=j%m;
						for(int k=0;k<8;k+=2){
							if(ok(st,x+drx[k],y+dry[k])
							 &&ok(st,x+drx[(k+1)%8],y+dry[(k+1)%8])
							 &&ok(st,x+drx[(k+2)%8],y+dry[(k+2)%8])){
								st|=(1<<j);
								bo=1;
								break;
							}
						}
					}
					if(!bo) break;
				}
				if(st==((1<<(n*m))-1))
					ans=(ans+powd(2,__builtin_popcount(i)))%md;
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
