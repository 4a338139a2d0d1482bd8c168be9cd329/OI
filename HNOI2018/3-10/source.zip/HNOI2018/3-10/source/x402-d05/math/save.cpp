#include<bits/stdc++.h>
using namespace std;
const int maxn=1001000;
#define uint unsigned int
int mysqrt(long long x){
	int y=sqrt(x);
	while(y*(long long)y>x) y--;
	while(y*(long long)y<x) y++;
	return y;
}
long long n;
int k,S;
long long id(long long x){
	return x<=S?x:S+n/x;
}
bool vis[maxn];
int prim[maxn],ilem;
uint phi[maxn],d[maxn];
uint prim_sum[maxn],prim_cnt[maxn];
uint prim_ans[maxn];
uint powd(uint x,int y){
	uint res=1;
	while(y){
		if(y&1) res=res*x;
		x=x*x;
		y>>=1;
	}
	return res;
}
uint G_sum(long long x,long long y){
	uint res=0;
	long long t;
	for(long long i=1;i<=y;i=t+1){
		t=x/(x/i);
		if(t>y) t=y;
		res=res+(prim_sum[t]-prim_sum[i-1])*(2*phi[x/i]-1);
	}
	return res;
}
uint G_cnt(long long x,long long y){
	uint res=0;
	long long t;
	for(long long i=1;i<=y;i=t+1){
		t=x/(x/i);
		if(t>y) t=y;
		res=res+(prim_cnt[t]-prim_cnt[i-1])*(2*phi[x/i]-1);
	}
	return res;
}
void csh(){
	for(int i=2;i<maxn;i++){
		if(!vis[i]){
			prim[++ilem]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=ilem;j++){
			if(i*prim[j]>=maxn) break;
			vis[i*prim[j]]=1;
			if(i%prim[j]==0){
				phi[i*prim[j]]=phi[i]*prim[j];
				break;
			}
			phi[i*prim[j]]=phi[i]*(prim[j]-1);
		}
	}
	vis[1]=1;
	phi[1]=1;
	for(int i=1;i<maxn;i++){
		phi[i]+=phi[i-1];
		prim_sum[i]=prim_sum[i-1]+((!vis[i])?powd(i,k):0);
		prim_cnt[i]=prim_cnt[i-1]+(!vis[i]);
	}
}
uint F(long long x,int y){
	if(prim[y]>x) return 0;
	uint res=G_sum(x,x)-G_sum(x,prim[y]-1);
	long long st;
	for(int i=y;i<=ilem;i++){
		st=prim[i];
		if(st*st>x) break;
		for(int j=1;;j++){
			if(st*prim[i]>x) break;
			res=res+F(x/st,i+1)*powd((uint)st,k)+powd(((uint)st*prim[i]),k)*(2*phi[x/(st*prim[i])]-1);
			st=st*prim[i];
		}
	}
	return res;
}
int main(){
	freopen("math.in","r",stdin);
	scanf("%lld%d",&n,&k);
	S=mysqrt(n);
	csh();
	uint ans=G_cnt(n,n)-G_cnt(n,1);

	long long st;
	uint ls=0;
	for(int i=1;i<=ilem;i++){
		st=prim[i];
		if(st*st>n) break;
		for(int j=1;;j++){
			if(st*prim[i]>n) break;
			ans=ans+F(n/st,i+1)*(powd((uint)(st/prim[i]),k))+(powd((uint)st,k))*(2*phi[n/(st*prim[i])]-1);
			ls+=(powd((uint)st,k))*(2*phi[n/(st*prim[i])]-1);
			st=st*prim[i];
		}
	}
	printf("%u\n",ans);
	return 0;
}
