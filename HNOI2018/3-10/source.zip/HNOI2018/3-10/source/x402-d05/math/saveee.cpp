#include<bits/stdc++.h>
using namespace std;
const int maxn=1001000;
#define uint unsigned int
long long Min(long long x,long long y){
	return x<y?x:y;
}
int mysqrt(long long x){
	int y=sqrt(x);
	while(y*(long long)y>x) y--;
	while(y*(long long)y<x) y++;
	return y;
}
long long n;
int k,S;
long long id(long long x){
	return x<=S?x:S+n/x;
}
bool vis[maxn<<1];
int prim[maxn<<1],ilem;
uint phi[maxn<<1],d[maxn<<1];
uint prim_sum[maxn<<1],prim_cnt[maxn<<1];
uint prim_ans[maxn<<1];
uint powd(uint x,int y){
	uint res=1;
	while(y){
		if(y&1) res=res*x;
		x=x*x;
		y>>=1;
	}
	return res;
}
uint G_sum(long long x,long long y){
	uint res=0;
	long long t;
	for(long long i=1;i<=y;i=t+1){
		t=x/(x/i);
		if(t>y) t=y;
		res=res+(prim_sum[t]-prim_sum[i-1])*(2*phi[x/i]-1);
	}
	return res;
}
uint G_cnt(long long x,long long y){
	uint res=0;
	long long t;
	for(long long i=1;i<=y;i=t+1){
		t=x/(x/i);
		if(t>y) t=y;
		res=res+(prim_cnt[t]-prim_cnt[i-1])*(2*phi[x/i]-1);
	}
	return res;
}
uint Sum(long long x){
	if(x&1) return ((uint)x)*(uint)((x+1)/2);
	else return ((uint)(x/2))*(uint)(x+1);
}
uint Ans(long long x){
	uint ans=0;
	for(int i=1;i<=x;i++)
		ans=ans+powd(i,k);
	return ans;
}
void csh_prim(){
	for(int i=2;i<maxn;i++){
		if(!vis[i]){
			prim[++ilem]=i;
			phi[i]=i-1;
			d[i]=1;
		}
		for(int j=1;j<=ilem;j++){
			if(i*prim[j]>=maxn) break;
			vis[i*prim[j]]=1;
			d[i*prim[j]]=i;
			if(i%prim[j]==0){
				phi[i*prim[j]]=phi[i]*prim[j];
				break;
			}
			phi[i*prim[j]]=phi[i]*(prim[j]-1);
		}
	}
	phi[1]=1;
	for(int i=1;i<maxn;i++)
		phi[i]+=phi[i-1];
}
int pid(long long x){
	return x<maxn?x:maxn+n/x;
}
void get_phi(long long x){
	if(x<maxn) return;
	uint res=Sum(x);
	long long t;
	for(long long i=2;i<=x;i=t+1){
		t=x/(x/i);
		get_phi(x/i);
		res-=phi[pid(n/i)]*((uint)t-(uint)i+1);
	}
	phi[pid(n/i)]=res;
}

void csh(){
	ilem=0;
	uint *l_ans=prim_ans,r_ans=prim_ans+maxn;
	for(int i=1;i<=S;i++)
		l_ans[i]=Ans(i),r_sum[i]=Ans(n/i);
	long long ed1,ed2,ed;
	uint v_ans;
	for(int i=2;i<=S;i++){
		if(vis[i]) continue;
		prim[++ilem]=i;
		ed1=(n/S)/i,ed2=Min(S,n/(i*(long long)i)),ed=i*(long long)i;
		v_ans=l_sum[i-1];
		for(int j=1;j<=ed1;j++){
			const int p=j*i;
			r_ans[i]-=r_ans[p]-v_ans;
		}
		long long M=n/i;
		for(int j=ed1+1;j<=ed2;j++){
			const int p=M/j;
			r_ans[i]-=l_ans[p]-v_ans;
		}
		for(int j=S;j>=ed;j--){
			const int p=j/i;
			l_ans[i]-=l_ans[p]-v_ans;
		}
	}
	prim[++ilem]=S+1;
}
uint F(long long x,int y){
	if(prim[y]>x) return 0;
	uint res=G_sum(x,x)-G_sum(x,prim[y]-1);
	long long st;
	for(int i=y;i<=ilem;i++){
		st=prim[i];
		if(st*st>x) break;
		for(int j=1;;j++){
			if(st*prim[i]>x) break;
			res=res+F(x/st,i+1)*powd((uint)st,k)+powd(((uint)st*prim[i]),k)*(2*phi[x/(st*prim[i])]-1);
			st=st*prim[i];
		}
	}
	return res;
}
int main(){
	freopen("math.in","r",stdin);
	scanf("%lld%d",&n,&k);
	S=mysqrt(n);
	csh();
	uint ans=G_cnt(n,n)-G_cnt(n,1);

	long long st;
	uint ls=0;
	for(int i=1;i<=ilem;i++){
		st=prim[i];
		if(st*st>n) break;
		for(int j=1;;j++){
			if(st*prim[i]>n) break;
			ans=ans+F(n/st,i+1)*(powd((uint)(st/prim[i]),k))+(powd((uint)st,k))*(2*phi[n/(st*prim[i])]-1);
			ls+=(powd((uint)st,k))*(2*phi[n/(st*prim[i])]-1);
			st=st*prim[i];
		}
	}
	printf("%u\n",ans);
	return 0;
}
