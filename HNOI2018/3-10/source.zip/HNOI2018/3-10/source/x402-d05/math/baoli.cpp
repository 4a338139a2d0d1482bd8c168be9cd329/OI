#include<bits/stdc++.h>
using namespace std;
const int maxn=1001000;
#define uint unsigned int
long long n;
int k,S;
long long id(long long x){
	return x<=S?x:S+n/x;
}
bool vis[maxn];
int prim[maxn],ilem;
uint phi[maxn],d[maxn];
void csh(){
	for(int i=2;i<maxn;i++){
		if(!vis[i]){
			prim[++ilem]=i;
			phi[i]=i-1;
			d[i]=1;
		}
		for(int j=1;j<=ilem;j++){
			if(i*prim[j]>=maxn) break;
			vis[i*prim[j]]=1;
			d[i*prim[j]]=i;
			if(i%prim[j]==0){
				phi[i*prim[j]]=phi[i]*prim[j];
				break;
			}
			phi[i*prim[j]]=phi[i]*(prim[j]-1);
		}
	}
	phi[1]=1;
	for(int i=1;i<maxn;i++)
		phi[i]+=phi[i-1];
}
uint powd(uint x,int y){
	uint res=1;
	while(y){
		if(y&1) res=res*x;
		x=x*x;
		y>>=1;
	}
	return res;
}
int main(){
	freopen("math.in","r",stdin);
//	freopen("baoli.out","w",stdout);
	scanf("%lld%d",&n,&k);
	csh();
	uint ans=0,ls=0;
	for(int i=2;i<=n;i++){
		ans=ans+(phi[n/i]*2-1)*powd(d[i],k);
		if(i==4||i==8||i==16||i==9) ls+=(phi[n/i]*2-1)*powd(d[i],k);
	}
	printf("%u\n",ans);
	cerr<<ls<<endl;
	ans=0;
	for(int i=3;i<=9;i++){
		if(i%2==0) continue;
		ans=ans+(phi[9/i]*2-1)*powd(i,k);
	}
	cerr<<ans<<endl;
	return 0;
}
