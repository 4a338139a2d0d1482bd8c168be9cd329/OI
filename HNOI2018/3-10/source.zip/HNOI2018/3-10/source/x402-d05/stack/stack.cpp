#include<bits/stdc++.h>
using namespace std;
const long long md=1e9+7;
const int maxn=100100;
long long dp[22][1<<20],cnt[22][maxn];
int pop_sum[1<<20],pop_end[1<<20];
int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=0;i<(1<<n);i++){
		for(int j=0;j<n;j++)
			if(i&(1<<j))
			{
				pop_sum[i]+=j+1;
				pop_end[i]=1<<j;
			}
	}

	cnt[0][0]=1;
	for(int i=0;i<=n;i++){
		for(int j=(1<<i)-1;j>=0;j--){
			if(!cnt[i][j]) continue;
			if(j>0){
				(dp[i][j^pop_end[j]]+=dp[i][j])%=md;
				(cnt[i][j^pop_end[j]]+=cnt[i][j])%=md;
			}
			(dp[i+1][j^(1<<i)]+=dp[i][j]+pop_sum[j^(1<<i)]*cnt[i][j])%=md;
			(cnt[i+1][j^(1<<i)]+=cnt[i][j])%=md;
		}
	}
	printf("%lld\n",dp[n][0]);
	return 0;
}
