#include<bits/stdc++.h>
using namespace std;
const long long md=1e9+7;
const int maxn=100100;
int stk[maxn],top;
int n;
long long ans=0,sum;
bool vis[maxn];
void dfs(int p,long long val){
	if(p>n){
		ans+=val;
		return;
	}
	stk[++top]=p;
	sum+=p;
	vis[p]=1;
	if(vis[1]) cerr<<p<<" "<<1<<endl;
	dfs(p+1,val+sum);
	vis[p]=0;
	sum-=p;
	top--;
	if(top){
		int st=stk[top];
		sum-=stk[top];
		top--;
		vis[st]=0;
		dfs(p,val);
		vis[st]=1;
		stk[++top]=st;
		sum+=stk[top];
	}
}
int main(){
	freopen("stack.in","r",stdin);
//	freopen("baoli.out","w",stdout);
	scanf("%d",&n);
	dfs(1,0);
	printf("%lld\n",ans);
	return 0;
}
