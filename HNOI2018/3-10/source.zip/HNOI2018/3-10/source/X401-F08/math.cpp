#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m;
ll ans;
int gcd(int a,int b){if(!b)return a;return gcd(b,a%b);}
ll ksm(int x,int y){
	ll kk=1;
	while(y){
		if(y&1)kk*=x;
		x*=x;
		y/=2;
	}
	return kk%4294967296;
}
ll sgcd(int a,int b){
	int k=gcd(a,b);
	if(k==1)return 0;
	for(int i=2;i<=k;++i)if(!(k%i)){k/=i;break;};
	return ksm(k,m)%4294967296;
}
int main(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&n,&m);
	for(i=2;i<=n;++i)
		for(j=2;j<=n;++j)
			ans=(ans+sgcd(i,j))%4294967296;
	printf("%lld",ans);
	return 0;
}

