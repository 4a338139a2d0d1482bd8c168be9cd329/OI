#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=1e9+7;
int n,m,ans,a[5][5],fl;
void dfs(int x,int y){
	if (x==n+1){
		For(i,1,n){
			fl=0;
			For(j,1,m) if (a[i][j]) {fl=1; break;}
			if (!fl) return;
		}
		For(i,1,m){
			fl=0;
			For(j,1,n) if (a[j][i]) {fl=1; break;}
			if (!fl) return;
		}
		++ans; return ;
	}
	int xx=x,yy=y+1; if (yy==m+1) ++xx,yy=1;
	a[x][y]=1; dfs(xx,yy);
	a[x][y]=2; dfs(xx,yy);
	a[x][y]=0; dfs(xx,yy);
}
int main(){
	freopen("graph.in","r",stdin); freopen("graph.out","w",stdout);
	int _=read(),s;
	while(_--){
		n=read(),m=read(); if (n>m) swap(n,m);
		if (n==1){
			s=1; For(i,1,m) {s<<=1; if (s>=mo) s-=mo;} printf("%d\n",s); continue;
		}
		ans=0; dfs(1,1); printf("%d\n",ans);
	}
	return 0;
}
