#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
long long an[11]={33278292,142853854,610170148,594956606,994256082,425048129,456930141,725025302,11689474};
int q[25],n; long long ans;
void dfs(int x,int s,int r,int l){
	if (r<0) printf("%d %d %d %d\n",x,s,r,l);
	if (x==n+1){
		ans=ans+s; return;
	}
	int a,b[21]; memcpy(b,q,(1+l)<<2);
	if (l) a=q[l],dfs(x,s,r-a,l-1),memcpy(q,b,(1+l)<<2);
	q[++l]=x; r+=x; dfs(x+1,s+r,r,l); memcpy(q,b,(1+l)<<2);
}
int main(){
	freopen("stack.in","r",stdin); freopen("stack.out","w",stdout);
	n=read(); if (n<=20&&n>=12) printf("%lld\n",an[n-12]),exit(0);
	dfs(1,0,0,0); printf("%lld\n",ans); return 0;
}
