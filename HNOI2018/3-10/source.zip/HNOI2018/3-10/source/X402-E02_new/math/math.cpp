#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int gcd(int x,int y){
	return x==0?y:gcd(y%x,x);
}
unsigned int a[3005],b[3005],ans,y;
int main(){
	freopen("math.in","r",stdin); freopen("math.out","w",stdout);
	int n=read(),k=read(),x;
	For(i,1,n){
		a[i]=1;
		For(j,1,k) a[i]=a[i]*i;
	}
	For(i,2,n){
		For(j,2,i) if (i%j==0) {b[i]=j; break;}
		b[i]=i/b[i];
	}
	For(i,1,n)
		For(j,i,n){
			x=gcd(i,j);
			if (x>1){
				y=a[b[x]]; ans+=y; if (i!=j) ans+=y;
			}
		}
	printf("%u\n",ans);
	return 0;
}
