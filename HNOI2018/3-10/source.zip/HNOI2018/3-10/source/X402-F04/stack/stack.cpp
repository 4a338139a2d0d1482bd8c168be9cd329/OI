//2018-3-10
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N 21
const int P = 1e9 + 7;

inline int Mod(int a){
	if(a < 0) return a + P;
	return a >= P? a - P: a;
}
inline int Mul(int a, int b){
	return (long long)a * b % P;
}
inline void Get(int &a, int b){a = Mod(a + b);}

int n, ans, g[N][1 << N], f[N][1 << N], sum[1 << N], lst[1 << N];

int main() {
	freopen("stack.in", "r", stdin);
	freopen("stack.out", "w", stdout);

	scanf("%d", &n);
	For(s, 0, (1 << n) - 1){
		lst[s] = -1;
		For(i, 1, n)
			if(s & (1 << (i - 1))) lst[s] = i - 1, sum[s] += i;
	}

	f[1][0] = 1;
	For(i, 1, n){
		Forr(j, (1 << (i - 1)) - 1, 0){
			if(lst[j] != -1) {
				Get(f[i][j ^ (1 << lst[j])], f[i][j]);
				Get(g[i][j ^ (1 << lst[j])], g[i][j]);
			}
			
			Get(f[i + 1][j | (1 << (i - 1))], f[i][j]);
			Get(g[i + 1][j | (1 << (i - 1))], Mod(g[i][j] + Mul(sum[j] + i, f[i][j])));
		}
	}

	For(i, 0, (1 << n) - 1) Get(ans, g[n + 1][i]);
	printf("%d\n", ans);
	
	return 0;
}
