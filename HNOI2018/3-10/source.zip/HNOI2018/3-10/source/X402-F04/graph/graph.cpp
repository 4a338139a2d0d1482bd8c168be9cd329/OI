//2018-3-10
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

const int P = 1e9 + 7;

int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = 1ll * ret * a % P;
		a = 1ll * a * a % P; anum >>= 1;
	}
	return ret;
}

int main(){
	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);

	int T, n, m;
	scanf("%d", &T);

	while(T --){
		scanf("%d%d", &n, &m);
		if(n < m) swap(n, m);

		printf("%d\n", Pow(2, n));
	}

	return 0;
}
