//2018-3-10
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define UI unsigned int
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (10000000 + 5)

inline UI Pow(UI a, int anum){
	UI ret = 1;
	while(anum){
		if(anum & 1) ret *= a;
		a *= a; anum >>= 1;
	}
	return ret;
}

UI g[N], mu[N];
int pn, prime[N], vis[N];

void Init(int n, int m){
	mu[1] = 1;
	For(i, 2, n){
		if(!vis[i]){prime[++pn] = i, vis[i] = 1; mu[i] = -1;}

		For(j, 1, pn){
			if(1ll * i * prime[j] > 1ll * n) break;
			vis[i * prime[j]] = i; mu[i * prime[j]] = -mu[i];
			if(i % prime[j] == 0){mu[i * prime[j]] = 0; break;}
		}
	}

	For(i, 1, n) g[i] = Pow(vis[i], m), mu[i] += mu[i - 1];
}

UI Calc(int n){
	UI ret = 0;
	for(int p = 1, nt = 0; p <= n; p = nt + 1){
		nt = n / (n / p);
		ret += (mu[nt] - mu[p - 1]) * (UI)(n / p) * (UI)(n / p);
	}
	return ret;
}

void Solve(int n){
	int lst = 0;
	UI lv, ans = 0;

	For(d, 1, n){
		if(n / d != lst) lv = Calc(lst = n / d);
		ans += g[d] * lv;
	}
	printf("%u\n", ans);
}

map<int, UI> ms;

UI Mu(int n){
	if(n <= 1000000) return mu[n];
	if(ms.count(n)) return ms[n];
	
	UI ret = 1;
	for(int i = 2, nt = 0; i <= n; i = nt + 1){
		nt = n / (n / i);
		ret -= (UI)(nt - i + 1) * Mu(n / i);
	}
	return ms[n] = ret;
}

UI Cheat(int n){
	UI ret = 0;
	for(int d = 1, nt; d <= n; d = nt + 1){
		nt = n / (n / d);
		ret += (UI)(n / d) * (n / d) * (Mu(nt) - Mu(d - 1));
	}
	return ret;
}

int main(){
	freopen("math.in", "r", stdin);
	freopen("math.out", "w", stdout);
	
	int n, m;

	scanf("%d%d", &n, &m);
	if(m == 0){
		Init(1000000, 0);
		printf("%u\n", (UI)n * n - Cheat(n)); return 0;
	}

	Init(n, m); Solve(n);

	return 0;
}
