#include<bits/stdc++.h>
using namespace std;

typedef unsigned int ui;
const int MAXN = 5000010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

bool np[MAXN];
int mp[MAXN], p[MAXN], cnt;
ui f[MAXN], phi[MAXN], Phi[MAXN];
ui ans;

inline ui qpow(ui a, int b) {
	if(a == 0 && b == 0) return 0;
	ui res = 1;
	while(b) {
		if(b & 1LL) res = res * a;
		b >>= 1, a = a * a;
	}
	return res;
}

inline void getprime() {
	int i, j;
	f[1] = 0;
	phi[1] = 1;
	for(i = 2; i <= 5000000; i++) {
		if(!np[i]) p[++cnt] = i, f[i] = 1, phi[i] = i-1;
		for(j = 1; j <= cnt && p[j] * i <= 5000000; j++) {
			np[p[j]*i] = true;
			f[p[j]*i] = i;
			if(i % p[j]) phi[i*p[j]] = phi[i]*phi[p[j]];
			else {
				phi[i*p[j]] = phi[i]*p[j];
				break;
			}
		}
	}
	for(i = 1; i <= 5000000; i++) Phi[i] = Phi[i-1]+phi[i];
}

inline ui PHI(int n) {
	if(n <= 5000000) return Phi[n];
	long long sum = (((long long)(1+n))*n)>>1;
	ui res = (ui)(sum&((1LL<<32)-1));
	int i, j;
	for(i = 2; i <= n; i = j+1) {
		j = n/(n/i);
		res -= PHI(n/i)*(j-i+1);
	}
	return res;
}

int n, K;

int main() {
	freopen("math.in", "r", stdin);
	freopen("math.out", "w", stdout);

	int i, j;
	n = read(), K = read();
	getprime();
	if(K == 0) {
		for(i = 2; i <= n; i = j+1) {
			j = n/(n/i);
			ans += (PHI(n/i)-1)*(j-i+1);
		}
		ans <<= 1;
		printf("%u\n", ans+n-1);
		return 0;
	}
	for(i = 1; i <= n; i++) {
		f[i] = qpow(f[i], K);
		ans += f[i];
	}
	for(i = 1; i <= n; i++)
		for(j = 2; j * i <= n; j++)
			ans += ((f[i]*phi[j])<<1);
	printf("%u\n", ans);
	return 0;
}
