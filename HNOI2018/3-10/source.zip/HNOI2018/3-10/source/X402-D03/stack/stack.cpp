#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 25;
const ll MOD = 1000000007;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n;
ll dp[MAXN][1<<20], ans, f[MAXN][1<<20];
int sum[1<<20], mx[1<<20];

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int main() {
	freopen("stack.in", "r", stdin);
	freopen("stack.out", "w", stdout);

	int s, i;
	n = read();
	for(s = 0; s < (1<<n); s++) {
		mx[s] = -1;
		for(i = 1; i <= n; i++)
			if((s>>(i-1))&1) mx[s] = i, sum[s] += i;
	}
	f[1][0] = 1;
	for(i = 1; i <= n; i++) {
		for(s = (1<<(i-1))-1; s >= 0; s--) {
			if(mx[s] != -1) {
				update(dp[i][s^(1<<(mx[s]-1))], dp[i][s]);
				update(f[i][s^(1<<(mx[s]-1))], f[i][s]);
				//printf("%d %d -> %d %d\n", i, s, i, s^(1<<(mx[s]-1)));
			}
			update(dp[i+1][s|(1<<(i-1))], (dp[i][s]+(sum[s]+i)*f[i][s]%MOD)%MOD);
			update(f[i+1][s|(1<<(i-1))], f[i][s]);
			//printf("%d %d -> %d %d\n", i, s, i+1, s|(1<<(i-1)));
		}
		/*for(s = 0; s < (1<<(i-1)); s++) 
			printf("%lld ", dp[i][s]);
		printf("\n");*/
	}
	/*for(s = 0; s < (1<<n); s++) printf("%lld ", dp[n+1][s]);
	printf("\n");*/
	for(s = 0; s < (1<<n); s++) update(ans, dp[n+1][s]);
	printf("%lld\n", ans);
	return 0;
}
