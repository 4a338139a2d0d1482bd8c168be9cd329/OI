#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 1000000007;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int n, m;

int main() {
	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);

	int T = read();
	while(T--) {
		n = read(), m = read();
		if(n == 1) printf("%lld\n", qpow(2, m));
		else printf("%lld\n", qpow(2, n));
	}
	return 0;
}
