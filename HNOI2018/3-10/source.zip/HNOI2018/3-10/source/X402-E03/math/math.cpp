#include <bits/stdc++.h>
#include <tr1/unordered_map>
#define unt unsigned int
using namespace std ;
void Read ( unt &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const unt maxn = 1e6 ;
unt n, m, k, pr[maxn+5] ;
bool isp[maxn+5] ;
unt F[maxn+5] ;
unt mu[maxn+5] ;
unt Qpow ( unt a, unt b, unt rec = 1 ) {
	if (!a) return 0 ;
	for ( ; b ; b >>= 1, a *= a )
		if (b&1) rec *= a ;
	return rec ;
}
void init() {
	unt i, j ;
	memset (isp, 1, sizeof isp) ;
	isp[1] = F[1] = 0 ;
	mu[1] = 1 ;
	for ( i = 2 ; i <= maxn ; i ++ ) {
		if (isp[i]) {
			pr[++m] = i ;
			F[i] = 1 ;
			mu[i] = -1 ;
		}
		for ( j = 1 ; j <= m && i*pr[j] <= maxn ; j ++ ) {
			isp[i*pr[j]] = 0 ;
			if (i%pr[j]) mu[i*pr[j]] = -mu[i] ;
			else {
				mu[i*pr[j]] = 0 ;
				break ;
			}
		}
		for ( j = 2 ; i*j <= maxn ; j ++ )
			if (!F[i*j]) F[i*j] = j ;
	}
	for ( i = 1 ; i <= maxn ; i ++ ) {
		F[i] = Qpow(F[i], k)+F[i-1] ;
		mu[i] += mu[i-1] ;
	}
}
void solve1() {
	unt i, j, t, ans = 0 ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= n ; j ++ ) {
			t = __gcd(i, j) ;
			ans += F[t]-F[t-1] ;
		}
	cout << ans << endl ;
}
tr1::unordered_map <unt, unt> SMU ;
unt Smu ( unt x ) {
	if (x <= maxn) return mu[x] ;
	if (SMU.count(x)) return SMU[x] ;
	unt rec = 1, i, r ;
	for ( i = 2 ; i <= x ; ) {
		r = x/(x/i) ;
		rec -= Smu(x/i)*(r-i+1) ;
		i = r+1 ;
	}
	return SMU[x] = rec ;
}
unt calc ( unt x ) {
	unt i, r, rec = 0 ;
	for ( i = 1 ; i <= x ; ) {
		r = x/(x/i) ;
		rec += (Smu(r)-Smu(i-1))*(x/i)*(x/i) ;
		i = r+1 ;
	}
	return rec ;
}
void solve2() {
	unt i, r, rec = 0 ;
	for ( i = 1 ; i <= n ; ) {
		r = n/(n/i) ;
		rec += (F[r]-F[i-1])*calc(n/i) ;
		i = r+1 ;
	}
	printf ( "%u\n", rec ) ;
}
void solve4() {
	printf ( "%u\n", n*n-calc(n) ) ;
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "math.in", "r", stdin ) ;
	freopen ( "math.out", "w", stdout ) ;
#endif
	Read(n), Read(k) ;
	init() ;
	if (k == 0) solve4() ;
	else if (n <= 900) solve1() ;
	else solve2() ;
	return 0 ;
}
