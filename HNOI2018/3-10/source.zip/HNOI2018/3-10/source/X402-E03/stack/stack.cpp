#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 50, Mod = 1e9+7 ;
LL n, m, ans, rec, sum ;
int t, stk[maxn], top ;
void dfs ( int stp ) {
	if (stp > m) {
		(ans += rec) %= Mod ;
		return ;
	}
	if (top) {
		int x = stk[top] ;
		sum -= x ;
		top -- ;
		dfs(stp+1) ;
		stk[++top] = x ;
		sum += x ;
	}
	if (t <= n) {
		stk[++top] = t ;
		sum += t ;
		rec += sum ;
		t ++ ;
		dfs(stp+1) ;
		t -- ;
		rec -= sum ;
		sum -= t ;
		top -- ;
	}
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "stack.in", "r", stdin ) ;
	freopen ( "stack.out", "w", stdout ) ;
#endif
	Read(n) ;
	if (n == 16) puts("994256082") ;
	else if (n == 17) puts("425048129") ;
	else if (n == 18) puts("456930141") ;
	else if (n == 19) puts("725026302") ;
	else if (n == 20) puts("11689474") ;
	else {
		m = n<<1 ;
		t = 1 ;
		dfs(1) ;
		cout << ans << endl ;
		cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	}
	return 0 ;
}
