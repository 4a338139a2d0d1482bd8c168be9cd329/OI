#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL Mod = 1e9+7 ;
LL Qpow ( LL a, LL b, LL rec = 1 ) {
	for ( ; b ; b >>= 1, (a *= a) %= Mod )
		if (b&1) (rec *= a) %= Mod ;
	return rec ;
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "graph.in", "r", stdin ) ;
	freopen ( "graph.out", "w", stdout ) ;
#endif
	LL a, b,  _ ;
	Read(_) ;
	while (_--) {
		Read(a), Read(b) ;
		cout << Qpow(2, a+b-1) << endl ;
	}
	return 0 ;
}
