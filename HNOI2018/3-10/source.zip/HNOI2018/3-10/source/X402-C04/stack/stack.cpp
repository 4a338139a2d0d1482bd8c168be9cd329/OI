#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=5e8+9;
const int md=1e9+7;
int n,a[100],stk[100];

namespace dp
{
	const int K=(1<<20)+9;
	ll f[43][K],g[43][K],k;
	int tops[K],vals[K];

	inline int val(int state)
	{
		if(~vals[state])return vals[state];
		int ret=0;
		for(int i=0;i<n;i++)
			if((state>>i)&1)
				ret+=i+1;
		return vals[state]=ret;
	}

	inline int top(int state)
	{
		if(~tops[state])return tops[state];
		for(int i=n-1;~i;i--)
			if((state>>i)&1)
				return tops[state]=i+1;
		return 0;
	}

	#define pop(x) __builtin_popcount(x) 

	inline void init()
	{
		memset(tops,-1,sizeof(tops));
		memset(vals,-1,sizeof(vals));
	}
		
	int mina()
	{
		memset(f,0,sizeof(f));
		memset(g,0,sizeof(g));

		k=1<<n;

		g[0][0]=1;
		for(int i=0;i<2*n;i++)
			for(int j=0;j<k;j++)
				if(g[i][j])
				{
					int cnt=pop(j),nxt=(i-cnt)/2+cnt+1;
					if(nxt<=n)
						(g[i+1][j|(1<<(nxt-1))]+=g[i][j])%=md;
					if(j)
						(g[i+1][j^(1<<(top(j)-1))]+=g[i][j])%=md;
				}

		f[1][1]=1;
		for(int i=1;i<2*n;i++)
			for(int j=0;j<k;j++)
				if(f[i][j])
				{
					int cnt=pop(j),nxt=(i-cnt)/2+cnt+1;
					if(nxt<=n)
						(f[i+1][j|(1<<(nxt-1))]+=f[i][j]+g[i][j]*val(j|(1<<(nxt-1)))%md)%=md;
					if(j)
						(f[i+1][j^(1<<(top(j)-1))]+=f[i][j])%=md;
				}
		printf("%lld\n",f[n*2][0]);
	}
}

int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);

	dp::init();
	scanf("%d",&n);
	dp::mina();
	return 0;
}
