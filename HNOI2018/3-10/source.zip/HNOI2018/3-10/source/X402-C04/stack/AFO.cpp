#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=5e8+9;
const int md=1e9+7;
int n,a[100],stk[100];

namespace dp
{
}

int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);

	scanf("%d",&n);


	return 0;
}
