#include<bits/stdc++.h>
using namespace std;

typedef unsigned int uint;
int n,k;

inline int gcd(int a,int b){return b?gcd(b,a%b):a;}

inline uint qpow(uint a,uint b)
{
	uint ret=1;
	while(b)
	{
		if(b&1)ret=ret*a;
		a=a*a;b>>=1;
	}
	return ret;
}

namespace trys
{
	const int N=1e6+9;
	uint mu[N],f[N],pri[N>>1],ptop;
	map<int,uint> smu;
	bool npri[N];

	inline void init()
	{
		mu[1]=1;f[1]=0;
		for(int i=2;i<N;i++)
		{
			if(!npri[i])
			{
				pri[++ptop]=i;
				f[i]=1;
				mu[i]=-1;
			}
			for(int j=1;j<=ptop && i*pri[j]<N;j++)
			{
				npri[i*pri[j]]=1;
				if(i%pri[j])
					mu[i*pri[j]]=-mu[i];
				else
				{
					mu[i*pri[j]]=0;
					break;
				}
			}
			for(int j=2;i*j<N;j++)
				if(!f[i*j])
					f[i*j]=j;
			mu[i]+=mu[i-1];
		}
		for(int i=1;i<N;i++)
			f[i]=qpow(f[i],k)+f[i-1];
	}

	inline uint cmu(int n)
	{
		if(n<5)return mu[n];
		if(smu.count(n))return smu[n];
		uint ret=1;
		for(int i=2,j;i<=n;i=j+1)
		{
			j=n/(n/i);
			ret-=(j-i+1)*cmu(n/i);
		}
		return smu[n]=ret;
	}

	inline uint calc(int n)
	{
		uint ret=0;
		for(int i=1,j;i<=n;i=j+1)
		{
			j=n/(n/i);
			ret+=(cmu(j)-cmu(i-1))*(n/i)*(n/i);
		}
		return ret;
	}

	inline uint calc2(int n)
	{
		uint ret=0;
		for(int i=1,j;i<=n;i=j+1)
		{
			j=n/(n/i);
			ret+=(f[j]-f[i-1])*calc(n/i);
		}
		return ret;
	}

	int mina1()
	{
		printf("%u\n",calc2(n));
		return 0;
	}


	inline int k0()
	{
		printf("%u\n",(uint)n*(uint)n-calc(n));
		return 0;
	}
	
	int bf()
	{
		uint ans=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				ans+=f[gcd(i,j)]-f[gcd(i,j)-1];
		printf("%u\n",ans);
		return 0;
	}
}

int main()
{
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);

	scanf("%d%d",&n,&k);
	trys::init();
	if(k==0)
		trys::k0();
	else if(n<=900)
		trys::bf();
	else
		trys::mina1();

	return 0;
}
