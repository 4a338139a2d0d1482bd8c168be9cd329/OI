#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
#define x first
#define y second
const int N=9;

int n,m,ans;
int g[N][N];
int dx[]={0,1,0,-1};
int dy[]={1,0,-1,0};
bool vis[N][N];

inline bool in(int x,int y)
{
	return 1<=x && x<=n && 1<=y && y<=m;
}

inline bool judge()
{
	static queue<pr> q;
	while(!q.empty())q.pop();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			if(g[i][j]>0)
				q.push(pr(i,j));
			vis[i][j]=(g[i][j]>0);
		}

	while(!q.empty())
	{
		pr u=q.front();q.pop();
		for(int i=0;i<=3;i++)
		{
			int tx=u.x+dx[i],ty=u.y+dy[i];
			if(in(tx,ty) && !vis[tx][ty])
			{
				for(int j=0;j<=3;j++)
					if(j!=i && (j+2)%4!=i)
					{
						int ttx=tx+dx[j],tty=ty+dy[j];
						if(in(ttx,tty) && vis[ttx][tty])
						{
							vis[tx][ty]=1;
							q.push(pr(tx,ty));
							goto nxt;
						}
					}
			}
			nxt:;
		}
	}

	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(!vis[i][j])
				return 0;
	return 1;
}

inline int calc()
{
	int ret=1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(g[i][j])
				ret<<=1;
	return ret;
}

inline void dfs(int x,int y)
{
	if(x==n+1)
	{
		if(judge())
			ans+=calc();
		return;
	}

	int nxtx=x,nxty=y+1;
	if(y==m)nxtx=x+1,nxty=1;

	for(int i=0;i<=1;i++)
	{
		g[x][y]=i;
		dfs(nxtx,nxty);
	}
}

inline int mina()
{
	scanf("%d%d",&n,&m);
	ans=0;
	if(n==1 && m==1)
		puts("2");
	else
		dfs(1,1);
	printf("%d\n",ans);
	return 0;
}

int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);

	int T;
	scanf("%d",&T);
	while(T--)
		mina();

	return 0;
}
