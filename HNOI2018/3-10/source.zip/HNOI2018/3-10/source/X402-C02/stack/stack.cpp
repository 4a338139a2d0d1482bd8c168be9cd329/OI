#include<bits/stdc++.h>
#define ll long long
const int MAXN=1000+10,Mod=1e9+7;
int n,stack[MAXN];
ll ans;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline void dfs(int x,int top,ll s=0)
{
	if(x>n&&top==0)
	{
		(ans+=s)%=Mod;
		return ;
	}
	if(top)
	{
		int las=stack[top-1];
		dfs(x,top-1,s);
		stack[top-1]=las;
	}
	if(x<=n)
	{
		for(register int i=0;i<top;++i)(s+=stack[i])%=Mod;
		stack[top]=x;
		(s+=x)%=Mod;
		dfs(x+1,top+1,s);
	}
}
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	read(n);
	dfs(1,0);
	write(ans,'\n');
	return 0;
}
