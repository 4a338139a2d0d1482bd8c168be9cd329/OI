#include<bits/stdc++.h>
#define ll long long
const ll Mod=2147483648,MAXN=1000000+10;
int n,k,prime[MAXN],cnt,vis[MAXN],f[MAXN],s[MAXN],mu[MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
inline int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
inline void init()
{
	memset(vis,1,sizeof(vis));
	vis[0]=vis[1]=0;
	mu[1]=1;
	for(register int i=2;i<MAXN;++i)
	{
		if(vis[i])
		{
			prime[++cnt]=i;
			mu[i]=-1;
		}
		for(register int j=1;j<=cnt&&i*prime[j]<MAXN;++j)
		{
			vis[i*prime[j]]=0;
			if(i%prime[j])mu[i*prime[j]]=-mu[i];
			else break;
		}
	}
	s[1]=mu[1];
	for(register int i=2;i<MAXN;++i)
	{
		s[i]=s[i-1]+mu[i];
		for(register int j=i;j<MAXN;j+=i)
			if(!f[j])f[j]=i;
	}
}
inline void bf()
{
	ll ans=0;
	for(register int i=1;i<=n;++i)
		for(register int j=1;j<=n;++j)
		{
			int d=gcd(i,j),t=d;
			if(d==1)continue;
			for(register int p=2;p<=d;++p)
				if(d%p==0)
				{
					t=p;
					break;
				}
			(ans+=qexp((ll)d/t,(ll)k))%=Mod;
		}
	write(ans,'\n');
}
std::map<ll,ll> M;
inline ll calc(ll x)
{
	if(x<MAXN)return s[x]; 
	if(M.count(x))return M[x];
	ll res=1;
	for(register int i=2;;)
	{
		if(i>x)break;
		int j=x/(x/i);
		((res-=(ll)calc(x/i)*(j-i+1)%Mod)+=Mod)%=Mod;
		i=j+1;
	}
	return M[x]=res;
}
inline void sub1()
{	
	ll res=0;
	for(register int i=2;;)
	{
		if(i>n)break;
		int j=n/(n/i);
		ll tmp=0,m=(n/i);
		for(register int p=1;;)
		{
			if(p>m)break;
			int q=m/(m/p);
			(tmp+=(ll)(calc(q)-calc(p-1))*(ll)(m/p)%Mod*(ll)(m/p)%Mod)%=Mod;
			p=q+1;
		}
		(res+=tmp*(ll)(j-i+1))%=Mod;
		i=j+1;
	}
	write(res,'\n');
}
int main()
{
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	read(n);read(k);
	init();
	if(n<=900)bf();
	else if(k==0)sub1();
	else puts("nan");
	return 0;
}
