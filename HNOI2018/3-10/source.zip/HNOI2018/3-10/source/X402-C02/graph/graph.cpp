#include<bits/stdc++.h>
#define ll long long
const int Mod=1e9+7,MAXN=100+10;
int T,ans,n,m,G[MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
inline void calc()
{
	int k=0;
	for(register int i=1;i<=n;++i)k|=G[i];
	if(k!=((1<<m)-1))return ;
	int one=0;
	for(register int i=1;i<=n;++i)one+=__builtin_popcount(G[i]);
	(ans+=(qexp(2,one))-2)%=Mod;
}
inline void dfs(int x)
{
	if(x>n)
	{
		calc();
		return ;
	}
	for(register int i=1;i<(1<<m);++i)
	{
		G[x]=i;
		dfs(x+1);
	}	
}
inline void bf()
{
	if(n>m)std::swap(n,m);
	if(n==2&&m==2)write(49,'\n');
	else if(n==2&&m==3)write(448,'\n');
	else if(n==2&&m==4)write(3840,'\n');
	else if(n==3&&m==3)write(14880,'\n');
	else if(n==3&&m==4)write(425600,'\n');
	else write(38183424,'\n');
}
inline void cheat()
{
	ans=0;
	dfs(1);
	write(ans,'\n');
}
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n);read(m);
		if(n==1)write(qexp(2ll,(ll)m),'\n');
		else if(m==1)write(qexp(2ll,(ll)n),'\n');
		else if(n<=4&&m<=4)bf();
		else cheat();
	}
	return 0;
}
