#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
const int maxn=100+10;
const ll mod=1e9+7;
int T,n,m;
ll qpow(int a,int b){
	ll base=a,r=1;
	while(b){
		if(b&1)r=r*base%mod;
		base=base*base%mod;
		b/=2;
	}
	return r;
}
int main(){
	File();
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m);
		if(n==1)swap(n,m);
		cout<<qpow(2,n)<<endl;
	}
	return 0;
}
