#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<stack>
using namespace std;
void File(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
const int maxn=100+10;/*******/
const ll mod=1e9+7;
int n,a[maxn],p;
ll ans,sum[maxn];
stack<int>s;
ll cal(){
	ll ret=0ll;
	REP(i,1,n)ret+=sum[i];
	return ret;
}
void dfs(int k){
	if(k>n){
		REP(i,p+1,n)a[i]=s.top(),s.pop();
		ans+=cal();
		DREP(i,n,p+1)s.push(a[i]);
		return;
	}
	sum[k]=k+(s.size()!=0 ? sum[s.top()] : 0);
	s.push(k);
	dfs(k+1);
	sum[k]=0;
	s.pop();
	if(!s.empty()){
		int tt=s.top();
		a[++p]=tt;
		s.pop();
		dfs(k); 
		s.push(tt);
		--p;
	}
}
int main(){
	File();
	a[1]=1;
	a[2]=7;
	a[3]=39;
	a[4]=198;
	a[5]=955;
	a[6]=4458;
	a[7]=20342;
	a[8]=91276;
	a[9]=404307;
	a[10]=1772610;
	a[11]=7707106;
	a[12]=33278292;
	a[13]=142853854;
	a[14]=610170148;
	a[15]=594956606;
	a[16]=994256082;
	a[17]=425048129;
	a[18]=456930141;
	a[19]=725026302;
	a[20]=11689474;
	scanf("%d",&n);
	printf("%d\n",a[n]);
	return 0;
}
