#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<map>
using namespace std;
void File(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ui unsigned int
const int maxn=1e7+10;
ui ans;
int n,k;
int gcd(int x,int y){return x%y==0 ? y : gcd(y,x%y);}
int find(int x){
	if(x==1)return 0;
	REP(i,2,x)if(x%i==0)return x/i;
}
ui POW(int a,int b){
	ui ret=a;
	REP(i,2,b)
		ret*=a;
}
int main(){
	File();
	scanf("%d%d",&n,&k);
	REP(i,1,n)REP(j,1,n)
		ans=ans+POW(find(gcd(i,j)),k);
	cout<<ans<<endl;
	return 0;
}
