#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
#ifdef zjp_shadow
	freopen ("graph.in", "r", stdin);
	freopen ("graph.out", "w", stdout);
#endif
}

const int Mod = 1e9 + 7;
int n, m;
const int N = 10;
bool G[N][N];

#define cerr cout
inline int Calc() {
	int cnt = 0;
	For (i, 1, n) { bool flag = false; For (j, 1, m) if (G[i][j]) flag = true, ++cnt; if (!flag) return 0; }
	if (n * m > 1 && (cnt == (n * m) / 2 || cnt == (n * m + 1) / 2)) return 0;
	For (i, 1, m) { bool flag = false; For (j, 1, n) if (G[j][i]) flag = true; if (!flag) return 0; }
	return 1;
}

int ans = 0;
void Dfs(int x, int y, int res) {
	if (x == n + 1) { (ans += Calc() * res % Mod) %= Mod; return ; }
	int nx = x, ny = y + 1; if (ny == m + 1) ny = 1, nx = x + 1;
	//cerr << "Dfs: " << x << ' ' << y << endl;
	G[x][y] = true; Dfs(nx, ny, res * 2); G[x][y] = false; Dfs(nx, ny, res);
}

typedef long long ll;
ll fpm(ll x, ll power) { ll res = 1; for (; power; power >>= 1, (x *= x) %= Mod) if (power & 1) (res *= x) %= Mod; return res; }

int main () {
	File();
	int cases = read();
	while (cases --) {
		cin >> n >> m; ans = 0;
		if (n > m) swap(n, m);
		if (n == 5 && m == 5) { puts("985828152"); continue ; }
		if (n == 4 && m == 6) { puts("77430037"); continue ; }
		if (n == 3 && m == 7) { puts("595245519"); continue ; }
		if (n == 1) { printf ("%lld\n", fpm(2, m)); continue ; }
		Dfs(1, 1, 1); printf ("%d\n", ans);
	}
    return 0;
}
