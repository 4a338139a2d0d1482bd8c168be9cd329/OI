#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int Mod = 1e9 + 7;

int ans[110];
int A[6][6];
int n, m;

bool check() {
	while (true) {
		bool flag = true;
		For(i, 1, n - 1) For(j, 1, m - 1) {
			int c = A[i][j] + A[i][j + 1] + A[i + 1][j] + A[i + 1][j + 1];
			if (c == 3) {
				A[i][j] = A[i][j + 1] = A[i + 1][j] = A[i + 1][j + 1] = 1;
				flag = false;
			}
		}
		if (flag) break;
	}
	For(i, 1, n) For(j, 1, m) if (!A[i][j]) return false;
	return true;
}

int main() {

	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);

	int Case;
	scanf("%d", &Case);

	ans[0] = 1;
	For(i, 1, 100) ans[i] = ans[i - 1] * 2 % Mod;

	while (Case--) {
		scanf("%d%d", &n, &m);
		if (n == 1 || m == 1) printf("%d\n", n == 1 ? ans[m] : ans[n]);
		else {
			int c = n * m, sum = 0;
			For(i, 0, (1 << c) - 1) {
				memset(A, 0, sizeof A);

				int cnt = 0;
				For(j, 0, c - 1) if (i & (1 << j)) {
					A[j / m + 1][j % m + 1] = 1;
					++cnt;
				}
				if (check()) sum = (sum + ans[cnt]) % Mod;
			}
			printf("%d\n", sum);
		}
	}

	return 0;
}
