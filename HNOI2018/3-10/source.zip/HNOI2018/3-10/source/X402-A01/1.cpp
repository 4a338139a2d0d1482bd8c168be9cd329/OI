#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
long long f[1000010],a[1000010],flag=0,n,sum=0,v[100010];
long long js(){
	long long top=1,i=1,d=2,b=1,ans=0;
	sum=0;
	//for(i=1;i<=n;i++)printf("%d ",f[i]);
//	puts("");
	i=1;
	while(i<=n){
		//printf("------%lld\n",f[i]);
		if(d!=2)return 0;
		d=0;
		while(a[top-1]!=f[i] && b<=n){
			a[top]=b;
			sum+=b;
			ans+=sum;
			top++;
			b++;
		}
		while(a[top-1]==f[i] && top>1){
			sum-=a[top-1];
			top--;
			i++;
			d=2;
		}
		//printf("%d %d %d %d %d %d\n",b,i,ans,top,a[top-1],f[i]);
		if(b>n+1)return 0;
	}
	//printf("^^^^^%lld\n",ans);
	return ans;
}			
void dfs(long long x){
	if(x==n+1){
		flag+=js();
		return;
	}
	for(long long i=1;i<=n;i++)
	    if(!v[i]){
	    	v[i]=1;
	    	f[x]=i;
	    	dfs(x+1);
	    	v[i]=0;
	    }
}
int main(){
	long long i,j,k,m;
	scanf("%lld",&n);
	dfs(1);
	printf("%lld\n",flag);
	return 0;
}

