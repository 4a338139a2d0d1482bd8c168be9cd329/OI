#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
long long mod,k;
long long lily(long long a,long long b){
	long long ans=1;
	while(b>0){
		if(b%2){ans=(ans*a)%mod;}
		a=(a*a)%mod;
		b/=2;
	}
	return ans;
}
long long gcd(long long x,long long y){
	if(y==0)return x;
	return gcd(y,x%y);
}
long long js(long long x,long long y){
    long long e=gcd(x,y);
    if(e==1)return 0;
    for(long long i=2;i*i<=e;i++)
        if(e%i==0)return lily(e/i,k);
    return 1;
}
int main(){
	long long i,j,m,n,ans=0;
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	mod=(1<<30);
	mod*=4;
    scanf("%lld%lld",&n,&k);
	for(i=1;i<=n;i++){
	    for(j=i;j<=n;j++){
	    	long long h=js(i,j);
	        ans+=h;
	        if(i!=j)ans+=h;
	        ans%=mod;
	    }
	}
    printf("%lld\n",ans); 
	return 0;
}

