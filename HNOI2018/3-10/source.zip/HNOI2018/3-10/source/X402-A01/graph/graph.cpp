#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
long long mod=10e9+7; 
long long lily(long long x,long long y){
	long long ans=1;
	while(y>0){
		if(y%2){ans=(ans*x)%mod;}
		x*=x;
		x%=mod;
		y/=2;
	}
	return ans;
}
int main(){
	long long i,j,k,m,n,t;
	freopen("gragh.in","r",stdin);
	freopen("graph.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		scanf("%lld%lld",&n,&m);
		if(n==1)printf("%lld\n",lily(2,m)%mod);
		else printf("%lld\n",lily(2,n)%mod);
	}
	return 0;
}

