/**********************************************************
	File:graph.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-3-10 09:07:23
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 110
#define mod 1000000007
int T,n,m,h[N],l[N],s,ans;
long long power(long long x,long long y,long long m)
{
	long long r=1;
	while(y)
	{
		if(y&1)r=r*x%m;
		x=x*x%m;
		y>>=1;
	}
	return r;
}
void dfs(int x,int y)
{
//	printf("%d %d %d\n",x,y,s);
	if(x==n+1)
	{
//		fr(i,1,n)printf("%d ",h[i]);
//		putchar(' ');
//		fr(i,1,m)printf("%d%c",l[i],i==m?'\n':' ');
		fr(i,1,n)if(!h[i])return;
		fr(i,1,m)if(!l[i])return;
//		printf("%d\n",s);
		ans=(ans+power(2,s,mod))%mod;
		return;
	}
	h[x]++;
	l[y]++;
	s++;
	dfs(x+(y==m),y==m?1:y+1);
	h[x]--;
	s--;
	l[y]--;
	dfs(x+(y==m),y==m?1:y+1);
}
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();
		m=read();
		if(n>m){int k=n;n=m;m=k;}
		if(n==1)
		{
			printf("%lld\n",power(2,m,mod));
			continue;
		}
		ans=0;
		dfs(1,1);
		printf("%d\n",ans);
	}
	return 0;
}