/**********************************************************
	File:math.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-3-10 09:37:15
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
int n,k;
namespace main1
{
	int gcd(int x,int y)
	{
		return y?gcd(y,x%y):x;
	}
	long long power(long long x,long long y)
	{
		long long r=1;
		while(y)
		{
			if(y&1)r=r*x;
			x=x*x;
			y>>=1;
		}
		return r;
	}
	#define N 920
	int f[N],ans;
	int main()
	{
		fr(i,2,n)
		{
			int t=2;
			while(i%t)t++;
			f[i]=power(i/t,k);
		}
		fr(i,1,n)
			fr(j,1,n)
				ans+=f[gcd(i,j)];
		printf("%u\n",(unsigned int)ans);
		return 0;
	}
}
namespace main2
{
	#define M 1000000
	int phi[M+10],c[M+10],z[M+10],m,sphi[M+10],phis[M+10];
	int calc(int x,int k)
	{
		if(x<=M)return sphi[x];
		if(phis[k])return phis[k];
		int re;
		if(x&1)re=(x+1)/2*x;
		else re=x/2*(x+1);
		int l=1;
		while(l<=x)
		{
			int r=x/(x/l);
			re-=(r-l+1)*calc(x/l,k*l);
		}
		return re;
	}
	int main()
	{
		phi[1]=c[1]=1;
		fr(i,2,M)
		{
			if(!c[i])
			{
				phi[i]=i-1;
				z[++m]=i;
			}
			fr(j,1,m)
				if(i*z[j]>M)break;
				else if(i%z[j])
				{
					c[i*z[j]]=1;
					phi[i*z[j]]=phi[i]*(z[j]-1);
				}
				else
				{
					c[i*z[j]]=1;
					phi[i*z[j]]=phi[i]*z[j];
					break;
				}
		}
		fr(i,1,M)sphi[i]=sphi[i-1]+phi[i];
		printf("%u\n",(unsigned int)(n*n-calc(n,1)*2+1));
		return 0;
	}
}
int main()
{
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	n=read();
	k=read();
	if(n<=900)return main1::main();
	if(k==0)return main2::main();
	while(1);
	return 0;
}