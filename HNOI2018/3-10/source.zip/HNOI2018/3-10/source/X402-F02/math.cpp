#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/hash_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
typedef long long sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("math.in","r",stdin);
      freopen("math.out","w",stdout );
  #endif
}
ll n,k;
void input()
{
	n=read<ll>();k=read<ll>();
}
typedef unsigned int ui;
const int maxn=1e6;
namespace sub1
{
	int l[maxn+5],book[maxn+5],s[maxn+5];
	void init()
	{
		For(i,2,n)
		{
			if(!book[i])l[++l[0]]=i;
			for(register int j=1;j<=l[0]&&i*l[j]<=n;++j)
			{
				book[i*l[j]]=1;
				s[i*l[j]]=i;
				if(i%l[j]==0)break;
			}
		}
		For(i,1,l[0])s[l[i]]=1;
	}
	ui ans;
	ui power(ui x,int y)
	{
		if(x==0)return 0;
		ui res=1;
		for(;y;x=x*x,y>>=1)if(y&1)res=res*x;
		return res;
	}
	void solve()
	{
		init();
		For(i,1,n)For(j,1,n)
		{
			ans+=power(s[__gcd(i,j)],k);
		}
		write(ans,'\n');
	}
}
namespace sub2
{
	int l[maxn+5],book[maxn+5],mu[maxn+5];
	void init()
	{
		mu[1]=1;
		For(i,2,maxn)
		{
			if(!book[i])l[++l[0]]=i,mu[i]=-1;
			for(register int j=1;j<=l[0]&&i*l[j]<=maxn;++j)
			{
				book[i*l[j]]=1;
				if(i%l[j]==0)break;
				mu[i*l[j]]=-mu[i];
			}
			//cout<<i<<' '<<mu[i]<<endl;
			mu[i]+=mu[i-1];
		}
	}
	cc_hash_table<ll,int>vis,Mu;
	#define gp(x) (x>maxn?Mu[x]:mu[x]) 
	void F(ll x)
	{
		if(x<=maxn)return;
		if(vis[x])return;
		ll last;ui res=1;
		For(i,2,x)
		{
			last=x/(x/i);
			F(x/i);
			res-=(last-i+1)*gp(x/i);
			i=last; 
		}
		Mu[x]=res;vis[x]=1;
	}
	ui ans,mn;
	void solve()
	{
		init();
		ll last;
		For(i,1,n)
		{
			last=n/(n/i);
			F(last);mn=n/i;
			ans+=(gp(last)-gp(i-1))*mn*mn;
			i=last;
		}
		mn=n;
		write(mn*mn-ans,'\n');
	}
}
namespace sub3
{
	int l[maxn+5],book[maxn+5],s[maxn+5],mu[maxn],sum[maxn+5];
	ui power(ui x,int y)
	{
		if(x==0)return 0;
		ui res=1;
		for(;y;x=x*x,y>>=1)if(y&1)res=res*x;
		return res;
	}
	void init()
	{
		mu[1]=1;
		For(i,2,n)
		{
			if(!book[i])l[++l[0]]=i,mu[i]=-1;
			for(register int j=1;j<=l[0]&&i*l[j]<=n;++j)
			{
				book[i*l[j]]=1;
				s[i*l[j]]=i;
				if(i%l[j]==0)break;
				mu[i*l[j]]=-mu[i];
			}
		}
		For(i,1,l[0])s[l[i]]=1;
		ui temp;
		For(i,1,n)
		{
			temp=power(s[i],k);
			for(register int j=1;i*j<=n;++j)
			{
				sum[i*j]+=temp*mu[j];
			}
		}
		For(i,1,n)sum[i]+=sum[i-1];
	}
	ui ans,mn;
	int last;
	void solve()
	{
		init();
		//For(i,1,n)cout<<i<<' '<<' '<<s[i]<<' '<<sum[i]<<endl;
		For(i,1,n)
		{
			last=n/(n/i);mn=n/i;
			ans+=mn*mn*(sum[last]-sum[i-1]);
			i=last;
		}
		write(ans,'\n');
	}
}
void work()
{
	if(n<=900)
		sub1::solve();
	else if(n<=1000000)
		sub3::solve();
	else if(k==0)
		sub2::solve();
}
int main()
{
	file();
	input();
	work();
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
