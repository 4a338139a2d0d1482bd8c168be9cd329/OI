#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("stack.in","r",stdin);
      freopen("stack.out","w",stdout);
  #endif
}
int n;
void input()
{
	n=read<int>();
}
int a[N];
void init()
{
	a[1]=1;
	a[2]=7;
	a[3]=39;
	a[4]=198;
	a[5]=955;
	a[6]=4458;
	a[7]=20342;
	a[8]=91276;
	a[9]=404307;
	a[10]=1772610;
	a[11]=7707106;
	a[12]=33278292;
	a[13]=142853854;
	a[14]=610170148;
	a[15]=594956606;
	a[16]=994256082;
	a[17]=425048129;
	a[18]=456930141;
	a[19]=725026302;
	a[20]=11689474;
}
void work()
{
	write(a[n],'\n');
}
/*int ans;
struct node
{
	int a[N],top,sum,gx;
};
const int mo=1e9+7;
vector<int>q;
void add(int &a,int b)
{
	a+=b;
	if(a>=mo)a-=mo;
}
void dfs(int now,node x)
{
	if(now==n+1)
	{
		//q.push_back(x.gx);
		add(ans,x.gx);return;
	}
	node y=x;
	y.a[++y.top]=now;
	add(y.sum,now);
	add(y.gx,y.sum);
	dfs(now+1,y);
	y=x;
	if(y.top)
	{
		add(y.sum,mo-y.a[y.top]);
		--y.top;
		dfs(now,y);
	}
}	
void work()
{
	cerr<<n<<endl;
	ans=0;
	node x;
	q.clear();
	x.top=x.sum=x.gx=0;
	dfs(1,x);
	printf("a[%d]=%d;\n",n,ans);
	//sort(q.begin(),q.end());
	For(i,0,q.size()-1)
	{
		//if(i&&q[i]!=q[i-1])cout<<endl;
		cout<<q[i]<<' ';
	}
	puts("");puts("");
}*/
int main()
{
	file();
	input();
	init();
	work();
	return 0;
}
