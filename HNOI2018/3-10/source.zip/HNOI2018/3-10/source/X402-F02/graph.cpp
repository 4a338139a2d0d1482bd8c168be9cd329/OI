#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("graph.in","r",stdin);
      freopen("graph.out","w",stdout);
  #endif
}
int n,m;
void input()
{
	n=read<int>(),m=read<int>();
	if(n>m)swap(n,m);
}
const int mo=1e9+7;
ll power(ll x,int y)
{
	ll res=1;
	for(;y;x=x*x%mo,y>>=1)if(y&1)res=res*x%mo;
	return res;
}
void solve1()
{
	write(power(2,m),'\n');
}
/*int sum;
int l[N*N];
int w[N],h[N];
int check()
{
	memset(w,0,sizeof w);
	memset(h,0,sizeof h);
	For(i,1,n*m)
	{
		if(l[i]>0)
		{
			w[(i-1)/m+1]=1;
			h[(i-1)%m+1]=1;
			//cout<<i<<' '<<(i-1)/m+1<<' '<<(i-1)%m+1<<endl;
		}
	}
	puts("");
	For(i,1,n*m)cout<<l[i]<<' ';
	puts("");
	For(i,1,n)if(!w[i])return 0;
	For(i,1,m)if(!h[i])return 0;
	return 1;
}
void dfs(int now)
{
	if(now==n*m+1)
	{
		if(check())++sum;
		//For(i,1,n*m)cout<<l[i]<<' ';
		//cout<<endl<<check()<<endl;
		return;
	}
	l[now]=0;dfs(now+1);
	l[now]=1;dfs(now+1);
	l[now]=2;dfs(now+1);
}
void solve2()
{
	sum=0;
	dfs(1);
	printf("a[%d][%d]=%d\n",n,m,sum);
}
void work()
{
	//if(n==1)solve1();
	//else 
		solve2();
}*/
int main()
{
	file();
	int T=read<int>();
	while(T--)
	{
		input();
		solve1();
	}
	return 0;
}
