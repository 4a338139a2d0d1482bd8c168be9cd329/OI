#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100+10,mod=1e9+7;
int t,n,m;
bool vis[maxn][maxn],done[maxn][maxn];
ll ans;

inline ll fpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a%mod)
		if(n&1ll)
			res=res*a%mod;
	return res;
}
void dfs(int x,int y,int cnt){
	if(y>m)
		++x,y=1;
	if(x>n){
		queue<pair<int,int> > q;
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
				if(vis[i][j]){
					done[i][j]=true;
					q.push(make_pair(i,j));
				}
				else
					done[i][j]=false;
		while(!q.empty()){
			int x=q.front().first,y=q.front().second;q.pop();
			if(x>1&&y>1&&!done[x-1][y-1]&&done[x-1][y]&&done[x][y-1]){
				done[x-1][y-1]=true;
				q.push(make_pair(x-1,y-1));
			}
			if(x>1&&y<m&&!done[x-1][y+1]&&done[x-1][y]&&done[x][y+1]){
				done[x-1][y+1]=true;
				q.push(make_pair(x-1,y+1));
			}
			if(x<n&&y>1&&!done[x+1][y-1]&&done[x+1][y]&&done[x][y-1]){
				done[x+1][y-1]=true;
				q.push(make_pair(x+1,y-1));
			}
			if(x<n&&y<m&&!done[x+1][y+1]&&done[x+1][y]&&done[x][y+1]){
				done[x+1][y+1]=true;
				q.push(make_pair(x+1,y+1));
			}
			if(x>1&&y>1&&!done[x][y-1]&&done[x-1][y]&&done[x-1][y-1]){
				done[x][y-1]=true;
				q.push(make_pair(x,y-1));
			}
			if(x>1&&y>1&&!done[x-1][y]&&done[x][y-1]&&done[x-1][y-1]){
				done[x-1][y]=true;
				q.push(make_pair(x-1,y));
			}
			if(x>1&&y<m&&!done[x][y+1]&&done[x-1][y]&&done[x-1][y+1]){
				done[x][y+1]=true;
				q.push(make_pair(x,y+1));
			}
			if(x>1&&y<m&&!done[x-1][y]&&done[x][y+1]&&done[x-1][y+1]){
				done[x-1][y]=true;
				q.push(make_pair(x-1,y));
			}
			if(x<n&&y>1&&!done[x][y-1]&&done[x+1][y]&&done[x+1][y-1]){
				done[x][y-1]=true;
				q.push(make_pair(x,y-1));
			}
			if(x<n&&y>1&&!done[x+1][y]&&done[x][y-1]&&done[x+1][y-1]){
				done[x+1][y]=true;
				q.push(make_pair(x+1,y));
			}
			if(x<n&&y<m&&!done[x][y+1]&&done[x+1][y]&&done[x+1][y+1]){
				done[x][y+1]=true;
				q.push(make_pair(x,y+1));
			}
			if(x<n&&y<m&&!done[x+1][y]&&done[x][y+1]&&done[x+1][y+1]){
				done[x+1][y]=true;
				q.push(make_pair(x+1,y));
			}
		}
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
				if(!done[i][j])
					return;
		ans=(ans+fpow(2,cnt))%mod;
		return;
	}
	vis[x][y]=true;
	dfs(x,y+1,cnt+1);
	vis[x][y]=false;
	dfs(x,y+1,cnt);
}

int main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		ans=0;
		scanf("%d%d",&n,&m);
		if(n>m)swap(n,m);
		if(n==1){
			printf("%lld\n",fpow(2,m));
			continue;
		}
		if(n==2){
			printf("%lld\n",(fpow(2,m)-1+mod)%mod*fpow(4,m)%mod);
			continue;
		}
		dfs(1,1,0);
		printf("%lld\n",ans);
	}
	return 0;
}
