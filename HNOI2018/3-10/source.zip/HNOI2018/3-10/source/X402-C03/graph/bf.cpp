#include<bits/stdc++.h>
using namespace std;

int main(){
	int a,b=0;
	cin>>a;
	while(a%2==0)
		++b,a/=2;
	cout<<a<<"*2^"<<b<<endl;
}
