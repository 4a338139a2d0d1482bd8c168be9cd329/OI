#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1e6+10;
const ll mod=(1ll<<32)-1;
int n,k;
int pcnt,prime[maxn/10],minp[maxn];
bool isp[maxn];
ll ans,mu[maxn],sum[maxn];

inline ll fpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a)
		if(n&1ll)
			res=res*a;
	return res;
}
inline ll calc(ll n){
	ll res=0;
	for(int i=1,j;i<=n;){
		j=n/(n/i);
		res+=(sum[j]-sum[i-1])*(n/i)*(n/i);
		i=j+1;
	}
	return res;
}
map<int,ll> mp;
inline ll djs(int n){
	if(n<maxn)
		return sum[n];
	if(mp.count(n))
		return mp[n];
	ll res=0;
	for(int i=2,j;i<=n;){
		j=n/(n/i);
		res+=djs(n/i)*(j-i+1);
		i=j+1;
	}
	return mp[n]=1-res;
}

int main(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	sum[1]=mu[1]=1;
	for(int i=2;i<maxn;++i){
		if(!isp[i]){
			prime[++pcnt]=i;
			mu[i]=-1;
			minp[i]=i;
		}
		for(int j=1;j<=pcnt&&i*prime[j]<maxn;++j){
			isp[i*prime[j]]=true;
			if(i%prime[j]){
				mu[i*prime[j]]=-mu[i];
				minp[i*prime[j]]=prime[j];
			}
			else{
				mu[i*prime[j]]=0;
				minp[i*prime[j]]=prime[j];
				break;
			}
		}
		sum[i]=sum[i-1]+mu[i];
	}
	scanf("%d%d",&n,&k);
	if(k==0){
		for(int i=1,j;i<=n;){
			j=n/(n/i);
			ans+=(djs(j)-djs(i-1))*(n/i)*(n/i);
			i=j+1;
		}
		printf("%lld\n",(n*n-ans)&mod);
		return 0;
	}
	for(int i=2,j;i<=n;){
		j=n/(n/i);
		ll tmp=0;
		for(int x=i;x<=j;++x)
			tmp+=fpow(x/minp[x],k);
		ans+=tmp*calc(n/i);
		i=j+1;
	}
	printf("%lld\n",ans&mod);
	return 0;
}
