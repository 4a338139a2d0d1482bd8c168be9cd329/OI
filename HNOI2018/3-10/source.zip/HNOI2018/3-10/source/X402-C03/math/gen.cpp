#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("math.in","w",stdout);
	int n=f(1,1000),k=f(0,50);
	if(rand()%3==0)
		k=0;
	else if(rand()%2==0)
		k=1;
	printf("%d %d\n",n,k);
	return 0;
}
