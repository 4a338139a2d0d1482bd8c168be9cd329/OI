#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1e6+10;
int n,k;
ll ans;

inline ll fpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a)
		if(n&1ll)
			res=res*a;
	return res;
}

int main(){
	freopen("math.in","r",stdin);
	freopen("math.txt","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j){
			int d=__gcd(i,j)-1;
			if(!d)
				continue;
			while(i%d||j%d)
				--d;
			ans+=fpow(d,k);
		}
	printf("%lld\n",ans&(1ll<<32)-1);
	return 0;
}
