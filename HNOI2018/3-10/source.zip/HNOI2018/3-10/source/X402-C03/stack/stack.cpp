#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1e5+10,mod=1e9+7;
int n;
ll inv[maxn<<1],fac[maxn<<1],c[maxn];
ll dp[maxn],f[maxn];

inline ll fpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a%mod)
		if(n&1ll)
			res=res*a%mod;
	return res;
}

int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	scanf("%d",&n);
	fac[0]=1;
	for(int i=1;i<2*maxn;++i)
		fac[i]=fac[i-1]*i%mod;
	inv[2*maxn-1]=fpow(fac[2*maxn-1],mod-2);
	for(int i=2*maxn-1;i;--i)
		inv[i-1]=inv[i]*i%mod;
	for(int i=0;i<maxn;++i)
		c[i]=fac[2*i]*inv[i]%mod*inv[i+1]%mod;
	for(int i=0;i<n;++i)
		for(int j=0;j<=i;++j)
			(f[i+1]+=c[j]*c[i-j]%mod*(j+1)+2ll*f[j]*c[i-j])%=mod;
	for(int i=0;i<n;++i)
		for(int j=0;j<=i;++j)
			(dp[i+1]+=c[j]*c[i-j]%mod*(j+1)+2ll*dp[j]*c[i-j]+f[i-j]*c[j]%mod*(j+2))%=mod;
	printf("%lld\n",dp[n]);
	return 0;
}
