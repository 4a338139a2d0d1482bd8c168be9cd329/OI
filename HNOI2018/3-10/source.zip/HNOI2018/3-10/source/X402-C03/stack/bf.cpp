#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1e5+10,mod=1e9+7;
int n;
ll ans;
int stk[maxn];

void dfs(int pos,int top,ll now){
	if(pos>n&&top==0){
		(ans+=now)%=mod;
		return;
	}
	if(top){
		int pre=stk[top-1];
		dfs(pos,top-1,now);
		stk[top-1]=pre;
	}
	if(pos<=n){
		stk[top]=pos;
		for(int i=0;i<=top;++i)
			now+=stk[i];
		dfs(pos+1,top+1,now);
	}
}

int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.txt","w",stdout);
	scanf("%d",&n);
	dfs(1,0,0);
	printf("%lld\n",ans);
	return 0;
}
