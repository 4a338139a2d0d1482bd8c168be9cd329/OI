#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
typedef unsigned int ui;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
map<int,ui> mp;
const int maxn=1e7+10;
ui mu[maxn],M[maxn],d[maxn],prime[maxn],tmp,f[maxn];
bool isprime[maxn];
ui ksm(ui x,ui y){
	if(x==0) return 0;
	ui res=1;
	while(y){
		if(y&1) res*=x;
		x*=x;
		y>>=1;
	}
	return res;
}
void init(int n){
	mu[1]=M[1]=1;
	d[1]=0;
	REP(i,2,n){
		if(!isprime[i]) prime[++tmp]=i,mu[i]=-1,d[i]=1;
		REP(j,1,tmp){
			if(1ll*i*prime[j]>n) break;
			int u=i*prime[j];
			isprime[u]=1;
			if(i%prime[j]) mu[u]=mu[i]*-1,d[u]=i;
			else{
				mu[0]=0,d[u]=i;
				break;
			}
		}
		M[i]=M[i-1]+mu[i];
	}
}
int lim;
ui find_mu(int x){
	if(x<=lim) return M[x];
	if(mp[x]) return mp[x];
	ui res=1;
	for(int i=2,r;i<=x;i=r+1){
		r=x/(x/i);
		res-=find_mu(x/i)*(r-i+1);
	}
	return mp[x]=res;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
#endif
	int n=read(),k=read();
	unsigned int ans=0;
	if(n<=1e6){
		init(n);
		REP(i,1,n) d[i]=ksm(d[i],k);
		REP(i,1,n)
			REP(j,1,n/i)
				f[i*j]+=d[i]*mu[j];
		REP(i,1,n) ans+=f[i]*(n/i)*(n/i);
		printf("%u\n",ans);
		return 0;
	}
	if(k==0){
		lim=1e7;
		init(lim);
		ans=(ui)n*(ui)n;
		for(int i=1,r=0;i<=n;i=r+1){
			r=n/(n/i);
			ans-=(find_mu(r)-find_mu(i-1))*(n/i)*(n/i);
		}
		printf("%u\n",ans);
		return 0;
	}
	printf("0\n");
	return 0;
}
