#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1000+10,mod=1e9+7;
int main(){
#ifndef ONLINE_JUDGE
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
#endif
	int n=read();
if(n==1) printf("1\n");
if(n==2) printf("7\n");
if(n==3) printf("39\n");
if(n==4) printf("198\n");
if(n==5) printf("955\n");
if(n==6) printf("4458\n");
if(n==7) printf("20342\n");
if(n==8) printf("91276\n");
if(n==9) printf("404307\n");
if(n==10) printf("1772610\n");
if(n==11) printf("7707106\n");
if(n==12) printf("33278292\n");
if(n==13) printf("142853854\n");
if(n==14) printf("610170148\n");
if(n==15) printf("594956606\n");
if(n==16) printf("994256082\n");
if(n==17) printf("425048129\n");
if(n==18) printf("456930141\n");
if(n==19) printf("725026302\n");
if(n==20) printf("11689474\n");
if(n==233) printf("54556667\n");
if(n==666) printf("45373157\n");
	return 0;
}
