#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
typedef long long LL;

int n,k;

LL sum,mod=1;

int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}

LL ksm(LL a,int b){
	LL ans=1;
	while(b){
		if(b&1) ans=ans*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}

int cc(int a,int b){
	for(int i=2;i<=max(a,b);i++)
		if(a%i==0&&b%i==0) return i;
	return 0;
}

int main()
{
	freopen("a.in","r",stdin);
	read(n),read(k);
	for(int i=1;i<=32;i++)
		mod=mod*2;
	if(k==0){
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(gcd(i,j)==1) continue;
				else sum++;
	}
	else if(k>1){
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				if(gcd(i,j)==1) continue;
				int qwq=cc(i,j);
				sum+=ksm(gcd(i,j)/qwq,k)%mod;
			}
	}
	else{
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				if(gcd(i,j)==1) continue;
				int qwq=cc(i,j);
				sum+=gcd(i,j)/qwq;
			}
	}
	printf("%lld",sum%mod);
	return 0;
}
