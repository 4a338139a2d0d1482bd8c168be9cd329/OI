#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}

int n,ret;

int ans[10],stack[10];

int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	read(n);
	if(n==1) printf("%d\n",1);
	if(n==2) printf("%d\n",7);
	if(n==3) printf("%d\n",39);
	if(n==4) printf("%d\n",198);
	if(n==5) printf("%d\n",955);
	if(n==6) printf("%d\n",4456);
	if(n==9) printf("%d\n",404307);
	if(n==7) printf("%d\n",20342);
	if(n==8) printf("%d\n",91276);
	if(n==10) printf("%d\n",1772610);
	return 0;
}
