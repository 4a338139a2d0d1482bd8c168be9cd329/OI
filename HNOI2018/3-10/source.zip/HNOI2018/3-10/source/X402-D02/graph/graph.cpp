#include<iostream>
#include<cstdio>
#include<cstring>

typedef long long ll;
const int N=6,MOD=1000000007;

ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

int n,m,ans;
bool G[N][N],f[N][N];

bool work()
{
	bool ret=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(!f[i][j])
			{
				if(f[i-1][j] && f[i][j-1] && f[i-1][j-1])ret=f[i][j]=1;
				if(f[i-1][j] && f[i][j+1] && f[i-1][j+1])ret=f[i][j]=1;
				if(f[i+1][j] && f[i][j-1] && f[i+1][j-1])ret=f[i][j]=1;
				if(f[i+1][j] && f[i][j+1] && f[i+1][j+1])ret=f[i][j]=1;
			}
	return ret;
}

bool check()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			f[i][j]=G[i][j];
	int k=n*m;
	while(k-- && work());
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(!f[i][j])return 0;
	return 1;
}

void dfs(int x,int y,int cnt)
{
	if(y>m){dfs(x+1,1,cnt);return;}

	if(x>n)
	{
		if(check())
			ans=(ans+qpow(2,cnt))%MOD;
		return;
	}

	G[x][y]=1,dfs(x,y+1,cnt+1);
	G[x][y]=0,dfs(x,y+1,cnt);
}

int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;)
	{
		scanf("%d%d",&n,&m);

		ans=0,dfs(1,1,0);
		printf("%d\n",ans);
	}

	return 0;
}
