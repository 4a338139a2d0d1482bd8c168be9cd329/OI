#include<iostream>
#include<cstdio>
#include<cstring>

namespace O_O
{
	typedef long long ll;
	const int N=31,M=2333,MOD=1000000007;
	inline void inc(int a,int &b){b=(a+b)%MOD;}
	
	ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}
	int fact[M],ifact[M];
	ll C(int n,int m){if(n<m)return 0;return (ll)fact[n]*ifact[m]%MOD*ifact[n-m]%MOD;}

	void initialize()
	{
		fact[0]=1;
		for(int i=1;i<M;i++)fact[i]=(ll)fact[i-1]*i%MOD;
		ifact[M-1]=inv(fact[M-1]);
		for(int i=M-1;i;i--)ifact[i-1]=(ll)ifact[i]*i%MOD;
	}

	int f[N][N][N*N];
	int n,m;

	void dp()
	{
		for(int i=1;i<N;i++)f[i][1][i]=f[1][i][i]=1;
		for(int i=0;i<N;i++)f[i][0][0]=f[0][i][0]=1;

		for(int x=2;x<N;x++)
			for(int y=2;y<N;y++)
			{
				for(int k=1;k<=x*y;k++)
				{
					int &v=f[x][y][k]=0;
					for(int i=1;i<=y && i<=k;i++)
						inc(f[x-1][y][k-i]*C(y,i)*2%MOD,v);
					for(int i=1;i<=x && i<=k;i++)
						inc(f[x][y-1][k-i]*C(x,i)*2%MOD,v);

					if(x==2 && y==2 && k==4)printf("v = %d\n",v);

					for(int i=2;i<=x+y-1 && i<=k;i++)
						inc(-f[x-1][y-1][k-i]*(C(x+y-1,i)-C(x,i)-C(y,i))%MOD*4%MOD,v);
					for(int i=2;i<=y*2 && i<=k;i++)
						inc(-f[x-2][y][k-i]*(C(y*2,i)-C(y,i)*2)%MOD,v);
					for(int i=2;i<=x*2 && i<=k;i++)
						inc(-f[x][y-2][k-i]*(C(x*2,i)-C(x,i)*2)%MOD,v);

					if(x==2 && y==2 && k==4)printf("v = %d\n",v);

					int tot=x+y-1+x-1;
					for(int i=2;i<=k;i++)
						inc(f[x-1][y-2][k-i]*(C(tot,i)-C(x-1,i)*2-C(y-2,i)-C(2,i))%MOD*2%MOD,v);
					tot=x*y-1+y-1;
					for(int i=2;i<=k;i++)
						inc(f[x-2][y-1][k-i]*(C(tot,i)-C(y-1,i)*2-C(x-2,i)-C(2,i))%MOD*2%MOD,v);

					if(x==2 && y==2 && k==4)printf("v = %d\n",v);

					tot=x*2+y*2-4;
					for(int i=2;i<=k;i++)
						inc(-f[x-2][y-2][k-i]*(C(tot,i)-C(x-2,i)*2-C(y-2,i)*2-C(4,i))%MOD,v);

					if(x==2 && y==2 && k==4)printf("v = %d\n",v);
				}
			}
		printf("end\n");
	}

	int g[N*N];
	void solve()
	{
		scanf("%d%d",&n,&m);
		memset(g,0,sizeof(g));
		for(int i=1;i<=n*m;i++)
		{
			printf("f[%d] = %d\n",i,f[n][m][i]);
			g[i]=(ll)f[n][m][i];
		}
		int ans=0;
		for(int i=1;i<=n*m;i++)
			ans=(ans+g[i]*qpow(2,i)%MOD)%MOD;
		ans=(ans+MOD)%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
//	freopen("graph.in","r",stdin);
//	freopen("graph.out","w",stdout);
	O_O::initialize();
	O_O::dp();
	O_O::solve();
	return 0;
}
