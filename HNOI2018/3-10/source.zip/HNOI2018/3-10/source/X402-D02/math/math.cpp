#include<iostream>
#include<cstdio>
#include<cstring>

typedef unsigned int ui;
int n,k;

namespace planA
{
	const int N=1010000;

	ui qpow(ui a,ui b){ui c=1;for(;b;b>>=1,a=a*a)if(b&1)c=c*a;return c;}

	ui f[N],g[N];
	void solve()
	{
		for(int i=1;i<=n;i++)
			f[i]=(n/i)*(n/i);

		for(int i=n;i;i--)
			for(int j=2,x;(x=i*j)<=n;j++)
				f[i]-=f[x];

		for(int d=2;d<=n;d++)
			for(int i=1,x;(x=i*d)<=n;i++)
				g[x/d]+=f[x],f[x]=0;

		ui ans=0;
		for(int i=1;i<=n;i++)
			ans+=g[i]*qpow(i,k);
		printf("%u\n",ans);
	}
}

namespace planB
{
	const int N=10000100,MO=1926817;

	struct hasher
	{
		ui w[N];
		int begin[MO],next[N],to[N];
		int e;

		ui& operator [](int n)
		{
			int x=n%MO;
			for(int i=begin[x];i;i=next[i])
				if(to[i]==n)return w[i];

			to[++e]=n;
			next[e]=begin[x];
			begin[x]=e;
			return w[e]=0;
		}
		bool count(int n)
		{
			int x=n%MO;
			for(int i=begin[x];i;i=next[i])
				if(to[i]==n)return 1;
			return 0;
		}
	};

	bool isit[N];
	int pri[N/10],tot;
	ui MU[N];
	void initialize()
	{
		MU[1]=1;
		for(int i=2;i<N;i++)
		{
			if(!isit[i])pri[++tot]=i,MU[i]=-1;
			for(int j=1,x;(x=i*pri[j])<N;j++)
			{
				isit[x]=1;
				if(i%pri[j])MU[x]=-MU[i];
				else break;
			}
		}
		for(int i=1;i<N;i++)MU[i]+=MU[i-1];
	}

	hasher MU_;

	ui calc_Mu(int n)
	{
		if(n<N)return MU[n];
		if(MU_.count(n))return MU_[n];

		ui ret=1;
		for(int i=2,j,x;i<=n;i=j+1)
		{
			x=n/i,j=n/x;
			ret-=(j-i+1)*calc_Mu(x);
		}

		return MU_[n]=ret;
	}

	void solve()
	{
		initialize();
		ui ans=(ui)n*(ui)n,x;
		for(int i=1,j;i<=n;i=j+1)
		{
			x=n/i,j=n/x;
			ans-=x*x*(calc_Mu(j)-calc_Mu(i-1));
		}
		printf("%u\n",ans);
	}
}

int main()
{
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(n<=1000000)planA::solve();
	else planB::solve();
	return 0;
}
