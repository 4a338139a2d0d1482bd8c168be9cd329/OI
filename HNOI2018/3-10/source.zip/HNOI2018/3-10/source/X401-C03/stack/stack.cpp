#include<bits/stdc++.h>
using namespace std;

int n;
int __ans;
const double a = 0.345;
const double b = 1.542;
const double e = 2.718281828459;
const double mod = 1e9 + 7;

double f_pow(double A,double B){
	int b = B;
	double ans = 1;
	while(b){
		if(b & 1)ans *= A ;
		A *= A;
		while(A > mod)A -= mod ;
		while(ans > mod)ans -= mod;
		b >>= 1;
	}
	return ans ;
}

int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	cin >> n;
	cout << (int)(a * f_pow(e,b * 1.0 *  n) + 0.5);
}
