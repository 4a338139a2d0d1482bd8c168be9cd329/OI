#include<bits/stdc++.h>
using namespace std;
#define UI unsigned int

UI prime[100005];
UI isPn[1000005];
UI fai [1000005];
UI sgcd[1000005];
UI all = 0;
UI n,k;

UI f_pow(UI A,UI B){
	UI ans = 1;
	while(B){
		if(B & 1)ans *= A;
		A *= A;
		B >>= 1;
	}
	return ans;
}

void get_fai_and_sgcd(int n){
    fai[1] = 0;
    int all = 0;
    for(UI i = 2;i <= n; ++i )isPn[i] = 1;
    for(UI i = 2;i <= n; ++i ){
        if(isPn[i]){
            prime[all ++] = i;
            fai[i] = i -1;
            sgcd[i] = 1;
        }
        for(UI j = 0;j < all;j ++){
        	int next = i * prime[j];
            if( next > n)break;
            isPn[next] = false;
            sgcd[next] = max(sgcd[i] * prime[j],i);
            if(i % prime[j] == 0){
                fai[next] = prime[j] * fai[i];
                break;
            }else{
                fai[next] = (prime[j] - 1) * fai[i];
            }
        }
    }
    for(UI i = 1;i <= n;i ++)sgcd[i] = f_pow(sgcd[i],k) + sgcd[i - 1];
}

int main(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	cin >> n >> k;
	get_fai_and_sgcd(1000000);
	UI ans = 0;
	for(int i = 1;i <= n;i ++){
		ans += fai[i] * sgcd[n / i];
	}
	cout << ans * 2 + sgcd[n];
	return 0;	
}
