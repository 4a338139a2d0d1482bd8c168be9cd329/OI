#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define mod (LL)(1e9 + 7)

LL f_pow(LL A, LL B){
	LL ans = 1;
	while(B){
		if(B & 1) (ans *= A) %= mod;
		(A *= A) %= mod;
		B >>= 1;
	}
	return ans;
}

int main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	int t;cin >> t;
	for(int i = 1;i <= t;i ++){
		int m,n;cin >> m >> n;
		if( m == 1 or n == 1){
			if(n == 1)swap(m,n);
			cout << f_pow(3,n) << "\n";
		}else{
				
		}
	}
	return 0;	
}
