#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=10;
const int mod=1e9+7;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int f[105+5][1<<N|1],n,m,pw[105+5];

void wj()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
}
int main()
{
	wj();
	pw[0]=1;
	for(int i=1;i<=100;++i) pw[i]=(pw[i-1]+pw[i-1])%mod;
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		n=read(); m=read();
		if(n<m) swap(n,m); //n>=m
		int tot=1<<m;
		for(int i=0;i<=n;++i) for(int j=0;j<tot;++j) f[i][j]=0;
		f[0][tot-1]=1;
		for(int i=0;i<n;++i) for(int j=0;j<tot;++j) if(f[i][j])
		{
			for(int k=0;k<tot-1;++k)
				f[i+1][j&k]=(f[i+1][j&k]+1ll*f[i][j]*pw[m-__builtin_popcount(k)])%mod;
		}
		printf("%d\n",f[n][0]);
	}
	return 0;
}
