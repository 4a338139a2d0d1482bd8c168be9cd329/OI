#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1050;
const int mod=1e9+7;

int n,f[N][N],g[N][N];

void wj()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	g[1][1]=1;
	for(int i=2;i<=n+1;++i) for(int j=1;j<=i;++j) g[i][j]=(g[i-1][j]+g[i][j-1])%mod;
	for(int i=2;i<=n+1;++i) for(int j=1;j<=i;++j)
		f[i][j]=(1ll*f[i][j-1]+f[i-1][j]*2ll+1ll*g[i-1][j]*(i-1)%mod)%mod;
	cout<<f[3][2]<<endl;
	printf("%d\n",f[n+1][n+1]);
	return 0;
}
