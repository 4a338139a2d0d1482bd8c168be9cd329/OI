#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
const int mod=1e9+7;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int fac[N],finv[N];
inline int cat(int n)
{
	return 1ll*fac[2*n]*finv[n+1]%mod*finv[n]%mod;
}

int n;
void wj()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	fac[0]=1;
	for(int i=1;i<=(n<<1);++i) fac[i]=1ll*fac[i-1]*i%mod;
	finv[n<<1]=qpow(fac[n<<1],mod-2);
	for(int i=(n<<1)-1;i>=0;--i) finv[i]=1ll*finv[i+1]*(i+1)%mod;

	int ans=0;
	for(int i=1;i<=n;++i) 
	{
		int sum=0;
		for(int j=1;j<=n-i+1;++j)
		{
			sum=(sum+1ll*cat(j-1)*j%mod*cat(n-j))%mod;
			if(i==2) cout<<j<<' '<<1ll*cat(j-1)*(cat(n-j+1)-cat(n-j))<<endl;
		}
		//cout<<sum<<endl;
		ans=(ans+1ll*sum*cat(i)%mod*i)%mod;
	}
	printf("%d\n",ans);
	return 0;
}
