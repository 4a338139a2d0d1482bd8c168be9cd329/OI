#include<bits/stdc++.h>
using namespace std;
const long long mod=1e9+7;
const int maxn=25;
inline void read(int &x){
	int p=1;
	char c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^'0');
		c=getchar();
	}
	x*=p;
}
int n,m,cas,a[maxn][maxn],x[maxn],y[maxn];
long long ans,tot;
long long qpow(long long _,long long __){
	long long ret=1;
	while(__){
		if(__&1)(ret*=_)%=mod;
		(_*=_)%=mod;
		__>>=1;
	}
	return ret;
}
bool check(){	
	tot=0;
	memset(x,0,sizeof(x));
	memset(y,0,sizeof(y));
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=m;++j){ 
			if(a[i][j]==1){
				x[i]++;
				y[j]++;
				tot++;
			}
		}
	}
	for(register int i=1;i<=n;++i){
		if(!x[i])return 0;
	}
	for(register int i=1;i<=m;++i){
		if(!y[i])return 0;
	}
	return 1;
}
inline void dfs(int _,int __){
	if(__==m+1){
		dfs(_+1,1);
		return;
	}
	if(_==n+1){
		if(check())(ans+=qpow(2,tot))%=mod;	
		return;
	}
	a[_][__]=0;
	dfs(_,__+1);
	a[_][__]=1;
	dfs(_,__+1);	
}

int main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	read(cas);
	while(cas--){
		read(n);read(m);
		if(n==1||m==1){
			long long x1=(long long)m*(long long)n;
			printf("%lld\n",qpow(2,x1));
			continue;
		}
		ans=0;
		dfs(1,1);
		printf("%lld\n",ans-qpow(2,n+m-1)*m);
	}
	return 0;
}

