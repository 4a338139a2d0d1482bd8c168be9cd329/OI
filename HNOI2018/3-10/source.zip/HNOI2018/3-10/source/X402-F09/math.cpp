#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
	int p=1;
	char c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^'0');
		c=getchar();
	}
	x*=p;
}
const long long mod=4294967296;
int n,k;
long long ans;
long long qpow(long long _,long long __){
	long long ret=1;
	while(__){
		if(__&1)(ret*=_)%=mod;
		(_*=_)%=mod;
		__>>=1;
	}
	return ret;
}
int main(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	read(n),read(k);	
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=n;++j){
			long long _=(long long)i,__=(long long)j,___=2;
			long long x=__gcd(_,__);
			if(x==1)continue;
			while(x%___){
				___++;
			}
			(ans+=qpow((x/___),k))%=mod;
		}
	}
	printf("%lld\n",ans);
	return 0;
}

