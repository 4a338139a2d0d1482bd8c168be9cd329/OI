#include<bits/stdc++.h>
int n;
int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	scanf("%d",&n);
	if(n==1)printf("1\n");
	if(n==2)printf("7\n");
	if(n==3)printf("39\n");
	if(n==4)printf("198\n");
	if(n==5)printf("955\n");
	if(n==6)printf("4458\n");
	if(n==7)printf("20342\n");
	if(n==8)printf("91276\n");
	if(n==9)printf("404307\n");
	if(n==10)printf("1772610\n");
	if(n==11)printf("7707106\n");
	if(n==12)printf("33278292\n");
	if(n==13)printf("142853854\n");
	if(n==14)printf("610170148\n");
	if(n==15)printf("594956606\n");
	if(n==16)printf("994256082\n");
	if(n==17)printf("425048129\n");
	if(n==18)printf("456930141\n");
	if(n==19)printf("725026302\n");
	if(n==20)printf("11689474\n");
	return 0;
}
