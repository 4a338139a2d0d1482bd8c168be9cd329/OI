/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-03-10 09:51
#
# Filename: math.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( LL i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const LL Mod = 4294967296;

LL n, k, ans, a[1010];
bool f[1010];

LL gcd(LL x, LL y)
{
    return y ? gcd(y, x % y) : x;
}

LL power(LL x, LL y)
{
    LL r = 1;
    while ( y )
    {
        if ( y & 1 ) r = r * x % Mod;
        y >>= 1;
        x = x * x % Mod;
    }
    return r % Mod;
}

int main()
{
    freopen("math.in", "r", stdin);
    freopen("math.out", "w", stdout);
    cin >> n >> k; 
    LL Max = 1010, s = 0;
    f[0] = true;
    f[1] = true;
    REP(i, 2, Max)
        if ( f[i] == false ) 
        {
            a[++ s] = i;
            for ( LL j = i + i; j <= Max; j += i )
                f[j] = true;
        }
    REP(i, 1, n)
    {
        REP(j, 1, n)
        {
            LL sum = 0;
            LL x = gcd(i, j);
            if ( x == 1 ) continue ;
            REP(t, 1, s)
                if ( a[t] <= x )
                {
                    if ( x % a[t] == 0 ) 
                    {
                        sum = x / a[t];
                        break ;
                    }
                }
                else break ;
            ans = (ans + power(sum, k) % Mod) % Mod;
        }
    }
    cout << ans << endl;
    return 0;
}

