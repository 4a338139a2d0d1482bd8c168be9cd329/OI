/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-03-10 10:12
#
# Filename: graph.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int Mod = 1000000007;

int power(int x, int y)
{
    int r = 1;
    while ( y ) 
    {
        if ( y & 1 ) r = r * x % Mod;
        x = x * x % Mod;
        y >>= 1;
    }
    return r;
}

int main()
{
    freopen("graph.in", "r", stdin);
    freopen("graph.out", "w", stdout);
    int n, m, T;
    cin >> T;
    while ( T -- )
    {
        cin >> n >> m;
        if ( n == 1 ) cout << power(2, m) << endl;
        else if ( m == 1 ) cout << power(2, n) << endl;
    }
    return 0;
}

