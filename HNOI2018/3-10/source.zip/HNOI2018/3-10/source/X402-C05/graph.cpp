#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7;
int T,m,n;
ll fpm(ll a,ll b){
	ll ret=1ll;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
void solve(){
	scanf("%d",&T);
	for(;T--;){
		scanf("%d%d",&n,&m);
		if(n==1||m==1){
			cout<<fpm(2,n*m)<<endl;
		}
	}
}
int main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	solve();
	
	return 0;
} 
