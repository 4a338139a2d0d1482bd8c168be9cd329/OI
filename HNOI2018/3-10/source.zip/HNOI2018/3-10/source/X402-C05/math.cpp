#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned int ui;
const int maxn=1e6+10;
bool np[maxn];
ui mu[maxn],d[maxn],g[maxn],ans;
vector<int> p;
int n,k;
ui ufpm(ui a,ui b){
	ui ret=1u;
	if(!a)return 0;
	for(;b;b>>=1,a=a*a)
		if(b&1)ret=ret*a;
	return ret;
}
void init(){
	mu[1]=1;d[1]=0;
	for(int i=2;i<=n;++i){
		if(!np[i]){
			mu[i]=-1;
			d[i]=1;
			p.push_back(i);
		}
		for(int j=0;j<p.size()&&p[j]*i<=n;++j){
			np[i*p[j]]=1;
			d[i*p[j]]=d[p[j]]*i;
			if(i%p[j]==0)break;
			mu[i*p[j]]=-mu[i];
		}
	}
//	for(int i=1;i<=min(20,n);++i){
//		cerr<<i<<" "<<d[i]<<" "<<mu[i]<<endl;
//	}
	for(int i=1;i<=n;++i)
		for(int j=1;i*j<=n;++j)
			g[i*j]+=mu[i]*ufpm(d[j],k);
	for(int i=1;i<=n;++i)g[i]+=g[i-1];//(g[i]+=g[i-1])%=mod;
}

namespace Work1{
	int lim;
	map<ui,ui> mp;
	void Init(int n){
		mu[1]=1;d[1]=0;
		for(int i=2;i<=n;++i){
			if(!np[i]){
				mu[i]=-1;
				d[i]=1;
				p.push_back(i);
			}
			for(int j=0;j<p.size()&&p[j]*i<=n;++j){
				np[i*p[j]]=1;
				d[i*p[j]]=d[p[j]]*i;
				if(i%p[j]==0)break;
				mu[i*p[j]]=-mu[i];
			}
		}
		for(int i=1;i<=n;++i)mu[i]+=mu[i-1];
	}
	ui G(ui n){
		if(n<=lim){return mu[n];}
		if(mp.count(n))return mp[n];
		ui ret=1;
		for(ui l=2,r;l<=n;l=r+1){
			r=n/(n/l);
			ret-=(r-l+1)*G(n/l);
		}
		return mp[n]=ret;
	}	
	void work1(){
		ans=1u*n*n;
		Init(lim=min(n,1000000));
		for(ui l=1,r,now,lst=0;l<=n;l=r+1){
			r=n/(n/l);now=G(r);
			ans-=(now-lst)*(n/l)*(n/l);
			lst=now;
		}
		cout<<ans<<endl;
		exit(0);
	}
}
void solve(){
	scanf("%d%d",&n,&k);
	if(!k)Work1::work1();
	init();
	for(int l=1,r;l<=n;l=r+1){
		r=n/(n/l);
		ans+=(g[r]-g[l-1])*(n/l)*(n/l);
	}
	cout<<ans<<endl;
}
int main(){
	freopen("math.in","r",stdin);freopen("math.out","w",stdout);
	solve();
	return 0;
} 
