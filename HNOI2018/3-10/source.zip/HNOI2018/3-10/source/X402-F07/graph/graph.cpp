#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=105,mod=1e9+7,dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1ll*res*x%mod;
		x=1ll*x*x%mod,y>>=1;
	}return res;
}
int n,m,a[maxn][maxn];
bool vis[maxn][maxn];
void DFS(int x,int y){
	if(!vis[x][y]){
		vis[x][y]=1;
		REP(k,0,3){
			int u=x+dir[k][0],v=y+dir[k][1];
			if((u<1)||(v<1)||(u>n)||(v>m)||((!a[u][v])&&(!vis[u][v])))continue;
			DFS(u,v);
		}
	}
	REP(k,0,1){
		REP(l,2,3){
			int u=x+dir[k][0],v=y+dir[l][1];
			if((u<1)||(v<1)||(u>n)||(v>m))continue;
			if((vis[u][v])||((!a[u][y])&&(!vis[u][y]))||((!a[x][v])&&(!vis[x][v])))continue;
			DFS(u,v);
		}
	}
}
bool check(){
	memset(vis,0,sizeof(vis));
	REP(i,1,n)
		REP(j,1,m)
			if(a[i][j]&&!vis[i][j])
				DFS(i,j);
	bool flag=1;
	REP(i,1,n)
		REP(j,1,m)
			flag&=vis[i][j];
	return flag;
}
void work(){
	int ans=0;
	n=read(),m=read();
	if(n==1)swap(n,m);
	if(m==1)return write(ksm(2,n),'\n');
	REP(i,0,(1<<(n*m))-1){
		REP(j,1,n)
			REP(k,1,m)
				a[j][k]=(i>>((j-1)*m+k-1))&1;
		if(check())
			(ans+=ksm(2,__builtin_popcount(i)))%=mod;
	}
	write(ans,'\n');
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
#endif
	int q_cnt=read();
	while(q_cnt--)work();
	return 0;
}
