#include<bits/stdc++.h>
#define neko 1000010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
int mod=1e9+7,s[neko],stk,sum,n;
int ans[30]={0,1,7,39,198,955,4458,20342,91276,404307,1772610,7707106,33278292,142853854,610170148,594956606,994256082,425048129,456930141,725026302,11689474};
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	scanf("%d",&n);
//	dfs(1,1);
	printf("%d\n",ans[n]);
	return 0;
}

