#include<cstdio>
#include<cstdlib>
#include<iostream>
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
typedef long long ll;
ll n,m,mod=1e9+7;
int cas;
ll slowpow(ll m,ll n)
{
    long long b=1;
    while(n>0)
    {
        if(n&1)b=(b*m)%mod;
        n>>=1;
        m=(m*m)%mod;
    }return b;
} 
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	scanf("%d",&cas);
	f(i,1,cas)
	{
		scanf("%lld%lld",&n,&m);
		if(n>m)std::swap(n,m);
		if(n==1)printf("%lld\n",slowpow(2,m));
	}
	return 0;
}

