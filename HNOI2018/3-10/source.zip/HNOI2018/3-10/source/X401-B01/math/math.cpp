#include<bits/stdc++.h>
#define neko 1000010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
typedef int arr[neko];
long long n,kkk;
arr isnprime,mu,prime;
unsigned int sum,ii,jj;
void sieve()
{
	mu[1]=1;
	f(i,2,1000000)
	{
		if(!isnprime[i])prime[++prime[0]]=i,mu[i]=-1;
		for(register int j=1;j<=prime[0]&&i*prime[j]<=1000000;j++)
		{
			isnprime[i*prime[j]]=1;
			if(i%prime[j]==0){mu[i*prime[j]]=0;break;}
			mu[i*prime[j]]=-mu[i];
		}
	}
}
int main()
{
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	scanf("%lld%lld",&n,&kkk);
/*	if(k==0)
	{
		
		return printf("%lld\n",n*n-ans)*0;
	}*/
	sieve(); 
	if(n<=2000)
	{
		f(i,1,n)
		 f(j,1,n)
		 {
		 	if(std::__gcd(i,j)==1)continue;
		 	f(k,1,prime[0])
		 	{
		 		if((i%prime[k])==0&&(j%prime[k])==0){ii=i/prime[k],jj=j/prime[k];break;}
		 	}
		 	sum+=pow(std::__gcd(ii,jj),kkk);
		 }
		printf("%u\n",sum);
	}
	return 0;
}
