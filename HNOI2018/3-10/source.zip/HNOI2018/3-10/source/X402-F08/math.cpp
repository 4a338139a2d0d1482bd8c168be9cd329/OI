#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=3000+10;
int n,k;
unsigned int sgcd[maxn];
unsigned int ans=0;

inline void file() {
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
}

int main() {
	file();
	scanf("%d%d",&n,&k);
	For (i,2,n) Forr (j,i-1,1)
		if (i%j==0) {
			sgcd[i]=j;
			break;
		}
//	For (i,1,n) printf("%d ",sgcd[i]); cout << endl;
	For (i,1,n) {
		unsigned int ss=1;
		For (j,1,k)  ss=ss*sgcd[i];
		sgcd[i]=ss;
	}
	For (i,1,n) For (j,1,n) {
		ans+=sgcd[__gcd(i,j)];
	}
	cout << ans << endl;
	return 0;
}
