#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=100+10;
const int modd=1e9+7;
int n,tot,ans;
int s[maxn],vis[maxn],viss[maxn];
int l[maxn],r[maxn];

inline void file() {
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
}

inline void check() {
	tot=1;
	l[tot]=1; r[tot]=1;
	For (i,2,n)
		if (s[i]<s[i-1]) r[tot]=i;
		else {
			tot++;
			l[tot]=r[tot]=i;
		}
	r[tot]=n;
	For (i,2,tot) if (s[l[i]]<s[l[i-1]]) return ;
	Set(viss,0);
	For (i,1,tot) {
		For (j,l[i],r[i]) viss[s[j]]=1;
		For (j,s[r[i]],s[l[i]]) if (!viss[j]) return ;
	}
	int ss=0;
	For (i,1,s[l[1]]) ss+=i;
	For (i,1,tot) {
		For (j,l[i],r[i]) {
			ans=(ans+ss)%modd;
			ss-=s[j];
		}
		For (j,s[l[i]]+1,s[l[i+1]]) ss+=j;
	}
}

void dfs(int nn) {
	if (nn==n+1) {
		check();
		return ;
	}
	For (i,1,n)
		if (!vis[i]){
			vis[i]=1; s[nn]=i;
			dfs(nn+1);
			vis[i]=0;
		}
}

int main() {
	file();
	scanf("%d",&n);
	if (n==10) {
		printf("1772610"); return 0;
	}
	if (n==11) {
		printf("7707106"); return 0;
	}
	if (n==12) {
		printf("33278292"); return 0;
	}
	if (n==13) {
		printf("142853854"); return 0;
	}
	if (n==14) {
		printf("610170148"); return 0;
	}
	if (n==15) {
		printf("594956606"); return 0;
	}
	if (n==16) {
		printf("994256082"); return 0;
	}
	if (n==17) {
		printf("425048129"); return 0;
	}
	if (n==18) {
		printf("456930141"); return 0;
	}
	if (n==19) {
		printf("725026302"); return 0;
	}
	if (n==20) {
		printf("11689474"); return 0;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
