#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e3+10;
int dp[maxn][maxn],dp1[maxn][maxn],dp2[maxn][maxn];
const int mod=1e9+7;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int fpm(int a,int b){
	int ans=1;
	while(b){
		if(b & 1)ans=1ll*ans*a%mod;
		a=1ll*a*a%mod;b/=2;
	}
	return ans;
}
inline void Mod(int &x,int y){
	x+=y;
	if(x>=mod)x-=mod;
}
int main(){
	int i,j,k,n;
#ifndef ONLINE_JUDGE
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
#endif
	n=read();
//	printf("%d\n",Ans[n]);
	int ans=0;
	dp1[n][1]=1;
	for(i=n;i>=1;i--){
		for(j=n-i+2;j>=2;j--)
			for(k=j-1;k>=1;k--)
				Mod(dp1[i-1][j],dp1[i][k]);
		for(k=1;k<=n-i+1;k++)
			Mod(dp1[i-1][1],dp1[i][k]);
	}
	dp2[0][1]=1;
	for(i=1;i<=n;i++){
		for(j=n-i+2;j>=2;j--){
			if(!dp2[i-1][j])continue;
			for(k=j-1;k>=2;k--)
				Mod(dp2[i][k],dp2[i-1][j]);
		}
		for(k=1;k<=n-i+1;k++)
			Mod(dp2[i][k],dp2[i-1][1]);
	}
	for(i=0;i<=n+1;i++)
		for(j=0;j<=n+1;j++)
			printf("%2d%c",dp1[i][j],j==n+1?'\n':' ');
	puts("----");
	for(i=0;i<=n+1;i++)
		for(j=0;j<=n+1;j++)
			printf("%2d%c",dp2[i][j],j==n+1?'\n':' ');
	puts("----");
	for(i=0;i<=n+1;i++)
		for(j=0;j<=n+1;j++)
			dp[i][j]=1ll*dp1[i][j]*dp2[i][j]%mod;
	for(i=0;i<=n+1;i++)
		for(j=0;j<=n+1;j++)
			printf("%2d%c",dp[i][j],j==n+1?'\n':' ');
	for(i=1;i<=n;i++)
		for(k=n-i+1;k>=1;k--)
			Mod(ans,1ll*i*k%mod*dp[i][k]%mod);
	printf("%d\n",ans);
	return 0;
}

