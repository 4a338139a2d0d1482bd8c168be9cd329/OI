#include<bits/stdc++.h>
using namespace std;
inline void read(unsigned int &x)
{
	x=0;
	static unsigned int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
unsigned int n,k;
unsigned int powk[1000100];
unsigned int ksm(unsigned int x,unsigned int mc)
{
	unsigned int tmp=x;
	unsigned int res=1;
	while(mc)
	{
		if(mc&1ll)res=res*tmp;
		tmp=tmp*tmp;
		mc>>=1ll;
	}
	return res;
}
int main()
{
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	read(n);read(k);
	for(unsigned int i=1;i<=n;i++)powk[i]=ksm(i,k);
	unsigned int ans=0;
	for(unsigned int i=1;i<=n;i++)
		for(unsigned int j=1;j<=n;j++)
		{
			unsigned int tmp=__gcd(i,j);
			if(tmp==1)continue;
			unsigned int max_rep=tmp;
			for(unsigned int l=2;l<=max_rep;l++)
				if(i%l==0&&j%l==0)
				{
					tmp/=l;
					ans+=powk[tmp];
					break;
				}
		}
	printf("%u\n",ans);
	return 0;
}
