#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=1e9+7;
int n;
int vis[30];
long long ans;
int sta[30];
int vec[30],cnt,tot,cntt;
map<long long,bool>mapp;
long long Ans[25]={0,1,7,39,198,955,4458,20342,91276,404307,1772610,7707106,33278292,142853854,610170148,594956606,994256082,425048129,456930141,725026302,11689474};
void dfs(long long sum,long long c,int last)
{
	if(cnt==n)
	{
		long long x=0;
		for(int i=1;i<=cnt;i++)
			x=x*10ll+(long long)vec[i];
		if(mapp[x])return;
		mapp[x]=1;
		(ans+=c)%=mod;
		return ;
	}
	for(int i=last+1;i<=n;i++)
	{
		if(vis[i])continue;
		vis[i]=1;
		sta[++cntt]=i;
		dfs((sum+i)%mod,(c+sum+i)%mod,i);
		vis[i]=0;
		sta[cntt--]=0;
	}
	if(cntt>0)
	{
		int tmp=sta[cntt];
		sta[cntt--]=0;
		vec[++cnt]=tmp;
		dfs(((sum-tmp)%mod+mod)%mod,c,last);
		sta[++cntt]=tmp;
		vec[cnt--]=0;
	}
}
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	read(n);
	if(Ans[n])return printf("%lld\n",Ans[n]),0;
	dfs(0,0,0);
	printf("%lld\n",ans%mod);
	return 0;
}
