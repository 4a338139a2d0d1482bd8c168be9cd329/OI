#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=1e9+7;
long long n,m;
long long ksm(long long x,long long mc)
{
	long long tmp=x%mod;
	long long res=1;
	while(mc)
	{
		if(mc&1ll)res=res*tmp%mod;
		tmp=tmp*tmp%mod;
		mc>>=1ll;
	}
	return res;
}
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	long long t;
	read(t);
	while(t--)
	{
		read(n);read(m);
		if(n>m)swap(n,m);
		if(n==1){printf("%lld\n",ksm(2,m));continue;}
	}
	return 0;
}
