#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("math.in", "r", stdin);
	freopen ("math.out", "w", stdout);
}

typedef unsigned int ui;

int n, k;

ui fpm(ui x, ui power) { ui res = 1; for (; power; power >>= 1, x *= x) if (power & 1) res *= x; return res; }

const int N = 1e6 + 1e3;
int mu[N], prime[N], f[N], cnt;
ui sum_mu[N];
bitset<N> is_prime;

inline void Init(int maxn) {
	is_prime.set();
	is_prime[0] = is_prime[1] = false;
	sum_mu[1] = mu[1] = 1;
	int res;
	For (i, 2, maxn) {
		if (is_prime[i]) { prime[++cnt] = i; mu[i] = -1; }
		For (j, 1, cnt) {
			if ((res = prime[j] * i) > maxn) break;
			is_prime[res] = false;
			if (i % prime[j]) mu[res] = -mu[i];
			else { mu[res] = 0; break ; }
		}
	}
	For (i, 2, maxn) {
		sum_mu[i] = sum_mu[i - 1] + mu[i];
		for (register int j = i; j <= maxn; j += i) if (!f[j]) f[j] = i;
	}
}

const int Limit = N - 1e3;

map<ui, ui> M;

inline ui Mu_Sum_(ui x) {
	if (x <= Limit) return sum_mu[x]; 
	if (M.count(x)) return M[x];
	register ui res = 1, Nextx;
	For (i, 2, x) {
		Nextx = x / (x / i);
		res -= (ui)(Nextx - i + 1) * Mu_Sum_(x / i);
		i = Nextx;
	}
	return (M[x] = res);
}

int main () {
	File() ;
	cin >> n >> k;
	Init(Limit);
	ui ans = 0;

	if (k == 0) {
		static int Nextd, Nextx, n_;
		For (d, 2, n) {
			Nextd = n / (n / d);
			ui res = 0; n_ = n / d;
			For (x, 1, n_) {
				Nextx = n_ / (n_ / x);
				res += (ui)(Mu_Sum_(Nextx) - Mu_Sum_(x - 1)) * (n_ / x) * (n_ / x);
				x = Nextx;
			}
			ans += res * (Nextd - d + 1);
			d = Nextd;
		}
		cout << ans << endl;

		return 0;
	}

	ans = 0;

	For (d, 2, n) {
	//	cerr << f[d] << endl;
		ui now = fpm(d / f[d], k), sum = 0;
		For (x, 1, n / d)
			sum += (ui)mu[x] * (n / (d * x)) * (n / (d * x));
		ans += now * sum;
	}
	cout << ans << endl;
    return 0;
}
