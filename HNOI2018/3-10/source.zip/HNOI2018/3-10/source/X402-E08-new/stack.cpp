#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("stack.in", "r", stdin);
	freopen ("stack.out", "w", stdout);
}

const int Mod = 1e9 + 7;
const int N = 11;
int a[N], sum[N], n;

int ans = 0;
stack<int> S;
inline int Add(int a, int b, int c) { int res = a + b + c; while (res >= Mod) res -= Mod; return res;}

void Dfs(int cur, int sum, int res) {
	if (cur == n + 1) { if ((ans += res) >= Mod) ans -= Mod; return; }
	if (sum) {
		int now = S.top(); S.pop();
		Dfs(cur, sum - now, res);
		S.push(now);
	}
	S.push(cur);
	Dfs(cur + 1, Add(sum, cur, 0), Add(res, sum, cur));
	S.pop();
}

int Table[100];

inline void Cheat() {
	Table[15] = 594956606;
	Table[16] = 994256082;
	Table[17] = 425048129;
	Table[18] = 456930141;
	Table[19] = 725026302;
	Table[20] = 11689474;
}

int main () {
	File();
	n = read();
	Cheat();
	if (n >= 15) { printf ("%d\n", Table[n]); return 0; }
	Dfs(1, 0, 0);
	printf ("%d\n", ans);
	//cerr << (double)clock() / CLOCKS_PER_SEC << endl;
    return 0;
}
