#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
int ans,n;
void dfs(int dep,int stac[20],int top,int sum,int tot)
{
	if(dep==n+1)
	{
		ans+=tot;
		return;
	}
	sum+=dep;
	for(int i=top;~i;--i)
	{
		stac[i+1]=dep;
		int t[20];
		memcpy(t,stac,sizeof(t));
		dfs(dep+1,t,i+1,sum,tot+sum);
		sum-=stac[i];
	}
}
int main()
{
	freopen("stac.in","r",stdin);
	freopen("stac.out","w",stdout);
	n=read();
	int stac[20]={0};
	dfs(1,stac,0,0,0);
	printf("%d\n",ans);
	return 0;
}
