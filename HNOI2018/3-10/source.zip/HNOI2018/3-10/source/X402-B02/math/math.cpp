#include<bits/stdc++.h>
#define ll long long
#define ull unsigned int

using namespace std;
const int N=1e6+10;
const ll mod=1ll<<32ll;

int p[N+10],pre[N+10],k,phi[N+10],n,cnt;
bool vis[N+10];
ull sphi[N+10];

map<int,ull> mp;

namespace buf{
	void init(){ 
		phi[1]=1;
		for(int i=2; i<=N; ++i){
			if(!vis[i]) {pre[i]=i;p[++cnt]=i;phi[i]=i-1;}
			for(int j=1;j<=cnt&&1ll*i*p[j]<=N;++j){
				vis[i*p[j]]=1;
				pre[i*p[j]]=p[j];
				if(i%p[j]==0){
					phi[i*p[j]]=phi[i]*p[j];	
					break;
				}
				phi[i*p[j]]=phi[i]*phi[p[j]];
			}
		}
	}
	inline ull fpm(ull x,ull y){
		ull s=1;
		while(y){
			if(y&1)s=s*x; y>>=1;
			x=x*x;
		}
		return s;
	}

	ull S(int x){
		if(x<=N) return sphi[x];
		if(mp.count(x)) {return mp[x];}
		ll g=1ll*(x+1)*x/2;
		g%=mod;
		ull p=(ull)g;
		for(int i=2,ni; i<=x; i=ni+1){
			ni=(x/(x/i));
			p-=(ni-i+1)*S(x/i);
		}
		return mp[x]=p;
	}

	void solve(){
		init();
		for(int i=1; i<=N; ++i) sphi[i]=sphi[i-1]+phi[i];
		scanf("%d%d",&n,&k);
		if(k==0){
			ull o=(ull)n*n+1-2*S(n);		
			printf("%u\n",o);
			return;
		}
		ull ans=0;
		for(int i=2; i<=n; ++i){
			ans+=(1ull*(2*sphi[n/i]-1)*fpm(i/pre[i],k));
		}
		printf("%u\n",ans);
	}
}

int main(){
	freopen("math.in","r",stdin);
	freopen("math.out","w",stdout);
	buf::solve();
}
