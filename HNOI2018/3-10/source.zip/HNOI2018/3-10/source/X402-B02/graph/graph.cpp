#include<bits/stdc++.h>
#define ll long long
const int mod=1e9+7;
using namespace std;
int n,m;
namespace buf{
	ll fpm(ll x,ll y){
		ll s=1;
		while(y){
			if(y&1)s=s*x%mod;
			y>>=1; x=x*x%mod;
		}
		return s;
	}
	void solve(){
		int T;
		scanf("%d",&T);
		while(T--){
			scanf("%d%d",&n,&m);
			if(n<m) swap(n,m);
			if(m==1) printf("%lld\n",fpm(2,n*m));
		}
	}
}

int main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	buf :: solve();
}
