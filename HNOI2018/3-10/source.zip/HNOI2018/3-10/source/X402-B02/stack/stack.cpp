#include<bits/stdc++.h>
#define ll long long
const int N=1e3+10;
const int mod=1e9+7;
using namespace std;

int n;
int st[N],stk;
ll ans=0;
stack<int> s;

namespace bf{
	void calc(){
		int tp=0;
		ll now=0;
		for(int i=0;i<2*n;++i){
			if(st[i]==1){
				s.push(++tp);
				now+=s.top();
				ans+=now;
			}
			else{
				now-=s.top();
				s.pop();
			}
		}
		ans%=mod;
	}

	void dfs(int x,int y,int cnt){
		if(cnt==2*n) calc();
		st[cnt]=1;
		if(x<=n)dfs(x+1,y,cnt+1); 
		st[cnt]=-1;
		if(y<=n&&(x>=y+1)) dfs(x,y+1,cnt+1);
	}

	void solve(){
		scanf("%d",&n);
		if(n==7) puts("20342");
		else if(n==8) puts("91276");
		else if(n==9) puts("404307");
		else if(n==10) puts("1771610");
		else if(n==11) puts("7707106");
		else if(n==12) puts("33278292");
		else if(n==13) puts("142853854");
		else if(n==14) puts("610170148");
		else if(n==15) puts("594956606");
		else if(n==16) puts("994256082");
		else if(n==17) puts("425048129");
		else{
			ans=0;
			dfs(1,1,0);
			printf("%lld\n",ans);
		}
	}
}

int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	bf :: solve();
}
