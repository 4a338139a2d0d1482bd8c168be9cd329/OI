#include <bits/stdc++.h>

using namespace std;

int main(){

	freopen("griffin4.in", "w", stdout);

	int n = 60000;
	printf("%d\n", n);
	while (n--) puts(rand() % 2 ? "yycjm" : "jmyyc");

	return 0;
}
