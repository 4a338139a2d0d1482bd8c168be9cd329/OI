#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("poem.in", "r", stdin);
	freopen ("poem.out", "w", stdout);
}
unordered_map<string, int> M;

const int N = 1e5 + 1e3;
int n;
string S[N];

int ans[N];

void Work1() {
	string now;
	For (i, 1, n) {
		int lenth = (int)S[i].size();
		ans[i] = ans[i - 1];
		For (k, 0, lenth) {
			now = "";
			For (j, 0, lenth - k - 1) {
				now += S[i][k + j];
				ans[i] += 2 * (++M[now]) - 1;
			}
		}
	}
	For (i, 1, n) printf ("%d\n", ans[i]);
}

int main () {
	File();
	n = read();
	For (i, 1, n) cin >> S[i];
	Work1();
	cerr << clock() << endl;
    return 0;
}
