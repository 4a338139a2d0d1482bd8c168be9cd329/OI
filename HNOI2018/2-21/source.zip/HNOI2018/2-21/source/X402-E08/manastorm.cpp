#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("manastorm.in", "r", stdin);
	freopen ("manastorm.out", "w", stdout);
}

int n, k;

typedef long long ll;
const int Mod = 998244353;
ll fpm(ll x, int power, ll mod) {
	ll res = 1;
	for (; power; power >>= 1, (x *= x) %= mod)
		if (power & 1) (res *= x) %= mod;
	return res;
}

const int N = 1e5 + 1e3;
ll val[N];

ll dp[310][310];
ll ans;

ll invn;
int cnt = 0;

void Dfs(int cur, int dep) {
	if (dep) {
		ll res = 1;
		For (i, 1, n) if (i ^ cur) (res *= val[i]) %= Mod;
		if (res < 0) res += Mod; 
		(res *= fpm(invn, dep, Mod) ) %= Mod;
		ans += res;
		if (ans >= Mod) ans -= Mod;
	}
	if (dep == k) return ;

	For (i, 1, n) { -- val[i]; Dfs(i, dep + 1); ++ val[i]; }
}

void Work3() {
	invn = fpm(n, Mod - 2, Mod);
	Dfs(0, 0);
	cout << ans << endl;
}

int main () {
	File();
	n = read(); k = read();
	For (i, 1, n) val[i] = read();
	Work3();
    return 0;
}
