#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("griffin.in", "r", stdin);
	freopen ("griffin.out", "w", stdout);
}

int n, m, c;
const int N = 210, M = 8e4 + 1e3;
int Head[N], Next[M], val[M], to[M], e = 0;
void Add(int u, int v, int w) {
	to[++e] = v;
	Next[e] = Head[u];
	Head[u] = e;
	val[e] = w;
}

int lev[N], maxw;
int ans = -1;

int dis[N];
int S = 1, T;
bool inq[N];
const int inf = 0x3f3f3f3f;

void Work1() {
	if (maxw > 0) return ;
	queue<int> Q;
	Set(dis, inf);
	dis[S] = 0; Q.push(S);
	while (!Q.empty() ) {
		int u = Q.front(); inq[u] = false; Q.pop();
		for (int i = Head[u]; i; i = Next[i]) {
			int v = to[i];
			if (chkmin(dis[v], dis[u] + 1) ) if (!inq[v]) { Q.push(v); inq[v] = true; }
		}
	}
	if (dis[T] != inf) ans = dis[T];
}

int dp[N][(int)(1e3 + 1e2)];

void Dp(int u, int w) {
	if (u == T) {chkmin(ans, dp[u][w]); return ;}
	for (int i = Head[u]; i; i = Next[i]) {
		int v = to[i];
		if (w >= val[i] && chkmin(dp[v][min(w + 1, maxw)], dp[u][w] + 1) ) Dp(v, min(w + 1, maxw));
	}
}

void Work2() {
	For (i, 1, e)
		val[i] = lev[val[i]];
	Set(dp, inf);
	dp[1][0] = 0;
	ans = inf; Dp(1, 0); if (ans == inf) ans = -1;
}

int main () {
	File();
	T = n = read(); m = read(); c = read();
	For (i, 1, m) {
		int u = read(), v = read(), w = read();
		Add(u, v, w);
	}
	maxw = 0;
	For (i, 1, c) lev[i] = read(), chkmax(maxw, lev[i]);
	
	if (c == 1) Work1();
	else if (maxw <= (int)(1e3) ) Work2();
	if (ans == -1) puts("Impossible");
	else printf ("%d\n", ans);
    return 0;
}
