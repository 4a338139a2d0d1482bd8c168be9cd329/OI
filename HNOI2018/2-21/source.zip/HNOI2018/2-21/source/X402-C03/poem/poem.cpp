#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+10,maxlen=3e5+10;
int n,ans;
char*s[maxn],ss[maxlen];

inline void calc(char*w,int r){
	int res=0;
	for(int i=1;i<=r;++i){
		char*p=s[i];
		while(p=strstr(p,w))
			++res,++p;
	}
	ans+=res*res;
}

int main(){
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%s",ss);
		s[i]=new char[strlen(ss)+1];
		strcpy(s[i],ss);
	}
	for(int r=1;r<=n;++r){
		ans=0;
		set<string> sets;
		for(int i=1;i<=r;++i)
			for(int j=0;s[i][j];++j)
				for(int k=0;s[i][j+k];++k)
					if(sets.insert(string(s[i]+j,k+1)).second){
						strncpy(ss,s[i]+j,k+1);
						ss[k+1]=0;
						calc(ss,r);
					}
		printf("%d\n",ans);
	}
	return 0;
}
