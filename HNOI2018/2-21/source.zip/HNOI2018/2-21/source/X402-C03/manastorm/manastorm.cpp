#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1e5+10,mod=998244353;
int n,k,a[maxn],ans;

inline ll qpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a%mod)
		if(n&1ll)
			res=res*a%mod;
	return res;
}
void dfs(int rest,int p){
	if(!rest)
		return;
	p=(ll)p*qpow(n,mod-2)%mod;
	for(int i=1;i<=n;++i){
		a[i]=(a[i]+mod-1)%mod;
		ll tmp=1;
		for(int j=1;j<i;++j)
			tmp=tmp*a[j]%mod;
		for(int j=i+1;j<=n;++j)
			tmp=tmp*a[j]%mod;
		ans=(ans+tmp*p)%mod;
		dfs(rest-1,p);
		a[i]=(a[i]+1)%mod;
	}
}

int main(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	if(n==2){
		printf("%lld\n",(a[1]+a[2]-(k-1)*qpow(2,mod-2)%mod+mod)%mod*k%mod*qpow(2,mod-2)%mod);
		return 0;
	}
	dfs(k,1);
	printf("%d\n",ans);
	return 0;
}
