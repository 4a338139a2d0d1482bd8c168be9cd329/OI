#include<bits/stdc++.h>
using namespace std;

template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}

const int maxn=180+5,maxc=50+5,inf=2e9;
int n,m,c,w[maxc],g[maxn][maxn],ans=inf;
int dis[maxn];bool inq[maxn];

struct matrix{
	int lenx,leny;
	long long t[maxn][3],tt[maxn][3];
	matrix(int a,int b){
		lenx=a;leny=b;
		memset(t,0,sizeof(t));
		memset(tt,0,sizeof(tt));
	}
	inline void mark(int a,int b){
		t[a][b>>6]|=1ll<<(b&63);
		tt[b][a>>6]|=1ll<<(a&63);
	}
	inline matrix operator* (const matrix&o){
		matrix res(lenx,o.leny);
		for(int i=0;i<lenx;++i)
			for(int j=0;j<o.leny;++j)
				if(t[i][0]&o.tt[j][0]||t[i][1]&o.tt[j][1]||t[i][2]&&o.tt[j][2])
					res.mark(i,j);
		return res;
	}
};
inline matrix qpow(matrix a,int n){
	matrix res(a.lenx,a.leny);
	for(int i=0;i<res.lenx;++i)
		res.mark(i,i);
	for(;n;n>>=1,a=a*a)
		if(n&1ll)
			res=res*a;
	return res;
}
inline void spfa(matrix&beg,int c){
	queue<int> q;
	for(int i=0;i<n;++i)
		if(beg.t[0][i>>6]>>(i&63)&1){
			q.push(i);
			inq[i]=true;
			dis[i]=0;
		}
		else
			dis[i]=inf;
	while(!q.empty()){
		int pos=q.front();q.pop();
		inq[pos]=false;
		for(int i=0;i<n;++i)
			if(g[pos][i]<=c&&dis[i]>dis[pos]+1){
				dis[i]=dis[pos]+1;
				if(!inq[i]){
					inq[i]=true;
					q.push(i);
				}
			}
	}
}

int main(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	scanf("%d%d%d",&n,&m,&c);
	for(int i=0;i<n;++i)
		for(int j=0;j<n;++j)
			g[i][j]=inf;
	for(int i=1;i<=m;++i){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		--u;--v;
		if(g[u][v]>w)g[u][v]=w;
	}
	for(int i=1;i<=c;++i)
		scanf("%d",&w[i]);
	matrix now(1,n);
	now.mark(0,0);
	for(int i=0;i<c;++i){
		spfa(now,i);
		if(dis[n-1]!=inf)
			chkmin(ans,w[i]+dis[n-1]);
		matrix base(n,n);
		for(int j=0;j<n;++j)
			for(int k=0;k<n;++k)
				if(i>=g[j][k])
					base.mark(j,k);
		now=now*qpow(base,w[i+1]-w[i]);
	}
	spfa(now,c);
	if(dis[n-1]!=inf)
		chkmin(ans,w[c]+dis[n-1]);
	if(ans<inf)
		printf("%d\n",ans);
	else
		puts("Impossible");
	return 0;
}
