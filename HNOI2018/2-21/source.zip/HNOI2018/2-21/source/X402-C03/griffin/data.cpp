#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("griffin.in","w",stdout);
	int seed;
	srand(seed=time(NULL)+clock()*clock());
	cerr<<seed<<endl;
	int n=180,m=rand()%40000,c=50,dt=2e7;
	n=15;m=rand()%700;c=10;dt=100;
	printf("%d %d %d\n",n,m,c);
	while(m--)
		printf("%d %d %d\n",rand()%n+1,rand()%n+1,rand()%c+1);
	int x=0;
	if(rand()%dt==0)
		x=rand()%dt;
	for(int i=1;i<=c;++i){
		printf("%d ",x);
		x+=rand()%dt+1;
	}
	return 0;
}
