#include<bits/stdc++.h>
using namespace std;

const int maxn=180+10,maxc=50+10;
int n,m,c,w[maxc],g[maxn][maxn];
bool now[maxn],tmp[maxn];
int dis[maxn];bool inq[maxn];

int main(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.txt","w",stdout);
	scanf("%d%d%d",&n,&m,&c);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			g[i][j]=1e9;
	for(int i=1;i<=m;++i){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		if(g[u][v]>w)g[u][v]=w;
	}
	for(int i=1;i<=c;++i)
		scanf("%d",&w[i]);
	now[1]=true;
	for(int i=0;i<w[c];++i){
		if(now[n]){
			printf("%d\n",i);
			return 0;
		}
		for(int j=1;j<=n;++j)
			tmp[j]=false;
		for(int j=1;j<=n;++j)
			if(now[j])
				for(int k=1;k<=n;++k)
					if(g[j][k]!=1e9&&i>=w[g[j][k]])
						tmp[k]=true;
		for(int j=1;j<=n;++j)
			now[j]=tmp[j];
	}
	queue<int> q;
	for(int i=1;i<=n;++i)
		if(now[i]){
			q.push(i);
			inq[i]=true;
		}
		else
			dis[i]=1e9;
	while(!q.empty()){
		int pos=q.front();q.pop();
		inq[pos]=false;
		for(int i=1;i<=n;++i)
			if(g[pos][i]!=1e9&&dis[i]>dis[pos]+1){
				dis[i]=dis[pos]+1;
				if(!inq[i]){
					inq[i]=true;
					q.push(i);
				}
			}
	}
	if(dis[n]!=1e9)
		printf("%d\n",dis[n]+w[c]);
	else
		puts("Impossible");
	return 0;
}
