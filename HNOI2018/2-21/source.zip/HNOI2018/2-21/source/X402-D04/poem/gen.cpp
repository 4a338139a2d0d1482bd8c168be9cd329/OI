#include<bits/stdc++.h>
using namespace std;

int n;

int main(){
	freopen("poem2.in","w",stdout);

	srand(time(0));
	printf("%d\n", n=1);
	for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=3000;j++) printf("%c", rand()%26+'a');
	return 0;
}
