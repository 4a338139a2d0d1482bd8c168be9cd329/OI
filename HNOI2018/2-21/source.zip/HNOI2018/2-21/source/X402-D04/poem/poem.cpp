#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
int n;
string s[maxn];
struct node{
	string s;
	vector<int> sum;
}a[3010*3010];
int cnt;
map<string,int> mp;

int calc(int x,int y){
	int l=a[y].s.length();
	if(a[y].s.length()>s[x].length()) return 0;
	int ret=0, len=s[x].length();
	for(int i=0;i+l<=len;i++) ret+=!((bool)s[x].compare(i,l,a[y].s));
	// printf("ret = %d\n", ret);
	return ret;
}

int main(){
	freopen("poem.in","r",stdin),freopen("poem.out","w",stdout);

	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		cin>>s[i];
		string t;
		int len=s[i].length();
		for(int l=0;l<len;l++){
			t.clear();
			for(int r=l;r<len;r++){
				t+=s[i][r];
				if(mp.count(t)) continue;
				mp[t]=1;
				a[++cnt].s=t;
				// cerr<<cnt<<endl;
			}
		}
	}
	// for(int i=1;i<=cnt;i++) cout<<a[i].s<<endl;
	// printf("cnt = %d\n", cnt);
	for(int i=1;i<=cnt;i++){
		a[i].sum.push_back(0);
		for(int j=1;j<=n;j++){
			a[i].sum.push_back(a[i].sum[j-1]+calc(j,i));
		}
		// for(int j=1;j<=n;j++) printf("%d ", a[i].sum[j]); puts("");
	}
	ll ans=0;
	for(int r=1;r<=n;r++){
		ans=0;
		for(int j=1;j<=cnt;j++) ans+=a[j].sum[r]*a[j].sum[r];
		/*
		for(int i=1;i<=r;i++){
			for(int j=1;j<=cnt;j++)
				ans+=(a[j].sum[i]-a[j].sum[i-1])*a[j].sum[r];
		}
		*/
		printf("%lld\n", ans);
	}
	return 0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=cnt;j++){
			ans+=(a[j].sum[i]-a[j].sum[i-1])*a[j].sum[i];
		}
		printf("%lld\n", ans);
	}
	return 0;
}
