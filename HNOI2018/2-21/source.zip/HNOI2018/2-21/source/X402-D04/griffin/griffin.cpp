#include<bits/stdc++.h>
using namespace std;

const int maxn=200;
const int maxm=40010;
int n, m, c;
int val[maxn];
vector<int> g[maxn], w[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

struct node{ int x, v; };
int vis[maxn][maxm];
queue<node> q;

int main(){
	freopen("griffin.in","r",stdin),freopen("griffin.out","w",stdout);

	read(n); read(m); read(c);
	int u, v, z;
	for(int i=1;i<=m;i++){
		read(u), read(v), read(z);
		g[u].push_back(v); w[u].push_back(z);
	}
	for(int i=1;i<=c;i++) read(val[i]);
	q.push((node){1, 0}); vis[1][0]=1;
	while(!q.empty()){
		node pi=q.front(); q.pop();
		int x=pi.x, v=pi.v;
		if(x==n){
			printf("%d\n", v);
			return 0;
		}
		for(int i=0;i<g[x].size();i++){
			int u=g[x][i], t=val[ w[x][i] ];
			if(v>=t && !vis[u][v+1]) q.push((node){u, v+1}), vis[u][v+1]=1;
		}
	}
	puts("Impossible");
	return 0;
}
