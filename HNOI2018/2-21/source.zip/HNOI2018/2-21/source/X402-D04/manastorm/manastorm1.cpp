#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=998244353;
int n, k;
int a[maxn];

ll ans;
ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}
void dfs(int x,ll now,ll pro){
	if(x>k){
		(ans+=now*pro%mod)%=mod;
		 printf("%lld %lld pro=%lld\n", now, ans, pro);
		return;
	}
	ll t=0, inv=n;
	inv=Pow(n, mod-2);
	for(int i=1;i<=n;i++) (t+=a[i])%=mod;
	pro=pro*inv%mod;
	for(int i=1;i<=n;i++){
		//ans=(ans+1ll*(t-a[i])*pro%mod+mod)%mod;
		// printf("%lld\n", 1ll*(t-a[i])*pro%mod);
		a[i]--;
		dfs(x+1, (now+(t-a[i]-1+mod)%mod)%mod, pro);
		a[i]++;
	}
}

int main(){
	freopen("manastorm.in","r",stdin),freopen("manastorm.out","w",stdout);

	scanf("%d%d", &n, &k);
	for(int i=1;i<=n;i++) scanf("%d", &a[i]);
	dfs(1, 0, 1);
	printf("%lld\n", ans);
	return 0;
}
