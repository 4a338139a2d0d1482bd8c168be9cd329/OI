#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=998244353;
int n, k;
int a[maxn];

ll ans;
ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}
int cnt;
void dfs(int x,ll now){
	// printf("-------x = %d\n", x);
	if(x>k){
		cerr<<++cnt<<endl;
		(ans+=now+mod)%=mod;
		// printf("now = %lld %lld\n", now, ans);
		return;
	}
	ll t=1;
	// printf("t = %lld\n", t);
	// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
	for(int i=1;i<=n;i++){
		t=1;
		for(int j=1;j<=n;j++) if(i!=j) t=t*a[j]%mod;
		//ans=(ans+1ll*(t-a[i])*pro%mod+mod)%mod;
		// printf("%lld\n", 1ll*(t-a[i])*pro%mod);
		a[i]--;
		// printf("i = %d %d\n");
		// printf("tt = %lld\n", t);
		dfs(x+1, (now+t)%mod);
		a[i]++;
	}
}

int main(){
	freopen("manastorm.in","r",stdin),freopen("manastorm.out","w",stdout);

	scanf("%d%d", &n, &k);
	for(int i=1;i<=n;i++) scanf("%d", &a[i]);
	dfs(1, 0);
	ll pro=Pow(Pow(n, mod-2), k);
	ans=ans*pro%mod;
	printf("%lld\n", ans);
	return 0;
}
