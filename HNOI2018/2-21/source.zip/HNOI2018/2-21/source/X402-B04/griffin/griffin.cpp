/*
Author: CNYALI_LK
LANG: C++
PROG: griffin.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
int beg[1926],to[102424],lst[102424],e;
int s[1926];
void add(int u,int v,int w){
	to[++e]=v;
	lst[e]=beg[u];
	beg[u]=e;
}
int q[102424],*l,*r;
int zdl[1926];
void bfs(int u){
	*(l=r=q)=u;	
	memset(zdl,-1,sizeof(zdl));
	zdl[u]=0;
	while(l<=r){
		for(int i=beg[*l];i;i=lst[i])if(!~zdl[to[i]]){zdl[to[i]]=zdl[*l]+1;*(++r)=to[i];}
		++l;
	}
}
int main(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	int n,m,c;
	n=read();m=read();c=read();
	for(int i=1;i<=m;++i){
		int u,v,w;
		u=read();v=read();w=read();
		add(u,v,w);
	}
	for(int i=1;i<=c;++i)s[i]=read();
	if(s[1])printf("Impossible\n");
	else{
		bfs(1);
		if(!~zdl[n])	printf("Impossible\n");
		else printf("%d\n",zdl[n]);
	}
	return 0;
}

