#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	x=x*w;
}
inline void File(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
}

const int maxn=200,maxm=40000+10,maxc=55,inf=0x7f7f7f7f;
int n,m,c;
int e,beg[maxn],nex[maxm],to[maxm],w[maxm];
int wc[maxc];

inline void add(int x,int y,int z){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}

#include<queue>
inline int tsk1(){
	int vis[maxn];
	queue<int> q;
	for(Rint i=1;i<=n;i++)vis[i]=inf;
	q.push(1);
	vis[1]=0;
	while(!q.empty()){
		int x=q.front();q.pop();
		for(Rint i=beg[x];i;i=nex[i]){
			int y=to[i];
			if(y==x)continue;
			vis[y]=min(vis[y],vis[x]+1);
			q.push(y);
		}
	}
	return vis[n]==inf?-1:vis[n];
}

int main(){
	File();
	read(n);read(m);read(c);
	for(Rint i=1;i<=m;i++){
		int u,v,lv;
		read(u);read(v);read(lv);
		add(u,v,lv);
	}
	for(Rint i=1;i<=c;i++)read(wc[i]);
	if(c==1){
		if(wc[1]!=0){
			printf("Impossible\n");
			return 0;
		}
		int p=tsk1();
		if(p!=-1)printf("%d\n",p);
		else printf("Impossible\n");
		return 0;
	}
//	spfa();
	return 0;
}
