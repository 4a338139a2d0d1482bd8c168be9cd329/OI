#include<iostream>
#include<cstdio>
#define next Next
#define inf (0x3f3f3f3f)
using namespace std;
const int maxn=180+10,maxm=4e4+10;
int head[maxn],next[maxm],to[maxm],v[maxm];
int vis[maxn],w[maxm],n,m,c,e,ans=inf;
struct node{
	int x,y,z;
}a[maxm];

void file(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
}

void add(int x,int y,int z){
	to[++e]=y;
	next[e]=head[x];
	head[x]=e;
	v[e]=z;
}

void init(){
	scanf("%d%d%d",&n,&m,&c);
	for(int i=1;i<=m;++i)
		scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].z);
	for(int i=1;i<=c;++i)
		scanf("%d",&w[i]);
	for(int i=1;i<=m;++i)
		add(a[i].x,a[i].y,w[a[i].z]);
}

void dfs(int x,int s){
	if(x==n){	
		ans=min(ans,s);
		return;
	}
	if(vis[x]>1000)
		return;
	++vis[x];
	for(int i=head[x];i;i=next[i])
		if(s>=v[i])
			dfs(to[i],s+1);
}

void solve(){
	dfs(1,0);
	if(ans==inf)
		printf("Impossible");
	else
		printf("%d\n",ans);
}
int main(){	
	file();
	init();
	solve();
	return 0;
}
