#include<iostream>
#include<cstdio>
#define inv(x) (ksm(x,mod-2))
typedef long long ll;
using namespace std;
const int maxn=1e5+10,mod=998244353;
int a[maxn],n,k;
ll ans=0,qaq=1,inv;
ll ksm(ll a,ll k){
	ll ans=1;
	while(k){
		if(k&1)
			ans=ans*a%mod;
		k/=2;
		a=a*a%mod;
	}
	return ans%mod;
}
void dfs(int x,int s,ll sum,ll gailu){
	if(s>n){
		cout<<sum<<endl;
		ans=(ans+sum)%mod;
		return;
	}
	ll ovo=gailu;a[x]--;
	for(int i=1;i<=n;++i)
		ovo=(ovo*(i==x?1:a[i])+mod)%mod;
	for(int i=1;i<=n;++i)
		dfs(i,s+1,(sum+ovo)%mod,gailu*inv%mod);
	a[x]++;
}
int main(){
	scanf("%d%d",&n,&k);
	inv=inv(n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]),qaq=qaq*inv%mod;
	for(int i=1;i<=n;++i)
		dfs(i,1,0,inv);
	printf("%lld",ans);
	return 0;
}
