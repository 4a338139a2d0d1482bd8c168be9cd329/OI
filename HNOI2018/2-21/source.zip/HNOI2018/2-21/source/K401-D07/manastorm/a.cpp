#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
const int maxn=1e6*3+10;
ll n,mod;
ll inv[maxn];
int main(){
    cin>>n>>mod;
    inv[1]=1;
    printf("%lld\n",inv[1]);
    for(register int i=2;i<=n;++i)
        inv[i]=(mod-mod/i)*inv[mod%i]%mod,printf("%lld\n",inv[i]);;

    return 0;
}

