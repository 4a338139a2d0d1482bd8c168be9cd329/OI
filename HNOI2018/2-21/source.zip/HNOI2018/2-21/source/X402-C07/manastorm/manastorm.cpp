#include<cstdio>
#include<algorithm>
using namespace std;

long long a[100012];
long long ans=0,n,k;

const int mod=998244353;
long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

void dfs(int k){
	if (k==0)
	  return ;
	for (int i=1;i<=n;i++)
	{
	  a[i]-=1;
	  long long num=1;
	  for (int j=1;j<=n;j++)
	    if (i!=j)
	      num=(num*a[j]%mod+mod)%mod;
	  num=num*mi(n,k-1)%mod;
	  ans=((ans+num)%mod+mod)%mod;
	  dfs(k-1);
	  a[i]+=1;
	}
}

int main(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for (int i=1;i<=n;i++)
	  scanf("%lld",&a[i]);
	dfs(k);
	long long tot=mi(n,k);
	ans=ans*mi(tot,mod-2)%mod;
	printf("%lld\n",ans);
	return 0;
}
