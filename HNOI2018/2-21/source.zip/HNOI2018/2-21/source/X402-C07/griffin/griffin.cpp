#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;

int tot=0,pre[40012],son[40012],now[212],v[40012];
int n,m,c,dis[212],w[212],aa[40012],bb[40012],cc[40012];
bool f[212][10012];
void add(int a,int b,int c){
	tot++;
	pre[tot]=now[a];
	now[a]=tot;
	son[tot]=b;
	v[tot]=w[c];
}
int main(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	scanf("%d%d%d",&n,&m,&c);
	if (c==1)
	{
	  for (int i=1;i<=m;i++)
	  	scanf("%d%d%d",&aa[i],&bb[i],&cc[i]);
	  for (int i=1;i<=c;i++)
	    scanf("%d",&w[i]);
	  for (int i=1;i<=m;i++)
	    add(aa[i],bb[i],cc[i]);
	  if (w[1]!=0)
	  {
	    printf("Impossible\n");
	    return 0;
	  }
	  else
	  {
	  	queue<int> h;
	  	for (int i=1;i<=n;i++)
	  	  dis[i]=0x3f3f3f3f;
		h.push(1);
		dis[1]=0;
	  	while (!h.empty())
	  	{
	  	  int x=h.front();
	  	  h.pop();
	  	  for (int p=now[x];p>0;p=pre[p])
	  	  {
	  	  	int s=son[p];
	  	  	if (dis[s]>dis[x]+1)
	  	  	{
	  	  	  dis[s]=dis[x]+1;
	  	  	  h.push(s);
	  	    }
	  	  }
	    }
	    if (dis[n]==0x3f3f3f3f)
	    {
	      printf("Impossible\n");
	      return 0;
	    }
	    else
	    {
	      printf("%d\n",dis[n]);
	      return 0;
	    }
	  }
	}
	for (int i=1;i<=m;i++)
	  scanf("%d%d%d",&aa[i],&bb[i],&cc[i]);
	for (int i=1;i<=c;i++)
	  scanf("%d",&w[i]);
	for (int i=1;i<=m;i++)
	  add(aa[i],bb[i],cc[i]);
	f[1][0]=1;
	queue<int> h;
	queue<int> k;
	h.push(1);
	k.push(0);
	while (!h.empty())
	{
	  int x=h.front();
	  int y=k.front();
	  h.pop();
	  k.pop();
	  if (y>w[c]*10)
	    continue;
	  for (int p=now[x];p>0;p=pre[p])
	  {
	  	int s=son[p];
	  	if (v[p]>y)
	  	  continue;
	  	if (f[s][y+1]==0)
	  	{
	  	  f[s][y+1]=1;
	  	  h.push(s);
	  	  k.push(y+1);
	    }
	  }
	}
	for (int i=0;i<=w[c]*2;i++)
	  if (f[n][i]==1)
	  {
	    printf("%d\n",i);
	    return 0;
	  }
	printf("Impossible\n");
	return 0;
}
