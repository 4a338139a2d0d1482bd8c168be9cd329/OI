#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

int ans=0,n,len[10012];
char s[10012][10012];

int doing(int pos,int a,int b,int kace){
	int tot=0;
	for (int i=1;i<=kace;i++)
	{
	  int w=b-a+1;
	  for (int j=1;j<=len[i]-w+1;j++)
	  {
	    int k=1;
		for (k;k<=w;k++)
		  if (s[pos][a+k-1]!=s[i][j+k-1])
			break;
		if (k==w+1)
		  tot++;
	  }
	}
	return tot;
}

int main(){
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	  scanf("%s",s[i]+1),len[i]=strlen(s[i]+1);
	for (int kace=1;kace<=n;kace++)
	{
	  ans=0;
	  for (int i=1;i<=kace;i++)
	  {
	    for (int a=1;a<=len[i];a++)
	      for (int b=a;b<=len[i];b++)
	      {
			int w=b-a+1,tot=0,ok=0;
	        for (int j=1;j<=len[i]-w+1;j++)
	        {
	      	  int k=1;
			  for (k;k<=w;k++)
			  {
				if (s[i][a+k-1]!=s[i][j+k-1])
			      break;
			  }
			  if (k==w+1)
			  {
			    tot++;
			    if (j<a)
			    {
				  ok=1;
				  break;
				}
			  }
		    }
		    if (ok==1)
		      continue;
		    if (tot>0)
		  	  tot*=doing(i,a,b,kace);
		    ans+=tot;
		  }
	  }
	  printf("%d\n",ans);
	}
	return 0;
}
