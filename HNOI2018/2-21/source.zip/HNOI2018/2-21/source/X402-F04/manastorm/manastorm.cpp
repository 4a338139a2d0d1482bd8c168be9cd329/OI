//2018-2-21
//miaomiao
//Read()
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (100000 + 5)

const int P = 998244353;

inline int Mod(int a){
	if(a < 0) return a + P;
	return a >= P? a - P: a;
}
inline int Mul(int a, int b){
	return 1ll * Mod(a) * Mod(b) % P;
}

int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = Mul(ret, a);
		a = Mul(a, a), anum >>= 1;
	}
	return ret;
}

int n, m, revn, sum, a[N];

int Dfs(int now, int tot, int cs){
	if(now > m) return Mul(tot, cs);

	int ret = 0;

	For(i, 1, n){
		--a[i];

		int tmp = 1;
		For(j, 1, n) if(i != j) tmp = Mul(tmp, a[j]);
		ret = Mod(ret + Dfs(now + 1, Mod(tot + tmp), Mul(revn, cs)));
		
		++a[i];
	}
	return ret;
}

int main(){
	freopen("manastorm.in", "r", stdin);
	freopen("manastorm.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	For(i, 1, n){
		scanf("%d", &a[i]);
		sum = Mod(sum + a[i]);
	}

	if(n == 2){
		int tmp = Mul(n - 1, Pow(n, P - 2));
		
		int ans = Mul(m, Mul(tmp, sum)) +
		          Mul(tmp, Mod(1ll * m * (m + 1) / 2 % P - Mul(m, m)));
		printf("%d\n", Mod(ans));
		return 0;
	}

	revn = Pow(n, P - 2);
	printf("%d\n", Dfs(1, 0, 1));

	return 0;
}
