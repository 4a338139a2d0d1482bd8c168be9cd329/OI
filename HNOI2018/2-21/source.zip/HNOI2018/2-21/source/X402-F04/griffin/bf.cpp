//2018-2-21
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (180 + 5)
#define M (100000 + 5)
const int oo = 0x3f3f3f3f;

struct node{
	int v, lv;
};

int n, m, c, f[N][M], w[N];
bool vis[N];

queue<node> q;
vector<node> G[N];

void Dfs(int now){
	if(vis[now]) return;
	vis[now] = true;
	For(i, 0, G[now].size() - 1) Dfs(G[now][i].v);
}

bool Check(){
	Dfs(1);
	return vis[n];
}

int main(){
	freopen("griffin.in", "r", stdin);
	freopen("griffin.out", "w", stdout);
	
	int u, v, lv;

	scanf("%d%d%d", &n, &m, &c);
	For(i, 1, m){
		scanf("%d%d%d", &u, &v, &lv);
		G[u].pb((node){v, lv});
	}
	For(i, 1, c) scanf("%d", &w[i]);

	if(c == 1 && w[1]){
		puts("Impossible"); return 0;
	}
	if(!Check()){
		puts("Impossible"); return 0;
	}

	f[1][0] = true; q.push((node){1, 0});
	
	while(!q.empty()){
		int now = q.front().v, mw = q.front().lv; q.pop();
		
		if(now == n){
			printf("%d\n", mw); return 0;
		}

		For(i, 0, G[now].size() - 1) if(mw >= w[G[now][i].lv]){
			if(f[G[now][i].v][mw + 1]) continue;
			f[G[now][i].v][mw + 1] = true;
			q.push((node){G[now][i].v, mw + 1});
		}
	}
	puts("Impossible");

	return 0;
}
