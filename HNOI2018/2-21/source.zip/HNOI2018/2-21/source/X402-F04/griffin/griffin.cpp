//2018-2-21
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define K (50 + 5)
#define N (180 + 5)
#define M (40000 + 5)
const int oo = 0x3f3f3f3f;

inline bool Get(int a, int &b){
	if(a < b){
		b = a; return true;
	}
	return false;
}

int n, m, k;

struct Matrix{
	bool s[N][N];

	Matrix(int type = 0){
		Set(s, 0);
		if(type) For(i, 1, n) s[i][i] = 1;
	}
}G[K];

struct Vector{
	bool s[N];
	Vector(){Set(s, 0);}
};

Matrix operator * (Matrix &A, Matrix &B){
	Matrix ret;
	bitset<N> a[N], b[N];

	Set(ret.s, 0);
	For(i, 1, n) a[i].reset(), b[i].reset();
	For(i, 1, n) For(j, 1, n) a[i][j] = A.s[i][j], b[i][j] = B.s[j][i];
	For(i, 1, n) For(j, 1, n) ret.s[i][j] = (a[i] & b[j]).count() > 0? 1: 0;

	return ret;
}

Vector operator * (Matrix &A, Vector &B){
	Vector ret;
	Set(ret.s, 0);
	
	For(i, 1, n)
		for(int j=1; j<=n && !ret.s[i]; j++) ret.s[i] |= A.s[j][i] & B.s[j];
	return ret;
}

Matrix Pow(Matrix A, int anum){
	Matrix ret(1);
	while(anum){
		if(anum & 1) ret = ret * A;
		A = A * A; anum >>= 1;
	}
	return ret;
}

Vector A;
Matrix B;
int w[K], f[K][N];

void Calc(int me){
	queue<int> q;
	while(!q.empty()) q.pop();
	For(i, 1, n) f[me][i] = oo;

	q.push(n); f[me][n] = 0;
	while(!q.empty()){
		int now = q.front(); q.pop();
		For(i, 1, n)
			if(G[me].s[i][now] && Get(f[me][now] + 1, f[me][i])) q.push(i);
	}
}

void Solve(){
	A.s[1] = 1;
	int ans = oo;

	For(i, 0, k){
		For(p, 1, n) if(A.s[p]) Get(w[i] + f[i][p], ans);
		if(i == k) break;
		B = Pow(G[i], w[i+1] - w[i]); A = B * A;
	}

	if(ans == oo) printf("Impossible\n");
	else printf("%d\n", ans);
}

int main(){
	freopen("griffin.in", "r", stdin);
	freopen("griffin.out", "w", stdout);
	
	int u, v, lev;

	scanf("%d%d%d", &n, &m, &k);
	For(i, 1, m){
		scanf("%d%d%d", &u, &v, &lev);
		G[lev].s[u][v] = true;
	}

	For(i, 1, k) scanf("%d", &w[i]);
	For(p, 2, k) For(i, 1, n) For(j, 1, n) G[p].s[i][j] |= G[p - 1].s[i][j];
	For(i, 0, k) Calc(i);

	Solve();

	return 0;
}
