#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;
const int maxn=185,maxm=4e4+100,maxc=55;
int n,m,c,beg[maxn],lev[maxm],nxt[maxm],to[maxm],e,w[maxc],ans=-1;
inline void add(int u,int v,int w)
{
	to[++e]=v;
	nxt[e]=beg[u];
	beg[u]=e;
	lev[e]=w;
}
struct node {
	int now,len;
	node(){now=len=0;}
};
int maintain()
{
	queue<node>que;
	node start;start.now=1;
	que.push(start);
	while(!que.empty())
	{
		node now=que.front(),next;
		que.pop();
		if(now.now==n)
		{
			ans=now.len;
			return now.len;
		}
		if(now.len>n*n*n)return 0;
		for(int i=beg[now.now];i;i=nxt[i])
		{
			if(w[lev[i]]<=now.len)
			{
				next=now;next.now=to[i];next.len++;
				que.push(next);
			}
		}
	}
	return 0;
}
int main()
{
#ifndef LOCAL_RUN
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
#endif
	scanf("%d%d%d",&n,&m,&c);
	for(int i=1,u,v,lv;i<=m;++i)
	{
		scanf("%d%d%d",&u,&v,&lv);
		add(u,v,lv);
	}
	for(int i=1;i<=c;++i)
		scanf("%d",w+i);
	maintain();
	~ans?printf("%d\n",ans):printf("Impossible\n");
	return 0;
}
