#include <cstdio>
#include <cmath>
#include <cstring>
const int mod=998244353;
int main()
{
	
	return 0;
}
