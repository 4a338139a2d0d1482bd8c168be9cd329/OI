#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
long long a[100010],g[1000010],f[1010][1010];
long long mod=998244353,n,ans,k;
long long lily(long long x,long long y){
	long long ans1=1,k=x;
	while(y>0){
		if(y%2){ans1=(ans1*k)%mod;}
		k=(k*k)%mod;
		y/=2;
	}
	return ans1;
}
long long js(long long k1){
	long long i,ans2=1;
	for(i=1;i<=n;i++)
	     if(k1!=i){
	     	ans2=(ans2*a[i])%mod;
	     }
	return ans2+mod;
}
	     	
void dfs(long long x,long long y,long long u,long long k1){
	long long i;
	if(x==k+1){
		//printf("%lld %lld\n",js(k1),y);
		ans=(ans+(u*y)%mod)%mod;
		return;
	}
	for(i=1;i<=n;i++){
		a[i]--;
		//printf("----------%lld\n",lily(2,3));
	    dfs(x+1,(y*lily(n,mod-2))%mod,(u+js(i))%mod,i);
	    a[i]++;
	}
}
		
int main(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	long long i,j,m,u;
	scanf("%lld%lld",&n,&k);
	for(i=1;i<=n;i++)
	     scanf("%lld",&a[i]);
	dfs(1,1,0,0);
	printf("%lld\n",ans);
	
	    
	        
	    
	return 0;
}/*
9 2
0 11 12 9 20 7 8 18 2
*/


