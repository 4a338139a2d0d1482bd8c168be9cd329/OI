#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int m,n,d,a[210][210],v[20010],ans[210][10010],find1[210][10010],v1[210],u[20010],l[20010],p[100010],maxw;
struct node{
	int x,dis;
}q[100010];
int dfs(int x,int y){
	int i;
	if(find1[x][y])return ans[x][y];
	if(x==n)return y;
	if(y>maxw)return ans[x][y]=y-maxw+dfs(x,maxw);
	find1[x][y]=1;
	ans[x][y]=1000000010;
	for(i=1;i<=n;i++){
		//if(i==1)printf("-----%d\n",a[1][1]);
	     if(a[x][i]<1000000010 && a[x][i]<=y){
		      int h=dfs(i,y+1);
			  ans[x][y]=min(ans[x][y],h);
		}
	}
	//printf("%d %d %d\n",x,y,ans[x][y]);
	return ans[x][y];
}
void bfs(int x){
	int r=0,l=1,i;
	q[0].x=x;
	q[0].dis=0;
	v1[x]=1;
	while(r<l){
		int xx=q[r].x,dis=q[r].dis;
		if(xx==n){
			printf("%d\n",dis);
			return;
		}
		r++;
		for(i=1;i<=n;i++){
			if(!v1[i] && a[xx][i]<1000000010 && a[xx][i]<=dis){
		        v1[i]=1;
				q[l].x=i;
				q[l].dis=dis+1;
				l++;
			}
		}
	}
	printf("Impossible\n");
}
int main(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	int i,j,k;
	scanf("%d%d%d",&n,&m,&d);
	for(i=1;i<=n;i++)
	    for(j=1;j<=n;j++)
	         a[i][j]=1000000010;
	for(i=1;i<=m;i++){
		scanf("%d%d%d",&u[i],&v[i],&l[i]);
	}
	for(i=1;i<=d;i++)
	    scanf("%d",&p[i]);
	for(i=1;i<=m;i++){
		  a[u[i]][v[i]]=min(a[u[i]][v[i]],p[l[i]]);
	}
	for(i=1;i<=m;i++){
		maxw=max(maxw,a[u[i]][v[i]]);
	}
	if(d==1){
		if(a[u[1]][v[1]]!=0){printf("Impossible\n");return 0;}
		bfs(1);
		return 0;
	}
	int gh=dfs(1,0);
	if(gh==1000000010)printf("Impossible\n");
	else printf("%d\n",gh);
	return 0;
}/*
3 3 1
1 2 1
2 1 1
2 3 1
0 
*/

