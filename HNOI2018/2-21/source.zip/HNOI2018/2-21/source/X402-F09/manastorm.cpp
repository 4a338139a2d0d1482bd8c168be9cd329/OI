#include<bits/stdc++.h>
using namespace std;
const int maxn=100010,mod=998244353;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
long long ans;
int k,n,a[maxn];
inline long long quickmod(long long a,long long b){
	long long ret=1;
	while(b){
		if(b&1)ret=ret*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ret;
}
inline void dfs(int x,long long cnt,long long pos){
	if(x==k){
		(ans+=(((cnt%mod)+mod)%mod*pos)%mod)%=mod;
		return ;
	}
	for(register int i=1;i<=n;++i){
		a[i]--;
		long long now=1;
		for(register int j=1;j<=n;++j){
			if(j!=i)(now*=a[j])%=mod;
        }
		dfs(x+1,(cnt+now)%mod,(pos*quickmod(n,mod-2))%mod);
		a[i]++;
	}
}
int main(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	read(n);read(k);
	for(register int i=1;i<=n;++i){
        read(a[i]);
    }
	dfs(0,0,1);
	printf("%lld\n",ans);
	return 0;
}
