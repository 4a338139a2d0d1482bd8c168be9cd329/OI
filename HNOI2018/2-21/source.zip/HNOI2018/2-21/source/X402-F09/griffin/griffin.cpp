#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=200;
const int maxm=40005;
const int maxc=55;
typedef pair<int,int> pa;
#define mp make_pair
#define x first
#define y second
struct edge{
    int to,next,w;
}e[maxm<<1];
int head[maxn],n,m,c,tot;
bool flag;
inline int _min(int a,int b){
    return a<b?a:b;
}
inline void add(int u,int v,int w){
    e[++tot].to=v;
    e[tot].next=head[u];
    e[tot].w=w;
    head[u]=tot;
}
map<pa,int>ma;
inline void spfa(){
    queue< pa >qu;
    qu.push(mp(1,0));
    while(!qu.empty()){
        pa u=qu.front();
        qu.pop();
        for(register int i=head[u.x];i;i=e[i].next){
            if(u.y>=e[i].w){
                if(e[i].to==n){
                    flag=1;
                    printf("%d\n",u.y+1);
                    return ;
                }
                if(!ma[mp(e[i].to,u.y+1)]){
					qu.push(mp(e[i].to,u.y+1));
					ma[mp(e[i].to,u.y+1)]=1;
				}
            }
        }
    }
}
int gra[maxn][maxn],w[maxc];
int main(){
    freopen("griffin.in","r",stdin);
    freopen("griffin.out","w",stdout);
    read(n);read(m);read(c);
    memset(gra,0x3f,sizeof(gra));
    int inf=gra[1][1];
    for(register int i=1;i<=m;++i){
        int u,v,lv;
        read(u);read(v);read(lv);
        gra[u][v]=_min(gra[u][v],lv);
    }
    for(register int i=1;i<=c;++i){
        read(w[i]);
    }
    for(register int i=1;i<=n;++i){
        for(register int j=1;j<=n;++j){
            if(gra[i][j]<inf)add(i,j,w[gra[i][j]]);
        }
    }
    spfa();
    if(!flag)printf("Impossible\n");
    return 0;
}
