#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
unordered_map<string,int>ma;
const int maxn=100110;
int n;
string str[maxn];
int main(){
    freopen("poem.in","r",stdin);
    freopen("poem.out","w",stdout);
    int ans[maxn];
	read(n);
	for(register int i=1;i<=n;++i){
        cin>>str[i];
    }
	string tmp;
    for(register int i=1;i<=n;++i){
        int len=str[i].length();
        ans[i]=ans[i-1];
        for(register int j=0;j<len;++j){
            tmp.clear();
            for(register int k=0;k<=len-j-1;++k){
                tmp+=str[i][j+k];
                ans[i]+=2*(++ma[tmp])-1;
            }
        }
    }
    for(register int i=1;i<=n;++i){
        printf("%d\n",ans[i]);
    }
    return 0;
}
