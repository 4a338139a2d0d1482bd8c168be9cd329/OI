#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
using namespace std;
const ll mod=998244353;
const int maxn=10000+10;
void File(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
}
int n,k;
ll x,y,w[maxn],mu,ans;
ll exgcd(ll a,ll b){
	if(a%b==0){
		x=0ll;
		y=1ll;
		return b;
	}
	ll ret=exgcd(b,a%b);
	ll tmp=x;
	x=y;
	y=tmp-a/b*y;
	return ret;
}
ll qpow(int a,int b){
	ll base=a,ret=1ll;
	while(b){
		if(b&1)ret=(ret*base)%mod;
		base=base*base%mod;
		b/=2;
	}
	return ret;
}
ll getinv(ll a){
	ll gcd=exgcd(a,mod);
	return x/gcd;
}
void dfs(int th,ll sum){
	if(th>k){
		ans=(ans+(sum*mu)%mod)%mod;
		return;
	}
	REP(i,1,n){
		--w[i];
		ll s=1ll;
		REP(j,1,n)
			s*=(j!=i) ? w[j] : 1; 
		dfs(th+1,sum+s);
		++w[i];
	}
}
ll subtask2(){
	--k;
	ll fa=499122176ll;
	ll fb=998244350ll;
	ll s=k/4;
	int last=k%4+1;
	if(last<=2){
		fa=(fa-qpow(2,s))%mod;
		fa=(fa-(6*(1+s)*s/2)%mod)%mod;
		if(last==2)fa-=2*s+1;
		return fa;
	}
	else{

	}
}
int main(){
	File();
	scanf("%d%d",&n,&k);
	REP(i,1,n)
		scanf("%lld",&w[i]);
	mu=pow(n,k);
	mu=getinv(mu);
	dfs(1,0);
	cout<<(ans%mod+mod)%mod<<endl;
	return 0;
}

