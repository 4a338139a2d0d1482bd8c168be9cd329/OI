#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<queue>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define mem(a,b) memset(a,b,sizeof(a))
#define MREP(i,x) for(register int i=beg[x];i;i=E[i].last)
using namespace std;
const int maxn=180+10;
const int maxm=4e4+10;
const int maxc=50+10;
void File(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
}
int read(){
	int sum=0,s=1;
	char c=getchar();
	while((c<='9' && c>='0') || c=='-'){
		if(c=='-')s=-1;
		else sum=(sum<<1)+(sum<<3)+(c^'0');
		c=getchar();
	}
	return sum*s;
}
int n,m,c,w[maxc],beg[maxn],len,dp[maxn][maxc];
struct edge{
	int to;
	int last;
	int lv;
}E[maxm];
void add(int u,int v,int lv){
	++len;
	E[len].to=v;
	E[len].last=beg[u];
	beg[u]=len;
	E[len].lv=lv;
}
int subtask1(){
	bool vis[maxn];
	int step[maxn];
	queue<int>q;
	q.push(1);
	vis[1]=1;
	step[1]=0;
	while(!q.empty()){
		int u=q.front();
		q.pop();
		MREP(i,u){
			int v=E[i].to;
			if(w[E[i].lv]==0 && !vis[v]){
				if(v==n)return step[u]+1;
				step[v]=step[u]+1;
				vis[v]=1;
				q.push(v);
			}
		}
	}
	return -1;
}
int subtask2(){
	int step[maxn]={0};
	queue<int>q;
	q.push(1);
	step[1]=0;
	while(!q.empty()){
		int u=q.front();
		q.pop();
		if(step[u]>2000)return -1;
		MREP(i,u){
			int v=E[i].to;
			if(step[u]+1==step[v])
				continue;
			if(w[E[i].lv]<=step[u]){
				if(v==n)return step[u]+1;
				step[v]=step[u]+1;
				q.push(v);
			}
		}
	}
	return -1;
}
int main(){
	bool sub2=true;
	File();
	n=read();
	m=read();
	c=read();
	REP(i,1,m){
		int u=read(),v=read(),lv=read();
		add(u,v,lv);
	}
	REP(i,1,c){
		w[i]=read();
		if(w[i]>1000)
			sub2=0;
	}
	if(c==1){
		int ans=subtask1();
		if(ans==-1)
			printf("Impossible");
		else
			printf("%d\n",ans);
		return 0;
	}
	if(sub2){
		int ans=subtask2();
		if(ans==-1)
			printf("Impossible");
		else
			printf("%d\n",ans);
		return 0;
	}
	mem(dp,127);
	dp[1][0]=0;
	return 0;
}
