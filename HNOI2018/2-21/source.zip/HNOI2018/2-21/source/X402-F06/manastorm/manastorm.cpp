#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10,mod=998244353;
int a[maxn];
int C[2000+1][2000+1];
inline void add(int &x,int y){
	if(y<0) y+=mod;
	x+=y;
	if(x>=mod) x-=mod;
}
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return res;
}
int num=0,n,m;
void dfs(int pos){
	if(pos>m){
		int res=1;
		REP(i,1,n) res=1ll*a[i]*res%mod;
		add(num,res);
		return;
	}
	REP(i,1,n){
		add(a[i],-1);
		dfs(pos+1);
		add(a[i],1);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n) a[i]=read();
	int ans=1;
	REP(i,1,n) ans=1ll*ans*a[i]%mod;
	int inv_n=ksm(n,m);
	inv_n=ksm(inv_n,mod-2);
	dfs(1);
	num=1ll*num*inv_n%mod;
	printf("%d\n",(ans+mod-num)%mod);
	return 0;
}
