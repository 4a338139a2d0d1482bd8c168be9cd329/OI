#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=300+10;
char s[maxn][maxn];
int len[maxn];
bool f[maxn][maxn][maxn];
int g[maxn];
inline bool check(int x,int l1,int r1,int y,int l2,int r2){
	REP(i,0,r1-l1) if(s[x][i+l1]!=s[y][i+l2]) return 0;
	return 1;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
#endif
	int n=read(),ans=0;
	REP(i,1,n) scanf("%s",s[i]+1),len[i]=strlen(s[i]+1);
	REP(i,1,n)
		REP(l,1,len[i])
			REP(r,l,len[i]){
				if(f[i][l][r]) continue;
				int le=r-l;
				int res=0;
				REP(j,i,n){
					REP(k,1,len[j]-le)
						if(check(i,l,r,j,k,k+le)) res++,f[j][k][k+le]=1;
					g[j]+=res*res;
				}
			}
	REP(i,1,n) printf("%d\n",g[i]);
	return 0;
}
