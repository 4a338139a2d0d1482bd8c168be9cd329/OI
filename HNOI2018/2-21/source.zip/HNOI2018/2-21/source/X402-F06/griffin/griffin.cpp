#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxk=180+10,maxn=50+10,maxm=4e4+10;
int N;
bitset<maxk> l1[maxk],l2[maxk];
struct Matrix{
	bool a[maxk][maxk];
	void clear(){
		memset(a,0,sizeof(a));
	}
	Matrix operator *(const Matrix &rhs) const{
		Matrix A;
		A.clear();
		REP(i,1,N) REP(j,1,N) l1[i][j]=a[i][j],l2[j][i]=rhs.a[i][j];
		REP(i,1,N)
			REP(j,1,N)
				A.a[i][j]=(l1[i]&l2[j]).any();
		return A;
	}
	void output(){
		REP(i,1,N)
			REP(j,1,N)
				printf("%d%c",a[i][j],j==jend?'\n':' ');
		putchar('\n');
	}
};
struct Edge{
	int x,y,z;
	bool operator <(const Edge &rhs) const{
		return z<rhs.z;
	}
}E[maxm];
int c[maxn];
Matrix e;
Matrix ksm(Matrix x,int y){
	Matrix res=e;
	while(y){
		if(y&1) res=res*x;
		x=x*x;
		y>>=1;
	}
	return res;
}
Matrix res,G;
int main(){
#ifndef ONLINE_JUDGE
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
#endif
	N=read();
	int m=read(),n=read();
	REP(i,1,m) E[i].x=read(),E[i].y=read(),E[i].z=read();
	sort(E+1,E+m+1);
	REP(i,1,n) c[i]=read();
	int pos=1;
	res.clear(),G.clear();
	e.clear();
	res.a[1][1]=1,G.a[N][N]=1;
	REP(i,1,N) e.a[i][i]=1;
	c[n+1]=c[n]+1e9;
	REP(i,1,n+1){
		Matrix u=res;
		res=res*ksm(G,c[i]-c[i-1]);
		if(res.a[1][N]){
			int L=1,R=c[i]-c[i-1];
			Matrix tmp;
			while(L<=R){
				int Mid=(L+R)>>1;
				tmp=u*ksm(G,Mid);
				if(tmp.a[1][N]) R=Mid-1;
				else L=Mid+1;
			}
			printf("%d\n",c[i-1]+R+1);
			return 0;
		}
		if(i==iend){
			printf("Impossible\n");
			return 0;
		}
		while(pos<=m && E[pos].z==i) G.a[E[pos].x][E[pos].y]=1,++pos;
	}
	return 0;
}
