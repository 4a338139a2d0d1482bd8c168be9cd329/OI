#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 3010;

ll ans;

namespace Trie {
	struct node {
		int sz;
		node* ch[26];
		node() {
			sz = 0;
			memset(ch, 0, sizeof(ch));
		}
	};
	node* h;
	inline void init() { h = new node(); }
	inline void insert(char *s) {
		int i, len = strlen(s);
		node* p = h;
		for(i = 0; i < len; i++) {
			int c = s[i]-'a';
			if(p->ch[c] == NULL) p->ch[c] = new node();
			p = p->ch[c];
			ans -= (p->sz)*(p->sz);
			p->sz++, ans += (p->sz)*(p->sz);
		}
	}
}

int n;
char *s[MAXN], t[300010];

int main() {
	freopen("poem.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j, len;
	scanf("%d", &n);
	for(i = 1; i <= n; i++) {
		scanf("%s", t);
		len = strlen(t);
		s[i] = new char[len+5]();
		strcpy(s[i], t);
	}
	Trie::init();
	ans = 0;
	for(i = 1; i <= n; i++) {
		len = strlen(s[i]);
		for(j = 0; j < len; j++) 
			Trie::insert(s[i]+j);
		printf("%lld\n", ans);
	}
	return 0;
}
