#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 3010;

ll ans;

namespace Trie {
	struct node {
		int sz;
		node* ch[26];
		node() {
			sz = 0;
			memset(ch, 0, sizeof(ch));
		}
	};
	node* h;
	inline void init() { h = new node(); }
	inline void insert(char *s) {
		int i, len = strlen(s);
		node* p = h;
		for(i = 0; i < len; i++) {
			int c = s[i]-'a';
			if(p->ch[c] == NULL) p->ch[c] = new node();
			p = p->ch[c];
			ans -= (p->sz)*(p->sz);
			p->sz++, ans += (p->sz)*(p->sz);
		}
	}
}

struct SAM {
	int ch[600010][26], cnt, ml[600010];
	int last, fa[600010];
	int buc[600010], sz[600010];
	SAM() { last = cnt = 1;}
	inline void extend(int c) {
		int p = last, np;
		np = ++cnt;
		sz[np] = 1;
		last = np, ml[np] = ml[p]+1;
		for(; p && !ch[p][c]; p = fa[p]) ch[p][c] = np;
		if(!p) fa[np] = 1;
		else {
			int q = ch[p][c];
			//printf("%c %d %d %d\n", c+'a', p, ml[p], ml[q]);
			if(ml[p]+1 == ml[q]) fa[np] = q;
			else {
				int nq = ++cnt;
				ml[nq] = ml[p]+1, fa[nq] = fa[q];
				memcpy(ch[nq], ch[q], sizeof(ch[q]));
				fa[np] = fa[q] = nq;
				for(; p && ch[p][c] == q; p = fa[p]) ch[p][c] = nq;
			}
		}
	}
	inline void Topo() {
		static int q[600010];
		int i;
		/*for(i = 1; i <= cnt; i++) 
			printf("%d: %d %d %d %d\n", i, ch[i][1], ch[i][2], fa[i], ml[i]);*/
		for(i = 1; i <= cnt; i++) buc[ml[i]]++;
		for(i = 1; i <= cnt; i++) buc[i] += buc[i-1];
		for(i = 1; i <= cnt; i++) q[buc[ml[i]]--] = i;
		for(i = cnt; i >= 1; i--) sz[fa[q[i]]] += sz[q[i]];
		/*for(i = 1; i <= cnt; i++) printf("%d ", q[i]);
		printf("\n");*/
		for(i = 1; i <= cnt; i++) ans += (ll)(ml[i]-ml[fa[i]])*sz[i]*sz[i];
	}
};

int n;
char *s[MAXN], t[300010];

int main() {
	freopen("poem.in", "r", stdin);
	freopen("poem.out", "w", stdout);

	int i, j, len;
	scanf("%d", &n);
	if(n == 1) {
		SAM* T;
		T = new SAM();
		scanf("%s", t);
		len = strlen(t);
		i = 0;
		for(i = 0; i < len; i++) {
			T->extend(t[i]-'a');
			/*for(j = 1; j <= T->cnt; j++) 
				printf("%d ", T->ml[j]);
			printf("\n");*/
		}
		T->Topo();
		printf("%lld\n", ans);
		return 0;
	}
	for(i = 1; i <= n; i++) {
		scanf("%s", t);
		len = strlen(t);
		s[i] = new char[len+5]();
		strcpy(s[i], t);
	}
	Trie::init();
	ans = 0;
	for(i = 1; i <= n; i++) {
		len = strlen(s[i]);
		for(j = 0; j < len; j++) 
			Trie::insert(s[i]+j);
		printf("%lld\n", ans);
	}
	return 0;
}
