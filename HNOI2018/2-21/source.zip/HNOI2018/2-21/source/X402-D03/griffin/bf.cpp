#include<bits/stdc++.h>
using namespace std;

const int MAXN = 200, MAXC = 60, MAXM = 40010;
const int INF = 1000000000;

inline int read() {
	int x = 0;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) ;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x;
}

int st[MAXN], to[MAXM];
int nxt[MAXM], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int n, m, c, w[MAXM];
int d[MAXN];
bool vis[MAXN];

queue<int> q;

inline void BFS() {
	int i;
	for(i = 2; i <= n; i++) d[i] = INF;
	d[1] = 0, q.push(1), vis[1] = true;
	while(!q.empty()) {
		int u = q.front();
		q.pop();
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(!vis[v] && d[v] > d[u]+1) {
				d[v] = d[u]+1;
				vis[v] = true, q.push(v);
			}
		}
	}
}

int main() {
	freopen("griffin.in", "r", stdin);
	freopen("griffin.out", "w", stdout);

	int i;
	n = read(), m = read(), c = read();
	if(c != 1) {
		printf("Impossible\n");
		return 0;
	}
	for(i = 1; i <= m; i++) {
		int u = read(), v = read(), lv = read();
		Add(u, v);
	}
	for(i = 1; i <= c; i++) w[i] = read();
	if(w[1]) {
		printf("Impossible\n");
		return 0;
	}
	BFS();
	if(d[n] == INF) printf("Impossible\n");
	else printf("%d\n", d[n]);
	return 0;
}
