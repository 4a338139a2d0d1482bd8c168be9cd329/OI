#include<bits/stdc++.h>
using namespace std;

const int MAXN = 190, MAXC = 60, MAXM = 40010;
const int INF = 1000000000;

inline int read() {
	int x = 0;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) ;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x;
}

int n;

struct Matrix {
	bitset<MAXN> g[MAXN];
	Matrix(int x = 0) {
		int i;
		for(i = 1; i <= n; i++) g[i] = 0;
		if(x == 1) for(i = 1; i <= n; i++) g[i][i] = 1;
	}
	inline void output() {
		int i, j;
		for(i = 1; i <= n; i++) {
			for(j = 1; j <= n; j++)
				printf("%d ", (int)g[i][j]);
			printf("\n");
		}
			printf("\n");
	}
};


Matrix T(const Matrix &A) {
	int i, j;
	Matrix res;
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++) res.g[i][j] = A.g[j][i];
	return res;
}

Matrix operator * (const Matrix &A, const Matrix &B) {
	Matrix res, TB = T(B);
	int i, j;
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= n; j++) 
			res.g[i][j] = (A.g[i]&TB.g[j]).any();
	return res;
}

Matrix qpow (Matrix A, int b) {
	Matrix res = 1;
	while(b) {
		if(b & 1) res = res * A;
		b >>= 1, A = A * A;
	}
	return res;
}

struct Edge {
	int u, v;
	Edge(int u0 = 0, int v0 = 0): u(u0), v(v0) {}
};
vector<Edge> E[MAXC];

int m, c, w[MAXC];

int main() {
	freopen("griffin.in", "r", stdin);
	freopen("griffin.out", "w", stdout);

	int i, j;
	n = read(), m = read(), c = read();
	for(i = 1; i <= m; i++) {
		int u = read(), v = read(), lv = read();
		E[lv].push_back(Edge(u, v));
	}
	for(i = 1; i <= c; i++) w[i] = read();
	w[c+1] = w[c]+m;
	c++;
	if(w[1] != 0) {
		printf("Impossible\n");
		return 0;
	}
	Matrix G = 1, NC, C = 1, NG;
	for(i = 1; i < c; i++) {
		for(j = 0; j < (int)E[i].size(); j++) {
			//printf("%d %d\n", E[i][j].u, E[i][j].v);
			G.g[E[i][j].u][E[i][j].v] = true;
			NG.g[E[i][j].u][E[i][j].v] = true;
		}
		NC = C*qpow(G, w[i+1]-w[i]);
		/*if(i == 2) {
			C.output();
			G.output();
			NC.output();
			exit(0);
		}*/
		if(NC.g[1][n]) {
			int l = w[i]+1, r = w[i+1];
			while(l < r) {
				int mid = (l+r)>>1;
				if((C*qpow(G, mid-w[i])).g[1][n]) r = mid;
				else l = mid+1;
			}
			printf("%d\n", l);
			return 0;
		}
		/*if(i == 1) {
			printf(":\n");
			NG.output();
			printf("?%d\n", w[i+1]-w[i]);
			(qpow(NG, w[i+1]-w[i])).output();
		}*/
		C = C * qpow(NG, w[i+1]-w[i]);
		//NG.output();
		//C.output(), R.output(), G.output();
	}
	printf("Impossible\n");
	return 0;
}
