#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 310;
const ll MOD = 998244353;

inline int read() {
	int x = 0;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) ;
	for(; isdigit(ch); ch = getchar()) x = x*10+(ch^48);
	return x;
}

ll fac[MAXN], ifac[MAXN];

inline ll binom(ll n, ll m) {
	return fac[n]*ifac[m]%MOD*ifac[n-m]%MOD;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int n, K, a[MAXN];
ll S, ans;

int main() {
	freopen("manastorm.in", "r", stdin);
	freopen("manastorm.out", "w", stdout);
	int i, j;
	n = read(), K = read();
	generate(a+1, a+n+1, read);
	for(i = 1; i <= n; i++) S = (S+a[i])%MOD;
	fac[0] = 1;
	for(i = 1; i <= K; i++) fac[i] = fac[i-1]*i%MOD;
	ifac[K] = qpow(fac[K], MOD-2);
	for(i = K; i >= 1; i--) ifac[i-1] = ifac[i]*i%MOD;
	for(i = 0; i < K; i++) 
		for(j = 1; j <= K-i; j++) {
			ll res = qpow(n-1, j);
			res = res * binom(i+j-1, i)%MOD * ((S-n*i%MOD+MOD)%MOD)%MOD;
			ans = (ans+res)%MOD;
		}
	printf("%lld\n", ans*qpow(qpow(n, K), MOD-2)%MOD);
	return 0;
}
