/************************************************
 * Au: Hany01
 * Prob: C
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("poem.in", "r", stdin);
    freopen("poem.out", "w", stdout);
}

const int maxn = 3005;

int n, len[maxn];
LL Ans[maxn], Sum, tmp;
char s[maxn][maxn], W[maxn];
map<string, bool> mp;

int count(char *p, char *s)
{
	int lenp = strlen(p + 1), lens = strlen(s + 1), mark, Sum = 0;
	For(st, 1, lens - lenp + 1) {
		mark = 1;
		For(ed, st, st + lenp - 1) if (s[ed] != p[ed - st + 1]) { mark = 0; break; }
		Sum += mark;
	}
	return Sum;
}

int main()
{
    File();
	n = read();
	For(i, 1, n) scanf("%s", s[i] + 1), len[i] = strlen(s[i] + 1);
	For(r, 1, n) {
		For(i, 1, r) {
			mp.clear();
			For(L, 1, len[i])
				For(R, L, len[i]) {
					Set(W, 0);
					For(j, L, R) W[j - L + 1] = s[i][j];
					if (mp[(string)(W + 1)]) continue;
					mp[(string)(W + 1)] = 1;
					Sum = 0;
					For(j, 1, r) Sum += count(W, s[j]);
					tmp = count(W, s[i]);
					Ans[r] += Sum * 1ll * tmp;
				}
		}
		printf("%lld\n", Ans[r]);
	}
	return 0;
}
