#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=40000+10,INf=0x7f7f7f7f;
inline void read(int &x)
{
	x=0;  int p=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') p=-1; ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		x=(x<<1)+(x<<3)+(ch^'0'); ch=getchar();
	}
	x=x*p;
}
int n,m,c;
struct node 
{
	int x,y,lv;
}e[maxn];

int to[maxn],nex[maxn],beg[maxn],cnt;
inline void add(int x,int y)
{
	to[++cnt]=y;
	nex[cnt]=beg[x];
	beg[x]=cnt;
}

#define maxm 50+10
int lev[maxm],d[maxm],que[maxn],p[maxn];

inline void spfa()
{
	for(register int i=1;i<=n;i++) d[i]=INf;
	d[1]=0; que[1]=1; p[1]=1;
	int l=0,r=1,k;
	while(l<r){
		k=que[++l];
		for(register int i=beg[k];i;i=nex[i]){
			int v=to[i];
			if(d[v]>d[k]+1){
				d[v]=d[k]+1;
				if(!p[v]){
					p[v]=1;
					que[++r]=v;
				}
			}
		}
	}
}

int main()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	read(n); read(m); read(c);
	for(register int i=1;i<=m;i++){
		read(e[i].x); read(e[i].y); read(e[e[i].y].lv);
		add(e[i].x , e[i].y);
	}
	for(register int i=1;i<=c;i++) read(lev[i]);
	if(lev[1]!=0) {printf("Impossible\n"); return 0;}
	if(c==1){
		spfa();
		if(d[n]!=INf) printf("%d\n",d[n]);
		else printf("Impossible\n");
		return 0;
	}
	else {
		spfa(); //cout<<d[n]<<' '<<lev[e[n].lv]<<endl;
		if(d[n]==INf) {printf("Impossible\n"); return 0;}
		if(d[n]>=lev[e[n].lv]+1) {printf("%d\n",d[n]); return 0;}
		if(m==n-1) printf("Impossible\n");
		if(m==n){
			int k=d[n];
			while(k<lev[e[n].lv]+1) k=k+2;
			printf("%d\n",k);
		}
	}
	return 0;
}
