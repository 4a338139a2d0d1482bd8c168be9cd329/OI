#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=10000+10,mod=998244353;
inline void read(int &x)
{
	x=0;  int p=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') p=-1; ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		x=(x<<1)+(x<<3)+(ch^'0'); ch=getchar();
	}
	x=x*p;
}
int n,k,cnt;
int a[maxn];
long long ans;

void dfs(int x,int now)
{
    if(x==k+1){
        ans+=now; ans%=mod;
        cnt+=1;
        return;
    }
    for(register int i=1;i<=n;i++){
        a[i]-=1;
        int s=1;
        for(register int j=1;j<=n;j++){
        	if(j!=i){
        		s=s*(a[j]%mod),s=s%mod;
        	}
		}
        dfs(x+1,now+s);
        a[i]+=1;
    }
}

inline long long ksm(long long x,long long mc)
{
    long long tmp=x%mod;
    long long res=1;
    while(mc){
        if(mc&1) res=(res*tmp)%mod;
        tmp=tmp*tmp%mod;
        mc>>=1;
    }
    return res;
}

int main()
{
	freopen("manastorm2.in","r",stdin);
	//freopen("manastorm.out","w",stdout);
	read(n); read(k);
    for(register int i=1;i<=n;i++) read(a[i]);
    dfs(1,0);
    printf("%d\n",( ( (ans%mod+mod) %mod) * ksm(cnt , mod-2) ) % mod);
    return 0;
}

