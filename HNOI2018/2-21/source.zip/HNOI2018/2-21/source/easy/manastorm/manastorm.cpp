#include <bits/stdc++.h>
using namespace std;
const int maxn = 300 +10;
const long long mod = 998244353;
long long read(){
	int x=0,flag=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')flag=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*flag;
}
long long n,K,ai[maxn];
long long Pow(long long x,long long t){
	long long ans = 1; x%= mod;
	while(t){
		if(t&1)ans = ans * x % mod;
		x = x * x % mod; t >>= 1;
	}
	return ans;
}
const int inf = 0x7f7f7f7f;
long long Ans = 0 , bas = 0;
void dfs(int x,long long ans){
	if( x==K ){ (Ans += ans)%=mod;++bas; return; }
	for(int i=1;i<=n;i++){
		ai[i] -= 1;
		long long tmp = 1;
		for(int j=1;j<=n;j++)if(j!=i)tmp = tmp * ai[j]%mod;
		dfs(x+1,(ans+tmp)%mod);
		ai[i] += 1;
	}
}
int main(){
	freopen("manastorm.in","r",stdin),freopen("manastorm.out","w",stdout);
	n=read(); K=read();
	for(int i=1;i<=n;i++)ai[i]=read();
	dfs(0,0);
	printf("%lld\n",(Ans * Pow(bas,mod-2)% mod + mod)%mod);
	return 0;
}
