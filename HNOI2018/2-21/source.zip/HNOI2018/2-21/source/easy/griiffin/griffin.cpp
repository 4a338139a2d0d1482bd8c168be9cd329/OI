#include <bits/stdc++.h>
using namespace std;
const int maxm = 180 +5;
const int maxn = 500000 +10;
const long long inf = 1e14;

int read(){
	int x = 0,flag = 1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')flag=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*flag;
}
bitset <maxm> t1[maxm],t2[maxm];
int n,m,c;
struct matt{
	int siz;
	bool mat[maxm][maxm];
	void init(int type,int Siz){
		siz = Siz;
		for(int i=0;i<maxm;i++)for(int j=0;j<maxm;j++)mat[i][j]=0;
		for(int i=0;i<maxm;i++)mat[i][i]=type;
	}
	matt operator + (const matt & rhs) const {
		matt a; a.init(0,rhs.siz);
		for(int i=1;i<=siz;i++)for(int j=1;j<=siz;j++)a.mat[i][j]=mat[i][j]+rhs.mat[i][j];
		return a;
	}
	matt operator * (const matt & rhs) const {
		matt a; a.init(0,rhs.siz);

		
		for(int i=1;i<=siz;i++)t1[i].reset();
		for(int j=1;j<=siz;j++)for(int k=1;k<=siz;k++)t2[j][k]=rhs.mat[j][k];

		for(int i=1;i<=siz;i++)for(int j=1;j<=siz;j++)if(mat[i][j])t1[i]|=t2[j];

		for(int i=1;i<=siz;i++)for(int k=1;k<=siz;k++)a.mat[i][k] = t1[i][k];

		return a;
	}
	matt operator ^ (const int & T) const{
		int t = T; -- t;
		matt x;x.siz = siz;
		for(int i=1;i<=siz;i++)for(int j=1;j<=siz;j++)x.mat[i][j] = mat[i][j];
		matt ans = x;
		while(t){
			if(t&1)ans = ans * x;
			x = x* x; t>>=1;
		}
		return ans;
	}
};
struct Edge{
	int fr,to,ci;
	Edge(void){}
	Edge(int a,int b,int ca):fr(a),to(b),ci(ca){}
	bool operator < (const Edge & rhs) const { return ci < rhs.ci; } 
};
Edge e[maxn];
matt way;
void get_way2(int x){
	way.init(0,n);
	for(int i=1;i<=m;i++) if(e[i].ci <= x) way.mat[e[i].fr][e[i].to]=1;
}
long long f[maxm][maxm],w[maxn];
void get_way(int x){
	way.init(0,n);
	for(int i=1;i<=m;i++){
		if(e[i].ci < x) way.mat[e[i].fr][e[i].to]=1;
		else if(e[i].ci == x) f[e[i].fr][e[i].to]=1;
	}
}
int main(){
	freopen("griffin.in","r",stdin),freopen("griffin.out","w",stdout);
	n = read();	m =read(); c= read();	
	for(int i=1;i<=m;i++){ e[i].fr=read(); e[i].to=read(); e[i].ci=read(); }
	for(int i=1;i<=c;i++)w[i]=1LL*read();
	if(n==1)printf("0\n");
	else if(w[1]!=0)puts("Impossible");
	else{
		matt bas; bas.init(0,n);
		for(int i=1;i<=n;i++)for(int j=1;j<=n;j++)f[i][j]=inf;
		long long ans = inf;
		for(int cnt=2;cnt<=c;cnt++){
			get_way(cnt);
			for(int k=1;k<=n;k++)for(int i=1;i<=n;i++)for(int j=1;j<=n;j++)f[i][j] = min(f[i][k]+f[k][j],f[i][j]);
			int tmp = w[cnt]-w[cnt-1];
			if(tmp>1)way = way ^ tmp;
			if(cnt != 2)bas = bas * way; else bas = way;
			for(int j=2;j<=n;j++)for(int i=1;i<=n;i++)bas.mat[j][i] = 0;
			for(int i=1;i<=n;i++)if(bas.mat[1][i])ans = min(ans,w[cnt]+f[i][n]);
		}
		if(ans == inf)puts("Impossible\n");
		else printf("%lld\n",ans);
	}
	return 0;
}
