#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=100000+10,Mod=998244353;
ll ans,C[310][310];
int n,k,A[MAXN];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
inline void dfs(int x,ll tot,ll pos)
{
	if(x==k)
	{
		(ans+=(((tot%Mod)+Mod)%Mod*pos)%Mod)%=Mod;
		return ;
	}
	for(register int i=1;i<=n;++i)
	{
		A[i]--;
		ll now=1;
		for(register int j=1;j<=n;++j)
			if(j!=i)(now*=A[j])%=Mod;
		dfs(x+1,(tot+now)%Mod,(pos*qexp(n,Mod-2))%Mod);
		A[i]++;
	}
}
inline void init()
{
	C[0][0]=1;
	for(register int i=1;i<305;++i)
	{
		C[i][0]=1;
		for(register int j=1;j<305;++j)C[i][j]=(C[i-1][j]+C[i-1][j-1])%Mod;
	}
}
int main()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	read(n);read(k);
	for(register int i=1;i<=n;++i)read(A[i]);
	if(n==2)printf("%lld\n",((A[1]+A[2]-(k-1)*qexp(2,Mod-2)%Mod)%Mod+Mod)%Mod*k%Mod*qexp(2,Mod-2)%Mod);
	else
	{
		dfs(0,0,1);
		printf("%lld\n",ans);
	}
	return 0;
}
