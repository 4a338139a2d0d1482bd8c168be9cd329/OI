#include<bits/stdc++.h>
using namespace std;
const int MAXN=180+10,MAXM=40000+10,MAXC=50+10;
int n,m,c,w[MAXC],to[MAXM],beg[MAXN],nex[MAXM],lv[MAXM],e,p[MAXN],G[MAXN][MAXN];
struct node{
	int pos;
	int val;
	int res;
};
node tmp;
queue<node> q;
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void insert(int x,int y,int z)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	lv[e]=z;
}
inline void subt1()
{
	for(register int i=1;i<=m;++i)
	{
		int x,y,k;
		read(x);read(y);read(k);
		to[++e]=y;
		nex[e]=beg[x];
		beg[x]=e;
	}
	read(w[1]);
	if(w[1]!=0)
	{
		printf("Impossible\n");
		return ;
	}
	int res=0;
	queue<int> qq;
	qq.push(1);
	p[1]=1;
	while(!qq.empty())
	{
		int x=qq.front();
		qq.pop();
		for(register int i=beg[x];i;i=nex[i])
			if(!p[to[i]])
			{
				if(to[i]==n)
				{
					printf("%d\n",res+1);
					return ;
				}
				p[to[i]]=1;
				qq.push(to[i]);
			}
		res++;
	}
	printf("Impossible\n");
}
int main()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	read(n);read(m);read(c);
	if(c==1)
	{
		subt1();
		return 0;
	}
	for(register int i=1;i<=m;++i)
	{
		int u,v,k;
		read(u);read(v);read(k);
		insert(u,v,k);
	}
	for(register int i=1;i<=c;++i)read(w[i]);
	tmp.pos=1;
	tmp.val=0;
	tmp.res=0;
	q.push(tmp);
	while(!q.empty())
	{
		tmp=q.front();
		q.pop();
		int x=tmp.pos,k=tmp.val,now=tmp.res;
		for(register int i=beg[x];i;i=nex[i])
			if(k>=w[lv[i]])
			{
				if(to[i]==n)
				{
					printf("%d\n",now+1);
					return 0;
				}
				tmp.pos=to[i];
				tmp.val=k+1;
				tmp.res=now+1;
				q.push(tmp);
			}
	}
	printf("Impossible\n");
	return 0;
}
