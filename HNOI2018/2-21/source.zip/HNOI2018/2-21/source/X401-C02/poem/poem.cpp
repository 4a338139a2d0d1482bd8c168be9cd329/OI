#include<bits/stdc++.h>
using namespace std;
const int MAXN=100000+10,MAXS=300000+10;
int n,ans;
char *s[MAXN],g[MAXS];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void f(char *w,int r)
{
	int res=0;
	for(register int i=1;i<=r;++i)
	{
		char *p=s[i];
		while(p=strstr(p,w))res++,p++;
	}
	ans+=res*res;
}
int main()
{
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	read(n);
	for(register int i=1;i<=n;++i)
	{
		scanf("%s",g);
		s[i]=new char[strlen(g)+1];
		strcpy(s[i],g);
	}
	for(register int r=1;r<=n;++r)
	{
		ans=0;
		set<string> T;
		for(register int i=1;i<=r;++i)
			for(register int j=0;s[i][j];++j)
				for(register int k=0;s[i][j+k];++k)
					if(T.insert(string(s[i]+j,k+1)).second)
					{
						strncpy(g,s[i]+j,k+1);
						g[k+1]=0;
						f(g,r);
					}
		printf("%d\n",ans);
	}
	return 0;
}
