#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
}

typedef long long ll;
const int maxn=1e5+10;
const ll mod=998244353;
ll ans,n,k,a[maxn],tot,P;
ll fac[maxn],F[maxn];

ll ksm(ll a,ll b){
	ll res=1;
	while(b){
		if(b&1) (res*=a)%=mod;
		(a*=a)%=mod;
		b>>=1;
	}
	return res;
}

void dfs(int k){
	if(k==0) return;
	For(i,1,n){
		a[i]--;
		ll S=1;
		For(j,1,n) if(i!=j)
			S=(S*a[j]%mod+mod)%mod;
		(S*=ksm(n,k-1))%=mod;
		ans=((ans+S)%mod+mod)%mod;
		dfs(k-1);
		a[i]++;
	}
}

inline void Pre_(){
	fac[0]=fac[1]=1;
	F[0]=F[1]=1;
	For(i,2,k){
		fac[i]=(fac[i-1]*i)%mod;
		F[i]=ksm(fac[i],mod-2);
	}
}

int main(){
	file();
	read(n),read(k);
	For(i,1,n) read(a[i]);
	if(n==2){
		Pre_();
		For(i,0,k)
			(ans+=(i*a[2]+(k-i)*a[1]-i*(k-i))%mod*fac[k]%mod*F[i]%mod*F[k-i]%mod+mod)%mod;
		printf("%lld\n",ans*ksm(ksm(2,k),mod-2)%mod);
		return 0;
	}
	dfs(k);	
	ans=(ans%mod)*(ksm(ksm(n,k),mod-2)%mod)%mod;
	printf("%lld\n",(ans+mod)%mod);
	return 0;
}

