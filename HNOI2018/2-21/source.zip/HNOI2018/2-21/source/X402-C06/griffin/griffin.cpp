#include<bits/stdc++.h>
#define Travel(i,x) for(register int i=beg[x];i;i=nex[i])
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
}

const int N=4e4+10;
int n,m,c,u,v,l,w[N],level[N],now[200];
int e,beg[N],nex[N<<1],to[N<<1],ww[60];
int mp[185][185],tot,vis[200],flag;

inline void add(int x,int y,int z){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}

bool check(int x){
	int cnt=0;
	Travel(i,x){
		int t=to[i];
		if(now[x]>=ww[w[i]]) cnt++;
	}
	if(!cnt) return 0;
	return 1;
}

inline void BFS(){
	queue<int> Q;
	Q.push(1),now[1]=0;
	while(!Q.empty()){
		int s=Q.front();
		Q.pop();
		if(!check(s)){
			flag=1;
			return;
		}
		Travel(i,s){
			int t=to[i];
			now[t]=now[s]+1;
			if(now[s]>=ww[w[i]]){
				Q.push(t);
				if(t==n) return;
			}
		}
	}
}

int main(){
	file(),flag=0;
	read(n),read(m),read(c);
	For(i,1,m){
		read(u),read(v),read(l);
		if(mp[u][v]==0) mp[u][v]=l;
		else if(l<mp[u][v]) mp[u][v]=l;
	}
	For(i,1,180) For(j,1,180)
		if(mp[i][j]>0) add(i,j,mp[i][j]);
	For(i,1,c) read(ww[i]);
	BFS();
	if(flag) printf("Impossible\n");
	else printf("%d\n",now[n]);
	return 0;
}


