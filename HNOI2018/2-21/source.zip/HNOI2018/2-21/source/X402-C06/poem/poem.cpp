#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

unordered_map<string,int> mp;
const int maxn=1e5+10;;
int n,ans[maxn];
string s[maxn];

inline void file(){
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
}

inline void Init(){
	read(n);
	For(i,1,n) cin>>s[i];
}

inline void Solve(){
	string x;
	For(i,1,n){
		int len=(int)s[i].size();
		ans[i]=ans[i-1];
		For(t,0,len){
			x="";
			For(j,0,len-t-1){
				x=x+s[i][t+j];
				mp[x]++;
				ans[i]+=(mp[x]<<1)-1;
			}
		}
	}
	For(i,1,n) printf ("%d\n", ans[i]);
}

int main(){
	file();
	Init();
	Solve();
	return 0;
}
