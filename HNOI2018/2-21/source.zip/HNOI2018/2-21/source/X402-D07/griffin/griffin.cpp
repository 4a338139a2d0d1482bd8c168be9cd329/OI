#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

#define pb push_back
#define pp pop_back
#define mp make_pair

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef pair<int,int> PII;

const int maxn=200,maxm=40010,maxc=55,INF=0x3f3f3f3f;

int n,m,c,w[maxn],ans=INF;

struct Matrix{
    bitset<maxn> A[maxn];
    Matrix(){ for(int i=1;i<maxn;i++) A[i].reset(); }
} base,G;

Matrix Mul(Matrix a,Matrix b){
    Matrix res,bT;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++) bT.A[i][j]=b.A[j][i];
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            res.A[i][j]=(a.A[i]&bT.A[j]).any();
    return res;
}

Matrix fpm(Matrix x,int k){
    Matrix res;
    for(int i=1;i<=n;i++) res.A[i][i]=1;
    for(;k;k>>=1,x=Mul(x,x))
        if(k&1) res=Mul(res,x);
    return res;
}

vector<PII> t[maxc];

priority_queue<PII> q;
int dis[maxn];
bool vis[maxn];

void Dijkstra(int h){
    memset(dis,INF,sizeof dis);
    memset(vis,0,sizeof vis);

    dis[h]=0; q.push(mp(dis[h],h));

    while(!q.empty()){
        int u=q.top().second; q.pop();

        if(vis[u]) continue;
        vis[u]=1;

        for(int i=1;i<=n;i++) if(G.A[i][u])
            if(!vis[i]&&chkmin(dis[i],dis[u]+1)) q.push(mp(dis[i],i));
    }
}

int main(){
    freopen("griffin.in","r",stdin);
    freopen("griffin.out","w",stdout);

    read(n); read(m); read(c);
    for(int i=1;i<=m;i++){
        int u,v,lv;
        read(u); read(v); read(lv);
        t[lv].pb(mp(u,v));
    }
    for(int i=1;i<=c;i++) read(w[i]);

    base.A[1][1]=1;
    if(w[1]) puts("Impossible"),exit(0);

    for(int i=1;i<=c;i++){
        while(!t[i].empty()){
            PII u=t[i].back(); t[i].pp();
            G.A[u.first][u.second]=1;
        }

        Dijkstra(n);
        for(int j=1;j<=n;j++) if(base.A[1][j]) chkmin(ans,w[i]+dis[j]);

        if(i<c) base=Mul(base,fpm(G,w[i+1]-w[i]));
    }

    if(ans==INF) puts("Impossible");
    else printf("%d\n",ans);

    return 0;
}
