#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=10,mo=998244353;

int n,m,a[maxn];

void Add(int& x,int y){
    x+=y;
    if(x>=mo) x-=mo;
    if(x<0) x+=mo;
}

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

namespace BF{
    int ans=0;

    void dfs(int u,int sum){
        if(u==m+1) return void(Add(ans,sum));
        for(int i=1;i<=n;i++){
            a[i]--; int tmp=1;
            for(int j=1;j<=n;j++) if(i!=j) tmp=1ll*tmp*a[j]%mo;
            Add(sum,tmp); dfs(u+1,sum);
            Add(sum,-tmp); a[i]++;
        }
    }

    void solve(){
        dfs(1,0);
        printf("%lld\n",1ll*ans*fpm(fpm(n,m),mo-2)%mo);
    }
}

int main(){
    freopen("manastorm.in","r",stdin);
    freopen("manastorm.out","w",stdout);

    read(n); read(m);
    for(int i=1;i<=n;i++) read(a[i]);

    BF::solve();

    return 0;
}
