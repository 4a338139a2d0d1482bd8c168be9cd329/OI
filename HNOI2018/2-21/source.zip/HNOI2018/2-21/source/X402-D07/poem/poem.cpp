#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int maxn=100010;

int n;
string s[maxn];

LL ans;

namespace Trie{
    int ch[2000000][26];
    int t[2000000],cur;
    void insert(int u,int p){
        int h=0,len=s[u].length();
        for(;p<len;p++){
            if(!ch[h][s[u][p]-'a']) ch[h][s[u][p]-'a']=++cur;
            h=ch[h][s[u][p]-'a'];
            ans+=t[h]*2+1; t[h]++;
        }
    }
}

using namespace Trie;

int main(){
    freopen("poem.in","r",stdin);
    freopen("poem.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++) cin>>s[i];

    for(int i=1;i<=n;i++){
        int len=s[i].length();
        for(int j=0;j<len;j++) insert(i,j);
        printf("%lld\n",ans);
    }

    return 0;
}
