#include<bits/stdc++.h>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

inline void file() {
	freopen("poem.in","w",stdout);
}

const int maxn=300000;

int main() {
	file();
	srand(time(NULL));
	int n=1,N=1000;
	printf("%d\n",n);
	For (i,1,N) printf("%c",rand()%26+'a');
	return 0;
}
