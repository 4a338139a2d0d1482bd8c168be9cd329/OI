#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<map>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=300000+100;
int n;
ll ans;
char s[maxn];
map<string,int>ma;

inline void file() {
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
}

int main() {
	file();
	scanf("%d",&n);
	For (i,1,n) {
		scanf("%s",s+1);
		int l=strlen(s+1);
		For (i,1,l) {
			string ss="";
			For (j,i,l) {
				ss=ss+s[j];
				if (!ma[ss]) {
					ma[ss]=1;
					ans++;
				}
				else {
					int p=ma[ss];
					ma[ss]++;
					ans-=(ll)p*p;
					p++;
					ans+=(ll)p*p;
				}
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
