#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (ll i=j;i<=k;++i)
#define Forr(i,j,k) for (ll i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=100000+100;
const ll modd=998244353;
ll n,k,ans;
ll a[maxn],b[maxn];

inline void file() {
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
}

inline void read(ll &x) {
	x=0;
	ll p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline ll quick(ll a,ll b) {
	ll s=1; a%=modd;
	while (b) {
		if (b%2) s=s*a%modd;
		a=a*a%modd; b/=2;
	}
	return s%modd;
}

inline void add(ll kk,ll p) {
	ll s=1;
	For (i,1,n) if (i!=p) s=(s*a[i])%modd;
	ans=(ans+s*b[kk]%modd+modd)%modd;
}

void dfs(ll kk) {
	if (kk==k+1) {
		return ;
	}
	For (i,1,n) {
		add(kk,i); a[i]--;
		dfs(kk+1);
		a[i]++;
	}
}

int main() {
	file();
	read(n); read(k);
	For (i,1,n) read(a[i]);
	ll N=n;
	For (i,1,k) {
		b[i]=quick(N,modd-2);
		N=(N*n)%modd;
	}
	dfs(1);
	printf("%lld\n",(ans+modd)%modd);
	return 0;
}
