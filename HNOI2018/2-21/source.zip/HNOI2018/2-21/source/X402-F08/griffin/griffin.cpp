#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=200+10;
const int maxm=40000+10;
struct egde {
	int to,d,next;
}e[maxm<<1];
struct node {
	int u,cnt;
	node() { cnt=0; }
};
int n,m,c;
int tot;
int head[maxn],b[maxn];

inline void file() {
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void add(int from,int to,int d) {
	tot++;
	e[tot].to=to; e[tot].d=d; e[tot].next=head[from]; head[from]=tot;
}

inline int bfs() {
	queue<node>q;
	node p1,p2;
	p1.u=1; p1.cnt=0;
	q.push(p1);
	while (!q.empty()) {
		p1=q.front(); q.pop();
		if (p1.u==n) return p1.cnt;
		for (int i=head[p1.u];i!=0;i=e[i].next)
			if (p1.cnt>=b[e[i].d]) {
				int v=e[i].to;
				p2.u=v; p2.cnt=p1.cnt+1;
				q.push(p2);
			}
	}
	return 0;
}

int main() {
	file();
	read(n); read(m); read(c);
	For (i,1,m) {
		int x,y,z; read(x); read(y); read(z);
		add(x,y,z);
	}
	For (i,1,c) read(b[i]);
	if (c==1) {
		if (b[1]>0) printf("Impossible\n");
		else printf("%d\n",bfs());
		return 0;
	}
	int ans=bfs();
	if (!ans) printf("Impossible\n");
	else printf("%d\n",ans);
	return 0;
}
