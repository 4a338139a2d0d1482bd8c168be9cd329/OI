#include<bits/stdc++.h>
using namespace std;
#define mod 998244353
#define ll long long
#define N 100010
ll n,k;
ll ksm(ll x,ll r)
{
	ll tmp=x%mod;
	ll res=1;
	while(r) 
	{
		if(r&1) (res*=tmp)%=mod;
		(tmp*=tmp)%=mod;
		r>>=1ll;
	}
	return res%mod;
}
ll a[N],ans;
void dfs(ll x,ll sum)
{
	if(x==k+1)
	{
		ans=(ans+sum)%mod;
		return ;
	}
	for(int i=1;i<=n;++i) 
	{
		ll tot=1;
		for(int j=1;j<=n;++j) 
			if(j!=i) (tot*=a[j])%=mod;
		a[i]--;
		dfs(x+1,(sum+tot)%mod);
		a[i]++;
	}
}
int main()
{
	freopen("Manastorm.in","r",stdin);
	freopen("Manastorm.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;++i) scanf("%lld",&a[i]);
	dfs(1,0);
	ans=(ans%mod+mod)%mod;
	printf("%lld\n",ans%mod*ksm(ksm(n,k),mod-2)%mod);
	return 0;
}
