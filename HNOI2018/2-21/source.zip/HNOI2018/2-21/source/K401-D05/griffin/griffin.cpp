#include<bits/stdc++.h>
using namespace std;
#define Temp template<typename T>
#define N 200
#define M 40050
Temp inline void read(T &x)
{
	x=0;char c=getchar();T f=1;
	while(!isdigit(c)) {if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

int n,m,c;
struct A
{
	int to,last,w;
}E[M<<1];
int beg[N],e;
int h[N],dis[N];
bool vis[N];
void add(int u,int v,int w)
{
	E[++e].to=v;
	E[e].last=beg[u];
	beg[u]=e;
	E[e].w=w;
}
void putin()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	int x,y,z;
	read(n),read(m),read(c) ;
	for(int i=1;i<=m;++i) 
	{
		read(x),read(y),read(z);
		add(x,y,z);
	}
	for(int i=1;i<=c;++i) {read(x);h[i]=x;}
}
void jiao17()
{
	if(h[1]>0) {puts("Impossible");return ;}
	for(int i=1;i<=n;++i) dis[i]=0x3f3f3f3f;
	queue<int>q;
	q.push(1);
	vis[1]=1;
	dis[1]=0;
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		vis[u]=0;
		for(int i=beg[u];i;i=E[i].last)
		{
			int v=E[i].to;
			if(dis[v]>dis[u]+1)
			{
				dis[v]=dis[u]+1;
				if(!vis[v])
				{
					vis[v]=1;
					q.push(v);
				}
			}
		}
	}
	printf("%d",dis[n]);
	return ;
}
int main()
{
	putin();
	if(c==1) jiao17();
	return 0;
}
