#include<bits/stdc++.h>
#define N 100100
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n;
string s[N];
map<string,int>mapp,accu[N];
int main()
{
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	read(n);
	map<string,int>::iterator it;
	for(int i=1;i<=n;i++)
	{
		cin>>s[i];
		int len=s[i].size();
		for(int j=0;j<len;j++)
			for(int k=1;k<=len-j;k++)
			{
				string ss=s[i].substr(j,k);
				mapp[ss]++;
				accu[i][ss]++;
			}
		long long sum=0;
		for(int r=1;r<=i;r++)
		{
			it=accu[r].begin();
			for(;it!=accu[r].end();it++)
			sum+=it->second*mapp[it->first];
		}
		printf("%lld\n",sum);
	}
	return 0;
}
