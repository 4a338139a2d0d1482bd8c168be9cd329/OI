#include<bits/stdc++.h>
#define N 40100
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n,m,c,e;
int to[N],beg[200],nex[N],level[N],w[N],val[N];
void add(int x,int y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
void spfa(int s,int t)
{
	int vis[N]={0},dis[N];
	for(int i=1;i<=n;i++)dis[i]=0x7f7f7f7f;
	queue<int>q;
	q.push(s);
	vis[s]=1;
	dis[s]=0;
	while(!q.empty())
	{
		int k=q.front();
		q.pop();
		vis[k]=0;
		for(int i=beg[k];i;i=nex[i])
		{
			int y=to[i];
			if(dis[y]>dis[k]+1)
			{
				dis[y]=dis[k]+1;
				if(!vis[y])
				{
					vis[y]=1;
					q.push(y);
				}
			}
		}
	}
	if(dis[t]!=0x7f7f7f7f)printf("%d\n",dis[t]);
	else printf("Impossible\n");
}
typedef pair<int,int> pi;
void bfs()
{
	int ans=0x7f7f7f7f;
	queue<pi>q;
	map<pi,bool>mapp;
	q.push(pi(1,0));
	while(!q.empty())
	{
		pi k=q.front();
		q.pop();
		if(k.second>w[n]+m)continue;
		if(k.second>=ans)continue;
		if(k.first==n){ans=min(ans,k.second);continue;}
		for(int i=beg[k.first];i;i=nex[i])
		{
			int y=to[i];
			if(k.second+1<=w[i])continue;
			if(!mapp[pi(y,k.second+1)])
			{
				mapp[pi(y,k.second+1)]=1;
				q.push(pi(y,k.second+1));
			}
		}
	}
	if(ans==0x7f7f7f7f)printf("Impossible\n");
	else printf("%d\n",ans);
}
void solve1()
{
	if(w[1])printf("Impossible\n");
	else spfa(1,n);
	exit(0);
}
int main()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	read(n);read(m);read(c);
	for(int i=1;i<=m;i++)
	{
		static int x,y;
		read(x);read(y);read(level[i]);
		add(x,y);
	}
	for(int i=1;i<=c;i++)read(val[i]);
	for(int i=1;i<=m;i++)w[i]=val[level[i]];
	if(m==0)return printf("Impossible\n"),0;
	if(c==1)solve1();
	bool flag=true;
	for(int i=beg[1];i;i=nex[i])
		if(w[i]==0){flag=false;break;}
	if(flag)return printf("Impossible\n"),0;
	if(w[n]<=1000)
	{
		bfs();
		return 0;
	}
	return 0;
}
