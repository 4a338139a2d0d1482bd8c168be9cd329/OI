#include<bits/stdc++.h>
#define N 100100
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
long long n,k;
long long a[N];
long long ksm(long long x,long long mc)
{
	long long tmp=x%mod;
	long long res=1ll;
	while(mc)
	{
		if(mc&1ll)res=res*tmp%mod;
		tmp=tmp*tmp%mod;
		mc>>=1ll;
	}
	return res;
}
long long ans;
void dfs(long long x,long long sum)
{
	if(x==k+1)
	{
		ans=(ans+sum)%mod;
		return ;
	}
	for(int i=1;i<=n;i++)
	{
		long long tot=1;
		for(int j=1;j<=n&&tot!=0;j++)
			if(i!=j)(tot*=a[j])%=mod;
		a[i]--;
		dfs(x+1,(sum+tot)%mod);
		a[i]++;
	}
}
int dp[400][400];
int main()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	read(n);read(k);
	for(long long i=1;i<=n;i++)read(a[i]);
	if(n<=10&&k<=7)
	{
		dfs(1,0);
		ans=(ans%mod+mod)%mod;
		printf("%lld\n",ans%mod*ksm(ksm(n,k),mod-2)%mod);
		return 0;
	}
	else if(n==2)
	{
		long long A=a[1],b=a[2];
		printf("%lld\n",(((A+A-k+1ll)%mod*ksm(2,mod-2)%mod*k%mod+(b+b-k+1)%mod*ksm(2,mod-2)%mod*k%mod)%mod*ksm(ksm(n,k),mod-2)%mod+mod)%mod);
		return 0;
	}
	else 
	{
		dfs(1,0);
		ans=(ans%mod+mod)%mod;
		printf("%lld\n",ans%mod*ksm(ksm(n,k),mod-2)%mod);
		return 0;
	}
	return 0;
}
