#include<cstdio>
#include<queue>
#include<cstring>
#include<string>
#include<map>
#include<iostream>
#include<cstdlib>
#define neko 100010
#define meko 40010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
using namespace std;
string s[neko];
int n,len;
long long ele[neko];
map<string,int>Fr,accu[neko];
int main()
{
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	string a;
	scanf("%d",&n);getchar();
	f(i,1,n)
	{
		cin>>s[i];
		len=s[i].size();
		f(j,0,len-1)
		 f(k,1,len-j)
		 {
		 	a=s[i].substr(j,k);
		 	++accu[i][a],++Fr[a];
		 	//cout<<a<<endl;
		 }map<string,int>::iterator it;
		 f(j,1,i)
		  for(it=accu[j].begin();it!=accu[j].end();++it)
		   ele[i]+=it->second*Fr[it->first];
	}f(i,1,n)printf("%lld\n",ele[i]);
	return 0;
}
