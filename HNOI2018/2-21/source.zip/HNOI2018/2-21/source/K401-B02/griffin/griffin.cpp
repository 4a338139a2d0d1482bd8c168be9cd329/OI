#include<cstdio>
#include<queue>
#include<cstring>
#define neko 310
#define meko 40010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
#define travel(i,u,v) for(register int i=head[u],v=e[i].v;i;i=e[i].next,v=e[i].v)
using std::queue;
struct node
{
	int v,w,next;
}e[meko<<1];
int real[110],renown,n,m,c,t;
typedef int arr[neko];
arr head,dis,book;
void add(int x,int y,int z)
{
	e[++t].v=y;
	e[t].w=z;
	e[t].next=head[x];
	head[x]=t;
}
void bfs()
{
	queue<int>q;
	q.push(1);
	int u;
	while(!q.empty())
	{
		u=q.front(),q.pop();
		book[u]=0;
		travel(i,u,v)
		{
			if(real[e[i].w]<=renown&&!book[v])
			{
				q.push(v),book[v]=1;
				if(v==n){printf("%d\n",renown+1);return;}
			}
		}++renown;
	}printf("Impossible\n");
}
int spfa()
{
	int u;
	queue<int>q;
	q.push(1);
	memset(dis,0x3f,sizeof(dis));
	dis[1]=0,book[1]=1;
	while(!q.empty())
	{
		u=q.front(),q.pop();
		book[u]=0;
		travel(i,u,v)
		{
			if(dis[v]>dis[u]+1)
			{
				dis[v]=dis[u]+1;
				if(!book[v])q.push(v),book[v]=1;
			}
		}
	}return dis[n];
}
int main()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	int x,y,z;
	scanf("%d%d%d",&n,&m,&c);
	f(i,1,m)scanf("%d%d%d",&x,&y,&z),add(x,y,z);
	f(i,1,c)scanf("%d",&real[i]);	
	if(real[1])return printf("Impossible\n")*0;
	if(c==1)return printf("%d\n",spfa())*0;
	bfs();return 0;
}
