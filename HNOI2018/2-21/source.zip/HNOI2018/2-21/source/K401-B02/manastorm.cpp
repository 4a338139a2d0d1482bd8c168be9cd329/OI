#include<cstdio>
#include<queue>
#include<cstring>
#define neko 100010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
#define travel(i,u,v) for(register int i=head[u],v=e[i].v;i;i=e[i].next,v=e[i].v)
typedef long long ll;
ll mod=998244353,ans,a[neko];
int n,k;
ll slowpow(ll m,ll n)
{
    long long b=1;
    while(n>0)
    {
          if(n&1)b=(b*m)%mod;
          n>>=1;
          m=(m*m)%mod;
    }
    return b;
} 
void dfs(int step,ll now)
{
	if(step==k+1)
	{
		ans=(ans+now)%mod;
		return;
	}
	f(i,1,n)
	{
		ll sum=1;
		f(j,1,n)if(i!=j)sum*=a[j],sum%=mod;
		--a[i];
		dfs(step+1,(now+sum)%mod);
		++a[i];
	}
}
int main()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	scanf("%d%d",&n,&k);
	f(i,1,n)scanf("%lld",&a[i]);
	ll slp=(slowpow(n,k)*slowpow(2,mod-2))%mod;
	if(n<=10&&k<=10)dfs(1,0);
	else if(n==2) {ans=(((a[1]+a[1]-k+1LL)%mod*slowpow(2,mod-2)%mod*slp)
	+((a[2]+a[2]-k+1LL)%mod*slowpow(2,mod-2))%mod*slp)%mod;}
	printf("%lld\n",(ans*slowpow(slowpow(n,k),mod-2)%mod+mod)%mod);
}
