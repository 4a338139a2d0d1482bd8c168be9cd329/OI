/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-21 10:08
#
# Filename: gen.cpp
#
# CopyRight 
#
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

int main()
{
    freopen("griffin.in", "w", stdout);
    srand(time(0));
    int n = 180, m = 40000, c = 50;    
    printf("%d %d %d\n", n, m, c);
    REP(i, 1, m)
    {
        int u = rand() % n + 1, v = rand() % n + 1;
        printf("%d %d %d\n", u, v, rand() % c + 1);
    }
    int a[1000];
    REP(i, 1, c)
    {
        a[i] = rand() % 1000 + 1;
    }
    a[1] = 0;
    sort ( a + 1, a + c + 1 );
    REP(i, 1, c)
    {
        printf("%d ", a[i]);
    }
    puts("");
    return 0;
}

