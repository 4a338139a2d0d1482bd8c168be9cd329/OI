/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-21 08:36
#
# Filename: griffin.cpp
#
# CopyRight 
#
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;

const int maxn = 200;

int Map[maxn][maxn], Begin[maxn * maxn], Next[maxn * maxn], To[maxn * maxn], W[maxn], e;

int n, c, m, a[maxn];

void add(int u, int v, int w)
{
    To[++ e] = v;
    Next[e] = Begin[u];
    Begin[u] = e;
    W[e] = w;
}

struct node
{
    int x, s;
}p1, p2;

void BFS()
{
    int cnt = 0;
    queue<node> Q;
    p1.x = 1, p1.s = 0;
    Q.push(p1);
    while ( !Q.empty() || cnt > (1000 + m) )
    {
        p1 = Q.front();
        Q.pop();
        if ( p1.x == n )
        {
            printf("%d\n", p1.s);
            return ;
        }
        for ( int i = Begin[p1.x]; i; i = Next[i] )
        {
            int u = To[i];
            if ( p1.s >= a[W[i]] )
            {
                // printf("%d %d %d %d %d\n", p1.x, u, p1.s, W[i], a[W[i]]);
                p2.s = p1.s + 1;
                p2.x = u;
                Q.push(p2);
            }
        }
    }
    printf("Impossible\n");
}

int main()
{
    // freopen("griffin3.in", "r", stdin);
    // freopen("griffin.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &c);
    REP(i, 1, m)
    {
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        if ( !Map[u][v] ) Map[u][v] = w;
        else Map[u][v] = min(Map[u][v], w);
    }
    m = 0;
    REP(i, 1, n)
    {
        REP(j, 1, n)
        {
            if ( Map[i][j] )
            {
                ++ m;
                add(i, j, Map[i][j]);
            }
        }
    }
    REP(i, 1, c)
    {
        scanf("%d", &a[i]);
    }
    BFS();
    return 0;
}

