/**********************************************************
	File:griffin.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-21 08:51:22
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 200
#define C 100
#define W 10010
int n,m,c,ap[N][N],w[C],vis[N][W];
#include<queue>
queue<int>q,ww;
int main()
{
	//freopen("griffin.in","r",stdin);
	//freopen("griffin1.out","w",stdout);
	n=read();
	m=read();
	c=read();
	fr(i,1,m)
	{
		int u=read(),v=read(),w=read();
		if(ap[u][v])ap[u][v]=min(ap[u][v],w);
		else ap[u][v]=w;
	}
	fr(i,1,c)
		w[i]=read();
	fr(i,1,n)
		fr(j,1,n)
			if(ap[i][j])ap[i][j]=w[ap[i][j]];
			else ap[i][j]=-1;
	q.push(1);
	ww.push(0);
	while(!q.empty())
	{
		int u=q.front(),w=ww.front();
		q.pop();
		ww.pop();
		if(u==n)
		{
			printf("%d\n",w);
			return 0;
		}
		if(vis[u][w])continue;
		vis[u][w]=1;
		fr(v,1,n)
			if(ap[u][v]!=-1&&ap[u][v]<=w)
			{
				q.push(v);
				ww.push(w+1);
			}
	}
	printf("Impossible\n");
	return 0;
}
