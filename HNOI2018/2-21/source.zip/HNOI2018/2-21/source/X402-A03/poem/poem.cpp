/**********************************************************
	File:poem.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-21 10:31:05
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(long long i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(long long i=(a),_end_=(b);i>=_end_;i--)
long long read()
{
	long long r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
struct trie
{
	long long num;
	trie *s[26];
	trie()
	{
		num=0;
		fr(i,0,25)s[i]=NULL;
	}
}*root;
#define L 300010
int n,l;
long long ans;
char s[L];
int main()
{
	root=new trie;
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	n=read();
	fr(i,1,n)
	{
		scanf("%s",s+1);
		l=strlen(s+1);
		fr(i,1,l)
		{
			trie *k=root;
			fr(j,i,l)
			{
				if(k->s[s[j]-'a']==NULL)
					k->s[s[j]-'a']=new trie;
				k=k->s[s[j]-'a'];
				k->num++;
				ans+=k->num+k->num-1;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}