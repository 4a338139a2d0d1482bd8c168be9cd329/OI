/**********************************************************
	File:manastorm.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-21 09:40:23
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(long long i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(long long i=(a),_end_=(b);i>=_end_;i--)
long long read()
{
	long long r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 100010
#define mod 998244353
long long n,k,a[N],f[N],ans,pf[N];
long long power(long long x,long long y,long long m)
{
	long long r=1;
	while(y)
	{
		if(y&1)r=r*x%m;
		x=x*x%m;
		y>>=1;
	}
	return r;
}
void dfs(int x,long long d)
{
	if(x==k+1)
	{
		ans=(ans+d+mod)%mod;
//		printf("%lld\n",d);
		return;
	}
	fr(i,1,n)
	{
		a[i]--;
		long long k=1;
		fr(j,1,n)
			if(i!=j)
				k=k*a[j]%mod;
		dfs(x+1,(d+k+mod)%mod);
		a[i]++;
	}
}
int main()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	n=read();
	k=read();
	fr(i,1,n)
		a[i]=read();
	if(n==2)
	{
		f[0]=pf[0]=1;
		f[1]=pf[1]=1;
		fr(i,2,k)f[i]=f[i-1]*i%mod,pf[i]=power(f[i],mod-2,mod);
		fr(i,0,k)
			ans=(ans+(i*a[2]+(k-i)*a[1]-i*(k-i))%mod*f[k]%mod*pf[i]%mod*pf[k-i]%mod+mod)%mod;
		printf("%lld\n",ans*power(power(2,k,mod),mod-2,mod)%mod);
		return 0;
	}
	dfs(1,0);
	printf("%lld\n",ans*power(power(n,k,mod),mod-2,mod)%mod);
	return 0;
}