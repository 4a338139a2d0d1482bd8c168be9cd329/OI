#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
using namespace std;
int main(){
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	while(1)cout<<"YIZHU I LOVE YOU"<<endl;
	return 0;
}
