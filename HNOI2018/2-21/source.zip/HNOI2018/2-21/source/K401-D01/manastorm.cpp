#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=(int)1e5+10;
const ll mod=998244353;
ll A[maxn],N,K;
ll x,y;
ll exgcd(ll a,ll b,ll &x,ll &y){
	if(b==0){
		x=1,y=0;
		return a;
	}ll gcd=exgcd(b,a%b,x,y);
	ll tmp=x;x=y,y=tmp-(a/b)*y;
	return gcd;
}
ll Pow(ll s,ll t){
	ll ans=1;
	for(;t;t>>=1){
		if(t&1)ans=ans*s%mod;
		s=s*s%mod;
	}return ans;
}
ll inv(int fuck){
	exgcd(fuck,mod,x,y);
	return (x%mod+mod)%mod;
}
inline ll cal(int pos){
	ll ans=1;
	for(register int i=1;i<=N;++i)if(i!=pos)ans=(ans*A[i]+mod)%mod;
	return ans;
}
ll cnt=0;
ll ANS=0;
inline void dfs(ll dep){
	if(dep==K){
		++cnt;
		return;
	}
	for(register int i=1;i<=N;++i){
		--A[i];
		ANS=(ANS+(cal(i)%mod*Pow(N,K-dep-1)%mod+mod)%mod)%mod;
		dfs(dep+1);
		++A[i];
	}
}
int main(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	cin>>N>>K;
	for(register int i=1;i<=N;++i)scanf("%lld",&A[i]);
	dfs(0);
	printf("%lld\n",(ANS*inv(cnt)+mod)%mod);
	return 0;
}
