#include<bits/stdc++.h>
using namespace std;
const int maxn=200+10;
const int maxm=(int)4e4+10;
int fst[maxm],lst[maxm],to[maxm],lv[maxm],e;
int w[maxn];
inline void added(int x,int y,int z){
	to[++e]=y,lv[e]=z,lst[e]=fst[x],fst[x]=e;
}
int stp[maxn],N,M,C,vis[maxn];
int ANS=-1;
inline void init(){
	cin>>N>>M>>C;
	int x,y,z;
	for(register int i=1;i<=M;++i)scanf("%d%d%d",&x,&y,&z),added(x,y,z);
	for(register int i=1;i<=C;++i)scanf("%d",&w[i]);
}
inline void c1(){
	if(w[1]){
		cout<<"Impossible"<<endl;
		return;
	}queue<int>q;
	q.push(1);
	while(!q.empty()){
		int u=q.front();q.pop();
		vis[u]=1;
		if(u==N){
			ANS=stp[u];
			break;
		}
		for(register int i=fst[u];i;i=lst[i]){
			int v=to[i];
			if(!vis[v])stp[v]=stp[u]+1,q.push(v);
		}
	}
	if(ANS>=0)cout<<ANS<<endl;
	else cout<<"Impossible"<<endl;
}
inline void c2(){
	queue<int>q;
	q.push(1);
	while(!q.empty()){
		int u=q.front();q.pop();
		if(u==N){
			ANS=stp[u];
			break;
		}
		for(register int i=fst[u];i;i=lst[i]){
			if(w[lv[i]]>stp[u])continue;
			int v=to[i];
			stp[v]=stp[u]+1;
			q.push(v);
		}
	}if(ANS>=0)cout<<ANS<<endl;
	else cout<<"Impossible"<<endl;
	return;
}
int main(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	init();
	if(C==1)c1();
	else c2();
	return 0;
}

