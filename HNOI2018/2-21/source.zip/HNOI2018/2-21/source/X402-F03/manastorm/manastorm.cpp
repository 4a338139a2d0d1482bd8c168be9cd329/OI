#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
const ll mod=998244353;
int n,K,n_ny;
ll a[1010],ans;
ll power(ll x,ll k)
{
	ll sss=1;
	while (k)
	{
		if (k%2) sss=sss*x%mod;
		x=x*x%mod;
		k/=2;
	}
	return sss;
}
void dfs(int deep,ll doe)
{
	if (deep>K) return;
	for (int i=1;i<=n;++i)
	{
		--a[i];
		ll sss=1;
		for (int j=1;j<=n;++j)
			if (i!=j)
				sss=sss*a[j]%mod;
		sss=((sss*doe%mod)+mod)%mod;
		ans=(ans+sss)%mod;
		dfs(deep+1,doe*n_ny%mod);
		++a[i];
	}
}
int main()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	scanf("%d%d",&n,&K);
	for (int i=1;i<=n;++i)
		scanf("%lld",&a[i]);
	n_ny=power(n,mod-2);
	dfs(1,n_ny);
	printf("%lld\n",ans);
	return 0;
}
