#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
const int inf=99999999;
int n,m,c,doe;
int mp[210][210];
int pre[101010],son[101010],now[220],v[101010];
bool f[2][210];
int w[60];
void add(int x,int y,int z)
{
	++doe;
	pre[doe]=now[x];
	now[x]=doe;
	son[doe]=y;
	v[doe]=z;
}
int main()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	memset(mp,0x3f3f3f3f,sizeof(mp));
	scanf("%d%d%d",&n,&m,&c);
	int x,y,z;
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d%d",&x,&y,&z);
		mp[x][y]=min(mp[x][y],z);
	}
	for (int i=1;i<=c;++i)
		scanf("%d",&w[i]);
//	printf("finish_read\n");
	for (int i=1;i<=n;++i)
	for (int j=1;j<=m;++j)
		if (mp[i][j]<inf)
			add(i,j,mp[i][j]);
	
	if (n==1)
	{
		printf("0\n");
		return 0;
	}
	f[0][1]=1;
	for (int ii=1;;++ii)
	{
	//	printf("aa\n");
//		printf("ii:%d\n",ii);
		int i=ii%2;
		if (ii>1700)
		{
			printf("Impossible\n");
			return 0;
		}
	//	printf("a\n");
	//	printf("aaaaai:%d\n",i);
		for (int j=1;j<=n;++j)
			f[i][j]=0;
		for (x=1;x<=n;++x)
		{
//			printf("%d\n",x);
			int p=now[x];
			while (p)
			{
				y=son[p];
//				printf("v[p]:%d %d %d\n",w[v[p]],i,i^1);
				if (w[v[p]]<=ii-1)
					f[i][y]|=f[i^1][x];
//				printf("==\n");
				p=pre[p];
//				printf("p:%d\n",p);
			}		
		}
		if (f[i][n])
		{
			printf("%d\n",ii);
			return 0;
		}

	}

	return 0;
}
