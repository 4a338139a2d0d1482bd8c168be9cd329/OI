#include<bits/stdc++.h>
#define ll long long
using namespace std;
int qmax(int &x,int y) {if (x<y) x=y;}
int qmin(int &x,int y) {if (x>y) x=y;}
int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e5+10;
const ll mod=998244353;
int n;
ll k;
ll a[maxn],s,ans,sum;
ll ksm(ll x,int y)
{
	ll ss=1;
	while (y)
	{
		if (y&1) ss=ss*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return ss;
}
void dfs(int x)
{
	if (x==k+1)
	{
		sum++;
		ans+=s;ans%=mod;
		return;
	}
	for (int i=1;i<=n;i++)
	{
		a[i]--;
		int s1=1;
		for (int j=1;j<=n;j++)
		{
			if (j!=i) s1*=a[j]%mod;
		}
		s=(s+s1)%mod;
		dfs(x+1);
		s=(s-s1)%mod;
		a[i]++;
	}
}
void work1()
{
	dfs(1);
	sum=ksm(sum,mod-2);
	ans=ans*sum%mod;
	ans=(ans+mod)%mod;
	printf("%lld\n",ans);
}
void work2()
{
	ans=(1+k)%mod*k%mod*ksm(2,mod-1)%mod*((a[1]+a[2]+k)%mod)%mod;
	ans-=k%mod*(k+1)%mod*((2*k+1)%mod)%mod*ksm(6,mod-2)%mod;
	printf("%lld\n",ans);
}
int main()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	n=read();k=read();
	for (int i=1;i<=n;i++) a[i]=read();
	work1();
	return 0;
}
