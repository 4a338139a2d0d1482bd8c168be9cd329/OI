#include<bits/stdc++.h>
#define ll long long
using namespace std;
int qmax(int &x,int y) {if (x<y) x=y;}
int qmin(int &x,int y) {if (x>y) x=y;}
int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
map<string,int> Map;
char ch[3010],a[3010];
char b[3010][3010];
int n,l,id,p;
ll ans[3010];
int main()
{
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	n=read();
	for (int T=1;T<=n;T++)
	{
		scanf("%s",ch+1);
		l=strlen(ch+1);
		for (int i=1;i<=l+1;i++) b[T][i]=ch[i];
		for (int i=1;i<=l;i++)
		{
			p=-1;
			for (int j=i;j<=l;j++)
			{
				p++;
				a[p]=ch[j];
				a[p+1]='\0';
				Map[a]++;
			}
		}
		for (int k=1;k<=T;k++)
		{
			l=strlen(b[k]+1);
			for (int i=1;i<=l;i++)
			{
				p=-1;
				for (int j=i;j<=l;j++)
				{
					p++;
					a[p]=b[k][j];
					a[p+1]='\0';
					ans[T]+=Map[a];
				}
			}
		}
		printf("%lld\n",ans[T]);
	}
	return 0;
}
