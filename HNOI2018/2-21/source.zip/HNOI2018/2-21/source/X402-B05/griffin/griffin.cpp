#include<bits/stdc++.h>
#define ll long long
using namespace std;
int qmax(int &x,int y) {if (x<y) x=y;}
int qmin(int &x,int y) {if (x>y) x=y;}
int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF) exit(0);
	if(s=='-') base=-1,s=getchar();
	while(isdigit(s)) k=k*10+(s^'0'),s=getchar();
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
int n,m,c;
int f[200][200];
int w[200];
void work1()
{
	int x,y,z;
	memset(f,1,sizeof(f));
	int inf=f[1][1];
	for (int i=1;i<=n;i++) f[i][i]=0;
	for (int i=1;i<=m;i++)
	{
		x=read();y=read();z=read();
		f[x][y]=1;
	}
	for (int i=1;i<=c;i++) w[i]=read();
	for (int k=1;k<=n;k++)
		for (int i=1;i<=n;i++)
		{
			if (i==k) continue;
			for (int j=1;j<=n;j++)
			{
				if (j!=i&&j!=k) qmin(f[i][j],f[i][k]+f[k][j]);
			}
		}
	if (f[1][n]>=inf)
	{
		printf("Impossible");
	} else
	{
		printf("%d\n",f[1][n]);
	}
}
vector<int> G[60];
void work2()
{
	int x,y,z;
	memset(f,1,sizeof(f));
	int inf=f[1][1];
	for (int i=1;i<=n;i++) f[i][i]=0;
	for (int i=1;i<=m;i++)
	{
		x=read();y=read();z=read();
		f[x][y]=1;
	}
	for (int i=1;i<=c;i++) w[i]=read();
	for (int k=1;k<=n;k++)
		for (int i=1;i<=n;i++)
		{
			if (i==k) continue;
			for (int j=1;j<=n;j++)
			{
				if (j!=i&&j!=k) qmin(f[i][j],f[i][k]+f[k][j]);
			}
		}

}
int main()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	n=read();m=read();c=read();
	if (c==1)
	{
		work1();
		return 0;
	}
	if (m<=1000)
	{
	

	}
	printf("Impossible");
	return 0;
}
