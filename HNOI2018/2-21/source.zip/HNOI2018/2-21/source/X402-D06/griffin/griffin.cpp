#include<bitset>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=180+10;
const int maxm=4e4+10;
int w[maxn],q[maxn],dis[maxn],to[maxm],nex[maxm],beg[maxn],Lv[maxm],vis[maxn];
int n,e;
struct Matrix{
	bitset<maxn> A[maxn];
	Matrix(){
		int i,j;
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				A[i][j]=0;
	}
};
inline Matrix operator * (const Matrix &lhs,const Matrix &rhs){
	int i,j;
	Matrix ans,tmp;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			tmp.A[i][j]=rhs.A[j][i];
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			ans.A[i][j]=(lhs.A[i] & tmp.A[j]).count()?1:0;
	return ans;
}
struct Edge{
	int x,y,lv;
}edge[maxm];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y,int z){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	Lv[e]=z;
}
inline Matrix fpm(Matrix base,int power,Matrix A){
	while(power){
		if(power & 1)A=A*base;
		base=base*base;power/=2;
	}
	return A;
}
inline int Bfs(int f,int l,int lim){
	int i;
	while(f<l){
		int x=q[++f];
		for(i=beg[x];i;i=nex[i])
			if(!vis[to[i]] && Lv[i]<lim){
				vis[to[i]]=1;
				dis[to[i]]=dis[x]+1;
				q[++l]=to[i];
			}
	}
	return dis[n]>INF?-1:dis[n];
}
int main(){
	int i,j,k,m,c;
#ifndef ONLINE_JUDGE
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
#endif
	n=read();m=read();c=read();
	for(i=1;i<=m;i++){
		int x=read(),y=read(),lv=read();
		add(x,y,lv);
		edge[i]=(Edge){x,y,lv};
	}
	for(i=1;i<=c;i++)w[i]=read();
	if(w[1])return puts("Impossible"),0;
	Matrix res;w[1]=1;
	for(i=1;i<=e;i++)
		if(edge[i].lv==1)
			res.A[edge[i].x][edge[i].y]=1;
	w[c+1]=INF;
	for(i=2;i<=c+1;i++){
		Matrix A;
		for(j=1;j<=m;j++)
			if(edge[j].lv<i)
				A.A[edge[j].x][edge[j].y]=1;
		int l=0;
		memset(vis,0,sizeof(vis));memset(dis,63,sizeof(dis));
		for(j=1;j<=n;j++)if(res.A[1][j])q[++l]=j,dis[j]=0,vis[j]=1;
		int ans=Bfs(0,l,i);
		if(ans!=-1)return printf("%d\n",w[i-1]+ans),0;
		res=fpm(A,w[i]-w[i-1],res);
	}
	puts("Impossible");
	return 0;
}

