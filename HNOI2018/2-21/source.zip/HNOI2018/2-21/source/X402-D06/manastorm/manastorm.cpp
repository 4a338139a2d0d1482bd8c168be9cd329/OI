#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const int mod=998244353;
const long double eps=1e-9;
const int maxn=10;
int a[maxn];
ll ans=0,n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
void dfs(int cur,int tot,ll Sum){
	int i,j;
	if(cur>tot){
		ans=(ans+Sum)%mod;
		return;
	}
	for(i=1;i<=n;i++){
		a[i]--;
		ll prod=1;
		for(j=1;j<=n;j++){
			if(j==i)continue;
			prod=prod*a[j]%mod;
		}
		dfs(cur+1,tot,(Sum+prod)%mod);
		a[i]++;
	}
}
inline ll fpm(ll base,ll b){
	ll res=1;
	while(b){
		if(b & 1)res=res*base%mod;
		base=base*base%mod;b/=2;
	}
	return res;
}
int main(){
	int i,k;
#ifndef ONLINE_JUDGE
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
#endif
	n=read();k=read();
	for(i=1;i<=n;i++)a[i]=read();
	dfs(1,k,0);
	ans=(ans%mod+mod)%mod;
	printf("%lld\n",ans*fpm(fpm(n,k),mod-2)%mod);
	return 0;
}

