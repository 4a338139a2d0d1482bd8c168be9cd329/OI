#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int mod=998244353;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int A[N],n,k,ans=0,pw[N];
void dfs(int r)
{
	if(r==k+1) return ;
	for(int i=1;i<=n;++i)
	{
		A[i]--;
		int mul=1;
		for(int j=1;j<=n;++j) if(i!=j) mul=1ll*mul*(A[j]+mod)%mod;
		ans=(ans+1ll*pw[r]*mul)%mod;
		dfs(r+1);
		A[i]++;
	}
}

void wj()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
}
int main()
{
	wj();
	n=read(); k=read();
	for(int i=1;i<=n;++i) A[i]=read();
	pw[0]=1;
	for(int i=1;i<=k;++i) pw[i]=1ll*pw[i-1]*qpow(n,mod-2)%mod;
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
