#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<map>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef unsigned long long ul;

const int N=401;
const ul bas=233333;
char s[N][N],t[N*N][N];
ll fr[N*N];
int n,len[N*N],nex[N*N][N],tot=0;
map<ul,int>mp;

void wj()
{
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i)
	{
		scanf("%s",s[i]+1);
		int L=strlen(s[i]+1);
		for(int j=1;j<=L;++j) for(int k=j;k<=L;++k) 
		{
			ul Hash=0;
			for(int o=j;o<=k;++o) Hash=Hash*bas+s[i][o]-'a'+1;
			if(mp[Hash]) continue;
			mp[Hash]=1;
			tot++;
			for(int o=j;o<=k;++o) t[tot][++len[tot]]=s[i][o];
			int p=0; nex[tot][1]=0;
			for(int o=2;o<=len[tot];++o)
			{
				while(p&&t[tot][o]!=t[tot][p+1]) p=nex[tot][p];
				if(t[tot][o]==t[tot][p+1]) p++;
				nex[tot][o]=p;
			}
		}
	}

	ll ans=0;
	for(int i=1;i<=n;++i)
	{
		int L=strlen(s[i]+1);
		for(int j=1;j<=tot;++j)
		{
			int sum=0,p=0;
			for(int k=1;k<=L;++k)
			{
				while(p&&s[i][k]!=t[j][p+1]) p=nex[j][p];
				if(s[i][k]==t[j][p+1]) p++;
				if(p==len[j]) p=nex[j][p],sum++;
			}
			ans+=2ll*fr[j]*sum+1ll*sum*sum;
			fr[j]+=sum;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
