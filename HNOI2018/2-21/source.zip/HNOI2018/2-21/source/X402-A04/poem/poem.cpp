#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef unsigned long long ul;

const int N=3050;
const ul bas=233333;
const int rt=1;
const int SZ=2000051;
char s[300050];
vector<char>S[100050];
int ch[SZ][26],sz=1,fail[SZ];
void insert(int st,int len)
{
	int o=rt;
	for(int i=st;i<=len;++i)
	{
		int x=s[i]-'a';
		if(!ch[o][x]) ch[o][x]=++sz;
		o=ch[o][x];
	}
}
queue<int>q;
void buildfail()
{
	q.push(rt);
	while(!q.empty())
	{
		int o=q.front(); q.pop();
		for(int i=0;i<26;++i)
		{
			int v=ch[o][i];
			if(!v) {ch[o][i]=ch[fail[o]][i];continue;}
			if(o==rt) fail[v]=rt;
			else
			{
				int p=fail[o];
				while(p)
				{
					if(ch[p][i]) {fail[v]=ch[p][i];break;}
					p=fail[p];
				}
				if(!p) fail[v]=rt;
			}
			q.push(v);
		}
	}
}
ll fr[SZ];
int n;

void wj()
{
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i)
	{
		scanf("%s",s+1);
		int L=strlen(s+1);
		for(int j=1;j<=L;++j) insert(j,L);
		for(int j=0;j<L;++j) S[i].pb(s[j+1]);
	}
	buildfail();

	ll ans=0;
	for(int i=1;i<=n;++i)
	{
		//int L=strlen(s[i]+1);
		int L=S[i].size();
		int o=rt;
		for(int j=0;j<L;++j)
		{
			int x=S[i][j]-'a';
			o=ch[o][x];
			if(!o) o=rt;
			int p=o;
			while(p!=rt) 
			{
				ans+=2ll*fr[p]+1;
				fr[p]++;
				p=fail[p];
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
