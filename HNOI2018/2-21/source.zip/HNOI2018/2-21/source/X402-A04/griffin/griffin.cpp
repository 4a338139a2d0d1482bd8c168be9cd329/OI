#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<bitset>
#include<queue>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=195;
const int lv=55;
const int inf=0x3f3f3f3f;
bitset<N>mat[lv][N],bas[lv][N];
int n,m,c;
int lnk[N][N],val[lv],f[N][lv],dis[N];
bool vis[N];

queue<int>q;
bitset<N>ls[N],ret[N];
void mul(bitset<N> *a,bitset<N> *b)
{
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) ls[i][j]=b[j][i],ret[i][j]=0;
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) if((a[i]&ls[j]).any()) ret[i][j]=1;
	//for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) cerr<<a[i][j]<<(j==n?'\n':' ');
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) a[i][j]=ret[i][j];
}

void wj()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); c=read();
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read(),k=read();
		lnk[x][y]=k;
	}
	for(int i=1;i<=c;++i) val[i]=read();
	if(val[1]!=0) {printf("Impossible\n");return 0;}
	val[c+1]=0;
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) 
		if(lnk[i][j]) lnk[i][j]=val[lnk[i][j]];
		else lnk[i][j]=-1;
	sort(val+1,val+1+c+1);
	c=unique(val+1,val+1+c+1)-(val+1);
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) 
		if(lnk[i][j]!=-1) lnk[i][j]=lower_bound(val+1,val+1+c,lnk[i][j])-val;
		else lnk[i][j]=0;
	
	int k=1;
	for(;k<=c;++k)
	{
		for(int i=1;i<=n;++i) vis[i]=0;
		q.push(1); vis[1]=1;
		while(!q.empty())
		{
			int u=q.front(); q.pop();
			for(int v=1;v<=n;++v) if(lnk[u][v]&&lnk[u][v]<=k&&!vis[v])
				vis[v]=1,q.push(v);
		}
		if(vis[n]) break;
	}

	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) if(lnk[i][j]) 
		for(int l=lnk[i][j];l<=c;++l)
			bas[l][i][j]=1;
	for(int i=1;i<c;++i)
	{
		for(int j=1;j<=n;++j) mat[i][j][j]=1;
		int p=val[i+1]-val[i];
		for(;p;p>>=1,mul(bas[i],bas[i])) if(p&1) mul(mat[i],bas[i]);
	}
	//cerr<<mat[1][2][2]<<endl;

	f[1][1]=1;
	for(int j=2;j<=c;++j) for(int i=1;i<=n;++i)
	{
		for(int p=1;p<=n;++p) if(mat[j-1][p][i])
		{
			f[i][j]|=f[p][j-1];
			if(f[i][j]) break;
		}
	}

	q.push(n); dis[n]=0;
	while(!q.empty())
	{
		int u=q.front(); q.pop();
		for(int i=1;i<=n;++i) if(lnk[i][u]&&!dis[i])
		{
			dis[i]=dis[u]+1;
			q.push(i);
		}
	}

	int minn=inf*2;
	for(int i=1;i<=n;++i) if(f[i][k]) minn=min(minn,val[k]+dis[i]);
	if(minn==inf*2) printf("Impossible\n");
	else printf("%d\n",minn);
	return 0;
}
