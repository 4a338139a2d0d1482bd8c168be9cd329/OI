#include<bits/stdc++.h>
using namespace std;
const int maxn=200;
int n,m,c;
struct edge{
	int s,t,v;
	void readl(){
		scanf("%d%d%d",&s,&t,&v);
	}
}w[40010];
struct node{
	bool a[maxn][maxn];
	void mem(){
		memset(a,0,sizeof(a));
	}
	void csh(){
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++)
			a[i][i]=1;
	}
};
bitset<200> bitA[200],bitB[200];
node operator * (const node &A,const node &B){
	node res;
	res.mem();
	for(int i=1;i<=n;i++)
		bitA[i].reset(),bitB[i].reset();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(A.a[i][j]) bitA[i].set(j);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(B.a[i][j]) bitB[j].set(i);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			res.a[i][j]=(bitA[i]&bitB[j]).count();
	return res;
}
node powd(node x,long long y){
	node res;
	res.csh();
	while(y){
		if(y&1) res=res*x;;
		x=x*x;
		y>>=1;
	}
	return res;
}
int val[maxn];
int dis[maxn];
int beg[maxn],tto[40010],nex[40010],V[40010],e;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	V[e]=v;
}
void BFS(const node &A,int v){
	static int q[maxn];
	int l=1,r=0,u;
	for(int i=1;i<=n;i++){
		dis[i]=A.a[1][i]?0:-1;
		if(A.a[1][i]) q[++r]=i;
	}

	while(l<=r){
		u=q[l],l++;
		for(int i=beg[u];i;i=nex[i]){
			if(V[i]<=v&&dis[tto[i]]==-1){
				dis[tto[i]]=dis[u]+1;
				q[++r]=tto[i];
			}
		}
	}
}
int main(){
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	scanf("%d%d%d",&n,&m,&c);
	for(int i=1;i<=m;i++){
		w[i].readl();
		putin(w[i].s,w[i].t,w[i].v);
	}

	for(int i=1;i<=c;i++)
		scanf("%d",&val[i]);
	val[c+1]=1000000000;

	node Base,res,ans;
	res.csh(),ans.csh();
	int ps;
	for(ps=0;ps<=c;ps++){
		BFS(ans,ps);
		if(0<=dis[n]&&dis[n]<=val[ps+1]-val[ps]) break;

		Base.mem();
		for(int j=1;j<=m;j++)
			if(w[j].v<=ps)
				Base.a[w[j].s][w[j].t]=1;
		ans=ans*powd(Base,val[ps+1]-val[ps]);
	}
	if(ps>c){
		printf("Impossible\n");
		return 0;
	}
	printf("%d\n",val[ps]+dis[n]);
	return 0;
}
