#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=100100;
int a[maxn];
int n,m;
long long ans=0;
void dfs(int p,long long v){
	if(p>m){
		ans=(ans+v)%md;
		return;
	}
	long long r;
	for(int i=1;i<=n;i++){
		r=1;
		for(int j=1;j<=n;j++){
			if(i==j) continue;
			r=r*(md+a[j])%md;
		}
		a[i]--;
		dfs(p+1,(v+r)%md);
		a[i]++;
	}
}
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int main(){
	freopen("manastorm.in","r",stdin);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	dfs(1,0);
	printf("%lld\n",ans*powd(powd(n,m),md-2)%md);
	return 0;
}
