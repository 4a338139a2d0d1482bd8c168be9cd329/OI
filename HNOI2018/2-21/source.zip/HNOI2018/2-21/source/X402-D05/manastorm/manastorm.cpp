#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=400100;
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int n,m;
int a[maxn];
long long dp[maxn],dq[maxn];
long long f[maxn],g[maxn];
namespace mian{
	long long fac[maxn],inv[maxn];
	void solve(){
		fac[0]=1;
		for(int i=1;i<=m;i++)
			fac[i]=fac[i-1]*i%md;
		inv[m]=powd(fac[m],md-2);
		for(int i=m;i>=1;i--)
			inv[i-1]=inv[i]*i%md;

		dp[0]=1;
		for(int i=1;i<=n;i++){
			for(int j=0;j<=m;j++)
				f[j]=g[j]=0;
			for(int j=0;j<=m;j++)
				for(int k=0;k<=m-j;k++){
					f[j+k]=(f[j+k]+dp[j]*(a[i]-k+md)%md*inv[k])%md;
					g[j+k]=(g[j+k]+dq[j]*(a[i]-k+md)%md*inv[k])%md;
					g[j+k]=(g[j+k]+dp[j]*inv[k])%md;
				}
			for(int j=0;j<=m;j++)
				dp[j]=f[j],dq[j]=g[j];
		}
		long long ans=0;
		for(int i=1;i<=m;i++)
			ans=(ans+g[i-1]*fac[i-1]%md*powd(n,m-i))%md;
		printf("%lld\n",ans*powd(powd(n,m),md-2)%md);
	}
}
void solve(){
	memset(dp,0,sizeof(dp));
	memset(dq,0,sizeof(dq));
	if(m==0){
		printf("0\n");
		return;
	}
	dp[0]=1;
	for(int i=1;i<=n;i++){
		for(int j=0;j<=n;j++)
			f[j]=g[j]=0;
		for(int j=0;j<=n;j++){
			if(j>0){
				f[j]=(a[i]*dp[j]-dp[j-1]+md)%md;
				g[j]=(a[i]*dq[j]-dq[j-1]+md)%md;
			}
			f[j]=(f[j]+dp[j]*a[i])%md;
			g[j]=(g[j]+dp[j]+dq[j]*a[i])%md;
		}
		for(int j=0;j<=n;j++)
			dp[j]=f[j],dq[j]=g[j];
	}
	long long res=0;
	for(int i=1;i<=m;i++)
		res=(res+dq[i-1]*powd(n,m-i))%md;
	printf("%lld\n",res*powd(powd(n,m),md-2)%md);
}
int main(){
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	mian::solve();
	return 0;
}
