#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
long long A[maxn],B[maxn];
long long fac[maxn];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int main(){
	int n=10;
	fac[0]=1;
	for(int i=1;i<=n;i++)
		fac[i]=fac[i-1]*i%md;
	B[0]=1;
	return 0;
}
