#include<iostream>
#include<cstdio>
#include<cstring>

namespace O_O
{
	typedef long long ll;
	const int N=10,MOD=998244353;

	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}
	ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

	int A[N];
	int n,k,ans;

	void dfs(int p=1,int sum=0)
	{
		if(p>k)
		{
			ans=(ans+sum)%MOD;
			return ;
		}

		for(int i=1;i<=n;i++)
		{
			int pi=1;
			for(int j=1;j<=n;j++)
				if(i!=j)pi=(ll)pi*A[j]%MOD;
			A[i]--;
			dfs(p+1,(sum+pi)%MOD);
			A[i]++;
		}
	}

	void solve()
	{
		scanf("%d%d",&n,&k);
		for(int i=1;i<=n;i++)
			scanf("%d",A+i);

		ans=0,dfs();
		ans=(ans*inv(qpow(n,k))%MOD+MOD)%MOD;

		printf("%d\n",ans);
	}

}

int main()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
	O_O::solve();
	return 0;
}
