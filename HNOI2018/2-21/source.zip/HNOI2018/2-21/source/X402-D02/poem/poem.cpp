#include<iostream>
#include<cstdio>
#include<cstring>

namespace qwq
{
	typedef long long ll;
	const int N=301000,M=N*3;

	struct SAM
	{
		int st[M][26],fail[M],maxlen[M];
		int cnt[N];
		int e;

		void init()
		{
			for(int i=1;i<=e;i++)
				memset(st[i],0,26*4),fail[i]=maxlen[i]=cnt[i]=0;
			e=1;
		}

		inline int copy(int p)
		{
			e++;
			memcpy(st[e],st[p],26*4);
			fail[e]=fail[p],maxlen[e]=maxlen[p];
			return e;
		}

		int extend(int c,int last,int w)
		{
			int p=last,np=++e,q,nq;
			maxlen[np]=maxlen[p]+1,cnt[last=np]+=w;

			for(;p && !st[p][c];p=fail[p])st[p][c]=np;
			if(!p){fail[np]=1;return last;}
			
			q=st[p][c];
			if(maxlen[q]==maxlen[p]+1){fail[np]=q;return last;}

			nq=copy(q),maxlen[nq]=maxlen[p]+1;
			fail[q]=fail[np]=e;

			for(;p && st[p][c]==q;p=fail[p])st[p][c]=nq;

			return last;
		}

		int siz[N];

		ll calc()
		{
			static int c[M],seq[M];
			for(int i=1;i<=e;i++)c[i]=0,siz[i]=cnt[i];
			for(int i=1;i<=e;i++)c[maxlen[i]]++;
			for(int i=1;i<=e;i++)c[i]+=c[i-1];
			for(int i=1;i<=e;i++)seq[c[maxlen[i]]--]=i;

			for(int i=e;i;i--)siz[fail[seq[i]]]+=siz[seq[i]];
			
			ll ret=0;
			for(int i=1;i<=e;i++)
				ret+=(ll)(maxlen[i]-maxlen[fail[i]])*siz[i]*siz[i];

			return ret;
		}

	}S;

	struct Trie
	{
		int st[N][26],fa[N],pos[N];
		int cnt[N];
		int e;

		inline int check(int &p){return p?p:p=++e;}
		void insert(char *s,int len)
		{
			for(int i=1,p=1,q;i<=len;i++)
			{
				q=check(st[p][s[i]-'a']);
				fa[q]=p;
				cnt[p=q]++;
			}
		}

		void build()
		{
			static int Q[N];
			S.init();

			int u=0,d=0,p,q;
			pos[Q[++u]=1]=1;
			while(u>d)
			{
				p=Q[++d];
				for(int i=0;i<26;i++)
					if((q=st[p][i]))
					{
						pos[q]=S.extend(i,pos[p],cnt[q]);
						Q[++u]=q;
					}
			}
		}
	}T;

	char s[N];
	int n,len;

	void solve()
	{
		scanf("%d",&n),S.e=T.e=1;

		while(n--)
		{
			scanf("%s",s+1);
			len=strlen(s+1);
			T.insert(s,len);
			T.build();

			printf("%lld\n",S.calc());
		}
	}
}

int main()
{
	freopen("poem.in","r",stdin);
	freopen("poem.out","w",stdout);
	qwq::solve();
	return 0;
}
