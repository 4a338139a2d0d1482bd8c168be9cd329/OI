#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<ctime>
#include<bitset>

inline bool check_min(int a,int &b){return a<b?b=a,1:0;}

namespace meishenmefen
{
	const int N=182,M=N*N,K=55,INF=1000023333;

	int n,m,k;

	struct matrix
	{
		bool s[N][N];
		matrix(int ty=0)
		{
			memset(s,0,sizeof(s));
			if(ty==1)for(int i=1;i<=n;i++)s[i][i]=1;
		}
	};
	struct vector
	{
		bool s[N];
		vector(){memset(s,0,sizeof(s));}
	};
	
	matrix operator * (matrix &A,matrix &B)
	{
		static matrix C;
		static std::bitset<N> X[N],Y[N];

		memset(C.s,0,sizeof(C.s));

		for(int i=1;i<=n;i++)X[i].reset(),Y[i].reset();
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				X[i][j]=A.s[i][j],Y[i][j]=B.s[j][i];

		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				C.s[i][j]=(X[i]&Y[j]).count()>0;

//		for(int i=1;i<=n;i++)
//			for(int j=1;j<=n;j++)
//				for(int k=1;k<=n && !C.s[i][j];k++)
//					C.s[i][j]|=A.s[i][k]&B.s[k][j];

		return C;
	}

	vector operator * (matrix &A,vector &B)
	{
		static vector C;
		C=vector();
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n && !C.s[i];j++)
				C.s[i]|=A.s[j][i]&B.s[j];
		return C;
	}

	matrix qpow(matrix A,int b)
	{
		static matrix C;
		C=matrix(1);
		for(;b;b>>=1,A=A*A)if(b&1)C=C*A;
		return C;
	}

	int w[K];

	matrix G[K];

	void initialize()
	{
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1,u,v,h;i<=m;i++)
		{
			scanf("%d%d%d",&u,&v,&h);
			G[h].s[u][v]=1;
		}

		for(int i=1;i<=k;i++)
			scanf("%d",w+i);

		for(int p=2;p<=k;p++)
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					G[p].s[i][j]|=G[p-1].s[i][j];
	}

	int f[K][N];

	void calc(int id)
	{
		static std::queue<int> Q;
		while(!Q.empty())Q.pop();

		for(int i=1;i<=n;i++)f[id][i]=INF;

		Q.push(n);f[id][n]=0;
		while(!Q.empty())
		{
			int p=Q.front();Q.pop();
			for(int q=1;q<=n;q++)
				if(G[id].s[q][p] && check_min(f[id][p]+1,f[id][q]))
					Q.push(q);
		}
	}

	vector A;
	matrix B;

	void solve()
	{
		initialize();

		for(int i=0;i<=k;i++)calc(i);

		A=vector();
		A.s[1]=1;

		int ans=INF;

		for(int i=0;i<=k;i++)
		{
			for(int p=1;p<=n;p++)
				if(A.s[p])check_min(w[i]+f[i][p],ans);

			if(i==k)break;

			B=qpow(G[i],w[i+1]-w[i]);

			A=B*A;
		}

		if(ans==INF)printf("Impossible\n");
		else printf("%d\n",ans);
	}
}

int main()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
	
	meishenmefen::solve();

//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);

	return 0;
}
