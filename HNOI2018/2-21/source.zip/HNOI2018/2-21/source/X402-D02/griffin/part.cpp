#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>

inline bool check_min(int a,int &b){return a<b?b=a,1:0;}

namespace meishenmefen
{
	const int N=200,M=N*N,INF=2147483647;

	int begin[N],next[M],to[M];

	int n,m,e;

	void add(int x,int y)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}

	int dis[N];

	bool check()
	{
		static std::queue<int> Q;
		while(!Q.empty())Q.pop();
		for(int i=1;i<=n;i++)dis[i]=INF;
		dis[1]=0,Q.push(1);
		while(!Q.empty())
		{
			int p=Q.front(),q;
			for(int i=begin[p];i;i=next[i])
				if(check_min(dis[p]+1,dis[q=to[i]]))
					Q.push(q);
		}
		return dis[n]<INF;
	}

	void solve()
	{
		int tmp;
		scanf("%d%d%d",&n,&m,&tmp);
		for(int i=1,u,v;i<=m;i++)
		{
			scanf("%d%d%d",&u,&v,&tmp);
			add(u,v);
		}
		scanf("%d",&tmp);

		if(tmp>0 || !check())printf("Impossible\n");
		else printf("%d\n",dis[n]);
	}
}

int main()
{
	meishenmefen::solve();
	return 0;
}
