#include<iostream>
#include<cstdio>
#include<cstring>
#include<bitset>

std::bitset<200> A;

int main()
{
	A.reset();
	printf("%d\n",(int)A.count());
	A[12]=1;
	printf("%d\n",(int)A.count());
	A[2]=1;
	A[53]=1;
	printf("%d\n",(int)A.count());
	A[99]=1;
	printf("%d\n",(int)A.count());
	return 0;
}
