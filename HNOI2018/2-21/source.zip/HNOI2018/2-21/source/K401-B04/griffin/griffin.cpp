//2017-02-21
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register int i=a;i<=b;i++)
#define Forr(i,a,b) for(register int i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen("griffin.in","r",stdin);
	freopen("griffin.out","w",stdout);
}
inline void read(int &x)
{
	int p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}
#define N 100010
int n,m,c,cnt,ans=0x7f7f7f7f;
int beg[N],w[N],vis[N],dis[N],zh[N];
struct node
{
	int nex,to,w;
}e[N];
inline void add(int u,int v,int w)
{
	e[++cnt].to=v;
	e[cnt].nex=beg[u];
	e[cnt].w=w;
	beg[u]=cnt;
}
inline void spfa()
{
	queue<int> q;
	For(i,1,n)dis[i]=0x7f7f7f7f,vis[i]=0;
	q.push(1);
	vis[1]=1;
	dis[1]=0;
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		vis[x]=0;
		for(register int i=beg[x];i;i=e[i].nex)
		{
			int y=e[i].to;
			if(dis[y]>dis[x]+1)
			{
				dis[y]=dis[x]+1;
				if(!vis[y])
				{
					q.push(y);
					vis[y]=1;
				}
			}
		}
	}
}
void dfs(int x,int now,int pd)
{
	if(now>=ans)return;
	if(x==n){ans=now;return;}
	int flag=pd;
	if(zh[x])flag=1;
	for(register int i=beg[x];i;i=e[i].nex)
	{
		int y=e[i].to,OwO=w[e[i].w];

		if(OwO<=now)dfs(y,now+1,flag);
		else if(pd||flag)dfs(y,OwO,flag);

	}
}
inline void spfa1()
{
	queue<int> q;
	For(i,1,n)dis[i]=0x7f7f7f7f,vis[i]=0;
	q.push(1);
	vis[1]=1;
	dis[1]=0;
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		vis[x]=0;
		for(register int i=beg[x];i;i=e[i].nex)
		{
			int y=e[i].to,OwO=w[e[i].w],op=dis[x]==0x7f7f7f7f?0:dis[x];
			if(OwO<=dis[x])
			{
				if(dis[y]>dis[x]+1)
				{
					dis[y]=dis[x]+1;
					if(!vis[y])
					{
						q.push(y);
						vis[y]=1;
					}
				}
			}
		}
	}
}
inline void solve()
{
	dfs(1,0,zh[1]==1);

	if(ans==0x7f7f7f7f)puts("Impossible");
	else printf("%d\n",ans);
}
int main()
{
	File();
	read(n),read(m),read(c);
	if(c==1)
	{
		For(i,1,m)
		{
			int x,y,l;
			read(x),read(y),read(l);
			if(x==y)continue;
			add(x,y,l);
		}
		For(i,1,c)read(w[i]);
		if(w[1]>0){puts("Impossible");return 0;}
		spfa();
		if(dis[n]!=0x7f7f7f7f)cout<<dis[n]<<endl;
		else puts("Impossible");
		return 0;	
	}
	else
	{
		For(i,1,m)
		{
			int x,y,l;
			read(x),read(y),read(l);
		    if(x==y){zh[x]=1;continue;}
			add(x,y,l);
		}
		int qwq=0;
		For(i,1,c){read(w[i]);if(!w[i])qwq=1;}
		if(!qwq){puts("Impossible");return 0;}
		solve();
		return 0;
	}
	return 0;
}
