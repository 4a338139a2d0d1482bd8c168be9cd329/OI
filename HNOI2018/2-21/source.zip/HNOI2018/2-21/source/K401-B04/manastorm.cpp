//2017-02-21
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register ll i=a;i<=b;i++)
#define Forr(i,a,b) for(register ll i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen("manastorm.in","r",stdin);
	freopen("manastorm.out","w",stdout);
}
inline void read(ll &x)
{
	ll p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}
const int p=998244353;
ll n,k,cnt;
ll a[1000010];
ll ans;
void dfs(ll x,ll now)
{
	if(x==k+1)
	{
		ans+=now;
		ans%=p;
		cnt+=1;
		return;
	}
	For(i,1,n)
	{
		a[i]-=1;
		ll qwq=1;
		For(j,1,n)qwq=j==i?qwq:qwq*(a[j]%p),qwq%=p;
		dfs(x+1,now+qwq);
		a[i]+=1;
	}
}
inline ll ksm(ll x,ll mc)
{
    ll tmp=x%p;
    ll res=1;
    while(mc)
    {
        if(mc&1)res=(res*tmp)%p;
        tmp=tmp*tmp%p;
        mc>>=1;
    }
    return res;
}
int main()
{
	File();
	read(n),read(k);
	For(i,1,n)read(a[i]);
	dfs(1,0);
	printf("%lld\n",(((ans%p+p)%p)*ksm(cnt,p-2))%p);
	return 0;
}
