#include <bits/stdc++.h>

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

typedef long long ll;

const int mod = 998244353;

int fpm(int x, int e)
{
	int ret = 1;
	for (; e; e >>= 1) {
		if (e & 1) ret = (ll)ret * x % mod;
		x = (ll)x * x % mod;
	}
	return ret;
}

const int MAXN = 1e6 + 5;

int N, P[MAXN];
bool vis[MAXN];

namespace SubTask1
{
	int ans;

	void DFS(int d)
	{
		if (d > N) {
			for (int i = 1; i <= N; ++i) {
				if (i == P[i]) return ;
			}
			ans ++;
			return ;
		}
		if (P[d]) {
			DFS(d + 1);
			return ;
		}
		for (int i = 1; i <= N; ++i) {
			if (vis[i]) continue;
			P[d] = i; vis[i] = 1;
			DFS(d + 1);
			P[d] = 0; vis[i] = 0;
		}
	}

	void main()
	{
		DFS(1);
		printf("%d\n", ans);
	}
}

namespace SubTask2
{
	int fac[MAXN], ifac[MAXN];
	int M;
	
	void FacInit(int N)
	{
		for (int i = 0; i <= N; ++i) {
			fac[i] = i? (ll)fac[i-1] * i % mod : 1;
		}
		ifac[N] = fpm(fac[N], mod - 2);
		for (int i = N; i >= 1; --i) {
			ifac[i-1] = (ll)ifac[i] * i % mod;
		}
	}

	int C(int N, int M)
	{
		if (N < M) return 0;
		return (ll)fac[N] * ifac[M] % mod * ifac[N - M] % mod;
	}

	void main()
	{
		FacInit(MAXN - 5);

		int R = 0;
		for (int i = 1; i <= N; ++i) {
			if (!P[i]) {
				R ++;
				M += !vis[i];
			}
		}

		int ans = 0;
		for (int i = 0; i <= M; ++i) {
			if (i & 1) ans = (ans - (ll)C(M, i) * fac[R - i] % mod) % mod;
			else ans = (ans + (ll)C(M, i) * fac[R - i] % mod) % mod;
		}

		printf("%d\n", ans);
	}
}

int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	N = read();
	for (int i = 1; i <= N; ++i) {
		P[i] = read();
		vis[P[i]] = 1;
	}

//	if (N <= 10) SubTask1 :: main();
	SubTask2 :: main();

	return 0;
}
