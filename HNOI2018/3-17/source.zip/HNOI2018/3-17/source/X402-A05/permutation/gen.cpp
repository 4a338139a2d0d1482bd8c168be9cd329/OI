#include <bits/stdc++.h>

int P[20];
bool vis1[100];
bool vis2[100];

int main()
{
	freopen("permutation.in", "w", stdout);
	srand(time(NULL));

	int N = 13;
	printf("%d\n", N);

	vis1[0] = 1; vis2[0] = 1;

	int O = 2 + rand() % 5;
	for (int ban = 1; ban <= O; ++ban) {
		int y = 0;
		while (vis1[y]) y = rand() % N + 1;

		int vy = 0;
		while (vis2[vy] || vy == y) vy = rand() % N + 1;
		P[y] = vy;

		vis1[y] = 1; vis2[vy] = 1;
	}

	for (int i = 1; i <= N; ++i)
		printf("%d%c", P[i], i != N? ' ':'\n');

	return 0;
}
