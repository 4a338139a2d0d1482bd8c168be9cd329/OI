
#include <bits/stdc++.h>

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

typedef long long ll;

const int mod = 998244353;

int fpm(int x, int e)
{
	int ret = 1;
	for (; e; e >>= 1) {
		if (e & 1) ret = (ll)ret * x % mod;
		x = (ll)x * x % mod;
	}
	return ret;
}

const int MAXN = 1e6 + 5;

int N, P[MAXN];
bool vis[MAXN];

namespace SubTask1
{
	int ans;

	void DFS(int d)
	{
		if (d > N) {
			for (int i = 1; i <= N; ++i) {
				if (i == P[i]) return ;
			}
			ans ++;
			return ;
		}
		if (P[d]) {
			DFS(d + 1);
			return ;
		}
		for (int i = 1; i <= N; ++i) {
			if (vis[i]) continue;
			P[d] = i; vis[i] = 1;
			DFS(d + 1);
			P[d] = 0; vis[i] = 0;
		}
	}

	void main()
	{
		DFS(1);
		printf("%d\n", ans);
	}
}

int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.ans", "w", stdout);

	N = read();
	for (int i = 1; i <= N; ++i) {
		P[i] = read();
		vis[P[i]] = 1;
	}

	SubTask1 :: main();
//	fprintf(stderr, "it's bf\n");

	return 0;
}
