#include <bits/stdc++.h>

#define SZ(x) ((int)(x).size())

typedef long long ll;

int read(int x = 0, int _f = 0) 
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}
template <typename T> bool chkmax(T &a, T b) { return a < b? a = b, true : false; }
template <typename T> bool chkmin(T &a, T b) { return a > b? a = b, true : false; }

const int mod = 998244353;
const int inf = 0x3f3f3f3f;

const int MAXN = 1e5 + 5;

int N, M, K;

int e, Begin[MAXN];
struct Edge
{
	int to, next, w;
	Edge(int to = 0, int next = 0, int w = 0) : to(to), next(next), w(w) {}
}E[MAXN << 1];

void AddEdge(int u, int v, int w)
{
	E[++e] = Edge(v, Begin[u], w); Begin[u] = e;
}

namespace SubTask1
{
	ll DFS_check(int u, int status, ll dist = 0, int fa = -1) 
	{
		ll ret = (status >> (u-1)) & 1? dist : 0;
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa) continue;
			chkmax(ret, DFS_check(v, status, dist + E[i].w, u));
		}
		return ret;
	}

	void main()
	{
		int ans = 0;
		for (int s = 1; s < 1 << N; ++s) {
			if (__builtin_popcount(s) != M) continue;
			for(int i = 1; i <= N; ++i) {
				ll tmp = DFS_check(i, s);
				if (tmp <= K) {
					ans ++; break;
				}
			}
		}
		for (int i = 1; i <= M; ++i) ans = (ll)ans * i % mod;
		printf("%d\n", ans);
	}
}

namespace SubTask2
{
	using std :: vector;
	using std :: sort;

	int ans;

	int g[MAXN] = {inf};
	int rt;

	int size[MAXN];
	int done[MAXN];

	vector<ll> info, ch[MAXN];

	void DFS_size(int u, int fa = 0)
	{
		size[u] = 1;
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa || done[v]) continue;
			DFS_size(v, u);
			size[u] += size[v];
		}
	}

	void DFS_root(int u, int tot, int fa = 0) 
	{
		g[u] = tot - size[u];
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa || done[v]) continue;
			DFS_root(v, tot, u);
			chkmax(g[u], size[v]);
		}
		if (g[u] < g[rt]) rt = u;
	}

	void DFS_info(int u, int id, ll dist, int fa = 0)
	{
		ch[id].push_back(dist);
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa || done[v]) continue;
			DFS_info(v, id, dist + E[i].w, u);
		}
	}

	int calc(vector<ll> cur)
	{
		int r = SZ(cur) - 1, ret = 0;
		for (int i = 0; i < SZ(cur); ++i) {
			chkmax(r, i);
			while (r > i && cur[i] + cur[r] > 2*K) --r;
			ret = (ret + r - i) % mod;
		}
		return ret;
	}

	void DFS_divide(int u)
	{
		DFS_size(u);
		rt = 0;
		DFS_root(u, size[u]);
		done[rt] = true;
//		fprintf(stderr, "%d\n", rt);

		info.push_back(0);
		int cnt = 0;
		for (int i = Begin[rt]; i; i = E[i].next) {
			int v = E[i].to;
			if (done[v]) continue;
			cnt ++;
			DFS_info(v, cnt, E[i].w, rt);
//			if (rt == 4) fprintf(stderr, "%d %d\n", v, SZ(ch[cnt]));
			for (int j = 0; j < SZ(ch[cnt]); ++j)
				info.push_back(ch[cnt][j]);
		}

		sort(info.begin(), info.end());
		for (int i = 1; i <= cnt; ++i) sort(ch[i].begin(), ch[i].end());

		ans = (ans + calc(info)) % mod;
		info.clear();
		for (int c = 1; c <= cnt; ++c) {
			ans = (ans - calc(ch[c]) + mod) % mod;
			ch[c].clear();
		}
		
		for (int i = Begin[rt]; i; i = E[i].next) {
			int v = E[i].to;
			if (done[v]) continue;
			DFS_divide(v);
		}
	}

	void main()
	{
		DFS_divide(1);
		for (int i = 1; i <= M; ++i) ans = (ll) ans * i % mod;
		printf("%d\n", ans);
	}
}

namespace SubTask3
{
	using std :: vector;

	int ans = 0;
	vector<int> ch[MAXN];
	vector<int> rt[MAXN];

	void DFS_push(int u, ll dist = 0, int fa = 0)
	{
		ch[u].push_back(dist);
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa) continue;
			DFS_push(v, dist + E[i].w, u);
			for (int j = 0; j < SZ(ch[v]); ++j)
				ch[u].push_back(ch[v][j]);
		}
		for (int i = 0; i < SZ(ch[u]); ++i) 
			ch[u][i] -= dist;
	}

	void DFS_root(int u, int st, ll dist = 0, int fa = 0)
	{
		rt[st].push_back(dist);
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa) continue;
			DFS_root(v, st, dist + E[i].w, u);
		}
	}

	int C[5000 + 5][5000 + 5];
	void CInit(int N)
	{
		for (int i = 0; i <= N; ++i) C[i][0] = 1;
		for (int i = 1; i <= N; ++i) {
			for (int j = 1; j <= i; ++j)
				C[i][j] = (C[i-1][j] + C[i-1][j-1]) % mod;
		}
	}

	void DFS_trans(int u, int fa = 0)
	{
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa) continue;

			int nj = std::upper_bound(ch[v].begin(), ch[v].end(), K) - ch[v].begin() - 1;
			nj ++;
			int oj = K >= E[i].w? std::upper_bound(ch[v].begin(), ch[v].end(), K - E[i].w) - ch[v].begin() - 1: -1;
			oj ++;
			int nk = std::upper_bound(rt[v].begin(), rt[v].end(), K) - rt[v].begin() - 1;
			nk -= nj;
//			if (v == 2) fprintf(stderr, "%d %d\n", nj, oj);
			for (int j = 1; j <= nj - oj; ++j)
				ans = (ans + (ll)C[nj - oj][j] * C[nk+nj-(nj-oj)][M - j] % mod) % mod;
			DFS_trans(v, u);
		}
	}

	void main()
	{
		CInit(5000);
		DFS_push(1);
		for (int i = 1; i <= N; ++i) DFS_root(i, i);
		for (int i = 1; i <= N; ++i) {
			sort(ch[i].begin(), ch[i].end());
			sort(rt[i].begin(), rt[i].end());
		}
		int k = std::upper_bound(rt[1].begin(), rt[1].end(), K) - rt[1].begin() - 1;
		ans = C[k + 1][M];
		DFS_trans(1);
		printf("%d\n", ans);
	}
}

int main()
{
	freopen("party.in", "r", stdin);
	freopen("party.out", "w", stdout);

	N = read(), M = read(), K = read();
	for (int i = 1; i < N; ++i) {
		int u = read(), v = read(), w = read();
		AddEdge(u, v, w);
		AddEdge(v, u, w);
	}

	if (N <= 20)
		SubTask1 :: main();
	else 
		SubTask2 :: main();
//	fprintf(stderr, "%lf\n", 1.0 * clock()/CLOCKS_PER_SEC);

	return 0;
}
