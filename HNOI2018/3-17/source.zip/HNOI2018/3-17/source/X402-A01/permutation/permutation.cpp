#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int ans=0,v[1000010],a[1000010],n,q[1000010];
void dfs(int x){
	if(x==n+1){
		ans++;
		return;
	}
	if(a[x]){q[x]=a[x];dfs(x+1);}
	else{
		for(int i=1;i<=n;i++)
		    if(!v[i] && i!=x){
		    	q[x]=i;
		    	v[i]=1;
		    	dfs(x+1);
		    	v[i]=0;
		    }
	}
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int i,j,k,m;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	    scanf("%d",&a[i]);
	for(i=1;i<=n;i++){
	    if(a[i]==i){printf("0\n");return 0;}
	    v[a[i]]=1;
	}
    dfs(1);    		 
    printf("%d\n",ans);
	return 0;
}
/*
5
0 0 4 3 0
*/
