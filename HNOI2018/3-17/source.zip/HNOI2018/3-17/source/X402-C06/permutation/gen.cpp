#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("permutation.in","w",stdout);
}

const int N=1e6+10;
int n,a[N];

int main(){
	file();
	srand(time(NULL));
	n=1000000;
	cout<<n<<endl;	
	For(i,1,n){
		int tmp;
		
		tmp=0;

		printf("%d ",tmp);
	}
	puts("");
	return 0;
}

