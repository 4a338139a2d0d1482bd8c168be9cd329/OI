#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif
}

typedef long long ll;
const int N=1e6+10;
const ll mod=998244353;
int n,num,a[N],vis[N],pos[N],X[N];
ll ans,fac[N],tot,sum;

ll ksm(ll a,ll b){
	ll res=1;
	while(b){
		if(b&1) (res*=a)%=mod;
		(a*=a)%=mod;
		b>>=1;
	}
	return res;
}
inline void Init(int n){
	fac[0]=fac[1]=1;
	For(i,2,n) fac[i]=1ll*fac[i-1]*i%mod;
}
ll C(ll n,ll m) {return fac[n]*ksm(fac[m],mod-2)%mod*ksm(fac[n-m],mod-2)%mod;}
ll P(ll n,ll m) {return fac[n]*ksm(fac[n-m],mod-2)%mod;}

void dfs(int x){
	if(x==n+1){
		ans++;
		return;
	}
	if(pos[x]==1) dfs(x+1);
	For(i,1,n){
		if(vis[i]) continue;
		if(i!=x){
			vis[i]=1;
			a[x]=i;
			dfs(x+1);
			a[x]=0;
			vis[i]=0;
		}
	}
}

int main(){
	file();
	read(n);
	For(i,1,n){
		read(a[i]);
		if(a[i]){
			vis[a[i]]=1,pos[i]=1;
			X[++num]=i;
		}				
		if(!a[i]) sum++;
		if(a[i]==i){
			printf("0\n");
			return 0;
		}
	}
	if(n<=10){
		dfs(1);
		printf("%lld\n",ans);
		return 0;
	}
	Init(N-5);
	For(i,1,num) if(!vis[X[i]]) tot++;
	ll now=sum-tot,x=0;	
	while(x<=now){
		ll tmp=C(now,x)*P(sum-x,now-x)%mod;
		if(x&1) (ans=ans-tmp+mod)%mod;
		else (ans+=tmp)%=mod;
		++x;
	}
	printf("%lld",ans*fac[tot]%mod);
	return 0;
}

