#include<bits/stdc++.h>
#define Travel(i,x) for(register int i=beg[x];i;i=nex[i])
#define mem(a,b) memset(a,0,sizeof(a))
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
#ifndef ONLINE_JUDGE
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
#endif
}

typedef long long ll;
const int N=1e5+10;
const ll mod=998244353;
int e,beg[N],nex[N<<1],to[N<<1];
int n,m,a[N],vis[N],x,y;
ll dis[N],w[N],k,z,ans,Fac;

inline void add(int x,int y,ll z){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}

ll Dis(int x,int y){
	if(x==y) return 0;
	For(i,1,25) dis[i]=0,vis[i]=0;
	int st=x;
	vis[st]=1,dis[st]=0;
	queue<int> Q;
	Q.push(st);
	while(!Q.empty()){
		int s=Q.front(),flag=0;
		Q.pop();
		Travel(i,s){
			int t=to[i];
			dis[t]=dis[s]+w[i];
			if(t==y){
				flag=1;
				break;
			}
			if(!vis[t]){
				vis[t]=1;
				Q.push(t);
			}
		}
		if(flag) break;
	}
	return dis[y];
}

bool check(int x){
	For(i,1,n){
		if(a[i]!=0 && Dis(i,x)>k) return false;
	}
	return true;
}

void dfs(int x,int lst){
	if(x==m+1){
		For(x,1,n) if(check(x)){
			ans++; break;
		}
		return ;
	}
	For(i,lst,n){
		a[i]=1;
		dfs(x+1,i+1);
		a[i]=0;
	}	
}

int main(){
	file();
	read(n),read(m),read(k);
	For(i,1,n-1){
		int x,y;ll z;
		read(x),read(y),read(z);
		add(x,y,z);
		add(y,x,z);
	}
	dfs(1,1);	
	Fac=1;
	For(i,1,m) Fac=Fac*1ll*i%mod;
	printf("%lld\n",ans*Fac%mod);
	return 0;
}

