#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
#ifndef ONLINE_JUDGE
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
#endif
}

const int N=5e3+10;
typedef long long ll;
int T,Case,MAX; 
ll a[N],xx,yy,n,m;

ll gcd(ll x,ll y){
	if(x%y==0) return y;
	return gcd(y,x%y);
}

inline void Work(){
	read(Case);
	while(Case--){
		read(n),read(m);
		For(i,1,n) read(a[i]);
		ll GCD=gcd(a[1],a[2]);
		For(i,3,n) GCD=gcd(GCD,a[i]);
		For(i,1,n) a[i]/=GCD;
		int flag=1;
		For(i,1,n) if(a[i]>m) flag=0;
		if(flag){
			printf("%lld %lld\n",GCD,GCD);
			continue;
		}	
		while(1){
			int x=rand()%n+1,y=rand()%n+1;
			if(x!=y){
				ll X=gcd(a[x],a[y]),Y=0;
				if(X*GCD>m) continue;
				For(i,1,n)
					if(a[i]%X!=0 || a[i]/X>m){
						if(Y==0) Y=a[i]; else Y=gcd(Y,a[i]);
					}
				if(Y*GCD>m) continue;
				flag=1;
				For(i,1,n){
					if(a[i]%X!=0 && a[i]%Y!=0){
						flag=0;
						break;
					}
					xx=yy=2000000000;
					if(a[i]%X==0) xx=a[i]/X;
					if(a[i]%Y==0) yy=a[i]/Y;
					if(xx>m || yy>m){
						flag=0;
						break;
					}
				}
				if(flag){
					if(X>Y) swap(X,Y);
					printf("%lld %lld\n",X*GCD,Y*GCD);
					break;
				}
			}
		}
	}	
}


int main(){
	file();
	srand(20020220);
	read(T);
	Work();	
	return 0;
}

