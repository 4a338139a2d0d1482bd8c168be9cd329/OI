#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 5010;

inline ll read() {
	ll x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n;
ll m, a[MAXN];

int main() {
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);

	int T = read(), t = read(), i, o;
	if(T == 1) {
		while(t--) {
			n = read(), m = read();
			for(i = 1; i <= n; i++) a[i] = read();
			ll ans = a[1];
			for(i = 2; i <= n; i++) ans = __gcd(ans, a[i]);
			printf("%lld %lld\n", ans, ans);
		}
	}
	if(T == 2 || T == 3) {
		while(t--) {
			n = read(), m = read();
			for(i = 1; i <= n; i++) a[i] = read();
			ll g = 0;
			for(i = 1; i <= n; i++) g = __gcd(g, a[i]);
			for(i = 1; i <= n; i++)
				if(a[i] / g > m) break;
			if(i == n+1) {
				printf("%lld %lld\n", g, g);
				continue;
			}
			for(o = 2; o <= 100; o++) {
				bool f1 = false, f2 = false;
				for(i = 1; i <= n; i++) {
					if(a[i]%o == 0) f1 = true;
					else f2 = true;
				}
				if(f1 && f2) {
					ll g1 = 0, g2 = 0;
					for(i = 1; i <= n; i++) 
						if(a[i] % o) g2 = __gcd(g2, a[i]);
					for(i = 1; i <= n; i++) 
						if(a[i] % o == 0 && a[i] % g2 != 0) g1 = __gcd(g1, a[i]);
					if(g1 == 0) continue;;
					for(i = 1; i <= n; i++) {
						if(a[i]%g1 == 0) {
							if(a[i]/g1 > m) break;
						}
						else {
							if(a[i]/g2 > m) break;
						}
					}
					if(i > n) {
						printf("%lld %lld\n", min(g1, g2), max(g1, g2));
						break;
					}
				}
			}
			if(o == 101) printf("0 0\n");
		}
	}
	return 0;
}
