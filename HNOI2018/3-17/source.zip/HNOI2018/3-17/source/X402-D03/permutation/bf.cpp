#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 1000010;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, ans;
int a[MAXN];
bool done[MAXN];

void dfs(int u) {
	int i;
	if(u == n+1) {
		ans++;
		return;
	}
	if(a[u]) {
		dfs(u+1);
		return;
	}
	for(i = 1; i <= n; i++) {
		if(i == u || done[i]) continue;
		a[u] = i;
		done[i] = true;
		dfs(u+1);
		done[i] = false;
		a[u] = 0;
	}
}

int main() {
	freopen("permutation.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i;
	n = read();
	for(i = 1; i <= n; i++) done[a[i] = read()] = true;
	dfs(1);
	printf("%d\n", ans);
	return 0;
}
