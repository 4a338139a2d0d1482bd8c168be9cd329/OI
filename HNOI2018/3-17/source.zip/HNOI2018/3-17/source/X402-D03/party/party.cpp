#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmin(ll &cur, ll val) {
	if(val < cur) cur = val;
}
inline void chkmax(int &cur, int val) {
	if(val > cur) cur = val;
}

int n, m, K;
ll ans;

namespace Plan3 {
	const int MAXN = 100010;
	int st[MAXN], to[MAXN<<1];
	int nxt[MAXN<<1], e = 1;
	inline void Add(int u, int v) {
		to[++e] = v, nxt[e] = st[u];
		st[u] = e;
	}

	bool ban[MAXN<<1];
	int dpn, dp[MAXN], root, size[MAXN];
	inline int DP(int u, int fa) {
		int i, sz = 1;
		dp[u] = 0;
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(ban[i] || v == fa) continue;
			int ss = DP(v, u);
			sz += ss, chkmax(dp[u], ss);
		}
		chkmax(dp[u], dpn-sz);
		if(!root || dp[u] < dp[root]) root = u;
		return sz;
	}
	inline int getroot(int u, int cnt) {
		dpn = cnt, root = 0, DP(u, 0);
		return root;
	}
	vector<int> T, t;
	inline void dfs(int u, int fa, int dist) {
		int i;
		t.push_back(dist);
		size[u] = 1;
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(ban[i] || v == fa) continue;
			dfs(v, u, dist+1), size[u] += size[v];
		}
	}
	inline void calc(int rt) {
		int i, p, q;
		T.clear();
		for(i = st[rt]; i; i = nxt[i]) {
			if(ban[i]) continue;
			int v = to[i];
			t.clear(), dfs(v, rt, 1);
			sort(t.begin(), t.end());
			q = (int)t.size()-1;
			for(p = 0; p < (int)t.size(); p++) {
				while(q > -1 && t[q] > 2*K-t[p]) q--;
				ans = (ans-q-1+MOD)%MOD;
				T.push_back(t[p]);
			}
		}
		T.push_back(0);
		sort(T.begin(), T.end());
		q = (int)T.size()-1;
		for(p = 0; p < (int)T.size(); p++) {
			while(q > -1 && T[q] > 2*K-T[p]) q--;
			ans = (ans+q+1)%MOD;
		}
		ans = (ans-1)%MOD;
		for(i = st[rt]; i; i = nxt[i]) {
			if(ban[i]) continue;
			ban[i] = ban[i^1] = true;
			int v = to[i];
			calc(getroot(v, size[v]));
		}
	}
	inline void solve() {
		int i;
		for(i = 1; i < n; i++) {
			int u = read(), v = read();
			read(), Add(u, v), Add(v, u);
		}
		calc(getroot(1, n));
	}
}

namespace Plan1 {
	const int MAXN = 110;
	const ll INF = 1LL<<60;
	ll g[MAXN][MAXN];
	bool cs[MAXN];

	void dfs(int u) {
		int i, j;
		if(u == n+1) {
			ll res = 0;
			for(i = 1; i <= n; i++) res += cs[i];
			if(res != m) return;
			for(i = 1; i <= n; i++) {
				res = 0;
				for(j = 1; j <= n; j++) 
					if(cs[j]) res = max(res, g[i][j]);
				if(res <= K) break;
			}
			if(i <= n) ans++;
			return;
		}
		cs[u] = true;
		dfs(u+1);
		cs[u] = false;
		dfs(u+1);
	}
	inline void solve() {
		int i, j, k;
		for(i = 1; i <= n; i++) 
			for(j = 1; j <= n; j++) {
				if(i == j) g[i][j] = 0;
				else g[i][j] = INF;
			}
		for(i = 1; i < n; i++) {
			int u = read(), v = read();
			g[u][v] = g[v][u] = read();
		}
		for(k = 1; k <= n; k++) 
			for(i = 1; i <= n; i++) 
				for(j = 1; j <= n; j++) 
					chkmin(g[i][j], g[i][k]+g[k][j]);
		dfs(1);
		for(i = 1; i <= m; i++) ans = ans * i % MOD;
	}
}

int main() {
	freopen("party.in", "r", stdin);
	freopen("party.out", "w", stdout);

	n = read(), m = read(), K = read();
	if(n > 20) Plan3::solve();
	else Plan1::solve();
	printf("%lld\n", ans);
	return 0;
}
