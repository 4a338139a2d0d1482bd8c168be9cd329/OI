#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll INF = 1LL<<60;
const ll MOD = 998244353;
const int MAXN = 110;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmin(ll &cur, ll val) {
	if(val < cur) cur = val;
}

int n, m, K;
ll g[MAXN][MAXN], ans;
bool cs[MAXN];

void dfs(int u) {
	int i, j;
	if(u == n+1) {
		ll res = 0;
		for(i = 1; i <= n; i++) res += cs[i];
		if(res != m) return;
		for(i = 1; i <= n; i++) {
			res = 0;
			for(j = 1; j <= n; j++) 
				if(cs[j]) res = max(res, g[i][j]);
			if(res <= K) break;
		}
		if(i <= n) ans++;
		return;
	}
	cs[u] = true;
	dfs(u+1);
	cs[u] = false;
	dfs(u+1);
}

int main() {
	freopen("party.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j, k;
	n = read(), m = read(), K = read();
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= n; j++) {
			if(i == j) g[i][j] = 0;
			else g[i][j] = INF;
		}
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		g[u][v] = g[v][u] = read();
	}
	for(k = 1; k <= n; k++) 
		for(i = 1; i <= n; i++) 
			for(j = 1; j <= n; j++) 
				chkmin(g[i][j], g[i][k]+g[k][j]);
	dfs(1);
	for(i = 1; i <= m; i++) ans = ans * i % MOD;
	printf("%lld\n", ans);
	return 0;
}
