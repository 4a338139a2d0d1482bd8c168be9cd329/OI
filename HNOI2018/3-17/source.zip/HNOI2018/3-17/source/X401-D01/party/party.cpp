#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define maxn 5005
#define maxm 25
#define mod 998344353
ll fst[maxn<<1],lst[maxn<<1],to[maxn<<1],w[maxn],dis[maxn],e,sum1[maxn],sum2[maxn],n,m,k;
ll dist[maxm][maxm];
bool p[maxn][maxn],f[maxn][maxn],vis[maxn];
ll fac[maxn],inv[maxn],ans[maxn];
inline ll pow(ll x,ll y){
	ll ans=1;
	for(;y;y>>=1){
		if(y&1)ans=ans*x%mod;
		x=x*x%mod;
	}return ans;
}
inline void add(int x,int y,ll z){
	to[++e]=y,w[e]=z,lst[e]=fst[x],fst[x]=e;
}
inline void init(){
	int x,y;ll z;
	for(register int i=1;i<n;++i)scanf("%d%d%lld",&x,&y,&z),add(x,y,z),add(y,x,z);
	fac[0]=1;
	for(register int i=1;i<maxn;++i)fac[i]=fac[i-1]*i%mod;
	for(register int i=0;i<maxn;++i)inv[i]=pow(fac[i],mod-2);
}
inline int check(){
	int cnt=0;
	for(register int i=1;i<=n;++i)if(vis[i])++cnt;
	if(cnt!=m)return 0;
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=n;++j){
			if(vis[j]&&dist[i][j]>k)break;
			if(j==n)return 1;
		}
	}return 0;
}
inline void dfs(int x){
	if(x>n){
		/*for(register int i=1;i<=n;++i)printf("%d ",vis[i]);
		cout<<check()<<endl;*/
		ans[n]+=check()*fac[m]%mod;
		ans[n]%=mod;
		return;
	}vis[x]=1;
	dfs(x+1);
	vis[x]=0;
	dfs(x+1);
}
inline void bf(){
	int x,y;ll z;
	for(register int i=1;i<=n;++i)for(register int j=1;j<=n;++j)dist[i][j]=12345678987;
	for(register int i=1;i<n;++i)scanf("%d%d%lld",&x,&y,&z),dist[x][y]=dist[y][x]=z;
	for(register int i=1;i<=n;++i)dist[i][i]=0;
	for(register int r=1;r<=n;++r){
		for(register int i=1;i<=n;++i){
			for(register int j=1;j<=n;++j){
				if(dist[i][j]>dist[i][r]+dist[r][j])dist[i][j]=dist[i][r]+dist[r][j];
			}
		}
	}fac[0]=1;
	for(register ll i=1;i<=n;++i)fac[i]=fac[i-1]*i%mod;
	dfs(1);
	printf("%lld\n",ans[n]);
}
inline ll A(int N,int M){
	if(M>N)return 0;
	return fac[N]*inv[N-M]%mod;
}
inline void work(int x){
	memset(dis,0,sizeof(dis));
	queue<int>q;
	q.push(x);
	while(!q.empty()){
		int u=q.front();q.pop();
		for(register int i=fst[u];i;i=lst[i]){
			int v=to[i];
			if(v==x||dis[v])continue;
			dis[v]=dis[u]+w[i];
			q.push(v);
		}
	}
	for(register int i=1;i<=n;++i)if(dis[i]<=k)p[x][i]=1;
}
inline void solve(){
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=n;++j){
			sum2[i]+=vis[j]&&p[i][j];
			vis[j]+=p[i][j];
			sum1[i]+=p[i][j];
		}
	}
	ans[1]=A(sum1[1],(ll)m);
	for(register int i=2;i<=n;++i){
		ans[i]=(ans[i-1]+A(sum1[i],(ll)m)-A(sum2[i],(ll)m))%mod;;
	}
	printf("%lld\n",ans[n]);
}
int main(){
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
	cin>>n>>m>>k;
	if(n<=20)bf();
	else{
		init();
		for(register int i=1;i<=n;++i)work(i);
		solve();
	}	return 0;
}

