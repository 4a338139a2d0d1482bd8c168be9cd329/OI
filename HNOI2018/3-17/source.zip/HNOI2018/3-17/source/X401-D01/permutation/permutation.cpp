#include<bits/stdc++.h>
using namespace std;
#define maxn 1000005
#define mod 998244353
#define maxm 1005
int vis[maxn],p[maxn],f[maxn],ans,n;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=x*10+ch-48;
	return x*f;
}
inline void dfs(int x){
	if(x>n){
		++ans;
		return;
	}
	if(p[x])f[x]=p[x],dfs(x+1);
	else for(register int i=1;i<=n;++i){
		if(vis[i]||i==x)continue;
		vis[i]=1;
		f[x]=i;
		dfs(x+1);
		vis[i]=0;
	}
}
inline void bf1(){
	int x;
	for(register int i=1;i<=n;++i)x=read(),vis[x]=1,p[i]=x;
	dfs(1);
	cout<<ans%mod<<endl;
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	cin>>n;
	bf1();
	return 0;
}

