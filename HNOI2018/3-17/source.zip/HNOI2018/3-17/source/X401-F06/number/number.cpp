#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <cstdlib>
using namespace std;
long long read()
{
    char ch;
    for(ch=getchar();ch<'0'||ch>'9';ch=getchar());
    long long x=ch-'0';
    for(ch=getchar();ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
    return x;
}
const int N=5*1e3+5;
long long m,p[N];
long gcd(long long x,long long y)
{
	return y?gcd(y,x%y):x;
}
int main() {
    freopen("number.in","r",stdin);
    freopen("number.out","w",stdout);
    read();
    for(int ty=read();ty;ty--)
	{
        int n=read();
		m=read();
        for(int i=1;i<=n;i++)p[i]=read();
        long long D=p[1];
	    for(int i=2;i<=n;i++)D=gcd(D,p[i]);
        for(int i=1;i<=n;i++)p[i]/=D;
        bool ok=1;
        for(int i=1;i<=n;i++)ok&=p[i]<=m;
        if(ok)
		{
            printf("%lld %lld\n",D,D);
            continue;
        }
        for(;;)
		{
            int x=rand()%n+1,y=rand()%n+1;
            if(x==y)continue;
            long long a=gcd(p[x],p[y]);
            if (a*D>m)continue;
            long long b=0;
            for(int i=1;i<=n;i++) 
                if (p[i]%a||p[i]/a>m){
                    if(!b)b=p[i];
                    else b=gcd(b,p[i]);
                }
            if(!b)b=a;
            if(b*D>m)continue;
            bool ok=1;
            for(int i=1;i<=n;i++)
			{
                if(p[i]%a&&p[i]%b)
				{
					ok=0;
					break;
				}
                long long nn=m+1,mm=m+1;
                if(!(p[i]%a))nn=p[i]/a;
                if(!(p[i]%b))mm=p[i]/b;
                if(nn>m&&mm>m)
				{
					ok=0;
					break;
				}
            }
            if(ok)
			{
                if(a>b)swap(a,b);
                printf("%lld %lld\n",a*D,b*D);
                break;
            }
        }
    }
    return 0;
}
/*
0
1
20 1000 2160 1917 390 9890 1743 1398 9290 5810 1365 1884 3350 1656 2433 1480 2862 1140 6860 1146 978 1659
*/
