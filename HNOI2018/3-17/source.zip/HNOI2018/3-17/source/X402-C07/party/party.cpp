#include<cstdio>
#include<algorithm>
using namespace std;
const int mod=998244353;
int n,m,k,ans=0,h[100012],a[100012],q[1012][1012];
int check(){
	int tot=0;
	for (int i=1;i<=n;i++)
	  if (a[i])
	    h[++tot]=i;
	if (tot!=m)
	  return 0;
	for (int i=1;i<=n;i++)
	{
	  int ok=1;
	  for (int j=1;j<=tot;j++)
	    if (q[i][h[j]]>k)
	    {
		  ok=0;
		  break;
		}
	  if (ok==1)
	    return true;
	}
	return false;
}

void doing(int pos,int num){
	if (num==m+1)
	  return ;
	if (pos==n+1)
	{
	  if (check())
	    ans++;
	  return ;
	}
	a[pos]=0;
	doing(pos+1,num);
	a[pos]=1;
	doing(pos+1,num+1);
}

int main(){
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=n;j++)
	    q[i][j]=0x3f3f3f3f;
	for (int i=1;i<=n;i++)
	  q[i][i]=0;
	for (int i=1;i<=n-1;i++)
	{
	  int a,b,c;
	  scanf("%d%d%d",&a,&b,&c);
	  q[a][b]=c;
	  q[b][a]=c;
	}
	for (int k=1;k<=n;k++)
	  for (int i=1;i<=n;i++)
	    for (int j=1;j<=n;j++)
	      if (i!=j&&i!=k&&j!=k)
		    q[i][j]=min(q[i][j],q[i][k]+q[k][j]);
	doing(1,0);
	for (int i=1;i<=m;i++)
	  ans=ans*i%mod;
	printf("%d\n",ans);
	return 0;
}
