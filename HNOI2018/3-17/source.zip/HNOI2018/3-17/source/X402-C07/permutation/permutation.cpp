#include<cstdio>
#include<algorithm>
using namespace std;
const int mod=998244353;
int n,q[1000012],a[1000012];
long long ans=0;
int num[1000012],pos[1000012];
long long fac[1000012],gac[1000012],w[1000012];
int nu=0,po=0,tot=0;

long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

long long c(long long n,long long m){
	long long t=fac[n]*gac[n-m]%mod*gac[m]%mod;
	return t;
}

long long p(long long n,long long m){
	long long t=fac[n]*gac[n-m]%mod;
	return t;
}

long long read(){
	long long x=0,f=1;
	char ch=getchar();
	while (ch>'9'||ch<'0')
	{
	  if (ch=='-')
	    f=-1;
	  ch=getchar();
	}
	while (ch>='0'&&ch<='9')
	{
	  x=(x<<1)+(x<<3)+(ch^'0');
	  ch=getchar();
	}
	return x*f;
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++)
	{
	  q[i]=read(),
	  a[i]=i;
	  if (q[i]==i)
	  {
	  	printf("%d\n",0);
	  	return 0;
	  }
	}
	if (n<=10)
	{
	  ans=0;
	  while (next_permutation(a+1,a+1+n))
	  {
	    int ok=1;
	    for (int i=1;i<=n;i++)
	    {
		  if (a[i]==i)
		    ok=0;
		  if (ok==0)
		    break;
	    }
	    for (int i=1;i<=n;i++)
	    {
	  	  if (q[i]!=0)
	  	    if (a[i]!=q[i])
	  	      ok=0;
	  	  if (ok==0)
	  	    break;
	    }
	    ans+=ok;
	  }
	  printf("%d\n",ans);
	  return 0;
	}
	ans=0;
	for (int i=1;i<=n;i++)
	  if (q[i]!=0)
	  	num[q[i]]=1,pos[i]=1;
	for (int i=1;i<=n;i++)
	{
	  if (num[i]==1&&pos[i]==1)
	  {
	    tot++;
	    continue;
	  }
	  if (num[i]==1)
	    nu++;
	  if (pos[i]==1)
	    po++;
	}
	int u=n-tot-po-nu;
	int v=n-tot-po;
	fac[0]=1;
	fac[1]=1;
	for (int i=2;i<=v;i++)
	  fac[i]=fac[i-1]*i%mod;
	gac[v]=mi(fac[v],mod-2);
	for (int i=v-1;i>=1;i--)
	  gac[i]=gac[i+1]*(i+1)%mod;
	gac[0]=1;
	for (int i=1;i<=u;i++)
	  w[i]=c(u,i)*p(v-i,u-i)%mod;
	ans=p(v,u);
	for (int i=1;i<=u;i++)
	  if (i%2==1)
	    ans=(ans-w[i]+mod)%mod;
	  else
	    ans=(ans+w[i])%mod;
	ans=ans*fac[nu]%mod;
	printf("%lld\n",ans);
	
	return 0;
}
