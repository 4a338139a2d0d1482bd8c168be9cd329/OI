#include<cstdio>
#include<algorithm>
#include<map>
using namespace std;
map<int,int> mp;
int T,t,n,m,a[100012],b[100012],h[100012],num[100012],tot=0;
int p(int x){
	if (mp[x]!=0)
	  return mp[x];
	mp[x]=++tot;
	h[tot]=x;
	return mp[x];
}

int gcd(int a,int b){
	if (b==0)
	  return a;
	return gcd(b,a%b);
}

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d",&T);
	scanf("%d",&t);
	while (t--)
	{
	  scanf("%d%d",&n,&m);
	  int maxn=0;
	  for (int i=1;i<=n;i++)
	  {
	    scanf("%d",&a[i]);
	    maxn=max(maxn,a[i]);
	  }
	  if (T==1)
	  {
	  	int w=a[1];
		for (int i=2;i<=n;i++)
	  	  w=gcd(w,a[i]);
	  	printf("%d %d\n",w,w);
	  }
	  else
	  {
	    for (int i=1;i<=50000;i++)
	      num[i]=0;
	    mp.clear();
	    tot=0;
		for (int i=1;i<=n;i++)
	    {
	  	  int x=a[i];
	  	  for (int j=1;j*j<=x;j++)
	  	    if (x%j==0)
	  	    {
			  num[p(j)]++;
	  	      if (x/j!=j)
	  	        num[p(x/j)]++;
	  	    }
	    }
		int ok=0;
	  	for (int i=1;i<=tot;i++)
	  	  if (maxn/h[i]<=m)
	  	  {
			for (int j=1;j<=tot;j++)
	  	  	  b[j]=num[j];
	  		for (int j=1;j<=n;j++)
	  		{
			  int x=a[j];
			  if (x%h[i]!=0)
			    continue;
	  		  for (int k=1;k*k<=x;k++)
	  	  		if (x%k==0)
	  	  		{
				  num[p(k)]--;
	  	    	  if (x/k!=k)
	  	      		num[p(x/k)]--;
	  	  		}
	  		}
	  		//printf("%d\n",h[i]);
	  		for (int j=1;j<=tot;j++)
			  if (h[j]!=1&&num[j]+b[i]==n)
	  		  {
	  		  	ok=1;
				printf("%d %d\n",min(h[i],h[j]),max(h[i],h[j]));
				break;
	  		  }
	  		if (ok==0)
			  for (int j=1;j<=tot;j++)
	  		    num[j]=b[j];
	  		if (ok==1)
	  		  break;
	  	  }
	  	if (ok==0)
	  	{
	  	  for (int i=1;i<=tot;i++)
	  	    if (num[i]==n)
	  	    {
			  printf("%d\n",h[i]);
			  ok=1;
			  break;
			}
		}
		if (ok==0)
		  printf("%d %d\n",1,a[n/2]);
	  }
	}
	return 0;
}
