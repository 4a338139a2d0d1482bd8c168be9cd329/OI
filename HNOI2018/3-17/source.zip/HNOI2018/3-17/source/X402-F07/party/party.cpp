#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005,mod=998244353;
int n,m,k;
vector<int>E[maxn];
int sz[maxn];
bool vis[maxn];
void getsz(int u,int fa){
	sz[u]=1;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa)||(vis[v]))continue;
		getsz(v,u);
		sz[u]+=sz[v];
	}
}
int findroot(int u,int fa,int tot){
	int Max=tot-sz[u];
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa)||(vis[v]))continue;
		chkmax(Max,sz[v]);
		int res=findroot(v,u,tot);
		if(res)return res;
	}return Max<=tot/2?u:0;
}
vector<int>c;
void dfs(int u,int fa,int dep){
	c.pb(dep);
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa)||(vis[v]))continue;
		dfs(v,u,dep+1);
	}
}
int calc(int u,int fa,int dep){
	int res=upper_bound(c.begin(),c.end(),2*k-dep)-c.begin();
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa)||(vis[v]))continue;
		(res+=calc(v,u,dep+1))%=mod;
	}return res;
}
int ans=0;
void solve(int u){
	getsz(u,0);
	u=findroot(u,0,sz[u]);
	vis[u]=1;
	c.clear();
	dfs(u,0,0);
	sort(c.begin(),c.end());
	int res=upper_bound(c.begin(),c.end(),2*k)-c.begin()-1;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(vis[v])continue;
		(res+=calc(v,u,1))%=mod;
	}
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(vis[v])continue;
		c.clear();
		dfs(v,u,1);
		sort(c.begin(),c.end());
		(res+=mod-calc(v,u,1))%=mod;
	}
	(ans+=1ll*res*((mod+1)/2)%mod)%=mod;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(!vis[v])solve(v);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
#endif
	n=read(),m=read(),k=read();
	if(n<=20){
		static ll d[25][25];
		memset(d,0x3f,sizeof(d));
		REP(i,2,n){
			int u=read(),v=read(),w=read();
			d[u][v]=w,d[v][u]=w;
		}
		REP(i,1,n)d[i][i]=0;
		REP(k,1,n)REP(i,1,n)REP(j,1,n)chkmin(d[i][j],d[i][k]+d[k][j]);
		int ans=0;
		REP(i,0,(1<<n)-1){
			if(__builtin_popcount(i)!=m)continue;
			bool res=0;
			REP(j,1,n){
				bool flag=1;
				REP(l,1,n)
					if((i>>(l-1))&1)
						if(d[j][l]>k){flag=0;break;}
				if(flag){res=1;break;}
			}
			ans+=res;
		}
		REP(i,2,m)ans=1ll*ans*i%mod;
		write(ans,'\n');
	}else{
		REP(i,2,n){
			int u=read(),v=read(),w=read();
			E[u].pb(v),E[v].pb(u);
		}
		solve(1);
		REP(i,2,m)ans=1ll*ans*i%mod;
		write(ans,'\n');
	}
	return 0;
}
