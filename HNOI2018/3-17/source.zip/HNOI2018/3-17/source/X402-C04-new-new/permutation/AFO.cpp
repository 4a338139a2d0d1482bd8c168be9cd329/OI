#include<iostream>
#include<cstdio>
#include<cstring>

namespace ZiYouFenZi
{
	typedef long long ll;
	const int N=1010000,MOD=998244353;
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

	int fact[N],ifact[N];
	int f[N];
	int C(int n,int m){return (ll)fact[n]*ifact[m]%MOD*ifact[n-m]%MOD;}

	void initialize()
	{
		fact[0]=f[0]=1;
		for(int i=2;i<N;i++)
			f[i]=(ll)(i-1)*(f[i-1]+f[i-2])%MOD;
		for(int i=1;i<N;i++)fact[i]=(ll)fact[i-1]*i%MOD;
		ifact[N-1]=(inv(fact[N-1])+MOD)%MOD;
		for(int i=N-1;i;i--)ifact[i-1]=(ll)ifact[i]*i%MOD;
	}

	int s[N];
	int n,a,b;

	void calcab()
	{
		static bool vis[N];

		a=b=0;
		for(int i=1;i<=n;i++)
			if(s[i]!=0 && !vis[i])
			{
				int p;
				for(p=i;p && !vis[p];p=s[p])vis[p]=1;
				if(!p)b++;
			}
		for(int i=1;i<=n;i++)
			a+=s[i]==0;
	}

	void solve()
	{
		initialize();

		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",s+i);

		calcab();

		int ans=0;
		for(int i=0;i<=b;i++)
			ans=(ans+(ll)f[a-i]*C(b,i))%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutations.out","w",stdout);
	ZiYouFenZi::solve();
	return 0;
}
