#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=1000009;
const int M=10000;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

int a[N],vis[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("permutation.in","w",stdout);

	int n=100;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
	{
		if(rand()%3==0)
		{
			int u;
			re:;u=rand()%n+1;
			if(u==i || vis[u])goto re;
			vis[u]=1;
			printf("%d ",u);
		}
		else printf("0 ");
	}
	puts("");
	return 0;
}

