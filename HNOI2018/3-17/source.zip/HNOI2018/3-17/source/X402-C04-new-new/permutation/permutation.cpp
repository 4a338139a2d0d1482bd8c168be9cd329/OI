#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=1e6+9;
const ll md=998244353;

int n,a[N],ans;
ll fac[N],inv[N];
bool pos[N],val[N];

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}

inline void init()
{
	fac[0]=1;
	for(ll i=1;i<N;i++)
		fac[i]=fac[i-1]*i%md;
	inv[N-1]=qpow(fac[N-1],md-2);
	for(ll i=N-1;i;i--)
		inv[i-1]=inv[i]*i%md;
}

inline ll c(ll a,ll b)
{
	return fac[a]*inv[b]%md*inv[a-b]%md;
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);

	init();
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		val[i]=1;

	ll cnt=0;
	for(int i=1;i<=n;i++)
		if(a[i]==0)
			pos[i]=1,cnt++;
		else
		{
			pos[i]=0;
			val[a[i]]=0;
		}

	ll ccnt=0;
	for(int i=1;i<=n;i++)
		if(pos[i] && val[i])
			ccnt++;

	ll ans=fac[cnt];
	for(int i=1;i<=ccnt;i++)
		(ans+=(i&1?(-1):1)*c(ccnt,i)%md*fac[cnt-i]%md)%=md;
	printf("%d\n",(ans%md+md)%md);
	return 0;
}

