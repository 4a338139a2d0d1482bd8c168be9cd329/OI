#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=5009;

inline ll read()
{
	ll x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

int T,n,m;
ll a[N];

inline ll gcd(ll a,ll b){return b?gcd(b,a%b):a;}

inline int work1()
{
	ll gcds=a[1];
	for(int i=2;i<=n;i++)
		gcds=gcd(gcds,a[i]);
	printf("%lld %lld\n",gcds,gcds);
	return 0;
}

inline int gbz()
{
	ll gcds=a[1];
	for(int i=2;i<=n;i++)
		gcds=gcd(gcds,a[i]);
	for(int i=1;i<=n;i++)
		a[i]/=gcds;
	ll ans[]={a[1],0};	
	for(int i=2;i<=n;i++)
		if(gcd(ans[0],a[i])!=1)
			ans[0]=gcd(ans[0],a[i]);
		else
			ans[1]=gcd(ans[1],a[i]);
	if(ans[1]==0)ans[1]=1;
	else
	{
		ans[0]=0;
		for(int i=1;i<=n;i++)
			if(gcd(ans[1],a[i])!=ans[1])
				ans[0]=gcd(ans[0],a[i]);
		if(ans[0]==0)
			ans[0]=1;
	}
	if(ans[0]>ans[1])swap(ans[0],ans[1]);
	printf("%lld %lld\n",ans[0]*gcds,ans[1]*gcds);
	return 0;
}

inline int mina()
{
	n=read();m=read();
	cerr<<n<<endl;
	for(int i=1;i<=n;i++)
		a[i]=read();
	if(T==1)
		return work1();
	else
		return gbz();
	return 0;
}

int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);

	T=read();
	for(int tt=read();tt;tt--)
		mina();
	return 0;
}
