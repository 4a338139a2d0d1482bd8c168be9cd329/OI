#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=1000;
const int M=10000;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("number.in","w",stdout);

	puts("0\n1");
	int n=5000,m=1e9;
	printf("%d %d\n",n,m);
	int a=rand()%m+1,b=rand()%m+1;
	for(int i=1;i<=n;i++)
	{
		if(rand()%2)
			printf("%lld ",(ll)a*(ll)(rand()%m+1));
		else
			printf("%lld ",(ll)b*(ll)(rand()%m+1));
	}
	freopen("numbers.out","w",stdout);
	if(a>b)swap(a,b);
	printf("%lld %lld\n",a,b);
	return 0;
}
