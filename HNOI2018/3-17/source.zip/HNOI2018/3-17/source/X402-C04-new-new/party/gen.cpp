#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=1000;
const int M=10000;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("party.in","w",stdout);

	int n=5,m=2,k=1;
	printf("%d %d %d\n",n,m,k);
	for(int i=2;i<=n;i++)
		printf("%d %d %d\n",rand()%(i-1)+1,i,1);
	return 0;
}
