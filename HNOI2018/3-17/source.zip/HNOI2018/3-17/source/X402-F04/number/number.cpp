//2018-3-17
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (5000 + 5)

inline int Gcd(int a, int b){
	return !b? a: Gcd(b, a % b);
}

int T;

void Cheat1(){
	int n, m, ans, rt;

	while(T --){
		scanf("%d%d", &n, &m);
		
		scanf("%d", &ans);
		For(i, 1, n - 1){
			scanf("%d", &rt); ans = Gcd(ans, rt);
		}
		printf("%d %d\n", ans, ans);
	}
}

int h[N];
bool vis[N];

void Cheat2(){
	int n, m;

	srand(time(NULL));
	while(T --){
		scanf("%d%d", &n, &m);
		For(i, 1, n) scanf("%d", &h[i]), vis[i] = false;

		int Cnt = 0, a, b, p;
		while(true){
			For(i, 1, n) swap(h[rand() % n + 1], h[rand() % n + 1]);
			
			p = 2, a = h[1];
			while(p < n && Gcd(h[1], h[p]) > 1) ++p;
			b = h[p];

			For(i, 1, p - 1) a = Gcd(a, h[i]);
			For(i, p + 1, n){
				if(Gcd(a, h[i]) > 1) a = Gcd(a, h[i]);
				else b = Gcd(b, h[i]);
			}
			
			if(a != 1 && b != 1) break;
			if(++Cnt > 20) break;
		}
			
		if(a > b) swap(a, b);
		printf("%d %d\n", a, b);
	}
}

int main(){
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);
	
	int type;
	scanf("%d%d", &type, &T);

	if(type == 1){
		Cheat1(); return 0;
	}else Cheat2();

	return 0;
}
