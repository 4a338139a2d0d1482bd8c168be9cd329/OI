//2018-2-25
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)
int id[N];

int main(){
	freopen("party.in", "w", stdout);

	srand(time(NULL));
	int n = rand() % 17 + 4, m = 2, rk = rand() % 10 + rand() % 50 + 1;
	printf("%d %d %d\n", n, m, rk);
	
	For(i, 1, n) id[i] = i;
	For(i, 1, n * 3) swap(id[rand() % n + 1], id[rand() % n + 1]);
	For(i, 2, n) printf("%d %d 1\n", id[i], id[rand() % (i - 1) + 1]);
	
	return 0;
}
