//2018-3-17
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (200000 + 5)
const int P = 998244353;

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

typedef complex<double> CMX;
const double PI = acos(-1.0);

inline bool Chkmin(int &a, int b){
	if(a > b){a = b; return true;}
	return false;
}

vector<int> G[N];

LL ans[N << 1];
int rn, m, hvy, mins, siz[N], dep[N];
bool vis[N];

namespace FFT{
	int n, nbit, rev[N << 1];
	CMX h[N << 1];

	void Init(int tn){
		n = 1; nbit = 0;
		while(n < (tn * 2 + 1)) n <<= 1, ++nbit;
		For(i, 0, n - 1)
			rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (nbit - 1));
	}
	
	void Clear(){
		For(i, 0, n - 1) h[i] = CMX(0, 0);
	}

	void Fft(int dft){
		For(i, 0, n - 1) if(i < rev[i]) swap(h[i], h[rev[i]]);

		CMX Cnk, Cn, x, y;
		for(int step = 1; step < n; step <<= 1){
			Cn = exp(CMX(0, dft * PI / step));
			
			for(int i = 0; i < n; i += step << 1){
				Cnk = CMX(1, 0);
				For(j, i, i + step - 1){
					x = h[j], y = h[j + step] * Cnk;
					h[j] = x + y; h[j + step] = x - y;
					Cnk *= Cn;
				}
			}
		}

		if(dft == -1){
			For(i, 0, n - 1) h[i] /= (double)n;
		}
	}

	void Sqr(int op){
		Fft(1);
		For(i, 0, n - 1) h[i] = h[i] * h[i];
		Fft(-1);

		For(i, 1, n) ans[i + 1] += op * (LL)(h[i].real() + 0.5);
	}
};

#define v G[now][i]

void FindHeavy(int now, int F){
	siz[now] = 1;

	int Mx = 0;
	For(i, 0, G[now].size() - 1){
		if(v == F || vis[v]) continue;
		FindHeavy(v, now); siz[now] += siz[v];
		Mx = max(Mx, siz[v]);
	}
	Mx = max(Mx, m - siz[now]);

	if(Chkmin(mins, Mx)) hvy = now;
}

void Dfs_dep(int now, int F){
	siz[now] = 1;
	For(i, 0, G[now].size() - 1){
		if(v == F || vis[v]) continue;
		Dfs_dep(v, now); siz[now] += siz[v];
	}
}

void Dfs_init(int now, int F){
	dep[now] = dep[F] + 1;
	For(i, 0, G[now].size() - 1){
		if(vis[v] || v == F) continue;
		Dfs_init(v, now);
	}
}

void Dfs_get(int now, int F){
	FFT::h[dep[now] - 1].real() += 1;
	For(i, 0, G[now].size() - 1){
		if(vis[v] || v == F) continue;
		Dfs_get(v, now);
	}
}

#undef v

void Work(int H){
	Dfs_init(H, 0); FFT::Init(m);
	Dfs_get(H, 0);
	FFT::Sqr(1); FFT::Clear();

	int v;
	For(i, 0, G[H].size() - 1){
		if(vis[v = G[H][i]]) continue;
		
		FFT::Init(siz[v] + 1); Dfs_get(v, H);
		FFT::Sqr(-1); FFT::Clear();
	}
}

int Tot;

void Solve(int H, int F){
	++Tot;
	hvy = H, mins = m;
	
	FindHeavy(H, F); Dfs_dep(hvy, 0); 
	Work(hvy);
	
	vis[H = hvy] = true;
	For(i, 0, G[H].size() - 1){
		int v = G[H][i]; m = siz[v];
		if(!vis[v]) Solve(v, H);
	}
}

struct node{
	int v, w;
};

namespace Bf{
	int nn, mm, rkk, cnt[N];
	vector<node> g[N];
#define v g[now][i].v
	void Work(int now, int F, long long dis){
		if(dis > (long long)rkk) return;
		++cnt[now];
		For(i, 0, g[now].size() - 1)
			if(v != F) Work(v, now, dis + g[now][i].w);
	}
#undef v
	
	void bf(){
		int u, v, w;

		scanf("%d%d", &mm, &rkk);
		For(i, 1, nn - 1){
			scanf("%d%d%d", &u, &v, &w);
			g[u].pb((node){v, w});
			g[v].pb((node){u, w});
		}

		int ret = 0;
		For(i, 1, (1 << nn) - 1){
			if(__builtin_popcount(i) != mm) continue;
			
			For(j, 1, nn) cnt[j] = 0;
			For(j, 1, nn) if(i & (1 << (j - 1))) Work(j, 0, 0);
		
			For(j, 1, nn) if(cnt[j] == mm){
				++ret; break;
			}
		}

		For(i, 2, mm) ret = (long long)i * ret % P;
		printf("%d\n", ret);
	}
};

int main(){
	freopen("party.in", "r", stdin);
	freopen("party.out", "w", stdout);

	int u, v, w, kk;

	Read(rn);
	if(rn <= 20){
		Bf::nn = rn;
		Bf::bf(); return 0;
	}

	scanf("%d%d", &u, &kk);
	For(i, 1, rn - 1){
		Read(u), Read(v), Read(w);
		G[u].pb(v); G[v].pb(u);
	}

	int Ans = 0;

	m = rn; Solve(1, 0);
	For(i, 2, rn) if((i - 1) <= (kk << 1)){
		Ans += ans[i] % P;
		if(Ans >= P) Ans -= P;
	}
	printf("%d\n", Ans);
	
	return 0;
}
