//2018-3-17
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)
const int P = 998244353;

struct node{
	int v, w;
};

int n, m, rk, cnt[N];
vector<node> G[N];

#define v G[now][i].v
void Work(int now, int F, int dis){
	if(dis > rk) return;
	++cnt[now];
	For(i, 0, G[now].size() - 1)
		if(v != F) Work(v, now, dis + G[now][i].w);
}
#undef v

int main(){
	freopen("party.in", "r", stdin);
	freopen("party2.out", "w", stdout);

	int u, v, w;

	scanf("%d%d%d", &n, &m, &rk);
	For(i, 1, n - 1){
		scanf("%d%d%d", &u, &v, &w);
		G[u].pb((node){v, w});
		G[v].pb((node){u, w});
	}

	int ans = 0;
	For(i, 1, (1 << n) - 1){
		if(__builtin_popcount(i) != m) continue;
		
		For(j, 1, n) cnt[j] = 0;
		For(j, 1, n) if(i & (1 << (j - 1))) Work(j, 0, 0);
	
		For(j, 1, n) if(cnt[j] == m){
			++ans; break;
		}
	}

	For(i, 2, m) ans = (long long)i * ans % P;
	printf("%d\n", ans);

	return 0;
}
