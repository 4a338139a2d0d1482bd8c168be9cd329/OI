//2018-3-17
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (1000000 + 5)

int n, ans, a[N];
bool vis[N];

void Dfs(int now){
	if(now > n){
	//	For(i, 1, n) printf("%d ", a[i]); puts("");
		++ans; return;
	}

	if(a[now]){
		Dfs(now + 1); return;
	}

	For(i, 1, n) if(!vis[i] && i != now){
		a[now] = i; vis[i] = true;
		Dfs(now + 1);
		vis[i] = false;
	}
	a[now] = 0;
}

int main(){
	freopen("permutation.in", "r", stdin);
	freopen("permutation2.out", "w", stdout);
	
	scanf("%d", &n);
	For(i, 1, n){
		scanf("%d", &a[i]), vis[a[i]] = true;
		if(i == a[i]){
			puts("0"); return 0;
		}
	}

	Dfs(1);
	printf("%d\n", ans);

	return 0;
}
