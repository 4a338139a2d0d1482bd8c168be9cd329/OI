//2018-3-17
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (1000000 + 5)
int a[N];

int main(){
	freopen("permutation.in", "w", stdout);
	srand(time(NULL));

	int n = rand() % 7 + 6;
	//n = 1000000;
	printf("%d\n", n);

	For(i, 1, n) a[i] = i;

	random_shuffle(a + 1, a + n + 1);
	For(i, 1, n * (rand() % 3)) swap(a[rand() % n + 1], a[rand() % n + 1]);
	For(i, 1, n) if(a[i] == i) a[i] = 0;

	int t = rand() % 2? (n / 3): 5;
	For(i, 1, n){
		if(rand() % t) printf("0 ");
		else printf("%d ", a[i]);
	}
	puts("");

	return 0;
}
