//2018-3-17
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (1000000 + 5)
const int P = 998244353;

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

inline int Mod(int a){
	if(a < 0) return a + P;
	return a >= P? a - P: a;
}
inline int Mul(int a, int b){
	return (long long)a * b % P;
}
inline int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = Mul(ret, a);
		a = Mul(a, a); anum >>= 1;
	}
	return ret;
}

int n, f[N], in[N], to[N], fac[N], rfac[N];

int C(int a, int b){
	return Mul(fac[a], Mul(rfac[b], rfac[a - b]));
}

int main(){
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	
	int rt;

	Read(n);
	For(i, 1, n){
		Read(rt); ++in[rt];
		if(rt) ++to[i];
	
		if(i == rt){
			puts("0"); return 0;
		}
	}

	int a = 0, b = 0;
	For(i, 1, n) if(!in[i]){
		if(to[i]) ++b; else ++a;
	}
//	printf("a = %d b = %d\n", a, b);

	f[0] = f[2] = 1; f[3] = 2;
	For(i, 4, n) f[i] = Mul(i - 1, Mod(f[i - 1] + f[i - 2]));
	
	fac[0] = rfac[0] = 1;
	For(i, 1, n){
		fac[i] = Mul(fac[i - 1], i); rfac[i] = Pow(fac[i], P - 2);
	}

	if(b == 0){
		printf("%d\n", f[a]); return 0;
	}

	int ans = 0, tmp, op = -1;
	For(i, 0, a){
		op *= -1;
		tmp = Mod(op * Mul(C(a, i), fac[a - i + b]));
		ans = Mod(ans + tmp);
	}

	printf("%d\n", ans);

	return 0;
}
