#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod=998244353,maxn=1e6+10;
int now,a[maxn],b[maxn],cnt,ovo,vis[maxn];
int pd1[maxn],pd2[maxn];
ll qaq,ans,jc[maxn],inv[maxn];

inline ll rel(ll x){
	if(x%2)
		return -1;
	return 1;
}

inline ll qpow(ll a,ll x){
	ll ret=1;
	while(x){
		if(x&1)
			ret=ret*a%mod;
		x>>=1;
		a=a*a%mod;
	}
	return ret;
}

inline void read(int &x){
	int f=1;x=0;char c=getchar();
	while(c>'9'||c<'0'){
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	x*=f;
}


int main(void){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n,k;
	read(n);
	for(int i=1;i<=n;++i){
		read(a[i]);
		if(!a[i])
			b[++cnt]=i,pd2[i]=1;
		else
			vis[a[i]]=1;
	}
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;++i)	
		if(!vis[i])
			a[++ovo]=i,pd1[i]=1;
	jc[0]=1;
	for(int i=1;i<=cnt;++i)
		jc[i]=jc[i-1]*i%mod;
	inv[cnt]=qpow(jc[cnt],mod-2);
	for(int i=cnt;i>=1;--i)
		inv[i-1]=inv[i]*i%mod;	
	for(int i=1;i<=n;++i)
		if(pd1[i]==1&&pd2[i]==1)
			++qaq;
	for(int i=0;i<=qaq;++i)
		(ans+=rel(i)*(jc[qaq]*inv[i]%mod*inv[qaq-i]%mod)*jc[cnt-i]%mod)%=mod;
	
	printf("%lld\n",(ans+mod)%mod);	
}
