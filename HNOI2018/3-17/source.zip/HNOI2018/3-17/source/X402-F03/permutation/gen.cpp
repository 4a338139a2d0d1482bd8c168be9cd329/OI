#include<cstdio>
#include<iostream>
#include<cstdlib>
using namespace std;
int a[20];
int main()
{
	freopen("permutation.in","w",stdout);
	srand(233);
	int n=20;
	printf("%d\n",n);
	for (int i=1;i<=n;++i)
	if (rand()%2)
		a[rand()%n+1]=i;
	for (int i=1;i<=n;++i)
		printf("%d ",a[i]);
	printf("\n");
	return 0;
}
