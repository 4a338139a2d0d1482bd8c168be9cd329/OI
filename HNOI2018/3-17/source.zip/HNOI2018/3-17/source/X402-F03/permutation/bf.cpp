#include<cstdio>
#include<iostream>
using namespace std;
int a[22];
bool br[22];
int n,ans;
void dfs(int deep)
{
	if (deep>n)
	{
//		for (int i=1;i<=n;++i)
//			printf("%d-%d  ",i,a[i]);
//		printf("\n");
		++ans;
		return;
	}
	if (a[deep]) 
	{
		dfs(deep+1);
		return;
	}
	for (int i=1;i<=n;++i)
		if (br[i]==0 && i!=deep)
		{
			a[deep]=i;
			br[i]=1;
			dfs(deep+1);
			a[deep]=0;
			br[i]=0;
		}
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("bf.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
		scanf("%d",&a[i]),br[a[i]]=1;
	for (int i=1;i<=n;++i)
		if (a[i]!=0)
			if (a[i]==i)
			{
				printf("0\n");
				return 0;
			}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
