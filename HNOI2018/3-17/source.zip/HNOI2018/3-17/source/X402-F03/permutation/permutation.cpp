#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
const ll mod=998244353;

ll D[1010101],jc[1010101],jc_ny[1010101];
int n,a,b;
ll ans;
int nxt[1010101],pre[1010101];
bool br[1010101];
ll power(ll x,ll k)
{
	ll sss=1;
	while (k)
	{
		if (k%2==1)
			sss=sss*x%mod;
		x=x*x%mod;
		k/=2;
	}
	return sss;
}
ll ny(ll x)
{
	return power(x,mod-2);
}
ll C(int x,int y)
{
	if (y<0 || y>x) return 0;
	if (y==0 || y==x) return 1;
	ll sss=jc[x];
	sss=sss*jc_ny[y]%mod*jc_ny[x-y]%mod;
	return sss;
}
void Init()
{
	jc[0]=1; jc_ny[0]=1;
	for (int i=1;i<=1000001;++i)
		jc[i]=jc[i-1]*i%mod,jc_ny[i]=ny(jc[i]);		

	D[1]=0; D[2]=1;
	for (int i=3;i<=1000001;++i)
		D[i]=(i-1)*(D[i-1]+D[i-2]) %mod;
//	for (int i=1;i<=8;++i)
//		printf("%lld ",D[i]);
//	printf("\n=======================\n");
}
void sol()
{
	int kkk=min(a-2,b);
	for (int i=0;i<=kkk;++i)
	{
		ll sss=C(a,i)*jc[b]%mod*jc_ny[b-i]%mod;
		sss=sss*D[a-i]%mod*jc[a+b-i]%mod*jc_ny[a]%mod;
		ans=(ans+sss)%mod;
//		printf("%lld\n",sss);
	}
	if (a<=b)
	{
		ll sss=jc[b]*jc_ny[b-a]%mod;
		sss=sss*jc[b]%mod*jc_ny[a]%mod;
		ans=(ans+sss)%mod;
//		printf("%lld\n",sss);
	}

}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);

	Init();
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
		scanf("%d",&nxt[i]),pre[nxt[i]]=i;
	for (int i=1;i<=n;++i)
		if (br[i]==0 && (nxt[i]!=0 || pre[i]!=0))
		{
			++b;
			br[i]=1;
			int x=nxt[i];
			while (x)
			{
				if (br[x])
				{
					--b;
					break;
				}
				br[x]=1;
				x=nxt[x];
			}
			x=pre[i];
			while (x)
			{
				if (br[x])
					break;
				br[x]=1;
				x=pre[x];
			}

		}
	for (int i=1;i<=n;++i)
		if (br[i]==0) ++a;
//	printf("point:%d line:%d\n",a,b);
	sol();
	printf("%lld\n",ans);
	return 0;
}
