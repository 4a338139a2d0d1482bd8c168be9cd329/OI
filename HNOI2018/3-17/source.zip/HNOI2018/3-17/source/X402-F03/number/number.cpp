#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
int n,m;
ll gcd(ll x,ll y)
{
	if (y==0)
		return x;
	return gcd(y,x%y);
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int T;
	ll x,y;
	scanf("%lld%d",&x,&T);
	while (T--)
	{
		scanf("%d%d",&n,&m);
		x=m;
		for (int i=1;i<=n;++i)
		{
			scanf("%lld",&y);
			x=gcd(x,y);
		}
		printf("%lld %lld\n",x,x);
	}
	return 0;
}
