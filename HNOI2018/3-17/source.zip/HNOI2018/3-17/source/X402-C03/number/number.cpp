#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=5e3+10;
int type,t,n,m;
ll x[maxn],gcd;

inline ll read(){
	ll x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	srand(time(NULL));
	type=read();t=read();
	while(t--){
		n=read();m=read();
		for(int i=1;i<=n;++i)
			x[i]=read();
		gcd=0;
		for(int i=1;i<=n;++i)
			gcd=__gcd(gcd,x[i]);
		if(type==1)
			printf("%lld %lld\n",gcd,gcd);
		else{
			for(int i=1;i<=n;++i)
				x[i]/=gcd;
			ll a,b;
			while(true){
				a=__gcd(x[rand()%n+1],x[rand()%n+1]),b=0;
				for(int i=1;i<=n;++i)
					if(x[i]%a)
						b=__gcd(x[i],b);
				if(!b)
					b=1;
				for(int i=1;i<=n;++i)
					if(x[i]%a==0&&x[i]/a<=m||x[i]%b==0&&x[i]/b<=m)
						;
					else
						goto fail;
				break;
fail:
				;
			}
			if(a>b)swap(a,b);
			printf("%lld %lld\n",a*gcd,b*gcd);
		}
	}
	return 0;
}
