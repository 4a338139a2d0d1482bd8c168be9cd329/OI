#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("number.txt","w",stdout);
	FILE*f=fopen("temp.txt","r");
	int a,b;
	while(fscanf(f,"%d%d",&a,&b)==2){
		printf("%d %d\n",a,b);
	}
	return 0;
}
