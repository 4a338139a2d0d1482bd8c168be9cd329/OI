#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}
typedef long long ll;

int main(){
	init();
	freopen("number.in","w",stdout);
	FILE*file=fopen("temp.txt","w");
	int t=f(1,5),x=300;
	printf("%d\n%d\n",t,x);
	while(x--){
		int a,b,n=f(5000,5000),m=1e9;
		double p;

		a=f(1,m),b=f(1,m);
		if(a>b)swap(a,b);
		p=f(10000,990000)/1e6;

		if(t==1)
			a=b=f(1,m);
		else if(t==2)
			p=0.5;
		else if(t==3)
			;
		else if(t==4){
			if(f(0,1)){
				int w=f(1,m/40);
				a=w*f(1,20);
				b=w*f(1,20);
				if(a>b)swap(a,b);
			}
			p=0.5;
		}
		else{
			if(f(0,1)){
				int x=1e2-sqrt(f(1,1e4))+1;
				int w=f(1,m/x);
				a=w*f(1,x);
				b=w*f(1,x);
				if(a>b)swap(a,b);
			}
		}
		fprintf(file,"%d %d\n",a,b);
		printf("%d %d ",n,m);
		for(int i=1;i<=n;++i)
			if(rand()/pow(2,31)<=p)
				printf("%lld ",(ll)f(1,m)*a);
			else
				printf("%lld ",(ll)f(1,m)*b);
		puts("");
	}
	return 0;
}
