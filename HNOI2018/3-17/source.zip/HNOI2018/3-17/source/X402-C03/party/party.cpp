#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=5e3+10,mod=998244353;
int n,m,k,tmp[maxn];
int g[maxn][maxn];
ll ans;

void dfs(int pos,int chosen){
	if(chosen>=m){
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j)
				if(g[i][tmp[j]]>k)
					goto fuck;
			++ans;
			return;
fuck:
			;
		}
		return;
	}
	if(pos>n)
		return;
	tmp[chosen+1]=pos;
	dfs(pos+1,chosen+1);
	dfs(pos+1,chosen);
}

int main(){
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			g[i][j]=i==j?0:k+1;
	for(int i=1,u,v,w;i<n;++i){
		scanf("%d%d%d",&u,&v,&w);
		g[u][v]=g[v][u]=w;
	}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			for(int k=j+1;k<=n;++k)
				if(g[j][k]>g[j][i]+g[i][k])
					g[j][k]=g[k][j]=g[j][i]+g[i][k];
	dfs(1,0);
	for(int i=1;i<=m;++i)
		ans=ans*i%mod;
	printf("%lld\n",ans);
	return 0;
}
