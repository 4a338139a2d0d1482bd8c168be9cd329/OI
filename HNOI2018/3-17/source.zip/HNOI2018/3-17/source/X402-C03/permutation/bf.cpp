#include<bits/stdc++.h>
using namespace std;

const int maxn=1e6+10,mod=998244353;
int n,a[maxn],p[maxn],ans;

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.txt","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)
		p[i]=i;
	do{
		for(int i=1;i<=n;++i)
			if(p[i]==i||a[i]&&a[i]!=p[i])
				goto hell;
		++ans;
hell:
		;
	}
	while(next_permutation(p+1,p+n+1));
	printf("%d\n",ans%mod);
	return 0;
}
