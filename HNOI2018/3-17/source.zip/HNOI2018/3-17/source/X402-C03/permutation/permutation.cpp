#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=2e3+10,mod=998244353;
int n,a[maxn],p[maxn];
ll dp[maxn][maxn];
int x,y;

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
		p[a[i]]=i;
	}
	for(int i=1;i<=n;++i)
		if(!a[i]&&!p[i])
			++y;
		else if(!a[i]||!p[i])
			++x;
	x/=2;
	dp[0][0]=1;
	n=x+y;
	for(int i=0;i<n;++i)
		for(int j=0;j<n;++j){
			if(i<x)
				(dp[i+1][j]+=dp[i][j])%=mod;
			(dp[i+1][j+1]+=dp[i][j])%=mod;
			if(j)(dp[i+1][j]+=dp[i][j]*j*2ll)%=mod;
			if(j)(dp[i+1][j-1]+=dp[i][j]*j%mod*j)%=mod;
		}
	printf("%lld\n",dp[n][0]);
	return 0;
}
