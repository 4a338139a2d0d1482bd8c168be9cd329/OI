#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("permutation.in","w",stdout);
	int a[1000010];
	int n=f(2,10);
	for(int i=1;i<=n;++i)
		a[i]=i;
	random_shuffle(a+1,a+n+1);
	printf("%d\n",n);
	for(int i=1;i<=n;++i)
		if(f(1,7)<=2&&a[i]!=i)
			printf("%d ",a[i]);
		else
			printf("0 ");
	return 0;
}
