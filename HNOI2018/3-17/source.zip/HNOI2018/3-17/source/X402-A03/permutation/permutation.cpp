/**********************************************************
	File:permutation.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-3-17 08:50:31
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 998244353
#define N 1000010

namespace bf
{
	namespace bfrun
	{
		int p[N],n,a[N];
		void file()
		{
			freopen("permutation.in","r",stdin);
			freopen("permutation.out","w",stdout);
		}
		void input()
		{
			n=read();
			fr(i,1,n)a[i]=read();
		}
		int run()
		{
			fr(i,1,n)p[i]=i;
			int ans=0;
			while(next_permutation(p+1,p+n+1))
			{
				ans++;
				fr(i,1,n)if((a[i]&&a[i]!=p[i])||p[i]==i){ans--;break;}
			}
			return ans;
		}
		int main()
		{
			file();
			input();
			printf("%d\n",run());
			return 0;
		}
	}
	int run(int a,int b)
	{
		bfrun::n=a+b+b;
		fr(i,1,a+b)bfrun::a[i]=0;
		fr(i,1,b)bfrun::a[i+a+b]=i+a;
		return bfrun::run();
	}
	int main()
	{
		fr(i,0,4)
			fr(j,0,4)
				printf("%d%c",run(i,j),j==_end_?'\n':' ');
		return 0;
	}
}
int main(){return bf::bfrun::main();}