/**********************************************************
	File:party.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-3-17 11:00:07
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
namespace bf
{
	#define N 1000010
	#define mod 998244353
	int begin[N],next[N],to[N],w[N],e,n,m,k,t[N],ans;
	void add(int u,int v,int ww)
	{
		e++;
		to[e]=v;
		w[e]=ww;
		next[e]=begin[u];
		begin[u]=e;
	}
	#define fo(i,a) for(int i=begin[a];i;i=next[i])
	void dfs1(int u,int d,int x)
	{
		t[x]|=1<<(u-1);
		fo(i,u)
		{
			int v=to[i],ww=d-w[i];
			if(t[x]&(1<<(v-1))||ww<0)
				continue;
			dfs1(v,ww,x);
		}
	}
	void dfs2(int x,int y,int k)
	{
		if(y==m)
		{
			// printf("%d ",k);
			fr(i,1,n)
				if((t[i]&k)==k)
				{
					ans++;
					// putchar(10);
					return;
				}
			// printf("%d\n",k);
			return;
		}
		if(x==n+1)return;
		dfs2(x+1,y,k);
		dfs2(x+1,y+1,k|(1<<(x-1)));
	}
	int main()
	{
		freopen("party.in","r",stdin);
		freopen("party.out","w",stdout);
		n=read();
		m=read();
		k=read();
		fr(i,1,n-1)
		{
			int u=read(),v=read(),w=read();
			add(u,v,w);
			add(v,u,w);
		}
		fr(i,1,n)
			dfs1(i,k,i);
		dfs2(1,0,0);
		fr(i,2,m)ans=ans*i%mod;
		printf("%d\n",ans);
		return 0;
	}
}
int main(){return bf::main();}