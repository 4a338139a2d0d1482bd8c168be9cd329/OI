/*
Author: CNYALI_LK
LANG: C++
PROG: permutation.cpp Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll f[12][12],g[12][12],qzh[12][12];
int main(){
#ifdef cnyali_lk
	freopen("permutation.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	ll n=10,m=10;
	g[0][0]=1;
	for(ll i=1;i<=n;++i){g[i][0]=1;}
	qzh[0][1]=1;
	for(ll i=2;i<=m;++i){
		g[0][i]=(g[0][i-1]+g[0][i-2])*(i-1);
		qzh[0][i]=1;
	}
	for(ll i=1;i<=n;++i)for(ll j=1;j<=m;++j)
		qzh[i][j]=qzh[i-1][j]+qzh[i][j-1];
	for(ll i=1;i<=n;++i)for(ll j=1;j<=m;++j){
		g[i][j]=g[i-1][j]+g[i][j-1]*j;
		f[i][j]=0;
	}
	ll i=1,j=3;
		ll fq=1;
		
		for(ll k=j;~k;--k){
			printf("%d%c",qzh[j-k][i],k?' ':'\n');
			f[i][j]+=fq*g[0][k]*qzh[j-k][i];
			fq*=k;
		}
		printf("%lld%c",f[i][j],j==m?'\n':' ');
//	}
	
	return 0;
}

/*

 * */
