/*
Author: CNYALI_LK
LANG: C++
PROG: permutation.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll doub,only;
ll a[1049090],fac[1234567],inv[1234567],invf[1234567],pre[1234567],d[1234567],vis[1234567];
const ll p=998244353;
void go(ll x){
	ll t=x,st=0;
	while(t&&!vis[t]){
		vis[t]=1;
		t=a[t];
		++st;
	}
	if(vis[t])return;
	t=pre[x];
	while(t&&!vis[t]){
		vis[t]=1;
		t=pre[t];
		++st;
	}
	if(st>1)++doub;
	else ++only;
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	ll n=read();
	ll m=1048576;
	fac[0]=fac[1]=1;
	inv[1]=1;
	invf[0]=invf[1]=1;
	for(ll i=2;i<=m;++i){
		fac[i]=fac[i-1]*i%p;
		inv[i]=(p-p/i)*inv[p%i]%p;
		invf[i]=inv[i]*invf[i-1];
	}
	for(ll i=1;i<=n;++i)pre[a[i]=read()]=i;
	for(ll i=1;i<=n;++i)if(!vis[i])go(i);
	ll ans=0,cs=1,fq=1;
	d[0]=1;d[1]=0;
	for(ll i=2;i<=m;++i)d[i]=(i-1)*(d[i-1]+d[i-2])%p;
	if(!doub)printf("%lld\n",d[only]);
	else{
		for(ll i=only;~i;--i){
			ans=(ans+d[i]*fq%p*cs)%p;	
			cs=cs*(doub+(only-i))%p*inv[only-i+1]%p;
			fq=fq*i%p;
		}
		printf("%lld\n",ans*fac[doub]%p);
	}
	return 0;
}

