#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("party.in", "r", stdin);
	freopen ("party.out", "w", stdout);
}

int n, m, k;
const int N = 1e5 + 1e3;
const int inf = 0x3f3f3f3f;
const int NN = (1 << 20);

typedef long long ll;
const ll Mod = 998244353;

int dis[25][25];

void Solve1() {
	Set(dis, inf);
	For (i, 1, n - 1) {
		int u = read(), v = read(), w = read();
		dis[u][v] = dis[v][u] = w;
	}
	For (k, 1, n) For (i, 1, n) For (j, 1, n) chkmin(dis[i][j], dis[i][k] + dis[k][j]);
	int nn = 1 << n;
	ll ans = 0;

	For (i, 0, nn - 1)
		if (__builtin_popcount(i) == m) {
			bool flag = false;
			For (u, 1, n) {
				bool now = true;
				For (v, 1, n)
					if ((1 << (v - 1)) & i) if (dis[u][v] > k) { now = false; break; }
				if (now) { flag = true; break ; }
			}
			if (flag) ++ ans;
		}

	ll fac = 1;
	For (i, 1, m) (fac *= i) %= Mod;
	(ans *= fac) %= Mod;

	printf ("%lld\n", ans);
}

int main () {
	File();
	n = read(); m = read(); k = read();
	if (n <= 20) Solve1();
    return 0;
}
