#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(long long &a, long long b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(long long &a, long long b) {return b > a ? a = b, 1 : 0;}

inline long long read() {
    long long x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("number.in", "r", stdin);
	freopen ("number.out", "w", stdout);
}

typedef long long ll;
const int N = 5010;
int n, m; 
ll P[N];

int prob = 50;
inline bool Get() { return (rand() % 101 + 1 <= prob); }

void Solve1() {
	long long ans = 0;
	For (i, 1, n)
		ans = __gcd(ans, P[i]);
	if (ans >= (int) 1e9) {
		For (i, 2, 100) if (!(ans % i)) { ans /= i; break ; }
	}
	printf ("%lld %lld\n", ans, ans);
}

long long Best = 0;
int Ba, Bb;
void Judge(int a, int b) {
	if (chkmax(Best, 1ll * a * b)) { Ba = a; Bb = b; }
}

void Solve2() {
	srand(19260817);
	int Try = 30;
	ll ansa, ansb;
	Best = 0;
	while (Try --) {
		ll now = 0;
		for (;;) {
			int posa = rand() % n + 1, posb = rand() % n + 1;
			now = __gcd(P[posa], P[posb]);
			if (now > 1) break ;
		}
		while (now > m) {
			int pos = rand() % n + 1;
			ll res = __gcd(now, P[pos]);
			if (res == 1) continue ;
			now = res;
		}
		ansa = now, ansb = 0;
		For (i, 1, n)
			if ((P[i] % now)) ansb = __gcd(ansb, P[i]);
		if (!ansb) ansb = ansa;
		Judge(ansa, ansb);
	}
	ansa = Ba; ansb = Bb;
	if (ansa > ansb) swap(ansa, ansb);
	printf ("%lld %lld\n", ansa, ansb);
}

int main () {
	File();
	int type = read();
	int cases = read();
	while (cases --) {
		n = read(); m = read();
		For (i, 1, n) P[i] = read();
		if (type == 1) Solve1();
		else Solve2();
	}
	//cerr << (double)clock() / CLOCKS_PER_SEC << endl;
    return 0;
}
