#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("permutation.in", "r", stdin);
	freopen ("permutation.out", "w", stdout);
}

typedef long long ll;
const int N = 2010;
int n, a[N];
ll ans = 0;

void Out() { For (i, 1, n) printf ("%d ", a[i]); putchar('\n'); }


const ll Mod = 998244353;
ll fac[N], ifac[N];

ll fpm(ll x, ll power) {
	ll res = 1;
	for (; power; power >>= 1, (x *= x) %= Mod)
		if (power & 1) (res *= x) %= Mod;
	return res;
}

ll F[N];

void Init(int maxn) {
	fac[1] = ifac[0] = fac[0] = 1;
	For(i, 2, maxn) fac[i] = fac[i - 1] * i % Mod;
	ifac[maxn] = fpm(fac[maxn], Mod - 2);
	Fordown(i, maxn - 1, 1)
		ifac[i] = ifac[i + 1] * (i + 1) % Mod;
	F[0] = 1; F[1] = 0; F[2] = 1;
	For (i, 3, maxn)
		F[i] = (F[i - 1] + F[i - 2]) * (i - 1) % Mod;
}

ll C(int m, int n) { if (m > n || m < 0 || n < 0) return 0; return fac[n] * ifac[m] % Mod * ifac[n - m] % Mod; }

bool P[N];
ll res[N];

int main () {
	File();
	Init(2000);
	int k = 0, l = 0;
	n = read(); 
	For (i, 1, n) { a[i] = read(); P[a[i]] = true; if (a[i] == i) return puts("0"), 0; }
	For (i, 1, n) 
		if (!a[i]) { if (!P[i]) ++ k; ++ l; }
	ans = fac[l];
	Fordown (i, k, 1) {
		res[i] = fac[l - i] * C(i, k) % Mod;
		For (j, i + 1, k)
			(res[i] += Mod - res[j] * C(i, j)) %= Mod;
		(ans += Mod - res[i]) %= Mod;
	}

	printf ("%lld\n", ans);
    return 0;
}
