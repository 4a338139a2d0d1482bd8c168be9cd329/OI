#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1000100, INF = 0x3f3f3f3f, Mod = 998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
}
int n, a[N];
int vis[N], V[N];
ll fac[N], ifac[N];
ll qpow(ll a, ll b){
	ll ret = 1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}

int dfs(int u){
	if(vis[u])return 0;
	vis[u] = 1;
	if(!a[u])return 1;
	return dfs(a[u]);
}
int t, m;
void init(){
	read(n);
	For(i, 1, n){
		read(a[i]);
		if(a[i])V[a[i]] = V[i] = 1;
	}
	For(i, 1, n)m += !V[i];
	t = 0;
	For(i, 1, n)
		if(a[i] && !vis[i] && dfs(i))t++;
		
	fac[0] = 1;
	For(i, 1, n)fac[i] = fac[i - 1] * i % Mod;
	ifac[n] = qpow(fac[n], Mod - 2);
	Forr(i, n, 1)ifac[i - 1] = ifac[i] * i % Mod;
}
inline ll C(int a, int b){
	if(a < 0 || b < 0 || a < b)return 0;
	return fac[a] * ifac[b] % Mod * ifac[a - b] % Mod;
}
void solve(){
	ll Fac = 1, ans = 0;
	For(i, 1, t)Fac = Fac * i % Mod;
	For(i, 0, m){
		if((m-i)&1)
			ans = (ans + Mod - C(m, i) * Fac % Mod) % Mod;
		else 
			ans = (ans + C(m, i) * Fac % Mod) % Mod;
		Fac = Fac * (i + 1 + t) % Mod; 
	}
	printf("%lld\n", ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
