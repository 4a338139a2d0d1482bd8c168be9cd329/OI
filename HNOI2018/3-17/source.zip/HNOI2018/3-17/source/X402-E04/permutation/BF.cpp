#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 20, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("permutation.in","r",stdin);
	freopen("BF.out","w",stdout);
}
int n, a[N], vis[N], p[N];
void init(){
	read(n);
	For(i, 1, n)read(a[i]), vis[a[i]] = 1;
}
int ans=0;
void dfs(int now){
	if(now > n){
		return void (ans++);
	}
	if(a[now]){p[now] = a[now];return void(dfs(now + 1));}
	For(i, 1, n)if(!vis[i] && i != now){
		vis[i] = 1;p[now] = i;
		dfs(now + 1);
		vis[i] = 0;
	}
}
void solve(){
	dfs(1);
	cerr<<"okbf"<<endl;
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
