#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1000100, INF = 0x3f3f3f3f;

int vis[N];
int main(){
	srand(time(0));
	int n = 1000000;
	freopen("permutation.in","w",stdout);
	printf("%d\n", n);
	For(i, 1, n){
		int r = rand()%2%1;
		if(r){
			int x = rand() % n + 1;
			while(vis[x] || x==i)x = rand() % n + 1;
			vis[x] = 1;
			printf("%d ", x);
		}else {
			printf("0 ");
		}
	}
	cerr<<"okgen"<<endl;
	puts("");
}
