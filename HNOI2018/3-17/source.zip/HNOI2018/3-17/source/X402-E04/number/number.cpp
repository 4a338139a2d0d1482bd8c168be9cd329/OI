#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
}
int n, T, t, m;
ll a[N];
void init(){
	read(T);
	read(t);
}
void solve(){
	if(T == 1){
		while(t--){
			read(n), read(m);
			For(i, 1, n)read(a[i]);
			ll b = a[1];
			For(i, 2, n)b = __gcd(b, a[i]);
			printf("%lld %lld\n", b, b);
		}
	}else {

	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
