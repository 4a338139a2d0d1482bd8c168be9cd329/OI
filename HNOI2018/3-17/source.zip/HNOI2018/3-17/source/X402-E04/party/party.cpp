#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f, Mod = 998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
}
int n, Begin[N], Next[N<<1], e=1, to[N<<1], m, k, w[N<<1];
inline void add(int x, int y, int z){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e, w[e] = z;
}
void init(){
	read(n), read(m), read(k);
	For(i, 1, n - 1){
		int x, y, z;
		read(x), read(y), read(z);
		add(x, y, z), add(y, x, z);
	}
}
namespace BF1{
	int ans = 0;
	int p[N];
	ll dep[N];
	void dfs(int u, int f){
		Rep(i, u)if(v^f)
			dep[v] = dep[u] + w[i], dfs(v, u);
	}
	bool check(){
		For(i, 1, n){
			dep[i] = 0;dfs(i, 0);
			int ok = 1;
			For(j, 1, n)if(p[j] && dep[j] > k)ok = 0;
			if(ok == 1)return 1;
		}
		return 0;
	}
	void DFS(int now, int cnt){
		if(now > n)
			return void(cnt == m ? ans += check(): 0);
		p[now] = 1;
		DFS(now + 1, cnt + 1);
		p[now] = 0;
		DFS(now + 1, cnt);
	}
	void solve(){
		DFS(1, 0);
		For(i, 1, m)ans = 1ll * ans * i % Mod;
		printf("%d\n", ans);
	}
}
namespace BF2{
	int p[N<<1],siz[N],fa[N];
	ll dis[N];
    void Getcg(int u,int sz,int &cg){  
        uint flag(1);  
        siz[u]=1;  
        Rep(i,u)  
            if(!p[i]&&fa[u]!=v){  
                fa[v]=u,  
                Getcg(v,sz,cg),siz[u]+=siz[v];  
                if (siz[v]>sz>>1)flag=0;  
            }  
        if(sz-siz[u]>sz>>1)flag=0;  
        if(flag)cg=u;  
    }
    void dfs1(int u,ll d){  
        dis[u]=d;  
        Rep(i,u)  
            if (!p[i]&&fa[u]!=v)  
                fa[v]=u,dfs1(v,(dis[v]=d+w[i]));  
    }
    int top;
	ll ret;
	ll s[N];  
    void dfs2(int u){  
        s[++top]=dis[u];  
        Rep(i,u)  
            if (!p[i]&&fa[u]!=v)  
                dfs2(v);  
    }
    int calc(int u){  
        top=ret=0;  
        dfs2(u);  
        sort(s+1,s+top+1);  
        for(int i=1,j=top;i<=top;i++){  
            for(;j&&s[i]+s[j]>k*2;j--);  
            ret += j;  
        }  
        return ret;  
    }
	ll ans;
    void Tree_Divide(int rt,int sz){  
        int cg;  
        fa[rt]=0;  
        Getcg(rt,sz,cg);  
        siz[fa[cg]]=sz-siz[cg];  
        fa[cg]=0;  
        dfs1(cg,0);   
        ans+=calc(cg) - 1;  
        Rep(i,cg)  
            if (!p[i])ans-=calc(v);  
        Rep(i,cg)  
            if (!p[i])p[i]=p[i^1]=1,Tree_Divide(v,siz[v]);   
    }
	void solve(){
		ans = 0;
		Tree_Divide(1, n);
		ans = ans / 2 % Mod;
		For(i, 1, m)ans = ans * i % Mod;
		printf("%lld\n", ans);
	}
}
void solve(){
	if(n > 20){
		if(m == 2)BF2::solve();
	}else {
		BF1::solve();
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
