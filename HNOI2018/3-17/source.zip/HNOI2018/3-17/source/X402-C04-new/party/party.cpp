#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

#define debug(...) fprintf(stderr,__VA_ARGS__)
typedef long long ll;
const int N=1e5+9;
const int M=22;
const int md=998244353;

ll ans;
int n,m,k;
int f[M][M],deg[N],Inf;
int to[N<<1],nxt[N<<1],w[N<<1],beg[N],tot=1;
ll fac[N],inv[N];

inline void chkmin(int &a,int b){if(a>b)a=b;}
inline void chkmax(int &a,int b){if(a<b)a=b;}

inline void add(int u,int v,int c)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	w[tot]=c;
	beg[u]=tot;
	deg[v]++;
}

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}


inline void init()
{
	fac[0]=1;
	for(ll i=1;i<N;i++)
		fac[i]=fac[i-1]*i%md;
	inv[N-1]=qpow(fac[N-1],md-2);
	for(ll i=N-1;i>=1;i--)
		inv[i-1]=inv[i]*i%md;
}

inline ll c(ll a,ll b)
{
	return fac[a]*inv[b]%md*inv[a-b]%md;
}

namespace cd
{
	int siz[N];ll bit[N];
	int id[N],ed[N],seg[N],dep[N],dfn;
	bool ban[N];

	inline void modify(int x,int v)
	{
		for(int i=x;i<=k*2;i+=i&-i)
			(bit[i]+=v)%=md;
	}

	inline ll query(int x)
	{
		ll ret=0;
		for(int i=x;i;i-=i&-i)
			(ret+=bit[i])%=md;
		return ret;
	}

	inline int getrt(int u,int fa,int &rt,int tsiz)
	{
		int sz=1,mx=0;
		for(int i=beg[u];i;i=nxt[i])
			if(!ban[i] && to[i]!=fa)
			{
				chkmax(mx,siz[i]=getrt(to[i],u,rt,tsiz));
				sz+=siz[i];siz[i^1]=tsiz-siz[i];
			}
		chkmax(mx,tsiz-sz);
		if((mx<<1)<=tsiz)rt=u;
		return sz;
	}

	inline void dfs_pre(int u,int fa,int dis)
	{
		seg[id[u]=++dfn]=u;
		dep[u]=dis;
		for(int i=beg[u];i;i=nxt[i])
			if(!ban[i] && to[i]!=fa)
				dfs_pre(to[i],u,dis+1);
		ed[u]=dfn;
	}

	inline void work(int u,int tsiz)
	{
		int rt;
		getrt(u,0,rt,tsiz);
		dfs_pre(rt,0,dfn=0);

		for(int i=beg[rt];i;i=nxt[i])
			if(!ban[i])
			{
				for(int j=id[to[i]];j<=ed[to[i]];j++)
					if(dep[seg[j]]<=k*2)
						(ans+=query(k*2-dep[seg[j]])+(dep[seg[j]]<=k*2))%=md;
				for(int j=id[to[i]];j<=ed[to[i]];j++)
					if(dep[seg[j]]<=k*2)
						modify(dep[seg[j]],1);
			}

		for(int i=beg[rt];i;i=nxt[i])
			if(!ban[i])
				for(int j=id[to[i]];j<=ed[to[i]];j++)
					if(dep[seg[j]]<=k*2)
						modify(dep[seg[j]],-1);

		for(int i=beg[rt];i;i=nxt[i])
			if(!ban[i])
			{
				ban[i]=ban[i^1]=1;
				work(to[i],siz[i]);
			}
	}

	int mina()
	{
		work(1,n);
		printf("%lld\n",ans*2ll%md);
		return 0;
	}
}

namespace nsqr
{
	const int P=5009;
	const int K=23;
	
	map<ll,ll> g[P];
	map<ll,int> ha;int htop;
	set<ll> exi;

	int id[N],ed[N],seg[N],dfn;
	ll bit[P*P],dis[N],rk[P*P];
	int fa[N][K],dep[N];

	inline void modify(int x,ll v)
	{
		for(int i=x;i<=htop;i+=i&-i)
			(bit[i]+=v)%=md;
	}
	inline ll query(int x)
	{
		ll ret=0;
		for(int i=x;i;i-=i&-i)
			(ret+=bit[i])%=md;
		return ret;
	}

	inline void dfs_pre(int u)
	{
		seg[id[u]=++dfn]=u;
		for(int i=beg[u];i;i=nxt[i])
			if(to[i]!=fa[u][0])
			{
				dis[to[i]]=dis[u]+w[i];
				dep[to[i]]=dep[u]+1;
				fa[to[i]][0]=u;
				for(int j=1;j<K;j++)
					fa[to[i]][j]=fa[fa[to[i]][j-1]][j-1];
				dfs_pre(to[i]);
			}
		ed[u]=dfn;
	}

	inline int lca(int a,int b)
	{
		if(dep[a]>dep[b])swap(a,b);
		for(int i=K-1;i;i--)
			if(dep[fa[b][i]]>=dep[a])
				b=fa[b][i];
		if(a==b)return a;
		for(int i=K-1;i;i--)
			if(fa[b][i]!=fa[a][i])
				a=fa[a][i],b=fa[b][i];
		return fa[a][0];
	}
	
	int mina()
	{
		init();
		dfs_pre(dep[1]=1);
		for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++)
				ha[dis[i]+dis[j]-2*dis[lca(i,j)]];
		for(map<ll,int>::iterator it=ha.begin();it!=ha.end();it++)
			rk[(*it).second=++htop]=(*it).first;
		printf("%lld\n",ans);
		return 0;
	}
}


int main()
{
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);

	n=read();m=read();k=read();
	memset(f,127,sizeof(f));
	Inf=f[0][0];bool fl=(m==2);
	for(int i=1,u,v,c;i<n;i++)
	{
		u=read();v=read();
		f[u][v]=f[v][u]=c=read();
		add(u,v,c);add(v,u,c);
		if(c!=1)fl=0;
	}

	if(fl)return cd::mina();

	for(int i=1;i<=n;i++)
		f[i][i]=0;
	for(int l=1;l<=n;l++)
		for(int i=1;i<=n;i++)
			if(f[i][l]!=Inf)
				for(int j=1;j<=n;j++)
					if(f[l][j]!=Inf)
						chkmin(f[i][j],f[i][l]+f[l][j]);

	ans=0;
	ll fac=1;
	for(int i=2;i<=m;i++)
		fac=fac*(ll)i%md;
	for(int i=(1<<n)-1;~i;i--)
		if(__builtin_popcount(i)==m)
		{
			bool flag=0;
			for(int j=1;j<=n && !flag;j++)
			{
				for(int l=1;l<=n;l++)
					if((i>>(l-1)&1) && f[l][j]>k)
						goto hell;
				flag=1;
				hell:;
			}

			if(flag)
			{
				ans+=fac;
				if(ans>=md)
					ans-=md;
			}
		}

	printf("%lld\n",ans);
	return 0;
}
