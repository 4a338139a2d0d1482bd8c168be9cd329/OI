#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9') {if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int maxm = 2010;

const int maxnm = 2000;

const int mod = 998244353;

int n, a[maxn];

void Get() {
	n = read();
	For(i, 1, n) a[i] = read();
}

int f[maxn], dp[maxm][maxm];

void pre_work() {
	dp[0][0] = 1;
	dp[1][0] = 1;

	For(i, 2, maxnm) {
		For(j, 0, i) {
			if(i == j) {
				dp[i][j] = 1ll * dp[i-1][j-2] * (i-1) % mod;
			}
			else{
				dp[i][j] = 1ll * (i-j) * dp[i-1][j] % mod;
				if(j) (dp[i][j] += 1ll * j * dp[i-1][j-1] % mod) %= mod;
			}
		}
	}
}

int vis[maxn];

void solve() {
	pre_work();
	For(i, 1, n) vis[a[i]] = 1;

	int cnt = 0, tot = 0;
	For(i, 1, n) {
		if(a[i] == 0) ++ tot;
		if(a[i] == 0 && !vis[i]) {
			++ cnt;
		}
	}

	printf("%d\n", dp[tot][cnt]);
}

int main() {

	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	Get();
	solve();

	return 0;
}
