#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9') {if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int inf = 1e9 + 7;

const int maxn = 400010;

const int mod = 998244353;

int n, m, K, Begin[maxn], to[maxn], e, Next[maxn], w[maxn];

void add(int x,int y,int z) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
	w[e] = z;
}

void Get() {
	n = read(), m = read(), K = read();
	For(i, 2, n) {
		int x = read(), y = read(), z = read();
		add(x, y, z), add(y, x, z);
	}
}

int vis[maxn], Size[maxn], root, Max[maxn], Min;

void get_size(int h,int father) {
	Size[h] = 1;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father || vis[v]) continue;

		get_size(v, h);
		Size[h] += Size[v];
	}
}

void find_root(int h,int father,int tmp) {
	Max[h] = 0;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father || vis[v]) continue;

		find_root(v, h, tmp);
		Max[h] = max(Max[h], Size[v]);
	}

	Max[h] = max(Max[h], tmp - Size[h]);
	if(Max[h] < Min) Min = Max[h], root = h;
}

int max_dis = 0, tong[maxn];

ll Ans;

void dfs_stack(int h,int father,int dist) {
	++ tong[dist];
	max_dis = max(max_dis, dist);

	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father || vis[v]) continue;

		dfs_stack(v, h, dist + w[i]);
	}
}

void get_presum() {
	For(i, 1, max_dis) tong[i] += tong[i-1];
}

void dfs_calc(int h,int father,int dist,int tp) {
	if(K*2-dist >= 0) Ans += tong[min(max_dis, K*2-dist)] * tp;
	for(int i = Begin[h]; i; i = Next[i]) {
		int v = to[i];
		if(v == father || vis[v]) continue;

		dfs_calc(v, h, dist + w[i], tp);
	}
}

void Init() {
	For(i, 0, max_dis) tong[i] = 0;
}

void dfs_apart(int h) {
	max_dis = 0;
	vis[h] = 1;

	dfs_stack(h, -1, 0);
	get_presum();
	-- Ans;
	dfs_calc(h, -1, 0, 1);
	Init();

	for(int i = Begin[h]; i; i = Next[i]) {
		int v = to[i];
		if(vis[v]) continue;

		dfs_stack(v, h, w[i]);
		get_presum();
		dfs_calc(v, h, w[i], -1);
		Init();
	}

	for(int i = Begin[h];i ; i = Next[i]) {
		int v = to[i];
		if(vis[v]) continue;

		root = v, Min = inf;
		get_size(v, -1);
		find_root(v, -1, Size[v]);
		dfs_apart(root);
	}
}

void solve() {
	root = 1; Min = inf;
	get_size(1, -1);
	find_root(1, -1, Size[1]);
	dfs_apart(root);
	printf("%lld\n", Ans % mod);
}

int main() {
	
	freopen("party.in", "r", stdin);
	freopen("party.out", "w", stdout);

	Get();
	solve();

	return 0;
}
