#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )

#define For(i, a, b) for(ll i = (a);i <= (b); ++i)
#define rep(i, a, b) for(ll i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

ll read() {
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9') {if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const ll inf = 1e9 + 7;

const ll maxn = 200010;

const ll mod = 998244353;

ll gcd(ll x,ll y){return !y ? x : gcd(y, x%y);}

ll n, m, a[maxn], Max = 0;

void Get() {
	n = read(), m = read();
	For(i, 1, n) a[i] = read();
}

void solve() {
	ll Ans = a[1];
	For(i, 2, n) Ans = gcd(Ans, a[i]);
	if(Ans <= m && Ans >= 1) printf("%lld %lld\n", Ans, Ans);
	else printf("%lld %lld\n", Ans % m + 1, Ans % m + 1);
}

int main() {
	
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);

	ll __ = read();
	ll _ = read();
	while(_ --){
		Get();
		solve();
	}

	return 0;
}
