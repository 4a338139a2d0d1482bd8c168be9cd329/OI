#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=998244353;
int n, m, k;
vector<int> g[maxn], w[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

ll dis[maxn], fac; int use[maxn];
void dfs(int x,int fa=0){
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa) continue;
		dis[v]=dis[x]+w[x][i]; dfs(v,x);
	}
}
bool check(int x){
	dis[x]=0, dfs(x);
	for(int i=1;i<=n;i++) if(use[i] && dis[i]>k) return false;
	return true;
}
void solve1(){
	fac=1;
	for(int i=1;i<=m;i++) fac=fac*i%mod;
	int ret=0;
	for(int i=0;i<(1<<n);i++){
		int tot=0;
		for(int j=1;j<=n;j++) if(i & (1<<(j-1))) tot++, use[j]=1; else use[j]=0;
		if(tot!=m) continue;
		int f=0;
		for(int j=1;j<=n;j++) if(check(j)){ f=1; break; }
		if(f){
			// for(int j=1;j<=n;j++) if(use[j]) printf("%d ", j); puts("");
			ret++;
		}
	}
	printf("%lld\n", fac*ret%mod);
}

ll ans;
int cnt, dfn[maxn], dep[maxn], e, st[maxn], ed[maxn], id[maxn];
int lc[maxn*30], rc[maxn*30], sum[maxn*30], root[maxn];
void modify(int& o,int x,int l,int r,int pos){
	o=++e; lc[o]=lc[x], rc[o]=rc[x], sum[o]=sum[x]+1;
	// printf("%d %d %d %d %d\n", o, l, r, lc[o], rc[o]);
	if(l==r) return;
	int mid=(l+r)>>1;
	if(pos<=mid) modify(lc[o],lc[x],l,mid,pos); else modify(rc[o],rc[x],mid+1,r,pos);
}
int query(int x,int y,int l,int r,int ql,int qr){
	// cerr<<x<<' '<<y<<endl;
	if(ql<=l && qr>=r){
		// printf("%d %d\n", sum[x], sum[y]);
		return sum[y]-sum[x];
	}
	int mid=(l+r)>>1, ret=0;
	if(ql<=mid) ret=query(lc[x],lc[y],l,mid,ql,qr); if(qr>mid) ret+=query(rc[x],rc[y],mid+1,r,ql,qr);
	return ret;
}
void DFS(int x,int fa=0){
	dfn[x]=++cnt; id[cnt]=x; st[x]=cnt;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa) continue;
		dep[v]=dep[x]+1, DFS(v, x);
	}
	ed[x]=cnt;
}
void solve(){
	dep[1]=1, DFS(1);
	// for(int i=1;i<=n;i++) printf("%d ", dep[i]); puts("");
	for(int i=1;i<=cnt;i++){
		modify(root[i],root[i-1],1,n,dep[ id[i] ]);
	}
	for(int i=1;i<=cnt;i++){
		// printf("%d\n", query(root[ st[i]-1 ],root[ ed[i] ],1,n,dep[ id[i] ]+1, min(dep[ id[i] ]+k*2,n)));
		(ans+=query(root[ st[i]-1 ],root[ ed[i] ],1,n,dep[ id[i] ]+1, min(dep[ id[i] ]+k*2,n)))%=mod;
	}
	printf("%lld\n", ans*2%mod);
}

int main(){
	freopen("party.in","r",stdin),freopen("party.out","w",stdout);

	read(n), read(m), read(k);
	int u, v, z;
	for(int i=1;i<n;i++){
		read(u), read(v), read(z);
		g[u].push_back(v), w[u].push_back(z);
		g[v].push_back(u), w[v].push_back(z);
	}
	if(n<=20){ solve1(); return 0; }
	solve();
	return 0;
}
