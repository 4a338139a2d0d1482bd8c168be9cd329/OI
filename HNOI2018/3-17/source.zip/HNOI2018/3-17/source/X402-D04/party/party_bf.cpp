#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=998244353;
int n, m, k;
vector<int> g[maxn], w[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

ll dis[maxn], fac; int use[maxn];
void dfs(int x,int fa=0){
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa) continue;
		dis[v]=dis[x]+w[x][i]; dfs(v,x);
	}
}
bool check(int x){
	dis[x]=0, dfs(x);
	for(int i=1;i<=n;i++) if(use[i] && dis[i]>k) return false;
	return true;
}
void solve1(){
	fac=1;
	for(int i=1;i<=m;i++) fac=fac*i%mod;
	int ret=0;
	for(int i=0;i<(1<<n);i++){
		int tot=0;
		for(int j=1;j<=n;j++) if(i & (1<<(j-1))) tot++, use[j]=1; else use[j]=0;
		if(tot!=m) continue;
		int f=0;
		for(int j=1;j<=n;j++) if(check(j)){ f=1; break; }
		if(f){
			// for(int j=1;j<=n;j++) if(use[j]) printf("%d ", j); puts("");
			ret++;
		}
	}
	printf("%lld\n", fac*ret%mod);
}

int main(){
	freopen("party.in","r",stdin),freopen("party.out","w",stdout);

	read(n), read(m), read(k);
	int u, v, z;
	for(int i=1;i<n;i++){
		read(u), read(v), read(z);
		g[u].push_back(v), w[u].push_back(z);
		g[v].push_back(u), w[v].push_back(z);
	}
	if(n<=20){
		solve1(); return 0;
	}
	return 0;
}
