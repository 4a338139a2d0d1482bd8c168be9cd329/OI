#include<bits/stdc++.h>
using namespace std;

const int maxn=1000010;
int n;
int p[maxn];

int main(){
	freopen("permutation.in","w",stdout);

	srand(time(0));
	printf("%d\n", n=10);
	for(int i=1;i<=n;i++) p[i]=i;
	random_shuffle(p+1,p+1+n);
	for(int i=1;i<n;i++) if(p[i]==i){
		swap(p[i],p[i+1]);
	}
	if(p[n]==n) swap(p[n], p[4]);
	for(int i=1;i<=n;i++){
		int t=rand()%2;
		if(t) printf("%d ", p[i]); else printf("0 ");
	}
	return 0;
}
