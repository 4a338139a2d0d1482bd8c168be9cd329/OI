#include<bits/stdc++.h>
using namespace std;

const int maxn=1000010;
int n;
int a[maxn], p[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

bool check(){
	for(int i=1;i<=n;i++) if(a[i] && p[i]!=a[i]) return false;
	for(int i=1;i<=n;i++) if(p[i]==i) return false;
	return true;
}
void solve(){
	int tot=1, ans=0;
	for(int i=1;i<=n;i++) p[i]=i, tot*=i;
	while(tot--){
		if(check()) ans++;
		next_permutation(p+1,p+1+n);
	}
	printf("%d\n", ans);
}

int main(){
	freopen("permutation.in","r",stdin),freopen("permutation.ans","w",stdout);

	read(n);
	for(int i=1;i<=n;i++) read(a[i]);
	solve();
	return 0;
}
