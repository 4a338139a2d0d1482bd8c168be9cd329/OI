#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1000010;
const int mod=998244353;
int n;
int a[maxn], p[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

bool check(){
	for(int i=1;i<=n;i++) if(a[i] && p[i]!=a[i]) return false;
	for(int i=1;i<=n;i++) if(p[i]==i) return false;
	return true;
}
void solve(){
	int tot=1, ans=0;
	for(int i=1;i<=n;i++) p[i]=i, tot*=i;
	while(tot--){
		if(check()) ans++;
		next_permutation(p+1,p+1+n);
	}
	printf("%d\n", ans);
}

int fa[maxn]; ll f[maxn];
int find(int x){ return x==fa[x] ? x : fa[x]=find(fa[x]); }

int cnt, tot, vis[maxn], iscircle, size[maxn];
void dfs(int x){
	// printf("%d %d\n", x, a[x]);
	if(vis[x]){ iscircle=1; return; }
	vis[x]=1; size[x]=1;
	if(a[x]) dfs(a[x]), size[x]+=size[ a[x] ];
}
ll inv(int x){ return Pow(x,mod-2); }

ll ans;

int main(){
	freopen("permutation.in","r",stdin),freopen("permutation.out","w",stdout);

	read(n);
	for(int i=1;i<=n;i++) read(a[i]);
	//if(n<=10){ solve(); return 0; }
	for(int i=1;i<=n;i++) fa[i]=i;
	f[1]=0, f[2]=1;
	for(int i=3;i<=n;i++) f[i]=1ll*(i-1)*(f[i-1]+f[i-2])%mod;
	// for(int i=1;i<=n;i++) printf("%lld ", f[i]); puts("");
	for(int i=1;i<=n;i++) if(a[i]){
		iscircle=0, dfs(i); 
		if(!iscircle) cnt++;
	}
	tot=cnt;
	for(int i=1;i<=n;i++) if(!vis[i]) tot++;
	printf("%d %d\n", tot, cnt);
	ll c=1;
	for(int i=0;i<=cnt;i++){
		(ans+=c*f[tot-i]%mod)%=mod;
		c=c*(cnt-i)%mod*inv(i+1)%mod;
	}
	// cerr<<ans<<endl;
	printf("%lld\n", ans);
	return 0;
}
