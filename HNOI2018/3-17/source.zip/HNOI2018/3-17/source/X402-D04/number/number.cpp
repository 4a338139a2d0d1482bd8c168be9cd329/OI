#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=5010;
int n, m;
ll a[maxn], sum, ans, sum1, sum2, ans1, ans2;

bool pd(int x){
	for(int i=1;i<=n;i++) if(a[i]%x) return false;
	return true;
}
void solve1(){
	int T;
	scanf("%d", &T);
	while(T--){
		sum=0;
		scanf("%d%d", &n, &m);
		for(int i=1;i<=n;i++) scanf("%lld", &a[i]);
		for(int i=1;i<=n;i++) sum+=a[i]/n;
		// printf("%lld\n", sum);
		int tot=(int)((1.0*m/2)+0.5);
		ans=(int)(1.0*sum/(m/2)+0.5);
		for(int i=0;i<=100;i++){
			if(pd(ans-i)){ ans-=i; break; }
			if(pd(ans+i)){ ans+=i; break; }
		}
		printf("%lld %lld\n", ans, ans);
	}
}
bool calc(int x){
	int ret=0;
	for(int i=1;i<=n;i++) if(a[i]%x==0) ret++;
	if(ret>=(int)(0.40*n)) return true;
	return false;
}
void solve2(){
	int T;
	scanf("%d", &T);
	while(T--){
		sum1=sum2=0;
		scanf("%d%d", &n, &m);
		for(int i=1;i<=n;i++) scanf("%lld", &a[i]);
		int t;
		int tot=(int)((1.0*n/2)+0.5);
		for(int i=1;i<=n;i++){
			t=rand()&1;
			if(t) sum1+=a[i]/tot; else sum2+=a[i]/tot;
		}
		tot=(int)((1.0*m/2)+0.5);
		ans1=(int)(1.0*sum1/tot+0.5); ans2=(int)(1.0*sum2/tot+0.5);
		if(ans1>ans2) swap(ans1, ans2);
		// printf("%lld %lld\n", ans1, ans2);
		int r, del;
		r=rand()%max(1,(min(50,(int)(0.005*m))))+2, del=rand()%max(1,(min(10,(int)(0.0005*m)))+1);
		// printf("%d %d\n", r, del);
		for(int i=max(1ll,ans1-r-del);i<=min(1ll*m, ans1+r-del);i++) if(calc(i)){ ans1=i; break; }
		r=rand()%max(1,(min(50,(int)(0.005*m))))+2; del=rand()%max(1,(min(10,(int)(0.0005*m))))+1;
		// printf("%lld - %lld\n", ans2+r, ans2-r);
		for(int i=min(1ll*m,ans2+r+del);i>=min(1ll, ans2-r+del);i--) if(calc(i)){ ans2=i; break; }
		printf("%lld %lld\n", ans1, ans2);
	}
}

int main(){
	freopen("number.in","r",stdin),freopen("number.out","w",stdout);

	srand(time(0));
	int T;
	scanf("%d", &T);
	if(T==1){ solve1(); return 0; }
	else{ solve2(); return 0; } 
	return 0;
}
