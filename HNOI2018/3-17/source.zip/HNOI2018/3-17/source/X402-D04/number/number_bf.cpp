#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=5010;
int n, m;
ll a[maxn], sum, ans;

int main(){
	freopen("number.in","r",stdin),freopen("number.out","w",stdout);

	int T;
	scanf("%d", &T);
	scanf("%d", &T);
	while(T--){
		sum=0;
		scanf("%d%d", &n, &m);
		for(int i=1;i<=n;i++) scanf("%lld", &a[i]);
		for(int i=1;i<=n;i++) sum+=a[i]/n;
		// printf("%lld\n", sum);
		ans=(int)(1.0*sum/(m/2)+0.5);
		printf("%lld %lld\n", ans, ans);
	}
	return 0;
}
