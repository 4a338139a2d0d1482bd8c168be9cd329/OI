#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int T,x,n,m,ans;
	scanf("%d",&T);
	scanf("%d",&T);
	while (T--) {
		scanf("%d%d%d",&n,&m,&ans);
		for (int i = 1;i < n;i++) scanf("%d",&x),ans = __gcd(ans,x);
		printf("%d %d\n",ans,ans);
	}
	return 0;
}
