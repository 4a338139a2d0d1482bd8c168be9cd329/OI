#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;
FILE *ans=fopen("number.ans","w");

typedef long long ll;

void work()
{
	int n=5000,m=1000000000;
	printf("%d %d\n",n,m);
	ll a=rand()%m+1,b=rand()%m+1;
//	ll a=1,b=2;
	if(a>b)std::swap(a,b);
	for(int i=1;i<=n;i++)
		if(rand()%50)printf("%lld ",a*(rand()%m+1));
		else printf("%lld ",b*(rand()%m+1));

	fprintf(ans,"%lld %lld\n",a,b);
}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("number.in","w",stdout);//look at here

	int type=2333,T=300;
	printf("%d\n%d\n",type,T);

	while(T--)work();

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());

	fprintf(stderr,"cost = %lf\n",(double)clock()/CLOCKS_PER_SEC);

	return 0;
}
