#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<cstdlib>

template<typename T>T read()
{
	T x=0;char c=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	return x;
}

typedef long long ll;
const int N=5010;
ll gcd(ll a,ll b){return b?gcd(b,a%b):a;}

namespace score
{
	ll s[N];
	int n,m;
	void solve()
	{
		n=read<int>(),m=read<int>();
		for(int i=1;i<=n;i++)s[i]=read<ll>();
		ll ans=s[1];
		for(int i=2;i<=n;i++)
			ans=gcd(ans,s[i]);
		printf("%lld %lld\n",ans,ans);
	}
}

namespace LuanGao
{
#define x first
#define y second
	typedef std::pair<ll,ll> pii;

	pii add(pii A,pii B)
	{
		if(A.x<0)return B;
		return pii(std::max(A.x,B.x),gcd(A.y,B.y));
	}

	ll s[N];
	pii t[N];
	int n,m,tot,dtot;
	int a,b;

	void work()
	{
		static bool flag=0;

		int ind;
		if(flag)ind=rand()%tot+1,flag=0;
		else ind=tot;

		pii res=pii(-1,-1);

		int tmp=tot;

		dtot=0;
		for(int i=1;i<=tot;i++)
			if(i!=ind && gcd(t[ind].y,t[i].y)<t[ind].x)res=add(res,t[i]);
			else t[++dtot]=t[i];
		tot=dtot;

		if(res.x>=0)t[++tot]=res;

		if(tot==tmp)flag=1;
	}

	void fk()
	{
		int ind=rand()%tot+1;
		pii res=t[ind];

		dtot=0;
		for(int i=1;i<=tot;i++)
		{

			if(i!=ind && gcd(t[i].y,res.y)>=res.x)
				res=add(t[i],res);
			else if(i!=ind)t[++dtot]=t[i];

		}
		tot=dtot;

		t[++tot]=res;
	}

	bool check()
	{
		for(int i=1;i<=n;i++)
		{
			if(s[i]%a==0 && s[i]/a<=m)continue;
			if(s[i]%b==0 && s[i]/b<=m)continue;
			return 0;
		}
		return 1;
	}

#define div(x) ((x)/m+((x)%m!=0))

	void solve()
	{
		n=read<int>(),m=read<int>();

		for(int i=1;i<=n;i++)
		{
			s[i]=read<ll>();
			t[i]=pii(div(s[i]),s[i]);
		}
		std::sort(t+1,t+n+1);
		tot=n;

		int cnt=0;
		while(tot>2)
		{
			work();
			cnt++;
			if(cnt>10)fk();
//			fprintf(stderr,"tot = %d\n",tot);
		}

		a=t[1].y,b=t[2].y;
		if(a>b)std::swap(a,b);

		if(!check())printf("1 2\n");
		else printf("%d %d\n",a,b);
	}
}

int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);

	srand('a'+'i'+'m'+'e'+'r');

	int type,T;
	scanf("%d",&type);

	for(scanf("%d",&T);T--;)
	{
		if(type!=1)LuanGao::solve();
		else score::solve();
//		fprintf(stderr,"T = %d\n",T);
	}

//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
