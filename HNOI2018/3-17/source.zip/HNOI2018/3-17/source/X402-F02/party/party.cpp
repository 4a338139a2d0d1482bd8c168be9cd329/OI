#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("party.in","r",stdin);
      freopen("party.out","w",stdout);
  #endif
}
int n,m,k;
int head[N],w[N<<1],nex[N<<1],to[N<<1],tt;
void add(int x,int y,int z)
{
	++tt;w[tt]=z,to[tt]=y,nex[tt]=head[x],head[x]=tt;
}
void input()
{
	int x,y,z;
	n=read<int>(),m=read<int>(),k=read<int>();
	For(i,2,n)
	{
		x=read<int>(),y=read<int>(),z=read<int>();
		add(x,y,z),add(y,x,z);
	}
}
const int mo=998244353;
namespace sub1
{
	int popcnt[1<<20],q[1<<20],top;
	ll dis[25][25],p[30];
	void dfs(int u,int pre,int start,ll W)
	{
		dis[start][u]=W;
		for(register int i=head[u];i;i=nex[i])
		{
			if(to[i]==pre)continue;
			dfs(to[i],u,start,W+w[i]);
		}
		p[1]=1;For(i,2,n)p[i]=p[i-1]<<1;
	}
	void init()
	{
		int s=(1<<n)-1;
		For(i,1,s)
		{
			popcnt[i]=popcnt[i>>1]+(i&1);
			if(popcnt[i]==m)q[++top]=i;
		}
		For(i,1,n)dfs(i,0,i,0);
	}
	int ans;
	int check(int d)
	{
		//cout<<d<<endl;
		int j;
		For(i,1,n)
		{
			for(j=1;j<=n;++j)if((d&p[j])&&dis[i][j]>k)break;
			if(j>n)return 1;
		}
		return 0;
	}
	void solve()
	{
		init();
		//For(i,1,n)For(j,1,n)printf("%lld%c",dis[i][j],j==n?'\n':' ');
		For(i,1,top)if(check(q[i]))++ans;
		For(i,2,m)ans=1ll*ans*i%mo;
		write(ans,'\n');
	}
}
namespace sub2
{
	int ans,f[N],size[N];
	int root,vis[N],sum;
	void get_root(int u,int pre)
	{
		size[u]=1,f[u]=0;
		for(register int i=head[u];i;i=nex[i])
		{
			if(to[i]^pre&&!vis[to[i]])
			{
				get_root(to[i],u);
				size[u]+=size[to[i]];
				cmax(f[u],size[to[i]]);
			}
		}
		cmax(f[u],sum-size[u]);
		if(f[u]<f[root])root=u;
	}
	void add(int &a,int b)
	{
		a+=b;if(a>=mo)a-=mo;
	}
	int q[N],top;
	void get_dep(int u,int pre,int W)
	{
		q[++top]=W;
		for(register int i=head[u];i;i=nex[i])
		{
			if(to[i]^pre&&!vis[to[i]])
			{
				get_dep(to[i],u,W+w[i]);
			}
		}
	}
	int cal(int u,int W)
	{
		int res=0;
		top=0;
		get_dep(u,u,W);
		sort(q+1,q+top+1);
		int r=top;
		For(i,1,top)
		{
			/*For(j,i+1,top)
			{
				if(q[i]+q[j]<=k)res++;
			}*/
			while(r&&q[i]+q[r]>k)--r;
			if(!r)break;
			if(r<i)add(res,r);
			else add(res,r-1);
		}
		return res;
	}
	void dfz(int u)
	{
		//cout<<u<<endl;
		vis[u]=1;add(ans,cal(u,0));
		for(register int i=head[u];i;i=nex[i])
		{
			if(vis[to[i]])continue;
			add(ans,mo-cal(to[i],w[i]));
			sum=size[to[i]];root=0;
			get_root(to[i],u);
			dfz(root);
		}
	}
	const int inf=0x3f3f3f3f;
	void solve()
	{
		sum=n,root=0,f[0]=inf;
		get_root(1,0);
		dfz(root);
		write(ans,'\n');
	}
}
void work()
{
	if(n<=20)
		sub1::solve();
	else 
		sub2::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
