#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=5e3+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("number.in","r",stdin);
      freopen("number.out","w",stdout);
  #endif
}
int n,m,p1,p2;
ll a[N],A,B,d;
void input()
{
	n=read<int>();m=read<int>();
	For(i,1,n)a[i]=read<ll>();
	d=a[1];For(i,2,n)d=__gcd(d,a[i]);
	For(i,1,n)a[i]/=d;
}
int get()
{
	return rand()%n+1;
}
ll q1[N],q2[N];
int top1,top2;
int check()
{
	For(i,1,top2)if(q2[i]/B>m)return 0;
	return 1;
}
void out()
{
	if(A>B)swap(A,B);
	write(A*d,' '),write(B*d,'\n');
}
void work()
{
	int i;
	for(i=1;i<=n;++i)if(a[i]>m)break;
	if(i>n){A=B=1;out();return;}
	For(k,1,5000)
	{
		do{p1=get(),p2=get();}while(p1==p2);
		A=__gcd(a[p1],a[p2]);
		top1=top2=0;
		For(i,1,n)
		{
			if(a[i]%A==0&&a[i]/A<=m)q1[++top1]=a[i];
			else q2[++top2]=a[i];
		}
		if(top1==n){B=A;out();return;}
		B=q2[1];For(i,2,top2)B=__gcd(B,q2[i]);
		if(check()){out();return;}
	}
}
int main()
{
	file();
	srand(19491001);
	int nouse=read<int>(),T=read<int>();
	while(T--)
	{
		input();
		work();
	}
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
