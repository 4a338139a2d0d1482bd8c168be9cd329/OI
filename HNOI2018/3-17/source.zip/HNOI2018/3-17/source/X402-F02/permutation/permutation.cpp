#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e6+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("permutation.in","r",stdin);
      freopen("permutation.out","w",stdout);
  #endif
}
const int mo=998244353;
int n,a[N],book[N],vis[N],sum;
void input()
{
	n=read<int>();
	For(i,1,n)
	{
		a[i]=read<int>();
		if(a[i])book[a[i]]=1,vis[i]=1,++sum;
	}
}
int C[2005][2005],cp[N],mc[N];
//inv[N];
/*ll power(ll x,int y)
{
	ll res=1;
	for(;y;x=x*x%mo,y>>=1)if(y&1)res=res*x%mo;
	return res;
}*/
void add(int &a,int b)
{
	a+=b;if(a>=mo)a-=mo;
}
void init(int maxn)
{
	cp[2]=1;For(i,3,maxn)cp[i]=1ll*(cp[i-1]+cp[i-2])*(i-1)%mo;
	mc[1]=1;For(i,2,maxn)mc[i]=1ll*mc[i-1]*i%mo;
	mc[0]=cp[0]=1;
	//inv[n]=power(mc[n],mo-2);
	//Fordown(i,n-1,1)inv[i]=1ll*inv[i+1]*(i+1)%mo;
	//inv[0]=1;
	For(i,1,maxn)C[i][0]=C[i][i]=1;
	For(i,2,maxn)For(j,1,i-1)C[i][j]=(C[i-1][j-1]+C[i-1][j])%mo;
}
int tot,num;
int dp[2005][2005];
int F(int a,int b)
{
	if(!b)return cp[a];
	if(!a)return mc[b];
	if(dp[a][b])return dp[a][b];
	int res=0,s=min(a,b);
	For(i,0,s)add(res,1ll*C[b][i]*C[a][i]%mo*F(a-i,i)%mo*mc[b]%mo);
	return dp[a][b]=res;
}
int ans;
void work()
{
	For(i,1,n)if(!book[i]&&vis[i])++num;
	tot+=n-sum-num;
	//cout<<tot<<' '<<num<<' '<<sum<<endl;
	init(max(tot,num));
	write(F(tot,num),'\n');
}
int main()
{
	file();
	input();
	work();
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
