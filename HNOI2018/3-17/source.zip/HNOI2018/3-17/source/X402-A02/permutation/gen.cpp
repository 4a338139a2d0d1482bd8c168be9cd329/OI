/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-03-17 10:00
#
# Filename: gen.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

bool f[20];

int main()
{
    freopen("permutation.in", "w", stdout);
    int n = 10;
    cout << n << endl;
    srand(time(0));
    REP(i, 1, 10)
    {
        int x = rand() % 10 + 1;
        int y = rand() % 3;
        if ( y == 0 ) 
        {
            while ( f[x] == true ) x = rand() % 10 + 1;
            cout << x << " ";
            f[x] = true;
        }
        else printf("0 ");
    }
    cout << endl;
    return 0;
}

