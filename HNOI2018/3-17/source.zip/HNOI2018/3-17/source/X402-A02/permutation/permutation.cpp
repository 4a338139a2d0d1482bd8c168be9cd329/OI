/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-03-17 08:29
#
# Filename: permutation.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 110;
const int Mod = 998244353;

int n, s[maxn], sum, ans;
bool f[maxn];

void dfs(int x)
{
    if ( x == sum + 1 ) 
    {
        ++ ans;
        ans %= Mod;
        return ;
    }
    REP(i, 1, n)
        if ( !f[i] && i != s[x] )  
        {
            f[i] = true;
            dfs(x + 1);
            f[i] = false;
        }
}

int main()
{
    freopen("permutation.in", "r", stdin);
    freopen("permutation.out", "w", stdout);
    cin >> n;
    REP(i, 1, n)
    {
        int x;
        scanf("%d", &x);
        if ( x == 0 ) s[++ sum] = i;
        else f[x] = true;
    }
    dfs(1);
    printf("%d\n", ans);
    return 0;
}

