#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e6+100;
const ll mod=998244353;
int n;
ll ans;
int a[maxn],c[maxn],b[maxn],p;
ll f[maxn];
ll jie[maxn],ny[maxn];
ll dp[2010][2010];
ll k[maxn];
ll ksm(ll x,int y)
{
	ll sum=1;
	while (y)
	{
		if (y&1) sum=sum*x%mod;
		y>>=1;
		x=x*x%mod;
	}
	return sum;
}
void dfs(int x)
{
	if (x==n+1)
	{
		ans++;
		return;
	}
	if (a[x]!=0) dfs(x+1); else
	{
		for (int i=1;i<=n;i++)
		{
			if (!c[i]&&x!=i)
			{
				c[i]=1;
				dfs(x+1);
				c[i]=0;
			}
		}
	}
}
int N,M;
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++) a[i]=read(),c[a[i]]=1;
	if (n<=10)
	{
		dfs(1);
		printf("%lld\n",ans);
		return 0;
	}
	jie[0]=1;
	for (int i=1;i<=n;i++) jie[i]=jie[i-1]*i%mod;
	k[0]=1;k[1]=0;
	for (int i=1;i<=n;i++)
		k[i]=(i-1)*((k[i-1]+k[i-2])%mod)%mod;
	for (int i=1;i<=n;i++) if (a[i]==0) c[i]==0?N++:M++;
	for (int i=1;i<=N;i++) dp[i][0]=k[i];
	for (int i=1;i<=M;i++) dp[0][i]=jie[i];
	for (int i=1;i<=N;i++)
		for (int j=1;j<=M;j++)
		{
			dp[i][j]=i*dp[i-1][j]%mod+dp[i][j-1]*j%mod;
			if (dp[i][j]>=mod) dp[i][j]-=mod;
		}
	dp[N][M]%=mod;
	printf("%lld\n",dp[N][M]);
}
