#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e5+1000;
const ll mod=998244353;
int n,k,id,to[maxn<<1],ne[maxn<<1];
ll w[maxn<<1];
int vis[maxn],po[maxn],X,Y,Z,root,SZ;
ll deep[maxn];
int d0,size[maxn],son[maxn];
ll a[maxn],m;
ll ans;
inline void add(int x,int y,ll z)
{
    id++;to[id]=y;w[id]=z;ne[id]=po[x];po[x]=id;
}
void getroot(int x,int fa)
{
    son[x]=0;size[x]=1;
    for (int i=po[x];i;i=ne[i])
    {
        if (!vis[to[i]]&&to[i]!=fa)
        {
            getroot(to[i],x);
            size[x]+=size[to[i]];
            qmax(son[x],size[to[i]]);
        }
    }
    son[x]=max(son[x],SZ-size[x]);
    if (son[x]<son[root]||root==0) root=x;
}
void getdeep(int x,int fa)
{
    a[++d0]=deep[x];
    for (int i=po[x];i;i=ne[i])
    {
        if (!vis[to[i]]&&to[i]!=fa)
        {
            deep[to[i]]=deep[x]+w[i];
            getdeep(to[i],x);
        }
    }
}
ll cal(int x,int y)
{
    deep[x]=y;d0=0;ll ss=0;
    getdeep(x,0);
    sort(a+1,a+d0+1);
	ll l=1,r=d0;
	while (l<r)
	{
		if (a[r]+a[l]<=k) ss+=(r-l),l++; else r--;
	}
    return ss;
}
void solve(int x)
{
    ans+=cal(x,0);vis[x]=1;
	if (ans>=mod) ans-=mod;
    for (int i=po[x];i;i=ne[i])
    {
        if (!vis[to[i]])
        {
            ans-=cal(to[i],w[i]);
			if (ans<0) ans+=mod;
            root=0;SZ=size[to[i]];
            getroot(to[i],0);
            solve(root);
        }
    }
}
int dis[10][10];
void dfs(int x,int y,int fa)
{
	for (int i=po[x];i;i=ne[i])
	{
		if (to[i]!=fa) 
		{
			dis[y][to[i]]=w[i]+dis[y][x];
			dfs(to[i],y,x);
		}
	}
}
int d[40],cnt;
void Dfs(int x)
{
	if (n-x+1+cnt<m) return;
	if (cnt>m) return;
	if (x==n+1)
	{
		bool flag=false;
		for (int i=1;i<=n;i++)
		{
			bool f2=true;
			for (int j=1;j<=n;j++)
			{
				if (d[j]==1&&dis[i][j]>k)
				{
					f2=false;
					break;
				}
			}
			if (f2)
			{
				ans++;
//				printf("--%d\n",i);
				return;
			}
		}
//		printf("\n");
		return;
	}
	if (n-x+1+cnt==m)
	{
		d[x]=1;cnt++;
		Dfs(x+1);
		cnt--;
		return;
	}
	d[x]=0;
	Dfs(x+1);

	d[x]=1;cnt++;
	Dfs(x+1);cnt--;
}
signed main()
{
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
    n=read();m=read();k=read();
	if (m==2&&n>20)
	{
		k=k*2;
        ans=0;
        memset(vis,0,sizeof(vis));
        id=0;memset(po,0,sizeof(po));
        memset(size,0,sizeof(size));d0=0;
        for (int i=1;i<n;i++)
        {
            X=read();Y=read();Z=read();
            add(X,Y,Z);add(Y,X,Z);
        }
        SZ=n;
        getroot(1,0);
        solve(root);
		ans%=mod;
		ans=(ans+mod)%mod;
		ans=ans*2%mod;
//		ans=ans*(ans-1)%mod;
//		ans=(ans%mod+mod)%mod;
        printf("%lld\n",ans);
		return 0;
	}
	if (n<=20)
	{
		for (int i=1;i<n;i++)
		{
			X=read();Y=read();Z=read();
			add(X,Y,Z);
			add(Y,X,Z);
		}
		for (int i=1;i<=n;i++) dfs(i,i,0);
		Dfs(1);
		ll s=1;
		for (int i=1;i<=m;i++) s=s*i%mod;
		ans=ans*s%mod;
		printf("%lld\n",ans);
	}
}
