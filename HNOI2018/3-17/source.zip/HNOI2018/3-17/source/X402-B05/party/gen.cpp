#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
int n,m,k;
int a[100100],l,x,y;
int main()
{
#ifdef ylx
	freopen("party.in","w",stdout);
#endif
	srand(time(0));
	n=100000;
	m=2;
	k=2;
	printf("%d %d %d\n",n,m,k);
	a[1]=n;l=1;
	k=8e7;
	for (int i=1;i<n;i++)
	{
		x=a[rand()%l+1];
		a[++l]=i;
		y=rand()%k+1;
		printf("%d %d %d\n",x,i,1);
	}
	return 0;
}
