#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;
const int M = 200000;
const int mo = 998244353;

int st[N + 5], nxt[M + 5], to[M + 5], w[M + 5], e = 1;

inline void addedge(int x, int y, int z) {
    to[++ e] = y; nxt[e] = st[x]; st[x] = e; w[e] = z;
    to[++ e] = x; nxt[e] = st[y]; st[y] = e; w[e] = z;
}

int n, m, k;
ll dis[N + 5];
int fa[N + 5][20], dep[N + 5];

int lca(int u, int v) {
    if(dep[u] < dep[v]) std::swap(u, v);
    for(int i = 19; i >= 0; --i) 
        if(dep[fa[u][i]] >= dep[v]) 
            u = fa[u][i];
    if(u == v) return u;
    for(int i = 19; i >= 0; --i) 
        if(fa[u][i] != fa[v][i]) 
            u = fa[u][i], v = fa[v][i];
    return fa[u][0];
}

inline int get_dis(int u, int v) {
    return dis[u] + dis[v] - 2 * dis[lca(u, v)];
}

void dfs(int u, int f = 0, int l = 0) {
    fa[u][0] = f;
    dis[u] = dis[f] + l;
    dep[u] = dep[f] + 1;

    for(int i = 1; fa[u][i-1]; ++i) fa[u][i] = fa[fa[u][i-1]][i-1];

    for(int i = st[u]; i; i = nxt[i]) {
        int v = to[i];
        if(v == f) continue;

        dfs(v, u, w[i]);
    }
}

int ans;
bool vis[N + 5];
bool chk() {
    for(int s = 1; s <= n; ++s) {
        bool flag = true;
        for(int i = 1; i <= n; ++i) if(vis[i]) {
            flag &= (get_dis(i, s) <= k);
        }
        if(flag) return true;
    }
    return false;
}

void Dfs(int cur, int s) {
    if(s == m) {
        ans += chk();
        return;
    }
    if(cur == n+1) return;

    vis[cur] = 1;
    Dfs(cur + 1, s + 1);
    vis[cur] = 0;
    Dfs(cur + 1, s);
}

int main() {
    freopen("party.in", "r", stdin);
    freopen("party.out", "w", stdout);

    read(n), read(m), read(k);
    for(int i = 1; i < n; ++i) {
        static int x, y, z;
        read(x), read(y), read(z);
        addedge(x, y, z);
    }

    dfs(1);
    Dfs(1, 0);
    for(int i = 1; i <= m; ++i) ans = (ll) ans * i % mo;
    printf("%d\n", ans);

    return 0;
}
