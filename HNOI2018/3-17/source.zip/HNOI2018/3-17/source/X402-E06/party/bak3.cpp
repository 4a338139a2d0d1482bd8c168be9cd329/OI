#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;
const int M = 200000;
const int mo = 998244353;

int fpm(int x, int y) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1) 
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

int fac[N + 5], inv[N + 5];
inline int binom(int n, int k) {
    if(n < k || k < 0 || n < 0) return 0;
    return 1ll * fac[n] * inv[k] % mo * inv[n-k] % mo;
}

void init() {
    fac[0] = 1;
    for(int i = 1; i <= N; ++i) fac[i] = 1ll * fac[i-1] * i % mo;
    inv[N] = fpm(fac[N], mo - 2);
    for(int i = N; i >= 1; --i) inv[i-1] = 1ll * inv[i] * i % mo;
}

int sz[M + 5];
bool mark[M + 5];

int st[N + 5], nxt[M + 5], to[M + 5], w[M + 5], e = 1;

inline void addedge(int x, int y, int z) {
    to[++ e] = y; nxt[e] = st[x]; st[x] = e; w[e] = z;
    to[++ e] = x; nxt[e] = st[y]; st[y] = e; w[e] = z;
}

int pre_dfs(int u, int n, int& c, int f = 0) {
    int size = 1, flag = 1;
    for(int i = st[u]; i; i = nxt[i]) if(!mark[i]) {
        int v = to[i];
        if(v == f) continue;

        sz[i] = pre_dfs(v, n, c, u);
        sz[i ^ 1] = n - sz[i]; size += sz[i];
        flag &= ((sz[i] << 1) <= n);
    }
    if(flag &= ((size << 1) >= n)) c = u;
    return size;
}

vector<ll> len, del;

int tot[N + 5];
ll lw[N + 5][20];
int fa[N + 5][20], dep[N + 5];

int get_c(int u, int l) {
    for(int i = 19; i >= 0; --i) {
        if(fa[u][i] && lw[u][i] <= l) {
            l -= lw[u][i];
            u = fa[u][i];
        }
    }
    return u;
}

void df
    fa[u][0] = f;
    lw[u][0] = l;
    dep[u] = dep[f] + 1;

    for(int i = 1; fa[u][i-1]; ++i) {
        fa[u][i] = fa[fa[u][i-1]][i-1];
        lw[u][i] = lw[u][i-1] + lw[fa[u][i-1]][i-1];
    }

    for(int i = st[u]; i; i = nxt[i]) if(!mark[i]) {
        int v = to[i];
        if(v == f) continue;

        dfs(v, u, w[i]);
    }
}

void calc(int c) {

}

int n, m, k;

void solve(int rt, int size) {
    if(size == 1) return;

    int c = rt;
    pre_dfs(rt, size, c);

    calc(c, +1);
    for(int i = st[c]; i; i = nxt[i]) if(!mark[i]) 
        calc(to[i], -1);

    for(int i = st[c]; i; i = nxt[i]) if(!mark[i]) {
        mark[i] = mark[i ^ 1] = true;
        solve(to[i], sz[i]);
    }
}

int main() {
    freopen("party.in", "r", stdin);
    freopen("party.out", "w", stdout);

    init();
    read(n), read(m), read(k);
    for(int i = 1; i < n; ++i) {
        static int x, y, z;
        read(x), read(y), read(z);
        addedge(x, y, z);
    }

    solve(1, n);

    return 0;
}
