#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;

ll v[N + 5];
int T, t, n, m;

void solve1() {
    read(t);
    while(t--) {
        static ll x, y;
        read(n), read(m);

        read(x);
        for(int i = 1; i < n; ++i) {
            read(y);
            x = std::__gcd(x, y);
        }
        printf("%lld %lld\n", x, x);
    }
}

void solve2() {
    read(t);
    while(t--) {
        static ll x, tot = 0;
        read(n), read(m);

        tot = 0;
        for(int i = 1; i <= n; ++i) { read(v[i]); tot += (v[i] <= m); }

        if(tot >= n / 2) {
            ll a = 1, b = 0;
            for(int i = 1; i <= n; ++i) 
                if(v[i] > m) b = b ? std::__gcd(b, v[i]) : v[i];
            printf("%lld %lld\n", a, b);
        }

        x = v[1];
        for(int i = 2; i <= n; ++i) { x = std::__gcd(x, v[i]); }
        for(int i = 1; i <= n; ++i) v[i] /= x;

        ll a = v[1], b = 0;
        for(int i = 2; i <= n; ++i) {
            if(std::__gcd(v[i], a) == 1) {
                if(!b) b = v[i]; else b = std::__gcd(b, v[i]);
            } else {
                a = std::__gcd(v[i], a);
            }
        }

        if(a > b) std::swap(a, b);
        printf("%lld %lld\n", a*x, b*x);
    }
}

int main() {
    freopen("number.in", "r", stdin);
    freopen("number.out", "w", stdout);

    read(T);

    if(T == 1) 
        solve1();
    else 
        solve2();

    return 0;
}
