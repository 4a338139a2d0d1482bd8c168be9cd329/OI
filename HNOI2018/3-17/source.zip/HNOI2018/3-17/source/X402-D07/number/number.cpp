#include<bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(),(x).end()

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=5010;
const double omega=3.0;

typedef long long LL;
typedef pair<int,LL> PIL;

int n,m,lim;
LL a[maxn],A,B;

map<LL,int> book;
map<LL,int>::iterator it;

vector<PIL> t;

bool check(int p){
    for(int i=p+1;i<=lim;i++)
        if(t[i].second%t[p].second==0&&1.*t[p].first/t[i].first<omega) return 0;
    return 1;
}

int main(){
    freopen("number.in","r",stdin);
    freopen("number.out","w",stdout);
    srand(19260817);

    int _; scanf("%*d%d",&_);

    while(_--){
        read(n); read(m);
        for(int i=1;i<=n;i++) read(a[i]);

        book.clear(); t.clear();

        for(int i=1;i<=n*2;i++){
            int u=rand()%(n-1)+1,v=u+rand()%(n-u)+1;
            LL d=__gcd(a[u],a[v]);
            if(!book.count(d)) book[d]=1;
            else book[d]++;
        }

        for(it=book.begin();it!=book.end();++it) t.pb(mp(it->second,it->first));
        sort(ALL(t),greater<PIL>()); lim=min(SZ(t)-1,100);

        int cur=0;
        while(cur<lim&&!check(cur)) ++cur;

        A=t[cur].second; B=0;
        for(int i=1;i<=n;i++) if(a[i]%A!=0) B=!B?a[i]:__gcd(B,a[i]);

        if(!B) for(int i=1;i<=n;i++) if(a[i]/A>1ll*m) B=!B?a[i]:__gcd(B,a[i]);

        if(!B) B=A;

        if(A>B) swap(A,B);
        printf("%lld %lld\n",A,B);
    }

    return 0;
}
