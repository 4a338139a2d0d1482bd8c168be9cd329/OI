#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=1e6+10,mo=998244353;

int n,m,cnt,a[maxn];

bool book[maxn],vis[maxn];

int fac[maxn],ifac[maxn],ans;

void Add(int& x,int y){
    x+=y;
    if(x>=mo) x-=mo;
    if(x<0) x+=mo;
}

int C(int N,int M){
    return 1ll*fac[N]*ifac[M]%mo*ifac[N-M]%mo;
}

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

void init(){
    fac[0]=1;
    for(int i=1;i<=n;i++) fac[i]=1ll*fac[i-1]*i%mo;
    ifac[n]=fpm(fac[n],mo-2)%mo;
    for(int i=n-1;~i;i--) ifac[i]=1ll*ifac[i+1]*(i+1)%mo;
}

int main(){
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);

    cnt=read(n); init();

    for(int i=1;i<=n;i++){
        read(a[i]);
        if(a[i]) book[i]=vis[a[i]]=1,--cnt;
    }

    for(int i=1;i<=n;i++) if(!book[i]&&!vis[i]) ++m;

    for(int i=0;i<=m;i++) Add(ans,(i&1?-1ll:1ll)*C(m,i)*fac[cnt-i]%mo);

    printf("%d\n",ans);

    return 0;
}
