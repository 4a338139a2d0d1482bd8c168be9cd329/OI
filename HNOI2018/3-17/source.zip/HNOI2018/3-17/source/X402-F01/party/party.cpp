#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n,m,k;
int he[200005],to[200005],ne[200005],cost[200005],e;
int dis[105][105],ans;
int dep[100005];
int st[100005][20];
const int mod = 998244353;
void add(int x,int y,int c){
    to[++e]=y;
	ne[e]=he[x];
	he[x]=e;
	cost[e]=c;
}
void dfs(int tot,int x,int fa){
     for(int i=he[x];i;i=ne[i]){
	     int v=to[i];
		 if(v==fa)continue;
		 dis[tot][v]=dis[tot][x]+cost[i];
		 dfs(tot,v,x);
	 }
}
int liv[100005];
bool check(){
   F(i,1,n){
	   bool flag=1;
     F(j,1,m){
	    if(dis[i][liv[j]]>k){
		  flag=0;
		  break;
		}
	 }
	 if(flag==1)return 1;
   }
   return 0;
}
void Dfs(int x,int sum){
     if(x==n){
	   if(sum==m)ans=(ans+check())%mod;
		return ;
	 }
    if(sum==m){
		Dfs(x+1,sum);
	   return ;
	}
	else{
	  Dfs(x+1,sum);
	  liv[x]=sum+1;
	  Dfs(x+1,sum+1);
	  liv[x]=0;
	  return ;
	}
}
int f[100005];
int main () {
#ifndef ONLINE_JUDGE
freopen("party.in","r",stdin);
freopen("party.out","w",stdout);
#endif
    n=read();
	m=read();
	k=read();
	f[1]=1;
	F(i,2,n){
	f[i]=1ll*f[i-1]*i%mod;
	}
	bool flag=1;
	F(i,1,n-1){
	   int x=read(),y=read(),c=read();	   
	   add(x,y,c);
	   add(y,x,c);
	   if(c!=1)flag=0;
	}
	if(flag==1){
		subtask3();
	   return 0;
	}
    F(i,1,n){
	  dfs(i,i,0);  
	}
	Dfs(1,0);
	printf("%lld\n",1ll*ans*f[m]%mod);
    return 0;
}
