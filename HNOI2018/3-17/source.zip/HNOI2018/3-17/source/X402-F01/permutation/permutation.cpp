#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
long long n,ans;
int a[100005];
const int mod =998244353;
long long f[100005];
int used[100005];
void dfs(int x){
    if(x==n+1){
		ans=(ans+1)%mod;
	    return ;
	}
	if(a[x]){
		dfs(x+1);
	     return ;
	}
	F(i,1,n){
	   if(used[i]==0&&x!=i){
	      used[i]=1;
		  a[x]=i;
		  dfs(x+1);
		  used[i]=0;
		  a[x]=0;
	   }
	} 
}
long long qpow(long long x,long long y){
     long long res=1;
	 while(y){
	    if(y&1)res=res*x%mod;
		x=x*x%mod;
		y>>=1;
	 }
	 return res;
}
int b[100005],flag1[100005],flag2[100005],inv[100005],cnt,sum;
void solve(){
  F(i,1,n){
     a[i]=read();
	 if(a[i]==0){
	   b[++cnt]=i;
	   flag1[i]=1;
	 }
	 else used[a[i]]=1;
  }
  Set(a,0);
  F(i,1,n){
    if(!used[i]){
		a[++sum]=i;
	   flag2[i]=1; 
	}
  }
  f[0]=1;
  F(i,1,n){
     f[i]=f[i-1]*i%mod;
  }
  inv[n]=qpow(f[n],mod-2);
  f(i,n-1,0){
	  inv[i]=inv[i+1]*(i+1)%mod;
  }
    sum=0;
  F(i,1,n){
    if(flag1[i]&&flag2[i]){
	   ++sum;
	}
  }
  F(i,0,sum){
     ans=(ans+(i%2==1?-1:1)*(f[sum]*inv[i]%mod)*inv[sum-i]%mod*f[cnt-i]%mod)%mod;
  }
}
int main () {
#ifndef ONLINE_JUDGE
freopen("permutation.in","r",stdin);
freopen("permutation.out","w",stdout);
#endif
    n=read();
	if(n<=10){
		F(i,1,n){
		   a[i]=read();
		   used[a[i]]=1;
		}
		dfs(1);
	}
	else solve();
	printf("%lld\n",(ans+mod)%mod);
   return 0;
}
