#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline long long read() {
 long long x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n,m;
long long a[5005];
long long aa,bb;
long long gcd(long long x,long long y){
   if(y==0)return x;
   else return gcd(y,x%y);
}
int main () {
#ifndef ONLINE_JUDGE
freopen("number.in","r",stdin);
freopen("number.out","w",stdout);
#endif
  int opt=read();
  srand(19260817);
	int t=read();
	while(t--){
	   n=read();
	   m=read();
	   F(i,1,n){
	      a[i]=read();
	   }
	   long long totd=a[1];
	   F(i,2,n){
	      totd=gcd(totd,a[i]);
	   }
	  // cout<<totd<<endl;
	  // break;
	   F(i,1,n)a[i]=a[i]/totd;
      bool flag=1;
	  F(i,1,n)if(a[i]>m){
		  flag=0;
		  break;
	  }
	  if(flag){
	     printf("%lld %lld\n",totd,totd);
		 continue;
	  }
	  else{
	     while(1){
			 flag=1;
		     int x=rand()%n+1,y=rand()%n+1;
			 while(x==y)x=rand()%n+1;
              aa=gcd(a[x],a[y]);
			  if(aa*totd>m)continue;
			  bb=0;
			  F(i,1,n){
               if(a[i]%aa!=0||a[i]/aa>m){
			      if(bb==0)bb=a[i];
				  else bb=gcd(bb,a[i]);
			   }
              }
			  if(bb==0)bb=aa;
			  if(bb*totd>=m)continue;
			  F(i,1,n){
			     if(a[i]%bb!=0&&a[i]%aa!=0){
					  flag=0;
					 break;
				 }
                 else{
				    int xx=m+1,yy=m+1;
					if(a[i]%aa==0)xx=a[i]/aa;
					if(a[i]%bb==0)yy=a[i]/bb;
					if(xx>m&&yy>m){
					  flag=0;
					  break;
					}
				 }
			  }
			  if(flag){
				  if(aa>bb)swap(aa,bb);
				  printf("%lld %lld\n",aa*totd,bb*totd);
			      break;
			  }
		 }
	  }
	}
    return 0;
}
