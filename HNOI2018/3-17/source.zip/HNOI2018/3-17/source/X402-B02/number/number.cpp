#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
const int N=6000+10;
using namespace std;

map<int,int> mp;

int a[N],n,m,T,sub;
int fr,se;
vector<int> g;

namespace num{
	int gcd(int a,int b){return (!b)?a:gcd(b,a%b);}
	void solve(){
		
		srand(19260817);	
		scanf("%d%d",&sub,&T);
		while(T--){
			scanf("%d%d",&n,&m);
			mp.clear();
			for(int i=1; i<=n; ++i) scanf("%d",&a[i]);
			for(int i=1; i<=1000; ++i){
				int a1=a[rand()%n+1];
				int a2=a[rand()%n+1];
				g.pb(gcd(a1,a2));
				mp[gcd(a1,a2)]++;
				if(mp[gcd(a1,a2)]>mp[fr]){
					fr=gcd(a1,a2);
				}
			}

			mp.clear();
			for(int i=1; i<=1000; ++i){
				int a1=a[rand()%n+1];
				int a2=a[rand()%n+1];
				g.pb(gcd(a1,a2));
				if(gcd(a1,a2)==fr) continue;
				mp[gcd(a1,a2)]++;
				if(mp[gcd(a1,a2)]>mp[se]){
					se=gcd(a1,a2);
				}	
			}

			/*int ret=0,fr=0,se=0;
			for(int i=0; i<1000; ++i){
				++ret;
				for(int j=1; j<=n; ++j){
					if(g[j]!=1&&a[j]%g[i]==0) ++ret;
				}
				if(ret>(int)(n*0.46)){
					if(g[i]>fr) se=fr,fr=g[i];
					else if(g[i]>se) se=g[i];
				}
			}*/
			printf("%d %d\n",fr,fr);
		}
	}
}

int main(){
	int sub, T, o;
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	num::solve();
}
