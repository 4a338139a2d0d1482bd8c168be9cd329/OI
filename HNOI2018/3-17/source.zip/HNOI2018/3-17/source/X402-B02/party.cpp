#include<bits/stdc++.h>
#define pb push_back
#define ll long long
const int N=1e5+10;
const int mod=998244353;
using namespace std;

ll ans,rfac[N],dis[N],cnt,fac[N];
int bgn[N],w[N<<1],nxt[N<<1],sz[N<<1],to[N<<1];
int n,e,m,k,lim,hvsz=0x3f3f3f3f,hv;
bool vis[N];
vector<ll> vec;

inline void add(int x,int y,int z){
 	to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e; w[e]=z;
}

namespace party{
	void gtsz(int x,int f=0){
		sz[x]=1;
		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			if(to[i]==f) continue;
			sz[x]+=sz[to[i]];
		}
	}

	void gthv(int x,int f=0){
		int ret=lim-sz[x];
		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			if(to[i]==f) continue;
			ret=max(ret,sz[to[i]]);
			gthv(to[i],x);
		}
		if(ret<hvsz) hvsz=ret,hv=x;
	}

	void gtpb(int x,int f=0){
		vec.pb(dis[x]);
		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			if(to[i]==f) continue;
			gtpb(to[i],x);
		}
	}

	void gtds(int x,int f=0){
		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			if(to[i]==f) continue;
			dis[to[i]]=dis[x]+w[i];
			gtds(to[i],x);
		}
	}

	inline ll P(int x,int y){
		if(x<y)return 0;
		return fac[x]*rfac[x-y]%mod;
	}

	void cal(int c){
		int l=1,r=(int)vec.size();
		int ret=0;
		for(int j=l;j<=r;++j)
			if(vec[j-1]<=k) ++ret;
		if(c==1) ans+=P(ret,m),ans=(ans%mod+mod)%mod;
		if(c==-1) ans-=P(ret,m),ans=(ans%mod+mod)%mod;
	}

	ll fpm(ll x,ll y){
		 ll s=1;
		 while(y){
		 	if(y&1)s=s*x%mod;
			y>>=1;x=x*x%mod;
		 }
		 return s;
	}

	void solve(int x){
		vec.clear(); dis[x]=0;
		gtds(x,0); gtpb(x); cal(1);
		vis[x]=1;
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(vis[y]) continue; 
			vec.clear();
			gtds(to[i],0); gtpb(to[i]); cal(-1);
			hvsz=0x3f3f3f3f;
			gtsz(to[i],x); lim=sz[to[i]];
			gthv(to[i],x); 
			solve(to[i]);
			solve(hv);
		}
	}

	void solve(){
		scanf("%d%d%d",&n,&m,&k);
		fac[0]=1;
		for(int i=1;i<=n;++i)fac[i]=fac[i-1]*i%mod;
		rfac[n]=fpm(fac[n],mod-2);
		for(int i=n-1;i>=0;--i)rfac[i]=rfac[i+1]*(i+1)%mod;
		int x=0,y=0,z=0;
		for(int i=1; i<n; ++i){
			scanf("%d%d%d",&x,&y,&z);
			add(x,y,z);add(y,x,z);
		}
		lim=n;gtsz(1,0);gthv(1,0);
		solve(hv);
		printf("%lld\n",ans);
	}
}

int main(){	
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
	party::solve();
}
