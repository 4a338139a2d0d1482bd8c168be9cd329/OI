#include<bits/stdc++.h>
using namespace std;

int vis[11],ret=0,n,a[11],b[11];
namespace pai{
	void pa(){
		for(int i=1; i<=n; ++i){
			if((b[i])&&(a[i]!=b[i])) return;
		}
		for(int i=1; i<=n; ++i) if(a[i]==i)return;
		ret++;
	}
	void dfs(int x){
		for(int i=1;i<=n;++i){
			if(!vis[i]){
				vis[i]=1;
				a[x]=i;
				if(x<n)dfs(x+1);else pa();
				vis[i]=0;
			}
		}
	}
	void fk(){
		scanf("%d",&n);
		for(int i=1;i<=n;++i)scanf("%d",&b[i]);
		dfs(1);
		printf("%d\n",ret);
	}
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	pai::fk();
}
