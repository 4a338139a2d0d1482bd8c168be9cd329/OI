#include<bits/stdc++.h>
#define getchar getchar_unlocked
#define ll long long 
const int mod=998244353;
const int N=1e6+10;
using namespace std;

int n;
int a[N+10];
ll fac[N+10],rfac[N+10];
int pa[N+10];
int pb[N+10];

namespace per{
	inline ll fpm(ll x,ll y){
		 ll s=1;
		 while(y){
		 	if(y&1)s=s*x%mod;
			y>>=1;x=x*x%mod;
		 }
		 return s;
	}
	inline int read(){
		int x=0; char ch=getchar();
		while(!isdigit(ch))ch=getchar();
		while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
		return x;
	}
	inline ll c(int x,int y){
		ll s=fac[x]*rfac[y]%mod*rfac[x-y]%mod;
		return s;
	}
	void solve(){
		n=read();
		for(int i=1; i<=n; ++i) a[i]=read();
		fac[0]=1;
		for(int i=1; i<=N; ++i) fac[i]=fac[i-1]*i%mod;
		rfac[N]=fpm(fac[N],mod-2);
		for(int i=N-1; i>=0; --i) rfac[i]=rfac[i+1]*(i+1)%mod;
		int rest=0,rest1=0;
		for(int i=1; i<=n; ++i) if(!a[i]) pa[i]=1,rest++;
		for(int i=1; i<=n; ++i) pb[a[i]]=1;
		for(int i=1; i<=n; ++i) pb[i]^=1;
		for(int i=1; i<=n; ++i) rest1+=(pa[i]&pb[i]);

		ll ans=0,z=1;
		for(int i=0;i<=rest1;++i,z=-z){
			if(z>0) ans=(ans+z*c(rest1,i)%mod*fac[rest-i]%mod)%mod;
			   else ans=(ans+(mod+z)*c(rest1,i)%mod*fac[rest-i]%mod)%mod;
		}
		printf("%lld\n",ans);
	}
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	per::solve();	
}
