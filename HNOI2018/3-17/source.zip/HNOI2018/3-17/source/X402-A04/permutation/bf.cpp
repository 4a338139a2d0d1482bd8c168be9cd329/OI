#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=15;
int a[N],p[N],n;

void wj()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) a[i]=read();
	for(int i=1;i<=n;++i) p[i]=i;
	int ans=0;
	do
	{
		bool can=1;
		for(int i=1;i<=n;++i) 
			if(!a[i]||a[i]==p[i]) ;
			else can=0;
		for(int i=1;i<=n;++i) if(!a[i]&&p[i]==i) can=0;
		ans+=can;
	}while(next_permutation(p+1,p+1+n));
	printf("%d\n",ans);
	return 0;
}
