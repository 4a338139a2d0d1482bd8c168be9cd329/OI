#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int mod=998244353;
const int inf=0x3f3f3f3f;
int head[N],cnt=0;
struct node
{
	int to,next,w;
}e[N<<1];
inline void add(int x,int y,int w)
{
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],w};head[y]=cnt;
}
int n,m,K;

namespace dc
{
	int siz[N],nn,rt,mx[N],seq[N],tot;
	bool vis[N];
	void findrt(int u,int fa)
	{
		siz[u]=1; mx[u]=0;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa||vis[v]) continue;
			findrt(v,u);
			siz[u]+=siz[v];
			mx[u]=max(mx[u],siz[v]);
		}
		mx[u]=max(mx[u],nn-siz[u]);
		if(mx[u]<mx[rt]) rt=u;
	}
	void getdep(int u,int fa,int d)
	{
		seq[++tot]=d;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa||vis[v]) continue;
			getdep(v,u,d+e[i].w);
		}
	}
	int calc()
	{
		sort(seq+1,seq+1+tot);
		int p1=tot,ans=0;
		for(int i=1;i<=tot;++i)
		{
			while(p1>=1&&seq[i]+seq[p1]>2*K) p1--;
			ans=(ans+p1)%mod;
		}
		for(int i=1;i<=tot;++i) ans-=(seq[i]+seq[i]<=2*K);
		ans=(ans+mod)%mod;
		return ans;
	}
	int ans=0;
	void dfs(int u)
	{
		vis[u]=1;
		tot=0;
		getdep(u,0,0);
		ans=(ans+calc())%mod;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(vis[v]) continue;
			tot=0;
			getdep(v,u,e[i].w);
			ans=(ans-calc()+mod)%mod;
		}
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(vis[v]) continue;
			rt=0; nn=siz[v]; findrt(v,u);
			dfs(rt);
		}
	}
	void solve()
	{
		mx[0]=inf;
		rt=0; nn=n; findrt(1,0);
		dfs(rt);
		printf("%d\n",ans);
	}
}

ll dis[25][25];
void dfs(int now,int u,int fa,ll d)
{
	dis[now][u]=d;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(now,v,u,d+e[i].w);
	}
}
void wj()
{
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); K=read();
	bool all1=1;
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read(),w=read();
		add(x,y,w);
		if(w!=1) all1=0;
	}
	if(m==2&&all1) {dc::solve();return 0;}
	for(int i=1;i<=n;++i) dfs(i,i,0,0);
	int tot=1<<n;
	int ans=0;
	for(int s=0;s<tot;++s) if(__builtin_popcount(s)==m)
	{
		bool can=0;
		for(int i=1;i<=n;++i) 
		{
			ll maxn=0;
			for(int j=1;j<=n;++j) if(s&(1<<j-1))
				maxn=max(maxn,dis[i][j]);
			if(maxn<=K) {can=1;break;}
		}
		ans+=can;
	}
	for(int i=1;i<=m;++i) ans=1ll*ans*i%mod;
	printf("%d\n",ans);
	return 0;
}
