#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
inline ll readl()
{
    char ch=getchar();int g=1;ll re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef pair<int,int> pii;

const int N=5050;
ll gcd(ll a,ll b)
{
	while(b) {ll t=a%b;a=b;b=t;}
	return a;
}
int n,m,tot=0;
ll A[N],B[N],divi[N];

void wj()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
}
int main()
{
	wj();
	srand(233333);
	int typ=read(),T=read();
	for(int cas=1;cas<=T;++cas)
	{
		int n=read(),m=read();
		for(int i=1;i<=n;++i) A[i]=readl();
		if(typ==1)
		{
			ll a=A[1];
			for(int i=2;i<=n;++i) a=gcd(a,A[i]);
			tot=0;
			int sq=sqrt(a);
			for(int i=2;i<=sq;++i) if(!(a%i))
			{
				divi[++tot]=i;
				if(1ll*i*i!=a) divi[++tot]=a/i;
			}
			while(tot&&a>m) a/=divi[tot--];
			printf("%lld %lld\n",a,a);
			continue;
		}
		for(int i=1;i<=n;++i) B[i]=A[i];
		ll ansa=0,ansb=0;
		for(int cur=1;cur<=6;++cur)
		{
			random_shuffle(B+1,B+1+n);
			ll a=B[1],b=B[(n>>1)+1];
			for(int i=2;i<=(n>>1);++i) a=gcd(a,B[i]);
			for(int i=(n>>1)+2;i<=n;++i) b=gcd(b,B[i]);
			if(abs(a+b-m)<abs(ansa+ansb-m)) ansa=a,ansb=b;
		}
		printf("%lld %lld\n",ansa,ansb);
	}
	return 0;
}
