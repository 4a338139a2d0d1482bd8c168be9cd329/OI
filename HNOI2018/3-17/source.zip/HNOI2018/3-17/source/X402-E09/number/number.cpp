#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
template<typename T>T read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
typedef long long ll;
ll gcd(ll x,ll y){
	return x==0?y:gcd(y%x,x);
}
int ans; ll s,ss,a[5005],k,y,x,an1,an2;
int main(){
	freopen("number.in","r",stdin); freopen("number.out","w",stdout);
	int _=read<int>(),t=read<int>(),n,m;
	if (_==1){
	while(t--){
		n=read<int>(),m=read<int>(); y=s=0; ss=(ll)n*(m+1)>>1;
		For(i,1,n) a[i]=read<ll>(),s+=a[i],k=s/ss,s-=k*ss,y+=k;
		x=a[1]; For(i,2,n) {if (a[i]>=x) x=gcd(x,a[i]); else x=gcd(a[i],x);}
		for(int i=y;i>=1;--i) if (x%i==0) {an1=i; break;}
		For(i,y+1,x) if (x%i==0) {an2=i; break;}
		if (s*2>=ss||(n%2==1&&m%2==0)){
			if (an2-y>=y-an1+1) printf("%lld\n",an2);
			else printf("%lld\n",an1);
		}
		else{
			if (an2-y>=y-an1) printf("%lld\n",an2);
			else printf("%lld\n",an1);
		}
	}
	}
	return 0;
}
