#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=100005,mo=998244353;
int to[N<<1],head[N],e,nex[N<<1],w[N<<1];
void add(int x,int y,int z){
	to[++e]=y; nex[e]=head[x]; head[x]=e; w[e]=z;
}
int s[23][23],q[23],l,lg[23];
void dfs(int x,int fa,int z){
	s[e][x]=z;
	for(int i=head[x];i;i=nex[i])
		if (to[i]!=fa) dfs(to[i],x,z+w[i]);
}
int main(){
	freopen("party.in","r",stdin); freopen("party.out","w",stdout);
	int n=read(),m=read(),k=read(),x,y,z,ans=0; long long xx;
	For(i,1,n-1) x=read(),y=read(),z=read(),add(x,y,z),add(y,x,z);
	if (n<=20){
		For(i,1,n) e=i,dfs(i,0,0);
		z=(1<<n)-1; lg[1]=1; For(i,2,n) lg[i]=lg[i-1]<<1;
		For(i,0,z){
			l=0; For(j,1,n) if (lg[j]&i) q[++l]=j; if (l!=m) continue;
			For(j,1,n){
				y=1;
				For(ii,1,l) if (s[j][q[ii]]>k) {y=0; break;}
				if (y) {++ans; break;}
			}
		}
		xx=1;
		For(i,2,m) xx=xx*i%mo;
		printf("%lld\n",xx*ans%mo);
	}
	return 0;
}
