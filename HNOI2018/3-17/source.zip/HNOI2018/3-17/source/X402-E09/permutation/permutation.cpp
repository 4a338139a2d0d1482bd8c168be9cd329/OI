#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=998244353;
typedef long long ll;
int a[1000005],s[1000005]; bool f[1000005];
ll ksm(ll x,int y){
	ll an=1;
	while(y){
		if (y&1) an=an*x%mo; y>>=1,x=x*x%mo;
	}
	return an;
}
int main(){
	freopen("permutation.in","r",stdin); freopen("permutation.out","w",stdout);
	int n=read(),ans=0,fl,x=0,y=0; ll z=1;
	For(i,1,n){
		a[i]=read();
		if (a[i]){
			if (a[i]==i) printf("0\n"),exit(0); ++x;
			if (f[i]) ++y; else f[i]=1;
			if (f[a[i]]) ++y; else f[a[i]]=1;
		}
	}
	n-=y,x-=y;
	if (n<=2){
		if (!n) printf("1\n");
		else if (n==1) printf("0\n");
		else printf("1\n"); exit(0);
	}
	s[1]=0,s[0]=s[2]=1; z=1; y=x;
	For(i,3,n-x) s[i]=(ll)(s[i-1]+s[i-2])*(i-1)%mo;
	For(i,n-x*2,n-x){
		ans+=z*s[i]%mo; if (ans>=mo) ans-=mo; z=z*y%mo*ksm(x-y+1,mo-2)%mo; --y;
	}
	printf("%d\n",ans);
	return 0;
}
