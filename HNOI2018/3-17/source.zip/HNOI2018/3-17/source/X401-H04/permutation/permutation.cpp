#include <cstring>
#include <cstdio>
#include <algorithm>
#define ll long long
const int MOD = 998244353;
inline int mul(int x, int y) { return (ll)x * (ll)y % MOD; }
inline int add(int x, int y) { int r = x + y; if(r >= MOD) r -= MOD; return r; }
inline int fpm(int a, int p) {
    int ret = 1, x = a;
    while(p) {
        if(p & 1) ret = mul(ret, x);
        x = mul(x, x);
        p >>= 1;
    }
    return ret;
}
using namespace std;

const int MAXN = 1000010;
int N, A[MAXN];
bool vis[MAXN];

int fact[MAXN], ifact[MAXN];
int F[MAXN], NFree = 0, NAll = 0;

inline int C(int n, int m) {
    if(m > n || m < 0) return 0;
    return mul(fact[n], mul(ifact[m], ifact[n - m]));
}

int main() {
    freopen("permutation.in", "rt", stdin);
    freopen("permutation.out", "wt", stdout);

    int i, k;
    scanf("%d", &N);
    for(i = 1; i <= N; i++) {
        scanf("%d", &A[i]);

        if(A[i]) vis[i] = 1;
        else NAll++;
    }
    for(i = 1; i <= N; i++) if(A[i] && !vis[A[i]]) NFree++;

    //Get Fact
    fact[0] = 1; for(i = 1; i <= NAll; i++) fact[i] = mul(fact[i - 1], i);
    ifact[NAll] = fpm(fact[NAll], MOD - 2); for(i = NAll - 1; i >= 0; i--) ifact[i] = mul(ifact[i + 1], i + 1);
    //Get Normal Permutation
    F[0] = 1, F[1] = 0; for(i = 2; i <= NAll; i++) F[i] = mul(i - 1, add(F[i - 1], F[i - 2]));

    int Ans = 0;
	for(i = 0; i <= NAll; i++) {
        Ans = add(Ans, mul( F[i], C(NFree, NFree - (NAll - i) ) ) );
    }
    printf("%d", Ans);
}
