#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 15;

int N, A[MAXN], P[MAXN], NAll = 0, NFree = 0;
bool vis[MAXN];

int main() {
    freopen("permutation.in", "rt", stdin);

    scanf("%d", &N);

    int i;
    for(i = 1; i <= N; i++) {
        scanf("%d", &A[i]);

        if(A[i]) vis[i] = 1;
        else NAll++;
    }
    for(i = 1; i <= N; i++) if(A[i] && !vis[A[i]]) NFree++;

    int Ans = 0;
    for(i = 1; i <= N; i++) P[i] = i;
    do {
        bool Ok = 1;
        for(i = 1; i <= N; i++) if( (i == P[i]) || (A[i] && (P[i] != A[i])) ) {
            Ok = 0;
            break;
        }
        if(Ok) Ans++;
    } while(next_permutation(P + 1, P + N + 1));
    printf("A = %d, F = %d --> %d", NAll, NFree, Ans);
}
