#include <cstring>
#include <cstdio>
#include <algorithm>
#include <ctime>
#define ll long long
const int MAXN = 5010;
using namespace std;

int Task, T, N, M;
inline ll gcd(ll a, ll b) { return !b ? a : gcd(b, a % b); }
ll V[MAXN];

int main() {
    freopen("number.in", "rt", stdin);
    freopen("number.out", "wt", stdout);

    int i;
    scanf("%d%d", &Task, &T);
    while(T--) {
        scanf("%d%d", &N, &M);
        for(i = 1; i <= N; i++) scanf("%lld", &V[i]);

        ll x = V[1];
        for(i = 2; i <= N; i++) x = gcd(x, V[i]);

        printf("%lld %lld\n", x, x);
    }
}
