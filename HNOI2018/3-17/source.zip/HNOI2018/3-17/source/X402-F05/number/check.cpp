#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int ansa[310], ansb[310];

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("number.in", "w", stdout);

	srand(time(0));

	int T = 300, N = 5000, M = 1e9;
	printf("5 %d\n", T);

	For(Case, 1, T) {
		printf("%d %d\n", N, M);

		int a = rand() % 2 ? randint(1, M) : randint(1, M), 
			b = rand() % 2 ? randint(1, M) : randint(1, M), p = randint(0, 3);
		if (a > b) swap(a, b);

		For(i, 1, N) 
			if (rand() % 100 <= p) printf("%lld\n", 1ll * randint(1, M) * a);
			else printf("%lld\n", 1ll * randint(1, M) * b);

		ansa[Case] = a, ansb[Case] = b;
	}

	freopen("number.ans", "w", stdout);
	For(i, 1, T) printf("%d %d\n", ansa[i], ansb[i]);

	return 0;
}
