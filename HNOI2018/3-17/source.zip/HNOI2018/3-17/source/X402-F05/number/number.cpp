#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

LL Read() {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	LL x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

LL gcd(LL x, LL y) {
	return !y ? x : gcd(y, x % y);
}

const int N = 5010;
const int LIM = 10;
const int M = 25000;
const int P = 9;

int n, m;
int a, b;
LL A[N];
int task;

int idx[M + 5], idy[M + 5];

namespace Solver {

	void bf () {
		for (a = 1; a <= LIM; ++a)
			for (b = a; b <= LIM; ++b) {
				bool flag = true;
				For(i, 1, n) 
					if ((A[i] % a == 0 && A[i] / a <= m) || (A[i] % b == 0 && A[i] / b <= m));
					else { flag = false; break; }
				if (flag) return;
			}
	}

	LL val[M + 10];

	bool check(LL x) {
		if (x > m || x == 0) return false;
		LL g = 0;
		bool fa = false, fb = false;
		For(i, 1, n) {
			if (A[i] % x != 0 || A[i] / x > m) {
				g = g ? gcd(A[i], g) : A[i];
			} else {
				fa |= A[i] / x >= m / 2;
			}
		}

		For(i, 1, n) 
			if (A[i] % x != 0 || A[i] / x > m) {
				if (A[i] / g > m) return false;
				fb |= A[i] / g >= m / 2;
			}

		if (!fa || !fb || g > m) return false;

		a = x, b = g;
		return true;
	}

	void main() {

		int c = 0;
		For(i, 1, n) if (A[i] <= 1ll * LIM * m) ++c;

		if (c == n) {
			bf(); return;
		}

		For(i, 1, M) {
			int u = idx[i] % n + 1, v = idy[i] % n + 1;
			val[i] = gcd(A[u], A[v]);
		}
		sort(val + 1, val + M + 1, greater<LL>());
		For(l, 1, M) {
			int r = l;
			while (r < M && val[r + 1] == val[l]) ++r;
			if (r - l + 1 >= M / P && check(val[l])) return;
			l = r;
		}

		//cerr << "oops" << endl;

	}

};

int main() {

	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);

	srand(time(0));

	For(i, 1, M) idx[i] = rand(), idy[i] = rand();

	task = Read();
	int T = Read();
	while (T--) {

		n = Read(), m = Read();
		LL g = 0;
		For(i, 1, n) A[i] = Read(), g = i == 1 ? A[i] : gcd(g, A[i]);
		For(i, 1, n) A[i] /= g;

		if (task == 1) a = 1, b = 1;
		else Solver::main();

		if (a > b) swap(a, b);

		printf("%lld %lld\n", a * g, b * g);

	}

	return 0;
}
