#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 1e6 + 10;
const int Mod = 998244353;

int A[N], P[N];

int L, n, m;

int main() {

	freopen("permutation.in", "r", stdin);
	freopen("permutation.ans", "w", stdout);

	scanf("%d", &L);

	int c = 1;
	For(i, 1, L) scanf("%d", &A[i]), P[i] = i, c *= i;

	int ans = 0;
	while (c--) {
		bool flag = true;
		For(i, 1, L) if ((A[i] && P[i] != A[i]) || P[i] == i) {
			flag = false; break;
		}
		next_permutation(P + 1, P + L + 1);
		ans += flag;
	}
	printf("%d\n", ans);

	return 0;
}
