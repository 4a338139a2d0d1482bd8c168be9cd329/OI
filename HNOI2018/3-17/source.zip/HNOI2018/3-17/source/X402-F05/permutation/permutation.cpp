#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 1e6 + 10;
const int Mod = 998244353;

int Pow(int x, int e) {
	int ret = 1;
	while (e) {
		if (e & 1) ret = 1ll * ret * x % Mod;
		x = 1ll * x * x % Mod;
		e >>= 1;
	}
	return ret;
}

bool vis[N];
int A[N];
int fac[N], rfac[N];

int C(int n, int m) {
	return 1ll * fac[n] * rfac[m] % Mod * rfac[n - m] % Mod;
}

int L, n, m;

int main() {

	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	scanf("%d", &L);
	For(i, 1, L) scanf("%d", &A[i]), vis[A[i]] = true;
	For(i, 1, L) 
		if (!A[i]) {
			++n;
			if (!vis[i]) ++m;
		}

	fac[0] = 1;
	For(i, 1, n) fac[i] = 1ll * fac[i - 1] * i % Mod;
	rfac[n] = Pow(fac[n], Mod - 2);
	Forr(i, n, 1) rfac[i - 1] = 1ll * rfac[i] * i % Mod;

	int ans = 0;
	For(i, 0, m) ans = (ans + 1ll * C(m, i) * fac[n - i] % Mod * ((i & 1) ? Mod - 1 : 1)) % Mod;
	printf("%d\n", ans);

	return 0;
}
