#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;
const int Mod = 998244353;

int n, m, k;
int Begin[N], Next[N << 1], to[N << 1], len[N << 1], e;

void add(int u, int v, int w) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e, len[e] = w;
}

typedef long long LL;

namespace BF {

	bool mark[N];

	LL DFS(int o, int f = 0) {
		LL dis = mark[o] ? 0 : -(1ll << 60);
		for (int i = Begin[o]; i; i = Next[i]) {
			int u = to[i];
			if (u == f) continue;
			dis = max(dis, DFS(u, o) + len[i]);
		}
		return dis;
	}

	void main() {

		int cnt = 0;
		For(i, 1, (1 << n) - 1) {
			if (__builtin_popcount(i) != m) continue;
			For(j, 0, n - 1) mark[j + 1] = i & (1 << j);

			bool flag = false;
			For(j, 1, n) if (DFS(j) <= k) { flag = true; break; }
			cnt += flag;
		}
		For(i, 1, m) cnt = 1ll * cnt * i % Mod;
		printf("%d\n", cnt);
	}

};

namespace Subtask3 {

	LL ans = 0;

	int nowsz, minsz, cen;
	int sz[N];
	bool vis[N];

	void DFS_Centroid(int o, int f) {
		sz[o] = 1;
		int mx = 0;
		for (int i = Begin[o]; i; i = Next[i]) {
			int u = to[i];
			if (vis[u] || u == f) continue;
			DFS_Centroid(u, o);
			sz[o] += sz[u];
			if (sz[u] > mx) mx = sz[u];
		}
		mx = max(mx, nowsz - sz[o]);
		if (mx < minsz) minsz = mx, cen = o;
	}

	int cnt[N], mxd;

	void DFS_info(int o, int f, int d) {
		if (d > mxd) mxd = d;
		cnt[d]++;
		sz[o] = 1;
		for (int i = Begin[o]; i; i = Next[i]) {
			int u = to[i];
			if (vis[u] || u == f) continue;
			DFS_info(u, o, d + 1);
			sz[o] += sz[u]; 
		}
	}

	int sum[N], scnt[N];

	void Divide_Conquer(int rt, int _n) {
		nowsz = minsz = _n, cen = rt;
		DFS_Centroid(rt, 0);
		int o = cen, c = 0;
		vis[o] = true;

		scnt[0] = 1, sum[0] = 0;
		--ans;
		for (int ed = Begin[o]; ed; ed = Next[ed]) {
			int u = to[ed];
			if (vis[u]) continue;

			mxd = 0;
			DFS_info(u, o, 1);
			c = max(c, mxd);
			For(i, 1, mxd) sum[i] = sum[i - 1] + cnt[i];
			For(i, 1, mxd) {
				ans -= 1ll * cnt[i] * sum[min(2 * k - i, mxd)];
				scnt[i] += cnt[i], cnt[i] = 0;
			}
		}
		sum[0] = 1;
		For(i, 1, c) sum[i] = sum[i - 1] + scnt[i];
		For(i, 0, c) {
			ans += 1ll * scnt[i] * sum[min(2 * k - i, c)];
			scnt[i] = 0;
		}

		for (int i = Begin[o]; i; i = Next[i])
			if (!vis[to[i]]) Divide_Conquer(to[i], sz[to[i]]);
	
	}
	
	void main() {
		Divide_Conquer(1, n);
		printf("%lld\n", ans % Mod);
	}

};

int main() {

	freopen("party.in", "r", stdin);
	freopen("party.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	For(i, 2, n) {
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		add(u, v, w), add(v, u, w);
	}

	if (n <= 20) BF::main();
	else if (m == 2) Subtask3::main();

	return 0;
}
