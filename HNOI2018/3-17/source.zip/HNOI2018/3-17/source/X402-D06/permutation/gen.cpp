#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
int a[1000010];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n;
	freopen("gen.in","r",stdin);
	int rand_num=read();
	srand(time(0)+rand_num);
	freopen("permutation.in","w",stdout);
	n=12;
	printf("%d\n",n);
	for(i=1;i<=n;i++)a[i]=i;
	random_shuffle(a+1,a+n+1);
	for(i=1;i<=n;i++)
		if(rand()%4<=2)a[i]=0;
	for(i=1;i<=n;i++)printf("%d%c",a[i],i==n?'\n':' ');
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	return 0;
}
