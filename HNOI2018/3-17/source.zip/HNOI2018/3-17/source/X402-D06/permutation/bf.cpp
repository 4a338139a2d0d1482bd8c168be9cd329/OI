#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const int maxn=1e6+10;
const long double eps=1e-9;
const int mod=998244353;
int a[maxn],vis[maxn],F[maxn];
int ans=0;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int chk(int n){
	int i;
	for(i=1;i<=n;i++)if(a[i]==i)return 0;
	return 1;
}
void dfs(int cur,int tot){
	if(cur>tot){
		if(chk(tot))ans++;
		return;
	}
	int i;
	if(F[cur]){
		dfs(cur+1,tot);
		return;
	}
	for(i=1;i<=tot;i++){
		if(vis[i])continue;
		vis[i]=1;
		a[cur]=i;
		dfs(cur+1,tot);
		vis[i]=0;
		a[cur]=0;
	}
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	n=read();
	for(i=1;i<=n;i++){
		a[i]=read(),vis[a[i]]=1;	
		if(a[i])F[i]=1;
	}
	dfs(1,n);
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}

