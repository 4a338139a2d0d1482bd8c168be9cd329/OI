#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=5e3+10;
ll a[maxn],cnt[maxn],sum[maxn];
inline ll read(){
	ll x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	ll i,j,k,m,n,T;
#ifndef ONLINE_JUDGE
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
#endif
	ll Task=read();T=read();
	while(T--){
		n=read();m=read();
		if(Task==1){
			for(i=1;i<=n;i++)a[i]=read();
			ll val=a[1];
			for(i=2;i<=n;i++)val=__gcd(val,a[i]);
			printf("%lld %lld\n",val,val);
		}
		else{
			memset(cnt,0,sizeof(cnt)),memset(sum,0,sizeof(sum));
			double avrg=0;ll Max=0,Min=1e18;
			for(i=1;i<=n;i++)
				a[i]=read(),avrg+=a[i]*1.0/m,Max=max(Max,a[i]),Min=min(Min,a[i]);
			sort(a+1,a+n+1);
			int blksz=80;
			ll val=Max/blksz+1;
			for(i=1;i<=n;i++)cnt[a[i]/val]++;
//			for(i=0;i<=blksz;i++)cout<<cnt[i]<<endl;
			sum[0]=cnt[0];
			for(i=1;i<=blksz;i++)sum[i]=sum[i-1]+cnt[i];
			int pos=0;double ratio=1.0*INF;
			for(i=2;i<=blksz-1;i++)
				if(cnt[i]*1.0/cnt[i-2]<ratio){
					ratio=cnt[i]*1.0/cnt[i-2];
					pos=i-1;
					if(ratio==0)break;
				}
//			cout<<pos<<" "<<ratio<<endl;
//			printf("%d %d %d\n",sum[3],sum[30],pos);
			ll gcd;
//			if(pos<=blksz-4 && ratio<0.4){
				gcd=a[n];
				ll cntnum=0;
				for(i=n;(i>=sum[pos+1] || cntnum<=8) && i>=1;i--){
					if(__gcd(gcd,a[i])<Min/m)continue;
					cntnum++;gcd=__gcd(gcd,a[i]);
				}
//			}
/*			else{
				gcd=a[n];
				for(i=n;i>=n-20;i--){
					if(__gcd(gcd,a[i])<Min/m)continue;
					gcd=__gcd(gcd,a[i]);
				}
			}
*/			bool Fir=0;ll gcd2=0;cntnum=0;
			for(i=0;(i<=sum[pos-1] || cntnum<=8) && i<=n;i++){
				if(a[i]%gcd==0 || (gcd2 && __gcd(gcd2,a[i])<Min/m))continue;
				if(!Fir)Fir=1,gcd2=a[i];
				gcd2=__gcd(gcd2,a[i]);cntnum++;
			}
//			printf("%lld %lld\n",gcd,gcd2);
			printf("%lld %lld\n",min(gcd,gcd2),max(gcd,gcd2));
		}
	}
	return 0;
}

