#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n;
	freopen("gen.in","r",stdin);
	int rand_num=read();
	srand(time(0)+rand_num);
	freopen("number.in","w",stdout);
	int T=300,Task=2;n=5000;m=1e9;
	printf("%d %d\n",Task,T);
	while(T--){
	printf("%d %d\n",n,m);
	int a=rand(),b=rand();
	int p=rand()%99+1;
	cerr<<p<<endl;
	for(i=1;i<=n;i++){
		if(rand()%100+1<=p)printf("%lld\n",1ll*a*(rand()%m+1));
		else printf("%lld\n",1ll*b*(rand()%m+1));
	}
	}
//	freopen("number.ans","w",stdout);
//	printf("%d %d\n",min(a,b),max(a,b));
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	return 0;
}
