#include<bits/stdc++.h>
#define N 1000100
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
long long n;
long long a[N],vis[N];
long long dp[N];
long long ans,cnt;
void dfs(long long x)
{
	if(x==n+1){ans++;return ;}
	if(a[x])dfs(x+1);
	else for(long long i=1;i<=n;i++)
	{
		if(!vis[i]&&x!=i)
		{
			vis[i]=1;
			a[x]=i;
			dfs(x+1);
			a[x]=0;
			vis[i]=0;
		}
	}
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	read(n);
	for(long long i=1;i<=n;i++)
	{
		read(a[i]);
		if(a[i])vis[a[i]]=1;
		if(!a[i])cnt++;
	}
	if(n<=10){dfs(1);printf("%lld\n",ans);return 0;}
	else 
	{
		long long tot=0;
		for(long long i=1;i<=n;i++)
			if(a[i]&&!a[a[i]])tot++;
		long long rest=cnt-tot;
		dp[0]=1ll;
		for(long long i=1;i<=tot;i++)
			(dp[0]=dp[0]*i)%=mod;
		for(long long i=1;i<=rest;i++)
		{
			(dp[i]+=tot*dp[i-1])%=mod;
			(dp[i]+=dp[i-1]*(i-1))%=mod;
			if(i!=1)(dp[i]+=dp[i-2]*(i-1))%=mod;
		}
		printf("%lld\n",dp[rest]%mod);
	}
	return 0;
}
