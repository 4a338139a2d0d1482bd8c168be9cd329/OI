#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
long long T,t,n,m;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	if(T==1)
	{
		read(t);
		while(t--)
		{
			read(n);read(m);
			static long long x;
			static long long maxn;
			maxn=2e18;
			read(x);
			maxn=max(x,maxn);
			long long a=x;
			for(long long i=1;i<=n-1;i++)
			{
				read(x);
				a=__gcd(a,x);
				maxn=max(maxn,x);
			}
			if(a<=2147483647ll)printf("%lld %lld\n",a,a);
			else 
			{
				for(long long i=2;i*i<=a&&i<=2147483647;i++)
				{
					if(a%i==0)
					{
						if(maxn/i<=2147483647ll){printf("%lld %lld\n",i,i);break;}
						else if(a/i<=2147483647)
						{
							if(maxn/(a/i)<=2147483647){printf("%lld %lld\n",maxn/i,maxn/i);break;}
						}
					}
				}
			}
		}
	}
	return 0;
}
