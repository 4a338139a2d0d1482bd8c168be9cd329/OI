#include<bits/stdc++.h>
#define N 100100
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
long long n,m,k;
long long e;
long long to[N<<1],beg[N],nex[N<<1],w[N<<1];
void add(long long x,long long y,long long z)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}
long long zh[N],vis[N];
long long G[30][30],ans;
void dfs(long long x,long long last)
{
    if(x==m+1)
    {
		for(long long i=1;i<=n;i++)
		{
			bool flag=1;
			for(long long j=1;j<=m;j++)
				if(G[i][zh[j]]>k){flag=0;break;}
			if(flag){ans=(ans+1ll)%mod;return ;}
		}
		return ;
    }
    for(long long i=last+1;i<=n;i++)
    {
		if(!vis[i])
		{
			vis[i]=1;
			zh[x]=i;
			dfs(x+1,i);
			zh[x]=0;
			vis[i]=0;
		}
    }
}
/*bool bj[N];
int Size[N],cnt,zx;
void find(int x)
{
	bj[x]=1;
	Size[x]=0;
	int now=0;
	for(int i=beg[x];i;i=nex[i])
	{
		int y=to[i];
		if(!bj[y])
		{
			find(y);
			Size[x]+=Size[y]+1;
			now=max(now,Size[y]+1);
		}
	}
	now=max(now,n-Size[x]-1);
	if(now<cnt||(now==cnt&&x<zs)){cnt=now;zx=x;}
}
void dfz(int x)
{
	
}*/
int main()
{
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
	read(n);read(m);read(k);
	if(n<=20)
	{
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
			G[i][j]=2e18;
		for(long long i=1;i<=n;i++)G[i][i]=0;
		for(long long i=1;i<=n-1;i++)
		{
			static long long x,y,z;
			read(x);read(y);read(z);
			G[x][y]=G[y][x]=z;
		}
		for(long long k=1;k<=n;k++)
			for(long long i=1;i<=n;i++)
				for(long long j=1;j<=n;j++)
				G[i][j]=min(G[i][j],G[i][k]+G[k][j]);
		dfs(1,0);
		long long fac=1;
		for(long long i=1;i<=m;i++)(fac=fac*i)%=mod;
		printf("%lld\n",ans*fac%mod);
		return 0;
	}
	for(long long i=1;i<=n-1;i++)
	{
		static long long x,y,z;
		read(x);read(y);read(z);
		add(x,y,z);
		add(y,x,z);
	}
/*	if(m==2)
	{
		cnt=2e18;
		find(1);
		dfz(zx);
	}
*/	return 0;
}
