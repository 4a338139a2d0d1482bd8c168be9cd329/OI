#include<bits/stdc++.h>
using namespace std;
const int maxn=1001000;
const int md=998244353;
int a[maxn];
bool vis[maxn],us[maxn];
int dp[2010][2010];
int main(){
	freopen("permutation.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		if(a[i])
			vis[i]=1,us[a[i]]=1;
	int cnt1=0,cnt2=0;
	for(int i=1;i<=n;i++){
		if(!us[i]){
			if(vis[i]) cnt1++;
			else cnt2++;
		}
	}
	dp[cnt1][cnt2]=1;
	for(int j=cnt2;j>=0;j--){
		for(int i=cnt1+cnt2;i>=0;i--){
			if(i>0){
				dp[i-1][j]=(dp[i-1][j]+dp[i][j]*(long long)i)%md;
				if(j>0)
					dp[i][j-1]=(dp[i][j-1]+dp[i][j]*(long long)j)%md;
			}
			else{
				if(j>1)
					dp[i+1][j-2]=(dp[i+1][j-2]+dp[i][j]*(long long)(j-1))%md;
			}
		}
	}
	printf("%d\n",dp[0][0]);
	cerr<<cnt1<<" "<<cnt2<<endl;
	return 0;
}
