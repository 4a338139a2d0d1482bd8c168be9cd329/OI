#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=1001000;
long long fac[maxn],inv[maxn],f[maxn];
int a[maxn];
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
long long C(int x,int y){
	return fac[x]*inv[y]%md*inv[x-y]%md;
}
bool vis[maxn],us[maxn];
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		readl(a[i]);
		if(a[i]){
			vis[i]=1;
			us[a[i]]=1;
		}
	}
	fac[0]=1;
	for(int i=1;i<=n;i++)
		fac[i]=fac[i-1]*i%md;
	inv[n]=powd(fac[n],md-2);
	for(int i=n;i>=1;i--)
		inv[i-1]=inv[i]*i%md;
	f[0]=1,f[1]=0;
	for(int i=2;i<=n;i++)
		f[i]=(f[i-1]+f[i-2])*(i-1)%md;
	int cnt1=0,cnt2=0;
	for(int i=1;i<=n;i++){
		if(!us[i]){
			if(vis[i]) cnt1++;
			else cnt2++;
		}
	}
	long long ans=0;
	for(int i=0;i<=cnt1;i++)
		ans=(ans+f[cnt2+i]*C(cnt1,i))%md;
	printf("%lld\n",ans);
	return 0;
}
