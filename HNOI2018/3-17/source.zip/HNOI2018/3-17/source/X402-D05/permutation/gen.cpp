#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxn=1001000;
int a[maxn];
int stk[maxn],top;
void solve(){
	int n=rand()%2000+1;
	int gl=rand()%n+2;
	for(int i=1;i<=n;i++){
		if(rand()%gl==0) stk[++top]=i;
	}
	for(int i=1;i<=top;i++){
		int p=rand()%n+1;
		while(a[p]) p=rand()%n+1;
		a[p]=stk[i];
	}
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		printf("%d ",a[i]);
	printf("\n");
}
int main(){
	srand(time(0)+getx());
	freopen("permutation.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
