#include<bits/stdc++.h>
using namespace std;
string procstatus(){
	ifstream t("/proc/self/status");
	return (string){istreambuf_iterator<char>(t),istreambuf_iterator<char>()};
}
const int maxn=100100;
const long long md=998244353;
const int L=0,R=1e9+7;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
long long fac[maxn],inv[maxn];
int n,m,k;
int cnt[maxn];
void readl(int &x){
	x=0;
	char ch=getchar();
	bool zx=0;
	while(!isdigit(ch)){
		if(ch=='-') zx^=1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
	if(zx) x=-x;
}
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
long long C(int x,int y){
	return fac[x]*inv[y]%md*inv[x-y]%md;
}
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e;
bool vis[maxn];
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
namespace Seg{
#define mid ((l+r)>>1)
	struct node{
		int l,r,v;
	}tr[maxn*42];
	int num,rt;
	int newnode(){
		num++;
		tr[num].l=tr[num].r=tr[num].v=0;
		return num;
	}
	void clear(){
		num=0,rt=0;
	}
	void Insert(int &h,int l,int r,int p,int v){
		if(!h) h=newnode();
		tr[h].v+=v;
		if(l==r) return;
		if(p<=mid) Insert(tr[h].l,l,mid,p,v);
		else Insert(tr[h].r,mid+1,r,p,v);
	}
	void Insert(int p,int v){
		Insert(rt,L,R,p,v);
	}
	int Query(int h,int l,int r,int s,int t){
		if(!tr[h].v) return 0;
		if(s<=l&&r<=t) return tr[h].v;
		if(t<=mid) return Query(tr[h].l,l,mid,s,t);
		else if(s>mid) return Query(tr[h].r,mid+1,r,s,t);
		else
			return Query(tr[h].l,l,mid,s,mid)+Query(tr[h].r,mid+1,r,mid+1,t);
	}
	int Query(int l,int r){
		if(l>r) return 0;
		return Query(rt,L,R,l,r);
	}
}
namespace Root{
	int siz[maxn],mxson[maxn];
	void get_size(int u,int fa){
		siz[u]=1,mxson[u]=0;
		for(int i=beg[u];i;i=nex[i]){
			if(tto[i]==fa) continue;
			if(vis[tto[i]]) continue;
			get_size(tto[i],u);
			siz[u]+=siz[tto[i]];
			chkmax(mxson[u],siz[tto[i]]);
		}
	}
	int find_root(int tot,int u,int fa){
		chkmax(mxson[u],tot-siz[u]);
		if(mxson[u]*2<=tot) return u;
		int v;
		for(int i=beg[u];i;i=nex[i]){
			if(tto[i]==fa) continue;
			if(vis[tto[i]]) continue;
			v=find_root(tot,tto[i],u);
			if(v==-1) continue;
			return v;
		}
		return -1;
	}
	int get_root(int u){
		get_size(u,-1);
		return find_root(siz[u],u,-1);
	}
}
int d[maxn];
void build_tree(int u,int fa,int dep){
	d[u]=dep;
	if(dep>k) return;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[tto[i]]) continue;
		build_tree(tto[i],u,dep+w[i]);
	}
}
void Insert(int u,int fa,int v){
	if(d[u]>k) return;
	Seg::Insert(d[u],v);
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[tto[i]]) continue;
		Insert(tto[i],u,v);
	}
}
void Query(int u,int fa){
	if(d[u]>k) return;
	cnt[u]=cnt[u]+Seg::Query(0,k-d[u]);
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[tto[i]]) continue;
		Query(tto[i],u);
	}
}
void solve(int u){
	Seg::clear();
	build_tree(u,-1,0);
	Insert(u,-1,1);
	vis[u]=1;
	cnt[u]=cnt[u]+Seg::Query(0,k);
	for(int i=beg[u];i;i=nex[i]){
		if(vis[tto[i]]) continue;
		Insert(tto[i],-1,-1);
		Query(tto[i],-1);
		Insert(tto[i],-1,1);
	}
	for(int i=beg[u];i;i=nex[i]){
		if(vis[tto[i]]) continue;
		solve(Root::get_root(tto[i]));
	}
	vis[u]=0;
}
int main(){
	int s,t,v;
	readl(n),readl(m),readl(k);
	for(int i=1;i<n;i++){
		readl(s),readl(t),readl(v);
		putin(s,t,v);
		putin(t,s,v);
	}
	fac[0]=1;
	for(int i=1;i<=n;i++)
		fac[i]=fac[i-1]*i%md;
	inv[n]=powd(fac[n],md-2);
	for(int i=n;i>=1;i--)
		inv[i-1]=inv[i]*i%md;
	solve(Root::get_root(1));
	long long ans=0;
	for(int i=1;i<=n;i++)
	return 0;
}
