#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=100100;
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int n,m,k;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
long long dep[maxn],fac[maxn],inv[maxn];
int f[maxn],fv[maxn];
int cnt1[maxn],cnt2[maxn];
void dfs_getdep(int u,int fa){
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		dep[tto[i]]=dep[u]+w[i];
		fv[tto[i]]=w[i];
		f[tto[i]]=u;
		dfs_getdep(tto[i],u);
	}
}
void dfs_getcnt1(int rt,int u,int dp){
	if(dp>k) return;
	if(dp+fv[rt]>k)
		cnt1[rt]++;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==f[u]) continue;
		dfs_getcnt1(rt,tto[i],dp+w[i]);
	}
}
void dfs_getcnt2(int rt,int u,int fa,int dp){
	if(dp>k) return;
	cnt2[rt]++;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		dfs_getcnt2(rt,tto[i],u,dp+w[i]);
	}
}
long long C(int x,int y){
	if(x<0||y<0||x-y<0) return 0;
	return fac[x]*inv[y]%md*inv[x-y]%md;
}
int main(){
	freopen("party.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int s,t,v;
	scanf("%d%d%d",&n,&m,&k);
	fac[0]=1;
	for(int i=1;i<=n;i++)
		fac[i]=fac[i-1]*i%md;
	inv[n]=powd(fac[n],md-2);
	for(int i=n;i>=1;i--)
		inv[i-1]=inv[i]*i%md;

	for(int i=1;i<n;i++){
		scanf("%d%d%d",&s,&t,&v);
		putin(s,t,v);
		putin(t,s,v);
	}
	dfs_getdep(1,-1);
	fv[1]=k+1;
	for(int i=1;i<=n;i++)
		dfs_getcnt1(i,i,0);
	for(int i=1;i<=n;i++)
		dfs_getcnt2(i,i,-1,0);
	long long ans=0;
	for(int i=1;i<=n;i++)
		ans=(ans+C(cnt2[i],m)-C(cnt2[i]-cnt1[i],m)+md)%md;
	printf("%lld\n",ans*fac[m]%md);
	if(ans) cerr<<ans<<endl;
	return 0;
}
