#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxv=1e9;
void solve(){
	int n=5000,m=rand()%n+1,k=rand()%maxv+1;
	int V=rand()%maxv+1;
	printf("%d %d %d\n",n,m,k);
	for(int i=2;i<=n;i++){
		printf("%d %d %d\n",rand()%(i-1)+1,i,rand()%V+1);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("party.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
