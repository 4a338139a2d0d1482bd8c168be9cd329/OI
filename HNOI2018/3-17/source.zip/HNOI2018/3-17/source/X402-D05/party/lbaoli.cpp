#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
const long long md=998244353;
int n,m,k;
long long a[30][30];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
void dfs_getdis(int rt,int u,int fa,long long dp){
	a[rt][u]=dp;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		dfs_getdis(rt,tto[i],u,dp+w[i]);
	}
}
int stk[maxn],top,ans;
bool pd(){
	bool bo;
	for(int i=1;i<=n;i++){
		bo=1;
		for(int j=1;j<=top;j++){
			if(a[i][stk[j]]>k)
				bo=0;
		}
		if(bo) return 1;
	}
	return 0;
}
void dfs(int p,int lef){
	if(lef==0){
		ans+=pd();
		return;
	}
	if(p>n) return;
	stk[++top]=p;
	dfs(p+1,lef-1);
	top--;
	dfs(p+1,lef);
}
long long fac[maxn];
int main(){
	freopen("party.in","r",stdin);
	freopen("lbaoli.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	int s,t,v;
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&s,&t,&v);
		putin(s,t,v);
		putin(t,s,v);
	}
	for(int i=1;i<=n;i++)
		dfs_getdis(i,i,-1,0);
	dfs(1,m);
	fac[0]=1;
	for(int i=1;i<=n;i++)
		fac[i]=fac[i-1]*i%md;
	printf("%lld\n",ans*fac[m]%md);
	return 0;
}
