#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
long long a[maxn];
int n,m;
long long da,db,mxa,mxb;
bool dfs(int p){
	if(p>n) return 1;
	long long sta=da,stb=db,ma=mxa,mb=mxb;
	mxa=mxa>a[p]?mxa:a[p];
	da=__gcd(a[p],da);
	if(mxa/da<=m){
		if(dfs(p+1)) return 1;
	}
	mxa=ma,da=sta;

	mxb=mxb>a[p]?mxb:a[p];
	db=__gcd(a[p],db);
	if(mxb/db<=m){
		if(dfs(p+1)) return 1;
	}
	mxb=mb,db=stb;
	return 0;
}
int test(int v){
	long long d=0,mx=0;
	for(int i=1;i<=n;i++){
		if(a[i]%v||a[i]>m*(long long)v){
			d=__gcd(a[i],d);
			if(a[i]>mx) mx=a[i];
			if(mx>m*d)return -1;
		}
	}
	return d;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int id,T;
	scanf("%d%d",&id,&T);
	long long d,v;
	for(id=1;id<=T;id++){
		da=0,db=0,d=0,v=0,mxa=0,mxb=0;
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)
			scanf("%lld",&a[i]);
		d=a[1];
		for(int i=2;i<=n;i++)
			d=__gcd(d,a[i]);
		for(int i=1;i<=n;i++)
			a[i]/=d;
		v=0;
		for(int i=1;i<=n;i++){
			if(a[i]>m){
				if(v==0) v=a[i];
				else v=__gcd(v,a[i]);
			}
		}
		if(v==0) v=1;
		bool bo=1;
		for(int i=1;i<=n;i++){
			if(a[i]>m&&a[i]/v>m){
				bo=0;
				break;
			}
		}
		if(bo){
			printf("%lld %lld\n",d,v*d);
			continue;
		}
		bo=0;
		for(int i=2;i<=10;i++){
			v=test(i);
			if(v!=-1){
				da=i,db=v;
				if(da>db) swap(da,db);
				printf("%lld %lld\n",d*da,d*db);
				bo=1;
				break;
			}
		}
		if(!bo){
			dfs(1);
			if(da>db) swap(da,db);
			printf("%lld %lld\n",da*d,db*d);
		}
	}
	return 0;
}
