#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	FILE *fp=fopen("number.ans","w");
	printf("0\n");
	int T=300;
	printf("%d\n",T);
	int n=5000,m=1e9;
	while(T--){
		int p=rand()%99+1;
		int a=rand()%m+1,b=rand()%m+1;
		if(rand()%10==0){
			if(rand()%5==0) a=rand()%10+1,b=rand()%10+1;
			else a=rand()%20+1,b=rand()%20+1;
		}
		if(a>b) swap(a,b);
		fprintf(fp,"%d %d\n",a,b);
		printf("%d %d\n",n,m);
		for(int i=1;i<=n;i++){
			if(rand()%100+1<=p)
				printf("%lld ",(rand()%m+1)*(long long)a);
			else
				printf("%lld ",(rand()%m+1)*(long long)b);
		}
		printf("\n");
	}
}
int main(){
	srand(time(0)+getx());
	freopen("number.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
