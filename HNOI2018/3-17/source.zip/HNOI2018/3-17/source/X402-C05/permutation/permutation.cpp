#include<bits/stdc++.h>
using namespace std;
const int maxn=2010,mod=998244353;
int n,cnt,a[maxn],d[maxn][maxn],c[maxn];
int p[maxn],pos[maxn],e[maxn],tot;
void solve(){
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",a+i);
		if(a[i])e[a[i]]=1;
	}
	for(int i=1;i<=n;++i)
		if(!e[i])p[++cnt]=i;
	for(int i=1;i<=cnt;++i){
		c[i]=c[i-1]+(!a[p[i]]);
		if(a[p[i]])pos[i]=1;
		else e[++tot]=p[i];
	}
	tot=cnt-tot;
	d[0][0]=1;
	for(int i=1;i<=tot;++i)
		d[i][0]=1ll*d[i-1][0]*i%mod;
	for(int i=2;i<=cnt-tot;++i)
		d[0][i]=1ll*(d[0][i-1]+d[0][i-2])%mod*(i-1)%mod;
	for(int i=1;i<=cnt;++i)
		for(int j=1;j<i;++j){
			if(i-j>tot||j>cnt-tot)continue;
			(d[i-j][j]+=1ll*(i-j)*d[i-j-1][j]%mod)%=mod;
			(d[i-j][j]+=1ll*j*d[i-j][j-1]%mod)%=mod;
		}
	//cerr<<d[tot][cnt-tot]<<endl;
	printf("%lld\n",d[tot][cnt-tot]);
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
