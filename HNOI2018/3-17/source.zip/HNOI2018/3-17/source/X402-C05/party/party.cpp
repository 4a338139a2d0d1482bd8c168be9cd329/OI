#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=5010,mod=998244353;
vector<pair<int,int> > G[maxn];
vector<int> f[maxn];
int n,m,k,fac[maxn],ans,tot,vis[maxn];
#define v G[u][i].first
#define w G[u][i].second
ll dis[maxn][maxn];
void dfs(int u,int h,int fa){
	for(int i=0;i<G[u].size();++i)if(v!=fa){
		dis[h][v]=dis[h][u]+w;
		dfs(v,h,u);
	}
}
vector<int> dfs1(int u,int fa){
	vector<int> ret;
	ret.clear();
	for(int i=0;i<G[u].size();++i)if(v!=fa){
		f[v]=dfs1(v,u);
		ret.insert(ret.begin(),f[v].begin(),f[v].end());
	}
	ret.push_back(u);
	return ret;
}
#undef v
#undef w
void solve(){
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1,u,v,w;i<n;++i){
		scanf("%d%d%d",&u,&v,&w);
		G[u].push_back(make_pair(v,w));
		G[v].push_back(make_pair(u,w));
	}
	if(n<=5000){
		fac[0]=1;
		for(int i=1;i<=n;++i){
			dfs(i,i,0);
			fac[i]=1ll*fac[i-1]*i%mod;
		}
		f[1]=dfs1(1,0);
		ans=0;
		for(int i=1,cmt;i<=n;++i){
			memset(vis,0,sizeof vis);
			tot=0;cmt=0;
			for(int j=0;j<f[i].size();++j){
				if(dis[i][f[i][j]]<=k)++cmt,++tot;
				vis[f[i][j]]=1;
			}
			for(int j=1;j<=n;++j){
				if(!vis[j]&&dis[i][j]<=k)
					++tot;
			}
			(ans+=1ll*(cmt-1)*fac[tot-1]%mod)%=mod;
		}
		printf("%d\n",ans);
	}
}
int main(){
	freopen("party.in","r",stdin);freopen("party.out","w",stdout);
	solve();
	fclose(stdin);fclose(stdout);
	return 0;
}
