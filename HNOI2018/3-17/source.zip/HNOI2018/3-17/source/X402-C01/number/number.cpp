/************************************************
 * Au: Hany01
 * Date: Mar 17th, 2018
 * Prob: number 随机乱搞
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("number.in", "r", stdin);
    freopen("number.out", "w", stdout);
}

int gcd(int x, int y) { return x ? gcd(y % x, x) : y; }

const int maxn = 5005;

int subtask, n, m, a[maxn], d, d1, cnt, b[maxn];

int main()
{
    File();
	srand(19260817);
	subtask = read();
	for (int T = read(); T --; ) {
		n = read(), m = read();
		For(i, 1, n) a[i] = read();
		int flag = 0;
		for (register int S = 1; S <= 100; ++ S) {
			register int x, y;
			do
				x = rand() % n + 1, y = rand() % n + 1;
			while (x == y);
			d = gcd(a[x], a[y]);
			if (d > m) {
				continue;
			}
			cnt = 0;
			For(i, 1, n) if (a[i] % d || a[i] / d > m) b[++ cnt] = a[i];
			if (!cnt) { flag = 1; printf("%d %d\n", d, d); break; }
			else {
				d1 = b[1];
				For(i, 2, cnt) d1 = gcd(d1, b[i]);
				register int mark = 0;
				For(i, 1, cnt) if (b[i] / d1 > m) { mark = 1; break; }
				if (mark) continue;
				if (d > d1) swap(d, d1);
				flag = 1;
				printf("%d %d\n", d, d1);
				break;
			}
		}
		if (!flag) puts("1 1");
	}
    return 0;
}
