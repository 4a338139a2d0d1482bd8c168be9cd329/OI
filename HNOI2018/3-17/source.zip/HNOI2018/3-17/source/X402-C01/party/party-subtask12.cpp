/************************************************
 * Au: Hany01
 * Date: Mar 17th, 2018
 * Prob: party 30pts
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("party.in", "r", stdin);
    freopen("party.out", "w", stdout);
}

const int maxn = 5005, maxm = 10005;

bool dis[maxn][maxn];
LL Ans, fac[maxn], ifac[maxn];
int n, m, k, beg[maxn], nex[maxm], e, v[maxm], w[maxm];

inline void add(int uu, int vv, int ww) { v[++ e] = vv, w[e] = ww, nex[e] = beg[uu], beg[uu] = e; }

void getdis(int st, int cur, LL l, int last) {
	for (register int i = beg[cur]; i; i = nex[i]) if (last != v[i])
		dis[st][v[i]] = (l + (LL)w[i] > (LL)k) ? 0 : 1, getdis(st, v[i], l + (LL)w[i], cur);
}

inline LL C(int n, int m) {
	if (n < m) return 0ll;
	return fac[n] * ifac[m] % Mod * ifac[n - m] % Mod;
}

inline LL Pow(LL a, LL b) {
	LL Ans = 1;
	for ( ; b; b >>= 1, a = a * a % Mod) if (b & 1) (Ans *= a) %= Mod;
	return Ans;
}

void dfs(int u, int fa)
{
	register int A = 0, B = 0;
	For(i, 1, n) if (dis[u][i]) {
		if (dis[fa][i]) ++ A; else ++ B;
	}
	Ans += C(A + B, m) - C(A, m);
	for (register int i = beg[u]; i; i = nex[i]) if (v[i] != fa) dfs(v[i], u);
}

int main()
{
    File();

	//Input
	static int uu, vv, ww;
	n = read(), m = read(), k = read();
	For(i, 2, n) uu = read(), vv = read(), ww = read(), add(uu, vv, ww), add(vv, uu, ww);
	For(i, 1, n) dis[i][i] = 1, getdis(i, i, 0, 0);
	//Get the fac[] and ifac[]
	fac[0] = 1;
	For(i, 1, n) fac[i] = fac[i - 1] * i % Mod;
	ifac[n] = Pow(fac[n], Mod - 2);
	Fordown(i, n, 1) ifac[i - 1] = ifac[i] * i % Mod;

	dfs(1, 0);
	For(i, 2, m) (Ans *= (LL)i) %= Mod;
	printf("%lld\n", Ans);

    return 0;
}
