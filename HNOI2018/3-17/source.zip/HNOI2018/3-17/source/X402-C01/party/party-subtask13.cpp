/************************************************
 * Au: Hany01
 * Date: Mar 17th, 2018
 * Prob: party
 * Email: hany01@foxmail.com
************************************************/

#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("party.in", "r", stdin);
    freopen("party.out", "w", stdout);
}

const int maxn = 100005, maxm = 200005;

int n, k, v[maxm], w[maxm], nex[maxm], beg[maxn], e, sz[maxn], maxch[maxn], rt, dep[maxn], lst[maxn], cnt, nodesum, vis[maxn], m, issel[maxn];
LL dis[25][25];
LL Ans;

inline void add(int uu, int vv, int ww) { v[++ e] = vv, w[e] = ww, nex[e] = beg[uu], beg[uu] = e; }

void getrt(int u, int fa)
{
	sz[u] = 1, maxch[u] = 1;
	for (register int i = beg[u]; i; i = nex[i]) if (fa != v[i] && !vis[v[i]])
		getrt(v[i], u), sz[u] += sz[v[i]], chkmax(maxch[u], sz[v[i]]);
	chkmax(maxch[u], nodesum - sz[u]);
	if (maxch[u] < maxch[rt]) rt = u;
}

void getDepth(int u, int fa)
{
	lst[++ cnt] = dep[u];
	for (register int i = beg[u]; i; i = nex[i]) if (fa != v[i] && !vis[v[i]])
		dep[v[i]] = dep[u] + w[i], getDepth(v[i], u);
}

int Calc(int u, int bg)
{
	dep[u] = bg, cnt = 0, getDepth(u, u);
	sort(lst + 1, lst + 1 + cnt);
	register int  l = 1, r = cnt, Sum = 0;
	while (l < r) if ((LL)lst[l] + (LL)lst[r] <= (LL)k) Sum += r - l, ++ l; else -- r;
	return Sum;
}

void DFZ(int u)
{
	Ans += Calc(u, 0), vis[u] = 1;
	for (register int i = beg[u]; i; i = nex[i]) if (!vis[v[i]]) {
		Ans -= Calc(v[i], w[i]);
		nodesum = sz[v[i]], rt = 0, getrt(v[i], v[i]);
		DFZ(rt);
	}
}

void getdis(int st, int cur, LL l, int last) {
	for (register int i = beg[cur]; i; i = nex[i]) if (last != v[i])
		dis[st][v[i]] = l + (LL)w[i], getdis(st, v[i], l + (LL)w[i], cur);
}

inline void chk()
{
	For(i, 1, n) {
		register int mark = 1;
		For(j, 1, n) if (issel[j] && dis[i][j] > (LL)k) { mark = 0; break; }
		if (mark) { ++ Ans; return ; }
	}
}

inline void dfs(int cur, int fns)
{
	if (n - cur + 1 < m - fns) return ;
	if (fns == m) { chk(); return ; }
	issel[cur] = 1;
	dfs(cur + 1, fns + 1);
	issel[cur] = 0;
	dfs(cur + 1, fns);
}

int main()
{
    File();
	register int uu, vv, ww, mark = 1;
	n = read(), m = read(), k = read();
	if (m != 2) mark = 0;
	For(i, 2, n) {
		uu = read(), vv = read(), ww = read(), add(uu, vv, ww), add(vv, uu, ww);
		if (ww != 1) mark = 0;
	}
	if (mark) {
		k <<= 1;
		maxch[0] = INF, nodesum = n, rt = 0, getrt(1, 1), DFZ(rt);
		printf("%lld\n", Ans * 2);
	} else {
		For(i, 1, n) getdis(i, i, 0, 0);
		dfs(1, 0);
		For(i, 2, m) (Ans *= (LL)i) %= Mod;
		printf("%lld\n", Ans);
	}
	return 0;
}
