#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
namespace Subtask1{ void work(){
		int T=read();
		while(T--){
			int n=read(),m=read();
			ll ans=readll();
			REP(i,2,n){
				ll x=readll();
				ans=__gcd(x,ans);
			}
			if(ans<=m){
				printf("%lld\n",ans);
				continue;
			}
			DREP(i,m,1)
				if(ans%i==0 || m-i>=2e7){
					printf("%d",i);
					break;
				}
		}
	}
}
namespace Subtask3{
	void work(){
		int T=read();
		while(T--){
			int n=read(),m=read();
			ll ansx=readll(),ansy=0;
			REP(i,2,n){
				ll x=readll();
				ll u=__gcd(ansx,x),v=__gcd(ansy,x);
				if(x/u<=m) ansx=u;
				else if(x/v<=m) ansy=v;
			}
			if(ansy==0) ansy=1;
			if(ansx>ansy) swap(ansx,ansy);
			printf("%lld %lld\n",ansx,ansy);
		}
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
#endif
	int ty=read();
	if(ty==1) Subtask1::work();
	else Subtask3::work();
	return 0;
}
