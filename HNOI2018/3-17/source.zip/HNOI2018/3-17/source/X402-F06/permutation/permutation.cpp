#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e6+10,mod=998244353;
bool p[maxn];
int a[maxn],fac[maxn],ifac[maxn],d[maxn];
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return res;
}
int C(int n,int m){
	if(m>n) return 0;
	return 1ll*fac[n]*ifac[m]%mod*ifac[n-m]%mod;
}
void init(int n){
	fac[0]=1;
	REP(i,1,n) fac[i]=1ll*fac[i-1]*i%mod;
	ifac[n]=ksm(fac[n],mod-2);
	DREP(i,n-1,0) ifac[i]=1ll*ifac[i+1]*(i+1)%mod;
	d[0]=1,d[1]=0;
	REP(i,2,n) d[i]=1ll*(i-1)*(d[i-1]+d[i-2])%mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif
	int n=read(),cnt=0;
	REP(i,1,n){
		a[i]=read();
		if(a[i]) ++cnt;
		if(a[i]==i){
			printf("0\n");
			return 0;
		}
		p[a[i]]=1;
	}
	init(n);
	int ans=0,sum=cnt;
	REP(i,1,n) if(p[i] && a[i]) --sum;
	REP(i,0,sum) add(ans,1ll*d[n-cnt-i]*C(sum,i)%mod);
	printf("%d\n",ans);
	return 0;
}
