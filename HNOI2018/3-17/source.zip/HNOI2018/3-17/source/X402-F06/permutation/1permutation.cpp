#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const int maxn=1e6+10;
const long double eps=1e-9;
const int mod=998244353;
int a[maxn],vis[maxn],fac[maxn],f[maxn],inv[maxn],dp[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int fpm(int base,int b){
	int ans=1;
	while(b){
		if(b & 1)ans=1ll*ans*base%mod;
		base=1ll*base*base%mod;b/=2;
	}
	return ans;
}
inline void initialize(int n){
	int i;
	fac[0]=1;
	for(i=1;i<=n;i++)fac[i]=1ll*fac[i-1]*i%mod;
	inv[n]=fpm(fac[n],mod-2);
	for(i=n-1;i>=0;i--)inv[i]=1ll*inv[i+1]*(i+1)%mod;
	f[0]=1;f[1]=0;
	for(i=2;i<=n;i++)f[i]=1ll*(i-1)*(f[i-1]+f[i-2]);
}
inline int C(int n,int m){
	return 1ll*fac[n]*inv[m]%mod*inv[n-m]%mod;
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif
	n=read();
	initialize(n);
	for(i=1;i<=n;i++){
		a[i]=read();
		if(a[i]==i)return puts("0"),0;
		vis[a[i]]=1;
	}
	int cnt1=0,cnt2=0;
	for(i=1;i<=n;i++){
		if(!a[i] && vis[i])cnt1++;
		if(!a[i] && !vis[i])cnt2++;
	}
	if(cnt1==0)return printf("%d\n",f[cnt2]),0;
	int ans=0;
	for(i=0;i<=cnt2;i++)
		ans=(ans+1ll*C(cnt2,i)*f[cnt2-i]%mod*C(i+cnt1-1,cnt1-1)%mod*fac[i]%mod)%mod;
	printf("%d\n",1ll*ans*fac[cnt1]%mod);
	return 0;
}

