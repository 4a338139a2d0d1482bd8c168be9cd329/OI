#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10,mod=998244353,inf=0x3f3f3f3f;
int Begin[maxn],Next[maxn<<1],to[maxn<<1],w[maxn<<1],e;
inline bool chkmax(int &x,int y){return (y>x)?(x=y,1):0;}
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
	if(x<0) x+=mod;
}
void add_edge(int x,int y,int z){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
	w[e]=z;
}
int n,m,k;
int dep[maxn],d[maxn],sz[maxn],f[maxn];
bool vis[maxn];
namespace bf{
	void dfs(int x,int ff,int num){
		if(num<0) return;
		d[x]++;
		for(int i=Begin[x];i;i=Next[i]){
			if(to[i]==ff) continue;
			dfs(to[i],x,num-w[i]);
		}
	}
	void work(){
		int ans=0;
		REP(i,0,(1<<n)-1){
			if(__builtin_popcount(i)!=m) continue;
			int cnt=0;
			REP(j,1,n) d[j]=0;
			REP(j,1,n) 
				if(i&(1<<j-1)) dfs(j,0,k),++cnt;
			REP(j,1,n) if(d[j]==cnt){
				ans++;
				break;
			}
		}
		REP(i,1,m) ans=1ll*ans*i%mod;
		printf("%d\n",ans);
	}
}
namespace Subtask3{
	int cnt,ans=0,rt,tmp;
	void dfs_root(int x,int ff){
		sz[x]=1,f[x]=0;
		for(int i=Begin[x];i;i=Next[i]){
			if(to[i]==ff || vis[to[i]]) continue;
			dfs_root(to[i],x);
			chkmax(f[x],sz[to[i]]);
			sz[x]+=sz[to[i]];
		}
		chkmax(f[x],cnt-sz[x]);
		if(f[x]<f[rt]) rt=x;
	}
	void dfs_dep(int x,int ff){
		d[++tmp]=dep[x];
		for(int i=Begin[x];i;i=Next[i]){
			if(to[i]==ff || vis[to[i]]) continue;
			dep[to[i]]=dep[x]+1;
			dfs_dep(to[i],x);
		}
	}
	void calc(int x,int s,int flag){
		tmp=0;dep[x]=s;
		dfs_dep(x,0);
		sort(d+1,d+tmp+1);
		for(int L=1,R=tmp;L<R;++L){
			while(d[R]+d[L]>2*k) --R;
			if(L<R) add(ans,flag*(R-L));
		}
	}
	void solve(int x){
		vis[x]=1;
		calc(x,0,1);
		for(int i=Begin[x];i;i=Next[i]){
			if(vis[to[i]]) continue;
			calc(to[i],1,-1);
			rt=0,cnt=sz[to[i]];
			dfs_root(to[i],x);
			solve(rt);
		}
	}
	void work(){
		cnt=n;
		f[0]=inf;
		dfs_root(1,0);
		solve(rt);
		printf("%d\n",2*ans%mod);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
#endif
	n=read(),m=read(),k=read();
	bool flag=(m==2);
	REP(i,1,n-1){
		int x=read(),y=read(),z=read();
		add_edge(x,y,z),add_edge(y,x,z);
		flag&=(z==1);
	}
	if(flag) Subtask3::work();
	else if(n<=20) bf::work();
	return 0;
}
