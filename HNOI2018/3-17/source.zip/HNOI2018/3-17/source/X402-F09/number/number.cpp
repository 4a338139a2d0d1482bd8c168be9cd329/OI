#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
inline void readl(long long &x){
    int p=1;
    char c=getchar();
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=(long long)p;
}
inline long long _max(long long a,long long b){
    return a>b?a:b;
}
inline long long _min(long long a,long long b){
    return a>b?b:a;
}
inline long long gcd(long long a,long long b){
    return b?gcd(b,a%b):a;
}
const int maxn=10005;
const int inf=1e9+10;
long long a[maxn],_,__,Gcd;
int sub,T;
bool flag;
int main(){
    freopen("number.in","r",stdin);
    freopen("number.out","w",stdout);
    read(sub);read(T);
    srand(20021116);
    while(T--){
        flag=1;
        int n,m;
        read(n);read(m);
        for(register int i=1;i<=n;++i){
            readl(a[i]);
        }
        Gcd=a[1];
        for(register int i=2;i<=n;++i){
            Gcd=gcd(Gcd,a[i]);
        }
        for(register int i=1;i<=n;++i){
            a[i]/=Gcd;
        }
        while(1){
            long long x=gcd(a[rand()%n+1],a[rand()%n+1]),y=0;
            flag=1;_=inf;__=inf;
            for(register int i=1;i<=n;++i){
                if(a[i]%x!=0||a[i]/x>m){
                    if(y==0)y=a[i];
                    else y=gcd(y,a[i]);
                }
            }
            if(y==0)y=x;
            if(x*Gcd>m||y*Gcd>m)continue;
            for(register int i=1;i<=n;++i){
                if((a[i]%x)&&(a[i]%y)){
                    flag=0;
                    break;
                }
                if((a[i]%x)==0)_=a[i]/x;
                if((a[i]%y)==0)__=a[i]/y;
                if((_>m)&&(__>m)){
                    flag=0;
                    break;
                }
            }
            if(flag){
                printf("%d %d\n",(int)(_min(x,y)*Gcd),(int)(_max(x,y))*Gcd);
                break;
            }
        }
    }
    return 0;
}
