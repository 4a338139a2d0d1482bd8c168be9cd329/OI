#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=100010;
const long long mod=998244353;
int head[maxn],tot,n,m,a[maxn],vis[maxn],k;
long long dis[maxn],ans,tmp;
struct edge{
    int to,next,w;
}e[maxn<<1];
inline void add(int u,int v,int w){
    e[++tot].to=v;
    e[tot].next=head[u];
    e[tot].w=w;
    head[u]=tot;
}
long long spfa(int x,int y){
	if(x==y)return 0;
    memset(dis,0,sizeof(dis));
    memset(vis,0,sizeof(vis));
	vis[x]=1;
    dis[x]=0;
	queue<int>qu;
	qu.push(x);
	while(!qu.empty()){
		int u=qu.front();
        bool flag=0;
		qu.pop();
		for(register int i=head[u];i;i=e[i].next){
			int v=e[i].to;
			dis[v]=dis[u]+(long long)e[i].w;
			if(v==y){
				flag=1;
				break;
			}
			if(!vis[v]){
				vis[v]=1;
				qu.push(v);
			}
		}
		if(flag)break;
	}
	return dis[y];
}
bool check(int x){
	for(register int i=1;i<=n;++i){
		if(a[i]!=0&&spfa(i,x)>k){
            return false;
        }
	}
	return true;
}
void dfs(int x,int pos){
	if(x==m+1){
		for(register int i=1;i<=n;++i){
            if(check(i)){
			    ans++;
                break;
            }
		}
		return ;
	}
	for(register int i=pos;i<=n;++i){
		a[i]=1;
		dfs(x+1,i+1);
		a[i]=0;
	}
}
int main(){
    freopen("party.in","r",stdin);
    freopen("party.out","w",stdout);
	read(n);read(m);read(k);
	for(register int i=1;i<=n-1;++i){
		int u,v,w;
		read(u);read(v);read(w);
		add(v,u,w);
		add(u,v,w);
	}
	dfs(1,1);	
	tmp=1;
	for(register int i=1;i<=m;++i){
        tmp=(tmp*1ll*i)%mod;
    }
    (ans*=tmp)%=mod;
	printf("%lld\n",ans);
	return 0;
}
