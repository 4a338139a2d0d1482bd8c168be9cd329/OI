#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
int n,p[25],a[25],ans;
int main(){
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    read(n);
    for(register int i=1;i<=n;++i){
        read(a[i]);
    }
    for(register int i=1;i<=n;++i){
        p[i]=i;
    }
    while(next_permutation(p+1,p+1+n)){
        bool flag=0;
        for(register int i=1;i<=n;++i){
            if(p[i]!=i){
                if(a[i]!=0){
                    if(a[i]!=p[i]){
                        flag=1;
                        break;
                    }
                }
            }
            else{
                flag=1;
                break;
            }
        }
        if(flag==0){
            ans++;
        }
    }
    printf("%d\n",ans);
    return 0;
}
