TP class BCS{
private :
	#define BCS_GLOBLE_INITLIZE \
	node **now =  &first; \
	UI   _noi  =  MaxUI ;
	
	#define BCS_RETURN_NULL( Way ) if( Way )return NTP;
	#define BCS_RETURN( Val ) if( IsNothing(*now) )return Val;
	
	#define BCS_RESUME_NEXT _noi >>= 1;
	#define BCS_GET_LVAL int Lval = ( (*now) -> left == NULL ? 0 : (*now) -> left -> size ); 
	#define BCS_MOVE_NOW( Con, Add )now = &( Con ? Add,(*now) -> right:(*now) -> left );
	
	#define BCS_MATCH ( _noi & num )
	
	#define BCS_NOW (*now)
	#define BCS_VALUE ( BCS_NOW -> value )
	
	#define BCS_NORMAL_RUN_LOOP while( _noi )
	struct node{
		tp value;
		UI size ;
		
		node *left;
		node *right;
		
		node (){
			left = right = Nothing;
			size = 0;
			value = NTP;
		}
	};
	const UI MaxUI = 2147483648;
	node  *first;
public:
	
	BCS() : first(new node()){}
	
	IN Sub push( UI num, tp value){
		BCS_GLOBLE_INITLIZE
		
		BCS_NORMAL_RUN_LOOP{
			BCS_NOW -> size ++;
			
			BCS_MOVE_NOW    ( BCS_MATCH , 0 )
			BSC_RETURN_NULL ( IsNothing(*now) );
			BCS_RESUME_NEXT
		}
		BCS_NOW -> size ++;
		BCS_NOW -> value = value;
	}
	
	IN tp& get( UI num){
		BCS_GLOBLE_INITLIZE
		
		BCS_NORMAL_RUN_LOOP{
			BCS_MOVE_NOW    ( BCS_MATCH , 0 )
			BSC_RETURN_NULL ( IsNothing(*now) );
			BCS_RESUME_NEXT
		}
		
		BCS_RETURN( BCS_NOW );
	}
	
	IN tp& find_by_rank( UI rank){
		BCS_GLOBLE_INITLIZE
		
		BCS_NORMAL_RUN_LOOP{
			BCS_RETURN_NULL ( rank > BCS_NOW -> size )
			BCS_GET_LVAL
			BCS_MOVE_NOW    ( rank > Lval , rank -= Lval )
			BCS_RESUME_NEXT
		}
		
		BCS_RETURN( BCS_NOW );
	}
	
	IN UI get_rank( UI num){
		BCS_GLOBLE_INITLIZE
		UI rank = 0;
		
		BCS_NORMAL_RUN_LOOP{
			BCS_GET_LVAL
			BCS_MOVE_NOW    ( BCS_MATCH , rank += Lval )
			BCS_RETURN      ( rank )
			BCS_RESUME_NEXT
		}
		
		BCS_RETURN( rank + 1 );
	}
};
