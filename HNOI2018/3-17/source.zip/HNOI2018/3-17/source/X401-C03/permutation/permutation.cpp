#include<bits/stdc++.h>
using namespace std;
const long long mod = 998244353;

int  line[100005];
long long S[100005];
long long J[100005];

long long x,y;

void exgcd(int a,int b){
    if(b==0){
        x=1;y=0;
        return ;
    }
    exgcd(b,a%b);
    int k=x;
    x=y;
    y=k-(a/b)*y;
    return ;
}

long long combo(int a,int b){
	exgcd(J[b],mod);
	int n = (x % mod + mod) % mod;
	exgcd(J[a - b],mod);
	int m = (x % mod + mod) % mod;
	return J[a] * n * m % mod;
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int m;cin >> m;
	for(int i = 1;i <= m;i ++){
		cin >> line[i];
	}
	S[2] = 1;S[3] = 2;
	for(int i = 4;i <= m;i ++){
		S[i] = (S[i - 1] + S[i - 2]) * (i - 1) % mod;
	}
	J[0] = J[1] = 1;
	for(int i = 2;i <= m;i ++){
		J[i] = J[i - 1] * i % mod;
	}
	int all = 0,nofline = 0;
	for(int i = 1;i <= m;i ++){
		if(!line[i])all ++;
		else{
			if(!line[ line[i] ])nofline ++;
		}
	}
	long long ans = 0;
	int ofline = all - nofline;
	for(int i = 0;i <= ofline;i ++){
		ans += S[ofline - i] * combo(nofline,i) % mod;
		ans %= mod;
	}
	cout << ans * combo(all,nofline) % mod;
	return 0;
}
