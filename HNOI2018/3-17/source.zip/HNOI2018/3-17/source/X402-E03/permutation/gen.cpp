#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1e6+5 ;
int v[maxn], a[maxn], n, m ;
bool vis[maxn] ;
bool cmp ( int x, int y ) {
	return v[x] < v[y] ;
}
int main() {
	freopen ( "permutation.in", "w", stdout ) ;
	srand(time(0)) ;
	int i, maxN = 16 ;
	n = rand()%maxN+1 ;
	//n = 1e6 ;
	m = rand()%n+1 ;
	cerr << m << endl ;
	while (m--) vis[rand()%n+1] = 1 ;
	for ( i = 1 ; i <= n ; i ++ )
		a[i] = i, v[i] = rand() ;
	sort(a+1, a+n+1, cmp) ;
	printf ( "%d\n", n ) ;
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%d ", vis[i]*a[i] ) ;
	return 0 ;
}
