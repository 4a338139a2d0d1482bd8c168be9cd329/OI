#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 23, Mod = 998244353 ;
int n, m, a[maxn], d[maxn], ans ;
bool vis[maxn] ;
void dfs ( int stp ) {
	if (stp > n) {
		++ ans ;
		return ;
	}
	if (a[stp]) d[stp] = a[stp], dfs(stp+1) ;
	else {
		for ( int i = 1 ; i <= n ; i ++ )
			if (!vis[i] && i!=stp) {
				vis[i] = 1 ;
				d[stp] = i ;
				dfs(stp+1) ;
				vis[i] = 0 ;
			}
	}
}
int main() {
	freopen ( "permutation.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;
	int i ;
	while (cin >> n) {
		memset (vis, 0, sizeof vis) ;
		for ( i = 1 ; i <= n ; i ++ ) Read(a[i]), vis[a[i]] = 1 ;
		ans = 0 ;
		dfs(1) ;
		cout << ans << endl ;
	}
	return 0 ;
}
