#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxN = 1e6, Mod = 998244353 ;
LL Qpow ( LL a, LL b, LL rec = 1 ) {
	for ( ; b ; b >>= 1, (a *= a) %= Mod )
		if (b&1) (rec *= a) %= Mod ;
	return rec ;
}
LL f[maxN+5], n, m, a[maxN+5], fac[maxN+5], inv[maxN+5], rdn[maxN+5] ;
void init() {
	LL i ;
	fac[0] = 1 ;
	for ( i = 1 ; i <= maxN ; i ++ )
		fac[i] = fac[i-1]*i%Mod ;
	inv[maxN] = Qpow(fac[maxN], Mod-2) ;
	for ( i = maxN ; i ; i -- )
		inv[i - 1] = inv[i]*i%Mod ;
}
LL C ( LL x, LL y ) {
	LL rec = fac[x] ;
	if (y > x) return 0 ;
	(rec *= inv[y]) %= Mod ;
	(rec *= inv[x-y]) %= Mod ;
	return rec ;
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "permutation.in", "r", stdin ) ;
	freopen ( "permutation.out", "w", stdout ) ;
#endif
	init() ;
	LL i, fri, fbd, ans ;
	while (cin >> n) {
		ans = 0 ;
		for ( i = 1 ; i <= n ; i ++ ) Read(a[i]), rdn[a[i]] = i ;
		fri = n ;
		fbd = 0 ;
		for ( i = 1 ; i <= n ; i ++ )
			if (a[i]) fri -- ;
			else if (!rdn[i]) fbd ++ ;
		//printf ( "free=%lld fbd=%lld\n", fri, fbd ) ;
		for ( i = 0 ; i <= fbd ; i ++ )
			if (i&1) ans = (ans + Mod - C(fbd,i)*fac[fri-i]%Mod)%Mod ;
			else (ans += C(fbd,i)*fac[fri-i]%Mod) %= Mod ;
		printf ( "%lld\n", ans ) ;
	}
	return 0 ;
}
