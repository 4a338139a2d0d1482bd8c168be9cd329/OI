#include<bits/stdc++.h>
#define L long long
#define pb push_back
using namespace std;
const int q=998244353;
int n,m,t,f[100010];
inline int ran()
{
	return (rand()<<15)+rand();
}
inline int fa(int i)
{
	return f[i]==i?i:fa(f[i]);
}
int main()
{
	srand(time(0));
	ran();
	freopen("party3-2.in","w",stdout);
	int i,j,k,l;
	n=100000;
	m=2;
	t=10000;
	printf("%d %d %d\n",n,m,t);
	for(i=1;i<=n;i++)
	  f[i]=i;
	for(i=1;i<n;i++)
	  {
	   if(i%100==0 || i>n-100)
	   	 cerr<<i<<"\n";
	   if(i<=20000)
	     j=i,k=i+1;
	   else
	   do
	     {
	      j=ran()%n+1;
	      k=ran()%n+1;
	     }
	   while(fa(j)==fa(k));
	   f[fa(j)]=fa(k);
	   printf("%d %d %d\n",j,k,1);
	  }
	return 0;
}

