#include<bits/stdc++.h>
#define L long long
using namespace std;
const int q=998244353;
int n,x[1000010];
inline int ran()
{
	return (rand()<<15)+rand();
}
int main()
{
	srand(time(0));
	ran();
	freopen("permutation4.in","w",stdout);
	int i,j,k,l;
	n=1000000;
	for(i=1;i<=n;i++)
	  {
	   x[i]=i;
	   swap(x[i],x[ran()%i+1]);
	  }
	for(i=1;i<=n;i++)
	  if(x[i]==i || ran()&1)
	    x[i]=0;
    printf("%d\n",n);
    for(i=1;i<=n;i++)
      printf("%d ",x[i]);
    printf("\n");
	return 0;
}
