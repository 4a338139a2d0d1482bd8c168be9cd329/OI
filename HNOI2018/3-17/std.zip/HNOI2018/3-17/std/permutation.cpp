#include<bits/stdc++.h>
#define L long long
using namespace std;
const int q=998244353;
char ch,B[1<<20],*S=B,*T=B;
#define getc() (S==T&&(T=(S=B)+fread(B,1,1<<20,stdin),S==T)?0:*S++)
#define isd(c) (c>='0'&&c<='9')
L aa,bb;L F(){
    while(ch=getc(),!isd(ch)&&ch!='-');ch=='-'?aa=bb=0:(aa=ch-'0',bb=1);
    while(ch=getc(),isd(ch))aa=aa*10+ch-'0';return bb?aa:-aa;
}
#define gi F()
int n,a[1000010],b[1000010],p;
bool x[1000010],y[1000010];
inline int C(int n,int m)
{
    return (L)a[n]*b[m]%q*b[n-m]%q;
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int i,j,k,l;
	n=gi;
	a[0]=b[0]=b[1]=1;
	for(i=2;i<=n;i++)
	  b[i]=q-(L)q/i*b[q%i]%q;
	for(i=1;i<=n;i++)
	  {
	   a[i]=(L)a[i-1]*i%q;
	   b[i]=(L)b[i-1]*b[i]%q;
      }
	for(i=1;i<=n;i++)
	  {
       j=gi;
       if(j)
         x[i]=y[j]=1;
      }
    for(i=1,j=k=0;i<=n;i++)
      if(!x[i])
        if(!y[i])
          j++;
        else
          k++;
    for(i=0,l=1;i<=j;i++,l*=-1)
      p=(p+(L)l*C(j,i)*a[j+k-i])%q;
    p=(p+q)%q;
    printf("%d\n",p);
	return 0;
}
