#include<bits/stdc++.h>
#define L long long
using namespace std;
char ch,B[1<<20],*S=B,*T=B;
#define getc() (S==T&&(T=(S=B)+fread(B,1,1<<20,stdin),S==T)?0:*S++)
#define isd(c) (c>='0'&&c<='9')
L aa,bb;L F(){
    while(ch=getc(),!isd(ch)&&ch!='-');ch=='-'?aa=bb=0:(aa=ch-'0',bb=1);
    while(ch=getc(),isd(ch))aa=aa*10+ch-'0';return bb?aa:-aa;
}
#define gi F()
int t,n,m;
L x[5010];
inline L gcd(L n,L m)
{
    return m?gcd(m,n%m):n;
}
inline bool check(L u,L v)
{
	int i;
	for(i=1;i<=n;i++)
	  if(!(!(x[i]%u) && x[i]/u<=m || !(x[i]%v) && x[i]/v<=m))
	    return 0;
	return 1;
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int i;
	L k,l,u,v;
	i=gi;
	t=gi;
	while(t--)
	  {
       n=gi;
       m=gi;
       for(i=1;i<=n;i++)
         x[i]=gi;
       for(i=1,k=0;i<=n;i++)
         k=gcd(k,x[i]);
       for(i=1;i<=n;i++)
         x[i]/=k;
       /*do
         {
          swap(x[n],x[((rand()<<15)+rand())%n+1]);
          for(i=1,u=0;i<n;i++)
            if(gcd(x[i],x[n])==1)
              u=gcd(u,x[i]);
         }
       while(!u);
       if(u>1)
         {
          for(i=1,v=0;i<=n;i++)
            if(x[i]%u)
              v=gcd(v,x[i]);
         }
       else
         {
		  sort(x+1,x+n+1);
          l=(x[n]-1)/m+1;
          for(i=n,u=v=0;i>0;i--)
            if(gcd(u,x[i])<l)
              v=gcd(v,x[i]);
            else
              u=gcd(u,x[i]);
         }
       if(!v)
         v=u;*/
       do
         {
          u=gcd(x[((rand()<<15)+rand())%n+1],x[((rand()<<15)+rand())%n+1]);
          for(i=1,v=0;i<=n;i++)
            if(x[i]%u || x[i]/u>m)
              v=gcd(v,x[i]);
          if(!v)
            v=u;
         }
       while(!check(u,v));
       if(check(u,u))
         v=u;
       if(check(v,v))
         u=v;
       if(u>v)
         swap(u,v);
       if(v*k<=m)
         printf("%lld %lld\n",u*k,v*k);
       else
         printf("0 0\n");
      }
	return 0;
}

