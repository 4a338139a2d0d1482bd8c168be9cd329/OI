#include<bits/stdc++.h>
#define L long long
#define pb push_back
using namespace std;
const int q=998244353;
int n,m,t,fa[100010],u[100010],w[100010],c[100010],d[100010],p;
L f[100010],g[100010],h[100010];
vector<int> a[100010],b[100010];
inline int C(int n,int m)
{
	if(n<m)
	  return 0;
	return (L)c[n]*d[m]%q*d[n-m]%q;
}
inline void dp(int i)
{
	int j;
	w[i]=1;
	for(j=0;j<a[i].size();j++)
	  if(a[i][j]!=fa[i])
	    {
	     fa[a[i][j]]=i;
	     u[a[i][j]]=b[i][j];
	     dp(a[i][j]);
	     w[i]+=w[a[i][j]];
	     L k=f[a[i][j]]+b[i][j];
	     if(k>f[i])
	       h[i]=f[i],f[i]=k;
	     else
	       h[i]=max(h[i],k);
	 	}
}
inline void dp2(int i)
{
	int j;
	for(j=0;j<a[i].size();j++)
	  if(a[i][j]!=fa[i])
	    {
	     L k=f[a[i][j]]+b[i][j];
	     if(k==f[i])
	       g[a[i][j]]=max(g[i]+u[i],h[i]);
	     else
	       g[a[i][j]]=max(g[i]+u[i],f[i]);
	     dp2(a[i][j]);
	    }
}
inline int dfs(int i,int j,int k)
{
	if(k<0)
	  return 0;
	if(j==fa[i])
	  if(f[i]<=k)
	    return w[i];
	if(j && j!=fa[i])
	  if(g[j]<=k)
	    return w[1]-w[j];
	if(!j)
	  if(f[i]<=k && g[i]+u[i]<=k)
		return n;
	int l,p=1;
	for(l=0;l<a[i].size();l++)
	  if(a[i][l]!=j)
	    p+=dfs(a[i][l],i,k-b[i][l]);
	return p;
}
int main()
{
	freopen("party.in","r",stdin);
	freopen("party.out","w",stdout);
	int i,j,k,l;
	scanf("%d%d%d",&n,&m,&t);
	for(i=1;i<n;i++)
	  {
	   scanf("%d%d%d",&j,&k,&l);
	   a[j].pb(k);
	   b[j].pb(l);
	   a[k].pb(j);
	   b[k].pb(l);
	  }
	c[0]=d[0]=d[1]=1;
	for(i=2;i<=n;i++)
	  d[i]=q-(L)q/i*d[q%i]%q;
	for(i=1;i<=n;i++)
	  {
	   c[i]=(L)i*c[i-1]%q;
	   d[i]=(L)d[i]*d[i-1]%q;
	  }
	dp(1);
	dp2(1);
	for(i=1;i<=n;i++)
	  {
	   j=dfs(i,0,t);
	   k=(i==1?0:(dfs(fa[i],i,t-u[i])+dfs(i,fa[i],t-u[i])));
	   p=(p+C(j,m)-C(k,m))%q;
	  }
	p=(L)p*c[m]%q;
	p=(p+q)%q;
	printf("%d\n",p);
	return 0;
}

