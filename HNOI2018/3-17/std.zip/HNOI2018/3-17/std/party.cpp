#include <iostream>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <string>
#include <bitset>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <sstream>
#include <stack>
#include <iomanip>
using namespace std;
#define pb push_back
#define mp make_pair
typedef pair<int,int> pii;
typedef long long ll;
typedef double ld;
typedef vector<int> vi;
#define fi first
#define se second
#define fe first
#define FO(x) {freopen(#x".in","r",stdin);freopen(#x".out","w",stdout);}
#define Edg int M=0,fst[SZ],vb[SZ],nxt[SZ];void ad_de(int a,int b){++M;nxt[M]=fst[a];fst[a]=M;vb[M]=b;}void adde(int a,int b){ad_de(a,b);ad_de(b,a);}
#define Edgc int M=0,fst[SZ],vb[SZ],nxt[SZ],vc[SZ];void ad_de(int a,int b,int c){++M;nxt[M]=fst[a];fst[a]=M;vb[M]=b;vc[M]=c;}void adde(int a,int b,int c){ad_de(a,b,c);ad_de(b,a,c);}
#define es(x,e) (int e=fst[x];e;e=nxt[e])
#define esb(x,e,b) (int e=fst[x],b=vb[e];e;e=nxt[e],b=vb[e])
#define SZ 555555
const int MOD=998244353;
ll fac[SZ],rfac[SZ];
ll qp(ll a,ll b)
{
	ll x=1; a%=MOD;
	while(b)
	{
		if(b&1) x=x*a%MOD;
		a=a*a%MOD; b>>=1;
	}
	return x;
}
ll C(int n,int m)
{
	if(m>n||m<0) return 0;
	return fac[n]*rfac[n-m]%MOD*rfac[m]%MOD;
}
Edgc
int n,m,k,fa[SZ],sz[SZ],son[SZ],pos[SZ];
ll fe[SZ],dep[SZ];
pair<ll,int> vs[SZ];
void dfs(int x,int f=0)
{
	fa[x]=f; sz[x]=1;
	for esb(x,e,b) if(b!=f)
	{
		fe[b]=vc[e];
		dep[b]=dep[x]+vc[e];
		dfs(b,x); sz[x]+=sz[b];
		if(sz[b]>sz[son[x]]) son[x]=b;
	}
}
//dsu on tree�󷨺ã���־�������
int ps[SZ],pn=0;
ll su[SZ]; bool in[SZ];
ll bb[SZ];
void edt(int x,int y)
{for(;x<=n;x+=x&-x) bb[x]+=y;}
ll gsum(int l)
{
	ll s=0;
	for(;l>=1;l-=l&-l) s+=bb[l];
	return s;
}
ll tag[SZ];
void put_tag(int l,int r,int v)
{
	for(l+=M-1,r+=M+1;l^r^1;l>>=1,r>>=1)
	{
		if(~l&1) tag[l^1]+=v;
		if(r&1) tag[r^1]+=v;
	}
}
void pd(int x)
{
	if(x<=M)
		tag[x+x]+=tag[x],
		tag[x+x+1]+=tag[x],
		tag[x]=0;
	else
	{
	if(in[vs[x-M].se])
	//	cerr<<"QTMD"<<vs[x-M].se<<"w"<<tag[x]<<"\n",
		su[vs[x-M].se]+=tag[x];
	tag[x]=0;
	}
}
ll gsum(int l,int r)
{return gsum(r)-gsum(l-1);}
void qry_pnt(int x,ll v)
{
	//dep[a]+dep[b]-v<=k
	int r=lower_bound(vs+1,vs+1+n,
	mp(k+v-dep[x],int(1e9)))-vs-1;
	su[x]+=gsum(1,r); put_tag(1,r,1);
	//cerr<<"qry"<<x<<"  <="<<k+v-dep[x]<<" "<<gsum(1,r)<<"\n";
}
void pdc(int x)
{
	//cerr<<"pdc"<<x<<"\n";
	static int ss[23]; int sn=0;
	for(x=pos[x]+M;x;x>>=1) ss[++sn]=x;
	while(sn) pd(ss[sn--]);
}
void ins_pnt(int x)
{
	//cerr<<"ins"<<x<<"  "<<dep[x]<<"\n";
	ps[++pn]=x; pdc(x);
	in[x]=1; edt(pos[x],1);
}
void clr_pnt(int x)
{
	//cerr<<"clr"<<x<<"\n";
	edt(pos[x],-1);
	pdc(x); in[x]=0;
}
void qry_sub(int x,int f,ll v)
{
	qry_pnt(x,v);
	for esb(x,e,b) if(b!=f)
		qry_sub(b,x,v);
}
void ins_sub(int x,int f)
{
	ins_pnt(x);
	for esb(x,e,b) if(b!=f)
		ins_sub(b,x);
}
void clr()
{
	while(pn) clr_pnt(ps[pn--]);
	//cerr<<"==\n";
}
ll v2[SZ];
void dsu(int x,bool ke,int f=0)
{
	for esb(x,e,b)
		if(b!=son[x]&&b!=f) dsu(b,0,x);
	if(son[x]) dsu(son[x],1,x);
	//cerr<<"CURRENT AT "<<x<<"<-"<<f<<"  "<<k<<"\n";
	qry_pnt(x,dep[x]*2LL); ins_pnt(x);
	for esb(x,e,b)
		if(b!=son[x]&&b!=f)
		{
			qry_sub(b,x,dep[x]*2LL);
			ins_sub(b,x);
		}
	//>k-fe[x]  <=k
	v2[x]=gsum(lower_bound(vs+1,vs+1+n,
	mp(k+dep[x],int(1e9)))-vs-1)
	-gsum(lower_bound(vs+1,vs+1+n,
	mp(k-fe[x]+dep[x],int(1e9)))-vs-1);
	if(!ke) clr();
}
int main()
{
	FO(party)
	fac[0]=1;
	for(int i=1;i<SZ;++i) fac[i]=fac[i-1]*i%MOD;
	rfac[SZ-1]=qp(fac[SZ-1],MOD-2);
	for(int i=SZ-1;i>=1;--i)
		rfac[i-1]=rfac[i]*i%MOD;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1,a,b,c;i<n;++i)
		scanf("%d%d%d",&a,&b,&c),
		adde(a,b,c);
	dfs(1);
	for(int i=1;i<=n;++i)
		vs[i]=mp(dep[i],i);
	sort(vs+1,vs+1+n);
	for(int i=1;i<=n;++i)
		pos[vs[i].se]=i;
	for(int i=1;i<=n;++i) su[i]++;
	dsu(1,0); v2[1]=su[1];
	ll ans=0;
	for(int i=1;i<=n;++i)
		ans+=C(su[i],m)-C(su[i]-v2[i],m),ans%=MOD;
	ans=(ans%MOD+MOD)%MOD;
	for(int i=1;i<=m;++i) ans=ans*i%MOD;
	ans=(ans%MOD+MOD)%MOD;
	printf("%d\n",int(ans));
	cerr<<clock()<<"ms\n";
}

