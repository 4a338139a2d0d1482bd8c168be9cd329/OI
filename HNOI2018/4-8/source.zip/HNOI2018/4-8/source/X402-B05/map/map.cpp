#include<bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)) {k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		printf("0");
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxm=5000;
const int maxn=300+50;
int m,n,S,T,id;
int to[maxm],po[maxn],ne[maxm],w[maxm],p[maxn],sum;
int h[maxn];
queue<int> q;
void add(int x,int y,int z)
{
	id++;to[id]=y;w[id]=z;ne[id]=po[x];po[x]=id;
}
bool bfs()
{
	memcpy(p,po,sizeof(po));
	while (!q.empty()) q.pop();
	memset(h,-1,sizeof(h));
	q.push(S);h[S]=1;
	int u=0,v=0;
	while (!q.empty())
	{
		u=q.front();q.pop();
		for (int i=po[u];i;i=ne[i])
		{
			v=to[i];
			if (h[v]==-1&&w[i]>0)
			{
				h[v]=h[u]+1;
				q.push(v);
			}
		}
	}
	return h[T]!=-1;
}
int dfs(int u,int low)
{
	if (u==T||low==0) return low;
	int used=0,v;
	for (int i=p[u];i;i=ne[i])
	{
		if (h[to[i]]==h[u]+1)
		{
			int W=dfs(to[i],min(low-used,w[i]));
			used+=W;
			p[u]=i;
			w[i]-=W;w[i^1]+=W;
			if (used==low) return low;
		}
	}
	if (used==0) h[u]=-1;
	return used;
}
int ans;
int X[maxm],Y[maxm];
int main()
{
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	while (true);
	n=read();m=read();
	for (int i=1;i<=m;i++)
	{
		X[i]=read();Y[i]=read();
	}
	S=rand()%n+1;
	ans=m;
	for (int i=1;i<=n;i++)
	{
		id=1;
		memset(po,0,sizeof(po));
		if (i==S) continue;
		T=i;
		for (int j=1;j<=m;j++)
		{
			add(X[j],Y[j],1);
			add(Y[j],X[j],1);
		}
		sum=0;
		while (bfs())
		{
			sum+=dfs(S,m);
		}
		qmin(ans,sum);
	}
	cout<<ans;
}
/*
��һ����������N,M ����������ʾ��
������M �У�ÿ������������x,y����ʾx ��y ֮����һ�������
*/

