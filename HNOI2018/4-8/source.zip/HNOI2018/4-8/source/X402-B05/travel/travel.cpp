#include<bits/stdc++.h>
#define int long long
#define ld long double
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)) {k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		printf("0");
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int mod=10007;
const int maxn=100000;
int ksm(int x,int y)
{
	x%=mod;
	int sum=1;
	while (y)
	{
		if (y%2==1) sum=sum*x%mod;
		x=x*x%mod;
		y/=2; 
	}
	return sum;
}
int n,c,p,I,X,Y;
int A[maxn],B[maxn];
int dp[maxn][22];
int ans,id,sum;
void work()
{	
	memset(dp,0,sizeof(dp));
	dp[0][0]=1;
	for (int i=1;i<=n;i++)
	{
		dp[i][0]=dp[i-1][0]*B[i]%mod;
		for (int j=1;j<c;j++)
		{
			dp[i][j]=B[i]*dp[i-1][j]%mod+A[i]*dp[i-1][j-1]%mod;
			if (dp[i][j]>=mod) dp[i][j]-=mod;
		}
	}
	ans=1;
	for (int i=1;i<=n;i++) ans=ans*(A[i]+B[i])%mod;
	sum=ans;
	for (int i=0;i<c;i++) 
	{
		ans-=dp[n][i];ans%=mod;
	}
	ans=(ans%mod+mod)%mod;
//	printf("%d\n",ans);
}
int na[maxn],nb[maxn],nab[maxn];
signed main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read();c=read();
	if (n<=1000)
	{
		for (int i=1;i<=n;i++) A[i]=read()%mod;
		for (int i=1;i<=n;i++) B[i]=read()%mod;
		p=read();
		for (int i=1;i<=p;i++)
		{
			I=read();X=read();Y=read();
			A[I]=X;B[I]=Y;
			work();
			printf("%d\n",ans);
		}
		return 0;
	}
	for (int i=1;i<=n;i++) A[i]=read()%mod,na[i]=ksm(A[i],mod-2);
	for (int i=1;i<=n;i++) B[i]=read()%mod,nb[i]=ksm(B[i],mod-2),nab[i]=ksm(A[i]+B[i],mod-2);
	p=read();
	work();
	id=n;
	while (p--)
	{
		I=read();X=read()%mod;Y=read()%mod;
		dp[n-1][0]=dp[n][0]*nb[I]%mod;
		for (int i=1;i<c;i++)
		{
			dp[n-1][i]=(dp[n][i]-A[I]*dp[n-1][i-1]%mod)*nb[I]%mod;
			dp[n-1][i]=dp[n-1][i]%mod;
		}
		na[I]=ksm(X,mod-2);nb[I]=ksm(Y,mod-2);
		A[I]=X;B[I]=Y;
		dp[n][0]=dp[n-1][0]*Y%mod;
		for (int j=1;j<c;j++)
		{
			dp[n][j]=B[I]*dp[n-1][j]%mod+A[I]*dp[id-1][j-1]%mod;
			dp[n][j]%=mod;
		}

		sum=sum*nab[I]%mod*((X+Y)%mod)%mod;
		nab[I]=ksm(X+Y,mod-2);
		ans=sum;
		for (int i=0;i<c;i++) 
		{
			ans-=dp[n][i];ans%=mod;
		}
		ans=(ans%mod+mod)%mod;
		printf("%d\n",ans);
	}
}
