#include<bits/stdc++.h>
#define LL long long
#define int long long
inline LL read(){
	char c=getchar();while (c!='-'&&(c<'0'||c>'9'))c=getchar();
	LL k=0,kk=1;if (c=='-')c=getchar(),kk=-1;
	while (c>='0'&&c<='9')k=k*10+c-'0',c=getchar();return kk*k;
}using namespace std;
void write(LL x){if (x<0)x=-x,putchar('-');if (x/10)write(x/10);putchar(x%10+'0');}
void writeln(LL x){write(x);puts("");}
int n,c,sum,f[1000010],g[1000010],a[1000010],b[1000010],na[1000010],nb[1000010],lsg,ans,q;
int ksm(int x,int y){
	int ans=1;while (y){
		if (y&1)(ans*=x)%=lsg;(x*=x)%=lsg;y>>=1;
	}return ans;
}
signed main(){
	n=read();c=read();lsg=10007;ans=f[0]=1;
	for (int i=1;i<=n;i++)a[i]=read()%lsg,na[i]=ksm(a[i],lsg-2);
	for (int i=1;i<=n;i++)b[i]=read()%lsg,nb[i]=ksm(b[i],lsg-2);
	for (int l=1;l<=n;l++){
		for (int i=0;i<=c;i++) g[i]=f[i];
		(ans*=a[l]+b[l])%=lsg;
		f[0]=g[0]*b[l]%lsg;for (int i=1;i<=c;i++)(f[i]=g[i-1]*a[l]+g[i]*b[l])%=lsg;
		}
		
		q=read();while (q--)
		{
		int i=read();(ans*=ksm(a[i]+b[i],lsg-2))%=lsg;
		g[0]=f[0]*nb[i]%lsg;
		for (int j=1;j<=c;j++) g[j]=(f[j]-g[j-1]*a[i])*nb[i]%lsg;
		
		a[i]=read()%lsg;b[i]=read()%lsg;
		na[i]=ksm(a[i],lsg-2);
		nb[i]=ksm(b[i],lsg-2);
		(ans*=a[i]+b[i])%=lsg;
		f[0]=g[0]*b[i]%lsg;
		for (int j=1;j<=c;j++) (f[j]=g[j-1]*a[i]+g[j]*b[i])%=lsg;
		for (int i=0;i<c;i++)sum+=f[i];sum%=lsg;
		writeln(((ans-sum)%lsg+lsg)%lsg);sum=0;
	}
}
/*
f[i][j]=f[i-1][j-1]*a[i]+f[i-1][j]*b[i]
f[i-1][0]=f[i][0]/b[i]
f[i-1][j]=(f[i][j]-f[i-1][j-1]*a[i])/b[i]
4 2
1 2 3 4
1 2 3 4
1
4 1 1
*/
