#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
const int mod=1e6;
int n, m, q;

int main(){
	freopen("map.in","w",stdout);

	srand(time(0));
	n=10;
	m=n;
	printf("%d %d\n", n, m);
	if(0){
		m=n-1;
		for(int i=1;i<=n;i++) printf("1 "); puts("");
		for(int i=2;i<=n;i++) printf("%d %d\n", i-1, i);
	}else{
		for(int i=1;i<=n;i++) printf("%d ", rand()%mod+1); puts("");
		for(int i=2;i<=n;i++) printf("%d %d\n", rand()%(i-1)+1, i);
		printf("%d %d\n", rand()%n+1, rand()%n+1);
	}
	printf("%d\n", q=1000);
	for(int i=1;i<=q;i++){
		printf("%d %d %d\n", rand()&1, rand()%n+1, rand()%mod+1);
	}
	return 0;
}
