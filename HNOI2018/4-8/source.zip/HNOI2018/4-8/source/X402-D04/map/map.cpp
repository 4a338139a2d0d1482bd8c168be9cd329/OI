#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
const int maxn=1000010;
const int N=1000000;
int n, m, Q;
int a[maxn];
vector<int> g[maxn], gg[maxn], id[maxn];
vector<pii> q[maxn];
int ans[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int fa[maxn], vis[maxn], pa[maxn];
void dec(int f,int x){
	// printf("%d - %d\n", f, x);
	int t=x;
	while(x!=f){
		t=fa[x];
		pa[x]=f;
		x=t;
	}
}
int dfn[maxn], cnt;
void dfs(int x){
	vis[x]=1, dfn[x]=++cnt;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x]) continue;
		// printf("x = %d %d\n", x, v);
		if(vis[v] && dfn[v]<dfn[x]) dec(v, x);
		else if(!vis[v]) fa[v]=x, dfs(v);
	}
}
void dfs1(int x){ for(int i=0;i<gg[x].size();i++) dfs1(gg[x][i]); }

int root[maxn*30], lc[maxn*30], rc[maxn*30], sum[maxn*30][2], node;
void pushup(int o){
	sum[o][0]=sum[ lc[o] ][0]+sum[ rc[o] ][0];
	sum[o][1]=sum[ lc[o] ][1]+sum[ rc[o] ][1];
}
void modify(int& o,int l,int r,int pos){
	if(!o) o=++node;
	if(l==r){
		if(!(sum[o][0]+sum[o][1])) sum[o][1]=1;
		else sum[o][0]^=1, sum[o][1]^=1;
		return;
	}
	int mid=(l+r)>>1;
	if(pos<=mid) modify(lc[o],l,mid,pos); else modify(rc[o],mid+1,r,pos);
	pushup(o);
}
int query(int o,int l,int r,int ql,int qr,int ty){
	if(!o) return 0;
	if(ql<=l && qr>=r) return sum[o][ty];
	int mid=(l+r)>>1, ret=0;
	if(ql<=mid) ret=query(lc[o],l,mid,ql,qr,ty); if(qr>mid) ret+=query(rc[o],mid+1,r,ql,qr,ty);
	return ret;
}
int Merge(int x,int y,int l,int r){
	if(!x || !y) return x+y;
	if(l==r){
		if((sum[x][0] && sum[y][1]) || (sum[x][1] && sum[y][0])) sum[x][1]=1, sum[x][0]=0;
		else sum[x][1]=0, sum[x][0]=1;
		return x;
	}
	int mid=(l+r)>>1;
	lc[x]=Merge(lc[x],lc[y],l,mid), rc[x]=Merge(rc[x],rc[y],mid+1,r);
	pushup(x);
	return x;
}
void solve(int x){
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i];
		solve(v);
		root[x]=Merge(root[x], root[v], 1, N);
	}
	modify(root[x],1,N,a[x]);
	for(int i=0;i<q[x].size();i++){
		int ty=q[x][i].fi, y=q[x][i].se;
		ans[ id[x][i] ]=query(root[x],1,N,1,y,ty);
	}
}

int main(){
	freopen("map.in","r",stdin),freopen("map.out","w",stdout);

	read(n), read(m);
	for(int i=1;i<=n;i++) read(a[i]);
	int u, v;
	for(int i=1;i<=m;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
	}
	dfs(1);
	// for(int i=1;i<=n;i++) printf("%d ", fa[i]); puts("");
	for(int i=2;i<=n;i++) if(!pa[i]) pa[i]=fa[i];
	// for(int i=1;i<=n;i++) printf("%d ", pa[i]); puts("");
	for(int i=2;i<=n;i++) gg[ pa[i] ].push_back(i);
	for(int i=1;i<=n;i++) g[i]=gg[i];
	read(Q);
	int ty, x, y;
	for(int i=1;i<=Q;i++){
		read(ty), read(x), read(y);
		q[x].push_back( make_pair(ty,y) ), id[x].push_back(i);
	}
	solve(1);
	for(int i=1;i<=Q;i++) printf("%d\n", ans[i]);
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
