#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<algorithm>
#define N 100010
#define mid (l+r>>1)
using namespace std;
int n,m,tim,a[N],z[N],q,dfn[N],low[N],st[N],top,ns,sz[N<<1],id[N<<1],ans[N];
int read()
{
	int x=0,f=1;char ch=getchar();
	for(;ch<'0'||ch>'9';ch=getchar()) if(ch=='-') f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}
struct edge
{
	int t;
	edge *next;
}*g1[N],*g2[N<<1];
void ins(edge **g,int x,int y)
{
	//if(g==g2) cout<<"ins:"<<x<<' '<<y<<endl;
	edge *p=new edge;
	p->t=y;
	p->next=g[x];
	g[x]=p;
}
struct node
{
	int id,ty,y;
};
vector<node> t[N];
void tarjan(int v,int fa)
{
	//cout<<"tarjan:"<<v<<' '<<fa<<endl;
	dfn[v]=low[v]=++tim;
	st[++top]=v;
	for(edge *p=g1[v];p;p=p->next)
		if(p->t!=fa)
		{
			if(!dfn[p->t]) 
			{
				tarjan(p->t,v);
				low[v]=min(low[v],low[p->t]);
				if(low[p->t]>=dfn[v])
				{
					//cout<<"!!!"<<' '<<p->t<<' '<<v<<endl;
					ns++;
					for(;st[top]!=v;top--) 	ins(g2,ns+n,st[top]);
					ins(g2,v,ns+n);
				}
			}
			else low[v]=min(low[v],dfn[p->t]);
			
		}
	//cout<<v<<' '<<dfn[v]<<' '<<low[v]<<endl;	
}
struct tree
{
	int d[2];
	tree *ls,*rs;
	tree(){ls=rs=0;d[0]=d[1]=0;}
	void update()
	{
		d[0]=(ls?ls->d[0]:0)+(rs?rs->d[0]:0);
		d[1]=(ls?ls->d[1]:0)+(rs?rs->d[1]:0);
	}
	void mdf(int l,int r,int x)
	{
		if(l==r) 
		{
			if(!d[0]&&!d[1]) d[1]=1;
			else swap(d[0],d[1]);
			return ;
		} 
		if(x<=mid) 
		{
			if(!ls) (ls=new tree);
			ls->mdf(l,mid,x);
		}
		else 
		{
			if(!rs) (rs=new tree);
			rs->mdf(mid+1,r,x);
		}
		update();
	}
	int qry(int l,int r,int lx,int rx,int b)
	{
		if(l==lx&&r==rx) return d[b];
		if(rx<=mid) return (ls?ls->qry(l,mid,lx,rx,b):0);
		if(lx>mid) return (rs?rs->qry(mid+1,r,lx,rx,b):0);
		return (ls?ls->qry(l,mid,lx,mid,b):0)+(rs?rs->qry(mid+1,r,mid+1,rx,b):0);
	}
	void outp(int l,int r)
	{
		if(l==r) return;
		cout<<l<<' '<<r<<' '<<d[0]<<' '<<d[1]<<endl;
		if(ls) ls->outp(l,mid);
		if(rs) rs->outp(mid+1,r);
	}
	
}*rt[N<<1];
tree *merge(tree *x,tree *y,int l,int r)
{
	if(!x) return y;
	if(!y) return x;
	if(l==r) 
	{
		if((x->d[0]&&y->d[1])||(x->d[1]&&y->d[0])) x->d[0]=0,x->d[1]=1;
		else x->d[0]=1,x->d[1]=0;
		return x;
	}
	x->ls=merge(x->ls,y->ls,l,mid);
	x->rs=merge(x->rs,y->rs,mid+1,r);
	x->update();
	return x;
}
void dfs(int v)
{
	sz[v]=1;int hs=0;
	for(edge *p=g2[v];p;p=p->next)
	{
		dfs(p->t);sz[v]+=sz[p->t];
		if(sz[p->t]>sz[hs]) hs=p->t;		
	}
	if(hs)
	{
		id[v]=id[hs];
		if(v<=n) rt[id[v]]->mdf(1,n,a[v]);
		for(edge *p=g2[v];p;p=p->next)
			if(p->t!=hs) merge(rt[id[v]],rt[id[p->t]],1,n);	
	}
	else 
	{
		id[v]=v;
		if(v<=n) (rt[id[v]]=new tree)->mdf(1,n,a[v]);
	}
	//cout<<"outp:"<<v<<' '<<id[v]<<endl;
//	rt[id[v]]->outp(1,n);
	if(v<=n) for(int i=0;i<t[v].size();i++)
		ans[t[v][i].id]=rt[id[v]]->qry(1,n,1,t[v][i].y,t[v][i].ty);
	
}

int main()
{
	freopen("map.in","r",stdin);
	freopen("map.ans","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
		z[i]=a[i]=read();
	sort(z+1,z+n+1);
	for(int i=1;i<=n;i++)
		a[i]=lower_bound(z+1,z+n+1,a[i])-z;	
//	for(int i=1;i<=n;i++)
//		cout<<a[i]<<' ';
//	puts("");		
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
		ins(g1,x,y);ins(g1,y,x);
	}
	q=read();
	for(int i=1;i<=q;i++)
	{
		node tmp;int x;
		tmp.ty=read();x=read();tmp.y=read();tmp.id=i;
		tmp.y=upper_bound(z+1,z+n+1,tmp.y)-z-1;
		//cout<<"qry:"<<tmp.y<<endl;
		t[x].push_back(tmp);
	}
	tarjan(1,0);
	dfs(1);
	for(int i=1;i<=q;i++)
		printf("%d\n",ans[i]);	
	return 0;
}
/*5 6
2 1 6 7 7
1 2
1 3
2 4
4 5
4 5
1 3
3
0 3 2
0 3 1
0 1 7

6 9
2 1 6 7 7 6
1 2
1 3
2 3
1 4
1 5
4 5
3
1 1 7
0 1 7
1 1 4

11 13
10 10 10 10 10 10 20 20 20 20 20
1 2
2 3
3 4
4 1
1 9 
9 10
10 1
4 5
5 6 
6 7
7 8
8 4
4 11
5
1 1 3
0 1 20
1 1 20
0 1 10
1 1 10
*/
