#include<bits/stdc++.h>
using namespace std;

int n, m;

int main(){
	freopen("connection.in","w",stdout);

	srand(time(0));
	printf("%d %d\n", n=100, m=1000);
	for(int i=2;i<=n;i++) printf("%d %d\n", rand()%(i-1)+1, i);
	for(int i=n;i<=m;i++) printf("%d %d\n", rand()%n+1, rand()%n+1);
	return 0;
}
