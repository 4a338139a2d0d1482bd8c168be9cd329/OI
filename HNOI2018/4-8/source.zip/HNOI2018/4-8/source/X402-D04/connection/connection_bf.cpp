#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
const int inf=1e9;
int n, m;
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(int& x,int y){ if(x>y) x=y; }

int fa[maxn], cnt[maxn], vis[maxn];
void solve(int x,int f){
	while(x!=f){
		cnt[x]++, x=fa[x];
	}
}

int dfn[maxn], tot;
void dfs(int x){
	dfn[x]=++tot, vis[x]=1;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x]) continue;
		if(vis[v] && dfn[v]<dfn[x]){
			solve(x, v);
		}else if(!vis[v]) fa[v]=x, dfs(v);
	}
}

int from[maxn], to[maxn], mp[maxn][maxn], use[maxn];
int DFS(int x){
	if(vis[x]) return 0;
	vis[x]=1;
	int ret=1;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(mp[x][v] || mp[v][x]) continue;
		ret+=DFS(v);
	}
	return ret;
}
void solve1(){
	int ans=inf;
	for(int i=0;i<(1<<m);i++){
		for(int j=1;j<=m;j++) if(i & (1<<(j-1))) use[j]=1; else use[j]=0;
		for(int j=1;j<=n;j++) for(int k=1;k<=n;k++) mp[j][k]=0;
		for(int j=1;j<=m;j++) if(use[j]) mp[ from[j] ][ to[j] ]=mp[ to[j] ][ from[j] ]=1;
		for(int j=1;j<=n;j++) vis[j]=0;
		if(DFS(1)<n) chkmin(ans, __builtin_popcount(i));
	}
	printf("%d\n", ans);
}

int deg[maxn];

int main(){
	freopen("connection.in","r",stdin),freopen("connection.ans","w",stdout);

	read(n), read(m);
	int u, v;
	for(int i=1;i<=m;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
		from[i]=u, to[i]=v;
		deg[u]++, deg[v]++;
	}
	if(m<=20){ solve1(); return 0; }
	dfs(1);
	int ans=inf;
	for(int i=2;i<=n;i++) chkmin(ans, cnt[i]);
	for(int i=1;i<=n;i++) chkmin(ans, deg[i]-1);
	printf("%d\n", ans+1);
	return 0;
}
