#include<bits/stdc++.h>
using namespace std;

const int maxn=10010;
const int inf=1e9;
int n, m;
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(int& x,int y){ if(x>y) x=y; }

int to[maxn*2], Next[maxn*2], Begin[maxn], w[maxn*2], e=1, s, t, W[maxn*2];
void add(int x,int y,int z){
	to[++e]=y, Next[e]=Begin[x], Begin[x]=e, w[e]=z;
}
void addedge(int x,int y){
	add(x, y, 1), add(y, x, 0);
}

int dis[maxn], gap[maxn];
int isap(int x,int flow){
	if(x==t) return flow;
	int res=flow, v;
	for(int i=Begin[x];i;i=Next[i]) if(w[i]>0 && dis[v=to[i]]+1==dis[x]){
		int Min=isap(v,min(res,w[i]));
		w[i]-=Min, w[i^1]+=Min, res-=Min;
		if(!res) return flow;
	}
	if(!(--gap[dis[x]])) dis[s]=n+1;
	++gap[++dis[x]];
	return flow-res;
}
int Maxflow(){
	memcpy(w,W,sizeof(w));
	memset(dis,0,sizeof(dis));
	memset(gap,0,sizeof(gap));
	int ret=0;
	for(gap[0]=n;dis[s]<n+1;) ret+=isap(s, inf);
	// printf("ret = %d\n", ret);
	return ret;
}

int ans;

int main(){
	freopen("connection.in","r",stdin),freopen("connection.out","w",stdout);

	read(n), read(m);
	int u, v;
	for(int i=1;i<=m;i++){
		read(u), read(v);
		addedge(u, v), addedge(v, u);
	}
	ans=inf;
	s=1;
	memcpy(W,w,sizeof(w));
	for(int i=2;i<=n;i++){
		t=i;
		chkmin(ans, Maxflow());
	}
	printf("%d\n", ans);
	return 0;
}
