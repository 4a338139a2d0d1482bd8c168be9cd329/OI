#include<bits/stdc++.h>
using namespace std;

const int maxn=71000;
const int mod=10007;
int n, c;
int a[maxn], b[maxn];
int q;

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int dp[maxn][20];
void solve(){
	memset(dp,0,sizeof(dp));
	dp[0][0]=1;
	for(int i=0;i<n;i++) for(int j=0;j<=c;j++) if(dp[i][j]){
		int nj=min(j+1, c);
		(dp[i+1][nj]+=1ll*dp[i][j]*a[i+1]%mod)%mod;
		(dp[i+1][j]+=1ll*dp[i][j]*b[i+1]%mod)%=mod;
	}
	printf("%d\n", dp[n][c]);
}

int main(){
	freopen("travel.in","r",stdin),freopen("travel.out","w",stdout);

	read(n), read(c);
	for(int i=1;i<=n;i++) read(a[i]);
	for(int i=1;i<=n;i++) read(b[i]);
	int u, x, y;
	read(q);
	while(q--){
		read(u), read(x), read(y);
		a[u]=x, b[u]=y;
		solve();
	}
	return 0;
}
