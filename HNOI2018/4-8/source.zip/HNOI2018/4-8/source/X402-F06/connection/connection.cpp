#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=300+10,maxm=2000+10,inf=0x3f3f3f3f;
int a[maxn][maxn];
int cur[maxn],Begin[maxn],Next[maxm],to[maxm],w[maxm],e;
int p[maxn],n,m,S,T,ans,d[maxn];
void add_edge(int x,int y,int z){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
	w[e]=z;
}
bool bfs(){
	queue<int> q;
	memset(d,-1,sizeof(d));
	d[S]=0;q.push(S);
	while(!q.empty()){
		int u=q.front();q.pop();
		for(int i=Begin[u];i;i=Next[i])
			if(w[i] && d[to[i]]==-1){
				d[to[i]]=d[u]+1;
				if(to[i]==T) return 1;
				q.push(to[i]);
			}
	}
	return 0;
}
int dfs(int x,int Min){
	if(x==T || (!Min)) return Min;
	int flow=0,tmp;
	for(int &i=cur[x];i;i=Next[i])
		if(d[to[i]]==d[x]+1 && w[i] && (tmp=dfs(to[i],min(Min,w[i])))){
			Min-=tmp;
			w[i]-=tmp;
			w[i^1]+=tmp;
			flow+=tmp;
			if(!Min) break;
		}
	return flow;
}
struct Edge{
	int x,y,w;
}E[maxm];
int tmp;
void findflow(){
	int res=0;
	REP(i,1,n) Begin[i]=0;
	e=1;
	REP(i,1,tmp) add_edge(E[i].x,E[i].y,E[i].w),add_edge(E[i].y,E[i].x,E[i].w);
	while(bfs()){
		REP(i,1,n) cur[i]=Begin[i];
		res+=dfs(S,inf);
		if(res>=ans) return;
	}
	ans=res;
}
int deg[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,m){
		int x=read(),y=read();
		if(x>y) swap(x,y);
		a[x][y]++;
		deg[x]++,deg[y]++;
	}
	ans=inf;
	REP(i,1,n) ans=min(ans,deg[i]);
	REP(i,1,n) REP(j,1,n) if(a[i][j]) E[++tmp]=(Edge){i,j,a[i][j]};
	REP(i,1,tmp){
	//	cerr<<E[i].x<<' '<<E[i].y<<' '<<E[i].w<<endl;
		S=E[i].x,T=E[i].y;
		findflow();
	}
	printf("%d\n",ans);
//	cerr<<"NOW:: "<<ans<<endl;
	return 0;
}
