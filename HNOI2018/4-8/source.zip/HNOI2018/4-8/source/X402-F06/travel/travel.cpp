#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int mod=10007,maxn=1e5+10;
int a[maxn],b[maxn];
int n,m;
struct Segment_tree{
	int ans[maxn<<2][21],lst[21];
	void push_up(int x){
		lst[m]=ans[x<<1|1][m];
		DREP(i,m-1,0){
			lst[i]=lst[i+1]+ans[x<<1|1][i];
			if(lst[i]>=mod) lst[i]-=mod;
		}
		REP(i,0,m) ans[x][i]=0;
		REP(i,0,m){
			REP(j,0,m-i-1) ans[x][i+j]+=ans[x<<1][i]*ans[x<<1|1][j]%mod;
			ans[x][m]+=lst[m-i]*ans[x<<1][i]%mod;
		}
		REP(i,0,m) ans[x][i]%=mod;
	}
	void build_tree(int x,int L,int R){
		if(L==R){
			REP(i,2,m) ans[x][i]=0;
			ans[x][0]=b[L],ans[x][1]=a[L];
			return;
		}
		int Mid=(L+R)>>1;
		build_tree(x<<1,L,Mid),build_tree(x<<1|1,Mid+1,R);
		push_up(x);
	}
	void update(int x,int L,int R,int q){
		if(L==R){
			ans[x][1]=read(),ans[x][0]=read();
			return;
		}
		int Mid=(L+R)>>1;
		if(q<=Mid) update(x<<1,L,Mid,q);
		else update(x<<1|1,Mid+1,R,q);
		push_up(x);
	}
}Seg;
int main(){
#ifndef ONLINE_JUDGE
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n) a[i]=read();
	REP(i,1,n) b[i]=read();
	Seg.build_tree(1,1,n);
	int q=read();
	while(q--){
		int x=read();
		Seg.update(1,1,n,x);
		printf("%d\n",Seg.ans[1][m]);
	}
	return 0;
}
