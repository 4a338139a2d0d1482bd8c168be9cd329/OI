#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
int n,m,q,T;
int a[maxn];
int beg[maxn],nex[maxn<<1],tto[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
bool vis[maxn],pd[maxn<<1];
void color_road(int u,int p){
	if(u==p) return;
	if(vis[u]) return;
	vis[u]=1;
	for(int i=beg[u];i;i=nex[i])
		color_road(tto[i],p);
}
int cnt1,cnt2;
int stk[maxn],top;
int cnt[1001000];
void dfs(int u,int y){
	if(vis[u]) return;
	vis[u]=1;
	if(a[u]<=y){
		if(cnt[a[u]]!=0){
			if(cnt[a[u]]&1) cnt1--;
			else cnt2--;
		}
		cnt[a[u]]++;
		if(cnt[a[u]]&1) cnt1++;
		else cnt2++;
		stk[++top]=a[u];
	}
	for(int i=beg[u];i;i=nex[i])
		dfs(tto[i],y);
}
int main(){
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	int s,t;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	scanf("%d",&q);
	int ty,x,y;
	for(T=1;T<=q;T++){
		scanf("%d%d%d",&ty,&x,&y);
		for(int i=1;i<=n;i++)
			vis[i]=pd[i]=0;
		color_road(1,x);
		cnt1=0,cnt2=0,top=0;
		dfs(x,y);
		if(ty==1) printf("%d\n",cnt1);
		else printf("%d\n",cnt2);
		for(int i=1;i<=top;i++)
			cnt[stk[i]]=0;
	}
	return 0;
}
