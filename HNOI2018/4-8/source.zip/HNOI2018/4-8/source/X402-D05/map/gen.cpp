#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxn=100100;
int f[maxn];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
bool c[maxn];
struct node{
	int s,t;
}w[maxn];
int m;
void dfs(int u,int v){
	if(rand()%2&&v>1){
		w[++m]=(node){u,rand()%(v-1)+1};
		int t=u;
		while(w[m].t){
			c[t]=1;
			t=f[t];
			w[m].t--;
		}
		w[m].t=t;
	}
	for(int i=beg[u];i;i=nex[i]){
		if(c[u]) dfs(tto[i],2);
		else dfs(tto[i],v+1);
	}
}
//const int maxv=1000000;
void solve(){
	int n=rand()%1000+1,q=rand()%1000+1;
	int maxv=rand()%100+1;
//	int n=rand()%10+1,q=rand()%1000+1;
	for(int i=2;i<=n;i++){
		f[i]=rand()%(i-1)+1;
		putin(f[i],i);
	}
	dfs(1,1);
	for(int i=2;i<=n;i++)
		w[++m]=(node){f[i],i};
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%maxv+1);
	printf("\n");
	for(int i=1;i<=m;i++)
		printf("%d %d\n",w[i].s,w[i].t);
	printf("%d\n",q);
	for(int i=1;i<=q;i++)
		printf("%d %d %d\n",rand()%2,rand()%n+1,rand()%maxv+1);
}
int main(){
	srand(time(0)+getx());
	freopen("map.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
