#include<bits/stdc++.h>
using namespace std;
const int maxn=300100;
#define mid ((l+r)>>1)
void chkmin(int &x,int y){
	x=x<y?x:y;
}
int n,m,q,T;
int c[maxn];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void clear_graph(){
	memset(beg,0,sizeof(beg));
	e=1;
}
struct Edge{
	int s,t;
}edge[maxn],stk[maxn];
int top;
int pre[maxn],low[maxn],dfs_time;
int dep[maxn];
int vis[maxn];
vector<int> vec[maxn];
int bcc_cnt;
void dfs(int u,int fa){
	pre[u]=low[u]=++dfs_time;
	dep[u]=dep[fa]+1;
	int sty;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(!pre[tto[i]]){
			sty=top;
			stk[++top]=(Edge){u,tto[i]};
			dfs(tto[i],u);
			if(low[tto[i]]>=pre[u]){
				bcc_cnt++;
				while(top>sty){
					if(vis[stk[top].s]!=bcc_cnt)
						vec[bcc_cnt].push_back(stk[top].s);
					vis[stk[top].s]=bcc_cnt;
					if(vis[stk[top].t]!=bcc_cnt)
						vec[bcc_cnt].push_back(stk[top].t);
					vis[stk[top].t]=bcc_cnt;
					top--;
				}
			}
			chkmin(low[u],low[tto[i]]);
		}
		else
			chkmin(low[u],pre[tto[i]]);
	}
}
struct Ask{
	int tp,v,id;
};
vector<Ask> ask[maxn];
int ans[maxn];
struct node{
	int l,r,c1,c2;
}tr[100100*21];
int rt[maxn];
int num;
void push_up(int h){
	tr[h].c1=tr[h].c2=0;
	if(tr[h].l){
		if(tr[tr[h].l].c2==-1){
			if(tr[tr[h].l].c1&1)
				tr[h].c1++;
			else
				tr[h].c2++;
		}
		else{
			tr[h].c1+=tr[tr[h].l].c1;
			tr[h].c2+=tr[tr[h].r].c2;
		}
	}
	if(tr[h].r){
		if(tr[tr[h].r].c2==-1){
			if(tr[tr[h].r].c1&1)
				tr[h].c1++;
			else
				tr[h].c2++;
		}
		else{
			tr[h].c1+=tr[tr[h].r].c1;
			tr[h].c2+=tr[tr[h].r].c2;
		}
	}
}
int merge(int h1,int h2,int l,int r){
	if(l==r){
		tr[h1].c1+=tr[h2].c1;
		return h1;
	}
	if(!h1||!h2) return h1+h2;
	tr[h1].l=merge(tr[h1].l,tr[h2].l,l,mid);
	tr[h1].r=merge(tr[h1].r,tr[h2].r,mid+1,r);
	push_up(h1);
	return h1;
}
void Insert(int &h,int l,int r,int p){
	if(!h)
		h=++num;
	if(l==r){
		tr[h].c1++,tr[h].c2=-1;
		return;
	}
	if(p<=mid) Insert(tr[h].l,l,mid,p);
	else Insert(tr[h].r,mid+1,r,p);
	push_up(h);
}
int Query1(int h,int l,int r,int s,int t){
	if(h==0) return 0;
	if(s<=l&&r<=t){
		if(l==r) return tr[h].c1&1;
		else return tr[h].c1;
	}
	if(t<=mid) return Query1(tr[h].l,l,mid,s,t);
	else if(s>mid) return Query1(tr[h].r,mid+1,r,s,t);
	else
		return Query1(tr[h].l,l,mid,s,mid)+Query1(tr[h].r,mid+1,r,mid+1,t);
}
int Query2(int h,int l,int r,int s,int t){
	if(h==0) return 0;
	if(s<=l&&r<=t){
		if(l==r) return !(tr[h].c1&1);
		else return tr[h].c2;
	}
	if(t<=mid) return Query2(tr[h].l,l,mid,s,t);
	else if(s>mid) return Query2(tr[h].r,mid+1,r,s,t);
	else
		return Query2(tr[h].l,l,mid,s,mid)+Query2(tr[h].r,mid+1,r,mid+1,t);
}
void solve(int u,int fa){
	rt[u]=0;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		solve(tto[i],u);
		T=u;
		rt[u]=merge(rt[u],rt[tto[i]],1,1000000);
	}
	T=u;
	if(c[u]!=-1) Insert(rt[u],1,1000000,c[u]);
	for(vector<Ask>::iterator it=ask[u].begin();it!=ask[u].end();it++){
		if((*it).tp==1)
			ans[(*it).id]=Query1(rt[u],1,1000000,1,(*it).v);
		else
			ans[(*it).id]=Query2(rt[u],1,1000000,1,(*it).v);
	}
}
int main(){
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	int s,t;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	m=0;
	dfs(1,0);
	clear_graph();
	for(int i=1;i<=bcc_cnt;i++){
		c[n+i]=-1;
		for(vector<int>::iterator it=vec[i].begin();it!=vec[i].end();it++){
			putin(*it,n+i);
			putin(n+i,*it);
		}
	}
	int tp,p,v;
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		scanf("%d%d%d",&tp,&p,&v);
		ask[p].push_back((Ask){tp,v,i});
	}
	solve(1,-1);
	for(int i=1;i<=q;i++)
		printf("%d\n",ans[i]);
	return 0;
}
