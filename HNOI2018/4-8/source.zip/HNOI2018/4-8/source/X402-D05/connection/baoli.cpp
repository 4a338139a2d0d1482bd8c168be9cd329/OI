#include<bits/stdc++.h>
using namespace std;
const int INF=1e9;
const int maxn=200100;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e=1;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
bool vis[maxn<<1];
int n,m;
int ans=INF;
int cnt,pre[maxn],T;
void dfs(int u){
	if(pre[u]==T) return;
	cnt++;
	pre[u]=T;
	for(int i=beg[u];i;i=nex[i]){
		if(vis[i]) continue;
		dfs(tto[i]);
	}
}
bool check(){
	T++,cnt=0;
	dfs(1);
	if(cnt==n) return 0;
	int zlt=0;
	for(int i=1;i<=m;i++)
		if(vis[i<<1]) zlt++;
	return 1;
}
void dfs(int p,int sum){
	if(p>m){
		if(check())
			chkmin(ans,sum);
		return;
	}
	vis[p<<1]=vis[p<<1|1]=1;
	dfs(p+1,sum+1);
	vis[p<<1]=vis[p<<1|1]=0;
	dfs(p+1,sum);
}
int main(){
	freopen("connection.in","r",stdin);
	freopen("baoli.out","w",stdout);
	scanf("%d%d",&n,&m);
	int s,t;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	dfs(1,0);
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}
