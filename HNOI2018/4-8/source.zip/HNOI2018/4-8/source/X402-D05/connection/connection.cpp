#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
const int INF=1e9;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
int n,m;
int g[610][610];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
void Addedge(int s,int t,int v){
	putin(s,t,v);
	putin(t,s,v);
}
void clear_graph(){
	e=1;
	for(int i=1;i<=n;i++)
		beg[i]=0;
}
int S,T;
int dis[maxn],cur[maxn];
bool BFS(){
	static int q[maxn];
	for(int i=S;i<=n;i++)
		dis[i]=-1;
	int l=1,r=1;
	q[1]=S;
	int u;
	dis[S]=0;
	while(l<=r){
		u=q[l],l++;
		for(int i=beg[u];i;i=nex[i]){
			if(w[i]&&dis[tto[i]]==-1){
				dis[tto[i]]=dis[u]+1;
				if(tto[i]==T) return 1;
				q[++r]=tto[i];
			}
		}
	}
	return 0;
}
int dinic(int u,int fl){
	if(u==T) return fl;
	int res=fl,mn;
	for(int &i=cur[u];i;i=nex[i]){
		if(!w[i]||dis[tto[i]]!=dis[u]+1) continue;
		mn=dinic(tto[i],res<w[i]?res:w[i]);
		w[i]-=mn,w[i^1]+=mn;
		res-=mn;
		if(res==0) return fl;
	}
	return fl-res;
}
int solve(){
	int res=0;
	while(BFS()){
		for(int i=S;i<=n;i++)
			cur[i]=beg[i];
		res+=dinic(S,INF);
	}
	return res;
}
int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	scanf("%d%d",&n,&m);
	int s,t;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&s,&t);
		g[s][t]++,g[t][s]++;
	}
	int ans=m;
	for(int i=2;i<=n;i++){
		clear_graph();
		for(int j=i-1;j<=n;j++)
			for(int k=j+1;k<=n;k++)
				if(g[j][k])
					Addedge(j,k,g[j][k]);
		S=i-1,T=i;
		int res=solve();
		chkmin(ans,res);
		for(int j=1;j<=n;j++){
			g[i][j]+=g[i-1][j];
			g[i-1][j]=0;
		}
	}
	printf("%d\n",ans);
	return 0;
}
