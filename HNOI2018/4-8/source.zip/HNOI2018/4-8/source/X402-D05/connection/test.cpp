#include<bits/stdc++.h>
using namespace std;
vector<int> vec;
int main(){
	vec.push_back(3);
	vec.push_back(6);
	vec.push_back(9);
	vec.push_back(233);
	vec.push_back(233);
	vec.push_back(233);
	vec.push_back(233);
	vec.push_back(466);
	vec.push_back(4660);
	int p=lower_bound(vec.begin(),vec.end(),233)-vec.begin();
	printf("%d %d\n",p,vec[p]);
	return 0;
}
