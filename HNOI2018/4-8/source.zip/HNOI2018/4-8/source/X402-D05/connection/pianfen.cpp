#include<bits/stdc++.h>
using namespace std;
const int maxn=2010;
const int INF=1e9;
int Min(int x,int y){
	return x<y?x:y;
}
void chkmin(int &x,int y){
	x=x<y?x:y;
}
int n,m;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e=1;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void clear_graph(){
	e=1;
	memset(beg,0,sizeof(beg));
}
struct Edge{
	int s,t;
}edge[maxn];
int pre[maxn],dfs_time;
int f[maxn],dep[maxn];
vector<int> vec[maxn],cnt[maxn];
void dfs(int u,int fa){
	pre[u]=++dfs_time;
	dep[u]=dep[f[u]]+1;
	for(int i=beg[u];i;i=nex[i]){
		if(i==(fa^1)) continue;
		if(!pre[tto[i]]){
			edge[++m]=(Edge){u,tto[i]};
			f[tto[i]]=u;
			dfs(tto[i],i);
		}
		else if(pre[tto[i]]<pre[u]){
			vec[u].push_back(dep[tto[i]]);
			int v=u;
			while(v!=tto[i])
				cnt[v].push_back(dep[tto[i]]),v=f[v];
		}
	}
}
int ans=INF;
int dp[maxn];
int ti;
void dfs_solve(int u,int dr){
	dp[u]=lower_bound(vec[u].begin(),vec[u].end(),dr)-vec[u].begin();
	int v;
	for(int i=beg[u];i;i=nex[i]){
		dfs_solve(tto[i],dr);
		v=lower_bound(cnt[tto[i]].begin(),cnt[tto[i]].end(),dr)-cnt[tto[i]].begin();
		v=cnt[tto[i]].size()-v+1;
		dp[u]+=Min(dp[tto[i]],v);
	}
}
int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	int s,t;
	scanf("%d%d",&n,&m);
	clear_graph();
	for(int i=1;i<=m;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	m=0;
	dfs(1,0);
	if(dfs_time<n){
		printf("0\n");
		return 0;
	}
	clear_graph();
	for(int i=1;i<=m;i++)
		putin(edge[i].s,edge[i].t);
	for(int i=1;i<=n;i++){
		sort(vec[i].begin(),vec[i].end());
		sort(cnt[i].begin(),cnt[i].end());
	}
	for(int i=2;i<=n;i++){
		ti=i;
		dfs_solve(i,dep[i]);
		chkmin(ans,dp[i]+1);
	}
	printf("%d\n",ans);
	return 0;
}
