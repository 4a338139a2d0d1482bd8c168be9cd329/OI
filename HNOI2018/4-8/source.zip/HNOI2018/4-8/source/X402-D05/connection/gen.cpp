#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=rand()%10+2,m=rand()%20+2;
	printf("%d %d\n",n,m);
	int s,t;
	for(int i=1;i<=m;i++){
		s=rand()%n+1,t=rand()%n+1;
		while(s==t)
			s=rand()%n+1,t=rand()%n+1;
		printf("%d %d\n",s,t);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("connection.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
