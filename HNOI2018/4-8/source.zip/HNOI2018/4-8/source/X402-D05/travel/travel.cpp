#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
const int md=10007;
#define mid ((l+r)>>1)
string procstatus(){
	ifstream t("/proc/self/status");
	return (string){istreambuf_iterator<char>(t),istreambuf_iterator<char>()};
}
int powd(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int cas,n,m,C;
int a[maxn],b[maxn];
int tr[maxn<<2][20];
int sum[maxn<<2];
void Add(int h,int p){
	for(int i=0;i<C;i++)
		tr[h][i]=0;
	tr[h][0]=b[p],tr[h][1]=a[p];
	sum[h]=(a[p]+b[p])%md;
}
void push_up(int h){
	for(int i=0;i<C;i++)
		tr[h][i]=0;
	for(int i=0;i<C;i++)
		for(int j=0;i+j<C;j++)
			tr[h][i+j]+=tr[h<<1][i]*tr[h<<1|1][j]%md;
	for(int i=0;i<C;i++)
		tr[h][i]%=md;
	sum[h]=sum[h<<1]*sum[h<<1|1]%md;
}
void build_tree(int h,int l,int r){
	if(l==r){
		Add(h,l);
		return;
	}
	build_tree(h<<1,l,mid);
	build_tree(h<<1|1,mid+1,r);
	push_up(h);
}
void Insert(int h,int l,int r,int p){
	if(l==r){
		Add(h,l);
		return;
	}
	if(p<=mid) Insert(h<<1,l,mid,p);
	else Insert(h<<1|1,mid+1,r,p);
	push_up(h);
}
int Query(){
	int res=0;
	for(int i=0;i<C;i++)
		res=(res+tr[1][i])%md;
	res=(sum[1]-res+md)%md;
	return res;
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&C);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		a[i]%=md;
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&b[i]);
		b[i]%=md;
	}
	build_tree(1,1,n);
	int p,x,y;
	scanf("%d",&m);
	for(cas=1;cas<=m;cas++){
		scanf("%d%d%d",&p,&x,&y);
		x%=md,y%=md;
		a[p]=x,b[p]=y;
		Insert(1,1,n,p);
		printf("%d\n",Query());
	}
	return 0;
}
