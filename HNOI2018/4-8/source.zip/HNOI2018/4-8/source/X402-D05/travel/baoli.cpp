#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
const int md=10007;
int cas,n,m,C;
int a[maxn],b[maxn];
int dp[maxn][20];
int ans;
int main(){
	freopen("travel.in","r",stdin);
	freopen("baoli.out","w",stdout);
	scanf("%d%d",&n,&C);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		a[i]%=md;
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&b[i]);
		b[i]%=md;
	}
	scanf("%d",&m);
	int p,x,y;
	for(cas=1;cas<=m;cas++){
		scanf("%d%d%d",&p,&x,&y);
		x%=md,y%=md;
		a[p]=x,b[p]=y;
		ans=1;
		for(int i=1;i<=n;i++)
			ans=ans*(a[i]+b[i])%md;
		dp[0][0]=1;
		for(int i=1;i<=n;i++)
			for(int j=0;j<C;j++){
				dp[i][j]=dp[i-1][j]*b[i]%md;
				if(j==0) continue;
				(dp[i][j]+=dp[i-1][j-1]*a[i])%=md;
			}
		for(int i=0;i<C;i++)
			ans=(ans-dp[n][i]+md)%md;
		printf("%d\n",ans);
	}
	return 0;
}
