#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxv=100000001;
void solve(){
	int n=rand()%10000+1,C=rand()%20+1,m=rand()%100+1;
//	int n=100000,C=20,m=100000;
	printf("%d %d\n",n,C);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%maxv);
	printf("\n");
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%maxv);
	printf("\n");
	printf("%d\n",m);
	for(int i=1;i<=m;i++)
		printf("%d %d %d\n",rand()%n+1,rand()%maxv,rand()%maxv);
}
int main(){
	srand(time(0)+getx());
	freopen("travel.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
