#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=100009;
const int M=200009;
const int E=1e6+1;
const int P=M<<2;

int n,m,p,ori;
int a[N],fa[N];
int pre[N],id[M],ed[M],seg[M],dfn;
int stk[M],top;
bool ring[M];
int eto[N<<1],enxt[N<<1],ebeg[N],etot=1;
int to[M<<1],nxt[M<<1],beg[M],tot=1;

inline void eadd(int u,int v)
{
	eto[++etot]=v;
	enxt[etot]=ebeg[u];
	ebeg[u]=etot;
}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void tarjan(int u,int fae)
{
	pre[u]=++dfn;
	for(int i=ebeg[u],v;i;i=enxt[i])
		if((i^1)!=fae)
		{
			if(!pre[v=eto[i]])
			{
				fa[v]=u;
				ring[u]=0;
				tarjan(v,i);
				if(!ring[u])
					add(u,v),add(v,u);
			}
			else if(pre[v]<=pre[u])
			{
				int tmp=u;
				n++;
				while(1)
				{
					add(n,tmp);add(tmp,n);
					ring[tmp]=1;
					if(tmp==v)break;
					tmp=fa[tmp];
				}
			}
		}
}

inline void dfs(int u,int fat)
{
	fa[u]=fat;
	seg[id[u]=++dfn]=u;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fat)
			dfs(to[i],u);
	ed[u]=dfn;
}

int main()
{
	freopen("map.in","r",stdin);
	freopen("maps.out","w",stdout);

	ori=n=read();m=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1,u,v;i<=m;i++)
	{
		u=read();v=read();
		eadd(u,v);eadd(v,u);
	}

	tarjan(1,0);
	dfs(1,0);

	for(int tim=read(),ty,x,y;tim;tim--)
	{
		ty=read();x=read();y=read();
		int ans=0,cnt=0;top=0;
		for(int i=id[x];i<=ed[x];i++)
			if(seg[i]<=ori && a[seg[i]]<=y)
				stk[++top]=a[seg[i]];
		sort(stk+1,stk+top+1);
		for(int i=1;i<=top;i++)
		{
			if(i!=1 && stk[i]==stk[i-1])
				cnt++;
			else
			{
				if(cnt)ans+=((cnt&1)^ty^1);
				cnt=1;
			}
		}
		if(cnt)ans+=((cnt&1)^ty^1);
		printf("%d\n",ans);
	}

	return 0;
}
