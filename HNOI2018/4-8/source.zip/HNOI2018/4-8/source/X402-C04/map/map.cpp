#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

/*
inline void status()
{
	FILE *f=fopen("/proc/self/status","r");
	for(char cc=fgetc(f);cc!=EOF;cc=fgetc(f))
		fprintf(stderr,"%c",cc);
}
*/

const int N=100009;
const int M=200009;
const int E=1e6+1;
const int P=M<<2;

int n,m,p,ori;
int a[M],fa[M],ans[N];
int pre[M],dfn;
int rt[M],siz[M],stk[M],top;
bool ring[M];
int eto[M<<1],enxt[M<<1],ebeg[M],etot=1;
int to[M<<1],nxt[M<<1],beg[M],tot=1;

struct qu{int ty,y,id;};
vector<qu> q[M];

inline bool cmp(int a,int b){return siz[a]<siz[b];}

inline void eadd(int u,int v)
{
	eto[++etot]=v;
	enxt[etot]=ebeg[u];
	ebeg[u]=etot;
}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void tarjan(int u,int fae)
{
	pre[u]=++dfn;
	for(int i=ebeg[u],v;i;i=enxt[i])
		if((i^1)!=fae)
		{
			if(!pre[v=eto[i]])
			{
				fa[v]=u;
				ring[u]=0;
				tarjan(v,i);
				if(!ring[u])
					add(u,v),add(v,u);
			}
			else if(pre[v]<=pre[u])
			{
				int tmp=u;
				n++;
				while(1)
				{
					add(n,tmp);add(tmp,n);
					ring[tmp]=1;
					if(tmp==v)break;
					tmp=fa[tmp];
				}
			}
		}
}

namespace splay
{
	const int P=M<<2;
	int key[P],val[P],odd[P],even[P],ch[P][2],fa[P],tot;
	int stk[P],top;

	inline void init()
	{
		for(int i=1;i<P;i++)
			stk[++top]=i;
	}

	inline int newnode()
	{
		int ret=stk[top--];
		ch[ret][0]=ch[ret][1]=fa[ret]=0;
		odd[ret]=even[ret]=val[ret]=key[ret]=0;
		return ret;
	}

	inline void free(int x)
	{
		stk[++top]=x;
	}

	inline void update(int x)
	{
		odd[x]=(val[x]&1)+odd[ch[x][0]]+odd[ch[x][1]];
		even[x]=(val[x]&1^1)+even[ch[x][0]]+even[ch[x][1]];
	}

	inline void rotate(int x)
	{
		int y=fa[x],z=fa[y];
		int l=(ch[y][1]==x);
		if(z)ch[z][ch[z][1]==y]=x;
		fa[x]=z;fa[y]=x;fa[ch[x][l^1]]=y;
		ch[y][l]=ch[x][l^1];ch[x][l^1]=y;
		update(y);update(x);
	}

	inline void splay(int x,int r)
	{
		for(int y=fa[x],z=fa[y];fa[x];rotate(x),y=fa[x],z=fa[y])
			if(fa[y])
			{
				if(ch[z][1]==y^ch[y][1]==x)
					rotate(x);
				else 
					rotate(y);
			}
		rt[r]=x;
		update(x);
	}

	inline void insert(int x,int v,int r)
	{
		int now=rt[r],fat=0,son=0,cur;
		if(!now)
		{
			cur=newnode();
			val[cur]=v;
			key[cur]=x;
			rt[r]=cur;
			update(cur);
			return;
		}
		while(now)
		{
			if(key[now]==x)
			{
				val[now]+=v;
				cur=now;
				goto ed;
			}
			fat=now;
			if(x<key[now])
				now=ch[now][son=0];
			else
				now=ch[now][son=1];
		}

		cur=newnode();
		key[cur]=x;
		val[cur]=v;
		fa[cur]=fat;
		ch[fat][son]=cur;
		ed:;
		update(cur);
		siz[r]++;
		splay(cur,r);
	}

	inline void merge(int x,int y)
	{
		if(ch[x][0])merge(ch[x][0],y);
		insert(key[x],val[x],y);
		if(ch[x][1])merge(ch[x][1],y);
		free(x);
	}

	inline int query(int r,int v,int ty)
	{
		int ret=0,now=rt[r],*qv=(ty?odd:even);
		while(now)
		{
		//	printf("in %d,ret %d\n",now,ret);
			if(key[now]==v)
				return qv[now]-qv[ch[now][1]]+ret;
			else if(key[now]<v)
				ret+=qv[now]-qv[ch[now][1]],now=ch[now][1];
			else
				now=ch[now][0];
		//	printf("in %d,ret %d\n",now,ret);
		}
		return ret;
	}

	inline void out(int x)
	{
		if(ch[x][0])out(ch[x][0]);
		printf("%d:[%d][%d,%d] key %d val %d odd %d even %d\n",x,fa[x],ch[x][0],ch[x][1],key[x],val[x],odd[x],even[x]);
		if(ch[x][1])out(ch[x][1]);
	}
}

inline void dfs(int u,int fat)
{
	//cerr<<"asf"<<endl;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fat)
			dfs(to[i],u);
	//cerr<<"mid"<<endl;
	top=0;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fat)
			stk[++top]=to[i];
	if(top)
	{
		sort(stk+1,stk+top+1,cmp);
		for(int i=1;i<top;i++)
			splay::merge(rt[stk[i]],stk[i+1]);
		rt[u]=rt[stk[top]];
	}
	if(u<=ori)
	{
		splay::insert(a[u],1,u);
		for(int i=0;i<q[u].size();i++)
			ans[q[u][i].id]=splay::query(u,q[u][i].y,q[u][i].ty);
	}
	//cerr<<"pas"<<endl;
	//printf("out %d:\n",u);
	//splay::out(rt[u]);
}

int main()
{
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);

	splay::init();
	ori=n=read();m=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1,u,v;i<=m;i++)
	{
		u=read();v=read();
		eadd(u,v);eadd(v,u);
	}

	tarjan(1,0);

	int tim=read();
	for(int i=1,ty,x,y;i<=tim;i++)
	{
		ty=read();x=read();y=read();
		q[x].push_back((qu){ty,y,i});
	}
	dfs(1,0);
	
	for(int i=1;i<=tim;i++)
		printf("%d\n",ans[i]);
	return 0;
}

