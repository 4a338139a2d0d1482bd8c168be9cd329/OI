#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef double db;
typedef long long ll;

const int N=100009;
const int M=100;
const int C=3;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

int fa[N],siz[N];
set<pr> ha;

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("map.in","w",stdout);

	int n=200000,m=n-1,q=100000;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%M+1);
	puts("");
	for(int i=2,u;i<=n;i++)
	{
		printf("%d %d\n",(u=(rand()%(i-1)+1)),i);
		ha.insert(pr(u,i));
	}
	printf("%d\n",q);
	for(int i=1;i<=q;i++)
	{
		printf("%d %d %d\n",rand()%2,rand()%n+1,rand()%M+1);
	}
	return 0;
}
