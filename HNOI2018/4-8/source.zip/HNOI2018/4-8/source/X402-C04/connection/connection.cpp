#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=309;
const int M=1009;

int n,m,ans=1e9+7;
int to[M<<1],nxt[M<<1],beg[N],tot=1;
int vis[N],tim,cnts;
bool ban[M<<1];

inline void judge(int u)
{
	cnts++;vis[u]=tim;
	for(int i=beg[u];i;i=nxt[i])
		if(!ban[i] && vis[to[i]]!=tim)
			judge(to[i]);
}

inline void dfs(int u,int cnt)
{
	if(cnt>=ans)return;
	if(u==(tot+1)/2)
	{
		tim++;cnts=0;
		judge(1);
		if(cnts!=n)
			ans=cnt;
		return;
	}

	ban[u<<1]=ban[u<<1|1]=0;
	dfs(u+1,cnt);
	ban[u<<1]=ban[u<<1|1]=1;
	dfs(u+1,cnt+1);
}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);

	n=read();m=read();
	for(int i=1,u,v;i<=m;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
	}
	
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}
