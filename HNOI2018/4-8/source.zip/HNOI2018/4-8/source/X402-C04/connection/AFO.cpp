#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=309;
const int M=1009;

int n,m,ans=1e9+7;
int to[M<<1],nxt[M<<1],beg[N],tot=1;

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);

	n=read();m=read();
	for(int i=1,u,v;i<=m;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
	}
	
	printf("%d\n",ans);
	return 0;
}
