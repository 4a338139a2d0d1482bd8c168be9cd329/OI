#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=100009;
const int M=100;
const int C=3;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

int fa[N],siz[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("travel.in","w",stdout);

	int n=70,c=20,m=93;
	printf("%d %d\n",n,c);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%M+1);
	puts("");
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%M+1);
	puts("");
	printf("%d\n",m);
	for(int i=1;i<=m;i++)
		printf("%d %d %d\n",rand()%n+1,rand()%M+1,rand()%M+1);
	return 0;
}
