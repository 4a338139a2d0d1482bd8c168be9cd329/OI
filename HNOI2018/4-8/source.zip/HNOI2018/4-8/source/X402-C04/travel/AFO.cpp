#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=80009;
const int C=22;
const int md=10007;

int n,c,t;
int a[N],b[N];
int f[N][C];

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travels.out","w",stdout);

	n=read();c=read();
	for(int i=1;i<=n;i++)
		a[i]=read()%md;
	for(int i=1;i<=n;i++)
		b[i]=read()%md;

	t=read();
	while(t--)
	{
		int p=read(),x=read(),y=read();
		a[p]=x;b[p]=y;

		memset(f,0,sizeof(f));
		f[0][0]=1;
		for(int i=0;i<=n;i++)
			for(int j=0;j<=c+1;j++)
				if(f[i][j])
				{
					if(j+1<=c+1)
						(f[i+1][j+1]+=f[i][j]*a[i+1]%md)%=md;
					else
						(f[i+1][j]+=f[i][j]*a[i+1]%md)%=md;
					(f[i+1][j]+=f[i][j]*b[i+1]%md)%=md;
				}
		printf("%d\n",(f[n][c]+f[n][c+1])%md);
	}

	return 0;
}
