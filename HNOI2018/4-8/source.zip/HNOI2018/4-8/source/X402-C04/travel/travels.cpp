#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=80009;
const int C=22;
const int md=10007;

int n,c,t;
int a[N],b[N];
int f[N][C];

struct matrix
{
	int a[C][C];
	
	inline void init(){memset(a,0,sizeof(a));}
	matrix(){init();}
	inline int* operator [] (int x){return a[x];}
		
	inline matrix operator * (matrix o)const
	{
		matrix ret;
		for(int i=0;i<=c+1;i++)
			for(int j=i;j<=c+1;j++)
			{
				for(int k=i;k<=c+1 && k<=j;k++)
					ret[i][j]+=a[i][k]*o[k][j]%md;
				ret[i][j]%=md;
			}
		return ret;
	}

	inline void out()
	{
		for(int i=0;i<=c+1;i++,puts(""))
			for(int j=0;j<=c+1;j++)
				printf("%d ",a[i][j]);
		puts("");
	}
};

inline matrix calc(int x)
{
	matrix ret;
	for(int i=0;i<=c;i++)
		ret[i][i+1]=a[x];
	for(int i=0;i<=c;i++)
		ret[i][i]=b[x];
	ret[c+1][c+1]=(a[x]+b[x])%md;
	return ret;
}

namespace segt
{
	matrix t[N<<2];

	inline void build(int x,int l,int r)
	{
		if(l==r){t[x]=calc(l);return;}
		int mid=l+r>>1;
		build(x<<1,l,mid);
		build(x<<1|1,mid+1,r);
		t[x]=t[x<<1]*t[x<<1|1];
	}

	inline void modify(int x,int l,int r,int p)
	{
		if(l==r){t[x]=calc(p);return;}
		int mid=l+r>>1;
		if(p<=mid)modify(x<<1,l,mid,p);
		else modify(x<<1|1,mid+1,r,p);
		t[x]=t[x<<1]*t[x<<1|1];
	}
}

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travels.out","w",stdout);

	n=read();c=read();
	for(int i=1;i<=n;i++)
		a[i]=read()%md;
	for(int i=1;i<=n;i++)
		b[i]=read()%md;

	segt::build(1,1,n);

	t=read();
	while(t--)
	{
		int p=read(),x=read(),y=read();
		a[p]=x;b[p]=y;

		segt::modify(1,1,n,p);
		printf("%d\n",(segt::t[1][0][c]+segt::t[1][0][c+1])%md);
	}

	return 0;
}
