#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void write(int x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

inline void status()
{
	FILE *f=fopen("/proc/self/status","r");
	for(char cc=fgetc(f);cc!=EOF;cc=fgetc(f))
		fprintf(stderr,"%c",cc);
}

const int N=100000;
const int C=22;
const int md=10007;

int n,c,t;
int a[N],b[N],all;

inline int minn(int a,int b){if(a<b)return a;return b;}

inline int qpow(int a,int b)
{
	int ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}

struct poly
{
	int a[C],len;
	
	inline int& operator [] (int x){return a[x];}
	inline void init(){memset(a,0,sizeof(a));}
	poly(){init();}

	inline poly operator * (poly o)const
	{
		poly ret;
		for(int i=0;i<c && i<len;i++)
			for(int j=0;j<c && j<o.len && i+j<c;j++)
				ret[i+j]+=a[i]*o[j];
		ret.len=minn(c,len+o.len-1);
		for(int i=0;i<c && i<ret.len;i++)
			ret[i]%=md;
		return ret;
	}
};

inline void calc(int x,poly &ret)
{
	ret[0]=b[x];ret[1]=a[x];
	ret.len=2;
}

namespace segt
{
	poly t[N<<2];

	inline void build(int x,int l,int r)
	{
		if(l==r){calc(l,t[x]);return;}
		int mid=l+r>>1;
		build(x<<1,l,mid);
		build(x<<1|1,mid+1,r);
		t[x]=t[x<<1]*t[x<<1|1];
	}

	inline void modify(int x,int l,int r,int p)
	{
		if(l==r){calc(p,t[x]);return;}
		int mid=l+r>>1;
		if(p<=mid)modify(x<<1,l,mid,p);
		else modify(x<<1|1,mid+1,r,p);
		t[x]=t[x<<1]*t[x<<1|1];
	}
}

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);

	n=read();c=read();
	for(int i=1;i<=n;i++)
		a[i]=read()%md;
	for(int i=1;i<=n;i++)
		b[i]=read()%md;

	all=1;
	for(int i=1;i<=n;i++)
		all=all*(a[i]+b[i])%md;
	segt::build(1,1,n);

	t=read();
	while(t--)
	{
		int p=read(),x=read(),y=read();
		all=all*qpow((a[p]+b[p])%md,md-2)%md;
		a[p]=x;b[p]=y;
		all=all*(a[p]+b[p])%md;

		segt::modify(1,1,n,p);
		int ans=all;
		for(int i=0;i<c;i++)
		{
			ans=ans+md-segt::t[1][i];
			if(ans>=md)ans-=md;
		}
		write(ans);putchar('\n');
	}

	return 0;
}
