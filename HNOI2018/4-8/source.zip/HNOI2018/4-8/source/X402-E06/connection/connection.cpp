#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 500;

bool vis[N + 5]; 

int n, m;
int g[N + 5][N + 5];
int bel[N + 5], sum[N + 5];

int solve() {
    int ans = oo;
    for(int i = 1; i <= n; ++i) bel[i] = i;

    while(n > 1) {
        memset(sum, 0, sizeof sum);
        memset(vis, 0, sizeof vis);

        int p = 1;

        vis[bel[1]] = true;
        for(int i = 2; i <= n; ++i) {
            int x = -1;

            for(int j = 1; j <= n; ++j) if(!vis[bel[j]]) {
                sum[bel[j]] += g[bel[p]][bel[j]];
                
                if(x == -1 || sum[bel[j]] > sum[bel[x]]) {
                    x = j;
                }
            }

            vis[bel[x]] = true;

            if(i == n) {
                chkmin(ans, sum[bel[x]]);
                for(int j = 1; j <= n; ++j) {
                    g[bel[p]][bel[j]] += g[bel[x]][bel[j]];
                    g[bel[j]][bel[p]] += g[bel[j]][bel[x]];
                }
                bel[x] = bel[n--];
            }
            p = x;
        }
    }
    return ans;
}

int main() {
    freopen("connection.in", "r", stdin);
    freopen("connection.out", "w", stdout);

    read(n), read(m);
    for(int i = 1; i <= m; ++i) {
        static int u, v;
        read(u), read(v);
        g[u][v] ++; g[v][u] ++;
    }

    printf("%d\n", solve());

    return 0;
}
