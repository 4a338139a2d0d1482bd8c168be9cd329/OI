#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;
const int mo = 10007;

int n, m, c;
int a[N + 5], b[N + 5];

namespace SEG {

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)
    
    const int SZ = N << 2;

    int F[SZ + 5][50];

    inline void push_up(int u) {
        int *x = F[lc], *y = F[rc], *r = F[u];

        for(register int i = 0; i <= 2*c; ++i) r[i] = 0;
        for(register int i = 0; i <= c; ++i) {
            for(register int j = 0; j <= c; ++j) {
                r[i + j] = (r[i + j] + x[i] * y[j]) % mo;
            }
        }
        for(register int i = c+1; i <= 2*c; ++i) {
            r[c] = (r[c] + r[i]) % mo; r[i] = 0;
        }
    }

    void build(int u, int l, int r) {
        if(l == r) {
            F[u][1] = a[l];
            F[u][0] = b[l];
            return;
        }

        build(lc, l, mid);
        build(rc, mid+1, r);

        push_up(u);
    }

    void modify(int u, int l, int r, int p) {
        if(l == r) {
            F[u][1] = a[l];
            F[u][0] = b[l];
            return;
        }

        if(p <= mid)
            modify(lc, l, mid, p);
        else 
            modify(rc, mid+1, r, p);

        push_up(u);
    }
}

int main() {
    freopen("travel.in", "r", stdin);
    freopen("travel.out", "w", stdout);

    read(n), read(c);
    for(int i = 1; i <= n; ++i) read(a[i]), a[i] %= mo;
    for(int i = 1; i <= n; ++i) read(b[i]), b[i] %= mo;

    SEG::build(1, 1, n);

    read(m);
    for(; m--; ) {
        static int u, x, y;
        read(u), read(x), read(y);
        a[u] = x % mo, b[u] = y % mo;
        SEG::modify(1, 1, n, u);
        printf("%d\n", SEG::F[1][c]);
    }

    return 0;
}

