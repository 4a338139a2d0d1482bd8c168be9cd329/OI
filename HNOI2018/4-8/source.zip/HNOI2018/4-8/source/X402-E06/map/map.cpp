#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;
const int M = 300000;
const int RNG = 1000000;

namespace SEG {

#define mid ((l + r) >> 1)

    const int SZ = M << 4;

    int cnt;
    int lc[SZ + 5], rc[SZ + 5], sum[2][SZ + 5];

    inline int cpy(int x) {
        ++ cnt;
        lc[cnt] = lc[x];
        rc[cnt] = rc[x];
        sum[0][cnt] = sum[0][x];
        sum[1][cnt] = sum[1][x];
        return cnt;
    }

    void modify(int &x, int l, int r, int p) {
        x = ++ cnt;
        if(l == r) { sum[1][x] = 1; return; }

        if(p <= mid)
            modify(lc[x], l, mid, p);
        else
            modify(rc[x], mid+1, r, p);

        sum[0][x] = sum[0][lc[x]] + sum[0][rc[x]];
        sum[1][x] = sum[1][lc[x]] + sum[1][rc[x]];
    }

    void merge(int &x, int y, int l, int r) {
        if(!y) return;
        if(!x) { x = y; return; }

        x = cpy(x);
        if(l == r) {
            int t0 = (sum[0][x] ? 0 : 1);
            int t1 = (sum[0][y] ? 0 : 1);

            if(t0 == t1) {
                sum[0][x] = 1; sum[1][x] = 0;
            } else {
                sum[1][x] = 1; sum[0][x] = 0;
            }
            return;
        }

        merge(lc[x], lc[y], l, mid);
        merge(rc[x], rc[y], mid+1, r);

        sum[0][x] = sum[0][lc[x]] + sum[0][rc[x]];
        sum[1][x] = sum[1][lc[x]] + sum[1][rc[x]];
    }

    inline int query(int u, int l, int r, int x, int y, int ty) {
        if(!u || y < l || x > r) return 0;
        if(x <= l && r <= y) return sum[ty][u];
        return query(lc[u], l, mid, x, y, ty) + query(rc[u], mid+1, r, x, y, ty); 
    }
}

int a[N + 5];
int rt[N + 5];

namespace tree {

    int st[N + 5], to[M + 5], nxt[M + 5], e = 1;

    inline void addedge(int u, int v) {
        to[++ e] = v; nxt[e] = st[u]; st[u] = e;
        to[++ e] = u; nxt[e] = st[v]; st[v] = e;
    }

    void dfs(int u, int f = 0) {
        SEG::modify(rt[u], 1, RNG, a[u]);
        for(int i = st[u]; i; i = nxt[i]) {
            int v = to[i];
            if(v == f) continue;
            dfs(v, u);
            SEG::merge(rt[u], rt[v], 1, RNG);
        }
    }
}

namespace cactus {

    int st[N + 5], nxt[M + 5], to[M + 5], e = 1;

    inline void addedge(int u, int v) {
        to[++ e] = v; nxt[e] = st[u]; st[u] = e;
        to[++ e] = u; nxt[e] = st[v]; st[v] = e;
    }

    int pre[N + 5];
    int low[N + 5], dfn[N + 5], dfs_clock;

    void dfs(int u, int fe = 0) {
        
        low[u] = dfn[u] = ++ dfs_clock;

        for(int i = st[u]; i; i = nxt[i]) if(i != fe) {
            int v = to[i];

            if(!dfn[v]) {
                dfs(v, pre[v] = i ^ 1);
                chkmin(low[u], low[v]);
                if(low[v] > dfn[u]) tree::addedge(u, v);
            } else {
                chkmin(low[u], dfn[v]);
            }
        }

        for(int i = st[u]; i; i = nxt[i]) if(i != fe) {
            int v = to[i];
            if((i ^ 1) != pre[v] && low[v] == dfn[u]) {
                while(v != u) {
                    tree::addedge(u, v);
                    v = to[pre[v]];
                } break;
            }
        }
    }
    
    void build() { dfs(1); }
}

int n, m, q;
int main() {
    freopen("map.in", "r", stdin);
    freopen("map.out", "w", stdout);

    read(n), read(m);
    for(int i = 1; i <= n; ++i) read(a[i]);
    for(int i = 1; i <= m; ++i) {
        static int u, v;
        read(u), read(v);
        cactus::addedge(u, v);
    }

    cactus::build();
    tree::dfs(1);

    read(q);
    for(int i = 1; i <= q; ++i) {
        static int ty, x, y;
        read(ty), read(x), read(y);
        printf("%d\n", SEG::query(rt[x], 1, RNG, 1, y, ty));
    }

    return 0;
}
