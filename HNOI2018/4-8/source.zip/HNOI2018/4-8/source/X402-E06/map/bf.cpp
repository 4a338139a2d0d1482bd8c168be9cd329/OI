#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 1000;

int res[2];
int n, m, q;
vector<int> G[N + 5];
int a[N + 5], fa[N + 5], cnt[int(1e6) + 5];

void dfs(int u, int lim, int sgn) {
    if(a[u] <= lim) {
        cnt[a[u]] += sgn;
        if(cnt[a[u]] == 1 && sgn == +1) ++ res[1];
        else if(cnt[a[u]] == 0 && sgn == -1) -- res[1];
        else {
            if(cnt[a[u]] & 1) {
                -- res[0], ++ res[1];
            } else {
                -- res[1], ++ res[0];
            }
        }
    }

    for(int i = 0; i < (int) G[u].size(); ++i) {
        dfs(G[u][i], lim, sgn);
    }
}

int main() {
    freopen("map.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n), read(m);
    for(int i = 1; i <= n; ++i) read(a[i]);
    for(int i = 1; i <= m; ++i) {
        static int u, v;
        read(u), read(v); G[u].pb(v);
    }

    read(q);
    for(int i = 1; i <= q; ++i) {
        static int ty, x, y;
        read(ty), read(x), read(y);

        dfs(x, y, +1);

        printf("%d\n", res[ty]);

        dfs(x, y, -1);
    }

    return 0;
}
