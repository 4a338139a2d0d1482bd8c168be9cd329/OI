#include<iostream>
#include<cstdio>
#define neko 300010
#define chkmax(a,b) ((a)>(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
#define rf(i,a,b) for(register int i=(a);i>=(b);i=~(-i))
int n=300,m=1000;
int main()
{ 
	freopen("connection.in","w",stdout);
	printf("%d %d\n",n,m);
	f(i,2,n)printf("%d %d\n",rand()%(i-1)+1,i);
	f(i,1,m-n+1)printf("%d %d\n",rand()%n+1,rand()%n+1);
	return 0;
}

