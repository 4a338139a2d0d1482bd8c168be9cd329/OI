#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#define neko 5010
#define meko 5010
#define chkmin(a,b) ((a)<(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
#define travel(i,u,v) for(register int i=head[u],v=e[i].v;i;i=e[i].next,v=e[i].v)
struct node
{
	int v,cap,next;
}e[meko<<1];
int n,m,t=1,inf=1e9,S,T,ansx=2e9;
typedef int arr[neko];
arr dis,gap,head,book,E;
void add(int x,int y,int z)
{
	e[++t].v=y;
	E[t]=e[t].cap=z;
	e[t].next=head[x];
	head[x]=t;
	e[++t].v=x;
	E[t]=e[t].cap=0;
	e[t].next=head[y];
	head[y]=t;
}
int dfs(int u,int flow)
{
    if(u==T)return flow;
    int up,maxcap=flow;
    travel(i,u,v)
    {
        if(dis[u]==dis[v]+1&&e[i].cap)
        {
            up=dfs(v,chkmin(maxcap,e[i].cap));
            e[i].cap-=up,e[i^1].cap+=up;
            if(!(maxcap-=up))return flow;
        }
    }if(!(--gap[dis[u]]))dis[S]=1002;
    ++gap[++dis[u]];
    return flow-maxcap;
}
void init()
{
	memset(gap,0,sizeof(gap));
	memset(dis,0,sizeof(dis));
	f(i,1,t)e[i].cap=E[i];
}
int isap()
{
	init();
	int ans=0;
	for(gap[0]=1002;dis[S]<1002;ans+=dfs(S,inf));
	return ans;
}
int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	int x,y;
	scanf("%d%d",&n,&m);
	if(n==(m+1)){printf("1\n");return 0;}
	f(i,1,m)
	{
	//	if(x==1)book[y]=1;
	//	if(y==1)book[x]=1;
		scanf("%d%d",&x,&y),add(x,y,1),add(y,x,1);
	}
	//f(i,1,n)add(S,i,inf),add(i,T,inf);
	S=1,T=2;
	for(T=2;T<=n;T++)
	{
		ansx=chkmin(ansx,isap());
		//if(book[T])printf("%d\n",T);
	}printf("%d\n",ansx);
}
