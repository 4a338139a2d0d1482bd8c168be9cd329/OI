#include<iostream>
#include<cstdio>
#define neko 2010
#define chkmax(a,b) ((a)>(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
#define rf(i,a,b) for(register int i=(a);i>=(b);i=~(-i))
int n,c,p;
long long ans,mod=1e4+7,f[neko][neko],a[neko],b[neko],sum[neko];
template<typename T>
void read(T &x)
{
	char c=getchar();T p=1;x=0;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c))x=(x<<1)+(x<<3)+(c^'0'),c=getchar();
	x*=p;
}
/*void build()
{
	blk=sqrt(n);
	f(i,0,n)bl[i]=(i-1)/blk+1;
	f(i,1,n)Prda[bl[i]]=(Prda[bl[i]]*a[i])%mod;
}*/
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout); 
	int opt,x,y;
	scanf("%d%d",&n,&c);
	f(i,1,n)read(a[i]);
	f(i,1,n)read(b[i]);
	scanf("%d",&p);
//	build();
	f[0][0]=1;
/*	f(i,1,n)
	 f(j,0,i)
	  f[i][j]=f[i-1][j]*b[i]%mod;*/
	while(p--)
	{
		read(opt),read(x),read(y);
		a[opt]=x,b[opt]=y;
		ans=0,sum[0]=1;
		f(i,1,n)sum[i]=sum[i-1]*(a[i]+b[i])%mod; 
		/*f(i,1,n)
		{
			f(j,1,chkmin(blk,i))f[i][j]=(f[i][j]+f[i-1][j-1]*a[i]+f[i-1][j]*b[i])%mod;
			f(j,bl[1]+1,bl[i]-1)f[i][j*blk]=f[i-1]
			if(bl[1]!=bl[i])
		}*/
		f(i,1,n)
		 f(j,0,c-1)
		 {
			if(j)f[i][j]=(f[i-1][j-1]*a[i]+f[i-1][j]*b[i])%mod;
			else f[i][j]=f[i-1][j]*b[i]%mod;
			if(i==n)ans=(ans+f[i][j])%mod;
		 }
		printf("%lld\n",(sum[n]-ans+mod)%mod);
	}
	return 0;
}

