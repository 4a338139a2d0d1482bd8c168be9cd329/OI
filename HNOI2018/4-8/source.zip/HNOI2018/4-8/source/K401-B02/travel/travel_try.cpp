#include<iostream>
#include<cstdio>
#define neko 300010
#define chkmax(a,b) ((a)>(b)?(a):(b))
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~i))
#define rf(i,a,b) for(register int i=(a);i>=(b);i=~(-i))
int n,a[neko],Ans[];
namespace Short_Seg
{
	void build(int root,int l,int r)
	{
		if(l==r)
		{
			Ans[root][1]=a[l];
			Ans[root][0]=b[l];
			return;
		}
		build(lson);
		build(rson);
	}
	void pushup(int root)
	{
		memset(Ans,0,sizeof(Ans));
		f(i,0,c)
		 f(j,0,c)
		  Ans[root][chkmin(i+j,c)]=(Ans[root][chkmin(i+j,c)]+Ans[root<<1][i]*Ans[root<<1|1][j])%mod;
	}
	void update(int root,int l,int r,int tag,int tagx,int tagy)
	{
		if(l==r)Ans[0]=tagy,Ans[1]=tagx;
		if(tag<=mid)update(lson,ori);
		if(tag>mid)update(rson,ori);
	}
}
int main()
{
	scanf("%d%d",&n,&c);
	f(i,1,n)read(a[i]);
	f(i,1,n)read(b[i]);
	scanf("%d",&p);
	build(1,1,n);
	while(p--)
	{
		read(opt),read(x),read(y);
		update(1,1,n,opt,x,y); 
		printf("%d\n",Ans[root][c]);
	}
	return 0;
}

