#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=405;
int n,m,gra[maxn][maxn],to[maxn],dis[maxn];
int ans=2147483640;
bool vis[maxn];
int main(){
    freopen("connection.in","r",stdin);
    freopen("connection.out","w",stdout);
    read(n);read(m);
    while(m--){
        int u,v;
        read(u);read(v);
        gra[u][v]++;
        gra[v][u]++;
    }
	for(register int i=1;i<=n;++i){
        to[i]=i;
    }
    while(n>=2){
        int mx=2,pre=1;
        for(register int i=2;i<=n;++i){
            dis[to[i]]=gra[to[1]][to[i]];
            if(dis[to[i]]>dis[to[mx]])mx=i;
        }
        memset(vis,0,sizeof(vis));
        vis[to[1]]=1;
        for(register int i=2;i<=n;++i){
            if(i==n){
                ans=min(ans,dis[to[mx]]);
                for(register int j=1;j<=n;++j){
                    gra[to[pre]][to[j]]+=gra[to[j]][to[mx]];
                    gra[to[j]][to[pre]]=gra[to[pre]][to[j]];
                }
                to[mx]=to[n--];
                break;
            }
            pre=mx;
            vis[to[mx]]=1;
            mx=-1;
            for(register int j=2;j<=n;++j){
                if(!vis[to[j]]){
                    dis[to[j]]+=gra[to[pre]][to[j]];
                    if(mx==-1||dis[to[mx]]<dis[to[j]])mx=j;
                }
            }
        }
    }
    printf("%d\n",ans);
    return 0;
}
