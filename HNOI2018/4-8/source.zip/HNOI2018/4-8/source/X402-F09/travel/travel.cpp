#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=1050;
const int mod=10007;
int n,c,p;
int dp[maxn][maxn],a[maxn],b[maxn],ans;
int main(){
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
    read(n);read(c);
    for(register int i=1;i<=n;++i){
        read(a[i]);
    }
    for(register int i=1;i<=n;++i){
        read(b[i]);
    }
    read(p);
    while(p--){
        int I,x,y;
        read(I);read(x);read(y);
        a[I]=x;b[I]=y;
        dp[0][0]=1;
        for(register int i=1;i<=n;++i){
            dp[i][0]=dp[i-1][0]*b[i];
            for(register int j=1;j<=n;++j){
                dp[i][j]=(1ll*b[i]*dp[i-1][j]+1ll*a[i]*dp[i-1][j-1])%mod;
            }
        }
        ans=1;
        for(register int i=1;i<=n;++i){
            ans=(1ll*ans*(1ll*a[i]+1ll*b[i])%mod)%mod;
        }
        for(register int i=0;i<=c-1;++i){
            ans-=dp[n][i];
            while(ans<0)ans+=mod;
        }
        printf("%d\n",ans);
    }
    return 0;
}
