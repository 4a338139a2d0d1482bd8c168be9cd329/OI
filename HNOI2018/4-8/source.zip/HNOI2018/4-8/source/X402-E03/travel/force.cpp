#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 1e5+5, Mod = 10007 ;
LL n, m, f[maxn][30], a[maxn], b[maxn] ;
void DP() {
	LL i, j ;
	f[0][0] = 1 ;
	for ( i = 0 ; i ^ n ; i ++ ) {
		memset (f[i+1], 0, sizeof f[i+1]) ;
		for ( j = 0 ; j < m ; j ++ ) {
			(f[i+1][j] += f[i][j]*b[i+1]%Mod) %= Mod ;
			(f[i+1][j+1] += f[i][j]*a[i+1]%Mod) %= Mod ;
		}
		(f[i+1][m] += f[i][m]*(a[i+1]+b[i+1])%Mod) %= Mod ;
	}
	printf ( "%lld\n", f[n][m] ) ;
}
int main() {
	freopen ( "travel.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;
	LL _, i ;
	Read(n), Read(m) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(a[i]), a[i] = (a[i]%Mod+Mod)%Mod ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(b[i]), b[i] = (b[i]%Mod+Mod)%Mod ;
	/*DP() ;
	for ( i = 1 ; i <= n ; i ++, puts("") )
		for ( int j = 0 ; j <= m ; j ++ )
			printf ( "%lld ", f[i][j] ) ;
	return 0 ;*/
	Read(_) ;
	while (_--) {
		Read(i), Read(a[i]), Read(b[i]) ;
		a[i] = (a[i]%Mod+Mod)%Mod ;
		b[i] = (b[i]%Mod+Mod)%Mod ;
		DP() ;
	}
	cerr << "force : " << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
