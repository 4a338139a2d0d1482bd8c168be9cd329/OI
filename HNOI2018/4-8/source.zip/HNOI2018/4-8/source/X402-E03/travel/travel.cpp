#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) f |= c == '-' ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1e5+5, Mod = 10007 ;
int n, m ;
struct Matrix {
	int s[21][21], N, M ;
	friend Matrix operator * ( Matrix A, Matrix B ) {
		register int i, j, k ;
		Matrix C ;
		C.N = A.N, C.M = B.M ;
		memset (C.s, 0, sizeof C.s) ;
		for ( i = 0 ; i <= C.N ; i ++ )
			for ( k = i ; k <= A.M ; k ++ )
				if (A.s[i][k]) {
					for ( j = k ; j <= C.M ; j ++ )
						(C.s[i][j] += A.s[i][k]*B.s[k][j]%Mod) %= Mod ;
				}
		return C ;
	}
} ;
Matrix tree[maxn*3], t, st ;
int a[maxn], b[maxn] ;
void make ( int aa, int bb ) {
	register int i ;
	t.N = t.M = m ;
	for ( i = 0 ; i <= m ; i ++ ) {
		t.s[i][i] = bb ;
		if (i ^ m) t.s[i][i+1] = aa ;
	}
	(t.s[m][m] += aa) %= Mod ;
}
void push_up ( int h ) { tree[h] = tree[h<<1]*tree[h<<1|1] ; }
void create ( int h, int l, int r ) {
	if (l == r) {
		make(a[l], b[l]) ;
		tree[h] = t ;
		return ;
	}
	register int mid = (l+r)>>1 ;
	create(h<<1, l, mid), create(h<<1|1, mid+1, r) ;
	push_up(h) ;
}
int pos ;
void Update ( int h, int l, int r ) {
	if (l == r) {
		tree[h] = t ;
		return ;
	}
	register int mid = (l+r)>>1 ;
	if (pos <= mid) Update(h<<1, l, mid) ;
	else if (pos > mid) Update(h<<1|1, mid+1, r) ;
	push_up(h) ;
}
int main() {
	freopen ( "travel.in", "r", stdin ) ;
	freopen ( "travel.out", "w", stdout ) ;
	register int i, _ ;
	Read(n), Read(m) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(a[i]), a[i] = (a[i]%Mod+Mod)%Mod ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(b[i]), b[i] = (b[i]%Mod+Mod)%Mod ;
	//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	create(1, 1, n) ;
	Read(_) ;
	st.N = 0, st.M = m ;
	for ( i = 1 ; i <= m ; i ++ )
		st.s[0][i] = 0 ;
	st.s[0][0] = 1 ;
	while (_--) {
		Read(i), Read(a[i]), Read(b[i]) ;
		a[i] = (a[i]%Mod + Mod)%Mod ;
		b[i] = (b[i]%Mod + Mod)%Mod ;
		make(a[i], b[i]) ;
		pos = i ;
		Update(1, 1, n) ;
		printf ( "%d\n", (st*tree[1]).s[0][m] ) ;
		//cerr << _ << " " << (double)clock()/CLOCKS_PER_SEC << endl ;
	}
	//cerr << "solve : " << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
