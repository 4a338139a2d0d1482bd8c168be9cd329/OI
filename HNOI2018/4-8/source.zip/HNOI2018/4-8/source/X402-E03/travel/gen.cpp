#include <bits/stdc++.h>
using namespace std ;
int main() {
	srand(time(0)) ;
	freopen ( "travel.in", "w", stdout ) ;
	int i, n, m, _ ;
	srand(time(0)) ;
	n = 3000, m = 20, _ = 3000 ;
	printf ( "%d %d\n", n, m ) ;
	for ( i = 1 ; i <= n ; i ++ ) printf ( "%d ", rand() ) ; puts("") ;
	for ( i = 1 ; i <= n ; i ++ ) printf ( "%d ", rand() ) ; puts("") ;
	printf ( "%d\n", _ ) ;
	while (_--) {
		printf ( "%d %d %d\n", rand()%n+1, rand(), rand() ) ;
	}
	return 0 ;
}
