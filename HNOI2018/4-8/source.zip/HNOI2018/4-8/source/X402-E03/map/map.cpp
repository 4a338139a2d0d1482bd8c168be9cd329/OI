#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1e6+5 ;
int n, m, e = 1, Begin[maxn], Next[maxn*2], To[maxn*2], tg, col[maxn] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
int c[maxn], lim ;
bool vis[maxn], gt[maxn], cv[maxn] ;
void init() {
	memset (c, 0, sizeof c) ;
	memset (gt, 0, sizeof gt) ;
	memset (cv, 0, sizeof cv) ;
	memset (vis, 0, sizeof vis) ;
}
bool dfs ( int x ) {
	vis[x] = 1 ;
	if (x == tg) return 1 ;
	int i, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (vis[u]) continue ;
		if (dfs(u)) gt[x] = cv[i] = cv[i ^ 1] = 1 ;
	}
	return gt[x] ;
}
void solve ( int x ) {
	vis[x] = 1, ++ c[col[x]] ;
	//printf ( "solve %d col=%d c=%d\n", x, col[x], c[col[x]] ) ;
	int i, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (gt[u] || cv[i] || vis[u]) continue ;
		solve(u) ;
	}
}
int main() {
	freopen ( "map.in", "r", stdin ) ;
	freopen ( "map.out", "w", stdout ) ;
	int i, tp, x, u, _, ans ;
	Read(n), Read(m) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(col[i]) ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(x), Read(u) ;
		add(x, u), add(u, x) ;
	}
	Read(_) ;
	while (_--) {
		Read(tp) ;
		ans = 0 ;
		Read(x), Read(u) ;
		init() ;
		tg = x ;
		dfs(1) ;
		solve(x) ;
		for ( i = 1 ; i <= u ; i ++ )
			if (c[i] > 0 && c[i]%2 == tp)
				++ ans ;
		printf ( "%d\n", ans ) ;
	}
	return 0 ;
}
