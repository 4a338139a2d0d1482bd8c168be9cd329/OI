#include <bits/stdc++.h>
using namespace std ;
void chkmin ( int &a, int b ) { a = a<b? a:b ; }
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 305, maxm = 2005, inf = 0x3f3f3f3f ;
int n, m, e = 1, Begin[maxn], Next[maxm], To[maxm], W[maxm], Weight[maxm] ;
int st, ed, dis[maxn], cur[maxn], dfn[maxn], value[maxn] ;
bool vis[maxn] ;
void add ( int x, int y, int z ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
	Weight[e] = z ;
}
queue <int> Q ;
bool bfs() {
	while (!Q.empty()) Q.pop() ;
	memset (dis, inf, sizeof dis) ;
	int i, x, u ;
	dis[st] = 0 ;
	Q.push(st) ;
	while (!Q.empty()) {
		x = Q.front() ;
		Q.pop() ;
		for ( i = Begin[x] ; i ; i = Next[i] ) {
			u = To[i] ;
			if (dis[u] == inf && W[i] > 0) {
				dis[u] = dis[x]+1 ;
				Q.push(u) ;
			}
		}
	}
	return dis[ed] ^ inf ;
}
int dfs ( int x, int val ) {
	int u, rec, tot = 0 ;
	if (x == ed || val == 0) return val ;
	for ( int &i = cur[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (dis[u] == dis[x]+1 && W[i] > 0) {
			rec = dfs(u, min(val, W[i])) ;
			W[i] -= rec ;
			W[i ^ 1] += rec ;
			tot += rec ;
			val -= rec ;
			if (!val) return tot ;
		}
	}
	return tot ;
}
int dinic() {
	memcpy (W, Weight, sizeof W) ;
	int rec = 0 ;
	while (bfs()) {
		memcpy (cur, Begin, sizeof cur) ;
		rec += dfs(st, inf) ;
	}
	//printf ( "dinic <%d,%d>=%d\n", st, ed, rec ) ;
	return rec ;
}
bool cmp ( int x, int y ) { return value[x] < value[y] ; }
int main() {
	freopen ( "connection.in", "r", stdin ) ;
	freopen ( "connection.out", "w", stdout ) ;
	Read(n), Read(m) ;
	srand(time(0)) ;
	int i, x, u, lim = CLOCKS_PER_SEC*0.93 ;
	for ( i = 1 ; i <= n ; i ++ )
		value[i] = rand(), dfn[i] = i ;
	sort(dfn+1, dfn+n+1, cmp) ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(x), Read(u) ;
		x = dfn[x], u = dfn[u] ;
		add(x, u, 1), add(u, x, 1) ;
	}
	int ans = inf ;
	for ( st = 1 ; st <= n ; st ++ )
		for ( ed = st+1 ; ed <= n ; ed ++ ) {
			chkmin(ans, dinic()) ;
			if (clock() >= lim) goto end ;
		}
	end :
	printf ( "%d\n", ans ) ;
	//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
