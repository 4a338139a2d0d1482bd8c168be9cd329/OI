#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int maxn=1e5,maxc=25,mo=1e4+7;

int n,c,q,a[maxn],b[maxn];

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

void Add(int& x,int y){
    x+=y;
    if(x>=mo) x-=mo;
    if(x<0) x+=mo;
}

namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    int T[maxn<<2][20],Sum[maxn<<2];

    void pushup(int h){
        for(int i=0;i<c;i++){
            static LL tmp; tmp=0;
            for(int j=0;j<=i;j++) tmp+=1ll*T[ls][j]*T[rs][i-j];
            T[h][i]=tmp%mo;
        }
        Sum[h]=1ll*Sum[ls]*Sum[rs]%mo;
    }

    void update(int h,int l,int r,int p,int x,int y){
        if(l==r){
            T[h][1]=x; T[h][0]=y;
            Sum[h]=x+y;
            if(Sum[h]>=mo) Sum[h]-=mo;
            return;
        }

        if(p<=mid) update(ls,lc,p,x,y);
        else update(rs,rc,p,x,y);
        pushup(h);
    }
}

using namespace SGT;

int main(){
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);

    read(n); read(c);
    for(int i=1;i<=n;i++) read(a[i])%=mo;
    for(int i=1;i<=n;i++) read(b[i])%=mo;
    
    for(int i=1;i<=n;i++) update(1,1,n,i,a[i],b[i]);

    read(q);
    while(q--){
        int p,x,y;
        read(p); read(x)%=mo; read(y)%=mo;
        update(1,1,n,p,x,y);

        int ans=Sum[1];
        for(int i=0;i<c;i++) Add(ans,-T[1][i]);
        printf("%d\n",ans);
    }

    return 0;
}
