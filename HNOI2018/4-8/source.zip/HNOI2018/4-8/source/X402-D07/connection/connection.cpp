#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=15,maxm=25;

int n,m;

struct data{
    int u,v;
} E[maxm];

int head[maxn],nxt[maxm<<1],to[maxm<<1],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}

bool vis[maxn];
void dfs(int u){
    vis[u]=1;
    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(!vis[v]) dfs(v);
    }
}

int main(){
    freopen("connection.in","r",stdin);
    freopen("connection.out","w",stdout);

    read(n); read(m);
    for(int i=1;i<=m;i++) read(E[i].u),read(E[i].v);

    for(int i=1;i<=m;i++)
        for(int s=0;s<(1<<m);s++) if(__builtin_popcount(s)==i){
            memset(head,0,sizeof head); e=0;
            memset(vis,0,sizeof vis);
            for(int j=1;j<=m;j++) if(!((s>>(j-1))&1)) ae(E[j].u,E[j].v),ae(E[j].v,E[j].u);
            dfs(1);
            bool flag=0;
            for(int j=1;j<=n;j++) if(!vis[j]){ flag=1; break; }
            if(flag) printf("%d\n",i),exit(0);
        }

    return 0;
}
