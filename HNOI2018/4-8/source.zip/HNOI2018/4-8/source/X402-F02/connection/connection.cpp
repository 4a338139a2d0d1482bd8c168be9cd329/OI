#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=300+5,M=1e3+5;
template<typename T>bool cmax(T &a,T b){return (a<b)?a=b,1:0;}
template<typename T>bool cmin(T &a,T b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("connection.in","r",stdin);
      freopen("connection.out","w",stdout);
  #endif
}
int n,m;
int head[N],tt;
struct edge
{
	int v,flow,nex;
}e[M<<2];
void add(int x,int y,int z)
{
	e[++tt]=(edge){y,z,head[x]},head[x]=tt;
	e[++tt]=(edge){x,0,head[y]},head[y]=tt;
}
int t1[M],t2[M];
void input()
{
	n=read<int>(),m=read<int>();
	For(i,1,m)t1[i]=read<int>(),t2[i]=read<int>();
}
const int inf=0x3f3f3f3f;
/*namespace sub1
{
	int p[11];
	void solve()
	{
		int ans=inf,s=(1<<n)-1,res;
		p[1]=1;For(i,2,n)p[i]=p[i-1]<<1;
		For(i,1,s-1)
		{
			res=0;
			For(j,1,n)
			{
				if(!(i&p[j]))continue;
				for(register int k=head[j];k;k=nex[k])
				{
					if(!(i&p[to[k]]))++res;
				}
			}
			cmin(ans,res);
		}
		write(ans,'\n');
	}
}*/
namespace sub2
{
	int dis[N],gap[N],cur[N];
	int dfs(int u,int flow,int s,int t)
	{
		if(u==t)return flow;
		int res=flow,f,v;
		for(register int &i=cur[u];i;i=e[i].nex)
		{
			v=e[i].v;
			if(dis[u]==dis[v]+1&&e[i].flow)
			{
				f=dfs(v,min(res,e[i].flow),s,t);
				e[i].flow-=f,e[i^1].flow+=f;
				if(!(res-=f))return flow;
			}
		}
		if(!--gap[dis[u]])dis[s]=n+1;
		++gap[++dis[u]];
		return flow-res;
	}
	int ans;
	int isap(int s,int t)
	{
		memset(dis,0,sizeof dis);
		memset(gap,0,sizeof gap);
		int res=0;
		for(gap[0]=n+1;dis[s]<n+1;)
		{
			memcpy(cur,head,sizeof cur);
			res+=dfs(s,inf,s,t);
			if(res>=ans)return inf;
		}
		return res;
	}
	void rebuild()
	{
		memset(head,0,sizeof head);tt=1;
		For(i,1,m)add(t1[i],t2[i],1),add(t2[i],t1[i],1);
	}
	int d[N];
	void solve()
	{
		ans=inf;
		For(i,1,m)++d[t1[i]],++d[t2[i]];
		For(i,1,n)cmin(ans,d[i]);
		For(i,2,n)
		{
			rebuild();
			cmin(ans,isap(1,i));
		}
		write(ans,'\n');
	}
}
void work()
{
	if(n==m+1)puts("1");
	else sub2::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
