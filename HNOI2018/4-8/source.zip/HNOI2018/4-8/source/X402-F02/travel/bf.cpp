#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
template<typename T>bool cmax(T &a,T b){return (a<b)?a=b,1:0;}
template<typename T>bool cmin(T &a,T b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("travel.in","r",stdin);
      freopen("bf.out","w",stdout);
  #endif
}
int n,c;
int a[N],b[N];
void input()
{
	n=read<int>(),c=read<int>();
	For(i,1,n)a[i]=read<int>();
	For(i,1,n)b[i]=read<int>();
}
const int mo=1e4+7;
int dp[N][21];
void cal()
{
	int ans=1;
	dp[0][0]=1;
	For(i,1,n)
	{
		ans=ans*(a[i]+b[i])%mo;
		dp[i][0]=dp[i-1][0]*b[i]%mo;
		For(j,1,c-1)dp[i][j]=(dp[i-1][j-1]*a[i]%mo+dp[i-1][j]*b[i]%mo)%mo;
	}
	//cout<<ans<<' ';
	For(i,0,c-1)ans=(ans-dp[n][i]+mo)%mo;
	write(ans,'\n');
}
void work()
{
	int pos,x,y;
	int m=read<int>();
	while(m--)
	{
		pos=read<int>(),x=read<int>(),y=read<int>();
		a[pos]=x,b[pos]=y;
		cal();
	}
}
int main()
{
	file();
	input();
	work();
	return 0;
}
