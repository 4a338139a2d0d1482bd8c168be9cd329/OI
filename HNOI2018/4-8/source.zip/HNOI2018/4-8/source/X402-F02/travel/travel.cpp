#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
template<typename T>bool cmax(T &a,T b){return (a<b)?a=b,1:0;}
template<typename T>bool cmin(T &a,T b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("travel.in","r",stdin);
      freopen("travel.out","w",stdout);
  #endif
}
const int mo=1e4+7;
int n,c,a[N],b[N];
void input()
{
	n=read<int>(),c=read<int>();
	For(i,1,n)a[i]=read<int>(),a[i]%=mo;
	For(i,1,n)b[i]=read<int>(),b[i]%=mo;
}
#define mid ((l+r)>>1)
#define lson h<<1,l,mid
#define rson h<<1|1,mid+1,r
int sum[N<<2][21],num[N<<2];
void add(int &x,int y)
{
	x+=y;if(x>=mo)x-=mo;
}
void push_up(int h)
{
	int ls=h<<1,rs=ls|1;
	For(i,0,c-1)
	{
		sum[h][i]=0;
		For(j,0,i)add(sum[h][i],sum[ls][j]*sum[rs][i-j]%mo);
	}
	num[h]=num[ls]*num[rs]%mo;
}
void build(int h,int l,int r)
{
	if(l==r)sum[h][1]=a[l],sum[h][0]=b[l],num[h]=(a[l]+b[l])%mo;
	else
	{
		build(lson),build(rson);
		push_up(h);
	}
}
void update(int h,int l,int r,int pos,int A,int B)
{
	if(l==r)sum[h][1]=A,sum[h][0]=B,num[h]=(A+B)%mo;
	else
	{
		if(pos<=mid)update(lson,pos,A,B);
		else update(rson,pos,A,B);
		push_up(h);
	}
}
int m,ans;
void work()
{
	int pos,x,y;
	build(1,1,n);
	m=read<int>();
	while(m--)
	{
		pos=read<int>(),x=read<int>(),y=read<int>();
		x%=mo,y%=mo;
		update(1,1,n,pos,x,y);
		ans=num[1];
		For(i,0,c-1)add(ans,mo-sum[1][i]);
		write(ans,'\n');
	}
}
int main()
{
	file();
	input();
	work();
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
