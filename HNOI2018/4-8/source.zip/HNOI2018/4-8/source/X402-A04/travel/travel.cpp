#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=91050;
const int MAXC=23;
const int mod=10007;
int qpow(int a,int n)
{
	int ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int n,c;
int f[N<<2][MAXC],C[N];
void maintain(int o)
{
	int lc=o<<1,rc=o<<1|1;
	for(int i=0;i<c;++i) f[o][i]=0;
	for(int i=0;i<c;++i) if(f[lc][i]) for(int j=0;i+j<c;++j) if(f[rc][j])
		f[o][i+j]=(f[o][i+j]+f[lc][i]*f[rc][j])%mod;
}
void build(int o,int l,int r)
{
	f[o][0]=1;
	if(l==r) {f[o][1]=C[l];return ;}
	int mid=l+r>>1;
	build(o<<1,l,mid); build(o<<1|1,mid+1,r);
	maintain(o);
}
void update(int o,int l,int r,int x)
{
	if(l==r) {f[o][1]=C[l];return ;}
	int mid=l+r>>1;
	if(x<=mid) update(o<<1,l,mid,x);
	else update(o<<1|1,mid+1,r,x);
	maintain(o);
}

int A[N],B[N];
void wj()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	n=read(); c=read();
	int pro=1,bm=1;
	for(int i=1;i<=n;++i) A[i]=read()%mod;
	for(int i=1;i<=n;++i) B[i]=read()%mod;
	for(int i=1;i<=n;++i) 
	{
		pro=pro*(A[i]+B[i])%mod;
		bm=bm*B[i]%mod;
		C[i]=A[i]*qpow(B[i],mod-2)%mod;
	}
	build(1,1,n);
	int Q=read();
	for(int cas=1;cas<=Q;++cas)
	{
		int k=read(),x=read()%mod,y=read()%mod;
		pro=pro*qpow(A[k]+B[k],mod-2)%mod*(x+y)%mod;
		bm=bm*qpow(B[k],mod-2)%mod*y%mod;
		C[k]=x*qpow(y,mod-2)%mod;
		A[k]=x; B[k]=y;
		update(1,1,n,k);
		int sum=0;
		for(int i=0;i<c;++i) sum=(sum+f[1][i])%mod;
		printf("%d\n",(pro-bm*sum%mod+mod)%mod);
	}
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
