#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=91050;
const int MAXC=23;
const int mod=10007;
int qpow(int a,int n)
{
	int ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int n,c;
int f[MAXC][N];

int A[N],B[N],C[N];
void wj()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
}
int main()
{
	wj();
	n=read(); c=read();
	int pro=1,bm=1;
	for(int i=1;i<=n;++i) A[i]=read()%mod;
	for(int i=1;i<=n;++i) B[i]=read()%mod;
	for(int i=1;i<=n;++i) 
	{
		pro=pro*(A[i]+B[i])%mod;
		bm=bm*B[i]%mod;
		C[i]=A[i]*qpow(B[i],mod-2)%mod;
	}
	int Q=read();
	for(int cas=1;cas<=Q;++cas)
	{
		int k=read(),x=read()%mod,y=read()%mod;
		pro=pro*qpow(A[k]+B[k],mod-2)%mod*(x+y)%mod;
		bm=bm*qpow(B[k],mod-2)%mod*y%mod;
		C[k]=x*qpow(y,mod-2)%mod;
		A[k]=x; B[k]=y;
		
		for(int i=0;i<=n;++i) f[0][i]=1;
		for(int j=1;j<c;++j) for(int i=1;i<=n;++i)
			f[j][i]=(f[j][i-1]+C[i]*f[j-1][i-1])%mod;
		int sum=0;
		for(int j=0;j<c;++j) sum=(sum+f[j][n])%mod;
		printf("%d\n",(pro-bm*sum%mod+mod)%mod);
	}
	return 0;
}
