#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=300050;
int head[N],ecnt=1;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++ecnt]=(node){y,head[x]};head[x]=ecnt;
	e[++ecnt]=(node){x,head[y]};head[y]=ecnt;
}
pii P[N]; int PE=0;
int n,m,A[N],dot,low[N],dfn[N],clk=0,stk[N],top=0;

void dfs(int u,int pre)
{
	dfn[u]=low[u]=++clk;
	stk[++top]=u;
	for(int i=head[u];i;i=e[i].next) if(i!=(pre^1))
	{
		int v=e[i].to;
		if(!dfn[v])
		{
			dfs(v,i),low[u]=min(low[u],low[v]);
			if(low[v]>=dfn[u])
			{
				dot++;
				while(stk[top]!=u)
				{
					P[++PE]=pii(dot,stk[top]);
					top--;
				}
				P[++PE]=pii(dot,u);
			}
		}
		else low[u]=min(low[u],dfn[v]);
	}
}

struct ASK
{
	int typ,y,id;
	ASK(int typ=0,int y=0,int id=0):typ(typ),y(y),id(id) { }
};
vector<ASK>ask[N];
int efn[N],rnk[N];
void dfs1(int u,int f)
{
	dfn[u]=++clk; rnk[clk]=u;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==f) continue;
		dfs1(v,u);
	}
	efn[u]=clk;
}

const int M=1000050;
int vis[M];
int cnt[2]={0};

void wj()
{
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=1;i<=n;++i) A[i]=read();
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read();
		add(x,y);
	}
	dot=n;
	dfs(1,0);
	//cerr<<dot-n<<endl;
	//for(int i=1;i<=PE;++i) cerr<<P[i].fi<<' '<<P[i].se<<endl;

	ecnt=0;
	for(int i=1;i<=n;++i) head[i]=0;
	for(int i=1;i<=PE;++i) add(P[i].fi,P[i].se);
	clk=0;
	dfs1(1,0);
	int Q=read();
	for(int cas=1;cas<=Q;++cas)
	{
		int typ=read(),x=read(),y=read();
		cnt[0]=cnt[1]=0;
		for(int i=dfn[x];i<=efn[x];++i)
		{
			if(rnk[i]>n) continue;
			if(A[rnk[i]]>y) continue;
			vis[A[rnk[i]]]++;
			if(vis[A[rnk[i]]]!=1) cnt[vis[A[rnk[i]]]-1&1]--;
			cnt[vis[A[rnk[i]]]&1]++;
		}
		for(int i=dfn[x];i<=efn[x];++i)
		{
			if(rnk[i]>n) continue;
			if(A[rnk[i]]>y) continue;
			vis[A[rnk[i]]]=0;
		}
		printf("%d\n",cnt[typ]);
	}
	return 0;
}
