#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=300050;
int head[N],ecnt=1;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++ecnt]=(node){y,head[x]};head[x]=ecnt;
	e[++ecnt]=(node){x,head[y]};head[y]=ecnt;
}
pii P[N]; int PE=0;
int n,m,A[N],dot,low[N],dfn[N],clk=0,stk[N],top=0;

void dfs(int u,int pre)
{
	dfn[u]=low[u]=++clk;
	stk[++top]=u;
	for(int i=head[u];i;i=e[i].next) if(i!=(pre^1))
	{
		int v=e[i].to;
		if(!dfn[v])
		{
			dfs(v,i),low[u]=min(low[u],low[v]);
			if(low[v]>=dfn[u])
			{
				dot++;
				while(stk[top]!=u)
				{
					P[++PE]=pii(dot,stk[top]);
					top--;
				}
				P[++PE]=pii(dot,u);
			}
		}
		else low[u]=min(low[u],dfn[v]);
	}
}

struct ASK
{
	int typ,y,id;
	ASK(int typ=0,int y=0,int id=0):typ(typ),y(y),id(id) { }
};
vector<ASK>ask[N];
int efn[N],rnk[N];
void dfs1(int u,int f)
{
	dfn[u]=++clk; rnk[clk]=u;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==f) continue;
		dfs1(v,u);
	}
	efn[u]=clk;
}

int Ans[N],buc[N],tot=0;
int rt[N],ch[N*30][2],cnt[N*30][2],val[N*30],sz=0;
vector<int>ve;
inline int newnode()
{
	int x;
	if(ve.size()) x=ve.back(),ve.pop_back();
	else x=++sz;
	ch[x][0]=ch[x][1]=0; cnt[x][0]=cnt[x][1]=0; val[x]=0;
	return x;
}
void insert(int &o,int l,int r,int x)
{
	if(!o) o=newnode();
	if(l==r) {cnt[o][1]=1; val[o]=1; return ;}
	int mid=l+r>>1;
	if(x<=mid) insert(ch[o][0],l,mid,x);
	else insert(ch[o][1],mid+1,r,x);
	cnt[o][0]=cnt[ch[o][0]][0]+cnt[ch[o][1]][0];
	cnt[o][1]=cnt[ch[o][0]][1]+cnt[ch[o][1]][1];
}
int merge(int x1,int x2,int l,int r)
{
	if(!x1) return x2; if(!x2) return x1;
	int mid=l+r>>1;
	if(l==r) 
	{
		val[x1]=val[x1]^val[x2];
		cnt[x1][val[x1]]=1; cnt[x1][val[x1]^1]=0;
		ve.pb(x2);
		return x1;
	}
	ch[x1][0]=merge(ch[x1][0],ch[x2][0],l,mid);
	ch[x1][1]=merge(ch[x1][1],ch[x2][1],mid+1,r);
	ve.pb(x2);
	cnt[x1][0]=cnt[ch[x1][0]][0]+cnt[ch[x1][1]][0];
	cnt[x1][1]=cnt[ch[x1][0]][1]+cnt[ch[x1][1]][1];
	return x1;
}
int query(int o,int l,int r,int x,int y,int k)
{
	if(!o) return 0;
	if(x<=l&&r<=y) return cnt[o][k];
	int mid=l+r>>1,ans=0;
	if(x<=mid) ans+=query(ch[o][0],l,mid,x,y,k);
	if(y>mid) ans+=query(ch[o][1],mid+1,r,x,y,k);
	return ans;
}
void print(int o,int l,int r)
{
	if(!o) return ;
	if(l==r) {cerr<<l<<' '<<val[o]<<endl;return ;}
	int mid=l+r>>1;
	print(ch[o][0],l,mid); print(ch[o][1],mid+1,r);
}

void dfs2(int u,int fa)
{
	if(u<=n) insert(rt[u],1,tot,A[u]);
	//if(u==3) print(rt[u],1,tot);
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs2(v,u);
		//if(u==3) cp;
		rt[u]=merge(rt[u],rt[v],1,tot);
	}
	for(int i=0,siz=ask[u].size();i<siz;++i)
	{
		int typ=ask[u][i].typ,y=ask[u][i].y,id=ask[u][i].id;
		//if(u==3) cerr<<A[u]<<' '<<y<<endl;
		Ans[id]=query(rt[u],1,tot,1,y,typ);
	}
}

void wj()
{
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=1;i<=n;++i) A[i]=read(),buc[++tot]=A[i];
	sort(buc+1,buc+1+tot);
	tot=unique(buc+1,buc+1+tot)-(buc+1);
	for(int i=1;i<=n;++i) A[i]=lower_bound(buc+1,buc+1+tot,A[i])-buc;

	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read();
		add(x,y);
	}
	dot=n;
	dfs(1,0);
	//cerr<<dot-n<<endl;
	//for(int i=1;i<=PE;++i) cerr<<P[i].fi<<' '<<P[i].se<<endl;

	ecnt=0;
	for(int i=1;i<=n;++i) head[i]=0;
	for(int i=1;i<=PE;++i) add(P[i].fi,P[i].se);
	clk=0;
	dfs1(1,0);
	int Q=read();
	for(int cas=1;cas<=Q;++cas)
	{
		int typ=read(),x=read(),y=read();
		y=upper_bound(buc+1,buc+1+tot,y)-buc-1;
		if(y) ask[x].pb(ASK(typ,y,cas));
	}
	dfs2(1,0);
	for(int i=1;i<=Q;++i) printf("%d\n",Ans[i]);
	return 0;
}
