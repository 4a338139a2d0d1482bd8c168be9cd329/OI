#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
#include<ctime>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=315;
const int M=1050;
const int inf=0x3f3f3f3f;
int head[N],cnt=1;
struct node
{
	int to,next,w;
}e[M<<2];
inline void add(int x,int y,int w)
{
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],0};head[y]=cnt;
}
int S,T;
queue<int>q;
int dis[N],cur[N];
bool bfs()
{
	for(int i=1;i<=T;++i) dis[i]=-1;
	q.push(S); dis[S]=0;
	while(!q.empty())
	{
		int u=q.front(); q.pop();
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(dis[v]==-1&&e[i].w>0)
				dis[v]=dis[u]+1,q.push(v);
		}
	}
	return dis[T]!=-1;
}
int dfs(int u,int minn)
{
	if(u==T) return minn;
	int sum=0,f=0;
	for(int i=cur[u];i;i=e[i].next)
	{
		cur[u]=i;
		int v=e[i].to;
		if(dis[v]==dis[u]+1&&e[i].w>0&&(f=dfs(v,min(minn-sum,e[i].w))))
		{
			e[i].w-=f; e[i^1].w+=f;
			sum+=f;
			if(sum==minn) return sum;
		}
	}
	return sum;
}
int dinic()
{
	int ans=0;
	while(bfs())
	{
		for(int i=1;i<=T;++i) cur[i]=head[i];
		while(1)
		{
			int tmp=dfs(S,inf);
			if(!tmp) break;
			ans+=tmp;
		}
	}
	return ans;
}

int n,m;
pii p[M];

void wj()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	n=read(); m=read();
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read();
		p[i]=pii(x,y);
	}
	S=n+1; T=n+2;
	int ans=inf;
	for(int i=1;i<=m;++i)
	{
		cnt=1;
		for(int j=1;j<=T;++j) head[j]=0;
		add(S,p[i].fi,inf); add(p[i].se,T,inf);
		for(int j=1;j<=m;++j) if(j!=i) add(p[j].fi,p[j].se,1),add(p[j].se,p[j].fi,1);
		ans=min(ans,dinic()+1);
	}
	printf("%d\n",ans);
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
