#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define pl puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=305;
const int M=1050;
const int inf=0x3f3f3f3f;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[M<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}

int n,m;
pii p[M];
bool vis[N];
void dfs(int u)
{
	vis[u]=1;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(vis[v]) continue;
		dfs(v);
	}
}

void wj()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read();
		p[i]=pii(x,y);
	}
	int tot=1<<m,ans=inf;
	for(int s=0;s<tot;++s)
	{
		if(m-__builtin_popcount(s)>ans) continue;
		cnt=0;
		for(int i=1;i<=n;++i) head[i]=0,vis[i]=0;
		for(int i=1;i<=m;++i) if(s&(1<<i-1)) add(p[i].fi,p[i].se);
		int blk=0;
		for(int i=1;i<=n;++i) if(!vis[i]) dfs(i),blk++;
		if(blk>1) ans=min(ans,m-__builtin_popcount(s));
	}
	printf("%d\n",ans);
	return 0;
}
