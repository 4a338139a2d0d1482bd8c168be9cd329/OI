#include<bits/stdc++.h>

#define For(i, a, b) for(int i = (a);i <= (b); ++i)

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))

#define gnn cerr << "GNN" << endl;

using namespace std;

const int inf = 1e9 + 7;

const int maxn = 100010;

int n, m, Begin[maxn], to[maxn], e = 1, Next[maxn], id[maxn], vis[maxn], tot, pd[maxn];

void add(int x,int y) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get() {
	scanf("%d%d", &n, &m);
	For(i, 1, m) {
		int x, y;
		scanf("%d%d", &x, &y);
		add(x, y), add(y, x);
		id[i] = e;
	}
}

void dfs(int h) {
	pd[h] = 1;
	++ tot;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(vis[i]) continue;
		if(!pd[v]) dfs(v);
	}
}

void bf() {
	int tmp = (1 << m) - 1, Ans = inf;
	For(i, 0, tmp) {
		For(j, 1, e) vis[j] = 0;
		For(j, 1, n) pd[j] = 0;
		For(j, 1, m) {
			if(i & (1 << j-1)) {
				vis[id[j]] = 1;
				vis[id[j]^1] = 1;
			}
		}

		tot = 0;
		dfs(1);
		if(tot != n) Ans = min(Ans, __builtin_popcount(i));
	}

	printf("%d\n", Ans);
}

int main() {
	
	//freopen("connection.in", "r", stdin);
	//freopen("connection.out", "w", stdout);

	Get();
	bf();

	return 0;
}
