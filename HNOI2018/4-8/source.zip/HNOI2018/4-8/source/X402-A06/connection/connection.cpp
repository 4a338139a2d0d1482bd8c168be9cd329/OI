#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum<<1) + (sum<<3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int inf = 1e9 + 7;

int n, m, d[maxn], a[maxn], tmp[maxn], st, en, w[maxn];

int Begin[maxn], to[maxn], e = 1, cur[maxn], Ans = inf, Next[maxn];

void add(int x,int y,int z) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
	w[e] = z;
}

queue<int> q;

void Get() {
	n = read(), m = read();
	e = 1;
	For(i, 1, m) {
		int x = read(), y = read();
		add(x, y, 1), add(y, x, 1);
	}
}

bool bfs() {
	For(i, 1, n) d[i] = 0;
	d[st] = 1;
	q.push(st);
	
	while(!q.empty()) {
		int now = q.front();
		q.pop();

		for(int i = Begin[now];i ;i = Next[i]) {
			int v = to[i];
			if(w[i] && !d[v]) {
				d[v] = d[now] + 1;
				q.push(v);
			}
		}
	}

	return d[en] != 0;
}

int dfs(int h,int flow) {
	if(h == en || !flow) return flow;
	int k, res = 0;

	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(w[i] && d[v] == d[h] + 1 && (k = dfs(v, min(flow, w[i])))) {
			w[i] -= k;
			w[i^1] += k;
			res += k;
			flow -= k;
		}
		if(!flow) return res;
	}

	return res;
}

int solve_maxflow() {
	int ls, ans = 0;
	while(bfs()) {
		while( (ls = dfs(st, inf)) ) ans += ls;
	}
	return ans;
}

void restore() {
	for(int i = 2;i <= e;i += 2) {
		w[i] = (w[i] + w[i^1]) / 2;
		w[i^1] = w[i];
	}
}

void Gomory_tree(int l,int r) {
	if(l >= r) return;
	st = a[l], en = a[r];
	int ans = solve_maxflow();
	Ans = min(Ans, ans);
	restore();
	
	int L = l, R = r;
	For(i, l, r) {
		if(!d[a[i]]) tmp[L++] = a[i];
		else tmp[R--] = a[i];
	}

	For(i, l, r) a[i] = tmp[i];
	Gomory_tree(l, L-1), Gomory_tree(R+1, r);
}

void solve() {
	Ans = inf;
	For(i, 1, n) a[i] = i;
	Gomory_tree(1, n);
	printf("%d\n", Ans);
}

int main() {
	
	freopen("connection.in", "r", stdin);
	freopen("connection.out", "w", stdout);

	Get();
	solve();

	return 0;
}
