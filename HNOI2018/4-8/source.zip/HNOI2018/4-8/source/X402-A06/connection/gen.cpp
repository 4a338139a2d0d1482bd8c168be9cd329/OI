#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)

using namespace std;

int p[20][20];

int main() {
	
	int n = 5, m = 10;
	freopen("connection.in", "w", stdout);
	printf("%d %d\n", n, m);
	srand(time(NULL));

	For(i, 1, m) {
		while(1) {
			int x = rand() % n + 1;
			int y = rand() % n + 1;
			if(x == y) continue;
			printf("%d %d\n", x, y);
			break;
		}
	}

	return 0;
}
