#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum<<1) + (sum<<3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int inf = 1e9 + 7;

const int mod = 10007;

int mo(int x) {
	if(x >= mod) x -= mod;
	return x;
}

int n, C, a[maxn], b[maxn], q, dp[1010][22];
//暴力dp dp[i][j] means 前i个点选了j个去A国
void Get() {
	n = read(), C = read();
	For(i, 1, n) a[i] = mo(read());
	For(i, 1, n) b[i] = mo(read());
	q = read();
}

void __dp() {
	For(i, 0, n) For(j, 0, C+1) dp[i][j] = 0;
	dp[0][0] = 1;

	For(i, 1, n) {
		For(j, 0, C) {
			dp[i][j] += mo(dp[i-1][j] * b[i]);
			if(j) dp[i][j] = mo(dp[i][j] + dp[i-1][j-1] * a[i]);
		}

		dp[i][C+1] = mo(dp[i-1][C] * a[i]);
		dp[i][C+1] = mo(dp[i][C+1] + dp[i-1][C+1] * (a[i] + b[i]) );
	}

	printf("%d\n", mo(dp[n][C] + dp[n][C+1]));
}

void solve_bf() {
	For(i, 1, q) {
		int id = read(), x = mo(read()), y = mo(read());
		a[id] = x, b[id] = y;
		__dp();
	}
}
//Think once, code twice
struct matrix{
	int t[11][11];

	void init() {
		For(i, 0, C+1) For(j, 0, C+1) t[i][j] = 0;
	}
}node[200010], res;

matrix operator * (matrix c, matrix d) {
	res.init();
	For(i, 0, C+1) {
		For(j, 0, C+1) {
			For(k, 0, C+1) {
				res.t[i][j] = mo(res.t[i][j] + c.t[i][k] * d.t[k][j]);
			}
		}
	}
	return res;
}

void merge(int h) {
	node[h] = node[h<<1] * node[h<<1|1];
}

void build(int h,int l,int r) {
	if(l == r) {
		For(i, 0, C+1) {
			node[h].t[i][i] = b[l];
			if(i) node[h].t[i-1][i] = a[l];
		}
		node[h].t[C+1][C+1] += a[l];
		return;
	}

	int mid = l+r >> 1;
	build(h<<1, l, mid);
	build(h<<1|1, mid+1, r);

	merge(h);
}

void updada(int h,int l,int r,int pos) {
	if(l == r) {
		For(i, 0, C+1) {
			node[h].t[i][i] = b[l];
			if(i) node[h].t[i-1][i] = a[l];
		}
		node[h].t[C+1][C+1] += a[l];
		return;
	}

	int mid = l+r >> 1;
	if(pos <= mid) updada(h<<1, l, mid, pos);
	else updada(h<<1|1, mid+1, r, pos);

	merge(h);
}

void solve() {
	build(1, 1, n);
	while(q --) {
		int id = read(), x = mo(read()), y = mo(read());
		a[id] = x, b[id] = y;
		updada(1, 1, n, id);
		printf("%d\n", mo(node[1].t[0][C] + node[1].t[0][C+1]) );
	}
}

int main() {

	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);

	Get();

	if(n <= 1000) solve_bf();
	else solve();

	return 0;
}
