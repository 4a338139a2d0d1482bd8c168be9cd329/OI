#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum<<1) + (sum<<3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int inf = 1e9 + 7;

int n, m, a[maxn], Begin[maxn], to[maxn], e, Next[maxn], q;

void add(int x,int y) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get() {
	n = read(), m = read();
	For(i, 1, n) a[i] = read();
	For(i, 1, m) {
		int x = read(), y = read();
		add(x, y), add(y, x);
	}
	q = read();
}

int vis[maxn], pd[maxn], link[1010][1010], nowid;

void dfs(int h) {
	link[nowid][h] = 1;
	vis[h] = 1;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(!pd[v] && !vis[v]) dfs(v);
	}
}

void pre_work() {
	For(i, 1, n) {
		nowid = i;
		pd[i] = 1;
		if(i != 1) dfs(1);
		pd[i] = 0;

		For(j, 1, n) vis[j] = 0;
	}
}

int ans[maxn];

void solve() {
	pre_work();
	while(q--) {
		int tp = read(), x = read(), y = read();
		For(i, 0, 100) ans[i] = 0;
		For(i, 1, n) {
			if(!link[x][i]) {
				ans[a[i]] ++;
			}
		}

		int Ans = 0;
		For(i, 0, min(y, 100) ) if(ans[i] != 0 && ans[i]%2 == tp) ++ Ans;
		printf("%d\n", Ans);
	}
}

int main() {

	freopen("map.in", "r", stdin);
	freopen("map.out", "w", stdout);

	Get();
	solve();

	return 0;
}
