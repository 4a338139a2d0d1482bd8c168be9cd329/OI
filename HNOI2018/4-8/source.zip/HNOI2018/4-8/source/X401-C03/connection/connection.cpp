#include<bits/stdc++.h>
using namespace std;

namespace Dinic{
    #define NTX 300
    #define INF 1e9+7
    vector<int>to  [605];
    vector<int>com [605];
    vector<int>flow[605];

    int cur [605];
    int deep[605];
    int F;int T;
	
    void _addedge(int _u,int _v,int _f){
        to[ _u ].push_back( _v );
        to[ _v ].push_back( _u );
        com[ _u ].push_back( flow[_v].size() );
        com[ _v ].push_back( flow[_u].size() );
        flow[ _u ].push_back( _f );
        flow[ _v ].push_back( 0 );
    }

    void init(int _F,int _T){
    	for(int i = 1;i <= 600;i ++)to[i].clear(),com[i].clear(),flow[i].clear();
        for(int i = 1;i <= 300;i ++){
            _addedge( i, i + NTX, INF );
        }
        F = _F;
        T = _T;
    }

    void addedge(int u,int v){
        _addedge( u + NTX , v , 1);
        _addedge( v + NTX , u , 1);
    }

    bool bfs(){
        queue<int>Q;
        memset( deep, 0 ,sizeof(deep) );
        Q.push(F);deep[F] = 1;
        while( !Q.empty() ){
            int now = Q.front();Q.pop();
            for(int i = 0;i ^ to[now].size();i ++){
                int next = to[now][i];
                if( flow[now][i] > 0 and deep[next] == 0){
                    deep[next] = deep[now] + 1;
                    Q.push(next);
                }
            }
        }
        return deep[T];
    }

    int dfs(int now,int dist){
        if( now == T )return dist;
        for(int &i = cur[now];i ^ to[now].size();i ++){
            int next = to[now][i];
            if( deep[next] == deep[now] + 1 and flow[now][i] > 0 ){
                long di = dfs( next,min(dist,flow[now][i]) );
                if( di > 0 ){
                    flow[now][i] -= di;
                    flow[next][com[now][i]] += di;
                    return di;
                }
            }
        }
        return 0;
    }

    int Dinic(){
        int ans = 0;
        while(bfs()){
            memset(cur,0,sizeof(cur));
            while(int d = dfs(F,INF))ans += d;
        }
        return ans;
    }
}

int edge[1005][2];

int main(){
	freopen( "connection.in","r",stdin);
	freopen( "connection.out","w",stdout);
    int n,m;cin >> n >> m;
    for(int i = 1;i <= m;i ++){
        int a,b;scanf( "%d%d", &edge[i][0], &edge[i][1] );
    }
    int ans = 1e9 + 7;
    for(int i = 2;i <= n;i ++){
    	Dinic::init(1,i + 300);
    	for(int j = 1;j <= m;j ++){
    		Dinic::addedge( edge[j][0],edge[j][1] );
    	}
    	ans = min( ans, Dinic::Dinic() );
    }
    cout << ans;
    return 0;
}