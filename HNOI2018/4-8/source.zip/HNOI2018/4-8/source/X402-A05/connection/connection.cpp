#include <bits/stdc++.h>

typedef long long LL;

inline int read(int Num = 0, int Flag = 1)
{
	char ch = getchar();
	for (; !isdigit(ch); ch = getchar())
		if (ch == '-')
			Flag = -1;
	for (;  isdigit(ch); ch = getchar())
		Num = Num * 10 + ch - '0';
	return Num *= Flag;
}

const int MAXN = 1e5 + 5;

int N, M;
int degree[MAXN];

int e = 0, begin[MAXN];
struct Edge
{
	int to, next;
}edge[MAXN << 1];

void add_edge(int u, int v)
{
	edge[++e] = (Edge) {v, begin[u]}; begin[u] = e;
}

namespace SubTask_1
{
bool vis[MAXN], ban[MAXN << 1];

void DFS_calc(int u)
{
	vis[u] = true;
	for (int i = begin[u]; i; i = edge[i].next) {
		int v = edge[i].to;
		if (ban[i] || vis[v]) continue;
		DFS_calc(v);
	}
}

void main()
{
	int ans = M + 1;
	for (int s = 1; s < 1<<M; ++s) {
		for (int i = 0; i < M; ++i)
			if ((s >> i) & 1) {
				ban[i * 2 + 1] = true;
				ban[i * 2 + 2] = true;
			}

		for (int i = 1; i <= N; ++i) vis[i] = false;

		int sz = 0;
		for (int i = 1; i <= N; ++i) {
			if (!vis[i]) {
				DFS_calc(i);
				sz ++;
			}
		}

		if (sz > 1) {
			ans = std::min(ans, __builtin_popcount(s));
		}

		for (int i = 0; i < M; ++i) {
			if ((s >> i) & 1) {
				ban[i * 2 + 1] = false;
				ban[i * 2 + 2] = false;
			}
		}
	}
	printf("%d\n", ans);
}

}

int main()
{
	freopen("connection.in", "r", stdin);
	freopen("connection.out", "w", stdout);

	N = read(), M = read();

	for (int i = 1; i <= M; ++i) {
		int u = read(), v = read();
		add_edge(u, v);
		add_edge(v, u);
		degree[u] ++;
		degree[v] ++;
	}

	if (M <= 20) {
		SubTask_1 :: main();
	}
	else if (M + 1 == N) {
		puts("1");
	}
	else {
		int ans = M;
		for (int i = 1; i <= N; ++i)
			if (degree[i] < ans) ans = degree[i];
		printf("%d\n", ans - 1);
	}

	return 0;
}

