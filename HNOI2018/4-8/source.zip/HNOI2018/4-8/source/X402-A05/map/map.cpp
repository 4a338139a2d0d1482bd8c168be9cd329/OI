#include <bits/stdc++.h>

typedef long long LL;

inline int read(int Num = 0, int Flag = 1)
{
	char ch = getchar();
	for (; !isdigit(ch); ch = getchar())
		if (ch == '-')
			Flag = -1;
	for (;  isdigit(ch); ch = getchar())
		Num = Num * 10 + ch - '0';
	return Num *= Flag;
}

const int MAXN = 1e5 + 5;

int N, M, Q;
int oil[MAXN];

int e = 0, begin[MAXN];
struct Edge
{
	int to, next;
}edge[MAXN << 1];

void add_edge(int u, int v)
{
	edge[++e] = (Edge) {v, begin[u]}; begin[u] = e;
}

int dfs_clock;
int dfn[MAXN], low[MAXN];

void DFS_init(int u, int fa)
{
	dfn[u] = low[u] = ++dfs_clock;
	for (int i = begin[u]; i; i = edge[i].next) {
		int v = edge[i].to;
		if (!dfn[v]) {
			DFS_init(v, u);
			low[u] = std::min(low[u], low[v]);
		}
		else if (v != fa) {
			low[u] = std::min(low[u], low[v]);
		}
	}
}

int ans[(int)1e6 + 5];
int vis[(int)1e6 + 5];

void DFS_calc(int u, int _clock)
{
	ans[oil[u]] ++;
	vis[u] = 1;
	for (int i = begin[u]; i; i = edge[i].next) {
		int v = edge[i].to;
		if (low[v] < _clock || vis[v]) continue;
		DFS_calc(v, _clock);
	}
}

int main()
{
	freopen("map.in", "r", stdin);
	freopen("map.out", "w", stdout);

	N = read(), M = read();
	for (int i = 1; i <= N; ++i) oil[i] = read();
	for (int i = 1; i <= M; ++i) {
		int u = read(), v = read();
		add_edge(u, v);
		add_edge(v, u);
	}

	DFS_init(1, 0);

	Q = read();
	for (int cases = 1; cases <= Q; ++cases) {
		int ty = read(), st = read(), lim = read();

		DFS_calc(st, dfn[st]);

		int Ans = 0;
		for (int i = 1; i <= N; ++i) vis[i] = 0;

		for (int i = 1; i <= N; ++i) {
			if (!vis[oil[i]] && (ans[oil[i]] & 1) == ty) {
				if (oil[i] > lim || !ans[oil[i]]) continue;
				vis[oil[i]] = 1; Ans ++;
			}
		}
		printf("%d\n", Ans);

		for (int i = 1; i <= N; ++i) 
			vis[oil[i]] = ans[oil[i]] = 0;
	}

	return 0;
}

