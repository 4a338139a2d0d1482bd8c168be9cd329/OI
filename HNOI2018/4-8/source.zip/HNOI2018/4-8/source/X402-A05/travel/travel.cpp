#include <bits/stdc++.h>

typedef long long LL;

inline int read(int Num = 0, int Flag = 1)
{
	char ch = getchar();
	for (; !isdigit(ch); ch = getchar())
		if (ch == '-')
			Flag = -1;
	for (;  isdigit(ch); ch = getchar())
		Num = Num * 10 + ch - '0';
	return Num *= Flag;
}

const int mod = 1e4 + 7;

int fpm(int x, int e)
{
	int ret = 1;
	for (; e; e >>= 1) {
		if (e & 1) 
			ret = ret * x % mod;
		x = x * x % mod;
	}
	return ret;
}

const int MAXN = 1e5 + 5;

int N, lim, Q;
int NumA;

int A[MAXN];
int B[MAXN];
int C[MAXN];

int coe[MAXN];

struct Mul_SegmentTree
{
#define lc (h << 1)
#define rc (lc | 1)
#define mid ((l + r) >> 1)

	int mul[MAXN << 2];

	void clear(int N)
	{
		for (int i = 1; i < N << 2; ++i) mul[i] = 1;
	}

	void modify(int h, int l, int r, int p, int v)
	{
		if (l == r) mul[h] = v;
		else {
			if (p <= mid) modify(lc, l, mid, p, v);
			else modify(rc, mid + 1, r, p, v);

			mul[h] = mul[lc] * mul[rc] % mod;
		}
	}

#undef lc
#undef rc
#undef mid
}AT, BT, ST;

#define coe_a (AT.mul[1])
#define coe_b (BT.mul[1])
#define coe_s (ST.mul[1])

void insert(int x, int y)
{
	NumA --; 
	for (int j = lim-1; j >= 0; --j) {
		(coe[j + 1] += coe[j] * x % mod * fpm(y, mod - 2) % mod) %= mod;
	}
}

void erase(int x, int y)
{
	NumA ++;
	for (int i = 1; i <= lim; ++i) {
		(coe[i] -= coe[i-1] * x % mod * fpm(y, mod - 2) % mod) %= mod;
		(coe[i] += mod) %= mod;
	}
}

int main()
{
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);

	N = read(), lim = read();
	for (int i = 1; i <= N; ++i) A[i] = read() % mod;
	for (int i = 1; i <= N; ++i) B[i] = read() % mod;

	AT.clear(N);
	BT.clear(N);
	ST.clear(N);

	for (int i = 1; i <= N; ++i) {
		if (B[i] == 0) {
			AT.modify(1, 1, N, i, A[i]);
			NumA ++;
		}
		else {
			BT.modify(1, 1, N, i, B[i]);
		}

		ST.modify(1, 1, N, i, (A[i] + B[i]) % mod);
	}

	coe[0] = 1;
	for (int i = 1; i <= N; ++i) {
		if (B[i] == 0) continue;
		for (int j = lim; j >= 0; --j) {
			(coe[j + 1] += coe[j] * A[i] % mod * fpm(B[i], mod - 2) % mod) %= mod;
		}
	}

	Q = read();
	for (int cases = 1; cases <= Q; ++cases) {
		int id = read(), x = read(), y = read();

		ST.modify(1, 1, N, id, (x % mod + y % mod) % mod);

		if (B[id] == 0) {
			if (y % mod == 0) {
				AT.modify(1, 1, N, id, x % mod);
			}
			else {
				BT.modify(1, 1, N, id, y % mod);
				AT.modify(1, 1, N, id, 1);
				insert(x % mod, y % mod);
			}
		}
		else {
			if (y % mod == 0) {
				AT.modify(1, 1, N, id, x % mod);
				BT.modify(1, 1, N, id, 1);
				erase(A[id], B[id]);
			}
			else {
				BT.modify(1, 1, N, id, y % mod);
				erase(A[id], B[id]);
				insert(x % mod, y % mod);
			}
		}

		int del_num = 0;
		for (int i = 0; i <= lim - NumA - 1; ++i) (del_num += coe[i]) %= mod;
		(del_num *= coe_a * coe_b % mod) %= mod;

		printf("%d\n", (coe_s - del_num + mod) % mod);

		A[id] = x % mod;
		B[id] = y % mod;
	}

//	fprintf(stderr, "%lf\n", (double) clock()/CLOCKS_PER_SEC);
	return 0;
}

