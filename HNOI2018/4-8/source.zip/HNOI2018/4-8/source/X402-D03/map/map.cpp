#include<bits/stdc++.h>

#define fst first
#define snd second
#define mkp std::make_pair
typedef std::pair<int, int> pii;
const int MAXN = 100010, MAXM = 150010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], to[MAXM<<1];
int nxt[MAXM<<1], e = 1;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int cnt, rt[MAXM];
namespace Seg_T {
#define mid ((l+r)>>1)
	int s[2][MAXN*25], val[MAXN*25];
	int ls[MAXN*25], rs[MAXN*25];
	inline void insert(int &p, int l, int r, int x) {
		if(!p) p = ++cnt;
		if(l == r) {
			if(val[p]) s[val[p]&1][p]--;
			val[p]++, s[val[p]&1][p]++;
			return;
		}
		if(x <= mid) insert(ls[p], l, mid, x);
		else insert(rs[p], mid+1, r, x);
		s[0][p] = s[0][ls[p]]+s[0][rs[p]];
		s[1][p] = s[1][ls[p]]+s[1][rs[p]];
	}
	inline int merge(int x, int y, int l, int r) {
		if(!x || !y) return x+y;
		if(l == r) {
			if(val[x]) s[val[x]&1][x]--;
			val[x] += val[y];
			s[val[x]&1][x]++;
			return x;
		}
		ls[x] = merge(ls[x], ls[y], l, mid);
		rs[x] = merge(rs[x], rs[y], mid+1, r);
		s[0][x] = s[0][ls[x]]+s[0][rs[x]];
		s[1][x] = s[1][ls[x]]+s[1][rs[x]];
		return x;
	}
	inline int query(int p, int l, int r, int x, int y, int tp) {
		if(l == x && r == y) return s[tp][p];
		if(y <= mid) return query(ls[p], l, mid, x, y, tp);
		if(x > mid) return query(rs[p], mid+1, r, x, y, tp);
		return query(ls[p], l, mid, x, mid, tp)+query(rs[p], mid+1, r, mid+1, y, tp);
	}
	inline void output(int p, int l, int r) {
		printf("%d %d %d: %d %d %d %d\n", p, l, r, s[0][p], s[1][p], ls[p], rs[p]);
		if(ls[p]) output(ls[p], l, mid);
		if(rs[p]) output(rs[p], mid+1, r);
	}
}

int N, q, n, m, res[MAXN], a[MAXN];
int fa[MAXN], dfn[MAXN], dfs_clock;
std::vector<int> G[MAXM];
std::vector<pii> Q[MAXM][2];
bool vis[MAXN], ban[MAXN];
void dfs(int u, int pre) {
	int i;
	vis[u] = true;
	dfn[u] = ++dfs_clock;
	for(i = st[u]; i; i = nxt[i]) {
		if(i == (pre ^ 1)) continue;
		int v = to[i];
		if(vis[v]) {
			if(dfn[v] < dfn[u]) {
				++N;
				for(int t = u; t != v; t = fa[t]) {
					ban[t] = true;
					G[N].push_back(t);
				}
				G[v].push_back(N);
			}
			continue;
		}
		fa[v] = u, dfs(v, i);
		if(!ban[v]) G[u].push_back(v);
	}
}

inline void solve(int u) {
	int i;
	if(u <= n) Seg_T::insert(rt[u], 1, 1000000, a[u]);
	for(i = 0; i < (int)G[u].size(); i++) {
		int v = G[u][i];
		solve(v);
		rt[u] = Seg_T::merge(rt[u], rt[v], 1, 1000000);
	}
	for(i = 0; i < (int)Q[u][0].size(); i++) {
		int v = Q[u][0][i].fst;
		res[Q[u][0][i].snd] = Seg_T::query(rt[u], 1, 1000000, 1, v, 0);
	}
	for(i = 0; i < (int)Q[u][1].size(); i++) {
		int v = Q[u][1][i].fst;
		res[Q[u][1][i].snd] = Seg_T::query(rt[u], 1, 1000000, 1, v, 1);
	}
}

int main() {
	freopen("map.in", "r", stdin);
	freopen("map.out", "w", stdout);
	int i;
	n = read(), m = read();
	for(i = 1; i <= n; i++) a[i] = read();
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
	}
	N = n, dfs(1, 0);
	q = read();
	for(i = 1; i <= q; i++) {
		int op = read(), x = read(), y = read();
		Q[x][op].push_back(mkp(y, i));
	}
	solve(1);
	for(i = 1; i <= q; i++)
		printf("%d\n", res[i]);
	return 0;
}
