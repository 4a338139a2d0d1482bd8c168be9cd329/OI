#include<bits/stdc++.h>
using namespace std;

#define fst first
#define snd second
#define mkp make_pair
typedef pair<int, int> pii;
const int MAXN = 100010;
const int MAXM = 150010;

inline int randint(int x, int y) {
	return rand()%(y-x+1)+x;
}

int n, m, fa[MAXN];
int id[MAXN];
bool ban[MAXN];
pii p[MAXM];

int main() {
	freopen("map.in", "w", stdout);
	int i;
	srand(time(0));
	n = randint(1, 1000);
	for(i = 1; i <= n; i++) id[i] = i;
	random_shuffle(id+1, id+n+1);
	ban[id[1]] = true;
	for(i = 2; i <= n; i++) {
		fa[id[i]] = id[randint(1, i-1)];
		p[i-1] = mkp(fa[id[i]], id[i]);
	}
	m = n-1;
	while(randint(1, 400) != 4) {
		int u = randint(1, n);
		if(ban[u]) continue;
		int v = u, d = 0;
		while(!ban[v]) v = fa[v], d++;
		d = randint(1, d);
		v = u;
		while(d--) {
			ban[v] = true;
			v = fa[v];
		}
		m++;
		p[m] = mkp(u, v);
		if(m == 1500) break;
	}
	printf("%d %d\n", n, m);
	for(i = 1; i <= n; i++) printf("%d ", randint(1, 1000000));
	printf("\n");
	for(i = 1; i <= m; i++)
		printf("%d %d\n", p[i].fst, p[i].snd);
	int q = randint(1, 1000);
	printf("%d\n", q);
	while(q--) {
		printf("%d %d %d\n", randint(0, 1), randint(1, n), randint(1, 1000000));
	}
	return 0;
}
