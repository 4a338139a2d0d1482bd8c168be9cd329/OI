#include<bits/stdc++.h>

const int MAXN = 1010, MAXM = 1510;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], to[MAXM<<1];
int nxt[MAXM<<1], e = 1;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int N, Q, n, m, Hash[MAXN], cnt;
int fa[MAXN], dfn[MAXN], dfs_clock;
std::vector<int> G[MAXM];
bool vis[MAXN], ban[MAXN];
void dfs(int u, int pre) {
	int i;
	vis[u] = true;
	dfn[u] = ++dfs_clock;
	for(i = st[u]; i; i = nxt[i]) {
		if(i == (pre ^ 1)) continue;
		int v = to[i];
		if(vis[v]) {
			if(dfn[v] < dfn[u]) {
				++N;
				for(int t = u; t != v; t = fa[t]) {
					ban[t] = true;
					G[N].push_back(t);
				}
				G[v].push_back(N);
			}
			continue;
		}
		fa[v] = u, dfs(v, i);
		if(!ban[v]) G[u].push_back(v);
	}
}

int buc[MAXN], ans, a[MAXN];

void DFS(int u, int lim) {
	if(u <= n && Hash[a[u]] <= lim) buc[a[u]]++;
	int i;
	for(i = 0; i < (int)G[u].size(); i++) 
		DFS(G[u][i], lim);
}

int main() {
	freopen("map.in", "r", stdin);
	freopen("bf.out", "w", stdout);
	int i;
	n = read(), m = read();
	for(i = 1; i <= n; i++) Hash[++cnt] = a[i] = read();
	std::sort(Hash+1, Hash+cnt+1);
	cnt = std::unique(Hash+1, Hash+cnt+1)-Hash-1;
	for(i = 1; i <= n; i++) a[i] = std::lower_bound(Hash+1, Hash+cnt+1, a[i])-Hash;
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
	}
	N = n, dfs(1, 0);
	//for(i = 1; i <= N; i++)
	//	for(int j = 0; j < (int)G[i].size(); j++)
	//		printf("%d %d\n", i, G[i][j]);
	//printf("\n");
	Q = read();
	while(Q--) {
		int op = read(), x = read(), y = read();
		memset(buc, 0, sizeof(buc));
		DFS(x, y), ans = 0;
		for(i = 1; i <= n; i++) if(buc[i] && (buc[i] & 1) == op) ans++;
		printf("%d\n", ans);
	}
	return 0;
}
