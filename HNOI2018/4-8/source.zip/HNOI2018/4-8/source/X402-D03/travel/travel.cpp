#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100010, MAXC = 20;
const int MOD = 10007;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline int qpow(int a, int b) {
	int res = 1;
	while(b) {
		if(b & 1) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int n, C, P;
int dp[2][MAXC], r[MAXC], f[MAXC];
int a[MAXN], b[MAXN], g[MAXC];
int t[MAXC];
int zn, z, zero;
int ans, all, az;

int main() {
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);

	int i, j;
	n = read(), C = read();
	for(i = 1; i <= n; i++) a[i] = read()%MOD;
	for(i = 1; i <= n; i++) b[i] = read()%MOD;
	z = 1;
	all = 1, r[0] = 1;
	for(i = 1; i <= n; i++) {
		if(a[i] == 0 && b[i] == 0) zero++;
		else if(b[i] == 0) {
			zn++, z = z * a[i]%MOD;
			all = all * a[i] % MOD;
		}
		else {
			for(j = C-1; j > 0; j--) 
				r[j] = (r[j-1]*a[i]%MOD+r[j]*b[i]%MOD)%MOD;
			r[0] = r[0]*b[i]%MOD;
			if((a[i]+b[i])%MOD) all = all * ((a[i]+b[i])%MOD) % MOD;
			else az++;
		}
	}
	P = read();
	for(int k = 1; k <= P; k++) {
		int u = read(), x = read()%MOD, y = read()%MOD;
		//if(k == 384) {
		//	printf("!\n");
		//	for(i = C-1; i >= 0; i--) printf("%d ", r[i]);
		//	printf("\n");
		//	for(i = 1; i <= n; i++) printf("%d %d\n", a[i],b[i]);
		//	printf("%d %d %d\n", u, x, y);
		//	printf("%d\n", all);
		//}
		if(b[u] == 0 && a[u] == 0) zero--;
		else if(b[u] == 0) {
			zn--, z = z * qpow(a[u], MOD-2)%MOD;
			all = all * qpow(a[u], MOD-2)%MOD;
		}
		else {
			memset(f, 0, sizeof(f));
			f[0] = b[u], f[1] = a[u];
			g[0] = qpow(f[0], MOD-2);
			for(i = 1; i < C; i++) {
				g[i] = MOD-f[i]*g[0]%MOD;
				for(j = 1; j < i; j++) 
					g[i] = (g[i]-f[j]*g[i-j]%MOD+MOD)%MOD;
				g[i] = g[i]*g[0]%MOD;
			}
			memset(t, 0, sizeof(t));
			for(i = 0; i < C; i++)
				for(j = 0; i+j < C; j++) 
					t[i+j] = (t[i+j]+r[i]*g[j]%MOD)%MOD;
			memcpy(r, t, sizeof(t));
			if((a[u]+b[u])%MOD) all = all * qpow((a[u]+b[u])%MOD, MOD-2)%MOD;
			else az--;
		}
		//if(k == 384) {
		//	printf("!\n");
		//	for(i = C-1; i >= 0; i--) printf("%d ", r[i]);
		//	printf("\n");
		//	for(i = 1; i <= n; i++) printf("%d %d\n", a[i],b[i]);
		//	printf("%d %d %d\n", u, x, y);
		//	printf("%d %d\n", all, z);
		//}
		if(x == 0 && y == 0) zero++;
		else if(y == 0) {
			zn++, z = z * x %MOD;
			all = all * x  % MOD;
		}
		else {
			for(i = C-1; i >= 1; i--) 
				r[i] = (r[i]*y%MOD+r[i-1]*x%MOD)%MOD;
			r[0] = r[0]*y%MOD;
			if((x+y)%MOD) all = all * ((x+y)%MOD)%MOD;
			else az++;
		}
		a[u] = x, b[u] = y;
		//if(k == 7) {
		//	printf("!\n");
		//	for(i = C-1; i >= 0; i--) printf("%d ", r[i]);
		//	printf("\n");
		//	for(i = 1; i <= n; i++) printf("%d %d\n", a[i],b[i]);
		//	printf("%d %d %d\n", u, x, y);
		//	printf("%d %d\n", all, z);
		//}
		if(zero) printf("0\n");
		else if(zn) {
			ans = az ? 0 : all;
			for(i = zn; i < C; i++) 
				ans = (ans-r[i-zn]*z%MOD+MOD)%MOD;
			printf("%d\n", ans);
		}
		else {
			ans = az ? 0 : all;
			for(i = 0; i < C; i++) ans = (ans-r[i]+MOD)%MOD; 
			printf("%d\n", ans);
		}
	}
	return 0;
}
