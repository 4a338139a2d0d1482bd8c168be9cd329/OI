#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100010, MAXC = 25;
const int MOD = 10007;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, C, P;
int dp[MAXN][MAXC];
int a[MAXN], b[MAXN];

int main() {
	freopen("travel.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j;
	n = read(), C = read();
	for(i = 1; i <= n; i++) a[i] = read()%MOD;
	for(i = 1; i <= n; i++) b[i] = read()%MOD;
	P = read();
	while(P--) {
		int u = read();
		a[u] = read()%MOD, b[u] = read()%MOD;
		dp[0][0] = 1;
		for(i = 1; i <= n; i++) {
			dp[i][0] = dp[i-1][0]*b[i]%MOD;
			for(j = 1; j <= C; j++) 
				dp[i][j] = (dp[i-1][j-1]*a[i]%MOD+dp[i-1][j]*b[i]%MOD)%MOD;
			dp[i][C] = (dp[i][C]+dp[i-1][C]*a[i]%MOD)%MOD;
		}
		printf("%d\n", dp[n][C]);
	}
	return 0;
}
