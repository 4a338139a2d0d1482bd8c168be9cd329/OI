#include<bits/stdc++.h>
using namespace std;

#define fst first
#define snd second
#define mkp make_pair
typedef pair<int, int> pii;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, fa[30], ans;
pii E[30];
bool cs[30];

int find(int x) {
	return fa[x] = fa[x] == x ? x : find(fa[x]);
}

void dfs(int u, int cnt) {
	if(cnt >= ans) return;
	if(u == m+1) {
		int i, r = 0;
		for(i = 1; i <= n; i++) fa[i] = i;
		for(i = 1; i <= m; i++) 
			if(!cs[i]) {
				u = find(E[i].fst);
				int v = find(E[i].snd);
				if(u == v) continue;
				fa[u] = v, r++;
			}
		if(r < n-1) {
			ans = cnt;
		}
		return;
	}
	cs[u] = true;
	dfs(u+1, cnt+1);
	cs[u] = false;
	dfs(u+1, cnt);
}

int main() {
	freopen("connection.in", "r", stdin);
	freopen("connection.out", "w", stdout);

	int i;
	n = read(), m = read();
	if(m == n-1) {
		printf("1\n");
		return 0;
	}
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		E[i] = mkp(u, v);
	}
	ans = m;
	dfs(1, 0);
	printf("%d\n", ans);
	return 0;
}
