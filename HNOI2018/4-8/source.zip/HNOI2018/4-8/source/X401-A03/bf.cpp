#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("connection.in","r",stdin);
	freopen("bf.out","w",stdout);
}
template<typename T>void chckmax(T &_,T __){_=_>__ ? _ : __;}
template<typename T>void chckmin(T &_,T __){_=_<__ ? _ : __;}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define MREP(i,x) for(register int i=beg[x];i;i=E[i].last)
#define ll long long
#define inf (0x3f3f3f3f)
const int maxn=300+10;
const int maxm=1000+10;
int n,m,beg[maxn],cnt=1,ans=inf,d[maxn];
int num[maxn][maxn];
struct edge{
	int to;
	int last;
}E[maxm*2];
void add(int u,int v){
	++cnt;
	E[cnt].last=beg[u];
	beg[u]=cnt;
	E[cnt].to=v;
}
int fa[maxn];
bool vis[maxn];
int find(int x){return fa[x]==x ? x : fa[x]=find(fa[x]);}
bool pd(){
	REP(i,1,n)fa[i]=i;
	REP(i,1,n){
		int u=i;
		MREP(j,i){
			if(vis[j])continue;
			int v=E[j].to;
			if(find(u)!=find(v))
			fa[find(u)]=find(v);
		}
	}
	REP(i,1,n)if(find(i)!=find(1))return 1;
	return 0;
}
int main(){
	File();
	scanf("%d%d",&n,&m);
	REP(i,1,m){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		num[u][v]=cnt;
		add(v,u);
		num[v][u]=cnt;
		++d[u];
		++d[v];
	}
	REP(i,1,n)chckmin(ans,d[i]);
	REP(i,1,cnt){
		vis[i]=1;
		vis[i^1]=1;
		if(pd())chckmin(ans,1);
		vis[i]=0;
		vis[i^1]=0;
	}
	cout<<ans<<endl;
	return 0;
}
