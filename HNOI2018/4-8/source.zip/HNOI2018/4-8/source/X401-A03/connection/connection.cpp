#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
}
template<typename T>void chckmax(T &_,T __){_=_>__ ? _ : __;}
template<typename T>void chckmin(T &_,T __){_=_<__ ? _ : __;}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define MREP(i,x) for(register int i=beg[x];i;i=E[i].last)
#define ll long long
#define inf (0x3f3f3f3f)
const int maxn=300+10;
const int maxm=1000+10;
int n,m,beg[maxn],cnt=1,ans=inf,d[maxn];
int num[maxn][maxn];
struct edge{
	int to;
	int last;
}E[maxm*2];
void add(int u,int v){
	++cnt;
	E[cnt].last=beg[u];
	beg[u]=cnt;
	E[cnt].to=v;
}
namespace fuck{
	bool vis[maxm*2];
	bool used[maxm];
	bool dfs(int u,int t){
		if(u==t)return 1;
		MREP(i,u){
			if(vis[i])continue;
			vis[i]=vis[i^1]=1;
			int v=E[i].to;
			if(dfs(v,t))return 1;
		}
		return 0;
	}
	int cal(int x,int y){
		int ret=1;
		memset(vis,0,sizeof(vis));
		vis[num[x][y]]=vis[num[y][x]]=1;
		while(dfs(x,y))++ret;
		return ret;
	}
	void work(){
		chckmin(ans,cal(2,4));
		REP(i,1,n){
			MREP(j,i){
				int u=i,v=E[j].to;
				if(used[num[u][v]] || used[num[v][u]])continue;
				used[num[u][v]]=used[num[v][u]]=1;
				chckmin(ans,cal(u,v));
			}
		}
	}
}
using namespace fuck;
int main(){
	File();
	scanf("%d%d",&n,&m);
	REP(i,1,m){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		num[u][v]=cnt;
		add(v,u);
		num[v][u]=cnt;
		++d[u];
		++d[v];
	}
	if(n-1==m){
		cout<<1<<endl;
		return 0;
	}
	REP(i,1,n)chckmin(ans,d[i]);
	fuck::work();
	cout<<ans<<endl;
	return 0;
}
