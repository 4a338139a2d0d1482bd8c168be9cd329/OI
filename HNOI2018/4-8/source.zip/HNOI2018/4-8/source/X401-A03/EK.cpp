#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
void File(){
	freopen("EK.in","r",stdin);
	freopen("EK.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(regsiter int i=a;i>=b;--i)
#define MREP(i,x) for(register int i=beg[x];i;i=E[i].last)
struct EK{
	struct edge{
		int to;
		int last;
		int flow;
}T;
int main(){
	File();
	return 0;
}
