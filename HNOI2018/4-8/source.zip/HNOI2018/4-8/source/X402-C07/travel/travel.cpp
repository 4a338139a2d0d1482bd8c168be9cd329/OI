#include<cstdio>
#include<algorithm>
using namespace std;
const int mod=10007;
int n,c,m,a[100012],b[100012],f[1012][1012];
int num[400012][22];
int read(){
	int x=0,f=1;
	char ch=getchar();
	while (ch>'9'||ch<'0')
	{
	  if (ch=='-')
	    f=-1;
	  ch=getchar();
	}
	while (ch>='0'&&ch<='9')
	{
	  x=(x<<1)+(x<<3)+(ch^'0');
	  ch=getchar();
	}
	return x*f;
}

void pushup(int o){
	for (int i=0;i<=c;i++)
	  num[o][i]=0;
	for (int i=0;i<=c;i++)
	  for (int j=0;j<=c;j++)
	    num[o][min(i+j,c)]=(num[o][min(i+j,c)]+num[o*2][i]*num[o*2+1][j]%mod)%mod;
}

void build(int o,int l,int r){
	if (l==r)
	{
	  num[o][0]=b[l];
	  num[o][1]=a[l];
	  return ;
	}
	int mid=(l+r)/2;
	build(o*2,l,mid);
	build(o*2+1,mid+1,r);
	pushup(o);
}

void change(int o,int l,int r,int pos,int x,int y){
	if (l==r)
	{
	  num[o][0]=y;
	  num[o][1]=x;
	  return ;
	}
	int mid=(l+r)/2;
	if (pos<=mid)
	  change(o*2,l,mid,pos,x,y);
	else
	  change(o*2+1,mid+1,r,pos,x,y);
	pushup(o);
}

void write(int x){
	if (x==0)
	{
	  putchar('0');
	  return ;
	}
	if (x<0)
	{
	  putchar('-');
	  x=-x;
	}
	int tt=0,s[20];
	while (x>0)
	{
	  s[++tt]=x%10+'0';
	  x/=10;
	}
	for (register int i=tt;i>=1;--i)
	  putchar(s[i]);
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read(),c=read();
	for (register int i=1;i<=n;++i)
	  a[i]=read();
	for (register int i=1;i<=n;++i)
	  b[i]=read();
	m=read();	
	/*f[0][0]=1;
	for (register int i=1;i<=n;++i)
	  for (register int j=0;j<=i;++j)
	  {
	    f[i][j]=0;
		if (i-1>=j)
		  f[i][j]=(f[i][j]+f[i-1][j]*b[i]%mod)%mod;
		if (j-1>=0)
		  f[i][j]=(f[i][j]+f[i-1][j-1]*a[i]%mod)%mod;
	  }
	while (m--)
	{
	  int aa,x,y;
	  aa=read(),x=read(),y=read();
	  a[aa]=x,b[aa]=y;
	  for (register int i=aa;i<=n;++i)
	  {
	    register int* fi=f[i];
		register int* fi1=f[i-1];
		for (register int j=0;j<=i;++j)
		{
		  fi[j]=0;
		  if (i-1>=j)
		    fi[j]=(fi[j]+fi1[j]*b[i]%mod)%mod;
		  if (j-1>=0)
		    fi[j]=(fi[j]+fi1[j-1]*a[i]%mod)%mod;
		}
	  }
	  int ans=0;
	  for (register int i=c;i<=n;++i)
	    ans=(ans+f[n][i])%mod;
	  printf("%d\n",ans);
	}
	return 0;*/
	build(1,1,n);
	while (m--)
	{
	  int aa,x,y;
	  aa=read(),x=read(),y=read();
	  change(1,1,n,aa,x,y);
	  write(num[1][c]);
	}
	return 0;
}
