#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,tot,pre[2012],now[1012],son[2012],id[2012];
int vis[1012],f[1012],du[1012],aa[1012],bb[1012];

void add(int a,int b,int i){
	tot++;
	pre[tot]=now[a];
	now[a]=tot;
	son[tot]=b;
	id[tot]=i;
}

void doing(int x){
	vis[x]=1;
	tot++;
	for (int i=now[x];i>0;i=pre[i])
	{
	  int s=son[i];
	  if (vis[s]||f[id[i]])
	    continue;
	  doing(s);
	}
}

int read(){
	int x=0,f=1;
	char ch=getchar();
	while (ch>'9'||ch<'0')
	{
	  if (ch=='-')
	    f=-1;
	  ch=getchar();
	}
	while (ch>='0'&&ch<='9')
	{
	  x=(x<<1)+(x<<3)+(ch^'0');
	  ch=getchar();
	}
	return x*f;
}

int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	n=read(),m=read();
	for (register int i=1;i<=m;++i)
	  aa[i]=read(),bb[i]=read();
	for (register int i=1;i<=n;i++)
	{
	  int a=rand()%m+1,b=rand()%m+1;
	  swap(aa[a],aa[b]),swap(bb[a],bb[b]);
	}
	for (register int i=1;i<=m;++i)
	{
	  int a,b;
	  a=aa[i],b=bb[i];
	  add(a,b,i);
	  add(b,a,i);
	  du[a]++;
	  du[b]++;
	}
	int minn=2147483600;
	for (register int i=1;i<=n;++i)
	{
	  if(du[i]==1)
	  {
	    printf("%d\n",1);
		return 0;
	  }
	  minn=min(minn,du[i]);
	}
	for (register int i=1;i<=m;++i)
	{
	  f[i]=1;
	  for (register int j=1;j<=n;++j)
	    vis[j]=0;
	  tot=0;
	  doing(1);
	  f[i]=0;
	  if (tot!=n)
	  {
	    printf("%d\n",1);
		return 0;
	  }
	}
	if (minn==2)
	{
	  printf("%d\n",minn);
	  return 0;
	}
	for (register int i=1;i<=m;++i)
	  for (register int j=i+1;j<=m;++j)
	  {
	    f[i]=1,f[j]=1;
		for (register int k=1;k<=n;++k)
		  vis[k]=0;
		tot=0;
		doing(1);
		f[i]=0,f[j]=0;
		if (tot!=n)
		{
		  printf("%d\n",2);
		  return 0;
		}
	  }
	if (minn==3)
	{
	  printf("%d\n",minn);
	  return 0;
	}
	for (register int i=1;i<=m;++i)
	  for (register int j=i=1;j<=m;++j)
	    for (register int k=j+1;k<=m;++k)
		{
		  f[i]=1,f[j]=1,f[k]=1;
		  for (register int l=1;l<=n;++l)
		    vis[l]=0;
		  tot=0;
		  doing(1);
		  f[i]=0,f[j]=0,f[k]=0;
		  if (tot!=n)
		  {
		    printf("%d\n",3);
			return 0;
		  }
		}
	printf("%d\n",minn);
	return 0;
}
