#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
vector<int> son[10012];
int n,m,a[10012],vis[10012],ans[10012];
int t,p,pos,y;
void dfs(int x){
	if (x==pos)
	  return ;
	vis[x]=1;
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (vis[s])
	    continue;
	  dfs(s);
	}
}

void doing(int x){
	ans[a[x]]++;
	vis[x]=1;
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (vis[s])
	    continue;
	  doing(s);
	}
}
	

int main(){
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
	for (int i=1;i<=m;i++)
	{
	  int a,b;
	  scanf("%d%d",&a,&b);
	  son[a].push_back(b);
	  son[b].push_back(a);
	}
	scanf("%d",&t);
	while (t--)
	{
	  scanf("%d%d%d",&p,&pos,&y);
	  for (int i=1;i<=max(n,y);i++)
	    vis[i]=0,ans[i]=0;
	  dfs(1);
	  doing(pos);
	  int cnt=0;
	  for (int i=1;i<=y;i++)
	    if (ans[i]!=0&&ans[i]%2==p)
		  cnt++;
	  printf("%d\n",cnt);
	}
	return 0;
}
