/************************************************
 * Au: Hany01
 * Prob: map
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define File(a) freopen(a".in", "r", stdin), freopen(a".out", "w", stdout)
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define x first
#define y second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

const int maxn = 100005, maxm = 300005;

int n, m, v[maxm], nex[maxm], beg[maxn], e, a[maxn], fa[maxn], stk[maxn], top, isin[maxn], jam[maxn], incir[maxn], W;
map<int, int> mp;

inline void add(int uu, int vv) { v[++ e] = vv, nex[e] = beg[uu], beg[uu] = e; }

void dfs(int u, int fe)
{
	fa[u] = v[fe ^ 1];
	stk[++ top] = u, isin[u] = 1;
	for (register int i = beg[u]; i; i = nex[i]) if (i != (fe ^ 1))
	{
		if ((fa[v[i]] != u && fa[v[i]]) || v[i] == 1)
		{
			if (isin[v[i]])
				Fordown(j, top, 1) {
					incir[stk[j]] = 1;
					if (stk[j] == v[i]) break;
				}
			else {
				for (int t = u; t; t = fa[t]) incir[t] = 1;
				for (int t = v[i]; t; t = fa[t]) incir[t] = 1;
			}
		} else if (!fa[v[i]]) dfs(v[i], i);
	}
	-- top, isin[u] = 0;
}

void DFS(int u, int fa)
{
	if (a[u] <= W) ++ mp[a[u]];
	for (register int i = beg[u]; i; i = nex[i])
		if (!jam[v[i]] && v[i] != fa) DFS(v[i], u);
}

int main()
{
	File("map");

	static int uu, vv;
	n = read(), m = read();
	For(i, 1, n) a[i] = read();
	e = 1;
	while (m --) uu = read(), vv = read(), add(uu, vv), add(vv, uu);

	dfs(1, 0);

	for (static int q = read(); q --; )
	{
		int ty = read(), u = read(); W = read();
		if (incir[u] && u != 1) {
			if (a[u] <= W) puts("1"); else puts("0");
			continue;
		}
		Set(jam, 0);
		for (int t = u; t; t = fa[u]) jam[t] = 1;
		mp.clear();
		DFS(u, 0);
		int cnt = 0;
		for (map<int, int>::iterator it = mp.begin(); it != mp.end(); ++ it)
			if ((*it).y % 2 == ty) ++ cnt;
		printf("%d\n", cnt);
	}

    return 0;
}
