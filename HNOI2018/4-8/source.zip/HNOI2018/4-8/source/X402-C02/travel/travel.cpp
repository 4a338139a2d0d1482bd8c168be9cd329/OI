#include<bits/stdc++.h>
#define ui unsigned int
#define ll long long
#define db double
#define ld long double
#define ull unsigned long long
const int MAXN=100000+10,MAXC=25,Mod=1e4+7;
int n,c,q,A[MAXN],B[MAXN];
ll total=1;
#define Mid ((l+r)>>1)
#define lson rt<<1,l,Mid
#define rson rt<<1|1,Mid+1,r
struct SEG{
	ll f[MAXN<<2][MAXC];
	inline void PushUp(int rt)
	{
		for(register int i=0;i<c;++i)f[rt][i]=0;
		for(register int i=0;i<c;++i)
			for(register int j=0;i+j<c;++j)(f[rt][i+j]+=f[rt<<1][i]*f[rt<<1|1][j]%Mod)%=Mod;
	}
	inline void Build(int rt,int l,int r)
	{
		if(l==r)f[rt][0]=B[l],f[rt][1]=A[l];
		else
		{
			Build(lson);
			Build(rson);
			PushUp(rt);
		}
	}
	inline void Update(int rt,int l,int r,int pos)
	{
		if(l==r&&r==pos)f[rt][0]=B[l],f[rt][1]=A[l];
		else
		{
			if(pos<=Mid)Update(lson,pos);
			else Update(rson,pos);
			PushUp(rt);
		}
	}
};
SEG T;
#undef Mid
#undef lson
#undef rson
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	read(n);read(c);
	for(register int i=1;i<=n;++i)read(A[i]),A[i]%=Mod;
	for(register int i=1;i<=n;++i)read(B[i]),B[i]%=Mod;
	for(register int i=1;i<=n;++i)(total*=(A[i]+B[i])%Mod)%=Mod;
	T.Build(1,1,n);
	read(q);
	while(q--)
	{
		int p,x,y;
		ll res=0;
		read(p);read(x);read(y);
		total=total*qexp(A[p]+B[p],Mod-2)%Mod;
		A[p]=x%Mod;B[p]=y%Mod;
		total=total*((A[p]+B[p])%Mod)%Mod;
		T.Update(1,1,n,p);
		for(register int i=0;i<c;++i)(res+=T.f[1][i])%=Mod;
		write((total-res+Mod)%Mod,'\n');
	}
	return 0;
}
