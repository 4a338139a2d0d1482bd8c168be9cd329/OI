#include<bits/stdc++.h>
using namespace std;
const int Modn=70363,Modc=20,Modq=93259;
int main()
{
	freopen("travel.in","w",stdout);
	int n=rand()%Modn+1,c=rand()%Modc+1;
	printf("%d %d\n",n,c);
	for(register int i=1;i<=n;++i)printf("%d ",rand());puts("");
	for(register int i=1;i<=n;++i)printf("%d ",rand());puts("");
	int q=rand()%Modq+1;
	printf("%d\n",q);
	while(q--)
	{
		int pos=rand()%n+1;
		printf("%d %d %d\n",pos,rand(),rand());
	}
	return 0;
}
