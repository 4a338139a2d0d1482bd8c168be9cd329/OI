#include<cstdio>
#include<cctype>
using namespace std;
const int N=1e5+5,C=20,mo=10007;
int n,c,qi,tot;
int f[N<<2][C],a[N],b[N];
inline int read()
{
	int X=0,w=0; char ch=0;
	while(!isdigit(ch)) w|=ch=='-',ch=getchar();
	while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
	return w?-X:X;
}
inline void write(int x)
{
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
inline int ksm(int x,int y)
{
	int s=1;
	while(y)
	{
		if(y&1) s=s*x%mo;
		x=x*x%mo;
		y>>=1;
	}
	return s;
}
inline void update(int v)
{
	int ls=v<<1,rs=ls|1;
	for(int i=0;i<c;i++) f[v][i]=0;
	for(int i=0;i<c;i++)
		for(int j=0;i+j<c;j++)
			f[v][i+j]=(f[v][i+j]+f[ls][i]*f[rs][j])%mo;
}
void make(int v,int l,int r)
{
	if(l==r)
	{
		f[v][0]=b[l];
		f[v][1]=a[l];
		return;
	}
	int mid=l+r>>1;
	make(v<<1,l,mid);
	make(v<<1|1,mid+1,r);
	update(v);
}
void change(int v,int l,int r)
{
	if(l==r)
	{
		f[v][0]=b[qi];
		f[v][1]=a[qi];
		return;
	}
	int mid=l+r>>1;
	if(qi<=mid) change(v<<1,l,mid); else change(v<<1|1,mid+1,r);
	update(v);
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.txt","w",stdout);
	n=read(),c=read();
	for(int i=1;i<=n;i++) a[i]=read()%mo;
	for(int i=tot=1;i<=n;i++)
	{
		b[i]=read()%mo;
		tot=tot*(a[i]+b[i])%mo;
	}
	make(1,1,n);
	int p=read();
	while(p--)
	{
		qi=read();
		int x=read()%mo,y=read()%mo;
		tot=tot*ksm(a[qi]+b[qi],mo-2)%mo;
		tot=tot*(x+y)%mo;
		a[qi]=x,b[qi]=y;
		change(1,1,n);
		int ans=0;
		for(int i=0;i<c;i++) ans=(ans+f[1][i])%mo;
		ans=(tot-ans+mo)%mo;
		write(ans),putchar('\n');
	}
	return 0;
}
