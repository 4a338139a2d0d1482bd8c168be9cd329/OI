#include<bits/stdc++.h>
#define ui unsigned int
#define ll long long
#define db double
#define ld long double
#define ull unsigned long long
const int MAXN=300+10,MAXM=1000+10,inf=0x3f3f3f3f;
int n,m,ans=inf;
struct edge{
	int u,v;
};
edge side[MAXM];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
struct maxflow{
	int e,to[MAXM<<1],nex[MAXM<<1],beg[MAXN],s,t,cap[MAXN<<1],prex[MAXN],prei[MAXN],level[MAXN];
	std::queue<int> q;
	inline void init()
	{
		e=1;
		memset(beg,0,sizeof(beg));
		memset(cap,0,sizeof(cap));
	}
	inline void insert(int x,int y,int z)
	{
		to[++e]=y;
		nex[e]=beg[x];
		beg[x]=e;
		cap[e]=z;
		to[++e]=x;
		nex[e]=beg[y];
		beg[y]=e;
		cap[e]=z;
	}
	inline bool bfs()
	{
		memset(level,0,sizeof(level));
		level[s]=1;
		q.push(s);
		while(!q.empty())
		{
			int x=q.front();
			q.pop();
			for(register int i=beg[x];i;i=nex[i])
				if(!level[to[i]]&&cap[i])
				{
					level[to[i]]=1;
					q.push(to[i]);
					prex[to[i]]=x;
					prei[to[i]]=i;
				}
		}
		return level[t];
	}
	inline int dfs()
	{
		int res=inf;
		for(register int i=t;i!=s;i=prex[i])chkmin(res,cap[prei[i]]);
		for(register int i=t;i!=s;i=prex[i])cap[prei[i]]-=res,cap[prei[i]^1]+=res;
		return res;
	}
	inline int Dinic()
	{
		int res=0;
		while(bfs())res+=dfs();
		return res;
	}
	inline int solve(int x,int y)
	{
		init();
		s=x,t=y;
		for(register int i=1;i<=m;++i)insert(side[i].u,side[i].v,1);
		return Dinic();
	}
};
maxflow G;
int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	read(n);read(m);
	for(register int i=1;i<=m;++i)read(side[i].u),read(side[i].v);
	for(register int i=1;i<=n;++i)
		for(register int j=i+1;j<=n;++j)chkmin(ans,G.solve(i,j));
	write(ans,'\n');
	return 0;
}
