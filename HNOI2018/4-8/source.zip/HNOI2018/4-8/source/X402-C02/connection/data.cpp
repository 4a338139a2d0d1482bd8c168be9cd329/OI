#include<bits/stdc++.h>
using namespace std;
const int Modn=300,Modm=1000;
int main()
{
	freopen("connection.in","w",stdout);
	srand(time(0));
	int n=5,m=20;
	printf("%d %d\n",n,m);
	for(register int i=2;i<=n;++i)printf("%d %d\n",i,rand()%(i-1)+1);
	while(m>n-1)
	{
		int r=rand()%(n-1)+2,l=rand()%r+1;
		printf("%d %d\n",l,r);
		m--;
	}
	return 0;
}
