#include<bits/stdc++.h>
#define ui unsigned int
#define ll long long
#define db double
#define ld long double
#define ull unsigned long long
const int MAXN=300+10,MAXM=1000+10,inf=0x3f3f3f3f;
int n,m,to[MAXM<<1],nex[MAXM<<1],beg[MAXN],vis[MAXN],w[MAXM<<1],e,ans=inf;
std::queue<int> q;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
template<typename T> inline T min(T x,T y){return x<y?x:y;}
template<typename T> inline T max(T x,T y){return x>y?x:y;}
inline void insert(int x,int y,int z)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
	w[e]=z;
}
inline bool bfs()
{
	memset(vis,0,sizeof(vis));
	q.push(1);
	vis[1]=1;
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		for(register int i=beg[x];i;i=nex[i])
			if(w[i]&&!vis[to[i]])
			{
				vis[to[i]]=1;
				q.push(to[i]);
			}
	}
	for(register int i=1;i<=n;++i)
		if(!vis[i])return false;
	return true;
}
inline void dfs(int x,int s)
{
	if(x>m)
	{
		if(!bfs())chkmin(ans,s);
		return ;
	}
	w[(x<<1)-1]=0;w[x<<1]=0;
	dfs(x+1,s+1);
	w[(x<<1)-1]=1;w[x<<1]=1;
	dfs(x+1,s);
}
int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.txt","w",stdout);
	read(n);read(m);
	for(register int i=1;i<=m;++i)
	{
		int u,v;
		read(u);read(v);
		insert(u,v,1);insert(v,u,1);
	}
	dfs(1,0);
	write(ans,'\n');
	return 0;
}
