#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MOD = int(1e4 + 7);
const int MAXN = int(2e3), MAXC = 20;

int n, c;

int a[MAXN + 5], b[MAXN + 5];

inline void input()
{
	n = read<int>(), c = read<int>();
	for(int i = 1; i <= n; ++i) a[i] = read<int>() % MOD;
	for(int i = 1; i <= n; ++i) b[i] = read<int>() % MOD;
}

inline int fpm(int x, int y)
{
	int res = 1;
	for(x %= MOD; y; y >>= 1, x = LL(x) * x % MOD) if(y & 1) res = LL(res) * x % MOD;
	return res;
}

int f[MAXN + 5][MAXC + 5];

inline void DP()
{
	memset(f, 0, sizeof f);
	f[0][0] = 1;
	for(int i = 1; i <= n; ++i)
	{
		for(int j = 0; j <= min(i, c - 1); ++j)
		{
			(f[i][j] += LL(f[i - 1][j]) * b[i] % MOD) %= MOD;
			if(j) (f[i][j] += LL(f[i - 1][j - 1]) * a[i] % MOD) %= MOD;
		}
	}
}

inline void solve()
{
	int res = 1;
	for(int i = 1; i <= n; ++i) res = LL(res) * (a[i] + b[i]) % MOD;

	int Q = read<int>();
	while(Q--)
	{
		int p = read<int>(), x = read<int>() % MOD, y = read<int>() % MOD;
		res = LL(res) * fpm(a[p] + b[p], MOD - 2) % MOD;
		a[p] = x, b[p] = y;
		res = LL(res) * (a[p] + b[p]) % MOD;

		DP();
		int ans = res;
		for(int i = 0; i < c; ++i) (ans -= f[n][i]) %= MOD;
		printf("%d\n", (ans + MOD) % MOD);
	}
}

int main()
{
	freopen("travel.in", "r", stdin);
	freopen("travel.ans", "w", stdout);

	input();
	solve();

	return 0;
}

