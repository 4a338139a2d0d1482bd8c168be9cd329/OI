#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

int main()
{
	freopen("seed.txt", "r", stdin);
	srand(time(0) ^ rand());

	freopen("travel.in", "w", stdout);

	const int n = 2e3, c = 20, MAXV = INT_MAX, Q = 2e3;
	printf("%d %d\n", n, c);
	for(int i = 1; i <= n; ++i) printf("%d%c", rand(), i == n ? '\n' : ' ');
	for(int i = 1; i <= n; ++i) printf("%d%c", rand(), i == n ? '\n' : ' ');
	printf("%d\n", Q);
	for(int i = 1; i <= Q; ++i) printf("%d %d %d\n", rand() % n + 1, rand(), rand());

	return 0;
}

