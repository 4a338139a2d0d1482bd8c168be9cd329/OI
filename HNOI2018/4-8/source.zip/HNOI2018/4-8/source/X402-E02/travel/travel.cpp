#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MOD = int(1e4 + 7);
const int MAXN = int(1e5), MAXC = 20;

int n, c;

int a[MAXN + 5], b[MAXN + 5];

inline void input()
{
	n = read<int>(), c = read<int>();
 	for(int i = 1; i <= n; ++i) a[i] = read<int>() % MOD;
	for(int i = 1; i <= n; ++i) b[i] = read<int>() % MOD;
}

inline int fpm(int x, int y)
{
	int res = 1;
	for(x %= MOD; y; y >>= 1, x = LL(x) * x % MOD) if(y & 1) res = LL(res) * x % MOD;
	return res;
}

namespace MAT
{
	struct matrix
	{
		int a[MAXC + 5][MAXC + 5];

		inline matrix operator * (const matrix &rhs) const
		{
			matrix res;
			for(int i = 0; i < c; ++i)
				for(int k = 0; k < c; ++k) if(a[i][k])
					for(int j = 0; j < c; ++j)
						(res.a[i][j] += a[i][k] * rhs.a[k][j]) %= MOD;
			return res;
		}

		matrix() { memset(a, 0, sizeof a); }
	};
}

using namespace MAT;

namespace SEGT
{
	matrix sum[(MAXN << 2) + 5];

	inline void set_mat(matrix &res, int x, int y)
	{
		for(int i = 0; i < c; ++i)
		{
			res.a[i][i] = y;
			if(i + 1 < c) res.a[i][i + 1] = x;
		}
	}

	inline void push_up(int u) { sum[u] = sum[u << 1] * sum[u << 1 | 1]; }

	inline void build(int u, int l, int r)
	{
		if(l == r)
		{
			set_mat(sum[u], a[l], b[l]);
			return;
		}

		int mid = (l + r) >> 1;
		build(u << 1, l, mid);
		build(u << 1 | 1, mid + 1, r);
		push_up(u);
	}

	inline void update(int u, int l, int r, int pos, int x, int y)
	{
		if(l == r)
		{
			set_mat(sum[u], x, y);
			return;
		}

		int mid = (l + r) >> 1;
		if(pos <= mid) update(u << 1, l, mid, pos, x, y);
		else update(u << 1 | 1, mid + 1, r, pos, x, y);
		push_up(u);
	}

	inline matrix trans_all() { return sum[1]; }
}

inline void solve()
{
	int res = 1;
	for(int i = 1; i <= n; ++i) res = LL(res) * (a[i] + b[i]) % MOD;

	SEGT::build(1, 1, n);

	int Q = read<int>();
	while(Q--)
	{
		int p = read<int>(), x = read<int>() % MOD, y = read<int>() % MOD;
		res = LL(res) * fpm(a[p] + b[p], MOD - 2) % MOD;
		a[p] = x, b[p] = y, SEGT::update(1, 1, n, p, x, y);
		res = LL(res) * (a[p] + b[p]) % MOD;

		matrix trans = SEGT::trans_all();
		int ans = res;
		for(int i = 0; i < c; ++i) (ans -= trans.a[0][i]) %= MOD;
		printf("%d\n", (ans + MOD) % MOD);
	}
}

int main()
{
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);

	input();
	solve();

	return 0;
}

