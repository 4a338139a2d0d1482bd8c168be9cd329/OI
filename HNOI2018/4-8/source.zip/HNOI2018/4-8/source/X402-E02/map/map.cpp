#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

inline void proc_status()
{
    ifstream t("/proc/self/status");
    cerr << string(istreambuf_iterator<char>(t), istreambuf_iterator<char>()) << endl;
}

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = int(1e5), MAXM = int(2e5);

struct edge
{
	int adj, nxt, tag;

	edge() { }
	edge(int _adj, int _nxt): adj(_adj), nxt(_nxt) { }
};

edge e[MAXM * 2 + 5];
int st[MAXN + 5], edge_cnt;

inline void add_edge(int u, int v) { e[edge_cnt] = edge(v, st[u]), st[u] = edge_cnt++; }

int n;

int val[MAXN + 5];

inline void input()
{
	n = read<int>(), m = read<int>();
	for(int i = 1; i <= n; ++i) val[i] = read<int>();

	memset(st, -1, sizeof st), edge_cnt = 0;
	while(m--)
	{
		int u = read<int>(), v = read<int>();
		add_edge(u, v), add_edge(v, u);
	}
}

inline void BFS(int u, int v, int tag0)
{
}

inline void solve()
{
	int Q = read<int>();
	while(Q--)
	{
		int type = read<int>(), x = read<int>(), y = read<int>();
		BFS(1, x, Q);
		BFS_ans(x, Q);
	}
}

int main()
{
	freopen("map.in", "r", stdin);
	freopen("map.out", "w", stdout);

	input();
	solve();

	return 0;
}

