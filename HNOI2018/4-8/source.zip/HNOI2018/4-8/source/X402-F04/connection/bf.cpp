//2018-4-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N 21

struct Edge{
	int u, v;
}re[N];

vector<int> G[N];

int n, m;
bool vis[N];

void Dfs(int now){
	if(vis[now]) return;
	vis[now] = true;
	For(i, 0, G[now].size() - 1) Dfs(G[now][i]);
}

bool Check(){
	Dfs(1);
	For(i, 1, n) if(!vis[i]) return true;
	return false;
}

int main(){
	freopen("connection.in", "r", stdin);
	freopen("connection2.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	For(i, 1, m) scanf("%d%d", &re[i].u, &re[i].v);
	
	int ans = m;
	For(i, 0, (1 << m) - 1){

		For(j, 1, n) G[j].clear(), vis[j] = false;
		For(j, 1, m) if(i & (1 << (j - 1))){
			G[re[j].u].pb(re[j].v); G[re[j].v].pb(re[j].u);
		}

		if(Check()){
			ans = min(ans, m - __builtin_popcount(i));
		}
	}
	
	printf("%d\n", ans);

	return 0;
}
