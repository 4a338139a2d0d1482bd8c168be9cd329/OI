//2018-4-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000 + 5)
const int oo = 0x3f3f3f3f;

struct Edge{
    int from, to, cap, flow, cost;
};

namespace MCMF{
    vector<int> G[N];
    vector<Edge> edges;
    int n, m;
    int d[N], a[N], p[N];
    bool inq[N];
	
	void Clear(){
		For(i, 0, edges.size() - 1) edges[i].flow = 0;
	}

    void AddEdge(int from, int to, int cap, int cost){
         edges.pb((Edge){from, to, cap, 0, cost});
         edges.pb((Edge){to, from, 0, 0, -cost});
         m = edges.size();
         G[from].pb(m-2); G[to].pb(m-1);
    }

    bool SPFA(int s, int t, int &flow, int &cost){
        queue<int> q;
        Set(d, oo);
        q.push(s); d[s] = 0; a[s] = oo; inq[s] = true;
        
        while(!q.empty()){
            int now = q.front(); q.pop();
            inq[now] = false;
            
            For(i, 0, G[now].size()-1){
                Edge &e = edges[G[now][i]];
                if(e.cap > e.flow && (d[e.to] > d[now]+e.cost)){
                    d[e.to] = d[now]+e.cost;
                    a[e.to] = min(a[now], e.cap-e.flow);
                    p[e.to] = G[now][i];

                    if(!inq[e.to]){q.push(e.to); inq[e.to] = true;}
                }
            }
        }

        if(d[t] == oo) return false;
        flow += a[t]; cost += a[t] * d[t];
        int u = t;
        while(u != s){
            edges[p[u]].flow += a[t];
            edges[p[u]^1].flow -= a[t];
            u = edges[p[u]].from;
        }
        return true;
    }

    int MaxFlow(int s, int t){
        int flow = 0, cost = 0;
        while(SPFA(s, t, flow, cost));
		return flow;
	}
};
using namespace MCMF;

int rm;

int main(){
	freopen("connection.in", "r", stdin);
	freopen("connection3.out", "w", stdout);
	
	int u, v;

	scanf("%d%d", &n, &rm);
	For(i, 1, rm){
		scanf("%d%d", &u, &v);
		AddEdge(u, v, 1, 1); AddEdge(v, u, 1, 1);
	}
	
	int ans = m;
	For(i, 1, n) For(j, i + 1, n){
		Clear();
		ans = min(ans, MaxFlow(i, j));
	}
	printf("%d\n", ans);

	return 0;
}
