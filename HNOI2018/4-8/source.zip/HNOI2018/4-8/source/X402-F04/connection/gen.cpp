//2018-4-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int main(){
	freopen("connection.in", "w", stdout);
	
	srand(time(NULL));
	int n = rand() % 57 + 2, m = rand() % 221 + rand() % 113 + rand() % 520 + n;

	n = 300, m = 1000;
	printf("%d %d\n", n, m);
	For(i, 1, m){
		int u = rand() % n + 1, v = rand() % n + 1;
		while(v == u) v = rand() % n + 1;
		printf("%d %d\n", u, v);
	}

	return 0;
}
