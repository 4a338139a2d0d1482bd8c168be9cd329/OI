//2018-4-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (300 + 5)
#define M (1000 + 5)

struct node{
	int id, v;
};

node fa[N];
int n, m, dfn, ans, pre[N], dig[N], cov[M];
bool flag[M];

vector<node> G[N];

void Up(int now, int aim){
	while(now != aim){
		++cov[fa[now].id]; now = fa[now].v;
	}
}

#define v G[now][i].v
void Dfs(int now){
	pre[now] = ++dfn;
	
	For(i, 0, G[now].size() - 1) if(G[now][i].id != fa[now].id){
		if(!pre[v]){
			flag[G[now][i].id] = true;
			fa[v] = (node){G[now][i].id, now}; Dfs(v);
		}else if(pre[v] < pre[now]) Up(now, v);
	}
}
#undef v

int main(){
	freopen("connection.in", "r", stdin);
	freopen("connection.out", "w", stdout);
	
	int u, v;

	scanf("%d%d", &n, &m);
	For(i, 1, m){
		scanf("%d%d", &u, &v); ++dig[u], ++dig[v];
		G[u].pb((node){i, v}); G[v].pb((node){i, u});
	}

	ans = m;
	For(i, 1, n) ans = min(ans, dig[i]);

	Dfs(1);
	For(i, 1, m) if(flag[i]) ans = min(ans, cov[i] + 1);
	For(i, 1, n) if(!pre[i]) ans = 0;

	printf("%d\n", ans);

	return 0;
}
