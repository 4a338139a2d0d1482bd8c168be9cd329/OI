//2018-4-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

const int P = 10007;
inline void Mod(int &a){
	if(a < 0) a += P; if(a >= P) a -= P;
}

#define M (20 + 5)
#define N (100000 + 5)

int n, m, a[N], b[N], f[N][M];

void Solve(){
	For(i, 0, n) For(j, 0, m) f[i][j] = 0;

	f[0][0] = 1;
	For(i, 0, n - 1) For(j, 0, m) if(f[i][j]){
		Mod(f[i + 1][j + 1] += f[i][j] * a[i + 1] % P);
		Mod(f[i + 1][j] += f[i][j] * b[i + 1] % P);
	}
	
	int all = 1;
	For(i, 1, n) all = all * (a[i] + b[i]) % P;
	
	int ans = all;
	For(i, 0, m) Mod(ans -= f[n][i]);
	
	printf("%d\n", ans);
}

int main(){
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	
	scanf("%d%d", &n, &m); --m;
	For(i, 1, n) scanf("%d", &a[i]), a[i] %= P;
	For(i, 1, n) scanf("%d", &b[i]), b[i] %= P;

	int Q, p, x, y;
	scanf("%d", &Q);

	while(Q --){
		scanf("%d%d%d", &p, &x, &y);
		a[p] = x % P; b[p] = y % P; Solve();
	}

	return 0;
}
