//2018-4-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (20 + 5)
#define N (100000 + 5)

char chr;
void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0'); chr = getchar();
	}
}

const int P = 10007;
inline int Mod(int a){
	if(a < 0) return a + P;
	return a >= P? a - P: a;
}

inline int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = ret * a % P;
		a = a * a % P; anum >>= 1;
	}
	return ret;
}

int n, m, a[N], b[N], h[N << 2][M];

#define lc (o << 1)
#define rc (o << 1 | 1)
#define mid ((L + R) >> 1)

namespace SegTree{

	void Pushup(int o){
		For(i, 0, m) h[o][i] = 0;
		For(i, 0, m) For(j, 0, m - i)
			h[o][i + j] = Mod(h[o][i + j] + h[lc][i] * h[rc][j] % P);
	}

	void Build(int o, int L, int R){
		if(L == R){
			h[o][0] = b[L]; h[o][1] = a[L]; return;
		}

		Build(lc, L, mid); Build(rc, mid + 1, R);
		Pushup(o);
	}

	void Modify(int o, int L, int R, int p){
		if(L == R){
			h[o][0] = b[L]; h[o][1] = a[L]; return;
		}

		if(p <= mid) Modify(lc, L, mid, p);
		else Modify(rc, mid + 1, R, p);
		Pushup(o);
	}
};

#undef lc
#undef rc
#undef mid

using namespace SegTree;

int main(){
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	
	Read(n), Read(m); --m;
	For(i, 1, n) Read(a[i]), a[i] %= P; 
	For(i, 1, n) Read(b[i]), b[i] %= P;

	int all = 1;
	For(i, 1, n) all = all * (a[i] + b[i]) % P;

	Build(1, 1, n);

	int Q, p, x, y;
	Read(Q);

	while(Q --){
		Read(p), Read(x), Read(y);

		all = all * Pow(Mod(a[p] + b[p]), P - 2) % P;
		a[p] = x % P; b[p] = y % P;
		all = all * (a[p] + b[p]) % P;

		Modify(1, 1, n, p);

		int ans = all;
		For(i, 0, m) ans = Mod(ans - h[1][i]);
		printf("%d\n", ans);
	}

	return 0;
}
