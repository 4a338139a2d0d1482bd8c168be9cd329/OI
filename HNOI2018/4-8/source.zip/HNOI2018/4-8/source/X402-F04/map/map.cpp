//2018-4-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)
#define M (150000 + 5)

char chr;
void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0'); chr = getchar();
	}
}

int n, m, clk, siz1, siz2, o[N], oil[N];
vector<int> G[N];

int dfn[N], low[N], dy[N], id[N], siz[N], ans[N], sum[2][N], cnt[N * 10], bnum[N];
bool vis[N];

struct node{
    int l, r, ty, lim, num;

	bool operator <(const node &q)const{
	    if(bnum[l] ^ bnum[q.l]) return bnum[l] < bnum[q.l];
		return bnum[r] < bnum[q.r];
	}
}e[N];

#define v G[now][i]
void Tarjan(int now, int F){
    dfn[now] = low[now] = ++clk; dy[clk] = now;
	
	For(i, 0, G[now].size() - 1) if(v != F){
        if(!dfn[v]){
            Tarjan(v, now); low[now] = min(low[now], low[v]);
        }else low[now] = min(low[now], dfn[v]);
    }
}

void Dfs(int now){
	vis[now] = true; id[now] = ++clk; siz[now] = 1;
	For(i, 0, G[now].size() - 1)
		if(!vis[v] && low[v] >= dfn[now]) Dfs(v), siz[now] += siz[v];

    For(i, 0, G[now].size() - 1)
		if(!vis[v]) Dfs(v), siz[dy[low[v]]] += siz[v];
}
#undef v

void Up(int pos, bool ty){
    int p = (oil[pos] - 1) / siz2 + 1;
    if(ty){
        if(cnt[oil[pos]] & 1) --sum[1][p], ++sum[0][p];
        else if(cnt[oil[pos]]) --sum[0][p], ++sum[1][p];
        else ++sum[1][p];
        ++cnt[oil[pos]];
    }else{
        if(cnt[oil[pos]] == 1) --sum[1][p];
        else if(cnt[oil[pos]] & 1) --sum[1][p], ++sum[0][p];
        else --sum[0][p], ++sum[1][p];
        --cnt[oil[pos]];
    }
}

int Cal(int x, bool ty){
    int ret = 0, last = (x - 1) / siz2 + 1;

	For(i, 1, last - 1) ret += sum[ty][i];
    For(i, (last - 1) * siz2 + 1, x) ret += (cnt[i] && (cnt[i] & 1) == ty);
	
	return ret;
}

int main(){
	freopen("map.in", "r", stdin);
	freopen("map.out", "w", stdout);
	
	int u, v, Q, x;

    Read(n); Read(m); siz1 = sqrt(n);
	For(i, 1, n) bnum[i] = (i - 1) / siz1 + 1;
	For(i, 1, n) Read(o[i]), siz2 = max(siz2, o[i]);
    
	siz2 = sqrt(siz2);
	For(i, 1, m) Read(u), Read(v), G[u].pb(v), G[v].pb(u);

    clk = 0, Tarjan(1, 0); clk = 0, Dfs(1);
	For(i, 1, n) oil[id[i]] = o[i];

    Read(Q);
    For(i, 1, Q){
        Read(e[i].ty); Read(x); Read(e[i].lim);
        e[i].l = id[x]; e[i].r = id[x] + siz[x] - 1; e[i].num = i;
    }
    sort(e + 1, e + Q + 1);

    int L = 1, R = 0;
	For(i, 1, Q){
        while(R < e[i].r) Up(++R, 1); while(L > e[i].l) Up(--L, 1);
        while(R > e[i].r) Up(R--, 0); while(L < e[i].l) Up(L++, 0);
        ans[e[i].num] = Cal(e[i].lim, e[i].ty);
    }
    For(i, 1, Q) printf("%d\n", ans[i]);

	return 0;
}
