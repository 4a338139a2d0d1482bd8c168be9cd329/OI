#include<bits/stdc++.h>
#define N 100100
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=10007;
long long n,c;
long long a[N],b[N];
long long dp[1000][30];
long long sum[1000];
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	read(n);read(c);
	for(long long i=1;i<=n;i++)read(a[i]);
	for(long long i=1;i<=n;i++)read(b[i]);
	long long q;
	read(q);
	dp[0][0]=1;
	while(q--)
	{
		static long long op,x,y;
		read(op);read(x);read(y);
		a[op]=x;b[op]=y;
		sum[0]=1;
		for(long long i=1;i<=n;i++)
			sum[i]=sum[i-1]*(a[i]+b[i])%mod;
		long long ans=0;
		for(long long i=1;i<=n;i++)
			for(long long j=0;j<c;j++)
			{
				dp[i][j]=((j!=0)*dp[i-1][(j-1)>=0?j-1:0]*a[i]+dp[i-1][j]*b[i])%mod;
				if(i==n)(ans+=dp[i][j])%=mod;
			}
		printf("%lld\n",((sum[n]%mod-ans%mod)%mod+mod)%mod);
	}
	return 0;
}
