#include<bits/stdc++.h>
#define N 4100
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const int inf=0x7f7f7f7f;
int n,m;
int to[N],beg[N],nex[N],flow[N],vis[N];
int cur[N],d[N];
int e=1;
int ans;
inline void add(int x,int y,int z)
{
    to[++e]=y;
    nex[e]=beg[x];
    beg[x]=e;
    flow[e]=z;
}
queue<int>q;
int s,t;
inline bool bfs()
{
    memset(d,0,sizeof(d));
    while(!q.empty())q.pop();
    q.push(s);
    d[s]=1;
    while(!q.empty())
    {
        static int k;
        k=q.front();
        q.pop();
        for(register int i=beg[k];i;i=nex[i])
        {
            static int y;
            y=to[i];
            if(!d[y]&&flow[i])
            {
                d[y]=d[k]+1;
                if(y==t)return true;
                q.push(y);
            }
        }
    }
    return false;
}
int dfs(int x,int dd)
{
    if(x==t||dd==0)return dd;
    int floww=0,ff;
    for(int& i=cur[x];i;i=nex[i])
    {
        static int y;
        y=to[i];
        if(d[y]==d[x]+1&&(ff=dfs(y,min(dd,flow[i]))))
        {
            floww+=ff;
            flow[i]-=ff;
            flow[i^1]+=ff;
            dd-=ff;
            if(dd==0)break;
        }
    }
    if(!floww)d[x]=0;
    return floww;
}
int tmp[N];
int dinic()
{
	int floww=0;
	memcpy(flow,tmp,sizeof flow);
	while(bfs())
	{
		memcpy(cur,beg,sizeof cur);
		floww+=dfs(s,inf);
		if(floww>=ans)return inf;
	}
	return floww;
}
int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	read(n);read(m);
	if(m==n-1)return cout<<1<<endl,0;
	for(int i=1;i<=m;i++)
	{
		static int x,y;
		read(x);read(y);
		add(x,y,1);add(y,x,0);
		add(y,x,1);add(x,y,0);
	}
	ans=inf;
	memcpy(tmp,flow,sizeof tmp);
	for(int i=2;i<=n;i++)s=1,t=i,ans=min(ans,dinic());
	printf("%d\n",ans);
	return 0;
}
