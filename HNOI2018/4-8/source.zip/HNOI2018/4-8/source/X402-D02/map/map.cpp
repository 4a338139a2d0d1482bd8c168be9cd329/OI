#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<cassert>
#define x first
#define y second

inline void check_min(int a,int &b){if(a<b)b=a;}
inline void check_max(int a,int &b){if(a>b)b=a;}
inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

typedef std::pair<int,int> pii;
const int N=101000,M=301000;

struct node
{
	int lim,ty,id;
	node(int a=0,int b=0,int c=0):lim(a),ty(b),id(c){}
};

std::vector<node> V[N];

int val[N],ans[N];
int n,tot;

namespace Tree
{
#define lt(p) (st[p][0])
#define rt(p) (st[p][1])
#define mid ((L+R)>>1)
	const int SIZ=6000000,RG=1000000;
	int st[SIZ][2],w[SIZ][2],ep;

	inline void check(int &p){if(!p)p=++ep;}
	void upd(int p)
	{
		w[p][0]=w[lt(p)][0]+w[rt(p)][0];
		w[p][1]=w[lt(p)][1]+w[rt(p)][1];
	}
	int merge(int p0,int p1,int L=1,int R=RG)
	{
		if(!p0 || !p1)return p0|p1;
		if(L==R)
		{
			assert(w[p0][0]+w[p0][1]<=1),assert(w[p1][0]+w[p1][1]<=1);
			bool ret=w[p0][1]^w[p1][1];
			w[p0][1]=ret,w[p0][0]=ret^1;
			return p0;
		}
		lt(p0)=merge(lt(p0),lt(p1),L,mid);
		rt(p0)=merge(rt(p0),rt(p1),mid+1,R);
		upd(p0);
		return p0;
	}
	void inc(int x,int &p,int L=1,int R=RG)
	{
		check(p);
		if(L==R)
		{
			if(w[p][0]+w[p][1]==0)w[p][1]=1;
			else w[p][0]^=1,w[p][1]^=1;
			return;
		}
		if(x<=mid)inc(x,lt(p),L,mid);
		else inc(x,rt(p),mid+1,R);
		upd(p);
	}
	int query(int lim,int ty,int p,int L=1,int R=RG)
	{
		if(lim<L || w[p][ty]==0)return 0;
		if(lim>=R)return w[p][ty];
		return query(lim,ty,lt(p),L,mid)+query(lim,ty,rt(p),mid+1,R);
	}

	int root[N*2];
	int begin[N*2],next[N*2],to[N*2];

	int e;

	void add(int x,int y)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}
	void dfs(int p=1)
	{
		for(int i=begin[p],q;i;i=next[i])
		{
			dfs(q=to[i]);
			root[p]=merge(root[p],root[q]);
		}
		if(p<=n)inc(val[p],root[p]);

		for(int i=0;i<(int)V[p].size();i++)
		{
			int lim=V[p][i].lim,ty=V[p][i].ty,id=V[p][i].id;
			ans[id]=query(lim,ty,root[p]);
		}
	}
}

namespace ShaBi
{
	int begin[N],next[M],to[M];

	int m,Q,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	void initialize()
	{
		read(n),read(m);
		for(int i=1;i<=n;i++)read(val[i]);
		for(int u,v;m-->0;)read(u),read(v),add(u,v);
		read(Q);
		for(int i=1,ty,x,y;i<=Q;i++)
			read(ty),read(x),read(y),V[x].push_back(node(y,ty,i));
	}

	int dfn[N];
	pii stk[N];
	int top,clk;
	int dfs(int p=1,int h=0)
	{
		int lowp=dfn[p]=++clk,lowq;

		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !dfn[q])
			{
				stk[++top]=pii(p,q);
				check_min(lowq=dfs(q,p),lowp);

				if(lowq>dfn[p])
				{
					assert(stk[top]==pii(p,q));
					Tree::add(p,q);
					top--;
				}
				else if(lowq==dfn[p])
				{
					Tree::add(p,++tot);
					for(int x;;)
					{
						x=stk[top].y;
						Tree::add(tot,x);
						top--;
						if(x==q)break;
					}
				}
			}
			else if(q!=h)check_min(dfn[q],lowp);
		return lowp;
	}
	void solve()
	{
		initialize();
		tot=n,top=clk=0,dfs();
		Tree::dfs();
		for(int i=1;i<=Q;i++)
			printf("%d\n",ans[i]);
	}
}

int main()
{
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	ShaBi::solve();
	return 0;
}
