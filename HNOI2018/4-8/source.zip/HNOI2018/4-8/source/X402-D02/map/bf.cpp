#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<cassert>
#define x first
#define y second

inline void check_min(int a,int &b){if(a<b)b=a;}
inline void check_max(int a,int &b){if(a>b)b=a;}
inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

typedef std::pair<int,int> pii;
const int N=1050,M=301000;

int val[N];
int n,tot;

namespace Tree
{
	int begin[N*2],next[N*2],to[N*2];
	int e;

	void add(int x,int y)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}

	int cnt[N];
	void dfs(int p)
	{
		if(p<=n)cnt[val[p]]++;
		for(int i=begin[p];i;i=next[i])
			dfs(to[i]);
	}
	int solve(int p,int lim,int ty)
	{
		memset(cnt,0,sizeof(cnt));
		dfs(p);
		int ret=0;
		for(int i=1;i<=lim;i++)
			if(cnt[i]>0 && cnt[i]%2==ty)
				ret++;
		return ret;
	}
}

namespace bf
{
	int begin[N],next[M],to[M];

	int m,Q,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	void initialize()
	{
		read(n),read(m);
		for(int i=1;i<=n;i++)read(val[i]);
		for(int u,v;m-->0;)read(u),read(v),add(u,v);
		read(Q);
	}

	int dfn[N];
	pii stk[N];
	int top,clk;
	int dfs(int p=1,int h=0)
	{
		int lowp=dfn[p]=++clk,lowq;

		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !dfn[q])
			{
				stk[++top]=pii(p,q);
				check_min(lowq=dfs(q,p),lowp);

				if(lowq>dfn[p])
				{
					assert(stk[top]==pii(p,q));
					Tree::add(p,q);
					top--;
				}
				else if(lowq==dfn[p])
				{
					Tree::add(p,++tot);
					for(int x;;)
					{
						x=stk[top].y;
						Tree::add(tot,x);
						top--;
						if(x==q)break;
					}
				}
			}
			else if(q!=h)check_min(dfn[q],lowp);
		return lowp;
	}

	void solve()
	{
		initialize();
		tot=n,top=clk=0,dfs();

		for(int i=1,ty,x,y;i<=Q;i++)
		{
			read(ty),read(x),read(y);
			printf("%d\n",Tree::solve(x,y,ty));
		}
	}
}

int main()
{
	freopen("map.in","r",stdin);
	freopen("map.ans","w",stdout);
	bf::solve();
	return 0;
}
