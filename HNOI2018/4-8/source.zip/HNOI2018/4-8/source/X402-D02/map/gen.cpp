#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

const int N=233333;

struct tree
{
	int fa[N];
	void reset(int n){for(int i=1;i<=n;i++)fa[i]=0;}
	void setrt(int p)
	{
		if(!fa[p])return;
		setrt(fa[p]);
		fa[fa[p]]=p;
		fa[p]=0;
	}
}T;

bool fucked[N];

int dis(int u,int v)
{
	if(fucked[v])return -1;
	T.setrt(u);
	int ret=0;
	while(u!=v)
	{
		v=T.fa[v],ret++;
		if(fucked[v])return -1;
	}
	return ret;
}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("map.in","w",stdout);//look at here

	int n=1000,m=1050,lim=30;

//	n=100000,m=n-1,lim=100000;

	printf("%d %d\n",n,m);

	for(int i=1;i<=n;i++)
		printf("%d ",rand()%lim+1);
	printf("\n");
	
	for(int i=2;i<=n;i++)
	{
		int u=rand()%(i-1)+1,v=i;
		printf("%d %d\n",u,v);
		T.fa[v]=u;
	}

	int limdis=50;
	for(int i=n;i<=m;i++)
	{
		int u=rand()%n+1,v=rand()%n+1,k;
		k=dis(u,v);
		while(u==v || k<0 || k>limdis)
		{
			u=rand()%n+1,v=rand()%n+1;
			k=dis(u,v);
		}
		printf("%d %d\n",u,v);
		T.setrt(u),fucked[v]=1;
		while(u!=v)fucked[v=T.fa[v]]=1;
	}

	int q=2333;
//	q=100000;

	printf("%d\n",q);
	while(q--)
		printf("%d %d %d\n",rand()%2,rand()%n+1,rand()%lim+1);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
