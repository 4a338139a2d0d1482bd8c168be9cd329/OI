#include<iostream>
#include<cstdio>
#include<cstring>

inline void read(int &x)
{
	char c=x=0,flag=1;
	for(c=getchar();!isdigit(c) && c!='-';c=getchar());
	if(c=='-')flag=0,c=getchar();
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	if(!flag)x=-x;
}

namespace PaoBuGuo
{
	const int N=100010,M=21,MOD=10007;

	inline void inc(int a,int &b){b=(a+b)%MOD;}

	int n,m,T;

	struct Poly
	{
		int s[M];
		Poly(){memset(s,0,sizeof(s));}
	};

	Poly operator * (Poly &A,Poly &B)
	{
		static Poly C;
		C=Poly();
		for(register int i=0;i<=m;i++)
		{
			if(!A.s[i])continue;
			for(register int j=0;j<=m;j++)
			{
				if(!B.s[j])continue;

				register int k=std::min(i+j,m);
				C.s[k]+=A.s[i]*B.s[j];
				if(k==m && C.s[k]>1000000000)C.s[k]%=MOD;
			}
		}
		for(int i=0;i<=m;i++)C.s[i]%=MOD;
		return C;
	}

#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
	Poly calc(int p);

	Poly w[N*4];
	inline void upd(int p){w[p]=w[lt]*w[rt];}
	void reset(int x,int p=1,int L=1,int R=n)
	{
		if(L==R){w[p]=calc(L);return;}
		if(x<=mid)reset(x,lcq);
		else reset(x,rcq);
		upd(p);
	}
	void build(int p=1,int L=1,int R=n)
	{
		if(L==R){w[p]=calc(L);return;}
		build(lcq),build(rcq);
		upd(p);
	}

	int A[N],B[N];
	inline Poly calc(int p)
	{
		static Poly C;
		C=Poly();
		C.s[0]=B[p],C.s[1]=A[p];
		return C;
	}

	void initialize()
	{
		read(n),read(m);
		for(int i=1;i<=n;i++)
			read(A[i]),read(B[i]),A[i]%=MOD,B[i]%=MOD;
		build();
		read(T);
	}
	void solve()
	{
		initialize();
		for(int p;T--;)
		{
			read(p);

			read(A[p]),read(B[p]),A[p]%=MOD,B[p]%=MOD;

			reset(p);
			register int ret=(w[1].s[m]+MOD)%MOD;

			printf("%d\n",ret);

//			if(T%1000==0)fprintf(stderr,"T = %d\n",T);
		}
	}
}

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	PaoBuGuo::solve();
//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
