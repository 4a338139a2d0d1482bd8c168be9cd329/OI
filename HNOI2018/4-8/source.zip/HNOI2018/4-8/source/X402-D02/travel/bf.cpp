#include<iostream>
#include<cstdio>
#include<cstring>

namespace bf
{
	const int N=2333,M=21,MOD=10007;

	inline void inc(int a,int &b){b=(a+b)%MOD;}

	int A[N],B[N];
	int n,m,T;

	int dp()
	{
		static int f[N][M];
		memset(f,0,sizeof(f));
		f[0][0]=1;
		for(int i=0;i<n;i++)
			for(int j=0;j<=m;j++)
			{
				int v=f[i][j];
				if(!v)continue;

				inc(v*A[i+1]%MOD,f[i+1][std::min(j+1,m)]);
				inc(v*B[i+1]%MOD,f[i+1][j]);
			}
		return f[n][m];
	}

	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)
			scanf("%d%d",A+i,B+i),A[i]%=MOD,B[i]%=MOD;
		scanf("%d",&T);
	}
	void solve()
	{
		initialize();
		for(int p;T--;)
		{
			scanf("%d",&p);
			scanf("%d%d",A+p,B+p),A[p]%=MOD,B[p]%=MOD;
			printf("%d\n",dp());
		}
	}
}

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.ans","w",stdout);
	bf::solve();
	return 0;
}
