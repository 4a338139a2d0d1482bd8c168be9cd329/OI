#include<iostream>
#include<cstdio>
#include<cstring>

namespace PaoBuGuo
{
	const int N=100010,M=21,MOD=10007;

	inline void inc(int a,int &b){b=(a+b)%MOD;}
	int inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

	int n,m,T;

	struct matrix
	{
		int s[M][M];
		matrix(){memset(s,0,sizeof(s));}
	};
	struct vector
	{
		int s[N];
		vector(){memset(s,0,sizeof(s));}
	};

	matrix operator * (matrix &A,matrix &B)
	{
		static matrix C;
		C=matrix();
		for(int i=0;i<=m;i++)
			for(int j=0;j<=i;j++)
			{
				for(int k=j;k<=i;k++)
					C.s[i][j]+=A.s[i][k]*B.s[k][j];
				C.s[i][j]%=MOD;
			}
		return C;
	}
	vector operator * (matrix &A,vector &B)
	{
		static vector C;
		C=vector();
		for(int i=0;i<=m;i++)
		{
			for(int j=0;j<=i;j++)
				C.s[i]+=A.s[i][j]*B.s[j];
			C.s[i]%=MOD;
		}
		return C;
	}

#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
	matrix calc(int p);

	matrix w[N*4];
	void upd(int p){w[p]=w[lt]*w[rt];}
	void reset(int x,int p=1,int L=1,int R=n)
	{
		if(L==R){w[p]=calc(L);return;}
		if(x<=mid)reset(x,lcq);
		else reset(x,rcq);
		upd(p);
	}
	void build(int p=1,int L=1,int R=n)
	{
		if(L==R){w[p]=calc(L);return;}
		build(lcq),build(rcq);
		upd(p);
	}

	int A[N],B[N];
	matrix calc(int p)
	{
		static matrix C;
		C=matrix();
		for(int i=0;i<=m;i++)C.s[i][i]=B[p];
		for(int i=1;i<=m;i++)C.s[i][i-1]=A[p];
		inc(A[p],C.s[m][m]);
		return C;
	}

	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)
			scanf("%d%d",A+i,B+i),A[i]%=MOD,B[i]%=MOD;
		build();
		scanf("%d",&T);
	}
	void solve()
	{
		initialize();
		for(int p;T--;)
		{
			scanf("%d",&p);
			scanf("%d%d",A+p,B+p),A[p]%=MOD,B[p]%=MOD;
			reset(p);
			printf("%d\n",w[1].s[m][0]);
		}
	}
}

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	PaoBuGuo::solve();
	return 0;
}
