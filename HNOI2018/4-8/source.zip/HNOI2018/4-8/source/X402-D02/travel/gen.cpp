#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("travel.in","w",stdout);//look at here

	int n=70363,m=20,T=93259,lim=1000000007;
	n=1333,m=20,T=233;

	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%lim+1);
	printf("\n");
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%lim+1);
	printf("\n");

	for(printf("%d\n",T);T--;)
		printf("%d %d %d\n",rand()%n+1,rand()%lim+1,rand()%lim+1);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
