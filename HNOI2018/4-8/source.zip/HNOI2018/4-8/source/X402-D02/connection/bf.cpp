#include<iostream>
#include<cstdio>
#include<cstring>
#define x first
#define y second

typedef std::pair<int,int> pii;

const int N=22,M=1010;

pii s[M];
int n,m,ans;

bool sel[N];
bool fuck()
{
	for(int i=2;i<=n;i++)
		if(sel[i]!=sel[i-1])return 0;
	return 1;
}
int calc()
{
	if(fuck())return m;

	int ret=0;
	for(int i=1;i<=m;i++)
		ret+=sel[s[i].x]^sel[s[i].y];
	return ret;
}
void dfs(int p=1)
{
	if(p>n)
	{
		ans=std::min(ans,calc());
		return ;
	}
	sel[p]=1,dfs(p+1);
	sel[p]=0,dfs(p+1);
}

int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.ans","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
		scanf("%d%d",&s[i].x,&s[i].y);
	ans=m,dfs();
	printf("%d\n",ans);
	return 0;
}
