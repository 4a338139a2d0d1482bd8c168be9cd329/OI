#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("connection.in","w",stdout);//look at here
	
	int n=16,m=200;
	printf("%d %d\n",n,m);

	for(int i=2;i<=n;i++)
		printf("%d %d\n",rand()%(i-1)+1,i);
	for(int i=n;i<=m;i++)
	{
		int u=rand()%n+1,v=rand()%n+1;
		while(u==v)u=rand()%n+1,v=rand()%n+1;
		printf("%d %d\n",u,v);
	}

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
