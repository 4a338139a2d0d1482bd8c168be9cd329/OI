#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>

namespace MaoSiKeYiZuo
{
	const int N=303,M=1010,INF=1000000007;

	int begin[N],next[M*2],to[M*2],w[M*2];
	int lv[N];

	bool bfs(int st,int ed)
	{
		static std::queue<int> Q;
		memset(lv,0,sizeof(lv));
		lv[st]=1,Q.push(st);
		while(!Q.empty())
		{
			int p=Q.front(),q;Q.pop();
			for(int i=begin[p];i;i=next[i])
				if(w[i] && !lv[q=to[i]])lv[q]=lv[p]+1,Q.push(q);
		}
		return lv[ed]!=0;
	}
	int dfs(int p,int flow,int ed)
	{
		if(p==ed || !flow)return flow;
		int ret=0,k;
		for(int i=begin[p],q;i;i=next[i])
			if(w[i] && lv[q=to[i]]==lv[p]+1)
			{
				k=dfs(q,std::min(flow,w[i]),ed);
				w[i]-=k,w[i^1]+=k;
				ret+=k,flow-=k;
				if(!flow)break;
			}
		return ret;
	}
	int maxflow(int st,int ed)
	{
		int ret=0;
		while(bfs(st,ed))ret+=dfs(st,INF,ed);
		return ret;
	}

	int n,m,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		w[e]=1;
		if(k)add(y,x,0);
	}

	void solve()
	{
		scanf("%d%d",&n,&m),e=1;
		for(int i=1,u,v;i<=m;i++)
			scanf("%d%d",&u,&v),add(u,v);
		int ans=m;
		for(int i=2;i<=n;i++)
		{
			ans=std::min(ans,maxflow(1,i));
			for(int i=2;i<=e;i+=2)
				w[i]=w[i^1]=1;
		}
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	MaoSiKeYiZuo::solve();
	return 0;
}
