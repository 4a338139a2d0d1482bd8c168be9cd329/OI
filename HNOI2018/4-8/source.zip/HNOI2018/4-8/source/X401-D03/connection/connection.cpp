#include<bits/stdc++.h>
using namespace std;
const int maxn=1010,inf=0x3f3f3f3f;
int g[maxn][maxn],dis[maxn],vis[maxn],bin[maxn],n,m;
int merge(int &s,int &t){
	memset(dis,0,sizeof(dis));
	memset(vis,0,sizeof(vis));
	int cut;
	for(register int i=1;i<=n;++i){
		int k=-1,maxx=-1;
		for(register int j=1;j<=n;++j){
			if(!bin[j]&&!vis[j]&&dis[j]>maxx)k=j,maxx=dis[j];
		}if(k==-1)return cut;
		vis[k]=1,s=t,t=k,cut=maxx;
		for(register int j=1;j<=n;++j)if(!bin[j]&&!vis[j])dis[j]+=g[k][j];
	}
	return cut;
}
int stoer_wagner(){
	int cut=inf,s,t,ans;
	for(register int i=1;i<n;++i){
		ans=merge(s,t);
		bin[t]=1;
		cut=min(cut,ans);
		if(!cut)return 0;
		for(register int j=1;j<=n;++j)if(!bin[j])g[s][j]=(g[j][s]+=g[j][t]);
	}return cut;
}
int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	int x,y;
	scanf("%d%d",&n,&m);
	while(m--)scanf("%d%d",&x,&y),g[x][y]=g[y][x]=1;
	printf("%d\n",stoer_wagner());
	return 0;
}
