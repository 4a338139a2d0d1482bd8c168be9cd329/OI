#include<bits/stdc++.h>
using namespace std;
const int maxn=100100,mod=10007;
int f[maxn<<2][35],A[maxn],B[maxn],dp[maxn][35];
#define lson (rt<<1)
#define rson lson|1
int n,c,p;
inline void pushup(int rt){
	memset(f[rt],0,sizeof(f[rt]));
	for(register int i=0;i<=c;++i){
		for(register int j=0;j+i<=c;++j){
			f[rt][i+j]=(f[rt][i+j]+f[lson][i]*f[rson][j]%mod)%mod;
		}
	}
}
inline void build(int rt,int l,int r){
	if(l==r){
		f[rt][0]=B[l]%mod;
		f[rt][1]=A[l]%mod;
		return;
	}int mid=(l+r)>>1;
	build(lson,l,mid),build(rson,mid+1,r);
	pushup(rt);
}
inline void update(int rt,int l,int r,int x){
	if(l==r){
		if(l==x){;
			f[rt][0]=B[l]%mod;
			f[rt][1]=A[l]%mod;
		}return;
	}int mid=(l+r)>>1;
	if(x<=mid)update(lson,l,mid,x);
	else update(rson,mid+1,r,x);
	pushup(rt);
}
inline int Pow(int x,int y){
	int ans=1;
	for(;y;y>>=1){
		if(y&1)ans=ans*x%mod;
		x=x*x%mod;
	}return ans;
}
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())x=(x<<1)+(x<<3)+ch-48;
	return x*f;
}
inline void work(){
	dp[0][0]=1;
	for(register int i=1;i<=n;++i){
		dp[i][0]=dp[i-1][0]*B[i]%mod;
		for(register int j=1;j<=c;++j){
			dp[i][j]=(dp[i-1][j]*B[i]%mod+dp[i-1][j-1]*A[i]%mod)%mod;
		}dp[i][c]=(dp[i][c]+dp[i-1][c]*A[i]%mod)%mod;
	}
}
inline void bf1(){
	int x,y,z;
	while(p--){
		x=read(),y=read(),z=read();
		A[x]=y%mod,B[x]=z%mod;
		work();
		printf("%d\n",dp[n][c]);
	}return;
}
inline void bf2(){
	build(1,1,n);
	int tot=1;
	for(register int i=1;i<=n;++i)tot=(tot*(A[i]+B[i])%mod)%mod;
	int x,y,z;
	while(p--){
		x=read();
		int inv=Pow((A[x]+B[x])%mod,mod-2),tmp=0;
		tot=tot*inv%mod;
		y=read()%mod,z=read()%mod;
		tot=tot*(y+z)%mod;A[x]=y,B[x]=z;
		update(1,1,n,x);
		for(register int i=0;i<c;++i)tmp=(tmp+f[1][i])%mod;
		printf("%d\n",(tot-tmp+mod)%mod);
	}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read(),c=read();
	for(register int i=1;i<=n;++i)A[i]=read()%mod;
	for(register int i=1;i<=n;++i)B[i]=read()%mod;
	p=read();
	if(n<1234)bf1();
	else bf2();
	return 0;
}
