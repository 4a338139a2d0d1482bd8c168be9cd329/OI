#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int main(){
	freopen("1.in","w",stdout); srand(time(0));
	int n=300,m=1000,x,y; printf("%d %d\n",n,m);
	For(i,1,n){
		For(j,0,2) printf("%d %d\n",i,(i+j)%n+1);
	}
	For(i,n*3+1,m){
		do {x=rand()%n+1,y=rand()%n+1,y=rand()%n+1;} while(x==y);
		printf("%d %d\n",x,y);
	}
	return 0;
}
