#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=305,M=2005;
struct node{
	int to,w,nex;
}a[M];
int e=1,head[N],d[N],id[N],q[N],prv[N]; bool vis[N],fl;
bool cmd(int x,int y){
	return d[x]<d[y];
}
void add(int x,int y){
	a[++e]=(node){y,1,head[x]}; head[x]=e;
}
int main(){
	freopen("connection.in","r",stdin); freopen("connection.out","w",stdout);
	int n=read(),m=read(),x,y,ans=100,an,s,t,l,r;
	For(i,1,m) x=read(),y=read(),add(x,y),add(y,x),++d[x],++d[y];
	For(i,1,n) id[i]=i,ans=min(ans,d[i]); if (ans==1) printf("1\n"),exit(0);
	sort(id+1,id+1+n,cmd);
	For(ii,1,n-1){
		s=id[ii]; prv[s]=0;
		For(jj,ii+1,n){
			t=id[jj]; an=0;
			For(k,2,e) a[k].w=1;
			while(1){
				l=0,r=1; q[1]=s; memset(vis,0,sizeof(vis)),fl=0,vis[s]=1;
				while(l<r){
					x=q[++l];
					for(int i=head[x];i;i=a[i].nex) if (a[i].w){
						y=a[i].to;
						if (!vis[y]){
							prv[y]=i; if (y==t) {fl=1; goto en;} q[++r]=y,vis[y]=1;
						}
					}
				}
				en:; if (!fl) break; x=t; ++an; if (an==ans) break;
				while(x!=s) y=prv[x],--a[y].w,++a[y^1].w,x=a[y^1].to;
			}
			ans=min(ans,an); if (ans==1) printf("1\n"),exit(0);
		}
	}
	printf("%d\n",ans);
	return 0;
}
