#include<bits/stdc++.h>
#define maxn 100010
#define mid (l+r>>1)
#define check(s) (s<='9'&&s>='0')
const int mod=10007;
using namespace std;
int n,c,a[maxn],b[maxn],p;
struct tree{
	int w[21];
	tree*ls,*rs;
	tree()
	{
		ls=rs=NULL;
		for(int i=0;i<=c;++i) w[i]=0; 
	}
	void update()
	{
		for(int i=0;i<=c;++i)
			w[i]=0;
		for(int i=0;i<=c;++i)
			for(int j=0;j<=c;++j)
			w[min(i+j,c)]=(w[min(i+j,c)]+ls->w[i]*rs->w[j])%mod;
	}
	void build(int l,int r)
	{
		if(l==r) {
			w[0]=b[l];
			w[1]=a[l];
			return;
		}
		(ls=new tree)->build(l,mid);
		(rs=new tree)->build(mid+1,r);
		update();
	}
	void modify(int l,int r,int pos,int ai,int bi)
	{
		if(l==r){
			w[0]=bi;w[1]=ai;
			return;
		}
		if(pos>mid) rs->modify(mid+1,r,pos,ai,bi);
		else ls->modify(l,mid,pos,ai,bi);
		update();
	}
}*xtr;
int read()
{
	int res=0;char ch;
	for(ch=getchar();!check(ch);ch=getchar());
	res=ch-'0';
	for(ch=getchar();check(ch);ch=getchar()) res=res*10+ch-'0';
	return res;
}
int main()
{	
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&c);
	for(int i=1;i<=n;++i) a[i]=read()%mod;
	for(int i=1;i<=n;++i) b[i]=read()%mod;
	(xtr=new tree)->build(1,n);
	scanf("%d",&p);
	while(p--)
	{
		int i=read(),x=read()%mod,y=read()%mod;
		xtr->modify(1,n,i,x,y);
		printf("%d\n",xtr->w[c]);
	}
	return 0;
}
/*
4 2 
1 2 3 4 
1 2 3 4 
1 
4 1 1 
*/

