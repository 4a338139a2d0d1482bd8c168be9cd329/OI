#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define maxn 305
#define maxm 1010
#define check(s) (s<='9'&&s>='0')
using namespace std;
int read()
{
	int res=0;char ch;
	for(ch=getchar();!check(ch);ch=getchar());
	res=ch-'0';
	for(ch=getchar();check(ch);ch=getchar())
	res=res*10+ch-'0';
	return res;
}
struct node{
	int to,f,m;
	node*next,*rev;
}*con[maxn];
void addedge(int x,int y)
{
	node*p=new node;
	p->to=y;
	p->f=0;p->m=1;
	p->next=con[x];
	con[x]=p;
	p=new node;
	p->f=p->m=0;p->to=x;
	p->next=con[y];
	con[y]=p;
	con[x]->rev=con[y];
	con[y]->rev=con[x];   
}
int s,t,n,m,x[maxm],y[maxm],ans=inf;
int dl[maxn],de[maxn],head,tail;
bool bfs()
{
	bool tmp=false;
	for(int i=1;i<=n;++i) de[i]=-1;
	dl[tail=head=1]=s;
	de[s]=1;
	while(head<=tail)
	{
		int v=dl[head++];
		if(v==t) tmp=true;
		for(node*p=con[v];p;p=p->next)
		if(p->f<p->m&&de[p->to]==-1)
		de[p->to]=de[v]+1,dl[++tail]=p->to;
	}
	return tmp;
}
int dinic(int v,int e)
{
	int temp=0,o=0;
	if(de[v]==-1) return 0;
	if(v==t) return e;
	for(node*p=con[v];p;p=p->next){
	if(de[p->to]==de[v]+1&&p->f<p->m)
	{
		o=dinic(p->to,min(e-temp,p->m-p->f));
		temp+=o;
		p->f+=o;
		p->rev->f-=o;
	}
	if(temp==e) break;
	}
	if(temp==0) de[v]=-1;
	return temp;
}
int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout); 
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i)
		x[i]=read(),y[i]=read();
	s=n>>1;
	for(t=1;t<=n;++t)
	if(s!=t)
	{
		for(int i=1;i<=n;++i) con[i]=NULL;
		for(int i=1;i<=m;++i)
			addedge(x[i],y[i]),addedge(y[i],x[i]);
		int temp=0;
		while(bfs()){
			temp+=dinic(s,inf);
			if(temp>ans) break;
		}
		ans=min(ans,temp);
		
	}
	cout<<ans;
	return 0;
} 
