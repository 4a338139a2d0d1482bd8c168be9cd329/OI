#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
#define Chkmin(a,b) a=a<b?a:b
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
#endif
}
const int MAXN=1111;
static struct edge
{
	int v,nxt,f;
}p[MAXN<<1],las[MAXN<<1];
static int d[333],n,m,Head[333],head[333],e;
inline void aff(int u,int v)
{las[++e]=(edge){v,Head[u]},Head[u]=e;}
inline void init()
{
	read(n);read(m);
	static int u,v;
	Rep(i,1,m)read(u),read(v),aff(u,v),aff(v,u),++d[u],++d[v];
}
inline void add(int u,int v,int f)
{p[++e]=(edge){v,head[u],f};head[u]=e;}
static int ans;
typedef pair<int,int>Pr;
map<Pr,bool>G;
static int vis[333],tt;
static int use[333][333];
void Mak(int u,int s,int t)
{
	vis[u]=tt;
	for(register int v=Head[u];v;v=las[v].nxt)if(las[v].v!=s&&use[u][las[v].v]!=tt)
	{
		use[u][las[v].v]=use[las[v].v][u]=tt;
		add(u,las[v].v,1);
		if(vis[las[v].v]!=tt&&las[v].v!=t)Mak(las[v].v,s,t);
	}
}

static int que[333],h,ta,dis[333];

inline bool bfs(int s,int t)
{
	h=0;que[ta=1]=s;
	static int u;
	Rep(i,1,n+2)dis[i]=0;dis[s]=1;
	while(h<ta)
	{
		u=que[++h];
		for(register int v=head[u];v;v=p[v].nxt)if(p[v].f&&!dis[p[v].v])
			dis[que[++ta]=p[v].v]=dis[u]+1;
	}
	return dis[t];
}

static int cur[333];
int dfs(int u,int t,int flow)
{
	if(u==t||!flow)return flow;
	int sum=0,f;
	for(register int&v=cur[u];flow&&v;v=p[v].nxt)if(dis[p[v].v]==dis[u]+1&&p[v].f)
	{
		f=dfs(p[v].v,t,min(flow,p[v].f));
		sum+=f;flow-=f;
		p[v].f-=f;p[v^1].f+=f;
	}
	if(!flow)cur[u]=0;
	return sum;
}

inline int Dinic(int s,int t)
{
	static int sum;sum=0;
	while(sum<ans&&bfs(s,t))
		memcpy(cur,head,sizeof head),sum+=dfs(s,t,ans);
	return sum;
}
inline void solve()
{
	srand(137934221);
	ans=1111;
	Rep(i,1,n)Chkmin(ans,d[i]);
	if(ans==1)return (void)puts("1");
	static int u,v,cnt=0;
	while(cnt<n*(n-1)/2&&ans>1&&1.0*clock()/CLOCKS_PER_SEC<=0.90)
	{
		u=rand()%n+1;v=rand()%n+1;
		while(G[Pr(u,v)])
		{
			u=rand()%n+1;v=rand()%n+1;
			while(v==u)v=rand()%n+1;
		}G[Pr(u,v)]=G[Pr(v,u)]=true;++cnt;
		e=1;Rep(i,1,n)head[i]=0;++tt;Mak(u,u,v);
		u=Dinic(u,v);
		Chkmin(ans,u);
	}
	printf("%d\n",ans);
}
int main()
{
	file();
	init();
	solve();
	return 0;
}

