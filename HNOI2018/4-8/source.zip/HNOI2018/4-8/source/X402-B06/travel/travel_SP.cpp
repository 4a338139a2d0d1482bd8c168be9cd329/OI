#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("travel.in","r",stdin);
	freopen("travel_SP.out","w",stdout);
#endif
}
const int mod=10007;
static int n,C,P,all;
inline int power(int a,int b)
{
	static int sum;
	for(sum=1;b;b>>=1,a=a*a%mod)if(b&1)
		sum=sum*a%mod;
	return sum;
}
const int MAXN=1e5+7;
static int ans,a[MAXN],b[MAXN];
static int dp[2][MAXN];
void solve()
{
	dp[0][0]=1;
	Rep(j,1,n)
	{
		dp[j&1][0]=b[j]*dp[!(j&1)][0]%mod;
		Rep(k,0,C-1)
		{
			dp[j&1][k]=a[j]*dp[!(j&1)][k-1]%mod+b[j]*dp[!(j&1)][k]%mod;
			if(dp[j&1][k]>=mod)dp[j&1][k]-=mod;
		}
	}
	static int z,u,v;
	z=0;
	Rep(i,1,P)
	{
		read(z);read(u);read(v);u%=mod;v%=mod;
		ans=ans*power(a[z]+b[z],mod-2)%mod*(u+v)%mod;
		dp[!(n&1)][0]=dp[n&1][0]*power(b[z],mod-2)%mod;
		Rep(j,1,C-1)
		{
			dp[!(n&1)][j]
			=(dp[n&1][j]-dp[!(n&1)][j-1]*a[z]%mod+mod)%mod*power(b[z],mod-2)%mod;
		}
		a[z]=u;b[z]=v;
		dp[n&1][0]=dp[!(n&1)][0]*b[z]%mod;
		Rep(j,1,C-1)
		{
			dp[n&1][j]=dp[!(n&1)][j-1]*a[z]%mod+dp[!(n&1)][j]*b[z]%mod;
			if(dp[n&1][j]>=mod)dp[n&1][j]-=mod;
		}
		z=0;
		Rep(j,0,C-1)
		{
			z+=dp[n&1][j];
			if(z>=mod)z-=mod;
		}
		printf("%d\n",(ans-z+mod)%mod);
	}
	
}
int main()
{
	file();
	read(n);read(C);
	Rep(i,1,n)read(a[i]),a[i]%=mod;
	Rep(i,1,n)read(b[i]),b[i]%=mod;
	read(P);
	ans=1;
	Rep(i,1,n)ans=ans*(a[i]+b[i])%mod;
	solve();
	return 0;
}

