#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
#endif
}
const int mod=10007;
const int MAXN=1e5+7;
static int n,C,P;
static struct node
{
	int k[23];
	friend node operator*(node a,node b)
	{
		static node c;
		Rep(i,0,C)c.k[i]=0;
		Rep(i,0,C)Rep(j,0,C)(c.k[min(i+j,C)]+=a.k[i]*b.k[j]%mod)%=mod;
		return c;
	}
}p[MAXN<<2];
static int a[MAXN],b[MAXN];
void make_tree(int h,int l,int r)
{
	if(l==r){p[h].k[0]=b[l],p[h].k[1]=a[l];return;}
	int mid=(l+r)>>1;
	make_tree(h<<1,l,mid);
	make_tree(h<<1|1,mid+1,r);
	p[h]=p[h<<1]*p[h<<1|1];
}
inline void init()
{
	read(n);read(C);
	Rep(i,1,n)read(a[i]),a[i]%=mod;
	Rep(i,1,n)read(b[i]),b[i]%=mod;
	make_tree(1,1,n);
}
void modify(int h,int l,int r,int pos,int x,int y)
{
	if(l==r){p[h].k[1]=x;p[h].k[0]=y;return;}
	static int mid;mid=(l+r)>>1;
	pos<=mid?modify(h<<1,l,mid,pos,x,y):modify(h<<1|1,mid+1,r,pos,x,y);
	p[h]=p[h<<1]*p[h<<1|1];
}
inline void solve()
{
	read(P);
	static int z,u,v,ans,sum;
	Rep(i,1,P)
	{
		read(z);read(u);read(v);u%=mod;v%=mod;
		modify(1,1,n,z,u,v);
		printf("%d\n",p[1].k[C]);
	}
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
}
int main()
{
	file();
	init();
	solve();
	return 0;
}

