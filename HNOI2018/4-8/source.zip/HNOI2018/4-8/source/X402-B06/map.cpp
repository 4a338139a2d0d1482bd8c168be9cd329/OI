#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
#endif
}
static int n,m;
int main()
{
	file();
	static int u,v;
	read(n);read(m);
	Rep(i,1,n)read(u);
	Rep(i,1,m)read(u),read(v);
	read(n);
	Rep(i,1,n)puts("0");
	return 0;
}

