#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=100000+10;
const int mod=10007;
//int dp[maxn][25];
int dp[maxn];
int a[maxn],b[maxn];
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,c;
	cin>>n>>c;
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
		a[i]%=mod;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",&b[i]);
		b[i]%=mod;
	}
	int p;
	cin>>p;
	int z,x,y;
	for(int i=1;i<=p;++i){
		scanf("%d%d%d",&z,&x,&y);
		a[z]=x%mod;
		b[z]=y%mod;
		/*
		dp[0][0]=1;
		int s=1;
		for(int j=1;j<=n;++j){
			s=s*b[j]%mod;
			dp[j][0]=s;
		}
		for(int j=1;j<=n;++j){
			for(int k=1;k<=n;++k){
				dp[j][k]=(dp[j-1][k-1]*a[j]%mod+dp[j-1][k]*b[j]%mod)%mod;
			}
		}
		*/
		for(int j=1;j<=n;++j) dp[j]=0;
		dp[0]=1;
		for(int j=1;j<=n;++j){
			for(int k=n;k>=1;--k){
				dp[k]=(dp[k-1]*a[j]%mod+dp[k]*b[j]%mod)%mod;
			}
			dp[0]=dp[0]*b[j]%mod;
		}
		int ans=0;
		for(int j=c;j<=n;++j)
			ans=(ans+dp[j])%mod;
		printf("%d\n",ans);
	}
	return 0;
}
