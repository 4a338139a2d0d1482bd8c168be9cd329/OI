#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=1000+10;
const int inf=1000000000;
#define mmin(a,b) a<b?a:b
struct node{
	int to,last,c,f;
}a[maxn<<1];
int beg[maxn],e;
void add(int x,int y,int z){
	a[++e].to=y;
	a[e].last=beg[x];
	a[e].c=z;
	beg[x]=e;
}
int s,t,ans;
int nex[maxn],q[maxn],d[maxn];
int n,m,da;
void EK(){
	while(1){
		int f=0,l=1;
		q[1]=s;
		for(int i=1;i<=n;++i) d[i]=0;
		d[s]=inf;
		while(f<l){
			int u=q[++f];
			for(int i=beg[u];i;i=a[i].last){
				int v=a[i].to;
				if(!d[v] && a[i].f<a[i].c){
					d[v]=mmin(d[u],a[i].c-a[i].f);
					q[++l]=v;
					nex[v]=i;
				}
			}
			if(d[t]) break;
		}
		if(!d[t]) return ;
		nex[s]=0;
		for(int i=nex[t];i;i=nex[a[i^1].to]){
			a[i].f+=d[t];
			a[i^1].f-=d[t];
		}
		ans+=d[t];
		if(ans>da) return ;
	}
}
int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	cin>>n>>m;
	int x,y;
	e=1;
	for(int i=1;i<=m;++i){
		scanf("%d%d",&x,&y);
		add(x,y,1);
		add(y,x,1);
	}
	if(m==n-1){
		cout<<1<<endl;
		return 0;
	}
	da=inf;
	s=1;
		for(t=s+1;t<=n;++t){
			ans=0;
			for(int i=2;i<=e;++i) a[i].f=0;
			EK();
			if(ans<da) da=ans;
		}
	cout<<da<<endl;
	return 0;
}
