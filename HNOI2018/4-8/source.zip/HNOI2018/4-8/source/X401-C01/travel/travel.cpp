#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
typedef long long LL;
template<typename T>inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
inline void File(){
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
}

const int maxn=80000,maxc=30,mod=10007;
int n,c;
int a[maxn],b[maxn];
int dp[maxn][maxc];

inline int Work(){
	dp[0][0]=1;
	for(Rint i=1;i<=n;i++){
		for(Rint j=0;j<=min(i,c);j++){
			if(j==0){
				dp[i][j]=(dp[i-1][j]*b[i])%mod;
				continue;
			}
			dp[i][j]=(dp[i-1][j-1]*a[i])%mod+(dp[i-1][j]*b[i])%mod;
			dp[i][j]%=mod;
		}
		(dp[i][c]+=(dp[i-1][c]*a[i])%mod)%=mod;
	}
	return dp[n][c]%mod;
}

int main(){
	File();
	read(n);read(c);
	for(Rint i=1;i<=n;i++)read(a[i]);
	for(Rint i=1;i<=n;i++)read(b[i]);
	int q;read(q);
	while(q--){
		int p,x,y;
		read(p);read(x);read(y);
		a[p]=x;b[p]=y;
		printf("%d\n",Work()%mod);
	}
	return 0;
}
