#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
typedef long long LL;
template<typename T>inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
inline void File(){
    freopen("connection.in","r",stdin);
    freopen("connection.out","w",stdout);
}

const int maxn=500,inf=0x3f3f3f3f;
int n,m;
int ind[maxn];
int ans=inf;

int main(){
	File();
	read(n);read(m);
	for(Rint i=1;i<=m;i++){
		int x,y;
		read(x);read(y);
		ind[x]++;ind[y]++;
	}
	for(Rint i=1;i<=n;i++)ans=min(ans,ind[i]);
	printf("%d\n",ans);
	return 0;
}
