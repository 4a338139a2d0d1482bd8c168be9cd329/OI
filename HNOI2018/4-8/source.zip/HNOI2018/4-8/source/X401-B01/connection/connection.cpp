#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>

using namespace std;

#define fr(i,a,b) for(register int i=a;i<=b;i++)
#define fv(i,a,b) for(register int i=a;i>=b;i--)
#define travel(i,a,b) for(register int i=head[a],b=e[i].to;i!=0;i=e[i].next,b=e[i].to)
#define fmin(a,b) ((a)<(b)?(a):(b))

struct edge{
	int to,next,flow;
}e[2010];

int n,m,cnt,head[310],gap[2010],d[310],ne[2010],MAXN,c[310];
bool flag;

inline int v_in(){
	char ch=getchar();int sum=0,f=1;
	while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
	while(isdigit(ch)) sum=(sum<<3)+(sum<<1)+(ch^48),ch=getchar();
	return sum*f;
}

inline void add(int u,int v,int w){
	e[++cnt].to=v;
	e[cnt].flow=w;
	e[cnt].next=head[u];
	head[u]=cnt;
}

void inpt(){
	n=v_in(),m=v_in();
	fr(i,1,m){
		int u=v_in(),v=v_in();
		add(u,v,1),add(v,u,1);
		c[u]++,c[v]++;
	}
	MAXN=cnt*2;
}

int csap(int u,int ed,int flow){
	if(u==ed) return flow;
	int res=flow;
	travel(i,u,v) if(d[u]==d[v]+1&&e[i].flow){
		int t=csap(v,ed,fmin(res,e[i].flow));
		e[i].flow-=t;
		e[i^1].flow+=t;
		res-=t;
		if(!res) return flow;
	}
	gap[d[u]]--;
	if(!gap[d[u]]) flag=true;
	d[u]++;
	gap[d[u]]++;
	return flow-res;
}

int sap(int st,int ed){
	memset(d,0,sizeof d);
	memset(gap,0,sizeof gap);
	fr(i,1,cnt) e[i].flow=ne[i];
	gap[0]=n;
	int ans=0;
	flag=false;
	while(d[st]<n&&!flag){
		int cc=csap(st,ed,MAXN);
		ans+=cc;
	}
	return ans;
}

int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	inpt();
	int ans=m;
	fr(i,1,cnt) ne[i]=e[i].flow;
	if(n==m+1){
		printf("1\n");
		return 0;
	}
	ans=c[1];
	fr(i,2,n) ans=fmin(ans,c[i]);
	fr(i,2,n){
		int cc=sap(1,i);
		ans=fmin(ans,cc);
	}
	printf("%d\n",ans);
	return 0;
}
/*
5 7
1 2
2 3
3 4
4 5
5 1
2 4
1 3
*/
