#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 310, M = 1010;

int n, m, ans;
int G[N][N], deg[N];

struct Dinic {
	
	int Begin[N], Next[M << 1], to[M << 1], flow[M << 1], cap[M << 1], e;

	Dinic() { e = 1; }

	void add(int u, int v, int f) {
		to[++e] = v, Next[e] = Begin[u], Begin[u] = e, cap[e] = flow[e] = f;
		to[++e] = u, Next[e] = Begin[v], Begin[v] = e, cap[e] = flow[e] = f;
	}

	void reset() {
		For(i, 2, e) flow[i] = cap[i];
	}

	int dis[N];
	int S, T;

	bool BFS() {
		For(i, 1, n) dis[i] = 0;
		queue<int> q;
		dis[S] = 1, q.push(S);
		while (!q.empty()) {
			int o = q.front(); q.pop();
			for (int i = Begin[o]; i; i = Next[i]) {
				int u = to[i];
				if (!flow[i] || dis[u]) continue;
				dis[u] = dis[o] + 1, q.push(u);
			}
		}
		return dis[T];
	}

	int cur[N];

	int DFS(int o, int maxf) {
		if (o == T || !maxf) return maxf;
		int sumf = 0;
		for (int &i = cur[o]; i; i = Next[i]) {
			int u = to[i], f;
			if (dis[u] == dis[o] + 1 && (f = DFS(u, min(maxf, flow[i])))) {
				flow[i] -= f, flow[i ^ 1] += f;
				maxf -= f, sumf += f;
			}
			if (!maxf) break;
		}
		return sumf;
	}

	int Mincut(int s, int t) {
		reset();
		S = s, T = t;
		int ret = 0;
		while (BFS() && ret < ans) {
			For(i, 1, n) cur[i] = Begin[i];
			ret += DFS(S, ans - ret);
		}
		return ret;
	}

}F;

int main() {

	freopen("connection.in", "r", stdin);
	freopen("connection.out", "w", stdout);

	scanf("%d%d", &n, &m);
	ans = m; 
	For(i, 1, m) {
		int u, v;
		scanf("%d%d", &u, &v);
		G[u][v]++, G[v][u]++;
		++deg[u], ++deg[v];
	}
	For(i, 1, n) ans = min(ans, deg[i]);
	For(i, 1, n) For(j, i + 1, n) if (G[i][j]) F.add(i, j, G[i][j]);
	For(i, 1, n) For(j, i + 1, n) if (G[i][j])
		ans = min(ans, F.Mincut(i, j));
	printf("%d\n", ans);

	return 0;
}
