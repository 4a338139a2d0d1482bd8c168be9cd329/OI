#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 22;

int G[N][N];

int main() {

	freopen("connection.in", "r", stdin);
	freopen("connection.ans", "w", stdout);

	int n, m;
	scanf("%d%d", &n, &m);
	--n;
	For(i, 1, m) {
		int u, v;
		scanf("%d%d", &u, &v);
		--u, --v;
		G[u][v]++, G[v][u]++;
	}

	int ans = m;
	For(i, 1, (1 << n) - 1) {
		int tot = 0;
		For(j, 0, n) if (i & (1 << j))
			For(k, 0, n) if (!(i & (1 << k)))
				tot += G[j][k];
		ans = min(ans, tot);
	}
	printf("%d\n", ans);

	return 0;
}
