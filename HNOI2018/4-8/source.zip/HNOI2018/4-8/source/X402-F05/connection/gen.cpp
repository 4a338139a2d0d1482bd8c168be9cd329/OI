#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("connection.in", "w", stdout);

	srand(time(0));

	int n = 21, m = 1000;
	printf("%d %d\n", n, m);

	int x = randint(2, n - 2);
	while (m--) {
		int t = rand() % 100;
		if (t <= 3) printf("%d %d\n", randint(1, x), randint(x, n));
		else {
			int v;
			if (t <= 51) t = randint(1, x), v = randint(1, x - 1);
			else t = randint(x + 1, n), v = randint(x + 1, n - 1);
			if (v >= t) ++v;
			printf("%d %d\n", t, v);
		}
	}

	return 0;
}
