#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 2e5 + 10;

int Begin[N], Next[N], to[N], e;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n = 1e4, q = 1e4, m;
int eu[N], ev[N];

void DFS(int o, int top) {
	if (top != o && (rand() % 4 == 0 || !Begin[o])) {
		eu[++m] = o, ev[m] = top;
		top = o;
	}
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		DFS(u, top);
		top = o;
	}
}

int main() {

	freopen("map.in", "w", stdout);

	srand(time(0));

	For(i, 1, n - 1) add(eu[i] = max(1, i - rand() % 10), ev[i] = i + 1);
	m = n - 1;
	DFS(1, 1);

	printf("%d %d\n", n, m);
	For(i, 1, n) printf("%d%c", 
			rand() % 2 ? rand() % n + 1 : rand() % (n / 200) * 50 + 1, 
			i == n ? '\n' : ' ');
	For(i, 1, m) printf("%d %d\n", eu[i], ev[i]);
	printf("%d\n", q);
	For(i, 1, q) printf("%d %d %d\n", rand() % 2, rand() % n + 1, rand() % n + 1);

	return 0;
}
