#include <bits/stdc++.h>

#define pb push_back
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;
const int Mx = 1e6;

int Begin[N], Next[N << 2], to[N << 2], e = 1;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n, m;
bool vis[N];
int cnt[N], A[N];

void DFS(int o, int ban) {
	if (o == ban) return;
	vis[o] = true;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (vis[u]) continue;
		DFS(u, ban);
	}
}

int main() {

	freopen("map.in", "r", stdin);
	freopen("map.ans", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%d", &A[i]);
	For(i, 1, m) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}

	int q;
	scanf("%d", &q);
	For(j, 1, q) {
		int ty, x, y;
		For(i, 1, n) vis[i] = 0, cnt[i] = 0;
		scanf("%d%d%d", &ty, &x, &y);
		DFS(1, x);
		For(i, 1, n) if (!vis[i]) cnt[A[i]]++;
		int ans = 0;
		For(i, 1, y) if (cnt[i] && cnt[i] % 2 == ty) ++ans;
		printf("%d\n", ans);

	}
	
	return 0;
}
