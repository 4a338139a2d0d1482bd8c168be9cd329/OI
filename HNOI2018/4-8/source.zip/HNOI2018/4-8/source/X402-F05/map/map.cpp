#include <bits/stdc++.h>

#define pb push_back
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;
const int Mx = 1e6;

int Begin[N], Next[N << 2], to[N << 2], e = 1;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n, m;
int A[N];
vector<int> G[N];

int dfn[N], low[N], clk;
int st[N], p;

void DFS_bcc(int o, int fa = 0) {
	low[o] = dfn[o] = ++clk;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == fa) continue;
		if (!dfn[u]) {
			st[++p] = i;
			DFS_bcc(u, o);
			if (low[u] >= dfn[o]) {
				while (st[p] != i) G[o].pb(to[st[p]]), --p;
				G[o].pb(u), --p;
			} else {
				low[o] = min(low[o], low[u]);
			}
		} else {
			low[o] = min(low[o], dfn[u]);
		}
	}
	// for (int v : G[o]) printf("(%d, %d)\n", o, v);
	// printf("%d %d %d\n", o, low[o], dfn[o]);
}

struct Segment_Tree {
	
	const static int NODE = N * 22;

	int c[NODE][2], lc[NODE], rc[NODE], node;
	
	#define M ((L + R) >> 1)

	void pushup(int o) {
		c[o][0] = c[lc[o]][0] + c[rc[o]][0];
		c[o][1] = c[lc[o]][1] + c[rc[o]][1];
	}

	void insert(int &o, int L, int R, int x) {
		if (!o) o = ++node;
		if (L == R) {
			if (!c[o][0] && !c[o][1]) ++c[o][1];
			else swap(c[o][0], c[o][1]);
		} else {
			x <= M ? insert(lc[o], L, M, x) : insert(rc[o], M + 1, R, x);
			pushup(o);
		}
	}

	int merge(int x, int y, int L, int R) {
		if (!x) return y;
		if (!y) return x;
		if (L == R) {
			int u = c[x][1] ^ c[y][1];
			c[x][u] = 1, c[x][u ^ 1] = 0;
		} else {
			lc[x] = merge(lc[x], lc[y], L, M);
			rc[x] = merge(rc[x], rc[y], M + 1, R);
			pushup(x);
		}
		return x;
	}

	int query(int o, int L, int R, int l, int r, int t) {
		if (l <= L && R <= r) return c[o][t];
		else {
			int ret = 0;
			if (l <= M) ret += query(lc[o], L, M, l, r, t);
			if (r > M) ret += query(rc[o], M + 1, R, l, r, t);
			return ret;
		}
	}

}T;

int ans[N], root[N];

struct Query {
	int lim, ty, id;
};

vector<Query> Q[N];

void DFS_work(int o) {
	int sz = int(G[o].size()) - 1;
	T.insert(root[o], 1, Mx, A[o]);
	For(i, 0, sz) {
		int u = G[o][i];
		DFS_work(u);
		T.merge(root[o], root[u], 1, Mx);
	}
	sz = int(Q[o].size()) - 1;
	For(i, 0, sz) {
		Query s = Q[o][i];
		ans[s.id] = T.query(root[o], 1, Mx, 1, s.lim, s.ty);
	}
}

int main() {

	freopen("map.in", "r", stdin);
	freopen("map.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%d", &A[i]);
	For(i, 1, m) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}
	DFS_bcc(1);

	int q;
	scanf("%d", &q);
	For(i, 1, q) {
		int ty, x, y;
		scanf("%d%d%d", &ty, &x, &y);
		Q[x].pb((Query){y, ty, i});
	}
	DFS_work(1);
	For(i, 1, q) printf("%d\n", ans[i]);
	
	return 0;
}
