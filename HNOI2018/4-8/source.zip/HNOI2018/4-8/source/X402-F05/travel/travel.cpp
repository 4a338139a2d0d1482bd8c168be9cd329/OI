#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (register int i = j; i <= k; ++i)

using namespace std;

int Read() {
	char c = getchar();
	while (c > '9' || c < '0') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int Mod = 1e4 + 7;
const int N = 1e5 + 10, C = 21;

int n, m, q;
int A[N], B[N];

struct Segment_Tree {

	int ans[N << 2][C << 1];

	#define lc (o << 1)
	#define rc (o << 1 | 1)
	#define M ((L + R) >> 1)

	void pushup(int o, int L, int R) {
		int r = min(R - M, m), l = min(M - L + 1, m);
		int *ret = ans[o], *f = ans[lc], *g = ans[rc];
		For(i, 0, l + r) ret[i] = 0;
		For(i, 0, l) For(j, 0, r) ret[i + j] += f[i] * g[j];
		For(i, 0, l + r) ret[i] %= Mod;
		For(i, m + 1, l + r) ret[m] += ret[i];
		ret[m] %= Mod;
	}

	void build(int o, int L, int R) {
		if (L == R) {
			ans[o][0] = B[L], ans[o][1] = A[L];
		} else {
			build(lc, L, M), build(rc, M + 1, R);
			pushup(o, L, R);
		}
	}

	void modify(int o, int L, int R, int x) {
		if (L == R) {
			ans[o][0] = B[L], ans[o][1] = A[L];
		} else {
			x <= M ? modify(lc, L, M, x) : modify(rc, M + 1, R, x);
			pushup(o, L, R);
		}
	}

}T;

int main() {

	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);

	n = Read(), m = Read();
	For(i, 1, n) A[i] = Read() % Mod;
	For(i, 1, n) B[i] = Read() % Mod;
	T.build(1, 1, n);
	
	q = Read();
	while (q--) {
		int x = Read();
		A[x] = Read() % Mod, B[x] = Read() % Mod;
		T.modify(1, 1, n, x);
		printf("%d\n", T.ans[1][m]);
	}

	return 0;
}
