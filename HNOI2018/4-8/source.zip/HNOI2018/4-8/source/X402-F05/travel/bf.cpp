#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int Mod = 1e4 + 7;
const int N = 1e5 + 10, C = 21;

int n, m, q;
int A[N], B[N];
int dp[N][C];

int main() {

	freopen("travel.in", "r", stdin);
	freopen("travel.ans", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%d", &A[i]), A[i] %= Mod;
	For(i, 1, n) scanf("%d", &B[i]), B[i] %= Mod;
	
	scanf("%d", &q);
	while (q--) {
		int x;
		scanf("%d", &x);
		scanf("%d%d", &A[x], &B[x]);
		A[x] %= Mod, B[x] %= Mod;

		dp[0][0] = 1;
		For(i, 1, n) {
			For(j, 0, m) dp[i][j] = 0;
			For(j, 0, m) {
				(dp[i][min(j + 1, m)] += A[i] * dp[i - 1][j]) %= Mod;
				(dp[i][j] += B[i] * dp[i - 1][j]) %= Mod;
			}
		}
		printf("%d\n", dp[n][m]);

	}

	return 0;
}
