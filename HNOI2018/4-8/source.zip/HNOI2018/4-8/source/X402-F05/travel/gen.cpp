#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int main() {

	freopen("travel.in", "w", stdout);

	srand(time(0));
	int n = 70363, m = 20, q = 100;

	printf("%d %d\n", n, m);
	For(i, 1, n) printf("%d%c", rand(), i == n ? '\n' : ' ');
	For(i, 1, n) printf("%d%c", rand(), i == n ? '\n' : ' ');
	printf("%d\n", q);
	while (q--) {
		int x = rand() % n + 1;
		printf("%d %d %d\n", x, rand(), rand());
	}

	return 0;
}
