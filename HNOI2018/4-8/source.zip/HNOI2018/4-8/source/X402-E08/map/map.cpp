# include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("map.in", "r", stdin);
	freopen ("map.out", "w", stdout);
}

int n, m;

const int N = 1010, M = 1510 << 1;
int Head[N], Next[M], to[M], Ban[M], e = 1;
void add_edge(int u, int v) { to[++ e] = v; Next[e] = Head[u]; Ban[e] = false; Head[u] = e; }
void Add(int u, int v) { add_edge(u, v); add_edge(v, u); }

bitset<N> vis;
void Dfs(int u) {
	if (vis[u]) return ; vis[u] = true;
	for (int i = Head[u]; i; i = Next[i]) if (!Ban[i]) Dfs(to[i]);
}

int maxcol;
int val[N], App[1001000];

int main () {
	File();
	n = read(); m = read();
	For (i, 1, n) { val[i] = read(); chkmax(maxcol, val[i]); }
	For (i, 1, m) { int u = read(), v = read(); Add(u, v); }
	int q = read();
	For (i, 1, q) {
		int ty = read(), x = read(), y = read();
		for (int i = Head[x]; i; i = Next[i]) Ban[i] = Ban[i ^ 1] = true;
		vis.reset(); Dfs(1); if (x == 1) vis[1] = false;
		For (i, 1, n) if (!vis[i]) ++ App[val[i]];
		int res = 0;
	//	For (i, 1, maxcol) if (App[i]) printf ("App[%d] = %d;\n", i, App[i]);

		For (i, 1, maxcol) if (App[i] && App[i] <= y) 
			if ((ty && (App[i] & 1)) || (!ty && !(App[i] & 1))) ++ res;
		printf ("%d\n", res);

		For (i, 1, n) if (!vis[i]) -- App[val[i]];
		for (int i = Head[x]; i; i = Next[i]) Ban[i] = Ban[i ^ 1] = false;
	}
    return 0;
}
