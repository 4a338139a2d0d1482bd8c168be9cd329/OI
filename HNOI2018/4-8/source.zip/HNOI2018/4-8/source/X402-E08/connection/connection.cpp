#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("connection.in", "r", stdin);
	freopen ("connection.out", "w", stdout);
}

const int N = 310, M = 1010 << 1, inf = 0x3f3f3f3f;

struct Isap {
	int Next[M], Head[N], to[M], cap[M], e;
	void add_edge(int u, int v, int flow) { to[++ e] = v; Next[e] = Head[u]; cap[e] = flow; Head[u] = e; }
	void Add(int u, int v, int flow) { add_edge(u, v, flow); add_edge(v, u, 0); }

	int gap[N], d[N], S, T, n;
	int Dfs(int u, int flow) {
		if (u == T) return flow;
		int res = flow, f;
		for (int i = Head[u]; i; i = Next[i]) {
			int v = to[i];
			if (cap[i] && d[u] == d[v] + 1) {
				f = Dfs(v, min(res, cap[i]));
				cap[i] -= f; cap[i ^ 1] += f;
				if (!(res -= f)) return flow;
			}
		}
		if (!(-- gap[d[u]])) d[S] = n;
		++ gap[++ d[u]];
		return flow - res;
	}

	int Run() {
		int sum_flow = 0;
		for (gap[0] = n + 1; d[S] < n;)
			sum_flow += Dfs(S, inf);
		return sum_flow;
	}

	void Init(int n, int S, int T) { 
		this -> n = n; this -> S = S; this -> T = T; 
		e = 1; Set(Head, 0); Set(d, 0);
	}
} F;

int n, m, ans = inf;
struct Edge { int u, v; } lt[M];

int Calc(int Cut) {
	F.Init(n, n + 1, Cut);
	For (i, 1, n) if (i != Cut) F.Add(F.S, i, inf);
	For (i, 1, m) { int u = lt[i].u, v = lt[i].v; F.Add(u, v, 1); F.Add(v, u, 1); }
	return F.Run();
}

int main () {
	File();
	n = read(); m = read();
	For (i, 1, m) { int u = read(), v = read(); lt[i].u = u, lt[i].v = v; }

	For (i, 1, n)
		chkmin(ans, Calc(i));
	
	printf ("%d\n", ans);
	return 0;
}
