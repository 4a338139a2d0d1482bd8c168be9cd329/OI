#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), i##end = (int)(r); i <= i##end; ++i)
#define Fordown(i, r, l) for(register int i = (r), i##end = (int)(l); i >= i##end; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar()) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar()) x = (x * 10) + (ch ^ 48);
    return x * fh;
}

void File() {
	freopen ("travel.in", "r", stdin);
	freopen ("travel.out", "w", stdout);
}

const int Mod = 10007, N = 1e5 + 1e3;

int a[N], b[N], n, c;
#define lson o << 1, l, mid
#define rson o << 1 | 1, mid + 1, r
struct Segment_Tree {
	int dp[21][N << 2];

	inline void push_up(int o) {
		int ls = o << 1, rs = ls | 1;
		For (i, 0, c) dp[i][o] = 0;
		For (i, 0, c) For (j, 0, c)
			(dp[min(i + j, c)][o] += dp[i][ls] * dp[j][rs]) %= Mod;
	}

	void Build(int o, int l, int r) {
		if (l == r) { dp[0][o] = b[l], dp[1][o] = a[l]; return ; }
		int mid = (l + r) >> 1; Build(lson); Build(rson); push_up(o);
	}

	void Update(int o, int l, int r, int up) {
		if (l == r) { dp[0][o] = b[l], dp[1][o] = a[l]; return ; }
		int mid = (l + r) >> 1; if (up <= mid) Update(lson, up); else Update(rson, up); push_up(o);
	}
} T;

int main () {
	File();
	n = read(); c = read();
	For (i, 1, n) a[i] = read() % Mod;
	For (i, 1, n) b[i] = read() % Mod;
	T.Build(1, 1, n);
	int m = read();
	while (m --) {
		int pos = read();
		a[pos] = read() % Mod;
		b[pos] = read() % Mod;
		T.Update(1, 1, n, pos);
		printf ("%d\n", T.dp[c][1]);
	}
    return 0;
}
