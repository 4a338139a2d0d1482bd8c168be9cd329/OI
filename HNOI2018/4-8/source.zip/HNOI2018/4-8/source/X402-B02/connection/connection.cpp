#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#define NODES(i,h,a,b) for(int i=a[h]; i!=-1; i=b[i])
#define CURS(i,h,a,b) for(int &i=a[h]; i!=-1; i=b[i])
#define REP(i,a,b) for(int i=a; i<=b; ++i)
#define Q inline 
#define SET(A,B) memset(A,B,sizeof(A))
using namespace std;
const int N = 2000 + 100; 
const int E = 400 + 10;
int bgn[E], to[N<<1], level[E], pre[N<<1], cur[N], nxt[N<<1], w[N<<1], e, S, T;
int deg[N], gap[E], n, m, c[N];

struct node{
		int x,y;
};
struct node p[N];

namespace Net {
		void add(int x,int y,int z) {to[e] = y; w[e] = z; nxt[e] = bgn[x]; bgn[x] = e++;}
		void add_net(int x,int y,int z) {add(x,y,z); add(y,x,0);}
		int ckmn(int x,int y) {return x<y?x:y;}
		int mxflow(int N){
				int u; u=pre[S]=S; 
				int ang=-1,aans=0;
				while(level[S]<N){						
						int flag = 0;
						CURS(i,u,cur,nxt){
								int v=to[i];
								if(w[i] && level[u]==level[v]+1){
										flag = 1;
										if(ang==-1) ang=w[i]; else ang=ckmn(ang,w[i]); 
										pre[v]=u;u=v; 
										if(v==T){
												aans+=ang;
												for(u=pre[v]; v!=S; v=u,u=pre[v]) w[cur[u]]-=ang,w[cur[u]^1]+=ang;
												ang=-1;    
										}
										flag=1; break; 
								} 
						}
						if(flag) continue; int mn_level=N; int mn_i;
						NODES(i,u,bgn,nxt){
								int y=to[i];
								if(w[i] && level[y]<mn_level) {mn_level=level[y]; cur[u]=i;}
						}
						if(!(--gap[level[u]])) break;
						gap[(level[u]=mn_level+1)]++;
						u=pre[u];  
				}
				return aans;
		}
		void run(){
				int x,y,z;
				scanf("%d%d",&n,&m);
				for(int i=1; i<=m; ++i){
						scanf("%d%d",&p[i].x,&p[i].y);
						deg[p[i].x]++;
						deg[p[i].y]++;
				}	
			
				int ans=0x3f3f3f3f;
				for(int i=1; i<=n; ++i) ans=min(ans,deg[i]);

				S=n+1; T=n+2;
				for(int tt=2; tt<=n; ++tt){
						SET(bgn,-1);SET(pre,-1);
						SET(cur,-1);SET(level,0);SET(gap,0);
						for(int j=0;j<=T;++j)cur[j]=bgn[j];
						e=0;
						add_net(S,1,0x3f3f3f3f);
						add_net(tt,T,0x3f3f3f3f);
						for(int j=1; j<=m; ++j){
								add_net(p[j].x,p[j].y,1);
								add_net(p[j].y,p[j].x,1);
						}
						for(int j=0; j<=T; ++j) cur[j]=bgn[j];
						ans=min(ans,mxflow(T+2));
				}
				printf("%d\n",ans);
		}
}
using namespace Net; 
int main(){
		freopen("connection.in","r",stdin);
		freopen("connection.out","w",stdout);
		run();
}
