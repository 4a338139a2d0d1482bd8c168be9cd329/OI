#include<bits/stdc++.h>
#define mo mod
#define ll long long
const int N=74010;
const int C=10;
const int E=12;
const int N1=1e3+10;
const int mod=10007;
using namespace std;
int n,m,c;
int aa[N],b[N],f[N1][20];

int flag=0;
struct mat{
	int m[C][C];
	inline void clear() {memset(m,0,sizeof(m));}
	inline void init(){
		clear();
		m[0][0]=1;
	}
	void print(){
		for(int i=0; i<c; ++i){
			for(int j=0; j<c; ++j)
				printf("%d ",m[i][j]);
			puts("");
		}
	}
} Ret;

inline mat mul(mat A,mat B){
	mat C; C.clear();
	for(int i=0; i<c; ++i) 
		for(int j=0; j<c; ++j) if(A.m[i][j])
			for(int k=0; k<c; ++k) if(B.m[j][k]){
				C.m[i][k]+=A.m[i][j]*B.m[j][k]%mo;
				C.m[i][k]%=mo;
			}
	return C;
}
namespace segm{
	#define l(x) (x<<1)
	#define r(x) ((x<<1)|1)
	struct mat a[N<<2];
	void upd(int x,int l,int r,int p,int vx,int vy){
		int mm=(l+r)>>1;
		if(l==r){
			for(int i=0; i<c; ++i){
				a[x].m[i][i]=vy;
				if(i!=c-1) a[x].m[i][i+1]=vx;
			}
		}
		else{
			if(p<=mm) upd(l(x),l,mm,p,vx,vy);
			     else upd(r(x),mm+1,r,p,vx,vy);
			a[x]=mul(a[l(x)],a[r(x)]);
		}
	}
	void init(int x,int l,int r){
		int mm=(l+r)>>1;
		if(l==r){
			for(int i=0; i<c; ++i){
				a[x].m[i][i]=b[l];
				if(i!=c-1) a[x].m[i][i+1]=aa[l];
			}
		}
		else{
			init(l(x),l,mm);init(r(x),mm+1,r);
			a[x]=mul(a[l(x)],a[r(x)]);
		}	
	}
}

namespace travel{
	inline int fpm(int x,int y){
		int s=1;
		while(y){
			if(y&1) s=1ll*s*x%mod;
			y>>=1; x=1ll*x*x%mod;
		}
		return s;
	}
	inline int rev(int x){
		return fpm(x,mod-2);
	}
	void solve(){
		freopen("travel.in", "r", stdin);
		freopen("travel.out", "w", stdout);
		scanf("%d%d",&n,&c);
		for(int i=1; i<=n; ++i) scanf("%d",&aa[i]);
		for(int i=1; i<=n; ++i) scanf("%d",&b[i]);
		int ans=1;
		for(int i=1; i<=n; ++i) ans=1ll*ans*(aa[i]+b[i])%mo;
		
		if(n<N1); else segm::init(1,1,n);
		int x,y,z;
		scanf("%d",&m);
	
		if(n<N1){
			for(int T=1; T<=m; ++T){
				scanf("%d%d%d",&x,&y,&z);
				ans=1ll*ans*rev(aa[x]+b[x])%mo; 
				aa[x]=y; b[x]=z;
				ans=1ll*ans*(aa[x]+b[x])%mo;
				f[0][0]=1;
				for(int i=1; i<=n; ++i){
					for(int j=0; j<c; ++j){
						f[i][j]=0;
						if(j)f[i][j]+=f[i-1][j-1]*aa[i]%mo;
						f[i][j]+=f[i-1][j]*b[i]%mo;
						f[i][j]%=mo;
						}
				}
				for(int j=0; j<c; ++j) ans=(ans-f[n][j]+mo)%mo;
				printf("%d\n",ans);
			}
		}
	
		else{
			for(int T=1; T<=m; ++T){
				scanf("%d%d%d",&x,&y,&z);
				ans=1ll*ans*rev(aa[x]+b[x])%mo; 
				aa[x]=y; b[x]=z;
				ans=1ll*ans*(aa[x]+b[x])%mo;
				segm::upd(1,1,n,x,aa[x],b[x]);
				Ret.init();
				Ret=mul(Ret,segm::a[1]);
				for(int j=0; j<c; ++j) ans=(ans-Ret.m[0][j]+mo)%mo;
				printf("%d\n",ans);
			}
		}
	}
}

int main(){
	travel::solve();
}
