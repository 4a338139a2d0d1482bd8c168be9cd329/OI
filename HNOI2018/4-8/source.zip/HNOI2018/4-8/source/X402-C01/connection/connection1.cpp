/************************************************
 * Au: Hany01
 * Prob: connection
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define x first
#define y second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

const int maxn = 305, maxm = 1005;

struct Edge
{
	int u, v;
}E[maxm];

int n, m, fa[maxn], sz[maxn], vis[maxn], flag, dep;

int find(int x) { return fa[x] == x ? x : fa[x] = find(fa[x]); }

void check()
{
	For(i, 1, n) fa[i] = i, sz[i] = 1;
	For(i, 1, m) if (!vis[i])
	{
		int fu = find(E[i].u), fv = find(E[i].v);
		if (fu != fv)
		{
			fa[fv] = fu;
			sz[fu] += sz[fv];
			if (sz[fu] == n) return ;
		}
	}
	flag = 1;
}

void dfs(int cur, int now)
{
	if (cur == dep) {
		check();
		return ;
	}

	For(i, now, m)
	{
		vis[i] = 1;
		dfs(cur + 1, i + 1);
		if (flag) return ;
		vis[i] = 0;
	}
}

int main()
{
	freopen("connection.in", "r", stdin);
	freopen("connection1.out", "w", stdout);

	n = read(), m = read();
	For(i, 1, m) E[i].u = read(), E[i].v = read();

	for (dep = 0; dep <= m; ++ dep) {
		dfs(0, 1);
		if (flag) break;
	}

	printf("%d\n", dep);

    return 0;
}
