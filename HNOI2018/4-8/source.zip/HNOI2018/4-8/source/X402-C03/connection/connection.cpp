#include<bits/stdc++.h>
using namespace std;

const int maxn=1e3+10;
int n,m,ans,xxx[maxn];
int x[maxn][maxn];
bool vis[maxn];
pair<int,int> e[maxn];
vector<int> g[maxn];

inline void chkmin(int&a,int b){
	if(a>b)a=b;
}
int f(int pos){
	int res=0;
	for(int i=pos;i<=n;++i){
		int a=0,b=0;
		for(int j=1;j<pos;++j)
			if(vis[j])
				a+=x[i][j];
			else
				b+=x[i][j];
		res+=a<=b?a:b;
	}
	return res;
}
void dfs(int pos,int now,bool flag){
	if(now+f(pos)>=ans)
		return;
	if(pos>n){
		if(flag)
			ans=now;
		return;
	}
	{
		int more=0;
		for(int i=1;i<pos;++i)
			if(vis[i])
				more+=x[pos][i];
		vis[pos]=false;
		dfs(pos+1,now+more,flag);
	}
	{
		int more=0;
		for(int i=1;i<pos;++i)
			if(!vis[i])
				more+=x[pos][i];
		vis[pos]=true;
		dfs(pos+1,now+more,true);
	}
}

int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	srand(time(NULL));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		xxx[i]=i;
	random_shuffle(xxx+1,xxx+n+1);
	if(n==2){
		printf("%d\n",m);
		return 0;
	}
	for(int i=1;i<=m;++i){
		scanf("%d%d",&e[i].first,&e[i].second);
		e[i].first=xxx[e[i].first];
		e[i].second=xxx[e[i].second];
		g[e[i].first].push_back(e[i].second);
		g[e[i].second].push_back(e[i].first);
		++x[e[i].first][e[i].second];
		++x[e[i].second][e[i].first];
	}
	ans=m;
	for(int i=1;i<=n;++i)
		chkmin(ans,g[i].size());
	for(int i=1;i<=m;++i)
		chkmin(ans,g[e[i].first].size()+g[e[i].second].size()-2*x[e[i].first][e[i].second]);
	dfs(2,0,false);
	printf("%d\n",ans);
	return 0;
}
