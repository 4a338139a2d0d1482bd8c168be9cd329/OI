#include<bits/stdc++.h>
using namespace std;

const int maxn=300+10,maxm=1e3+10;
int n,m,ans;
pair<int,int> e[maxm];
vector<int> g[maxn];

namespace bf{
	bool vis[maxn];
	void dfs(int pos,int s,int t){
		if(pos>n){
			if(!s||!t)return;
			int res=0;
			for(int i=1;i<=n;++i)
				if(vis[i])
					for(int j=0;j<g[i].size();++j)
						if(!vis[g[i][j]])
							++res;
			if(ans>res)
				ans=res;
			return;
		}
		vis[pos]=true;
		dfs(pos+1,s+1,t);
		vis[pos]=false;
		dfs(pos+1,s,t+1);
	}
	int main(){
		dfs(1,0,0);
		printf("%d\n",ans);
	}
}

int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i){
		scanf("%d%d",&e[i].first,&e[i].second);
		g[e[i].first].push_back(e[i].second);
		g[e[i].second].push_back(e[i].first);
	}
	ans=m;
	bf::main();
	return 0;
}
