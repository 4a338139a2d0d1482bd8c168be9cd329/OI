#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+10;
int n,m,q,a[maxn];
vector<int> g[maxn];
bool vis[maxn];

int main(){
	freopen("map.in","r",stdin);
	freopen("map.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1,u,v;i<=m;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	scanf("%d",&q);
	while(q--){
		int ty,x,y,res=0;
		scanf("%d%d%d",&ty,&x,&y);
		for(int i=1;i<=n;++i)
			vis[i]=0;
		if(x!=1){
			queue<int> q;
			q.push(1);
			vis[1]=true;
			while(!q.empty()){
				int pos=q.front();q.pop();
				for(int i=0;i<g[pos].size();++i)
					if(!vis[g[pos][i]]&&g[pos][i]!=x){
						vis[g[pos][i]]=true;
						q.push(g[pos][i]);
					}
			}
		}
		map<int,bool> mp;
		for(int i=1;i<=n;++i)
			if(!vis[i]&&a[i]<=y)
				mp[a[i]]^=1;
		for(map<int,bool>::iterator i=mp.begin();i!=mp.end();++i)
			if(i->second==ty)
				++res;
		printf("%d\n",res);
	}
	return 0;
}
