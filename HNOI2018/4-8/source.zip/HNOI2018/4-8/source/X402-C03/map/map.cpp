#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while(!isdigit(c=getchar()));
	x=c-48;
	while(isdigit(c=getchar()))x=x*10+c-48;
	return x;
}

const int maxn=1e5+10;
int n,m,qn,a[maxn],ans[maxn];

namespace splay{
	int root[maxn];
	int fa[maxn],ch[maxn][2],odd[maxn],even[maxn],key[maxn];
	bool oe[maxn];
	inline void init(int pos,int a){
		key[pos]=a;
		oe[pos]=true;
		odd[pos]=1;
	}
	inline void push_up(int rt){
		odd[rt]=odd[ch[rt][0]]+odd[ch[rt][1]]+(oe[rt]==true);
		even[rt]=even[ch[rt][0]]+even[ch[rt][1]]+(oe[rt]==false);
	}
	inline void rotate(int pos){
		int f=fa[pos],ff=fa[f];
		if(ff)
			ch[ff][ch[ff][1]==f]=pos;
		bool tmp=ch[f][1]==pos;
		ch[f][tmp]=ch[pos][tmp^1];
		fa[ch[f][tmp]]=f;
		ch[pos][tmp^1]=f;
		fa[f]=pos;
		fa[pos]=ff;
		push_up(f);
		push_up(pos);
	}
	inline void splay(int&rt,int pos){
		while(fa[pos]){
			int f=fa[pos],ff=fa[f];
			if(ff)
				if((ch[ff][1]==f)==(ch[f][1]==pos))
					rotate(f);
				else
					rotate(pos);
			rotate(pos);
		}
		rt=pos;
	}
	inline int upper_bound(int&rt,int y){
		int p=rt,res=0;
		while(p)
			if(key[p]>y)
				res=p,p=ch[p][0];
			else
				p=ch[p][1];
		return res;
	}
	inline void insert(int&rt,int pos){
		if(!rt){
			rt=pos;
			return;
		}
		int p=rt;
		while(true)
			if(key[p]==key[pos]){
				if(oe[pos])
					oe[p]^=1;
				pos=p;
				push_up(pos);
				break;
			}
			else if(key[p]>key[pos]){
				if(ch[p][0])
					p=ch[p][0];
				else{
					ch[p][0]=pos;
					fa[pos]=p;
					break;
				}
			}
			else{
				if(ch[p][1])
					p=ch[p][1];
				else{
					ch[p][1]=pos;
					fa[pos]=p;
					break;
				}
			}
		splay(rt,pos);
	}
	void merge(int&rt,int pos){
		if(ch[pos][0]){
			fa[ch[pos][0]]=0;
			merge(rt,ch[pos][0]);
		}
		int tmp=ch[pos][1];
		ch[pos][0]=0;
		ch[pos][1]=0;
		push_up(pos);
		insert(rt,pos);
		if(tmp){
			fa[tmp]=0;
			merge(rt,tmp);
		}
	}
	inline int query(int&rt,int ty,int y){
		int pos=upper_bound(rt,y);
		if(!pos)
			if(ty)
				return odd[rt];
			else
				return even[rt];
		splay(rt,pos);
		if(ty)
			return odd[ch[pos][0]];
		else
			return even[ch[pos][0]];
	}
}
namespace tree_merge{
	struct quest{
		int id,ty,y;
	};
	vector<quest> q[maxn];
	vector<int> g[maxn];
	int size[maxn],son[maxn];
	inline void ae(int u,int v){
		g[u].push_back(v);
	}
	void dfs(int pos){
		size[pos]=1;
		for(int i=0;i<g[pos].size();++i){
			dfs(g[pos][i]);
			size[pos]+=size[g[pos][i]];
			if(size[g[pos][i]]>size[son[pos]])
				son[pos]=g[pos][i];
		}
	}
	void merge(int pos){
		if(son[pos]){
			merge(son[pos]);
			splay::root[pos]=splay::root[son[pos]];
			for(int i=0;i<g[pos].size();++i)
				if(g[pos][i]!=son[pos]){
					merge(g[pos][i]);
					splay::merge(splay::root[pos],splay::root[g[pos][i]]);
				}
		}
		splay::init(pos,a[pos]);
		splay::merge(splay::root[pos],pos);
		for(int i=0;i<q[pos].size();++i)
			ans[q[pos][i].id]=splay::query(splay::root[pos],q[pos][i].ty,q[pos][i].y);
	}
	inline int solve(){
		dfs(1);
		qn=read();
		for(int i=1;i<=qn;++i){
			int ty=read(),x=read(),y=read();
			q[x].push_back((quest){i,ty,y});
		}
		merge(1);
		for(int i=1;i<=qn;++i)
			printf("%d\n",ans[i]);
	}
}
namespace original_graph{
	const int maxm=1.5e5+10;
	int dfn,pre[maxn],low[maxn],top;
	int ecnt=1,ebeg[maxn],eto[maxm<<1],enxt[maxm<<1];
	pair<int,int> stk[maxm];
	inline void ae(int u,int v){
		++ecnt;
		enxt[ecnt]=ebeg[u];
		ebeg[u]=ecnt;
		eto[ecnt]=v;
	}
	void dfs(int pos,int fa){
		pre[pos]=low[pos]=++dfn;
		for(int i=ebeg[pos];i;i=enxt[i])
			if(i!=fa)
				if(!pre[eto[i]]){
					stk[top++]=make_pair(pos,eto[i]);
					dfs(eto[i],i^1);
					if(low[eto[i]]>pre[pos]){
						--top;
						tree_merge::ae(pos,eto[i]);
					}
					else if(low[eto[i]]>=pre[pos])
						while(stk[--top].first!=pos)
							tree_merge::ae(pos,stk[top].first);
					if(low[eto[i]]<low[pos])
						low[pos]=low[eto[i]];
				}
				else if(pre[eto[i]]<pre[pos]){
					stk[top++]=make_pair(pos,eto[i]);
					if(pre[eto[i]]<low[pos])
						low[pos]=pre[eto[i]];
				}
	}
	inline void work(){
		for(int i=1,u,v;i<=m;++i){
			u=read();v=read();
			ae(u,v);
			ae(v,u);
		}
		for(int i=1;i<=n;++i)
			if(!pre[i])
				dfs(i,0);
	}
}

int main(){
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	original_graph::work();
	tree_merge::solve();
	return 0;
}
