#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	fprintf(stderr,"%d\n",seed);
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int fa[1000000],dep[1000000],vis[1000000];
vector<pair<int,int> > vec;

int main(){
	init();
	freopen("map.in","w",stdout);
	int n=f(2,1e4),m=f(n-1,1.5*n),q=1e3,w=1e6;
//	n=f(1,20);m=f(n-1,n*3);q=f(1,100);
//	n=1e5;m=1.5e5;q=1e5;
	if(n==1)m=0;
	for(int i=2;i<=n;++i){
		fa[i]=f(1,i-1),--m;
		dep[i]=dep[fa[i]]+1;
		vec.push_back(make_pair(i,fa[i]));
	}
	while(m--){
		int x=f(1,n),y=f(1,n);
		while(x==y)x=f(1,n),y=f(1,n);
		int xx=x,yy=y;
		while(xx!=yy)
			if(dep[xx]>=dep[yy])xx=fa[xx];
			else yy=fa[yy];
		for(int i=x;i!=xx;i=fa[i])
			if(vis[i]){
				if(f(0,1))++m;
				goto xxx;
			}
		for(int i=y;i!=xx;i=fa[i])
			if(vis[i]){
				if(f(0,1))++m;
				goto xxx;
			}
		for(int i=x;i!=xx;i=fa[i])
			vis[i]=true;
		for(int i=y;i!=xx;i=fa[i])
			vis[i]=true;
		vec.push_back(make_pair(x,y));
xxx:
		;
	}
	m=vec.size();
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;++i)
		printf("%d ",f(1,w));puts("");
	for(int i=0;i<vec.size();++i)
		printf("%d %d\n",vec[i].first,vec[i].second);
	printf("%d\n",q);
	while(q--)
		printf("%d %d %d\n",f(0,1),f(1,n),f(0,w));
	return 0;
}
