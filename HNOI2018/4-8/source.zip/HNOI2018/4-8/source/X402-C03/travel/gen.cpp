#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f=fopen("seed","r");int seed;
	if(f){
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	else
		seed=time(NULL);
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d\n",rand());
	fclose(f);
	fprintf(stderr,"%d\n",seed);
}
inline int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("travel.in","w",stdout);
	int n=f(1,1000),c=f(1,20),p=1000;
//	n=70363;c=20;p=93259;
//	n=90929;c=18;p=66630;
	printf("%d %d\n",n,c);
	for(int i=1;i<=n;++i)printf("%d ",rand());puts("");
	for(int i=1;i<=n;++i)printf("%d ",rand());puts("");
	printf("%d\n",p);
	while(p--)
		printf("%d %d %d\n",f(1,n),rand(),rand());
	return 0;
}
