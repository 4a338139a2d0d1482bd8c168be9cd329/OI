#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}
inline int min_(int a,int b){return a<=b?a:b;}

const int maxn=1e5+10,mod=1e4+7;
int n,c,p,a[maxn],b[maxn];

struct node{
	int x,y[20];
	inline void init(int a,int b){
		x=(a+b)%mod;
		y[0]=b;y[1]=a;
	}
	inline void push_up(const node&a,const node&b,int len){
		x=a.x*b.x%mod;
		for(int i=0;i<len;++i){
			int&z=y[i];
			z=0;
			for(int j=i;~j;--j)
				z+=a.y[j]*b.y[i-j];
			z%=mod;
		}
	}
}st[maxn<<2];

void build(int rt,int l,int r){
	if(l==r){
		st[rt].init(a[l],b[l]);
		return;
	}
	int mid=l+r>>1;
	build(rt<<1,l,mid);
	build(rt<<1|1,mid+1,r);
	st[rt].push_up(st[rt<<1],st[rt<<1|1],min_(c,r-l+2));
}
void modify(int rt,int l,int r,int pos){
	if(l==r){
		st[rt].init(a[pos],b[pos]);
		return;
	}
	int mid=l+r>>1;
	if(pos<=mid)
		modify(rt<<1,l,mid,pos);
	else
		modify(rt<<1|1,mid+1,r,pos);
	st[rt].push_up(st[rt<<1],st[rt<<1|1],min_(c,r-l+2));
}
inline int calc(){
	int res=0;
	for(int i=0;i<c;++i)
		res=(res+st[1].y[i])%mod;
	return (st[1].x-res+mod)%mod;
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read();c=read();
	for(int i=1;i<=n;++i)
		a[i]=read()%mod;
	for(int i=1;i<=n;++i)
		b[i]=read()%mod;
	build(1,1,n);
	p=read();
	while(p--){
		int pos=read();
		a[pos]=read()%mod;
		b[pos]=read()%mod;
		modify(1,1,n,pos);
		printf("%d\n",calc());
	}
	return 0;
}
