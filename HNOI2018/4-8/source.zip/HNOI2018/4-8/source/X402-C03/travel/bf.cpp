#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll maxn=1e5+10,mod=1e4+7;
ll n,c,p,a[maxn],b[maxn];

inline ll calc1(){
	ll res=1;
	for(ll i=1;i<=n;++i)
		res=res*(a[i]%mod+b[i]%mod)%mod;
	return res;
}
inline ll calc2(){
	ll dp[2][20]={},res=0;
	dp[0][0]=1;
	for(ll i=1;i<=n;++i){
		dp[i&1][0]=dp[i&1^1][0]*b[i]%mod;
		for(ll j=1;j<c;++j)
			dp[i&1][j]=(dp[i&1^1][j-1]*(a[i]%mod)+dp[i&1^1][j]*(b[i]%mod))%mod;
	}
	for(ll i=0;i<c;++i)
		res=(res+dp[n&1][i])%mod;
	return res;
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.txt","w",stdout);
	scanf("%lld%lld",&n,&c);
	for(ll i=1;i<=n;++i)
		scanf("%lld",&a[i]);
	for(ll i=1;i<=n;++i)
		scanf("%lld",&b[i]);
	scanf("%lld",&p);
	while(p--){
		ll pos,x,y;
		scanf("%lld%lld%lld",&pos,&x,&y);
		a[pos]=x;b[pos]=y;
		printf("%lld\n",(calc1()-calc2()+mod)%mod);
	}
	return 0;
}
