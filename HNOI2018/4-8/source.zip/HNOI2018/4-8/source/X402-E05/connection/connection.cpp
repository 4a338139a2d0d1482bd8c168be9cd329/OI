#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int inf=0x3f3f3f3f;
const int N=310;
const int M=2010;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
}
int n,m,ans;
int dfs_cnt,dfn[N],w[N],fa[N];
int bgn[N],nxt[M],to[M],E;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void dfs(int u,int f)
{
	fa[u]=to[f];
	dfn[u]=++dfs_cnt;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if(i==f)continue;
		if(!dfn[v=to[i]])dfs(v,i^1);
		else 
		if(dfn[v]<dfn[u])
		{
			for(int x=u;x!=v;x=fa[x])w[x]++;
		}
	}
}
int main()
{
	int x,y;
	file();
	read(n),read(m);
	E=1;
	For(i,1,m)read(x),read(y),add_edge(x,y),add_edge(y,x);
	ans=m;
	For(i,1,n)
	{
		mem(dfn,0);
		mem(w,0);
		dfs_cnt=0;
		dfs(i,0);
		For(j,1,n)if(i^j)chkmin(ans,w[j]+1);
	}
	printf("%d\n",ans);
	return 0;
}
