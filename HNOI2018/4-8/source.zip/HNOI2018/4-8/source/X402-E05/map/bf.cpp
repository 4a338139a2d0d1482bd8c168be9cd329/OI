#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define ft first
#define sd second
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int M=300010;
const int T=5000010;
const int MAX=1000000;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("map.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,m,Q,s[T];
int a[N],ans[N];
pii q[N];
vector<int>G[N],F[N];
int dfn[N],low[N],dfs_time,st[N],top;
int bgn[N],nxt[M],to[M],E;
int rt[N],lc[T],rc[T],sum[T][2],tot;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void dfs(int u,int f)
{
	dfn[u]=low[u]=++dfs_time;st[++top]=u;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		if(!dfn[v])
		{
			dfs(v,u),chkmin(low[u],low[v]);
			if(low[v]>=dfn[u])
			{
				int x=st[top];
				while(x!=u){G[u].pb(x);x=st[--top];}
			}
		}
		else chkmin(low[u],dfn[v]);
	}
}
inline void pushup(int p){For(i,0,1)sum[p][i]=sum[lc[p]][i]+sum[rc[p]][i];}
inline int Combine(int l,int r,int x,int y)
{
	if(l==r)
	{
		int f=(sum[x][0]?0:1)^(sum[y][0]?0:1);
		sum[x][f]=1;sum[x][f^1]=0;
		return x;
	}
	if(!x||!y)return x^y;
	int mid=(l+r)>>1;
	lc[x]=Combine(ls,lc[x],lc[y]);
	rc[x]=Combine(rs,rc[x],rc[y]);
	pushup(x);
	return x;
}
inline void Add_tree(int l,int r,int&p,int x)
{
	if(!p)p=++tot;
	if(l==r)
	{
		int f=sum[p][1]?1:0;
		sum[p][f^1]=1,sum[p][f]=0;
		return;
	}
	int mid=(l+r)>>1;
	if(x<=mid)Add_tree(ls,lc[p],x);
	else Add_tree(rs,rc[p],x);
	pushup(p);
}
inline int Query(int l,int r,int p,int x,int y)
{
	if(!p)return 0;
	if(l==r)return sum[p][y];
	int mid=(l+r)>>1;
	if(x<=mid)return Query(ls,lc[p],x,y);
	else return sum[lc[p]][y]+Query(rs,rc[p],x,y);
}
inline void dfs_ans(int u,int x)
{
	For(i,0,SZ(G[u])-1)dfs_ans(G[u][i],x);
	s[a[u]]+=x;
}
int main()
{
	int type,x,y;
	file();
	read(n),read(m);
	For(i,1,n)read(a[i]);
	For(i,1,m)
	{
		read(x),read(y);
		add_edge(x,y),add_edge(y,x);
	}
	dfs(1,0);
	read(Q);
	For(i,1,Q)
	{
		read(type),read(x),read(y);
		q[i]=pii(type,y);
		F[x].pb(i);
		dfs_ans(x,1);
		int ret=0;
		For(j,1,y)if(s[j]&&(s[j]&1)==type)ret++;
		printf("%d\n",ret);
		dfs_ans(x,-1);
	}
	//cerr<<tot<<endl;
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
