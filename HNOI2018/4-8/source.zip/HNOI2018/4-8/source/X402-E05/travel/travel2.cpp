#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define lc p<<1
#define rc p<<1|1
#define ls l,mid
#define rs mid+1,r
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
const int mod=10007;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
}
int n,C,Q,now;
int a[N],b[N];
int dp[2][25];
int t[N<<3];
inline void Add(int&x,const int&y){x=x+y<mod?x+y:x+y-mod;}
inline int qpow(int a,int b)
{
	int ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void Add_node(int A,int B)
{
	For(i,0,C-1)
	{
		Add(dp[now^1][i],dp[now][i]*B%mod);
		Add(dp[now^1][i+1],dp[now][i]*A%mod);
	}
	mem(dp[now],0);
	now^=1;
}
inline void Del_node(int A,int B)
{
	int iB=qpow(B,mod-2);
	For(i,0,C-1)
	{
		dp[now][i]=dp[now][i]*iB%mod;
		Add(dp[now][i+1],mod-dp[now][i]*A%mod);
	}
}
inline int Solve()
{
	int ret=t[1];
	For(i,0,C-1)Add(ret,mod-dp[now][i]);
	return ret;
}
inline void Build(int l,int r,int p)
{
	if(l==r){t[p]=a[l]+b[l];return;}
	int mid=(l+r)>>1;
	Build(ls,lc),Build(rs,rc);
	t[p]=t[lc]*t[rc]%mod;
}
inline void Modify(int l,int r,int p,int x,int y)
{
	if(l==r){t[p]=y;return;}
	int mid=(l+r)>>1;
	if(x<=mid)Modify(ls,lc,x,y);
	else Modify(rs,rc,x,y);
	t[p]=t[lc]*t[rc]%mod;
}
int main()
{
	int x,y,z;
	file();
	read(n),read(C);
	For(i,1,n)read(a[i]),a[i]=(a[i]%mod+mod)%mod;
	For(i,1,n)read(b[i]),b[i]=(b[i]%mod+mod)%mod;
	Build(1,n,1);
	dp[now=0][0]=1;
	For(i,1,n)Add_node(a[i],b[i]);
	read(Q);
	while(Q--)
	{
		read(x),read(y),read(z);
		Del_node(a[x],b[x]);
		a[x]=y,b[x]=z;
		Modify(1,n,1,x,a[x]+b[x]);
		Add_node(a[x],b[x]);
		printf("%d\n",Solve());
	}
	return 0;
}
