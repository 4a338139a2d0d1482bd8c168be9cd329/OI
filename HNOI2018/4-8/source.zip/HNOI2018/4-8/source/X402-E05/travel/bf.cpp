#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
const int mod=10007;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("travel.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,C,Q;
int a[N],b[N];
int dp[2][25];
inline void Add(int&x,const int&y){x=x+y<mod?x+y:x+y-mod;}
inline int Solve()
{
	int now;
	mem(dp,0);
	dp[now=0][0]=1;
	For(i,1,n)
	{
		For(j,0,C)
		if(dp[now][j])
		{
			Add(dp[now^1][j],dp[now][j]*b[i]%mod);
			Add(dp[now^1][min(C,j+1)],dp[now][j]*a[i]%mod);
		}
		mem(dp[now],0);
		now^=1;
	}
	return dp[now][C];
}
int main()
{
	int x,y,z;
	file();
	read(n),read(C);
	For(i,1,n)read(a[i]),a[i]=(a[i]%mod+mod)%mod;
	For(i,1,n)read(b[i]),b[i]=(b[i]%mod+mod)%mod;
	read(Q);
	while(Q--)
	{
		read(x),read(y),read(z);
		a[x]=y,b[x]=z;
		printf("%d\n",Solve());
	}
	return 0;
}
