#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define lc p<<1
#define rc p<<1|1
#define ls l,mid
#define rs mid+1,r
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
const int mod=10007;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
}
int n,C,Q,now;
int a[N],b[N];
int dp[2][21];
int t[N<<3][21],s[N<<3][21];
inline void Add(int&x,const int&y){x=x+y<mod?x+y:x+y-mod;}
inline int qpow(int a,int b)
{
	int ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void pushup(int *t,int *s,int *l,int *r,int *sr)
{
	For(i,0,C)t[i]=0;
	For(i,0,C)
	if(l[i])
	{
		For(j,0,C-i)Add(t[i+j],l[i]*r[j]%mod);
		Add(t[C],l[i]*sr[C-i+1]%mod);
	}
	rFor(i,C,0)Add(s[i]=t[i],s[i+1]);
}
inline void Build(int l,int r,int p)
{
	if(l==r)
	{
		t[p][0]=b[l],t[p][1]=a[l];
		s[p][0]=a[l]+b[l],s[p][1]=a[l];
		return;
	}
	int mid=(l+r)>>1;
	Build(ls,lc),Build(rs,rc);
	pushup(t[p],s[p],t[lc],t[rc],s[rc]);
	/*
	printf("(%d %d) %d\n",l,r,p);
	For(i,0,C)printf("%d ",t[p][i]);puts("");
	For(i,0,C)printf("%d ",s[p][i]);puts("");
	*/
}
inline void Modify(int l,int r,int p,int x,int A,int B)
{
	if(l==r)
	{
		t[p][0]=B,t[p][1]=A;
		s[p][0]=A+B,s[p][1]=A;
		return;
	}
	int mid=(l+r)>>1;
	if(x<=mid)Modify(ls,lc,x,A,B);
	else Modify(rs,rc,x,A,B);
	pushup(t[p],s[p],t[lc],t[rc],s[rc]);
}
int main()
{
	int x,y,z;
	file();
	read(n),read(C);
	For(i,1,n)read(a[i]),a[i]=(a[i]%mod+mod)%mod;
	For(i,1,n)read(b[i]),b[i]=(b[i]%mod+mod)%mod;
	Build(1,n,1);
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	read(Q);
	while(Q--)
	{
		read(x),read(y),read(z);
		a[x]=y,b[x]=z;
		Modify(1,n,1,x,a[x],b[x]);
		printf("%d\n",t[1][C]);
	}
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
