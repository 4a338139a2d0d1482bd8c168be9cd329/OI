#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=1000;
const int inf=0x3f3f3f3f;
struct node {
	int from,to,next;
}e[maxn];
int n,m,M;
int tot,ans=inf;
int head[maxn],vis[maxn],Vis[maxn];

inline void file() {
	freopen("connection.in","r",stdin);
	freopen("bf.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void add(int from,int to) {
	tot++;
	e[tot].from=from; e[tot].to=to; e[tot].next=head[from]; head[from]=tot;
}

void dfs(int u) {
	Vis[u]=1;
	for (int i=head[u];i!=0;i=e[i].next) {
		if (vis[i]) continue;
		int v=e[i].to;
		if (Vis[v]) continue;
		dfs(v);
	}
}

int main() {
	file();
	read(n); read(m);
	For (i,1,m) {
		int x,y; read(x); read(y);
		add(x,y); add(y,x);
	}
	M=(1<<m);
	For (i,0,M-1) {
		Set(vis,0); Set(Vis,0);
		int cnt=0;
		For (j,0,m-1)
			if (i&(1<<j)) {
				cnt++;
				vis[j*2+1]=1; vis[j*2+2]=1;
			}
		dfs(1);
		int flag=1;
		For (i,1,n)
			if (!Vis[i]) {
				flag=0; break;
			}
		if (!flag) chkmin(ans,cnt);
	}
	printf("%d\n",ans);
	return 0;
}
