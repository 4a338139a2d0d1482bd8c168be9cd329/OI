#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=1000+10;
const int inf=0x3f3f3f3f;
struct node {
	int to,next,cap,flow;
}e[maxn<<2];
int n,m;
int tot,s,t,ans;
int head[maxn],cur[maxn],vis[maxn],d[maxn];

inline void file() {
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void add(int from,int to,int cap) {
	tot++;
	e[tot].to=to; e[tot].cap=cap; e[tot].flow=0;
	e[tot].next=head[from]; head[from]=tot;
}

inline bool bfs() {
	queue<int>q; q.push(s);
	Set(vis,0); vis[s]=1;
	Set(d,0); d[s]=1;
	while (!q.empty()) {
		int u=q.front(); q.pop();
		for (int i=head[u];i!=-1;i=e[i].next) {
			int v=e[i].to;
			if (!vis[v] && e[i].cap>e[i].flow) {
				vis[v]=1; d[v]=d[u]+1;
				q.push(v);
			}
		}
	}
	return vis[t];
}

int dfs(int u,int rst) {
	if (u==t || rst==0) return rst;
	int flow=0;
	for (int &i=cur[u];i!=-1;i=e[i].next) {
		int v=e[i].to,f;
		if (d[u]+1==d[v] && (f=dfs(v,min(rst,e[i].cap-e[i].flow)))>0) {
			e[i].flow+=f; e[i^1].flow-=f; flow+=f; rst-=f;
			if (!rst) break;
		}
	}
	return flow;
}

inline int solve() {
	int flow=0;
	while (bfs()) {
		For (i,0,n+1) cur[i]=head[i];
		flow+=dfs(s,inf);
	}
	return flow;
}

int main() {
	file();
	srand(2001);
	read(n); read(m);
	tot=-1; Set(head,-1);
	For (i,1,m) {
		int x,y; read(x); read(y);
		add(x,y,1);// add(y,x,0);
		add(y,x,1);// add(x,y,0);
	}
	ans=inf;
	int tt=3;
	while (tt--) {
		s=rand()%n+1;
		for (t=1;t<=n;++t) {
			if (t==s) continue;
			For (i,0,tot) e[i].flow=0;
			chkmin(ans,solve());
		}
	}
	printf("%d\n",ans);
	return 0;
}
