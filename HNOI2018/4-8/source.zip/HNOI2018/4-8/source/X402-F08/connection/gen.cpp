#include<bits/stdc++.h>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=300;
const int maxm=1000;
const int maxN=10000;

struct node {
	int from,to,next;
}e[maxN];
int n,m,tot;
int head[maxN],vis[maxN];

inline void file() {
	freopen("connection.in","w",stdout);
}

inline void add(int from,int to) {
	tot++;
	e[tot].from=from; e[tot].to=to; e[tot].next=head[from]; head[from]=tot;
}

void dfs(int u) {
	vis[u]=1;
	for (int i=head[u];i!=0;i=e[i].next) {
		int v=e[i].to;
		if (vis[v]) continue;
		dfs(v);
	}
}

int main() {
	file();
	srand(time(NULL));
//	n=rand()%maxn+2,m=rand()%maxm+1;
//	while (n>m) {
//		n=rand()%maxn+2; m=rand()%maxm+1;
//	}
	n=maxn; m=maxm;
	printf("%d %d\n",n,m);
	while (1) {
		tot=0; Set(head,0); Set(vis,0);
		For (i,1,m) {
			int x=rand()%n+1,y=rand()%n+1;
			while (x==y) {
				x=rand()%n+1; y=rand()%n+1;
			}
			add(x,y); add(y,x);
		}
		dfs(1);
		int flag=1;
		For (i,1,n)
			if (!vis[i]) {
				flag=0; break;
			}
		if (flag) break;
	}
	for (int i=1;i<=tot;i+=2) printf("%d %d\n",e[i].from,e[i].to);
	return 0;
}
