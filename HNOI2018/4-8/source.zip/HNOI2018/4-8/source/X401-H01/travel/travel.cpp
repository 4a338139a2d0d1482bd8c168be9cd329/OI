#include<iostream>
#include<cstdio>
#include<cstring>
#define N 91000
#define mid (l+r>>1)
//#define min(a,b) ((a)<(b)?(a):(b))
#define up(x,y) x=(x+(y))%mod
using namespace std;
const int mod=10007;
int read()
{
	int x=0,f=1;char ch=getchar();
	for(;ch<'0'||ch>'9';ch=getchar()) if(ch=='-') f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}
int n,c,a[N],b[N],q;
struct tree
{
	int w[22];
	tree *ls,*rs;
	tree(){ls=rs=0;memset(w,0,sizeof(w));}
	void update(int l,int r)
	{
		for(int i=0;i<=min(r-l+1,c);i++)
			w[i]=0;
		for(int i=0;i<=min(mid-l+1,c);i++)
			for(int j=0;j<=min(r-mid,c);j++)
				up(w[min(i+j,c)],ls->w[i]*rs->w[j]);
	}
	void build(int l,int r)
	{
		if(l==r) {w[0]=b[l];w[1]=a[l];return ;}
		(ls=new tree)->build(l,mid);
		(rs=new tree)->build(mid+1,r);
		update(l,r);
//		cout<<l<<' '<<r<<endl;
//		for(int i=0;i<=c;i++)
//			cout<<w[i]<<' ';
//		puts("");	
	}
	void mdf(int l,int r,int x,int da,int db)
	{
		if(l==r){w[0]=db;w[1]=da;return ;}
		if(x<=mid) ls->mdf(l,mid,x,da,db);
		else rs->mdf(mid+1,r,x,da,db);
		update(l,r);
	}	
}*xtr;
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read();c=read();
	for(int i=1;i<=n;i++)
		a[i]=read()%mod;
	for(int i=1;i<=n;i++)	
		b[i]=read()%mod;
	(xtr=new tree)->build(1,n);	
	q=read();
	while(q--)
	{
		int u=read(),x=read()%mod,y=read()%mod;
		xtr->mdf(1,n,u,x,y);
		printf("%d\n",xtr->w[c]);
	}
	return 0;
}
/*4 2
1 2 3 4
1 2 3 4
1 
4 1 1

4 3
1 2 1 3
4 1 1 2
1
1 1 4*/
