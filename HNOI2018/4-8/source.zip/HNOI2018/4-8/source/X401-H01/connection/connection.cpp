#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 310
using namespace std;
const int inf=0x3f3f3f3f;
int n,m,e[1010][2],ne[N],S,T,dl[N];
struct edge
{
	int t,c,f;
	edge *next,*rev;
}*con[310];
void ins(int x,int y,int c)
{
	edge *p=new edge;p->t=y;p->c=c;p->f=0;p->next=con[x];con[x]=p;
	p=new edge;p->t=x;p->c=0;p->f=0;p->next=con[y];con[y]=p;
	con[x]->rev=con[y];con[y]->rev=con[x];
}
bool bfs()
{
	bool re=0;
	memset(ne,0,sizeof(ne));
	dl[1]=S;ne[S]=1;
	for(int hd=1,tl=1,v=S;hd<=tl;re|=(v==T),v=dl[++hd])
		for(edge *p=con[v];p;p=p->next)
			if(p->c>p->f&&!ne[p->t]) ne[p->t]=ne[v]+1,dl[++tl]=p->t;
	return re;			
}
int dinic(int v,int flow)
{
	if(v==T) return flow;
	if(ne[v]==-1) return 0;
	int re=0;
	for(edge *p=con[v];p&&flow;p=p->next)
		if(p->c>p->f&&ne[p->t]==ne[v]+1)
		{
			int o=dinic(p->t,min(flow,p->c-p->f));
			p->f+=o;re+=o;
			p->rev->f-=o;flow-=o;
		}
	if(re==0) ne[v]==-1;
	return re;	
}
int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y,1);ins(y,x,1);
	}
	int ans=inf;S=1;
	for(int i=2;i<=n;i++)
	{
		T=i;
		for(int i=1;i<=n;i++)
			for(edge *p=con[i];p;p=p->next)
				p->f=0;
		int cal=0;
		while(bfs()) cal+=dinic(S,inf);	
		//cout<<T<<' '<<cal<<endl;	
		ans=min(ans,cal);
	}
	printf("%d",ans);
	return 0;	
}
