#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=305,maxm=1005;
int ans;
int n,m,pre[maxn];
bool mark[maxm],vis[maxn];
vector<int>E[maxn];
pair<int,int>e[maxm];
void dfs(int u){
	vis[u]=1;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(!vis[v])pre[v]=u,dfs(v);
	}
	int v=u,res,tot=0;
	while(v){
		mark[v]=1,res=0;
		if(++tot==n)break;
		REP(i,1,m)if(mark[e[i].first]^mark[e[i].second])++res;
		chkmin(ans,res);
		v=pre[v];
	}
	v=u;
	while(v){
		mark[v]=0;
		v=pre[v];
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,m){
		int u=read(),v=read();
		E[u].pb(v),E[v].pb(u);
		e[i]=make_pair(u,v);
	}
	ans=m;
	REP(i,1,m){
		int res=0;
		mark[e[i].first]=mark[e[i].second]=1;
		REP(j,1,m)if(mark[e[j].first]^mark[e[j].second])++res;
		mark[e[i].first]=mark[e[i].second]=0;
		chkmin(ans,res);
	}
	srand(time(0));
	while(clock()<=0.8*CLOCKS_PER_SEC){
		REP(i,1,n){
			random_shuffle(E[i].begin(),E[i].end());
			vis[i]=pre[i]=0;
		}
		dfs(1);
	}
	write(ans,'\n');
	return 0;
}
