#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
int n,m,q_cnt,val[maxn];
int tot,root[maxn];
struct node{
	int lc,rc,cnt,sum[2];
};
struct seg_tree{
	node tr[maxn*50];
	int newnode(){
		return ++tot;
	}
	void push_up(int p){
		tr[p].sum[0]=tr[tr[p].lc].sum[0]+tr[tr[p].rc].sum[0];
		tr[p].sum[1]=tr[tr[p].lc].sum[1]+tr[tr[p].rc].sum[1];
	}
	void update(int &p,int l,int r,int pos){
		if(!p)p=newnode();
		if(l==r){
			if(tr[p].cnt!=0)--tr[p].sum[tr[p].cnt&1];
			tr[p].cnt++,++tr[p].sum[tr[p].cnt&1];
			return;
		}
		int mid=(l+r)>>1;
		if(pos<=mid)update(tr[p].lc,l,mid,pos);
		else update(tr[p].rc,mid+1,r,pos);
		push_up(p);
	}
	int merge(int x,int y,int l,int r){
		int t=newnode();
		tr[t]=tr[x];
		x=t;
		if(!x){
			tr[x]=tr[y];
			return x;
		}
		if(!y)return x;
		if(l==r){
			if(tr[x].cnt!=0)--tr[x].sum[tr[x].cnt&1];
			tr[x].cnt+=tr[y].cnt,++tr[x].sum[tr[x].cnt&1];
			return x;
		}
		int mid=(l+r)>>1;
		tr[x].lc=merge(tr[x].lc,tr[y].lc,l,mid);
		tr[x].rc=merge(tr[x].rc,tr[y].rc,mid+1,r);
		push_up(x);
		return x;
	}
/*
	void dfs(int p,int l,int r){
		if(!p)return;
		if(l==r){
			cout<<l<<' '<<tr[p].cnt<<' '<<tr[p].sum[0]<<' '<<tr[p].sum[1]<<endl;
			return;
		}
		int mid=(l+r)>>1;
		dfs(tr[p].lc,l,mid);
		dfs(tr[p].rc,mid+1,r);
	}
*/
	int query(int p,int l,int r,int k,int type){
		if(r<=k)return tr[p].sum[type];
		int mid=(l+r)>>1,res=query(tr[p].lc,l,mid,k,type);
		if(k>mid)res+=query(tr[p].rc,mid+1,r,k,type);
		return res;
	}
}T;
int bcc_cnt,id[maxn],top[maxn];
int dfn[maxn],low[maxn],dfs_clock,pre[maxn];
vector<int>E[maxn],G[maxn],bcc[maxn];
stack<int>stk;
void build(int u,int fa){
	stk.push(u);
	dfn[u]=low[u]=++dfs_clock;
	REP(i,0,G[u].size()-1){
		int v=G[u][i];
		if(!dfn[v]){
			build(v,u),chkmin(low[u],low[v]);
			if(low[v]==dfn[u]){
				top[++bcc_cnt]=0;
				pre[bcc_cnt]=u;
				while(!stk.empty()){
					v=stk.top();
					stk.pop();
					id[v]=bcc_cnt;
					bcc[bcc_cnt].pb(v);
					if(v==G[u][i])break;
				}
				if((!stk.empty())&&(stk.top()==u)){
					stk.pop();
					top[++bcc_cnt]=u;
					id[u]=bcc_cnt;
					bcc[bcc_cnt].pb(u);
				}
			}
		}else if(v!=fa)chkmin(low[u],dfn[v]);
	}
	if((dfn[u]==low[u])&&(!stk.empty())&&(stk.top()==u)){
		stk.pop();
		top[++bcc_cnt]=u;
		id[u]=bcc_cnt;
		bcc[bcc_cnt].pb(u);
	}
}
void dfs(int u,int fa){
	REP(i,0,bcc[u].size()-1)
		T.update(root[u],1,1e6,val[bcc[u][i]]);
	sort(E[u].begin(),E[u].end());
	int sz=unique(E[u].begin(),E[u].end())-E[u].begin();
//	cout<<"u="<<u<<endl;
//	REP(i,0,sz-1)
//		write(E[u][i],i==iend?'\n':' ');
	REP(i,0,sz-1){
		int v=E[u][i];
		if(v==fa)continue;
		dfs(v,u);
		root[u]=T.merge(root[u],root[v],1,1e6);
	}
/*
	cout<<"u="<<u<<endl;
	T.dfs(root[u],1,1e6);
	puts("");
*/
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n)val[i]=read();
	REP(i,1,m){
		int u=read(),v=read();
		G[u].pb(v),G[v].pb(u);
	}
	build(1,0);
	REP(i,1,n){
		int u=id[i];
		REP(j,0,G[i].size()-1){
			int v=id[G[i][j]];
			if(u!=v){
				if(!pre[u]){
					if((!pre[v])||(pre[v]==i))E[u].pb(v);
				}else{
					if(low[bcc[v][0]]==dfn[bcc[v][0]])E[u].pb(v);
				}
			}
		}
	}
//	REP(i,1,n)write(id[i],i==n?'\n':' ');
//	REP(i,1,bcc_cnt)write(top[i],i==iend?'\n':' ');
	dfs(id[1],0);
	q_cnt=read();
	REP(i,1,q_cnt){
		int type=read(),u=read(),k=read(),ans=0;
//		cout<<id[u]<<endl;
//		T.dfs(root[id[u]],1,1e6);
		if(u!=top[id[u]])ans=(type)&(val[u]<=k);
		else ans=T.query(root[id[u]],1,1e6,k,type);
		write(ans,'\n');
	}
	return 0;
}
