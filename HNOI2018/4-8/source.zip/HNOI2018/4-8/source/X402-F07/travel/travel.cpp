#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005,mod=10007;
int n,m,q_cnt;
int a[maxn],b[maxn];
struct seg_tree{
	int f[maxn<<2][21];
	int sum[21];
	void push_up(int p,int u,int v){
		REP(i,0,m)
			f[p][i]=0;
		REP(i,0,m)
			REP(j,0,m-i-1)
				(f[p][i+j]+=f[u][i]*f[v][j])%=mod;
		sum[m]=f[v][m];
		DREP(i,m-1,0)
			sum[i]=(sum[i+1]+f[v][i])%mod;
		REP(i,0,m)
			(f[p][m]+=f[u][i]*sum[m-i])%=mod;
	}
	void build(int p,int l,int r){
		if(l==r){
			f[p][0]=a[l]%mod,f[p][1]=b[l]%mod;
			return;
		}
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		build(u,l,mid),build(v,mid+1,r);
		push_up(p,u,v);
	}
	void update(int p,int l,int r,int pos){
		if(l==r){
			f[p][0]=a[l]%mod,f[p][1]=b[l]%mod;
			return;
		}
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		if(pos<=mid)update(u,l,mid,pos);
		else update(v,mid+1,r,pos);
		push_up(p,u,v);
	}
}T;
int main(){
#ifndef ONLINE_JUDGE
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n)a[i]=read();
	REP(i,1,n)b[i]=read();
	T.build(1,1,n);
	q_cnt=read();
	REP(i,1,q_cnt){
		int u=read();
		a[u]=read(),b[u]=read();
		T.update(1,1,n,u);
		write(T.f[1][m],'\n');
	}
	return 0;
}
