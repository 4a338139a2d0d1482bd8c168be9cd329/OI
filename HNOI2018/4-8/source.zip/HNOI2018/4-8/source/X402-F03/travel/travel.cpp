#include<bits/stdc++.h>
using namespace std;
const int mod=10007;
int s[404040][22],doe[404040];
int a[101010],b[101010];
int n,C,m,ans;
inline void read(int &x)
{
    int data=0,w=1;
    char ch=0;
    while (ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
    if (ch=='-') w=-1,ch=getchar();
    while (ch>='0'&&ch<='9') data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
    x=data*w;
}
void sol(int p)
{
	int l=p*2,r=p*2+1;
	for (int i=0;i<C;++i)
	{
		s[p][i]=0;
		for (int j=0;j<=i;++j)
			s[p][i]=(s[p][i]+s[l][j]*s[r][i-j]%mod)%mod;
	}
}
void build(int p,int l,int r)
{
	if (l==r)
	{
		s[p][0]=b[l];
		s[p][1]=a[l];
		doe[p]=(a[l]+b[l])%mod;
		return;
	}
	int mid=(l+r)/2;
	build(p*2,l,mid);
	build(p*2+1,mid+1,r);
	sol(p);
	doe[p]=doe[p*2+1]*doe[p*2]%mod;
}
void change(int p,int l,int r,int id,int x,int y)
{
	if (l==r)
	{
		doe[p]=(x+y)%mod;
		s[p][0]=y;
		s[p][1]=x;
		return;
	}
	int mid=(l+r)/2;
	if (id<=mid) change(p*2,l,mid,id,x,y);
	else change(p*2+1,mid+1,r,id,x,y);
	sol(p);
	doe[p]=doe[p*2]*doe[p*2+1]%mod;
}
void find(int p,int l,int r,int x,int y)
{
	if (x<=l && r<=y) 
	{
		ans=ans*doe[p]%mod;
		return;
	}
	int mid=(l+r)/2;
	if (x<=mid) find(p*2,l,mid,x,y);
	if (y>mid) find(p*2+1,mid+1,r,x,y);
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&C);
	for (int i=1;i<=n;++i)
		read(a[i]),a[i]%=mod;
	for (int i=1;i<=n;++i)
		read(b[i]),b[i]%=mod;

	build(1,1,n);
	scanf("%d",&m);
	int id,x,y;
	for (int ii=1;ii<=m;++ii)
	{
		ans=1;
		read(id); read(x); read(y);
		x%=mod; y%=mod;
		change(1,1,n,id,x,y);
		int sss=doe[1];
		for (int i=0;i<C;++i)
			sss=(sss-s[1][i])%mod;
		sss=(sss+mod)%mod;
		printf("%d\n",sss);
	}
	return 0;
}
