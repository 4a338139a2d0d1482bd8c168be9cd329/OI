#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int n,m,s,t,doe=1,ans,Ans=99999;
int a[330],que[2020202];
int pre[4020],son[4020],now[330],v[4020];
struct node
{
	int x,y;
}line[1010];
void add(int x,int y,int z)
{
//	printf("%d %d %d\n",x,y,z);
	++doe;
	pre[doe]=now[x];
	now[x]=doe;
	son[doe]=y;
	v[doe]=z;

	++doe;
	pre[doe]=now[y];
	now[y]=doe;
	son[doe]=x;
	v[doe]=0;
}
bool bfs()
{
//	printf("s:%d t:%d\n",s,t);
	memset(a,-1,sizeof(a));
	int head=1,tail=1;
	a[s]=0;
	que[1]=s;
	while (head<=tail)
	{
		int x=que[head];
		int p=now[x];
		while (p)
		{
			int y=son[p];
			if (a[y]==-1 && v[p]>0)
			{
				a[y]=a[x]+1;
				if (y==t) return 1;
				++tail;
				que[tail]=y;
			}
			p=pre[p];
		}
		++head;
	}
//	printf("end\n");
	return 0;
}
int dinic(int x,int sum)
{
	if (sum==0) return 0;
	if (x==t) return sum;
	int p=now[x];
	int kkk=sum;
	while (p)
	{
		int y=son[p];
		if (a[y]==a[x]+1)
		{
			int k=dinic(y,min(sum,v[p]));
			v[p]-=k;
			v[p^1]+=k;
			sum-=k;
		}
		if (sum==0) break;
		p=pre[p];
	}
	if (sum) a[x]=-1;
	return kkk-sum;
}
int main()
{
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	scanf("%d%d",&n,&m);
	s=1;
	for (int i=1;i<=m;++i)
		scanf("%d %d",&line[i].x,&line[i].y);
for (t=2;t<=n;++t)
{
	ans=0; doe=1;
	memset(now,0,sizeof(now));
	memset(pre,0,sizeof(pre));
	for (int i=1;i<=m;++i)
		add(line[i].x,line[i].y,1),add(line[i].y,line[i].x,1);
	while (bfs())
		ans+=dinic(s,999999999);
//	printf("%d\n",ans);
	Ans=min(ans,Ans);
}	
	printf("%d\n",Ans);
	return 0;
}
