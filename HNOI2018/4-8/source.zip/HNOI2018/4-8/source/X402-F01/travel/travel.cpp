#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n,a[100005],b[100005],p,c;
int tot;
int mo[100005];
const int mod = 10007;
int tree[400005][25];
long long qpow(long long x,long long y){
    long long res=1;
	while(y){
	    if(y&1)res=res*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return res;
}
#define mid ((l+r)>>1)
void built(int rt,int l,int r){
     if(l==r){
	     tree[rt][0]=b[l];
		 tree[rt][1]=a[l];
		 return ;
	 }
     built(rt<<1,l,mid);
	 built(rt<<1|1,mid+1,r);
	 F(i,0,c-1)tree[rt][i]=0;
	 F(i,0,c-1){
	    for(int j=0;i+j<c;j++){
		   tree[rt][i+j]=(tree[rt][i+j]+1ll*tree[rt<<1][i]*tree[rt<<1|1][j]%mod)%mod;
		}
	 }
}
void update(int rt,int l,int r,int pos,int ai,int bi){
    if(l==r){
	    tree[rt][0]=ai;
		tree[rt][1]=bi;
		return ;
	}
	if(pos<=mid)update(rt<<1,l,mid,pos,ai,bi);
	if(pos>mid)update(rt<<1|1,mid+1,r,pos,ai,bi);
	
	 F(i,0,c-1)tree[rt][i]=0;
	 F(i,0,c-1){
	    for(int j=0;i+j<c;j++){
		   tree[rt][i+j]=(tree[rt][i+j]+1ll*tree[rt<<1][i]*tree[rt<<1|1][j]%mod)%mod;
		}
	 }
}
int main () {
#ifndef ONLINE_JUDGE
file("travel");
#endif
   n=read();
   c=read();
   F(i,1,n)a[i]=read(),a[i]%=mod;
   F(i,1,n)b[i]=read(),b[i]%=mod;
   tot=1;
   F(i,1,n){
      tot=1ll*tot*((a[i]+b[i])%mod)%mod;
   }
   F(i,1,mod-1)mo[i]=qpow(i,mod-2);
   p=read();
   built(1,1,n);
   while(p--){
      int pos=read(),x=read(),y=read();
	  tot=1ll*tot*mo[(a[pos]+b[pos])%mod]%mod;
     tot=1ll*tot*(x+y)%mod;
	 a[pos]=x,b[pos]=y;
	 update(1,1,n,pos,x,y);
	 int ans=0;
	 F(i,0,c-1)ans=(ans+tree[1][i])%mod;
	 //cout<<ans<<endl;
	 printf("%d\n",(tot-ans+mod)%mod);
   }
    return 0;
}
