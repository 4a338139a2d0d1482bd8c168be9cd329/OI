#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a.in,r,stdin),freopen(a.out,w,stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
const int mod=1e4+7;
int main () {
  freopen("travel.in","w",stdout);
   srand(time(NULL)); 
   int n=70363,c=20,p=93259;
	cout<<n<<" "<<c<<endl;
	F(i,1,n)
	   cout<<1ll*rand()*rand()%mod+1<<" ";
	cout<<endl;
	F(i,1,n)cout<<1ll*rand()*rand()%mod+1<<" ";
	cout<<endl;
	cout<<p<<endl;
	F(i,1,p){
	   cout<<1ll*rand()*rand()%n+1<<" "<<1ll*rand()*rand()%mod+1<<" "<<1ll*rand()*rand()%mod+1<<endl;
	}
    return 0;
}
