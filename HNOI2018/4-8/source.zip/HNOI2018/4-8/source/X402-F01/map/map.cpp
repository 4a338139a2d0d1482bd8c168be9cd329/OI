#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n,m;
int a[100005];
int q;
int he[300005],to[300005],ne[300005],e;
void add(int x,int y){
   to[++e]=y;
   ne[e]=he[x];
   he[x]=e;
}
int cnt[100005];
int c[100005],pos,vis[100005],g[100005],cc[100005];
bool dfs(int x){
	vis[x]=1;
    if(pos==x)return 1; 
   for(int i=he[x];i;i=ne[i]){
      int v=to[i];
	  if(vis[v])continue;
	  if(dfs(v)){
	      g[x]=cc[x]=cc[x^1]=1;
	  }
   }
   return g[x];
}
void dfs2(int x){
    vis[x]=1;
	++c[a[x]];
		for(int i=he[x];i;i=ne[i]){
		    int v=to[i];
			if(g[v]||cc[i]||vis[v])continue;
			dfs2(v);
		}
}
int main () {
#ifndef ONLINE_JUDGE
file("map");
#endif
    n=read();
	m=read();
    F(i,1,n)a[i]=read();
	F(i,1,m){
	   int x=read(),y=read();
	   add(x,y);
	   add(y,x);
	}
    q=read();
	while(q--){
	   int opt=read(),x=read(),y=read();
       int ans=0;
	   pos=x;
	   Set(c,0);Set(g,0);
	   Set(cc,0),Set(vis,0);
	   dfs(1);
	   dfs2(x);
	   F(i,1,y){
	     if(c[i]!=0&&c[i]%2==opt)ans++;
	   }
	   printf("%d\n",ans);
	}
	return 0;
}
