#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define file(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n,m;
int he[20005],to[20005],ne[20005],cost[20005],e=1;
int ans,sum;
int a[20005],gap[20005],b[20005],dis[20005],cur[20005],vis[20005];
struct node{
   int x,y;
}p[10005];
void add(int x,int y,int z){
    to[++e]=y;
	ne[e]=he[x];
	he[x]=e;
	cost[e]=z;
}
int s,t;
int sap(int x,int flow){
    if(x==t)return flow;
	int f=0;
	for(int i=cur[x];i;i=ne[i]){
	    int v=to[i];
		if(cost[i]&&dis[x]==dis[v]+1){
		   cur[x]=i;
		   int num=sap(v,min(cost[i],flow-f));
		   cost[i]-=num;
           cost[i^1]+=num;
		   f+=num;
		   if(f==flow||dis[s]>m)return f;
		}
	}
	cur[x]=he[x];
	if(!--gap[dis[x]])dis[s]=m+1;
	gap[++dis[x]]++;
	return f;
}
void dfs(int x){
      vis[x]=1;
	  for(int i=he[x];i;i=ne[i]){
	     int v=to[i];
		 if(cost[i]&&!vis[v])dfs(v);
	  }
}
void solve(int l,int r){
   if(l==r)return ;
   s=a[l],t=a[r];
   Set(gap,0);
   Set(dis,0);
   for(int i=1;i<=e;i+=2)cost[i]=cost[i^1]=cost[i]+cost[i^1]>>1;
   gap[0]=m;
   F(i,1,n)cur[i]=he[i];
   int sum=0;
   while(dis[s]<=m)sum+=sap(s,2107483648);
   ans=min(ans,sum);
   Set(vis,0);
   dfs(s);
   int ll=l,rr=r;
   F(i,l,r){
        if(vis[a[i]])b[ll++]=a[i];
		else b[rr--]=a[i];
   }
   F(i,l,r)a[i]=b[i];
   solve(l,ll-1);
   solve(ll,r);
}
int main () {
#ifndef ONLINE_JUDGE
file("connection");
#endif
    n=read();
	m=read();
	F(i,1,m){
	   p[i].x=read();
	   p[i].y=read();
	}
	if(m==n-1){
		printf("1\n");
	   return 0;
	}
	ans=2107483648;
	F(i,1,n){
	   add(p[i].x,p[i].y,1);
	   add(p[i].y,p[i].x,1);
	}
	F(i,1,n)a[i]=i;
    solve(1,n);
   printf("%d\n",ans);
    return 0;
}
