#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100100, INF = 0x3f3f3f3f, Mod = 10007;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("travel.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int A[N], B[N], n, C, P;
void init(){
	read(n), read(C);
	For(i, 1, n)read(A[i]);
	For(i, 1, n)read(B[i]);
}
int dp[N][30];
void solve(){
	read(P);
	while(P--){
		int u;
		read(u), read(A[u]), read(B[u]);
		dp[0][0] = 1;
		int all = 1;
		For(i, 1, n){
			all = all * (A[i] + B[i]) % Mod;
			For(j, 0, C)dp[i][j] = 0;
			For(j, 0, C)
				dp[i][j] = (dp[i][j] + dp[i - 1][j] * B[i]) % Mod,
				j ? dp[i][j] = (dp[i][j] + dp[i - 1][j - 1] * A[i]) % Mod : 0;
		}
		For(i, 0, C - 1)
			all = (all + Mod - dp[n][i]) % Mod;
		printf("%d\n", all);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
