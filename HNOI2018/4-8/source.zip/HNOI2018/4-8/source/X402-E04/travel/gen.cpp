#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;


int main(){
	freopen("travel.in","w",stdout);
	srand(time(0));
	int n = rand() % 1000 + 1, C =rand() % min(n, 20) + 1, M = 10007;
	//n = 73893, C = 9;
	printf("%d %d\n", n, C);
	For(i, 1, n)printf("%d ", rand()%M);puts("");
	For(i, 1, n)printf("%d ", rand()%M);puts("");
	int p = rand() % 1000 + 1;
	//p = 96448;
	printf("%d\n", p);
	while(p--){
		int pos = rand()%n + 1;
		int x = rand() % M, y = rand() %M;
		printf("%d %d %d\n", pos, x, y);
	}
	return 0;
}
