#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100100, INF = 0x3f3f3f3f, Mod = 10007;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
}
int A[N], B[N], n, C, p;
int S = 1;
void init(){
	read(n), read(C); C--;
	For(i, 1, n)read(A[i]), ((A[i] %= Mod) += Mod) %= Mod;
	For(i, 1, n)read(B[i]), ((B[i] %= Mod) += Mod) %= Mod;
}
ll qpow(ll a, ll b){
	ll ret = 1;
	for(;b;b>>=1, a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
struct Poly{
	int A[21];
	Poly(){memset(A, 0, sizeof(A));}
	int& operator [] (int x){return A[x];}
	Poly operator * (Poly & B)const {
		Poly D;
		For(i, 0, C)if(A[i])
			For(j, 0, C - i)
				D[i + j] = (D[i + j] + A[i] * B[j]) % Mod;
		return D;
	}
};
namespace Seg{
	Poly T[N<<2];
	void Build(int h, int l, int r){
		int mid = (l + r) >> 1;
		if(l == r)T[h][0] = B[l], T[h][1] = A[l];
		else {
			Build(h << 1, l, mid), Build(h << 1 | 1, mid + 1, r);
			T[h] = T[h << 1] * T[h << 1 | 1];
		}
	}
	void Mdf(int h, int l, int r, int p, int x, int y){
		int mid = (l + r) >> 1;
		if(l == r){T[h][0] = x, T[h][1] = y;}
		else {
			if(p <= mid)Mdf(h << 1, l, mid, p, x, y);
			else Mdf(h << 1 | 1, mid + 1, r, p, x, y);
			T[h] = T[h << 1] * T[h << 1 | 1];
		}
	}
}
namespace Seg1{
	int t[N<<2];
	void Mdf(int h, int l, int r, int p, int x){
		int mid = (l + r) >> 1;
		if(l == r)t[h] = x;
		else {
			if(p <= mid)Mdf(h << 1, l, mid, p, x);
			else Mdf(h << 1 | 1, mid + 1, r, p, x);
			t[h] = t[h << 1] * t[h << 1 | 1] % Mod;
		}
	}
}
void solve(){
	read(p);
	For(i, 1, n)Seg1::Mdf(1, 1, n, i, (A[i] + B[i]) % Mod);
	Seg::Build(1, 1, n);
	while(p--){
		int u, x, y;
		read(u), read(x), read(y);
		((x %= Mod) += Mod) %= Mod, ((y %= Mod) += Mod) %= Mod;
		Seg1::Mdf(1, 1, n, u, (x + y) % Mod);
		Seg::Mdf(1, 1, n, u, y, x);
		int ans = Seg1::t[1];
		For(i, 0, C)
			ans = (ans + Mod - Seg::T[1][i]) % Mod;
		printf("%d\n", ans);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
