#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i, u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N = 200100, INF = 0x3f3f3f3f, M = 500010;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
}
int Begin[N], Next[M], to[M], e, n, m, q, rt[N];
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
struct Segment_tree{
	#define Lc lc[h],l,Mid
	#define Rc rc[h],Mid+1,r
	#define Mid ((l+r)>>1)
	int S[N*30][2],lc[N*30],rc[N*30],cnt, A[N*30];
	inline void pushup(int h){
		S[h][0] = S[lc[h]][0] + S[rc[h]][0];
		S[h][1] = S[lc[h]][1] + S[rc[h]][1];
	}
	inline void Modify(int &h,int l,int r,int pos){
		if(!h)h=++cnt;
		if(l==r){
			A[h] ++;
			if(A[h] % 2)S[h][0] = 0, S[h][1] = 1;
			else S[h][0] = 1, S[h][1] = 0;
			return ;
		}
		pos<=Mid?Modify(Lc,pos):Modify(Rc,pos);
		pushup(h);
	}
	inline int Query(int h,int l,int r,int pos, int tp){
		if(r <= pos)return S[h][tp];
		if(pos > Mid)return Query(Lc, pos, tp) + Query(Rc, pos, tp);
		else return Query(Lc, pos, tp);
	}
	int Merge(int u,int v,int l,int r){
		if(!u||!v)return u+v;
		if(l==r){
			A[u] += A[v];
			if(A[u] % 2)S[u][0] = 0, S[u][1] = 1;
			else S[u][0] = 1, S[u][1] = 0;
			return u;
		}
		lc[u]=Merge(lc[u],lc[v],l,Mid);
		rc[u]=Merge(rc[u],rc[v],Mid+1,r);
		pushup(u);
		return u;
	}
}T;
const int L = 1e6;
int a[N];
typedef pair<int, int> pii;
struct Qe{
	int id, y, tp;
};
vector<Qe> Q[N];
int pre[N], dfs_cnt, son[N], ans[N];
int dfs(int u, int fa){
	int lowu = pre[u] = ++dfs_cnt, lowv;
	Rep(i, u)if(v^fa){
		if(!pre[v]){
			lowv = dfs(v, u);
			lowu = min(lowu, lowv);
			if(lowv < pre[u])son[u] = v;
			else 
				rt[u] = T.Merge(rt[u], rt[v], 1, 1e6);
		}else if(pre[v] < pre[u])lowu = min(lowu, pre[v]);
	}
	int S = Q[u].size();
	T.Modify(rt[u], 1, 1e6, a[u]);
	For(i, 0, S - 1)
		ans[Q[u][i].id] = T.Query(rt[u], 1, 1e6, Q[u][i].y, Q[u][i].tp);
	if(son[u])rt[u] = T.Merge(rt[u], rt[son[u]], 1, 1e6);
	return lowu;
}
void init(){
	read(n), read(m);
	For(i, 1, n)read(a[i]);
	For(i, 1, m){
		int x, y;
		read(x), read(y);
		add(x, y), add(y, x);
	}
	read(q);
	For(i, 1, q){
		int u, y, tp;
		read(tp), read(u), read(y);
		Q[u].push_back((Qe){i, y, tp});
	}
	dfs(1, 0);
}
void solve(){
	For(i, 1, q)printf("%d\n", ans[i]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
