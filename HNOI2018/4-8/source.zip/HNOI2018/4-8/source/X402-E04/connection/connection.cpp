#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i, u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ull unsigned long long
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c = getchar();
	while( isdigit(c))x = x * 10 + c - 48, c = getchar();
}
int Begin[N], Next[N<<1], to[N<<1], e, deg[N];
int n, m;
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e; deg[x] ++;
}
int ans = INF;
int pre[N], dfs_cnt, tot;
int cnt[N];
ull w[N], val[N];
vector<int>G[N];
void dfs(int u){
	pre[u] = ++dfs_cnt;
	Rep(i, u)
		if(!pre[v])G[u].push_back(v), dfs(v);
		else if(pre[v] > pre[u]){
			w[++tot] = (ull)rand() * rand() * rand();
			val[v] ^= w[tot], val[u] ^= w[tot];
			cnt[u] --, cnt[v]++;
		}	
}
void dfs1(int u){
	int S = G[u].size();
	For(i, 0, S - 1){
		int v = G[u][i];
		dfs1(v);
		val[u] ^= val[v];
		cnt[u] += cnt[v];
	}
	if(u != 1)w[++tot] = val[u];
}
void init(){
	srand(time(0));
	read(n), read(m);
	For(i, 1, m){
		int x, y;
		read(x), read(y);
		add(x, y), add(y, x);
	}
	For(i, 1, n)ans = min(ans, deg[i]);
	dfs(1);
	dfs1(1);
	For(i, 2, n)ans = min(ans, cnt[i] + 1);
}
inline void file(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
}
int dfs_cl;
void Dfs(int now, int &Ans, int cnt, ull vv){
	if(cnt >= Ans)return;
	if(vv == 0 && cnt)
		return void (Ans = min(Ans, cnt));
	if(now > tot)return ;
	++dfs_cl;
	if(dfs_cl > 60000000){
		printf("%d\n", ans);
		exit(0);
	}
	Dfs(now + 1, Ans, cnt, vv);
	Dfs(now + 1, Ans, cnt + 1, vv ^ w[now]);
}
void solve(){
	Dfs(1, ans, 0, 0);
	printf("%d\n", ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
