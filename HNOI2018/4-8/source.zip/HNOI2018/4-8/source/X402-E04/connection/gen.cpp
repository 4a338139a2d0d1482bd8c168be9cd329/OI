#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
const int N = 1000;
int deg[N];
int main(){
	freopen("connection.in","w",stdout);
	srand(time(0));
	int n = 300, m = 1000;
	printf("%d %d\n", n, m);
	m -= n - 1;
	For(i, 2, n){
		int x;
		printf("%d %d\n", i, x = rand() % (i - 1) + 1);
		deg[x] ++, deg[i]++;
	}
	int ave = 2 * m / n;
	For(i, 1, n){
		while(deg[i] < ave){
			int x = rand() % n + 1;
			while(x == i)x = rand() %  n + 1;
			deg[i] ++, deg[x]++;
			m--;
			printf("%d %d\n", i, x);
		}
	}
	while(m --){
		int u = rand() % n + 1, x = rand() % n + 1;
		while(x == u)x = rand() % n + 1;
		printf("%d %d\n", u, x);
	}
	return 0;
}
