#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=10007;
const int maxn=1e5+10;

int n,a[maxn],b[maxn],ans,C,q,totans;

/*ll fpm(ll a,ll b){
	ll ret=1ll;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}*/

int fpm(int a,int b){
	int ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
void inv(int *a,int *b,int n){
	if(n==1){
		b[0]=fpm(a[0],mod-2);
		return;
	}
	//int nn=(int)(ceil(1.0*n/2));
	int nn=n>>1;
	inv(a,b,nn);
	static int tmp[maxn],tmp2[maxn];
	for(int i=0;i<n*2;++i)tmp[i]=tmp2[i]=0;
	for(int i=0;i<nn;++i)
		for(int j=0;j<nn;++j)
			(tmp[i+j]+=b[i]*b[j]%mod)%=mod;
	for(int i=0;i<n;++i)
		for(int j=0;j<n-i;++j)
			(tmp2[i+j]+=a[i]*tmp[j]%mod)%=mod;
	for(int i=0;i<n;++i)
		b[i]=(2*b[i]-tmp2[i]+mod)%mod;
}

int f[maxn],g[maxn],h[maxn];

void mul(int *a,int *b,int n){
	static int tmp[maxn];
	for(int i=0;i<n;++i)tmp[i]=0;
	for(int i=0;i<n;++i)
		for(int j=0;j<n-i;++j)
			(tmp[i+j]+=a[i]*b[j]%mod)%=mod;
	for(int i=0;i<n;++i)
		a[i]=tmp[i];
}
void solve(){
	scanf("%d%d",&n,&C);
	for(int i=1;i<=n;++i){
		scanf("%d",a+i);
		a[i]%=mod;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",b+i);
		b[i]%=mod;
	}

	totans=1;
	for(int i=1;i<=n;++i)
		totans=totans*(a[i]+b[i])%mod;
	
	f[0]=1;
	for(int i=1;i<=n;++i){
		g[0]=a[i];g[1]=b[i];
		mul(f,g,32);
	}
	
	scanf("%d",&q);
	for(int id,x,y,tmpans;q--;){
		scanf("%d%d%d",&id,&x,&y);
		
		totans=totans*fpm(a[id]+b[id],mod-2)%mod;
		totans=totans*(x+y)%mod;
		
		g[0]=a[id];g[1]=b[id];
		inv(g,h,32);mul(f,h,32);

		g[0]=x;g[1]=y;
		mul(f,g,32);
		
		tmpans=0;
		for(int i=0;i<C;++i)
			(tmpans+=f[i])%=mod;
		a[id]=x;b[id]=y;
		
		tmpans=(totans-tmpans+mod)%mod;
		//cerr<<tmpans<<endl;
		printf("%d\n",tmpans);
	}
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
