#include<bits/stdc++.h>
using namespace std;
void solve(){
	cerr<<"FUCK_YOU"<<endl;
}
int main(){
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	solve();
	fclose(stdin);
	fclose(stdout);
}
