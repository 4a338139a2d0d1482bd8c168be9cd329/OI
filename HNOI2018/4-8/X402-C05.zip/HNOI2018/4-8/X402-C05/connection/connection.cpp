#include<bits/stdc++.h>
using namespace std;
const int maxn=510;
int n,m;
vector<int> G[maxn];
namespace WORK{
	vector<int> A,B;
	int vis[20],ans=INT_MAX;
	void chk(){
		int ret=0;
		for(int i=0,u;i<A.size();++i){
			u=A[i];
			for(int j=0,v;j<G[u].size();++j){
				v=G[u][i];
				if(v!=vis[i]){
					++ret;
				}
			}
		}
		
		//ans=min(ans,ret);

		if(ans>ret){
			ans=ret;
			/*for(int i=0;i<A.size();++i){
				cerr<<A[i]<<" ";
			}
			cerr<<endl;
			for(int i=0;i<B.size();++i){
				cerr<<B[i]<<" ";
			}
			cerr<<endl;*/
		}
	}
	void work(){
		int S=1<<n;
		for(int s=1;s<S-1;++s){
			A.clear();
			B.clear();
			memset(vis,0,sizeof vis);
			for(int i=0;i<n;++i){
				if((s>>i)&1){
					A.push_back(i+1);
					vis[i]=1;
				}
				else{
					B.push_back(i+1);
				}
			}
			chk();
		}
		printf("%d\n",ans);
	}
}
void solve(){
	scanf("%d%d",&n,&m);
	if(m==n-1){
		puts("1");
		return;
	}
	for(int i=1,u,v;i<=m;++i){
		scanf("%d%d",&u,&v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	if(n<=10){
		WORK::work();
		return;
	}

}
int main(){
	freopen("connection.in","r",stdin);
	freopen("connection.out","w",stdout);
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
