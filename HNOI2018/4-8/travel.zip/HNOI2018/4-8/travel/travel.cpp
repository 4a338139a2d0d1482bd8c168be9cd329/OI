#include <cstring>
#include <ctime>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;

#define debug(...) fprintf(stderr,__VA_ARGS__)

#define x first
#define y second
#define mp make_pair
#define pii pair<int,int>

const int MAXN=100000,MAXC=20;
const int Mod=10007;

int N,C;

pii A[MAXN+10];

struct SegTree
{
	int dp[(MAXN<<3)+10][MAXC+10];
	int sum[(MAXN<<3)+10];;

	void update(int x)
	{
		for (int i=0;i<C;i++) dp[x][i]=0;
		for (int i=0;i<C;i++)
			for (int j=0;j<=i;j++)
				dp[x][i]=(1LL*dp[x<<1][j]*dp[x<<1|1][i-j]+dp[x][i])%Mod;
		sum[x]=1LL*sum[x<<1]*sum[x<<1|1]%Mod;
		return ;
	}

	void newnode(int x,int k)
	{
		for (int i=0;i<C;i++) dp[x][i]=0;
		dp[x][0]=A[k].y; dp[x][1]=A[k].x;
		sum[x]=(A[k].x+A[k].y)%Mod;
		return ;
	}

	void build(int x,int l,int r)
	{
		if (l==r) { newnode(x,l); return ; }
		int mid=(l+r)>>1;
		build(x<<1,l,mid); build(x<<1|1,mid+1,r);
		update(x);
		return ;
	}

	void modify(int x,int l,int r,int k)
	{
		if (l==r) { newnode(x,l); return ; }
		int mid=(l+r)>>1;
		if (k<=mid) modify(x<<1,l,mid,k);
		else modify(x<<1|1,mid+1,r,k);
		update(x);
		return ;
	}
}seg;

void init()
{
	scanf("%d%d",&N,&C);
	for (int i=1;i<=N;i++) scanf("%d",&A[i].x);
	for (int i=1;i<=N;i++) scanf("%d",&A[i].y);
	
	seg.build(1,1,N);

	int p; scanf("%d",&p);
	while (p--) {
		int id,x,y; scanf("%d%d%d",&id,&x,&y);
		A[id]=mp(x,y);
		seg.modify(1,1,N,id);
		
		int ans=0;

		for (int i=0;i<C;i++)
			ans=(ans+seg.dp[1][i])%Mod;
		
		printf("%d\n",(seg.sum[1]-ans+Mod)%Mod); }

	return ;
}

int main()
{
	freopen("relativnost.in","r",stdin);
	freopen("relativnost.out","w",stdout);
	init();
	fclose(stdin);
	fclose(stdout);
	debug("%.3lf\n",(1.0*clock())/(1.0*CLOCKS_PER_SEC)); 
	return 0;
}
