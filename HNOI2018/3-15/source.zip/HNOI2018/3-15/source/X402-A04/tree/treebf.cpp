#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
const int inf=0x3f3f3f3f;
int head[N],cnt=0;
struct node
{
	int to,next,w;
}e[N<<1];
inline void add(int x,int y,int w)
{
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],w};head[y]=cnt;
}
int n,K;
ll stk[N*20]; int top=0;

int now=0;
void dfs(int u,int fa,ll d)
{
	if(now<u) stk[++top]=d;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,u,d+e[i].w);
	}
}

void wj()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
int main()
{
	wj();
	n=read(); K=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read(),w=read();
		add(x,y,w);
	}
	for(int i=1;i<=n;++i) now=i,dfs(i,0,0);
	sort(stk+1,stk+1+top);
	for(int i=top;i>=top-K+1;--i) printf("%lld\n",stk[i]);
	//for(int i=1;i<=top;++i) if(stk[i]==9432598360ll) cerr<<top-i+1<<' ';
	//cerr<<endl;
	//cerr<<"K-1 : "<<stk[top-K+2]<<endl;
	//cerr<<stk[top-K+1]<<endl;
	return 0;
}
