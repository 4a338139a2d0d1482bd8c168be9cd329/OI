#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
const int inf=0x3f3f3f3f;
int head[N],cnt=0;
struct node
{
	int to,next,w;
}e[N<<1];
inline void add(int x,int y,int w)
{
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],w};head[y]=cnt;
}
int n,K;

ll Ans[N]; int tot=0;
namespace seg
{
	ll maxv[N<<2],add[N<<2],dep[N];
	int dfn[N],efn[N],clk=0,rnk[N];
	void dfs1(int u,int fa,ll d)
	{
		dep[u]=d; dfn[u]=++clk; rnk[clk]=u;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa) continue;
			dfs1(v,u,d+e[i].w);
		}
		efn[u]=clk;
	}

	void build(int o,int l,int r)
	{
		if(l==r) {maxv[o]=dep[rnk[l]]; return ;}
		int mid=l+r>>1;
		build(o<<1,l,mid); build(o<<1|1,mid+1,r);
		maxv[o]=max(maxv[o<<1],maxv[o<<1|1]);
	}
	inline void pushdown(int o)
	{
		if(add[o])
		{
			add[o<<1]+=add[o]; add[o<<1|1]+=add[o];
			maxv[o<<1]+=add[o]; maxv[o<<1|1]+=add[o];
			add[o]=0;
		}
	}
	void update(int o,int l,int r,int x,int y,int k)
	{
		if(x<=l&&r<=y) {maxv[o]+=k; add[o]+=k; return ;}
		pushdown(o);
		int mid=l+r>>1;
		if(x<=mid) update(o<<1,l,mid,x,y,k);
		if(y>mid) update(o<<1|1,mid+1,r,x,y,k);
		maxv[o]=max(maxv[o<<1],maxv[o<<1|1]);
	}
	void print(int wh,int o,int l,int r,ll lim)
	{
		if(l==r) 
		{
			if(rnk[l]<wh) Ans[++tot]=maxv[o];
			return ;
		}
		pushdown(o);
		int mid=l+r>>1;
		if(maxv[o<<1]>lim) print(wh,o<<1,l,mid,lim);
		if(maxv[o<<1|1]>lim) print(wh,o<<1|1,mid+1,r,lim);
	}
	ll query(int o,int l,int r,int x)
	{
		if(l==r) return maxv[o];
		pushdown(o);
		int mid=l+r>>1;
		if(x<=mid) return query(o<<1,l,mid,x);
		else return query(o<<1|1,mid+1,r,x);
	}

	void dfs(int u,int fa,ll lim)
	{
		//if(u==4) cerr<<query(1,1,n,rnk[1])<<' ';
		print(u,1,1,n,lim);
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(v==fa) continue;
			update(1,1,n,1,n,e[i].w);
			update(1,1,n,dfn[v],efn[v],-2*e[i].w);
			dfs(v,u,lim);
			update(1,1,n,1,n,-e[i].w);
			update(1,1,n,dfn[v],efn[v],2*e[i].w);
		}
	}
	void solve(ll lim) //>=lim
	{
		dfs1(1,0,0);
		build(1,1,n);
		dfs(1,0,lim);
	}
}

vector<ll>ve[2][N];
vector<int>ch[N];
int all=0,U=0;

int sz[N],mx[N],rt,nn;
bool vis[N];
void findrt(int u,int fa)
{
	mx[u]=0; sz[u]=1;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa||vis[v]) continue;
		findrt(v,u);
		sz[u]+=sz[v];
		mx[u]=max(mx[u],sz[v]);
	}
	mx[u]=max(mx[u],nn-sz[u]);
	if(mx[u]<mx[rt]) rt=u;
}
void getdep(int wh,int u,int fa,ll d,bool typ)
{
	ve[typ][wh].pb(d);
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa||vis[v]) continue;
		getdep(wh,v,u,d+e[i].w,typ);
	}
}
void dfs(int u)
{
	vis[u]=1;
	//ve[0][u].reserve(sz[u]);
	getdep(u,u,0,0,0);
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(vis[v]) continue;
		all++;
		getdep(all,v,u,e[i].w,1);
		ch[u].pb(all);
		rt=0; nn=sz[v]; findrt(v,u);
		dfs(rt);
	}
}

ll calc(int wh,ll mid,bool typ)
{
	int p2=ve[typ][wh].size()-1,siz=ve[typ][wh].size();
	ll ans=0;
	for(int i=0;i<siz;++i)
	{
		while(p2>=0&&ve[typ][wh][i]+ve[typ][wh][p2]>mid) p2--;
		ans+=siz-1-p2;
	}
	for(int i=0;i<siz;++i) ans-=(ve[typ][wh][i]*2>mid);
	return (ans>>1);
}
bool judge(ll mid)
{
	ll ans=0;
	for(int i=1;i<=n;++i)
	{
		ans+=calc(i,mid,0);
		//cerr<<i<<' '<<ans<<endl;
		for(int j=0,siz=ch[i].size();j<siz;++j)
			ans-=calc(ch[i][j],mid,1);
		if(ans>K-1) return 1;
	}
	//cout<<ans<<endl;
	return ans>K-1;
}

bool cmp(ll a,ll b) {return a>b;}

void wj()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
int main()
{
	wj();
	n=read(); K=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read(),w=read();
		add(x,y,w);
	}
	mx[0]=inf;
	rt=0; nn=n; findrt(1,0);
	dfs(rt);
	for(int i=1;i<=n;++i) sort(ve[0][i].begin(),ve[0][i].end());
	for(int i=1;i<=all;++i) sort(ve[1][i].begin(),ve[1][i].end());

	clock_t sta=clock();
	ll l=1,r=2e14+1;
	while(l<r)
	{
		ll mid=l+r>>1;
		if(judge(mid)) l=mid+1; //num > K-1
		else r=mid;
	}
	seg::solve(l);
	clock_t fin=clock();
	cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	
	sort(Ans+1,Ans+1+tot,cmp);
	if(tot>=K) cp;
	for(int i=1;i<=tot;++i) printf("%lld\n",Ans[i]);
	for(int i=tot+1;i<=K;++i) printf("%lld\n",l);
	//cerr<<l<<endl;
	//cerr<<all<<endl;
	return 0;
}
