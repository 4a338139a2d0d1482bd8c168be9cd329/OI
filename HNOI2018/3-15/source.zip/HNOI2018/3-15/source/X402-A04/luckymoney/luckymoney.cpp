#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=109;
int p[N],n,K,A[N][N],f[N][N];

void wj()
{
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);
}
int main()
{
	wj();
	n=read(); K=read();
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) A[i][j]=read();
	if(n<=10)
	{
		for(int i=1;i<=n;++i) p[i]=i;
		bool found=0;
		do
		{
			bool can=1;
			for(int i=1;i<=n;++i) if(A[i][p[i]]==-1) {can=0;break;}
			if(can)
			{
				int sum=0;
				for(int i=1;i<=n;++i) sum=(sum+A[i][p[i]])%K;
				if(!sum) {found=1;break;}
			}
		}while(next_permutation(p+1,p+1+n));
		if(found) puts("Yes");
		else puts("No");
		return 0;
	}
	memset(f,0,sizeof(f));
	f[0][0]=1;
	for(int i=1;i<=n;++i) for(int j=0;j<K;++j)
	{
		for(int k=1;k<=n;++k) if(A[i][k]!=-1)
		{
			f[i][j]|=f[i-1][(j-A[i][k]+K)%K];
			if(f[i][j]) break;
		}
	}
	if(!f[n][0]) {puts("No");return 0;}
	
	memset(f,0,sizeof(f));
	f[0][0]=1;
	for(int i=1;i<=n;++i) for(int j=0;j<K;++j)
	{
		for(int k=1;k<=n;++k) if(A[k][i]!=-1)
		{
			f[i][j]|=f[i-1][(j-A[k][i]+K)%K];
			if(f[i][j]) break;
		}
	}
	if(!f[n][0]) {puts("No");return 0;}

	bool can=0;
	for(int o=1;o<=n;++o) if(A[n][o]!=-1)
	{
		memset(f,0,sizeof(f));
		f[0][0]=1;
		for(int i=1;i<n;++i) for(int j=0;j<K;++j)
		{
			for(int k=1;k<=n;++k) if(k!=o&&A[i][k]!=-1)
			{
				f[i][j]|=f[i-1][(j-A[i][k]+K)%K];
				if(f[i][j]) break;
			}
		}
		if(f[n-1][(0-A[n][o]+K)%K]) {can=1;break;}
	}
	if(!can) {puts("No");return 0;}
	puts("Yes");
	return 0;
}
