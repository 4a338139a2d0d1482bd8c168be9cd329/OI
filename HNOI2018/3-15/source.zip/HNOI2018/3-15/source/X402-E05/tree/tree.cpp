#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ALL(x) x.begin(),x.end()
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(register int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(register int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=200010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
int n,cnt;
int bgn[N],nxt[N<<1],to[N<<1],E;
LL w[N<<1],K,ans[N<<1];
inline void add_edge(int u,int v,LL ew){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v,w[E]=ew;}
namespace RMQ
{
	int lg2[N<<1],pos[N],dfs_time;
	LL dep[N],Rmq[N<<1][19],Maxdep;
	void Dfs(int u,int f)
	{
		chkmax(Maxdep,dep[u]);
		Rmq[pos[u]=++dfs_time][0]=dep[u];
		for(int v,i=bgn[u];i;i=nxt[i])
		{
			if((v=to[i])==f)continue;
			dep[v]=dep[u]+w[i];
			Dfs(v,u);
			Rmq[++dfs_time][0]=dep[u];
		}
	}
	inline LL Query(int x,int y)
	{
		x=pos[x],y=pos[y];
		if(x>y)swap(x,y);
		register int ret=lg2[y-x+1];
		return min(Rmq[x][ret],Rmq[y-(1<<ret)+1][ret]);
	}
	inline LL Get(int x,int y){return dep[x]+dep[y]-(Query(x,y)<<1);}
	inline void init()
	{
		Dfs(1,0);
		For(i,1,dfs_time)lg2[i]=i>=1<<(lg2[i-1]+1)?lg2[i-1]+1:lg2[i-1];
		For(i,1,18)
			For(j,1,dfs_time-(1<<i)+1)
				Rmq[j][i]=min(Rmq[j][i-1],Rmq[j+(1<<(i-1))][i-1]);
	}
}
namespace DT
{
	int fa[N];
	vector<LL>G[N],D[N];
	inline LL Get_num(vector<LL>&x,LL d)
	{
		if(x.empty()||(x.back()<<1ll)<d)return 0;
		int Size=SZ(x);
		int pos=Size;LL ret=0;
		For(i,0,Size-1)
		{
			while(pos&&x[pos-1]+x[i]>=d)pos--;
			ret+=Size-pos;
		}
		return ret;
	}
	inline LL Get_num(LL d)
	{
		LL ret=0;
		For(i,1,n)ret+=Get_num(G[i],d)-Get_num(D[i],d);
		return ret;
	}
	inline LL Solve()
	{
		For(u,1,n)for(int x=u;x;x=fa[x])
		{
			G[x].pb(RMQ::Get(x,u));
			if(fa[x])D[x].pb(RMQ::Get(fa[x],u));
		}
		For(i,1,n)sort(ALL(G[i])),sort(ALL(D[i]));
		LL l=1,r=RMQ::Maxdep<<1ll,ans=0;
		while(l<=r)
		{
			LL mid=(l+r)>>1ll;
			if(Get_num(mid)>=K<<1ll)ans=mid,l=mid+1;
			else r=mid-1;
		}
		return ans;
	}
}
int vis[N],rt,sz[N];
inline void dfs_root(int u,int f,int tot)
{
	sz[u]=1;
	int flag=1;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f||vis[v])continue;
		dfs_root(v,u,tot);
		sz[u]+=sz[v];
		if(sz[v]>(tot>>1))flag=0;
	}
	if(tot-sz[u]>tot>>1)flag=0;
	if(flag)rt=u;
}
namespace Answer
{
	multiset<LL>S;
	multiset<LL>::iterator it;
	vector<LL>G,E;
	LL dis;
	inline void dfs_ans(int u,int f,LL W)
	{
		it=S.end();it--;
		while(1)
		{
			LL x=*it+W;
			if(x>dis)G.pb(x);
			else if(x==dis){if(SZ(E)>=K)break;else E.pb(x);}
			else break;
			if(it==S.begin())break;
			it--;
		}
		for(int v,i=bgn[u];i;i=nxt[i])
		{
			if((v=to[i])==f||vis[v])continue;
			dfs_ans(v,u,W+w[i]);
		}
	}
	inline void dfs_ins(int u,int f,LL W)
	{
		S.insert(W);
		for(int v,i=bgn[u];i;i=nxt[i])
		{
			if((v=to[i])==f||vis[v])continue;
			dfs_ins(v,u,W+w[i]);
		}
	}
	inline void Solve(int u,int tot)
	{
		rt=u;dfs_root(u,0,tot);u=rt;
		vis[u]=1;
		S.clear();S.insert(0);
		for(int v,i=bgn[u];i;i=nxt[i])
		if(!vis[v=to[i]])
		{
			dfs_ans(v,0,w[i]);
			dfs_ins(v,0,w[i]);
		}
		for(int v,i=bgn[u];i;i=nxt[i])
			if(!vis[v=to[i]])
				Solve(v,sz[v]>=sz[u]?tot-sz[u]:sz[v]);
	}
	inline void Get_seq()
	{
		For(i,0,SZ(G)-1)ans[++cnt]=G[i];
		For(i,0,SZ(E)-1)ans[++cnt]=E[i];
	}
}
inline void Solve(int u,int f,int tot)
{
	rt=u;dfs_root(u,0,tot);u=rt;
	DT::fa[u]=f;vis[u]=1;
	for(int v,i=bgn[u];i;i=nxt[i])
		if(!vis[v=to[i]])
			Solve(v,u,sz[v]>=sz[u]?tot-sz[u]:sz[v]);
}
int main()
{
	int x,y,z;
	file();
	read(n),read(K);
	For(i,2,n)
	{
		read(x),read(y),read(z);
		add_edge(x,y,z),add_edge(y,x,z);
	}
	RMQ::init();
	Solve(1,0,n);
	mem(vis,0);
	Answer::dis=DT::Solve();
	Answer::Solve(1,n);
	Answer::Get_seq();
	sort(ans+1,ans+cnt+1);
	rFor(i,cnt,cnt-K+1)printf("%lld\n",ans[i]);
	return 0;
}
