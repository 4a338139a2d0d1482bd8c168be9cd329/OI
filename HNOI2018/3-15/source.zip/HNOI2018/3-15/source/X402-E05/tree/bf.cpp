#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=200010;
const int M=4000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("tree.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,cnt;
int bgn[N],nxt[N<<1],to[N<<1],E;
LL w[N<<1],K,a[M],dis[N];
inline void add_edge(int u,int v,LL ew){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v,w[E]=ew;}
inline void bfs(int S)
{
	queue<int>q;
	For(i,1,n)dis[i]=0;
	q.push(S);
	while(!q.empty())
	{
		int u=q.front();q.pop();
		for(int v,i=bgn[u];i;i=nxt[i])
		if(!dis[v=to[i]])
		{
			dis[v]=dis[u]+w[i];
			q.push(v);
		}
	}
	For(i,S+1,n)a[++cnt]=dis[i];
}
int main()
{
	int x,y,z;
	file();
	read(n),read(K);
	For(i,2,n)
	{
		read(x),read(y),read(z);
		add_edge(x,y,z),add_edge(y,x,z);
	}
	For(i,1,n)bfs(i);
	sort(a+1,a+cnt+1);
	rFor(i,cnt,cnt-K+1)printf("%lld ",a[i]);
	return 0;
}
