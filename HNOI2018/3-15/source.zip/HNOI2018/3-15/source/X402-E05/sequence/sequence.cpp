#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define lc p<<1
#define rc p<<1|1
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=200010;
const int inf=0x3f3f3f3f;
const int ALL=(1<<20)-1;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
}
int n,m,a[N];
int Max[N<<3],Or[N<<3],Ad[N<<3];
int So[N<<3],Sa[N<<3];
inline void pushup(int p)
{
	So[p]=So[lc]|So[rc];
	Sa[p]=Sa[lc]&Sa[rc];
	Max[p]=max(Max[lc],Max[rc]);
}
inline void Build(int l,int r,int p)
{
	Ad[p]=ALL;
	if(l==r){So[p]=Sa[p]=Max[p]=a[l];return;}
	int mid=(l+r)>>1;
	Build(ls,lc),Build(rs,rc);
	pushup(p);
}
inline void Ad_node(int p,int x){Max[p]-=So[p]&~x;So[p]&=x,Sa[p]&=x;Ad[p]&=x,Or[p]&=x;}
inline void Or_node(int p,int x){Max[p]+=(~(So[p]&x))&x;So[p]|=x,Sa[p]|=x,Or[p]|=x;}
inline void pushdown(int p)
{
	if(Ad[p]!=ALL)
	{
		Ad_node(lc,Ad[p]);
		Ad_node(rc,Ad[p]);
		Ad[p]=ALL;
	}
	if(Or[p]!=0)
	{
		Or_node(lc,Or[p]);
		Or_node(rc,Or[p]);
		Or[p]=0;
	}
}
inline void Ad_tree(int l,int r,int p,int x,int y,int z)
{
	if(x<=l&&r<=y&&(So[p]&~z)==(Sa[p]&~z)){Ad_node(p,z);return;}
	int mid=(l+r)>>1;pushdown(p);
	if(x<=mid)Ad_tree(ls,lc,x,y,z);
	if(y> mid)Ad_tree(rs,rc,x,y,z);
	pushup(p);
}
inline void Or_tree(int l,int r,int p,int x,int y,int z)
{
	if(x<=l&&r<=y&&(So[p]&z)==(Sa[p]&z)){Or_node(p,z);return;}
	int mid=(l+r)>>1;pushdown(p);
	if(x<=mid)Or_tree(ls,lc,x,y,z);
	if(y> mid)Or_tree(rs,rc,x,y,z);
	pushup(p);
}
inline int Query(int l,int r,int p,int x,int y)
{
	if(x<=l&&r<=y)return Max[p];
	int mid=(l+r)>>1,ret=0;pushdown(p);
	if(x<=mid)chkmax(ret,Query(ls,lc,x,y));
	if(y> mid)chkmax(ret,Query(rs,rc,x,y));
	return ret;
}
int main()
{
	int type,x,y,z;
	file();
	read(n),read(m);
	For(i,1,n)read(a[i]);
	Build(1,n,1);
	while(m--)
	{
		read(type),read(x),read(y);
		if(type<=2)
		{
			read(z);
			type==1?Ad_tree(1,n,1,x,y,z):Or_tree(1,n,1,x,y,z);
		}
		else printf("%d\n",Query(1,n,1,x,y));
	}
	cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
