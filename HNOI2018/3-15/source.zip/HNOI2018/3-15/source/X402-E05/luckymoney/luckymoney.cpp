#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=110;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);
}
int n,k,a[N][N],p[N],vis[N];
inline bool dfs(int now)
{
	if(now==n+1)
	{
		int ret=0;
		For(i,1,n)ret+=a[i][p[i]];
		return ret%k==0;
	}
	For(i,1,n)
	if(!vis[i]&&a[now][i]!=-1)
	{
		vis[i]=1,p[now]=i;
		if(dfs(now+1))return 1;
		vis[i]=0;
	}
	return 0;
}
int main()
{
	file();
	read(n),read(k);
	For(i,1,n)For(j,1,n)read(a[i][j]);
	dfs(1)?puts("Yes"):puts("No");
	return 0;
}
