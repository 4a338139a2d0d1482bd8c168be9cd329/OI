#include<bits/stdc++.h>
using namespace std;

int b[201],vis[201],a[201][201];
int flag=0,n,k;

namespace buf{
	void mo(){
		int ret=0;
		for(int i=1; i<=n; ++i){
			ret+=a[i][b[i]];
			if(a[i][b[i]]==-1)return;
		}
		if(ret%k==0) flag=1;
	}
	void dfs(int x){
		for(int i=1; i<=n; ++i){
			if(!vis[i]){
				b[x]=i;
				vis[i]=1;
				if(x<n)dfs(x+1); else mo();
				vis[i]=0;
			}
		}
	
	}
	void solve(){
		freopen("luckmoney.in", "r", stdin);
		freopen("luckmoney.out", "w", stdout);
		scanf("%d%d",&n,&k);

		for(int i=1; i<=n; ++i)
			for(int j=1; j<=n; ++j)
				scanf("%d",&a[i][j]);
		
		if(n<=10) dfs(1); else flag=rand()%2;
		puts(flag?"Yes":"No");
	}
}

int main(){
	buf::solve();
}
