#include<bits/stdc++.h>
#define pb push_back
#define sz size
#define getchar getchar_unlocked
#define ll long long 
using namespace std;
const int N=2e5+10;
int n,lim;
int e, bgn[N], tp[N<<1], to[N<<1], K, nxt[N<<1], w[N<<1];
int sz[N], vis[N];

vector<int> g,g1;
vector<ll> Ans;
ll dis[N],tot=0;
int hv,hvsz=0x3f3f3f3f;

struct node{
	int x,y;
	bool operator < (const struct node &xx)const{
		return dis[x]<dis[xx.x];
	}
};
bool cmp(int x,int y){
	return dis[x]<dis[y];
}
vector<node> gn;

namespace buf{
	inline int read(){
		char ch=getchar(); int x=0;
		while(!isdigit(ch))ch=getchar();
		while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
		return x;
	}
	void add(int x,int y,int z){
		to[++e]=y; w[e]=z; nxt[e]=bgn[x]; bgn[x]=e;
	}

	void dfs(int x,int f=0){
		for(int i=bgn[x]; i; i=nxt[i]){
			if(to[i]==f) continue;
			if(vis[to[i]]) continue;
			dis[to[i]]=dis[x]+w[i];
			dfs(to[i],x);
		}
	}
	
	void gtsn(int x,int f=0,int rt=0){
		g.pb(x);
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(y==f||vis[y]) continue;
			gtsn(y,x);
		}
	}

	ll cal(int x,ll k){
		int l=1, r=g.sz();
		ll ret=0;
		sort(g.begin(),g.end(),cmp);
		while(l<r){
			while(l<r&&dis[g[l-1]]+dis[g[r-1]]-2*dis[x]<k) ++l;
			ret+=(r-l); --r;
		}
		return ret;
	}

	void Cal(int x,ll k){
		int l=1, r=g.sz();
		gn.clear();
		for(int i=l;i<=r;++i) gn.pb((node){g[i-1],g1[i-1]});
		sort(gn.begin(),gn.end());
		while(l<r){
			while(l<r&&dis[gn[l-1].x]+dis[gn[r-1].x]-2*dis[x]<k) ++l;
			for(int j=l; j<r; ++j){
				if(gn[j-1].y!=gn[r-1].y){
					if(dis[gn[j-1].x]+dis[gn[r-1].x]-2*dis[x]>k){
						Ans.pb(dis[gn[j-1].x]+dis[gn[r-1].x]-2*dis[x]);		
					}
				}
			}
			--r;
		}
	}
	
	void Gtsn(int x,int f=0,int rt=0){
		g.pb(x); g1.pb(rt); 
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(y==f) continue;
			Gtsn(y,x,rt);
		}
	}

	void gtsz(int x,int f){
		sz[x]=1;
		for(int i=bgn[x]; i; i=nxt[i]){
			if(to[i]==f||vis[to[i]]) continue;
			gtsz(to[i],x);
			sz[x]+=sz[to[i]];
		}
	}

	void gthv(int x,int f){
		int ret=lim-sz[x];
		for(int i=bgn[x]; i; i=nxt[i]){
			if(to[i]==f||vis[to[i]]) continue;
			gthv(to[i],x);
			ret=max(ret,sz[to[i]]);
		}
		if(ret<hvsz) hvsz=ret,hv=x;
	}


	void find(int x,ll k){
		g.clear(); gtsn(x,0); vis[x]=1;
		tot+=cal(x,k);
		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			g.clear(); 
			gtsn(to[i],x,to[i]);
			tot-=cal(to[i],k-2*w[i]);
		}
		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			hvsz=0x3f3f3f3f;
			lim=sz[to[i]];
			gtsz(hv,x);
			gthv(hv,x);
			find(to[i],k);
		}
	}

	void Gfs(int x,ll k){
		g.clear(); g1.clear(); vis[x]=1;
		g.pb(x); g1.pb(x); 

		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			Gtsn(to[i],x,to[i]);
		}
		Cal(x,k);

		for(int i=bgn[x]; i; i=nxt[i]){
			if(vis[to[i]]) continue;
			hvsz=0x3f3f3f3f;
			lim=sz[to[i]];
			gtsz(hv,x);
			gthv(hv,x);
			Gfs(hv,k);
		}	
	}

	void gfs(int x,int f,ll k){
		g.clear(); g1.clear();
		g.pb(x); g1.pb(x);
		for(int i=bgn[x]; i; i=nxt[i]){
			if(to[i]==f) continue;
			Gtsn(to[i],x,to[i]);
		}
		Cal(x,k);
		for(int i=bgn[x]; i; i=nxt[i]){
			if(to[i]==f) continue;
			gfs(to[i],x,k);
		}
	}

	void solve(){
		
		ll l=1, r=(ll)2e9, ans=0;
		int x=0,y=0,z=0;
		n=read(); K=read();
		for(int i=1; i<n; ++i){
			x=read();y=read();z=read();
			add(x,y,z);add(y,x,z);
		}
		lim=n;
		hvsz=0x3f3f3f3f;
		gtsz(1,0);
		gthv(1,0);
		dfs(hv);
		int yv=hv;

		while(l<=r){
			lim=n; hvsz=0x3f3f3f3f;
			for(int j=1;j<=n;++j)vis[j]=0;
			ll mm=(l+r)/2; tot=0; find(yv,mm);
			if(tot>=K) ans=mm,l=mm+1;else r=mm-1;	
		}
		lim=n;
		for(int j=1;j<=n;++j)vis[j]=0;
		hvsz=0x3f3f3f3f;
		Gfs(yv,ans);
		for(int i=Ans.sz()+1; i<=K; ++i) Ans.pb(ans);
		sort(Ans.begin(),Ans.end());
		for(int i=0; i<(int)Ans.sz(); ++i) printf("%lld\n",Ans[K-1-i]);
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree1.out","w",stdout);
	buf::solve();
}
