#include<bits/stdc++.h>
#define rg register
#define putchar putchar_unlocked
#define getchar getchar_unlocked
using namespace std;
const int N=2e5+10;
int n,m;
namespace magicsegt{
	#define l(x) (x<<1)
	#define r(x) ((x<<1)|1)
	#define m ((l+r)>>1)
	inline int read(){
		char ch=getchar();
		int x(0);
		while(!isdigit(ch))ch=getchar();
		while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
		return x;
	}
	int addv[N<<2],andv[N<<2],orv[N<<2],mx[N<<2];
	inline void pd(int x,int l,int r){
		if(l==r)return;
		if(addv[x]){
			andv[l(x)]+=addv[x];orv[l(x)]+=addv[x];addv[l(x)]+=addv[x];mx[l(x)]+=addv[x];
			andv[r(x)]+=addv[x];orv[r(x)]+=addv[x];addv[r(x)]+=addv[x];mx[r(x)]+=addv[x];
			addv[x]=0;
		}
	}
	inline int ckmx(int a,int b){return a>b?a:b;}
	inline void mt(int x){
		andv[x]=andv[l(x)]&andv[r(x)];
		orv[x]=orv[l(x)]|orv[r(x)];
		mx[x]=ckmx(mx[l(x)],mx[r(x)]);
	}
	void init(int x,int l,int r){
		if(l==r){
			mx[x]=read();
			andv[x]=orv[x]=mx[x];
		}else{
			init(l(x),l,m);
			init(r(x),m+1,r);
			mt(x);
		}
	}
	void gtand(int x,int l,int r,int ql,int qr,int v){
		if(!(orv[x]&v))return;
		pd(x,l,r);
		if(ql<=l&&r<=qr){
			if((andv[x]&v)){
				addv[x]-=v;
				orv[x]-=v;
				andv[x]-=v;
				mx[x]-=v;
				return;
			}
		}
		if(l==r)return;
		if(ql<=m) gtand(l(x),l,m,ql,qr,v);
		 if(m<qr) gtand(r(x),m+1,r,ql,qr,v);
		mt(x);
	}
	void gtor(int x,int l,int r,int ql,int qr,int v){
		if((andv[x]&v))return;
		pd(x,l,r);
		if(ql<=l&&r<=qr){
			if(!(orv[x]&v)){
				addv[x]+=v;
				orv[x]+=v;
				andv[x]+=v;
				mx[x]+=v;
				return;
			}
		}
		if(l==r)return;
		if(ql<=m) gtor(l(x),l,m,ql,qr,v);
		 if(m<qr) gtor(r(x),m+1,r,ql,qr,v);
		mt(x);
	}
	int query(int x,int l,int r,int ql,int qr){
		if(ql<=l&&r<=qr){
			return mx[x];
		}else{
			pd(x,l,r);
			int d=0;
			if(ql<=m) d=ckmx(d,query(l(x),l,m,ql,qr));
			 if(m<qr) d=ckmx(d,query(r(x),m+1,r,ql,qr));
			return d;
		}
	}
	inline void out(int x){
		int buf[13],sz=0;
		buf[1]=0;
		while(x){buf[++sz]=x%10;x/=10;}
	  	sz=ckmx(sz,1);
		for(rg int i=sz;i>=1;--i)putchar(buf[i]+48);
		putchar('\n');
	}
	void solve(){
		int od,q,l,r,x;
		n=read();q=read();
		init(1,1,n);
		for(int i=1; i<=q; ++i){
			od=read(); l=read(); r=read();
			if(od!=3) x=read();
			if(od==1){
				for(rg int j=0; j<20; ++j) if(!((1<<j)&x)) gtand(1,1,n,l,r,(1<<j));
			}
			if(od==2){
				for(rg int j=0; j<20; ++j) if((1<<j)&x) gtor(1,1,n,l,r,(1<<j));
			}
			if(od==3){
				int ret=query(1,1,n,l,r);
				out(ret);
			}
		}
	}
}
using namespace magicsegt;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	magicsegt::solve();
}
