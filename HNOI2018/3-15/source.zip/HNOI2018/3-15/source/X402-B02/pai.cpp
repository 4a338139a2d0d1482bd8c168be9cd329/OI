#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("tree.in","w",stdout);
	int n=1000, m=100;

	srand(time(0));
	printf("%d %d\n",n,m);
	for(int i=2; i<=n; ++i){
		int x=i;
		int y=i-1;
		printf("%d %d %d\n",
			x,y,rand()%100);
	}
}
