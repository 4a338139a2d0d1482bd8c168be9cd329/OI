#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100;

int n, k, ans;
int a[N + 5][N + 5], vis[N + 5];

void dfs(int u, int v = 0) {
    if(u == n+1) {
        if(v == 0) {
            puts("Yes");
            exit(0);
        }
        return;
    }

    for(int i = 1; i <= n; ++i) if(!vis[i] && a[u][i] >= 0) {
        vis[i] = 1;
        dfs(u + 1, (v + a[u][i]) % k);
        vis[i] = 0;
    }
}

int main() {
    freopen("luckymoney.in", "r", stdin);
    freopen("luckymoney.out", "w", stdout);

    read(n), read(k);
    for(int i = 1; i <= n; ++i) 
        for(int j = 1; j <= n; ++j) read(a[i][j]);

    if(n <= 10) {
        dfs(1);
        puts("No");
    } else {
        static int p[N + 5];
        for(int i = 1; i <= n; ++i) p[i] = i;
        for(int i = 0; i < 1000000; ++i) {
            random_shuffle(p + 1, p + n + 1);

            int val = 0;
            for(int i = 1; i <= n; ++i) {
                if(a[i][p[i]] == -1) {
                    val = -1;
                    break;
                }
                val = (val + a[i][p[i]]) % k;
            }

            if(val == 0) {
                puts("Yes");
                return 0;
            }
        }
        puts("No");
    }

    return 0;
}
