#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;
const int S = (1 << 20) - 1;

namespace SEG {

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    const int SZ = N << 2;

    int os[SZ + 5], as[SZ + 5];
    int ot[SZ + 5], at[SZ + 5];
    int ad[SZ + 5], mx[SZ + 5];

    inline void push_down(int u) {
        if(at[u] < S) {
            int t = at[u] ^ S;

            mx[lc] -= (mx[lc] & t); 
            ot[lc] &= at[u], at[lc] &= at[u];
            os[lc] &= at[u], as[lc] &= at[u];

            mx[rc] -= (mx[rc] & t); 
            ot[rc] &= at[u], at[rc] &= at[u];
            os[rc] &= at[u], as[rc] &= at[u];

            at[u] = S;
        }
        if(ot[u] > 0) {

            mx[lc] |= ot[u]; ot[lc] |= ot[u];
            os[lc] |= ot[u], as[lc] |= ot[u];

            mx[rc] |= ot[u]; ot[rc] |= ot[u];
            os[rc] |= ot[u], as[rc] |= ot[u];

            ot[u] = 0;
        }
    }

    inline void push_up(int u) {
        as[u] = as[lc] & as[rc]; 
        os[u] = os[lc] | os[rc];
        mx[u] = std::max(mx[lc], mx[rc]); 
    }

    void build(int u, int l, int r) {
        ot[u] = 0;
        at[u] = S;
        if(l == r) { os[u] = as[u] = read(mx[u]); return; }
        
        build(lc, l, mid);
        build(rc, mid+1, r);
        push_up(u);
    }

    void modify_o(int u, int l, int r, int x, int y, int z) {
        if(x <= l && r <= y) {
            if((os[u] & z) == (as[u] & z)) {
                mx[u] += z ^ (as[u] & z);
                os[u] |= z, as[u] |= z;
                ot[u] |= z;
                return;
            } 
        }
        push_down(u);

        if(x <= mid) modify_o(lc, l, mid, x, y, z);
        if(mid < y) modify_o(rc, mid+1, r, x, y, z);

        push_up(u);
    }

    void modify_a(int u, int l, int r, int x, int y, int z) {
        if(x <= l && r <= y) {
            int t = z ^ S;
            if((os[u] & t) == (as[u] & t)) {
                mx[u] -= (as[u] & t);
                os[u] &= z, as[u] &= z;
                ot[u] &= z, at[u] &= z;
                return;
            }
        }
        push_down(u);

        if(x <= mid) modify_a(lc, l, mid, x, y, z);
        if(mid < y) modify_a(rc, mid+1, r, x, y, z);

        push_up(u);
    }

    int query(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return -oo;
        if(x <= l && r <= y) return mx[u];
        push_down(u);
        return std::max(query(lc, l, mid, x, y), query(rc, mid+1, r, x, y));
    }
}

int n, m;
int main() {
    freopen("sequence.in", "r", stdin);
    freopen("sequence.out", "w", stdout);

    using namespace SEG;

    read(n), read(m);
    build(1, 1, n);

    for(int i = 1; i <= m; ++i) {
        static int op, x, y, z;

        read(op), read(x), read(y);
        if(op <= 2) read(z);

        if(op == 1) modify_a(1, 1, n, x, y, z);
        if(op == 2) modify_o(1, 1, n, x, y, z);
        if(op == 3) printf("%d\n", query(1, 1, n, x, y));
    }

    return 0;
}
