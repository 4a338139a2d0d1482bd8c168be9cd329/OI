#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;
const int M = 400000;

typedef pair<ll, int> pli;

struct Heapnode {
    ll v;
    int b, l, r;

    Heapnode(ll _v = 0, int _b = 0, int _l = 0, int _r = 0): v(_v), b(_b), l(_l), r(_r) { }

    bool operator < (const Heapnode& rhs) const {
        return v < rhs.v;
    }
};

int n, k;
vector<pli> len[N + 5];
vector<int> lst[N + 5];

int sz[M + 5];
bool mark[M + 5];
int st[N + 5], to[M + 5], nxt[M + 5], w[M + 5], e = 1;

inline void addedge(int x, int y, int z) {
    to[++ e] = y; nxt[e] = st[x]; st[x] = e; w[e] = z;
    to[++ e] = x; nxt[e] = st[y]; st[y] = e; w[e] = z;
}

int pre_dfs(int u, int all, int &c, int f = 0) {
    int size = 1;
    bool flag = true; 
    for(int i = st[u]; i; i = nxt[i]) if(!mark[i]) {
        int v = to[i];
        if(v == f) continue;
        
        sz[i] = pre_dfs(v, all, c, u);
        sz[i ^ 1] = all - sz[i];

        size += sz[i];
        flag &= ((sz[i] << 1) <= all);
    }
    if(flag &= ((size << 1) >= all)) c = u;
    return size;
}

std::priority_queue<Heapnode> q;

int cur;
void dfs_cnt(int u, int f, vector<pli>& cnt, ll d) {
    cnt.pb(mp(d, cur));
    for(int i = st[u]; i; i = nxt[i]) if(!mark[i]) {
        int v = to[i];
        if(v == f) continue;
        dfs_cnt(v, u, cnt, d + w[i]);
    }
}

void solve(int rt, int size) {
    if(size == 1) return;

    int c = rt;
    pre_dfs(rt, size, c);
    
    len[c].pb(mp(0, c));
    for(int i = st[c]; i; i = nxt[i]) if(!mark[i]) {
        cur = to[i];
        dfs_cnt(to[i], c, len[c], w[i]);
    }
    std::sort(len[c].begin(), len[c].end(), std::greater<pli>());

    int m = len[c].size();
    lst[c].resize(m), lst[c][m-1] = m;

    for(int i = m - 2; i >= 0; --i) {
        lst[c][i] = (len[c][i].snd == len[c][i+1].snd ? lst[c][i+1] : i+1);

        if(lst[c][i] < m) {
            q.push(Heapnode(len[c][i].fst + len[c][lst[c][i]].fst, c, i, lst[c][i]));
        }
    }

    for(int i = st[c]; i; i = nxt[i]) if(!mark[i]) {
        mark[i] = mark[i ^ 1] = true;
        solve(to[i], sz[i]); 
    }
}

int main() {
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);

    read(n), read(k);
    for(int i = 1; i < n; ++i) {
        static int x, y, z;
        read(x), read(y), read(z);
        addedge(x, y, z);
    }

    solve(1, n);

    while(k--) { 
        assert(q.size());
        Heapnode tmp = q.top(); q.pop();
        printf("%lld\n", tmp.v);

        int c = tmp.b, m = len[c].size(), l = tmp.l, r = tmp.r;

        if(r < m-1) {
            int nr = (len[c][r+1].snd == len[c][l].snd ? lst[c][r+1] : r+1);
            if(nr < m) {
                q.push(Heapnode(len[c][l].fst + len[c][nr].fst, c, l, nr));
            }
        }
    }
    // std::cout << procStatus() << std::endl;
    return 0;
}
