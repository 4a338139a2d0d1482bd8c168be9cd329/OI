#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;

int n, k, cur;
vector<ll> ans;
vector<pii> G[N + 5];

void dfs(int u, int f = 0, ll d = 0) {
    if(u > cur) {
        ans.pb(d);
    }

    for(int i = 0; i < (int) G[u].size(); ++i) {
        int v = G[u][i].fst, w = G[u][i].snd;
        if(v == f) continue;

        dfs(v, u, d + w);
    }
}

int main() {
    freopen("tree.in", "r", stdin);
    freopen("bf.out", "w", stdout);


    read(n); read(k);
    for(int i = 1; i < n; ++i) {
        static int x, y, z;
        read(x), read(y), read(z);
        G[x].pb(mp(y, z)); G[y].pb(mp(x, z));
    }

    for(int i = 1; i <= n; ++i) {
        cur = i;
        dfs(i, 0);
    }

    std::sort(ans.begin(), ans.end(), std::greater<ll>());

    for(int i = 0; i < k; ++i) {
        printf("%lld\n", ans[i]);
    }

    return 0;
}
