#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
int n,m;
int a[maxn];
int main(){
	freopen("sequence.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	int op,l,r,x;
	for(m=1;m<=M;m++){
		scanf("%d%d%d",&op,&l,&r);
		if(op==1){
			scanf("%d",&x);
			for(int i=l;i<=r;i++)
				a[i]&=x;
		}
		else if(op==2){
			scanf("%d",&x);
			for(int i=l;i<=r;i++)
				a[i]|=x;
		}
		else{
			x=0;
			for(int i=l;i<=r;i++)
				chkmax(x,a[i]);
			printf("%d\n",x);
		}
	}
	return 0;
}
