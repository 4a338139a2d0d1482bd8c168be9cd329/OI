#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxv=1<<20;
void solve(){
	int n=200000,m=200000;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%maxv);
	printf("\n");
	int op,l,r;
	for(int i=1;i<=m;i++){
		op=rand()%3+1,l=rand()%n+1,r=rand()%n+1;
		if(l>r) swap(l,r);
		if(op<=2)
			printf("%d %d %d %d\n",op,l,r,rand()%maxv);
		else
			printf("%d %d %d\n",op,l,r);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("sequence.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
