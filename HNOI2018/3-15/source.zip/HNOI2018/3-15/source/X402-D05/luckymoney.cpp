#include<bits/stdc++.h>
using namespace std;
const int maxn=110;
int a[maxn][maxn];
bool dp[1<<12][maxn];
int main(){
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	dp[0][0]=1;
	int cnt;
	for(int i=0;i<(1<<n)-1;i++){
		cnt=__builtin_popcount(i);
		for(int j=0;j<n;j++){
			if(i&(1<<j)) continue;
			if(a[cnt][j]==-1) continue;
			for(int s=0;s<k;s++){
				dp[i|(1<<j)][(s+a[cnt][j])%k]|=dp[i][s];
			}
		}
	}
	if(dp[(1<<n)-1][0])
		printf("Yes\n");
	else
		printf("No\n");
	return 0;
}
