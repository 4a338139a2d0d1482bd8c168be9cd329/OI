#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
int beg[maxn],nex[maxn<<1],tto[maxn<<1],w[maxn<<1],e;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
long long a[1100000];
int num;
void dfs(int u,int fa,int rt,long long L){
	if(u<rt) a[++num]=L;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		dfs(tto[i],u,rt,L+w[i]);
	}
}
bool cmp(long long x,long long y){
	return x>y;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int n,k;
	int s,t,v;
	scanf("%d%d",&n,&k);
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&s,&t,&v);
		putin(s,t,v);
		putin(t,s,v);
	}
	for(int i=1;i<=n;i++)
		dfs(i,-1,i,0);
	sort(a+1,a+num+1,cmp);
	for(int i=1;i<=k;i++)
		printf("%lld\n",a[i]);
	return 0;
}
