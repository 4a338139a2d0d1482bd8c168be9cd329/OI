#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxv=1e9;
int Min(int x,int y){
	return x<y?x:y;
}
void solve(){
//	int n=200000,m=200000;
	int n=rand()%1000+1,m=rand()%(Min(n*(n-1)/2,200000))+1;
	printf("%d %d\n",n,m);
	for(int i=2;i<=n;i++)
		printf("%d %d %d\n",rand()%(i-1)+1,i,rand()%maxv+1);
}
int main(){
	srand(time(0)+getx());
	freopen("tree.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
