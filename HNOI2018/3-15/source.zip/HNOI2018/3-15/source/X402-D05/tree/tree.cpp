#include<bits/stdc++.h>
using namespace std;
const int maxn=400100;
string procstatus(){
	ifstream t("/proc/self/status");
	return (string){istreambuf_iterator<char>(t),istreambuf_iterator<char>()};
}
int Max(int x,int y){
	return x>y?x:y;
}
struct Edge{
	int s,t,v;
}edge[maxn<<1];
struct node{
	long long u,v;
	int p;
};
bool operator < (const node &A,const node &B){
	return A.v<B.v;
}
struct point{
	int p;
	long long v;
};
bool operator < (const point &A,const point &B){
	return A.v<B.v;
}
bool vis[maxn<<1],pd[maxn<<1];
int n,m,num;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
void clear_graph(){
	memset(beg,0,sizeof(beg));
	e=1;
}
namespace Root{
	int siz[maxn],f[maxn],fv[maxn],Min_val,siz_rt;
	void dfs_getsiz(int u,int fa){
		siz[u]=1;
		for(int i=beg[u];i;i=nex[i]){
			if(tto[i]==fa) continue;
			if(vis[i>>1]) continue;
			dfs_getsiz(tto[i],u);
			fv[tto[i]]=i,f[tto[i]]=u;
			siz[u]+=siz[tto[i]];
		}
	}
	void dfs_getval(int u,int fa){
		siz[u]=Max(siz[u],siz_rt-siz[u]);
		if(!Min_val||siz[Min_val]>siz[u])
			Min_val=u;
		for(int i=beg[u];i;i=nex[i]){
			if(tto[i]==fa) continue;
			if(vis[i>>1]) continue;
			dfs_getval(tto[i],u);
		}
	}
	Edge get_rt(int u){
		dfs_getsiz(u,-1);
		if(siz[u]<=1) return (Edge){0,0,0};
		Min_val=0,siz_rt=siz[u];
		dfs_getval(u,-1);
		return ((Edge){Min_val,f[Min_val],fv[Min_val]});
	}
}
void build_tree(int u,int fa){
	static Edge stk[maxn];
	int top=0;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		stk[++top]=(Edge){i>>1,tto[i],w[i]};
	}
	while(top>2){
		vis[stk[top].s]=1,vis[stk[top-1].s]=1;
		edge[++num]=(Edge){u,++n,0};
		edge[++num]=(Edge){n,stk[top].t,stk[top].v};
		edge[++num]=(Edge){n,stk[top-1].t,stk[top-1].v};
		stk[top-1]=(Edge){num-2,n,0};
		top--;
	}
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		build_tree(tto[i],u);
	}
}
vector<long long> vec[maxn];
priority_queue<node> q[maxn];
priority_queue<point> pq;
bool cmp(long long x,long long y){
	return x>y;
}
void dfs_build(int rt,int u,int fa,long long L){
	if(pd[u]) vec[rt].push_back(L);
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[i>>1]) continue;
		dfs_build(rt,tto[i],u,L+w[i]);
	}
}
void dfs_Insert(int rt,int u,int fa,long long L){
	if(pd[u])
		q[rt].push((node){L,L+vec[rt].front(),0});
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[i>>1]) continue;
		dfs_Insert(rt,tto[i],u,L+w[i]);
	}
}
void solve(Edge rt){
	if(rt.s==0) return;
	vis[rt.v>>1]=1;
	dfs_build(rt.v>>1,rt.t,rt.s,0);
	if(!vec[rt.v>>1].empty()){
		sort(vec[rt.v>>1].begin(),vec[rt.v>>1].end(),cmp);
		dfs_Insert(rt.v>>1,rt.s,rt.t,w[rt.v]);
		if(!q[rt.v>>1].empty())
			pq.push((point){rt.v>>1,q[rt.v>>1].top().v});
	}
	solve(Root::get_rt(rt.s));
	solve(Root::get_rt(rt.t));
	vis[rt.v>>1]=0;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&m);
	clear_graph();
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&edge[i].s,&edge[i].t,&edge[i].v);
		putin(edge[i].s,edge[i].t,edge[i].v);
		putin(edge[i].t,edge[i].s,edge[i].v);
	}
	for(int i=1;i<=n;i++)
		pd[i]=1;
	num=n-1;
	build_tree(1,-1);
	clear_graph();
	for(int i=1;i<=num;i++){
		if(vis[i]) continue;
		putin(edge[i].s,edge[i].t,edge[i].v);
		putin(edge[i].t,edge[i].s,edge[i].v);
	}
	memset(vis,0,sizeof(vis));
	solve(Root::get_rt(1));
	point st;
	node tt;
	while(m--){
		st=pq.top();
		pq.pop();
		printf("%lld\n",st.v);
		tt=q[st.p].top();
		q[st.p].pop();
		if(tt.p<(int)vec[st.p].size()-1)
			q[st.p].push((node){tt.u,tt.u+vec[st.p][tt.p+1],tt.p+1});
		if(!q[st.p].empty())
			pq.push((point){st.p,q[st.p].top().v});
	}
//	cerr<<n<<endl;
//	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
	return 0;
}
