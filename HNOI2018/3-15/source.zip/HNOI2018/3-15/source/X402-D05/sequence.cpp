#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
const int maxv=(1<<20)-1;
#define mid ((l+r)>>1)
int Max(int x,int y){
	return x>y?x:y;
}
int n,m;
int a[maxn];
namespace tree{
	int tr[maxn<<2],sg[maxn<<2],rg[maxn<<2];
	int tg[maxn<<2];
	void push_up(int h){
		tr[h]=Max(tr[h<<1],tr[h<<1|1]);
		sg[h]=sg[h<<1]&sg[h<<1|1];
		rg[h]=rg[h<<1]&rg[h<<1|1];
	}
	void push_down(int h){
		tr[h<<1]+=tg[h],tr[h<<1|1]+=tg[h];
		tg[h<<1]+=tg[h],tg[h<<1|1]+=tg[h];
		tg[h]=0;
		sg[h<<1]^=sg[h<<1]&rg[h],sg[h<<1]|=sg[h];
		rg[h<<1]^=rg[h<<1]&sg[h],rg[h<<1]|=rg[h];
		sg[h<<1|1]^=sg[h<<1|1]&rg[h],sg[h<<1|1]|=sg[h];
		rg[h<<1|1]^=rg[h<<1|1]&sg[h],rg[h<<1|1]|=rg[h];
	}
	void build_tree(int h,int l,int r){
		if(l==r){
			tr[h]=a[l];
			sg[h]=a[l];
			rg[h]=maxv^a[l];
			return;
		}
		build_tree(h<<1,l,mid);
		build_tree(h<<1|1,mid+1,r);
		push_up(h);
	}
	void Set(int h,int l,int r,int v){
		if(((sg[h]|rg[h])&v)==v){
			tr[h]+=v&rg[h];
			tg[h]+=v&rg[h];
			sg[h]^=v&rg[h];
			rg[h]^=v&rg[h];
		}
		else{
			push_down(h);
			Set(h<<1,l,mid,v);
			Set(h<<1|1,mid+1,r,v);
			push_up(h);
		}
	}
	void Set(int h,int l,int r,int s,int t,int v){
		if(s<=l&&r<=t){
			Set(h,l,r,v);
			return;
		}
		push_down(h);
		if(t<=mid) Set(h<<1,l,mid,s,t,v);
		else if(s>mid) Set(h<<1|1,mid+1,r,s,t,v);
		else{
			Set(h<<1,l,mid,s,mid,v);
			Set(h<<1|1,mid+1,r,mid+1,t,v);
		}
		push_up(h);
	}
	void Reset(int h,int l,int r,int v){
		if(((sg[h]|rg[h])&v)==v){
			tr[h]-=v&sg[h];
			tg[h]-=v&sg[h];
			rg[h]^=v&sg[h];
			sg[h]^=v&sg[h];
		}
		else{
			push_down(h);
			Reset(h<<1,l,mid,v);
			Reset(h<<1|1,mid+1,r,v);
			push_up(h);
		}
	}
	void Reset(int h,int l,int r,int s,int t,int v){
		if(s<=l&&r<=t){
			Reset(h,l,r,v);
			return;
		}
		push_down(h);
		if(t<=mid) Reset(h<<1,l,mid,s,t,v);
		else if(s>mid) Reset(h<<1|1,mid+1,r,s,t,v);
		else{
			Reset(h<<1,l,mid,s,mid,v);
			Reset(h<<1|1,mid+1,r,mid+1,t,v);
		}
		push_up(h);
	}
	int Query(int h,int l,int r,int s,int t){
		if(s<=l&&r<=t)
			return tr[h];
		push_down(h);
		if(t<=mid) return Query(h<<1,l,mid,s,t);
		else if(s>mid) return Query(h<<1|1,mid+1,r,s,t);
		else
			return Max(Query(h<<1,l,mid,s,mid),Query(h<<1|1,mid+1,r,mid+1,t));
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	tree::build_tree(1,1,n);
	int op,l,r,x;
	for(m=1;m<=M;m++){
		scanf("%d%d%d",&op,&l,&r);
		if(op==1){
			scanf("%d",&x);
			tree::Reset(1,1,n,l,r,maxv^x);
		}
		else if(op==2){
			scanf("%d",&x);
			tree::Set(1,1,n,l,r,x);
		}
		else
			printf("%d\n",tree::Query(1,1,n,l,r));
	}
	return 0;
}
