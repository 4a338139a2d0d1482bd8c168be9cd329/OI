#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i, u) for(int i = Begin[u], v = to[i];i;i = Next[i], v=to[i])
#define ll long long 
using namespace std;
const int N = 2010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0; char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("tree.in","r",stdin);
	freopen("BF.out","w",stdout);
}
int n, k, Begin[N], Next[N<<1], e, to[N<<1], dep[N];
int fa[N][11];
ll d[N], w[N<<1];
inline void add(int x, int y, ll z){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;w[e] = z;
}
void dfs(int u, int f){
	fa[u][0] = f;dep[u] = dep[f] + 1;
	Rep(i, u)if(v^f)
		d[v] = d[u] + w[i], dfs(v, u);
}
void st_init(){
	For(j, 1, 10)
		For(i, 1, n)
			fa[i][j] = fa[fa[i][j-1]][j-1];
}
int Lca(int u, int v){
	if(dep[u] < dep[v])swap(u, v);
	int d1 = dep[u] - dep[v];
	for(int i = 0;(1<<i) <= d1;++i)
		if(d1&(1<<i))u = fa[u][i];
	if(u == v)return u;
	Forr(i, 10, 0)
		if(fa[u][i] ^ fa[v][i])
			u = fa[u][i], v = fa[v][i];
	return fa[u][0];
}
inline ll Dis(int u, int v){
	return d[u] + d[v] - 2ll * d[Lca(u, v)];
}
void init(){
	read(n), read(k);
	For(i, 1, n - 1){
		int x, y, z;
		read(x), read(y), read(z);
		add(x, y, z), add(y, x, z);
	}
	dfs(1, 0);
	st_init();
}
ll ans[N * N];
inline bool cmp(ll x, ll y){
	return x > y;
}
void solve(){
	For(i, 1, n)
		For(j, i + 1, n)
			ans[++ans[0]] = Dis(i, j);
	sort(ans + 1, ans + ans[0] + 1, cmp);
	For(i, 1, k)printf("%lld\n", ans[i]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
