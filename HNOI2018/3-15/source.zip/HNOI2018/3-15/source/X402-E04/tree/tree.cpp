#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i, u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N = 200010, INF = 0x3f3f3f3f;
typedef pair<ll, ll> pll;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
int Begin[N], Next[N<<1], e=1, to[N<<1], n, K;
ll w[N<<1];
inline void add(int x, int y, int z){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;w[e] = z;
}
namespace Divide{
	int p[N<<1], siz[N], fa[N];  
	ll dis[N];
    priority_queue<ll>ans;
	ll k;  
    void Getcg(int u, int sz, int &cg){  
        uint flag(1);  
        siz[u] = 1;  
        Rep(i, u)  
            if(!p[i] && fa[u] != v){  
                fa[v] = u,  
                Getcg(v, sz, cg), siz[u] += siz[v];  
                if (siz[v] > sz>>1) flag = 0;  
            }  
        if(sz - siz[u] > sz>>1 )flag = 0;  
        if(flag)cg = u;  
    }
    void dfs1(int u, ll d){  
        dis[u] = d;  
        Rep(i, u)  
            if (!p[i] && fa[u] != v)  
                fa[v] = u, dfs1(v, (dis[v] = d + w[i]));  
    }
	vector<ll> s[N];  
    void dfs2(int u, int id){  
        s[id].push_back(dis[u]);  
        Rep(i,u)  
            if (!p[i] && fa[u] != v)  
                dfs2(v, id);  
    } 
    void calc(int u, int id){  
        dfs2(u, id);  
        sort(s[id].begin(), s[id].end());  
    }  
	ll Calc(int id){
		int top = s[id].size();ll ret = 0;
		for(int i=0, j = top - 1;i < top;i++){  
            for(;j>=0 && s[id][i] + s[id][j] >= k;j--);  
            ret += top - j - 1;  
        }  
		return ret;
	}
	int check(ll X, int Cnt){
		k = X;
		ll ret = Calc(0);
		For(i, 1, Cnt)ret -= Calc(i);
		if(X == 0)ret ++;
		return ret / 2;
	}
	ll st[N],tmp[N]; int top = 0;
	void Find(int Cnt, ll R){
		ll L = 0, Ans = 0;
		while(L < R){
			ll mid = (L + R) >> 1;
			if(check(mid, Cnt) >= K)L = mid + 1, Ans = mid;
			else R = mid - 1;
		}
		ll Count = check(Ans, Cnt) <= K?1ll * n * n: K - check(Ans + 1, Cnt);
		st[top = 1] = 0;
		For(i, 1, Cnt){
		
			int S = s[i].size(); S--;
			Forr(j, top, 1){
				Forr(l, S, 0)
					if(st[j] + s[i][l] >= Ans){
						if(st[j] + s[i][l] == Ans){
							if(Count>0)ans.push(st[j] + s[i][l]);
							Count--;
							if(Count == 0)break;
						}else ans.push(st[j] + s[i][l]);
					}else break;
				if(st[j] + s[i][S] < Ans)break;
			}
			For(j, 0, S)st[++top] = s[i][j];
			sort(st + 1, st + top + 1);
		}
	}
    void Tree_Divide(int rt, int sz){  
        int cg;  
		if(sz == 1)return ;
        fa[rt]=0;  
        Getcg(rt, sz, cg);  
        siz[fa[cg]] = sz - siz[cg];  
        fa[cg] = 0;  
        dfs1(cg, 0);
		int tot = 0;
        calc(cg, 0);
        Rep(i, cg)if(!p[i])calc(v, ++tot);
		Find(tot, s[0].back() * 2);
		For(i, 0, tot)s[i].clear();
        Rep(i, cg)  
            if(!p[i])p[i] = p[i^1] = 1, Tree_Divide(v, siz[v]);   
    }  
}
void init(){
	read(n), read(K);
	For(i, 1, n - 1){
		int x, y, z;
		read(x), read(y), read(z);
		add(x, y, z), add(y, x, z);
	}
}
void solve(){
	using namespace Divide;
	Tree_Divide(1, n);
	For(i, 1, K){
		printf("%lld\n", ans.top());ans.pop();
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
