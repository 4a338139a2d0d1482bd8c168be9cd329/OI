#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;


int main(){
	srand(time(0));
	freopen("tree.in","w",stdout);
	int n = 2000, k = rand()%(min(n*(n-1)/2,200000)) + 1;
	printf("%d %d\n", n, k);
	For(i, 2, n){
		printf("%d %d %d\n", i, rand()%(i-1) + 1, rand()%((int)1e9));
	}
}
