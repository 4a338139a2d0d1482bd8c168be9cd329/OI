#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 200010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
}
struct Seg{
	#define lc h<<1
	#define rc h<<1|1
	#define mid ((l+r)>>1)
	#define Lc lc, l, mid
	#define Rc rc, mid+1, r
	int Sum[N*4][2], tag[N*4][2], mx[N*4];
	const int ALL = (1<<20) - 1;
	Seg(){
		For(i, 1, N*4 - 10)tag[i][0] = ALL;
	}
	inline void Pushup(int h){
		mx[h] = max(mx[lc], mx[rc]);
		Sum[h][0] = Sum[lc][0] & Sum[rc][0];
		Sum[h][1] = Sum[lc][1] | Sum[rc][1];
	}
	inline void Pushdown(int h){
		if(tag[h][0]!=ALL){
			int val = tag[h][0];
			mx[lc] -= (~val) & Sum[lc][0];
			mx[rc] -= (~val) & Sum[rc][0];
			Sum[lc][0] &= val, Sum[rc][0] &= val;
			Sum[lc][1] &= val, Sum[rc][1] &= val;
			tag[lc][0] &= val, tag[rc][0] &= val;
			tag[lc][1] &= val, tag[rc][1] &= val;
			tag[h][0] = ALL;
		}
		if(tag[h][1]){
			int val = tag[h][1];
			mx[lc] += val ^ (val & Sum[lc][0]);
			mx[rc] += val ^ (val & Sum[rc][0]);
			Sum[lc][0] |= val, Sum[rc][0] |= val;
			Sum[lc][1] |= val, Sum[rc][1] |= val;
			tag[lc][1] |= val, tag[rc][1] |= val;
			tag[h][1] = 0;
		}
	}
	void And(int h, int l, int r, int L, int R, int v){
		if(L <= l && r <= R && ((~v)&Sum[h][0])==((~v)&Sum[h][1])){
			mx[h] -= (~v) & Sum[h][0];
			Sum[h][0] &= v, Sum[h][1] &= v;
			tag[h][0] &= v, tag[h][1] &= v;
			return ;
		}
		Pushdown(h);
		if(L <= mid) And(Lc, L, R, v);
		if(R >  mid) And(Rc, L, R, v);
		Pushup(h);
	}
	void Or(int h, int l, int r, int L, int R, int v){
		if(L <= l && r <= R && ((v)&Sum[h][0])==((v)&Sum[h][1])){
			mx[h] += v ^ (v & Sum[h][0]);
			Sum[h][0] |= v, Sum[h][1] |= v;
			tag[h][1] |= v;
			return ;
		}
		Pushdown(h);
		if(L <= mid) Or(Lc, L, R, v);
		if(R >  mid) Or(Rc, L, R, v);
		Pushup(h);
	}
	int Query(int h, int l, int r, int L, int R){
		if(L <= l && r <= R)return mx[h];
		int Mx = -1;
		Pushdown(h);
		if(L <= mid)Mx = Query(Lc, L, R);
		if(R >  mid)Mx = max(Mx, Query(Rc, L, R));
		return Mx;
	}
}t;
int n, q;
void init(){
	read(n), read(q);
	For(i, 1, n){
		int x;
		read(x);
		t.Or(1, 1, n, i, i, x);
	}
}
void solve(){
	while(q--){
		int tp, l, r, x;
		read(tp);
		if(tp == 1){
			read(l), read(r), read(x);
			t.And(1, 1, n, l, r, x);
		}else if(tp == 2){
			read(l), read(r), read(x);
			t.Or(1, 1, n, l, r, x);
		}else{
			read(l), read(r);
			printf("%d\n", t.Query(1, 1, n, l, r));
		}
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
