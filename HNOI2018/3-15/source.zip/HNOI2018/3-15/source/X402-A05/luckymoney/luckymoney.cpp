#include <bits/stdc++.h>

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int MAXN = 3e2 + 5;

int N, K;
int A[MAXN][MAXN];
int p[MAXN];

int S, T;
int e = 1, Begin[MAXN];
struct Edge
{
	int to, next, c, w;
	Edge(int to = 0, int next = 0, int c = 0, int w = 0) : to(to), next(next), c(c), w(w) {}
}E[MAXN * MAXN];

void AddEdge(int u, int v, int cap, int cost)
{
	E[++e] = Edge(v, Begin[u], cap, cost); Begin[u] = e;
}
void AddFlow(int u, int v, int cap, int cost)
{
	AddEdge(u, v, cap, cost), AddEdge(v, u, 0, -cost);
}

int Mxflow;

namespace MCMF
{
	int preV[MAXN];
	int preE[MAXN];
	int dis[MAXN], q[MAXN];
	bool inq[MAXN];

	int Spfa(int lstans, int r = 0)
	{
		for (int i = 1; i <= T; ++i) {
			preE[i] = preV[i] = 0;
			dis[i] = K + 1;
			inq[i] = false;
		}
		q[++r] = S; dis[S] = 0;
		for (int l = 1; l <= r; ++l) {
			int u = q[l]; 

			inq[u] = false;
			if (u == T) continue;

			for (int i = Begin[u]; i; i = E[i].next) {
				int v = E[i].to;
				if (E[i].c && dis[v] > (lstans + dis[u] + E[i].w + K) % K) {
					dis[v] = (lstans + dis[u] + E[i].w + K) % K;
					preV[v] = u;
					preE[v] = i;
					if (!inq[v]) {
						inq[v] = true;
						q[++r] = v;
					}
				}
			}
		}
		if (dis[T] > K) return -1;

		int Mnflow = 1e9;
		for (int u = T; u != S; u = preV[u]) {
			Mnflow = std::min(Mnflow, E[preE[u]].c);
		}
		for (int u = T; u != S; u = preV[u]) {
			E[preE[u]].c -= Mnflow;
			E[preE[u] ^ 1].c += Mnflow;
		}
		Mxflow += Mnflow;

		return dis[T];
	}
}

int main()
{
	freopen("luckymoney.in", "r", stdin);
	freopen("luckymoney.out", "w", stdout);

	N = read(), K = read();
	for (int i = 1; i <= N; ++i) {
		for (int j = 1; j <= N; ++j) A[i][j] = read();
	}

	if (N > 10) {
		int tot = 1;
		for (int i = 1; i <= N; ++i) {
			p[i] = i;
			tot *= i;
		}

		while (tot --) {
			bool flag = true;
			int sum = 0;
			for (int i = 1; i <= N; ++i) {
				if (A[i][p[i]] < 0) flag = false;
				else (sum += A[i][p[i]]) %= K;
			}

			if (flag && !sum)
				return puts("Yes"), 0;

			std::next_permutation(p + 1, p + N + 1);
		}
		return puts("No"), 0;
	}

	S = N*2 + 1, T = S + 1;
	for (int i = 1; i <= N; ++i) {
		AddFlow(S, i, 1, 0);
		AddFlow(i + N, T, 1, 0);
	}

	for (int i = 1; i <= N; ++i) {
		for (int j = 1; j <= N; ++j) {
			if (A[i][j] >= 0) 
				AddFlow(i, j + N, 1, A[i][j]);
		}
	}

	int ans = 0;
	while (true) {
		int tmp = MCMF::Spfa(ans);
		if (tmp < 0) break;
		ans = tmp;
	}
	
	if (!ans && Mxflow == N) puts("Yes");
	else puts("No");

	return 0;
}

