#include <bits/stdc++.h>

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int MAXN = 2e5 + 5;

int N, Q;
int val[20 + 5];

namespace SEGT
{
	using std :: max;
	#define mid ((l + r) >> 1)
	#define lc (h << 1)
	#define rc (lc | 1)

	int sumor[MAXN << 2], sumand[MAXN << 2];
	int tag[MAXN << 2], Max[MAXN << 2];

	inline void push_up(int h)
	{
		Max[h] = max(Max[lc], Max[rc]);
		sumor[h] = sumor[lc] | sumor[rc];
		sumand[h] = sumand[lc] & sumand[rc];
	}

	inline void push_down(int h, int l, int r)
	{
		if (tag[h] != 0) {
			sumor[lc] += tag[h]; sumand[lc] += tag[h]; 
			sumor[rc] += tag[h]; sumand[rc] += tag[h];
			Max[lc] += tag[h], tag[lc] += tag[h];
			Max[rc] += tag[h], tag[rc] += tag[h];
			tag[h] = 0;
		}
	}

	void buildTree(int h, int l, int r)
	{
		if (l == r) {
			register int x = read();
			Max[h] = sumand[h] = sumor[h] = x;
			return ;
		}
		buildTree(lc, l, mid);
		buildTree(rc, mid + 1, r);
		push_up(h);
	}

	//& 0
	inline void modifyAnd(int h, int l, int r, int ql, int qr, int bit)
	{
		if (!(sumor[h] & val[bit])) return ;
		if (ql <= l && r <= qr) {
			if (sumand[h] & val[bit]) {
				sumand[h] -= val[bit];
				sumor[h] -= val[bit];
				Max[h] -= val[bit];
				tag[h] -= val[bit];
				return ;
			}
		}
		push_down(h, l, r);
		if (ql <= mid) modifyAnd(lc, l, mid, ql, qr, bit);
		if (qr > mid) modifyAnd(rc, mid + 1, r, ql, qr, bit);
		push_up(h);
	}

	//| 1
	inline void modifyOr(int h, int l, int r, int ql, int qr, int bit)
	{
		if (sumand[h] & val[bit]) return ;
		if (ql <= l && r <= qr) {
			if (!(sumor[h] & val[bit])) {
				sumand[h] += val[bit];
				sumor[h] += val[bit];
				Max[h] += val[bit];
				tag[h] += val[bit];
				return ;
			}
		}
		push_down(h, l, r);
		if (ql <= mid) modifyOr(lc, l, mid, ql, qr, bit);
		if (qr > mid) modifyOr(rc, mid + 1, r, ql, qr, bit);
		push_up(h);
	}

	inline int query(int h, int l, int r, int ql, int qr)
	{
		if (ql <= l && r <= qr) return Max[h];
		push_down(h, l, r);
		return max(ql <= mid? query(lc, l, mid, ql, qr) : 0, 
				qr > mid? query(rc, mid + 1, r, ql, qr) : 0);
	}

	#undef lc
	#undef rc
	#undef mid
}

int main()
{
	//freopen("sequence.in", "r", stdin);
	//freopen("sequence.out", "w", stdout);

	for (int i = 0; i <= 20; ++i) val[i] = 1 << i;

	N = read(), Q = read();
	SEGT :: buildTree(1, 1, N);

	for (int i = 1; i <= Q; ++i) {
		int ty = read(), l = read(), r = read();
		if (ty <= 2) {
			int x = read();
			for (int j = 0; j < 20; ++j) {
				if ((ty & 1) == ((x>>j) & 1)) continue;
				if (ty & 1)
					SEGT :: modifyAnd(1, 1, N, l, r, j);
				else
					SEGT :: modifyOr(1, 1, N, l, r, j);
			}
		}
		else {
			printf("%d\n", SEGT :: query(1, 1, N, l, r));
		}
	}

	return 0;
}
