#include <bits/stdc++.h>

int read(int x = 0, int _f = 0)
{
	char c = getchar(); 
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

typedef long long LL;

const int MAXN = 2e5 + 5;

int N, K;
int degree[MAXN];

int e, Begin[MAXN];
struct Edge
{
	int to, next, w;
	Edge(int to = 0, int next = 0, int w = 0) : to(to), next(next), w(w) {}
}E[MAXN << 1];

void AddEdge(int u, int v, int w)
{
	E[++e] = Edge(v, Begin[u], w); Begin[u] = e;
}

namespace SubTask1
{
	using std :: sort;

	LL C[MAXN * 10];
	int cnt;

	void DFS(int u, int st, LL dist = 0, int fa = -1)
	{
		if (st < u) C[cnt++] = dist;
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa) continue;
			DFS(v, st, dist + E[i].w, u);
		}
	}

	void main()
	{
		for (int i = 1; i <= N; ++i) DFS(i, i);
		sort(C, C + cnt, std :: greater<LL>());
		for (int i = 0; i < K; ++i) printf("%lld\n", C[i]);
	}
}

namespace SubTask2
{
	using std :: pair;
	using std :: set;
	using std :: map;

	typedef pair<int, int> pii;

	set<pair<LL, pii> > S;
	map<pii, bool> inq;

	int st, ed;
	int Prev[MAXN];
	int Next[MAXN];
	LL chainval[MAXN];

	int q[MAXN];

	void BFS(int r = 0)
	{
		q[++r] = st;
		for (int l = 1; l <= r; ++l) {
			int u = q[l];
			for (int i = Begin[u]; i; i = E[i].next) {
				int v = E[i].to;
				if (v == Prev[u]) continue;
				Prev[v] = u;
				Next[u] = v;
				q[++r] = v;
				chainval[v] = chainval[u] + E[i].w;
			}
		}
		ed = q[r];
	}

	void main()
	{
		for (int i = 1; i <= N; ++i) {
			if (degree[i] == 1) {
				st = i; break;
			}
		}

		BFS(1);
		S.insert(make_pair(chainval[ed], pii(st, ed)));
		inq[pii(st, ed)] = true;

		for (int cnt = 0; cnt < K; ++cnt) {
			set<pair<LL, pii> >::iterator it = --S.end();
			printf("%lld\n", it -> first);

//			fprintf(stderr, "%d %d\n", it -> second.first, it -> second.second);
			inq[it -> second] = false;
			S.erase(it);

			int u = it -> second.first;
			int v = it -> second.second;
			if (!inq[pii(Next[u], v)]) {
				inq[pii(Next[u], v)] = true;
				LL sum = chainval[v] - chainval[Next[u]];
				S.insert(make_pair(sum, pii(Next[u], v)));
			}
			if (!inq[pii(u, Prev[v])]) {
				inq[pii(u, Prev[v])] = true;
				LL sum = chainval[Prev[v]] - chainval[u];
				S.insert(make_pair(sum, pii(u, Prev[v])));
			}
		}

	}
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	N = read(), K = read();
	for (int i = 1; i < N; ++i) {
		int u = read(), v = read(), w = read();
		AddEdge(u, v, w);
		AddEdge(v, u, w);
		degree[u] ++;
		degree[v] ++;
	}

	if (N <= 1000) {
		SubTask1 :: main();
	}
	else {
		SubTask2 :: main();
	}

	return 0;
}
