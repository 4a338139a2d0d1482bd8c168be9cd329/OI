#include <bits/stdc++.h>
using namespace std;
const int maxn = 200000 + 10;
int n,q,maxv[maxn<<2],mark[maxn<<2][2];
inline void pushup(int root) { maxv[root] = max(maxv[root<<1],maxv[root<<1|1]); }
inline void BuildTree(int l,int r,int root) {
	if (l == r) {
		scanf("%d",&maxv[root]);
		return;
	}
	int mid = l+r>>1;
	BuildTree(l,mid,root<<1);
	BuildTree(mid+1,r,root<<1|1);
	pushup(root);
}
inline void pushdown(int root) {
	if (mark[root][0]) {
		mark[root<<1][0] &= mark[root][0];
		maxv[root<<1] &= mark[root][0];
		mark[root<<1|1][0] &= mark[root][0];
		maxv[root<<1|1] &= mark[root][0];
		mark[root][0] = 0;
	}
	if (mark[root][1]) {
		mark[root<<1][1] |= mark[root][1];
		maxv[root<<1] |= mark[root][1];
		mark[root<<1|1][1] |= mark[root][1];
		maxv[root<<1|1] |= mark[root][1];
		mark[root][1] = 0;
	}
}
inline void UpdateAnd(int l,int r,int ql,int qr,int root,int x) {
	if (r < ql || l > qr) return;
	if (ql <= l && r <= qr) {
		maxv[root] &= x;
		if (!mark[root][0]) mark[root][0] = x;
		else mark[root][0] &= x;
		return;
	}
	pushdown(root);
	int mid = l+r>>1;
	UpdateAnd(l,mid,ql,qr,root<<1,x);
	UpdateAnd(mid+1,r,ql,qr,root<<1|1,x);
	pushup(root);
}
inline void UpdateOr(int l,int r,int ql,int qr,int root,int x) {
	if (r < ql || l > qr) return;
	if (ql <= l && r <= qr) {
		maxv[root] |= x;
		if (!mark[root][1]) mark[root][1] = x;
		else mark[root][1] |= x;
		return;
	}
	pushdown(root);
	int mid = l+r>>1;
	UpdateOr(l,mid,ql,qr,root<<1,x);
	UpdateOr(mid+1,r,ql,qr,root<<1|1,x);
	pushup(root);
}
inline int Query(int l,int r,int ql,int qr,int root) {
	if (r < ql || l > qr) return -99999999;
	if (ql <= l && r <= qr) return maxv[root];
	pushdown(root);
	int mid = l+r>>1;
	return max(Query(l,mid,ql,qr,root<<1),Query(mid+1,r,ql,qr,root<<1));
}
int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&q);
	if (n <= 5000 && q <= 5000) {
		for (int i = 1;i <= n;i++) scanf("%d",&maxv[i]);
		while (q--) {
			int ty,l,r,x;
			scanf("%d%d%d",&ty,&l,&r);
			if (ty == 1) {
				scanf("%d",&x);
				for (int i = l;i <= r;i++) maxv[i] &= x;
			} else if (ty == 2) {
				scanf("%d",&x);
				for (int i = l;i <= r;i++) maxv[i] |= x;
			} else {
				int Max = -9999999;
				for (int i = l;i <= r;i++) Max = max(Max,maxv[i]);
				printf("%d\n",Max);
			}
		}
		return 0;
	}
	BuildTree(1,n,1);
	while (q--) {
		int ty,l,r,x;
		scanf("%d%d%d",&ty,&l,&r);
		if (ty == 1) {
			scanf("%d",&x);
			UpdateAnd(1,n,l,r,1,x);
		} else if (ty == 2) {
			scanf("%d",&x);
			UpdateOr(1,n,l,r,1,x);
		} else printf("%d\n",Query(1,n,l,r,1));
	}
	return 0;
}
