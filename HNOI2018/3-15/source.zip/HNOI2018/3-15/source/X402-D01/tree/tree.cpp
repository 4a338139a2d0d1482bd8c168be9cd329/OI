#include <bits/stdc++.h>
using namespace std;
const int maxn = 100000 + 10;
int n,k,dep[maxn],deep[maxn],father[maxn][25],in[maxn];
vector<pair<int,int> > edges[maxn];
priority_queue<int> Q;
inline void dfs(int now,int f) {
    for (size_t i = 0;i < edges[now].size();i++)
		if (!deep[edges[now][i].first] && edges[now][i].first != f) {
			dep[edges[now][i].first] = dep[now]+1;
	        deep[edges[now][i].first] = deep[now]+edges[now][i].second;
			father[edges[now][i].first][0] = now;
			dfs(edges[now][i].first,now);
	    }
}
void init() {  
    for (int j = 1;(1<<j) <= n;j++)
        for (int i = 1;i <= n;i++)
            if (father[i][j-1] != -1) father[i][j] = father[father[i][j-1]][j-1];
}  
inline int lca(int a,int b) {
    if (dep[a] < dep[b]) swap(a,b);
    int i;
    for (i = 0;(1<<i) <= deep[a];i++);
    i--;
    for (int j = i;j >= 0;j--)
        if (dep[a]-(1<<j) >= dep[b]) a = father[a][j];
    if (a == b) return a;
    for (int j = i;j >= 0;j--) {
        if (father[a][j] != -1 && father[a][j] != father[b][j]) {
            a = father[a][j];
            b = father[b][j];
        }
    }
    return father[a][0];
}
inline int dist(int a,int b) {
    int LCA = lca(a,b);
	return deep[a]+deep[b]-2*deep[LCA];
}
int main() {
    freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&k);
	for (int i = 1,u,v,w;i < n;i++) {
		scanf("%d%d%d",&u,&v,&w);
		edges[u].push_back(make_pair(v,w));
		edges[v].push_back(make_pair(u,w));
	}
	bool flag = true;
	int s = -1,t;
	dfs(1,-1);
	init();
	for (int i = 1;i <= n;i++)
		for (int j = i+1;j <= n;j++) Q.push(dist(i,j));
	while (k--) printf("%d\n",Q.top()),Q.pop();
	return 0;
}
