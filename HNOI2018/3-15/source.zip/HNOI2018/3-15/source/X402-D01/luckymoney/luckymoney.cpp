#include <bits/stdc++.h>
using namespace std;
int n,k,p[11],a[11][11];
int main() {
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);
	scanf("%d%d",&n,&k);
	for (int i = 1;i <= n;i++) {
		p[i] = i;
		for (int j = 1;j <= n;j++) scanf("%d",&a[i][j]);
	}
	do {
		bool flag = true;
		int sum = 0;
		for (int i = 1;i <= n;i++) {
			sum +=  a[i][p[i]];
			if (a[i][p[i]] == -1) {
				flag = false;
				break;
			}
		}
		if (!(sum%k) && flag) {
			printf("Yes");
			return 0;
		}
	} while (next_permutation(p+1,p+n+1));
	printf("No");
	return 0;
}
