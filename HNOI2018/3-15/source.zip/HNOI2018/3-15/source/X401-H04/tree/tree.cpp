#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#define ll long long
const int INF = 0x3f3f3f3f;
const int MAXN = 200010;
using namespace std;

vector<int> G[MAXN], GL[MAXN];
int N, K;

inline bool greaterLL(ll a, ll b) { return a > b; }

namespace Solve {
    ll Out[MAXN];
    int NOut = 0;
    bool IsOut = 0;

    ll Val, Ans;

    bool vis[MAXN];

    int size[MAXN], cenid, censz, totsz;
    inline void dfssz(int u, int f) {
        int i, v, mxsz = 0;
        size[u] = 1;
        for(i = 0; i < G[u].size(); i++) {
            v = G[u][i];
            if(v != f && !vis[v]) dfssz(v, u), size[u] += size[v], mxsz = max(mxsz, size[v]);
        }
        mxsz = max(mxsz, totsz - size[u]);
        if(mxsz < censz) censz = mxsz, cenid = u;
    }

    struct item {
        ll d; int r;
        inline bool operator<(item rhs) { return d < rhs.d; }
    } T[MAXN];

    int curR, Tsz, ctr[MAXN];

    typedef multiset< ll, greater<ll> > RevSet;
    RevSet outset;
    ll outIns[MAXN]; int NIns;

    inline void dfssub(int u, int f, ll d) {
        if(d >= Val) Ans++;
        T[++Tsz] = (item){d, curR};

        int i, v;
        for(i = 0; i < G[u].size(); i++) {
            v = G[u][i];
            if(v != f && !vis[v]) dfssub(v, u, d + GL[u][i]);
        }
    }
    inline void dfssubout(int u, int f, ll d) {
        if(d >= Val) Out[++NOut] = d;
        for(RevSet::iterator it = outset.begin(); it != outset.end(); it++) {
            if(*it + d < Val) break;
            Out[++NOut] = *it + d;
        }
        outIns[++NIns] = d;

        int i, v;
        for(i = 0; i < G[u].size(); i++) {
            v = G[u][i];
            if(v != f && !vis[v]) dfssubout(v, u, d + GL[u][i]);
        }
    }
    inline void dfs(int u) {
        vis[u] = 1;

        int i, v;
        if(IsOut) {
            outset.clear();
            for(i = 0; i < G[u].size(); i++) if(!vis[v = G[u][i]]) {
                NIns = 0;
                dfssubout(v, u, GL[u][i]);
                for(int k = 1; k <= NIns; k++) outset.insert(outIns[k]);
            }
        }
        else {
            //Current Tree
            Tsz = 0;
            for(i = 0; i < G[u].size(); i++) if(!vis[v = G[u][i]]) {
                curR = i; dfssub(v, u, GL[u][i]);
            }

            //Scan Answers
            sort(T + 1, T + Tsz + 1);
            int L, R = Tsz + 1;
            for(L = 1; L <= Tsz; L++) {
                while( R <= L ) ctr[ T[R].r ]--, R++;
                while( (R - 1 > L) && ( (T[L].d + T[R - 1].d) >= Val) ) R--, ctr[ T[R].r ]++;
                
                Ans += (Tsz - R + 1) - ctr[ T[L].r ];
            }
            //Clear Counter
            for(i = 0; i < G[u].size(); i++) ctr[i] = 0;
        }

        //Subtree
        for(i = 0; i < G[u].size(); i++) if(!vis[v = G[u][i]]) {
            censz = INF, totsz = size[v], dfssz(v, u);
            dfs(cenid);
        }
    }

    ll NumberLte(ll x) {
        Val = x, Ans = 0;

        memset(vis, 0, sizeof(vis));
        censz = INF, totsz = N, dfssz(1, 0);

        dfs(cenid);
        return Ans;
    }

    void Solve(ll Sum) {
    	int i;
        ll L, R, Bound, Next, M;
        //Find bound
        L = -1, R = Sum;
        while(R - L > 1) {
            M = (L + R) >> 1;
            if(NumberLte(M) <= K) R = M; else L = M;
        }
        Bound = R;

        //Find next
        L = -1, R = Bound - 1;
        while(R - L > 1) {
            M = (L + R) >> 1;
            if(NumberLte(M) < K) R = M; else L = M;
        }
        Next = R;

        //Output
        IsOut = 1; NumberLte(Bound);
        sort(Out + 1, Out + NOut + 1, greaterLL);
        for(i = 1; i <= NOut; i++) printf("%lld\n", Out[i]);
        for(i = NOut + 1; i <= K; i++) printf("%lld\n", Next);
    }
}

int main() {
    freopen("tree.in", "rt", stdin);
    freopen("tree.out", "wt", stdout);

    int i, u, v, d;
    ll Sum = 0;

    scanf("%d%d", &N, &K);
    for(i = 1; i < N; i++) {
        scanf("%d%d%d", &u, &v, &d); Sum += d;
        G[u].push_back(v), GL[u].push_back(d);
        G[v].push_back(u), GL[v].push_back(d);
    }

    Solve::Solve(Sum);
}
