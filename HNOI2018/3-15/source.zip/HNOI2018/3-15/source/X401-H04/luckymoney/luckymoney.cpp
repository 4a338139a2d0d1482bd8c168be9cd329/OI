#include <cstring>
#include <cstdio>
#include <algorithm>
const int MAXN = 110;
using namespace std;

int N, K, A[MAXN][MAXN];
namespace SolveBF {
    int Perm[MAXN];
    bool solve() {
        int i;
        for(i = 1; i <= N; i++) Perm[i] = i;
        do {
            int sum = 0;
            bool ok = 1;

            for(i = 1; i <= N; i++) {
                if( A[i][ Perm[i] ] == -1 ) { ok = 0; break; }
                sum += A[i][ Perm[i] ];
            }
            if( ok && ((sum % K) == 0) ) return 1;
        }
        while(next_permutation(Perm + 1, Perm + N + 1));

        return 0;
    }
}

int main() {
	freopen("luckymoney.in", "rt", stdin);
	freopen("luckymoney.out", "wt", stdout);
	
    int i, j;
    scanf("%d%d", &N, &K);
    for(i = 1; i <= N; i++) for(j = 1; j <= N; j++) scanf("%d", &A[i][j]);

    bool Ans;
    Ans = SolveBF::solve();
    printf(Ans ? "Yes" : "No");
}
