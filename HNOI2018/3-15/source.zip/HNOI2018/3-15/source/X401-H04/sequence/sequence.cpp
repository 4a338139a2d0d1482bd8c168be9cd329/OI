#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;
const int MAXN = 200010;
const int ALL = (1 << 20) - 1;

inline void read(int &x) {
    char ch; while((ch = getchar()), (ch < '0' || ch > '9'));
    x = ch - '0'; while((ch = getchar()), (ch >= '0' && ch <= '9')) x = x * 10 + (ch - '0');
}

//0: And 1: Or
int A[MAXN];
namespace sgt {
    #define lch ((o) << 1)
    #define rch (((o) << 1) | 1)
    #define mid (((L) + (R)) >> 1)
    int maxv[4*MAXN], sumv[4*MAXN][2], addv[4*MAXN][2];
    //No tags here
    inline void reset(int o) {
        maxv[o] = max(maxv[lch], maxv[rch]);
        sumv[o][0] = sumv[lch][0] & sumv[rch][0];
        sumv[o][1] = sumv[lch][1] | sumv[rch][1];
    }
    //Tags applied to nodes
    inline void pushdown(int o) {
        int val = addv[o][0];
        if(val != ALL) {
            maxv[lch] &= val, maxv[rch] &= val;
            sumv[lch][0] &= val, sumv[lch][1] &= val;
            sumv[rch][0] &= val, sumv[rch][1] &= val;
            addv[lch][0] &= val, addv[lch][1] &= val;
            addv[rch][0] &= val, addv[rch][1] &= val;
            addv[o][0] = ALL;
        }
        val = addv[o][1];
        if(val != 0) {
            maxv[lch] |= val, maxv[rch] |= val;
            sumv[lch][0] |= val, sumv[lch][1] |= val;
            sumv[rch][0] |= val, sumv[rch][1] |= val;
            addv[lch][0] |= val, addv[lch][1] |= val;
            addv[rch][0] |= val, addv[rch][1] |= val;
            addv[o][1] = 0;
        }
    }
    //Building
    inline void build(int o, int L, int R) {
        addv[o][0] = ALL;
        if(L == R) maxv[o] = sumv[o][0] = sumv[o][1] = A[L];
        else {
            int M = mid;
            build(lch, L, M), build(rch, M+1, R);
            reset(o);
        }
    }

    int _l, _r, _v;
    inline void uand(int o, int L, int R) {
        if(_l <= L && _r >= R && ( ((~_v) & sumv[o][0]) == ((~_v) & sumv[o][1]) ) ) {
            addv[o][0] &= _v, addv[o][1] &= _v;
            sumv[o][0] &= _v, sumv[o][1] &= _v;
            maxv[o] &= _v;
        }
        else {
            pushdown(o);
            int M = mid;
            if(_l <= M) uand(lch, L, M);
            if(_r > M) uand(rch, M+1, R);
            reset(o);
        }
    }
    inline void uor(int o, int L, int R) {
        if(_l <= L && _r >= R && ( (_v & sumv[o][0]) == (_v & sumv[o][1]) ) ) {
            addv[o][0] |= _v, addv[o][1] |= _v;
            sumv[o][0] |= _v, sumv[o][1] |= _v;
            maxv[o] |= _v;
        }
        else {
            pushdown(o);
            int M = mid;
            if(_l <= M) uor(lch, L, M);
            if(_r > M) uor(rch, M+1, R);
            reset(o);
        }
    }
    inline void query(int o, int L, int R) {
        if(_l <= L && _r >= R) _v = max(_v, maxv[o]);
        else {
            pushdown(o);
            int M = mid;
            if(_l <= M) query(lch, L, M);
            if(_r > M) query(rch, M+1, R);
        }
    }
}

int N, M;
int main() {
    freopen("sequence.in", "rt", stdin);
    freopen("sequence.out", "wt", stdout);

    int i, op;
    read(N), read(M);
    for(i = 1; i <= N; i++) read(A[i]);
    sgt::build(1, 1, N);

    while(M--) {
        read(op), read(sgt::_l), read(sgt::_r);
        if(op == 1) read(sgt::_v), sgt::uand(1, 1, N);
        else if(op == 2) read(sgt::_v), sgt::uor(1, 1, N);
        else sgt::_v = 0, sgt::query(1, 1, N), printf("%d\n", sgt::_v);
    }
}
