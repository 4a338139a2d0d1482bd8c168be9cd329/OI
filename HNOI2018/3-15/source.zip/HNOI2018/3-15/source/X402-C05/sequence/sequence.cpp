#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10,ALL=((1<<20)-1);
template<typename T>T read(){
	T x=0,f=1;char c=getchar();
	
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
	
	return x*f;
}

#define mid (l+r>>1)
#define ls (u<<1)
#define rs (ls|1)
#define lc ls,l,mid
#define rc rs,mid+1,r
#define rt 1,1,n

int mx[maxn],tag[maxn][3],sum[maxn][3],n,Q;

void init(){for(int i=1;i<maxn;++i)tag[i][0]=ALL;}
void pushup(int u){
	mx[u]=max(mx[ls],mx[rs]);
	sum[u][0]=sum[ls][0]&sum[rs][0];
	sum[u][1]=sum[ls][1]|sum[rs][1];
}
void pushdown(int u){
	if(tag[u][0]!=ALL){
		mx[ls]-=(sum[ls][0]&(~tag[u][0]));
		mx[rs]-=(sum[rs][0]&(~tag[u][0]));
		tag[ls][0]&=tag[u][0],tag[ls][1]&=tag[u][0];
		tag[rs][0]&=tag[u][0],tag[rs][1]&=tag[u][0];
		sum[ls][0]&=tag[u][0],sum[rs][0]&=tag[u][0];
		sum[ls][1]&=tag[u][0],sum[rs][1]&=tag[u][0];
		tag[u][0]=ALL;
	}
	if(tag[u][1]){
		mx[ls]+=(tag[u][1]^(sum[ls][0]&tag[u][1]));
		mx[rs]+=(tag[u][1]^(sum[rs][0]&tag[u][1]));
		tag[ls][1]|=tag[u][1],tag[rs][1]|=tag[u][1];
		sum[ls][0]|=tag[u][1],sum[rs][0]|=tag[u][1];
		sum[ls][1]|=tag[u][1],sum[rs][1]|=tag[u][1];
		tag[u][1]=0;
	}
}
void u1(int u,int l,int r,int ql,int qr,int v){
	if(ql<=l&&r<=qr&&((sum[u][1]&(~v))==(sum[u][0]&(~v)))){
		mx[u]-=(sum[u][0]&(~v));
		tag[u][0]&=v,tag[u][1]&=v;
		sum[u][0]&=v,sum[u][1]&=v;
		return;
	}
	pushdown(u);
	if(ql<=mid)u1(lc,ql,qr,v);
	if(qr>mid)u1(rc,ql,qr,v);
	pushup(u);
}
void u2(int u,int l,int r,int ql,int qr,int v){
	if(ql<=l&&r<=qr&&((sum[u][1]&v)==(sum[u][0]&v))){
		mx[u]+=(v^(sum[u][0]&v));
		tag[u][1]|=v;
		sum[u][0]|=v,sum[u][1]|=v;
		return;
	}
	pushdown(u);
	if(ql<=mid)u2(lc,ql,qr,v);
	if(qr>mid)u2(rc,ql,qr,v);
	pushup(u);
}
int qu(int u,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr)return mx[u];
	pushdown(u);int ret=0;
	if(ql<=mid)ret=max(ret,qu(lc,ql,qr));
	if(qr>mid)ret=max(ret,qu(rc,ql,qr));
	return ret;
}

void solve(){
	init();n=read<int>(),Q=read<int>()+1;
	for(int i=1;i<=n;++i)u2(rt,i,i,read<int>());
	for(int op,l,r,x;--Q;){
		op=read<int>(),l=read<int>(),r=read<int>();
		if(op==1){
			x=read<int>();
			u1(rt,l,r,x);
			
		}
		else if(op==2){
			x=read<int>();
			u2(rt,l,r,x);
		}
		else printf("%d\n",qu(rt,l,r));
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout); 
	solve();
	
	return 0;
}
/*
5 6
1 1 1 1 1
3 1 3
2 1 1 5
3 1 3
1 1 4 6
2 3 4 1
3 2 3
*/
