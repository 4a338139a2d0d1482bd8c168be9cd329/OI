#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
int n,K;
int dep[maxn],fa[16][maxn];

ll dis[maxn];
//vector<ll> A;
priority_queue<ll> Q;
vector<pair<int,int> > G[maxn];
#define v G[u][i].first
#define w G[u][i].second
void dfs(int u){
	for(int i=0;i<G[u].size();++i)
		if(v!=fa[0][u]){
			fa[0][v]=u;
			dep[v]=dep[u]+1;
			dis[v]=dis[u]+w;
			dfs(v);
		}
}
#undef v
#undef w
int lca(int u,int v){
	if(dep[u]<dep[v])swap(u,v);
	for(int i=15;~i;--i)
		if(dep[fa[i][u]]>=dep[v])
			u=fa[i][u];
	if(u==v)return u;
	for(int i=15;~i;--i)
		if(fa[i][u]!=fa[i][v])
			u=fa[i][u],v=fa[i][v];
	return fa[0][u];
}
namespace Work1{
	set<ll,greater<ll> > s;
	set<ll,greater<ll> >::iterator it;
	int xn[maxn],zs[maxn];
	void work1(){
		int st,ls=-1;
		for(int i=1;i<=n;++i)
			if(G[i].size()==1){st=i;break;}
		for(int i=1;i<n;++i){
			xn[st]=i;zs[i]=st;
			if(G[st][0].first!=ls){
				ls=st;
				st=G[st][0].first;
				dis[i+1]=dis[i]+G[st][0].second;
			}
			else{
				ls=st;
				st=G[st][1].first;
				dis[i+1]=dis[i]+G[st][0].second;
			}
		}
		xn[st]=n;zs[n]=st;
		ll tmp;
		for(int i=1;i<=n;++i){
			for(int j=1;j<i;++j){
				tmp=dis[i]-dis[j];
				//cerr<<i<<" "<<j<<endl;
				if(s.size()<K){s.insert(tmp);}
				else if(s.upper_bound(tmp)!=s.end()){
					s.insert(tmp);
					it=s.end();--it;
					s.erase(it);
				}
				else{
					break;
				}
			}
		}
		for(it=s.begin();it!=s.end();++it)
			printf("%lld\n",*it);
	}
}
namespace Work2{
	typedef set<ll,greater<ll> > sll;
	sll s;
	sll::iterator it;
	int sz[maxn];
	#define v G[u][i].first
	#define w G[u][i].second
	void dfs(int u,int fa){
		sz[u]=1;
		for(int i=0;i<G[u].size();++i){
			dfs(v,u);//G[u][i].first
			sz[u]+=sz[v];
		}
	}
	bool cmp(pair<int,int> A,pair<int,int> B){
		return sz[A.first]>sz[B.first];
	}
	pair<sll,sll> mg(pair<sll,sll> a,pair<sll,sll> b){
//		ll tmp;
//		for(int i=1;i<=n;++i){
//			for(int j=1;j<i;++j){
//				tmp=dis[i]-dis[j];
//				//cerr<<i<<" "<<j<<endl;
//				if(s.size()<K){s.insert(tmp);}
//				else if(s.upper_bound(tmp)!=s.end()){
//					s.insert(tmp);
//					it=s.end();--it;
//					s.erase(it);
//				}
//				else{
//					break;
//				}
//			}
//		}
		
	}
	pair<sll,sll> dfs1(int u,int fa){
		sort(G[u].begin(),G[u].end(),cmp);
		pair<sll,sll> ret;
		if(u==1){
			ret=dfs1(G[u][0].first,u);
			for(int i=1;i<G[u].size();++i)
				ret=mg(ret,dfs1(v,u));
			return ret;
		}
		else if(G[u].size()>1){
			ret=dfs1(G[u][1].first,u);
			for(int i=2;i<G[u].size();++i)
				ret=mg(ret,dfs1(v,u));		
		}
		//ret.insert(G[u][0].second);
		//ret.mg()
		return ret;
	}
	#undef v
	#undef w
	void work2(){
		//dfs(1,0);
		//s=dfs1(1,0);
		for(it=s.begin();it!=s.end();++it)
			printf("%lld\n",*it);
	}
}
void solve(){
	scanf("%d%d",&n,&K);
	for(int i=1,u,v,w;i<n;++i){
		scanf("%d%d%d",&u,&v,&w);
		G[u].push_back(make_pair(v,w));
		G[v].push_back(make_pair(u,w));
		if(G[u].size()>2||G[v].size()>2)goto G;
	}
	if(n<=1000)goto G;
	//if(n*K<=20000000)Work2::work2(),exit(0);
	Work1::work1();exit(0);
	G:;
	//cerr<<"wea"<<endl;
	dep[1]=1;
	dfs(1);
	for(int i=1;i<=15;++i)
		for(int j=1;j<=n;++j)
			fa[i][j]=fa[i-1][fa[i-1][j]];
	for(int i=1;i<=n;++i){
		for(int j=i+1;j<=n;++j){
			Q.push(dis[i]+dis[j]-2*dis[lca(i,j)]);
		}
	}
	for(int i=0;i<K;++i)
		printf("%lld\n",Q.top()),Q.pop();
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	solve();
	return 0;
} 
