/*
Author: CNYALI_LK
LANG: C++
PROG: sequence.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
int a[211111];
struct smt{
	smt *l,*r;
	int ls,rs,se1,se0,mx,as,os;
	smt(int la,int ra){
		se1=se0=0;
		ls=la;rs=ra;
		if(ls==rs){
			mx=as=os=a[la];
			l=r=0;
		}
		else{
			int mid=(la+ra)>>1;
			l=new smt(la,mid);
			r=new smt(mid+1,ra);
			mx=max(l->mx,r->mx);
			as=l->as&r->as;
			os=l->os|r->os;
		}
	}
	void push_up(){
		mx=max(l->mx,r->mx);
		as=l->as&r->as;
		os=l->os|r->os;
	}
	void set_tag1(int s){
		mx=mx|s;
		as|=s;
		os|=s;
		se1|=s;
	}
	void set_tag0(int s){
		mx=mx&(~s);
		se0|=s;
		as&=~s;
		os&=~s;
	}
	void push_down(){
		if(!l)return;
		l->set_tag1(se1);
		r->set_tag1(se1);
		l->set_tag0(se0);
		r->set_tag0(se0);
		se1=se0=0;
	}
	int query(int la,int ra){
		if(la<=ls&&rs<=ra)return mx;
		if(rs<la||ra<ls)return 0;
		push_down();
		return max(l->query(la,ra),r->query(la,ra));
	}	
	void set1(int la,int ra,int s){
		s&=~as;	
		if(!s)return;
		if(ra<ls||rs<la)return;
		push_down();
		if(la<=ls&&rs<=ra&&!(os&s)){
			set_tag1(s);
			return;
		}
		else{
			l->set1(la,ra,s);
			r->set1(la,ra,s);
			push_up();
		}
	}
	void set0(int la,int ra,int s){
		s&=os;	
		if(!s)return;
		if(ra<ls||rs<la)return;
		push_down();
		if(la<=ls&&rs<=ra&&!(~as&s)){
			set_tag0(s);
			return;
		}
		else{
			l->set0(la,ra,s);
			r->set0(la,ra,s);
			push_up();
		}
	}

};
smt *root;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int n,q,ty,l,r,s;
	n=read(),q=read();
	int faq=(1<<20)-1;
	for(int i=1;i<=n;++i){
		a[i]=read();
	}
	root=new smt(1,n);
	while(q){
		--q;
		ty=read();l=read();r=read();
		if(ty==3){
			printf("%d\n",root->query(l,r));	
		}
		else{
			s=read();
			if(ty^1){
				root->set1(l,r,s);
			}
			else{
				root->set0(l,r,s^faq);
			}
		}
	}
	return 0;
}

