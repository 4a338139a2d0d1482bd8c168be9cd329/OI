#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

int Read() {
	char c = getchar();
	while (c > '9' || c < '0') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

using namespace std;

typedef long long LL;

const int N = 2e5 + 10;

struct Persistent_Segment_Tree {

	const static int NODE = 2.5e7 + 10;

	int lc[NODE], rc[NODE], sz[NODE], node;

	#define M ((L + R) >> 1)

	void insert(int &o, int ro, int L, int R, int x) {
		o = ++node;
		sz[o] = sz[ro] + 1, lc[o] = lc[ro], rc[o] = rc[ro];
		if (L < R) {
			if (x <= M) insert(lc[o], lc[ro], L, M, x);
			else insert(rc[o], rc[ro], M + 1, R, x);
		}
	}

	int kth(int o, int L, int R, int k) {
		if (sz[o] < k) return 0;
		if (L == R) return L;
		if (sz[rc[o]] >= k) return kth(rc[o], M + 1, R, k);
		else return kth(lc[o], L, M, k - sz[rc[o]]);
	}

}T;

int n, K;
int Begin[N], Next[N << 1], to[N << 1], len[N << 1], e;

void add(int u, int v, int w) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e, len[e] = w;
}

int cen, nowsz, minsz;
int sz[N];
bool vis[N];

void DFS_centroid(int o, int f) {
	sz[o] = 1;
	int mx = 0;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (vis[u] || u == f) continue;
		DFS_centroid(u, o);
		sz[o] += sz[u];
		mx = max(mx, sz[u]);
	}
	mx = max(mx, nowsz - sz[o]);
	if (mx < minsz) minsz = mx, cen = o;
}

int fa[N][18], root[N][18], dep[N], c;
int pos[N][18];
LL dis[N][18], *num;

void DFS_dis(int o, int f) {
	sz[o] = 1;
	int d = dep[o];
	num[++c] = dis[o][d];
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f || vis[u]) continue;
		dis[u][++dep[u]] = dis[o][d] + len[i];
		fa[u][d] = fa[o][d];
		DFS_dis(u, o);
		sz[o] += sz[u];
	}
}

LL buffer[N * 20], *p = buffer, *val[N];
int szv[N];
int nowrt, prert, nowmx, premx;

void DFS_insert(int o, int f, bool flag) {
	int id = lower_bound(num + 1, num + c + 1, dis[o][dep[o]]) - num;
	if (!flag) T.insert(nowrt, nowrt, 1, c, id);
	nowmx = max(nowmx, id);
	root[o][dep[o]] = prert;
	pos[o][dep[o]] = premx;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f || vis[u]) continue;
		DFS_insert(u, o, flag);
	}
}

void Divide_Conquer(int rt, int _n, int d) {
	
	nowsz = minsz = _n, cen = rt;
	DFS_centroid(rt, 0);
	int o = cen;
	vis[o] = true;

	if (_n == 1) return;

	val[o] = num = p;
	num[c = 1] = 0;
	++dep[o];
	fa[o][d] = o, dis[o][d] = 0;

	int lst = 0;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (vis[u]) continue;
		dis[u][++dep[u]] = len[i];
		fa[u][d] = o;
		DFS_dis(u, o);
		lst = u;
	}
	sort(num + 1, num + c + 1), c = unique(num + 1, num + c + 1) - num - 1;
	p += c + 3;
	szv[o] = c;

	T.insert(nowrt, 0, 1, c, 1);
	nowmx = 1;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (vis[u]) continue;
		prert = nowrt, premx = nowmx;
		DFS_insert(u, o, u == lst);
	}

	for (int i = Begin[o]; i; i = Next[i])
		if (!vis[to[i]]) Divide_Conquer(to[i], sz[to[i]], d + 1);

}

LL mxl[N][18];

struct Node {
	int o, x;

	bool operator < (const Node& A) const {
		return mxl[o][x] < mxl[A.o][A.x];
	}
	
	bool operator > (const Node& A) const {
		return mxl[o][x] > mxl[A.o][A.x];
	}

}A[N * 18];

int main() {

	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	n = Read(), K = Read();
	For(i, 2, n) {
		int u = Read(), v = Read(), l = Read();
		add(u, v, l), add(v, u, l);
	}
	Divide_Conquer(1, n, 1);

	c = 0;
	For(i, 1, n) For(j, 1, dep[i]) {
		int f = fa[i][j], x = pos[i][j];
		if (x) {
			mxl[i][j] = val[f][x] + dis[i][j];
			pos[i][j] = 1;
			A[++c] = (Node){i, j};
		}
	}

	sort(A + 1, A + c + 1, greater<Node>());

	priority_queue<Node> q;
	For(i, 1, min(K, c)) q.push(A[i]);
	For(i, 1, K) {

		Node s = q.top(); q.pop();
		int o = s.o, x = s.x, f = fa[o][x];
		printf("%lld\n", mxl[o][x]);
		int d = T.kth(root[o][x], 1, szv[f], ++pos[o][x]);
		if (d) {
			mxl[o][x] = val[f][d] + dis[o][x];
			q.push((Node){o, x});
		}
	}

	return 0;
}
