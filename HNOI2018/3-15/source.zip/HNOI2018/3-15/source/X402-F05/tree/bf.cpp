#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 2e5 + 10;

int n, K;
int Begin[N], Next[N << 1], to[N << 1], len[N << 1], e;

void add(int u, int v, int w) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e, len[e] = w;
}

LL dis[N * 100];
int c;

void DFS(int o, int f, LL d) {
	dis[++c] = d;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f) continue;
		DFS(u, o, d + len[i]);
	}
}

int main() {

	freopen("tree.in", "r", stdin);
	freopen("tree.ans", "w", stdout);

	scanf("%d%d", &n, &K);
	For(i, 2, n) {
		int u, v, l;
		scanf("%d%d%d", &u, &v, &l);
		add(u, v, l), add(v, u, l);
	}
	For(i, 1, n) DFS(i, 0, 0);

	sort(dis + 1, dis + c + 1, greater<LL>());
	For(i, 1, K) printf("%lld\n", dis[i << 1]);

	return 0;
}
