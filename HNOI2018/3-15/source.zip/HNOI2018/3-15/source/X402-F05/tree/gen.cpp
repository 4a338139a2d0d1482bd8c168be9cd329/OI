#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("tree.in", "w", stdout);
	
	srand(time(0));

	int n = 3000, k = max(n - 10, randint(1, min(200000ll, 1ll * n * (n - 1) / 2)));
	printf("%d %d\n", n, k);
	For(i, 2, n) printf("%d %d %d\n", i, randint(max(i - 100, 1), i - 1), randint(1, 1e9));

	return 0;
}
