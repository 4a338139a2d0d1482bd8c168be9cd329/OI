#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 110;

int n, K;
int A[N][N];

namespace BF {

	int P[N];

	void main() {
		int ct = 1;
		For(i, 1, n) ct *= i, P[i] = i;
		while (ct--) {
			int sum = 0;
			bool flag = true;
			For(i, 1, n) {
				if (A[i][P[i]] == -1) {
					flag = false;
					break;
				}
				sum = (sum + A[i][P[i]]) % K;
			}
			if (flag && !sum) {
				puts("Yes");
				return;
			}
			next_permutation(P + 1, P + n + 1);
		}
		puts("No");
	}

};

namespace Cheat {

	bool dp[N][N];

	void main() {

		dp[0][0] = true;
		For(i, 1, n) For(j, 0, K - 1) For(c, 1, n)
			if (dp[i - 1][j] && A[i][c] >= 0) dp[i][(j + A[i][c]) % K] = true;

		if (!dp[n][0]) {
			puts("No");
			return;
		}

		memset(dp, false, sizeof dp);
		dp[0][0] = true;
		For(i, 1, n) For(j, 0, K - 1) For(c, 1, n)
			if (dp[i - 1][j] && A[c][i] >= 0) dp[i][(j + A[c][i]) % K] = true;

		if (!dp[n][0]) {
			puts("No");
			return;
		}

		puts("Yes");
	}

};

int main() {

	freopen("luckymoney.in", "r", stdin);
	freopen("luckymoney.out", "w", stdout);

	scanf("%d%d", &n, &K);
	For(i, 1, n) For(j, 1, n) scanf("%d", &A[i][j]);

	if (n <= 10) BF::main();
	else Cheat::main();

	return 0;
}
