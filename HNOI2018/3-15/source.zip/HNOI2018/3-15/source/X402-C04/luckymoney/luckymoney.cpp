#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

const int N=109;
int n,k;
int a[N][N],b[N];


int main()
{
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);

	n=read();k=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			a[i][j]=read();
	for(int i=1;i<=n;i++)
		b[i]=i;
	do
	{
		int sum=0;
		for(int i=1;i<=n;i++)
			if(a[i][b[i]]!=-1)
				sum=(sum+a[i][b[i]])%k;
			else goto nxt;
		if(!sum)
			goto putans;
		nxt:;
	}while(next_permutation(b+1,b+n+1));

	puts("No");
	return 0;
	putans:;
	puts("Yes");
	return 0;
}
