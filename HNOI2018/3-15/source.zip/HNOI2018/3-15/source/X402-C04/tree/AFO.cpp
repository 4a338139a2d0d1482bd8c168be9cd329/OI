#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N=2e5+9;
const ll K=21;

ll n,k;
ll to[N<<1],nxt[N<<1],w[N<<1],beg[N],tot;
ll fa[N][K],dep[N],deg[N];
ll dis[N],stk[N];
priority_queue<ll,vector<ll>,greater<ll> > q;

inline ll read()
{
	ll x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void add(ll u,ll v,ll c)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	w[tot]=c;
	deg[v]++;
	beg[u]=tot;
}

inline void dfs(ll u)
{
	for(ll i=beg[u];i;i=nxt[i])
		if(to[i]!=fa[u][0])
		{
			fa[to[i]][0]=u;
			dep[to[i]]=dep[u]+1;
			dis[to[i]]=dis[u]+w[i];
			dfs(to[i]);
		}
}

inline ll lca(ll a,ll b)
{
	if(dep[a]>dep[b])swap(a,b);
	for(ll i=K-1;i>=0;i--)
		if(dep[fa[b][i]]>=dep[a])
			b=fa[b][i];
	if(a==b)return a;
	for(ll i=K-1;i>=0;i--)
		if(fa[a][i]!=fa[b][i])
			a=fa[a][i],b=fa[b][i];
	return fa[a][0];
}

namespace trys
{
	typedef pair<ll,ll> pr;
	priority_queue<pr,vector<pr>,greater<pr> > q;
	vector<pr> g[N],stk;
	vector<ll> vec;
	ll qsiz,siz[N],son[N];
	ll id[N],ed[N],seg[N],dfn;

	inline bool push(ll len,ll ways)
	{
		q.push(pr(len,ways));
		qsiz+=ways;
		ll ret=1;
		while(qsiz>k)
		{
			pr u=q.top();
			if(u.first==len && u.second==ways)
				ret=0;
			if(qsiz>=k+u.second)
				q.pop(),qsiz-=u.second;
			else
				q.pop(),u.second-=qsiz-k,q.push(u),qsiz=k;
		}
		return ret;
	}

	inline bool cmp(pr a,pr b)
	{
		return siz[a.second]>siz[b.second];
	}

	inline void dfs(ll u)
	{
		siz[u]=1;seg[id[u]=++dfn]=u;
		for(ll i=beg[u];i;i=nxt[i])
			if(to[i]!=fa[u][0])
			{
				g[u].push_back(pr(w[i],to[i]));
				fa[to[i]][0]=u;
				dep[to[i]]=dep[u]+1;
				dis[to[i]]=dis[u]+w[i];
				dfs(to[i]);
				siz[u]+=siz[to[i]];
				if(!son[u] || siz[to[i]]>siz[son[u]])
					son[u]=to[i];
			}
		ed[u]=dfn;
		sort(g[u].begin(),g[u].end(),cmp);
	}

	inline void dfs_work(ll u,ll cdis)
	{
		for(ll i=0;i<g[u].size();i++)
			dfs_work(g[u][i].second,cdis+g[u][i].first);
		for(ll i=vec.size()-1;i>=0;i--)
			if(!push(cdis+vec[i],1))
				break;
	}

	inline void dfs2(ll u)
	{
		for(ll i=0;i<g[u].size();i++)
			dfs2(g[u][i].second);
		vec.clear();vec.push_back(0);
		for(ll i=0;i<g[u].size();i++)
		{
			dfs_work(g[u][i].second,g[u][i].first);
			for(ll j=id[g[u][i].second],e=ed[g[u][i].second];j<=e;j++)
				vec.push_back(dis[seg[j]]-dis[u]);
			sort(vec.begin(),vec.end());
		}
	}

	inline ll main()
	{
		dfs(1);
		dfs2(1);
		while(!q.empty())
			stk.push_back(q.top()),q.pop();
		for(ll i=stk.size()-1;i>=0;i--)
			for(ll j=stk[i].second;j;j--)
				printf("%d\n",stk[i].first);
		return 0;
	}
}

namespace chain
{
	typedef pair<ll,ll> pr;
	priority_queue<pr> q;
	ll stk[N],id[N],pos[N];
	ll sdis[N];

	inline void dfs_pre(ll u,ll top)
	{
		id[stk[top]=u]=top;sdis[top]=0;
		for(ll i=beg[u];i;i=nxt[i])
			if(to[i]!=fa[u][0])
			{
				fa[to[i]][0]=u;
				dis[to[i]]=dis[u]+w[i];
				dfs_pre(to[i],top+1);
				sdis[top]=sdis[top+1]+w[i];
			}
	}
	
	ll mina()
	{
		ll rt=0;
		for(ll i=1;i<=n;i++)
			if(deg[i]==1)
			{
				rt=i;
				break;
			}
		dfs_pre(rt,1);

		for(ll i=1;i<n;i++)
		{
			pos[i]=n;
			q.push(pr(sdis[i]-sdis[pos[i]],i));
		}
		for(ll i=k;i>=1;i--)
		{
			pr u=q.top();q.pop();
			printf("%lld\n",u.first);
			ll po=u.second;
			pos[po]--;
			if(po<pos[po])
				q.push(pr(sdis[po]-sdis[pos[po]],po));
		}
		return 0;
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("trees.out","w",stdout);

	n=read();k=read();bool fl=0;
	for(ll i=1,u,v,l;i<n;i++)
	{
		u=read();v=read();l=read();
		add(u,v,l);add(v,u,l);
		if(deg[v]>2 || deg[u]>2)fl=1;
	}
	
	dfs(dep[1]=1);
	for(ll i=1;i<K;i++)
		for(ll j=1;j<=n;j++)
			fa[j][i]=fa[fa[j][i-1]][i-1];

	ll siz=0;
	for(ll i=1;i<=n;i++)
		for(ll j=i+1;j<=n;j++)
		{
			ll dist=dis[i]+dis[j]-2*dis[lca(i,j)];
			q.push(dist);siz++;
			if(siz>k)q.pop(),siz--;
		}

	for(ll i=1;i<=k;i++)
		stk[i]=q.top(),q.pop();
	for(ll i=k;i>=1;i--)
		printf("%lld\n",stk[i]);
	return 0;
}
