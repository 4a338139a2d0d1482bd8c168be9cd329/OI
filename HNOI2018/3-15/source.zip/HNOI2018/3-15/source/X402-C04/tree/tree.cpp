#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=2e5+9;
const int K=21;

int n,k;
int to[N<<1],nxt[N<<1],w[N<<1],beg[N],tot;
int fa[N][K],dep[N],deg[N];
ll dis[N],stk[N];
priority_queue<ll,vector<ll>,greater<ll> > q;

inline void write(ll a)
{
	if(a>=10)write(a/10);
	putchar('0'+a%10);
}

inline void add(int u,int v,int c)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	w[tot]=c;
	deg[v]++;
	beg[u]=tot;
}

inline void dfs(int u)
{
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa[u][0])
		{
			fa[to[i]][0]=u;
			dep[to[i]]=dep[u]+1;
			dis[to[i]]=dis[u]+w[i];
			dfs(to[i]);
		}
}

inline int lca(int a,int b)
{
	if(dep[a]>dep[b])swap(a,b);
	for(int i=K-1;i>=0;i--)
		if(dep[fa[b][i]]>=dep[a])
			b=fa[b][i];
	if(a==b)return a;
	for(int i=K-1;i>=0;i--)
		if(fa[a][i]!=fa[b][i])
			a=fa[a][i],b=fa[b][i];
	return fa[a][0];
}

namespace trys
{
	typedef pair<ll,int> pr;
	priority_queue<ll,vector<ll>,greater<ll> > q;
	vector<pr> g[N];
	vector<ll> vec,stk;
	int qsiz,siz[N],son[N];
	int id[N],ed[N],seg[N],dfn;

	inline bool push(ll len)
	{
		if(qsiz==k && len<q.top())return 0;
		q.push(len);qsiz++;
		if(qsiz>k)q.pop(),qsiz--;
		return 1;
	}

	inline bool cmp(pr a,pr b)
	{
		return siz[a.second]>siz[b.second];
	}

	inline void dfs(int u)
	{
		siz[u]=1;seg[id[u]=++dfn]=u;
		for(int i=beg[u];i;i=nxt[i])
			if(to[i]!=fa[u][0])
			{
				g[u].push_back(pr(w[i],to[i]));
				fa[to[i]][0]=u;
				dis[to[i]]=dis[u]+w[i];
				dfs(to[i]);
				siz[u]+=siz[to[i]];
				if(!son[u] || siz[to[i]]>siz[son[u]])
					son[u]=to[i];
			}
		ed[u]=dfn;
	}

	inline void dfs_work(int u,ll cdis)
	{
		for(int i=0;i<g[u].size();i++)
			dfs_work(g[u][i].second,cdis+g[u][i].first);
		for(int i=vec.size()-1;i>=0;i--)
			if(!push(cdis+vec[i]))
				break;
	}

	inline void dfs2(int u)
	{
		for(int i=0;i<g[u].size();i++)
			dfs2(g[u][i].second);
		vec.clear();vec.push_back(0);
		for(int i=0;i<g[u].size();i++)
		{
			dfs_work(g[u][i].second,g[u][i].first);
			for(int j=id[g[u][i].second],e=ed[g[u][i].second];j<=e;j++)
				vec.push_back(dis[seg[j]]-dis[u]);
			sort(vec.begin(),vec.end());
		}
	}

	inline int main()
	{
		dfs(1);dfs2(1);
		while(!q.empty())
			stk.push_back(q.top()),q.pop();
		for(int i=stk.size()-1;i>=0;i--)
			write(stk[i]),putchar('\n');
		return 0;
	}
}

namespace chain
{
	typedef pair<ll,int> pr;
	priority_queue<pr> q;
	int stk[N],id[N],pos[N];
	ll sdis[N];

	inline void dfs_pre(int u,int top)
	{
		id[stk[top]=u]=top;sdis[top]=0;
		for(int i=beg[u];i;i=nxt[i])
			if(to[i]!=fa[u][0])
			{
				fa[to[i]][0]=u;
				dis[to[i]]=dis[u]+w[i];
				dfs_pre(to[i],top+1);
				sdis[top]=sdis[top+1]+w[i];
			}
	}
	
	int mina()
	{
		int rt=0;
		for(int i=1;i<=n;i++)
			if(deg[i]==1)
			{
				rt=i;
				break;
			}
		dfs_pre(rt,1);

		for(int i=1;i<n;i++)
		{
			pos[i]=n;
			q.push(pr(sdis[i]-sdis[pos[i]],i));
		}
		for(int i=k;i>=1;i--)
		{
			pr u=q.top();q.pop();
			printf("%lld\n",u.first);
			int po=u.second;
			pos[po]--;
			if(po<pos[po])
				q.push(pr(sdis[po]-sdis[pos[po]],po));
		}
		return 0;
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);

	n=read();k=read();bool fl=0;
	for(int i=1,u,v,l;i<n;i++)
	{
		u=read();v=read();l=read();
		add(u,v,l);add(v,u,l);
		if(deg[v]>2 || deg[u]>2)fl=1;
	}

	if(!fl)
		return chain::mina();
	else if(n>1000)
		return trys::main();

	dfs(dep[1]=1);
	for(int i=1;i<K;i++)
		for(int j=1;j<=n;j++)
			fa[j][i]=fa[fa[j][i-1]][i-1];

	int siz=0;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
		{
			ll dist=dis[i]+dis[j]-2*dis[lca(i,j)];
			q.push(dist);siz++;
			if(siz>k)q.pop(),siz--;
		}

	for(int i=1;i<=k;i++)
		stk[i]=q.top(),q.pop();
	for(int i=k;i>=1;i--)
		printf("%lld\n",stk[i]);
	return 0;
}
