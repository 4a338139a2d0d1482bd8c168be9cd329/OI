#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=10;
const int M=1e9+7;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("tree.in","w",stdout);

	int n=2000,k=2000;
	printf("%d %d\n",n,k);
	for(int i=2;i<=n;i++)
		printf("%d %d %d\n",urand()%(i-1)+1,i,urand()%M);
	return 0;
}
