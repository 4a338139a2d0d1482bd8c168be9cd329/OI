#include<bits/stdc++.h>
using namespace std;

const int N=2e5+9;

int n,q;
int a[N];

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int maxx(int a,int b){return a>b?a:b;}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequences.out","w",stdout);

	n=read();q=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1,ty,l,r,x;i<=q;i++)
	{
		ty=read();l=read();r=read();
		if(ty!=3)x=read();
		if(ty==1)
			for(int j=l;j<=r;j++)
				a[j]=a[j]&x;
		else if(ty==2)
			for(int j=l;j<=r;j++)
				a[j]=a[j]|x;
		else
		{
			int ans=-1;
			for(int j=l;j<=r;j++)
				ans=maxx(ans,a[j]);
			printf("%d\n",ans);
		}
	}

	return 0;
}
