#include<bits/stdc++.h>
using namespace std;

const int N=2e5+9;
const int all=(1<<20)-1;

int n,q;
int a[N];

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int maxx(int a,int b){return a>b?a:b;}

namespace segt
{
	int tor[N<<2],tand[N<<2],tmax[N<<2];
	int tsand[N<<2],tsor[N<<2];

	inline void update(int x)
	{
		tmax[x]=maxx(tmax[x<<1],tmax[x<<1|1]);
		tsand[x]=tsand[x<<1]&tsand[x<<1|1];
		tsor[x]=tsor[x<<1]|tsor[x<<1|1];
	}

	inline void markor(int x,int v)
	{
		tmax[x]+=(tsand[x]&v)^v;
		tor[x]|=v;
		tsor[x]|=v;
		tsand[x]|=v;
	}

	inline void markand(int x,int v)
	{
		tmax[x]-=tsand[x]&(v^all);
		tand[x]&=v;
		tor[x]&=v;
		tsor[x]&=v;
		tsand[x]&=v;
	}

	inline void push(int x)
	{
		if(tand[x]!=all)
		{
			markand(x<<1,tand[x]);
			markand(x<<1|1,tand[x]);
			tand[x]=all;
		}
		if(tor[x])
		{
			markor(x<<1,tor[x]);
			markor(x<<1|1,tor[x]);
			tor[x]=0;
		}
	}

	inline void build(int x,int l,int r)
	{
		tor[x]=0;tand[x]=all;
		if(l==r)
		{
			tmax[x]=tsand[x]=tsor[x]=a[l];
			return;
		}
		int mid=l+r>>1;
		build(x<<1,l,mid);
		build(x<<1|1,mid+1,r);
		update(x);
	}

	inline void modand(int x,int l,int r,int dl,int dr,int v)
	{
		if(l!=r)push(x);int mid=l+r>>1;
		if(dl==l && r==dr && ((v^all)&tsand[x])==((v^all)&tsor[x]))
		{
			markand(x,v);
			return;
		}
		if(dr<=mid)
			modand(x<<1,l,mid,dl,dr,v);
		else if(mid<dl)
			modand(x<<1|1,mid+1,r,dl,dr,v);
		else
		{
			modand(x<<1,l,mid,dl,mid,v);
			modand(x<<1|1,mid+1,r,mid+1,dr,v);
		}
		update(x);
	}

	inline void modor(int x,int l,int r,int dl,int dr,int v)
	{
		if(l!=r)push(x);int mid=l+r>>1;
		if(dl==l && r==dr && (tsand[x]&v)==(tsor[x]&v))
		{
			markor(x,v);
			return;
		}
		if(dr<=mid)
			modor(x<<1,l,mid,dl,dr,v);
		else if(mid<dl)
			modor(x<<1|1,mid+1,r,dl,dr,v);
		else
		{
			modor(x<<1,l,mid,dl,mid,v);
			modor(x<<1|1,mid+1,r,mid+1,dr,v);
		}
		update(x);
	}

	inline int query(int x,int l,int r,int dl,int dr)
	{
		if(l!=r)push(x);
		if(dl==l && r==dr)return tmax[x];
		int mid=l+r>>1;
		if(dr<=mid)return query(x<<1,l,mid,dl,dr);
		else if(mid<dl)return query(x<<1|1,mid+1,r,dl,dr);
		else return maxx(query(x<<1,l,mid,dl,mid),query(x<<1|1,mid+1,r,mid+1,dr));
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);

	n=read();q=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	segt::build(1,1,n);
	for(int i=1,ty,l,r,x;i<=q;i++)
	{
		ty=read();l=read();r=read();
		if(ty!=3)x=read();
		if(ty==1)
			segt::modand(1,1,n,l,r,x);
		else if(ty==2)
			segt::modor(1,1,n,l,r,x);
		else
			printf("%d\n",segt::query(1,1,n,l,r));
	}

	return 0;
}

