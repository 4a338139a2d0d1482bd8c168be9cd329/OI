#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=10;
const int M=1048576;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("sequence.in","w",stdout);

	int n=5000,m=5000;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",urand()%M);
	puts("");
	for(int i=1;i<=m;i++)
	{
		int ty=rand()%3+1,l=rand()%n+1,r=rand()%n+1;
		if(l>r)swap(l,r);
		if(ty==3)printf("%d %d %d\n",ty,l,r);
		else printf("%d %d %d %d\n",ty,l,r,rand()%M);
	}
	return 0;
}
