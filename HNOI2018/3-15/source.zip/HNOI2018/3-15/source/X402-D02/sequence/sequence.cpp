#include<iostream>
#include<cstdio>
#include<cstring>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace PupilHasGone
{
	const int N=200010,M=N*4;
	const int U=(1<<20)-1;

	int A[N];
	int n,m;

#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
	int sumor[M],sumad[M],tagor[M],tagad[M],max[M];
	inline void put_or(int p,int x)
	{
		sumor[p]|=x;
		sumad[p]|=x;
		tagor[p]|=x;
		tagad[p]|=x;
		max[p]|=x;
	}
	inline void put_ad(int p,int x)
	{
		sumor[p]&=x;
		sumad[p]&=x;
		tagad[p]&=x;
		max[p]&=x;
	}
	inline void upd(int p)
	{
		sumor[p]=sumor[lt]|sumor[rt];
		sumad[p]=sumad[lt]&sumad[rt];
		max[p]=std::max(max[lt],max[rt]);
	}
	inline void down(int p)
	{
		if(tagor[p])
		{
			put_or(lt,tagor[p]);
			put_or(rt,tagor[p]);
			tagor[p]=0;
		}
		if(tagad[p]!=U)
		{
			put_ad(lt,tagad[p]);
			put_ad(rt,tagad[p]);
			tagad[p]=U;
		}
	}
	void build(int p=1,int L=1,int R=n)
	{
		if(L==R)sumor[p]=sumad[p]=max[p]=A[L],tagad[p]=U;
		else build(lcq),build(rcq),upd(p),tagad[p]=U;
	}
	void modify_or(int s,int t,int x,int p=1,int L=1,int R=n)
	{
		if(s>R || t<L)return;
		if(L>=s && R<=t && (sumor[p]&x)==(sumad[p]&x)){put_or(p,x);return;}
		if(L==R){put_or(p,x);return;}
		down(p);
		modify_or(s,t,x,lcq),modify_or(s,t,x,rcq);
		upd(p);
	}
	void modify_ad(int s,int t,int x,int p=1,int L=1,int R=n)
	{
		if(s>R || t<L)return;
		if(L>=s && R<=t && (sumad[p]&(U^x))==(sumor[p]&(U^x))){put_ad(p,x);return;}
		if(L==R){put_ad(p,x);return;}
		down(p);
		modify_ad(s,t,x,lcq),modify_ad(s,t,x,rcq);
		upd(p);
	}
	int query(int s,int t,int p=1,int L=1,int R=n)
	{
		if(s>R || t<L)return 0;
		if(L>=s && R<=t)return max[p];
		down(p);
		return std::max(query(s,t,lcq),query(s,t,rcq));
	}

	void initialize()
	{
		read(n),read(m);
		for(int i=1;i<=n;i++)
			read(A[i]);
		build();
	}
	void solve()
	{
		initialize();
		int ty,l,r,x;
		while(m--)
		{
			read(ty),read(l),read(r);
			if(ty==3){printf("%d\n",query(l,r));continue;}
			read(x);
			if(ty==1)modify_ad(l,r,x);
			else modify_or(l,r,x);
		}
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	PupilHasGone::solve();
	return 0;
}
