#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#include<set>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace random_algorithm
{
	typedef long long ll;
	typedef std::set<ll>::iterator sit;
	const int N=201000;
	int begin[N],next[N*2],to[N*2],w[N*2];

	int n,m,e;

	void add(int x,int y,int z,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		w[e]=z;
		if(k)add(y,x,z,0);
	}

	void initialize()
	{
		read(n),read(m);
		for(int i=1,u,v,h;i<n;i++)
			read(u),read(v),read(h),add(u,v,h);
	}

	std::priority_queue<ll,std::vector<ll>,std::greater<ll> >Q;
	std::set<ll> S;

	bool vis[N];
	int siz[N];
	ll dis[N];
	int getit(int p,int h,int size)
	{
		siz[p]=1;
		int ret,flag=1;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !vis[q])
			{
				ret=getit(q,p,size);
				if(ret>0)return ret;
				siz[p]+=siz[q];
				if(siz[q]>size/2)flag=0;
			}
		if(size-siz[p]>size/2)flag=0;
		return flag*p;
	}
	void dfs(int p,int h)
	{
		siz[p]=1;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !vis[q])
			{
				dis[q]=dis[p]+w[i];
				dfs(q,p);
				siz[p]+=siz[q];
			}
	}

	int seq[N],tot;
	void got(int p,int h)
	{
		seq[++tot]=p;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !vis[q])got(q,p);
	}
	void DC(int p,int size)
	{
		if(size==1)return;
		p=getit(p,0,size),dis[p]=0,dfs(p,0);

		S.clear();
		S.insert(0);
		sit it;

		for(int i=begin[p],q;i;i=next[i])
			if(!vis[q=to[i]])
			{
				tot=0,got(q,p);

				for(int i=1;i<=tot;i++)
				{
					for(it=--S.end();;it--)
					{
						ll x=*it+dis[seq[i]];

						if((int)Q.size()<m)Q.push(x);
						else if(x>Q.top())Q.push(x),Q.pop();
						else break;
						
						if(it==S.begin())break;
					}
				}
				for(int i=1;i<=tot;i++)
					S.insert(dis[seq[i]]);
			}

		vis[p]=1;
		for(int i=begin[p],q;i;i=next[i])
			if(!vis[q=to[i]])DC(q,siz[q]);
	}

	ll ans[N];

	void solve()
	{
		initialize();
		DC(1,n);
		tot=0;
		while(!Q.empty())ans[++tot]=Q.top(),Q.pop();
		for(int i=tot;i;i--)printf("%lld\n",ans[i]);
	}
}

int main(int hh,char *gg[])
{
	printf(":%d\n",hh);
	printf("%s\n",gg[0]);
	return 0;

	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	random_algorithm::solve();
	return 0;
}
