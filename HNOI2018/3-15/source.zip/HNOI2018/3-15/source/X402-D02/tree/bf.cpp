#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

typedef long long ll;

const int N=1050;

int begin[N],next[N*2],to[N*2],w[N*2];

ll dis[N];

int n,m,e;

void add(int x,int y,int z,bool k=1)
{
	to[++e]=y;
	next[e]=begin[x];
	begin[x]=e;
	w[e]=z;
	if(k)add(y,x,z,0);
}

void initialize()
{
	scanf("%d%d",&n,&m);
	for(int i=1,u,v,h;i<n;i++)
		scanf("%d%d%d",&u,&v,&h),add(u,v,h);
}
void dfs(int p,int h=0)
{
	for(int i=begin[p],q;i;i=next[i])
		if((q=to[i])!=h)dis[q]=dis[p]+w[i],dfs(q,p);
}

ll s[N*N];
int tot;

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.ans","w",stdout);
	initialize();
	tot=0;
	for(int i=1;i<=n;i++)
	{
		dis[i]=0,dfs(i);
		for(int j=i+1;j<=n;j++)
			s[++tot]=dis[j];
	}
	std::sort(s+1,s+tot+1);
	for(int i=tot;i>=tot-m+1;i--)
		printf("%lld\n",s[i]);
	return 0;
}
