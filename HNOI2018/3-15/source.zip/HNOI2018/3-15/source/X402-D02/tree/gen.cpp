#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("tree.in","w",stdout);//look at here

	int n=1000,m=2333,lim=1000000000;

	printf("%d %d\n",n,m);

	for(int i=2;i<=n;i++)
//		printf("%d %d %d\n",rand()%(i-1)+1,i,rand()%lim+1);
		printf("%d %d %d\n",i-1,i,rand()%lim+1);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
