//2018-3-15
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (200000 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0'); chr = getchar();
	}
}
inline void ReadL(LL &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0'); chr = getchar();
	}
}

struct node{
	int v;
	LL w;
};

int n, m;
vector<node> G[N];
vector<LL> son[N];
priority_queue<LL> q;

#define v G[now][i].v
void Dfs(int now, int F){
	son[now].pb(0);
	LL dis;

	For(i, 0, G[now].size() - 1) if(v != F){
		Dfs(v, now);
		For(j, 0, son[v].size() - 1){
			dis = son[v][j] + G[now][i].w;
			For(k, 0, son[now].size() - 1) q.push(dis + son[now][k]);
		}
		For(j, 0, son[v].size() - 1) son[now].pb(son[v][j] + G[now][i].w);
	}
}
#undef v

void Bf(){
	Dfs(1, 0);
	while(m --){
		printf("%lld\n", q.top()); q.pop();
	}
}

int dig[N];
LL d[N];

struct Heap{
	int l, r;
	bool operator <(const Heap &rhs)const{
		return d[r] - d[l - 1] < d[rhs.r] - d[rhs.l - 1];
	}
};
struct Pair{
	int a, b;
	bool operator <(const Pair &rhs)const{
		return (LL)a * n + b < (LL)rhs.a * n + rhs.b;
	}
};

map<Pair, int> ms;
priority_queue<Heap> qq;

void Cheat(int st){
	int nn = 0, F = 0;
	while(true){
		For(i, 0, G[st].size() - 1) if(G[st][i].v != F){
			d[++nn] = G[st][i].w; F = st; st = G[st][i].v;
		}
		if(dig[st] == 1) break;
	}
	For(i, 1, nn) d[i] += d[i - 1];
	
	Heap now;
	Pair tmp;

	qq.push((Heap){1, nn});
	while(m --){
		now = qq.top(); qq.pop();
		printf("%lld\n", d[now.r] - d[now.l - 1]);

		if(now.l < now.r){
			++now.l; tmp = (Pair){now.l, now.r};
			if(!ms.count(tmp)){
				qq.push(now), ms[tmp] = true;
			}
			--now.l, --now.r; tmp = (Pair){now.l, now.r};
			if(!ms.count(tmp)){
				qq.push(now), ms[tmp] = true;
			}
		}
	}
}

int main(){
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	
	int u, v;
	LL w;

	Read(n); Read(m);
	For(i, 1, n - 1){
		Read(u), Read(v); ReadL(w);
		G[u].pb((node){v, w}); G[v].pb((node){u, w});
		++dig[u]; ++dig[v];
	}

	if(n <= 1000){Bf(); return 0;}
	
	int st, mx = 0;
	For(i, 1, n){
		if(dig[i] == 1) st = i;
		mx = max(mx, dig[i]);
	}

	if(mx <= 2){Cheat(st); return 0;}

	return 0;
}
