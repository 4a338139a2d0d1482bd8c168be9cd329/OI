//2018-3-15
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int main(){
	freopen("tree.in", "w", stdout);

	srand(time(NULL));
	int n = 7, m = rand() % 3 + rand() % 5;
	printf("%d %d\n", n, m);
	For(i, 1, n - 1) printf("%d %d %d\n", i, i + 1, rand() % 1000000000 + 1);

	return 0;
}
