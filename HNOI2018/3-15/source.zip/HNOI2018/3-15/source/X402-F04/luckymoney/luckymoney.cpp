//2018-3-15
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (100 + 5)

int n, m, a[N][N];
bool vis[N], flag;

void Dfs(int now, int sum){
	if(flag) return;
	if(now > n){
		if(sum % m == 0) flag = true;
		return;
	}

	For(i, 1, n) if(!vis[i] && a[now][i] != -1){
		vis[i] = true; Dfs(now + 1, sum + a[now][i]);
		vis[i] = false;
	}
}

int id[N];

int main(){
	freopen("luckymoney.in", "r", stdin);
	freopen("luckymoney.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	For(i, 1, n) For(j, 1, n) scanf("%d", &a[i][j]);
	if(n <= 10){Dfs(1, 0); printf("%s", flag? "Yes": "No"); return 0;}
	
	For(i, 1, n) id[i] = i;

	srand(time(NULL));

	int cnt = 1000000, sum;

	while(cnt --){
		random_shuffle(id + 1, id + n + 1);
		
		flag = true; sum = 0;
		For(i, 1, n){
			if(a[i][id[i]] == -1){flag = false; break;}
			sum += a[i][id[i]];
		}

		if(sum % m == 0 && flag){
			puts("Yes"); return 0;
		}
	}
	
	printf("%s\n", rand() % 3? "Yes": "No");

	return 0;
}
