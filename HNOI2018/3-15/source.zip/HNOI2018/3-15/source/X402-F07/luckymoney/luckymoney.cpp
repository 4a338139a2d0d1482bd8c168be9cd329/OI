#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=105;
int K,all;
int n,m,a[maxn][maxn];
bool vis[maxn];
bool dp[1<<20][maxn];
bool check(int now){
	memset(dp,0,sizeof(dp));
	static int t[maxn];
	int cnt=0;
	REP(i,1,n)if(!vis[i])t[++cnt]=i;
	dp[0][0]=1;
	REP(i,0,all){
		int p=__builtin_popcount(i)+1;
		REP(j,0,m-1){
			if(!dp[i][j])continue;
			REP(k,1,K)
				if((!((i>>k-1)&1))&&(a[p][t[k]]!=-1)){
					int tmp=j+a[p][t[k]];
					if(tmp>=m)tmp-=m;
					dp[i^(1<<k-1)][tmp]|=dp[i][j];
				}
		}
	}
	return dp[all][now==0?0:m-now]==1;
}
void DFS(int step,int sum){
	if(step<=K){
		if(check(sum))puts("Yes"),exit(0);
		return;
	}
	static int t[maxn];
	int cnt=0;
	REP(i,1,n)if((a[step][i]!=-1)&&(!vis[i]))t[++cnt]=i;
	if(cnt==0)return;
	int pos=t[rand()%cnt+1],tmp=sum+a[step][pos];
	if(tmp>=m)tmp-=m;
	vis[pos]=1;
	DFS(step-1,sum+a[step][pos]);
	vis[pos]=0;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);
#endif
	srand(time(0));
	n=read(),m=read();
	K=min(n,17),all=(1<<K)-1;
	REP(i,1,n)REP(j,1,n)a[i][j]=read();
	if(n<=K){
		DFS(n,0);
		puts("No");
	}else{
		while(clock()<=CLOCKS_PER_SEC-100000)DFS(n,0);
		puts("No");
	}
//	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
