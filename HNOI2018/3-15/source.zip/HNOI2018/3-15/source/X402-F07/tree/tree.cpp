#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=200005;
int n;
ll m;
struct edge{int to,dis;};
vector<edge>E[maxn];
int sz[maxn];
bool vis[maxn];
void getsz(int u,int fa){
	sz[u]=1;
	REP(i,0,E[u].size()-1){
		int v=E[u][i].to;
		if((v==fa)||(vis[v]))continue;
		getsz(v,u);
		sz[u]+=sz[v];
	}
}
int findroot(int u,int fa,int tot){
	int Maxsz=tot-sz[u];
	REP(i,0,E[u].size()-1){
		int v=E[u][i].to,res;
		if((v==fa)||(vis[v]))continue;
		res=findroot(v,u,tot);
		if(res)return res;
		chkmax(Maxsz,sz[v]);
	}
	return Maxsz<=tot/2?u:0;
}
vector<ll>t1,t2;
struct data{
	bool type;
	vector<ll>t;
};
vector<data>c;
void dfs(int u,int fa,ll d){
	t1.pb(d),t2.pb(d);
	REP(i,0,E[u].size()-1){
		int v=E[u][i].to;
		if((v==fa)||(vis[v]))continue;
		dfs(v,u,d+E[u][i].dis);
	}
}
void div_tree(int u){
	getsz(u,0);
	u=findroot(u,0,sz[u]);
	vis[u]=1;
	t1.clear();
	REP(i,0,E[u].size()-1){
		int v=E[u][i].to;
		if(!vis[v]){
			t2.clear();
			dfs(v,u,E[u][i].dis);
			if(t2.size()){
				sort(t2.begin(),t2.end());
				c.pb((data){0,t2});
			}
		}
	}
	if(t1.size()){
		sort(t1.begin(),t1.end());
		c.pb((data){1,t1});
	}
	REP(i,0,E[u].size()-1){
		int v=E[u][i].to;
		if(!vis[v])div_tree(v);
	}
}
bool check(ll lim){
	ll cnt=0;
	REP(i,0,c.size()-1){
		t1=c[i].t;
		if(c[i].type){
			int cur=t1.size()-1;
			while((cur>=0)&&(t1[cur]>lim))--cur;
			cnt+=2*(cur+1);
			REP(j,0,t1.size()-1){
				while((cur>=0)&&(t1[j]+t1[cur]>lim))--cur;
				if(cur==-1)break;
				cnt+=cur+1;
			}
			if(cnt>=2*m)return 1;
		}else{
			int cur=t1.size()-1;
			REP(k,0,t1.size()-1){
				while((cur>=0)&&(t1[k]+t1[cur]>lim))--cur;
				if(cur==-1)break;
				cnt-=cur+1;
			}
		}
	}
	return 0;
}
vector<ll>ans;
multiset<ll>s;
multiset<ll>::iterator it;
void getans(ll lim){
	REP(i,0,c.size()-1){
		int j=i;
		while(c[j].type==0)++j;
		t1=c[j].t;
		REP(j,0,t1.size()-1)s.insert(t1[j]);
		it=s.end(),--it;
		while((*it)>=lim){
			ans.pb(*it);
			if(it==s.begin())break;
			--it;
		}
		REP(k,i,j-1){
			t1=c[k].t;
			REP(l,0,t1.size()-1)
				it=s.lower_bound(t1[l]),s.erase(it);
			if(k==j-1)break;
			REP(l,0,t1.size()-1){
				it=s.end(),--it;
				while((*it)+t1[l]>=lim){
					ans.pb((*it)+t1[l]);
					if(it==s.begin())break;
					--it;
				}
			}
		}
		i=j;
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
#endif
	n=read(),m=1ll*n*(n-1)/2-read()+1;
	REP(i,2,n){
		int u=read(),v=read(),w=read();
		E[u].pb((edge){v,w});
		E[v].pb((edge){u,w});
	}
	div_tree(1);
//	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	ll l=1,h=2e14;
	while(l<=h){
		ll mid=(l+h)>>1;
		if(check(mid))h=mid-1;
		else l=mid+1;
	}
//	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	getans(l+1);
	sort(ans.begin(),ans.end(),greater<ll>());
	m=1ll*n*(n-1)/2-m+1;
	REP(i,0,ans.size()-1)write(ans[i],'\n');
	REP(i,ans.size()+1,m)write(l,'\n');
//	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
