#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=200005,all=(1<<20)-1;
int n,m;
struct seg_tree{
	int Max[maxn<<2];
	int sum0[maxn<<2],sum1[maxn<<2];
	int tag0[maxn<<2],tag1[maxn<<2];
	void push_down(int p,int u,int v){
		Max[u]&=tag0[p];
		sum0[u]&=tag0[p],sum1[u]&=tag0[p];
		tag0[u]&=tag0[p],tag1[u]&=tag0[p];
		Max[u]|=tag1[p];
		sum0[u]|=tag1[p],sum1[u]|=tag1[p];
		tag0[u]|=tag1[p],tag1[u]|=tag1[p];
		Max[v]&=tag0[p];
		sum0[v]&=tag0[p],sum1[v]&=tag0[p];
		tag0[v]&=tag0[p],tag1[v]&=tag0[p];
		Max[v]|=tag1[p];
		sum0[v]|=tag1[p],sum1[v]|=tag1[p];
		tag0[v]|=tag1[p],tag1[v]|=tag1[p];
		tag0[p]=all,tag1[p]=0;
	}
	void push_up(int p,int u,int v){
		Max[p]=max(Max[u],Max[v]);
		sum0[p]=sum0[u]&sum0[v];
		sum1[p]=sum1[u]|sum1[v];
	}
	void build(int p,int l,int r){
		tag0[p]=all,tag1[p]=0;
		if(l==r){
			Max[p]=sum0[p]=sum1[p]=read();
			return;
		}
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		build(u,l,mid);
		build(v,mid+1,r);
		push_up(p,u,v);
	}
	void update(int p,int l,int r,int L,int R,int x,bool type){
		if((L<=l)&&(R>=r)){
			int tmp=sum0[p]|(sum1[p]^all);
			if(type==0){
				if(((x^all)&tmp)==(x^all)){
					Max[p]&=x;
					tag0[p]&=x,tag1[p]&=x;
					sum0[p]&=x,sum1[p]&=x;
					return;
				}
			}else{
				if((x&tmp)==x){
					Max[p]|=x;
					tag0[p]|=x,tag1[p]|=x;
					sum0[p]|=x,sum1[p]|=x;
					return;
				}
			}
		}
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		push_down(p,u,v);
		if(L<=mid)update(u,l,mid,L,R,x,type);
		if(R>mid)update(v,mid+1,r,L,R,x,type);
		push_up(p,u,v);
	}
	int query(int p,int l,int r,int L,int R){
		if((L<=l)&&(R>=r))return Max[p];
		int mid=(l+r)>>1,u=p<<1,v=u+1,res=0;
		push_down(p,u,v);
		if(L<=mid)chkmax(res,query(u,l,mid,L,R));
		if(R>mid)chkmax(res,query(v,mid+1,r,L,R));
		return res;
	}
}T;
int main(){
#ifndef ONLINE_JUDGE
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
#endif
	n=read(),m=read();
	T.build(1,1,n);
	REP(i,1,m){
		int type=read(),l=read(),r=read(),x;
		if(type==3)write(T.query(1,1,n,l,r),'\n');
		else{
			x=read();
			T.update(1,1,n,l,r,x,type-1);
		}
	}
	return 0;
}
