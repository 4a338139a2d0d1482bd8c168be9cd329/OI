#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int maxn=2e5+10;

int n,K;

int deg[maxn];

int head[maxn],nxt[maxn<<1],to[maxn<<1],w[maxn<<1],e;
void ae(int x,int y,int c){
    to[++e]=y; nxt[e]=head[x]; head[x]=e; w[e]=c;
}

namespace solver1{
    LL stk[2000010];
    int top;

    void dfs(int u,int fa,LL dis){
        if(fa) stk[++top]=dis;
        for(int i=head[u];i;i=nxt[i]) if(to[i]!=fa) dfs(to[i],u,dis+w[i]);
    }

    void solve(){
        for(int i=1;i<=n;i++) dfs(i,0,0);
        sort(stk+1,stk+top+1,greater<LL>());
        for(int i=1;i<=K<<1;i+=2) printf("%lld\n",stk[i]);
    }
}

namespace solver2{
    int a[maxn];
    LL sum[maxn];

    struct node{
        LL d;
        int l,r;
        node(LL _d,int _l,int _r):d(_d),l(_l),r(_r){}
        bool operator < (const node& rhs) const{
            return d<rhs.d;
        }
    };

    priority_queue<node> q;

    void solve(){
        for(int i=1;i<=n;i++) if(deg[i]==1){
            int pre=0,k=i;
            for(int j=1;j<=n;j++){
                a[j]=k;
                for(int ii=head[k];ii;ii=nxt[ii]) if(to[ii]!=pre){
                    sum[j+1]=sum[j]+w[ii];
                    pre=k; k=to[ii];
                    break;
                }
            }
            break;
        }
        q.push(node(sum[n],1,n));
        for(int i=1;i<=K;i++){
            node u=q.top(); q.pop();
            printf("%lld\n",u.d);
            if(u.l<u.r-1){
                q.push(node(sum[u.r-1]-sum[u.l],u.l,u.r-1));
                if(u.r==n) q.push(node(sum[u.r]-sum[u.l+1],u.l+1,u.r));
            }
        }
    }
}

int main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);

    read(n); read(K);
    for(int i=1;i<n;i++){
        int u,v,c;
        read(u); read(v); read(c);
        ae(u,v,c); ae(v,u,c);
        ++deg[u]; ++deg[v];
    }

    if(n<=1000) solver1::solve(),exit(0);

    solver2::solve();

    return 0;
}
