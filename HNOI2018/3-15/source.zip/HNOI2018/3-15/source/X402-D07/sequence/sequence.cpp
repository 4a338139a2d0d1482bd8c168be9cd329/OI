#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=2e5+10;

int n,q;

namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    const int ALL=(1<<20)-1;

    int Max[maxn<<2],T[maxn<<2][2],tag[maxn<<2][2];

    void init(){
        for(int i=1;i<=n;i++) tag[i][0]=ALL;
    }

    void pushdown(int h){
        if(tag[h][0]!=ALL){
            Max[ls]-=T[ls][0]&(~tag[h][0]);
            Max[rs]-=T[rs][0]&(~tag[h][0]);
            T[ls][0]&=tag[h][0]; T[rs][0]&=tag[h][0];
            T[ls][1]&=tag[h][0]; T[rs][1]&=tag[h][0];
            tag[ls][0]&=tag[h][0]; tag[rs][0]&=tag[h][0];
            tag[ls][1]&=tag[h][0]; tag[rs][1]&=tag[h][0];
            tag[h][0]=ALL;
        }
        if(tag[h][1]){
            Max[ls]+=tag[h][1]^(T[ls][0]&tag[h][1]);
            Max[rs]+=tag[h][1]^(T[ls][0]&tag[h][1]);
            T[ls][0]|=tag[h][1]; T[rs][0]|=tag[h][1];
            T[ls][1]|=tag[h][1]; T[rs][1]|=tag[h][1];
            tag[ls][1]|=tag[h][1]; tag[rs][1]|=tag[h][1];
            tag[h][1]=0;
        }
    }

    void pushup(int h){
        Max[h]=max(Max[ls],Max[rs]);
        T[h][0]=T[ls][0]&T[rs][0];
        T[h][1]=T[ls][1]|T[rs][1];
    }

    void update_or(int h,int l,int r,int L,int R,int w){
        if(L<=l&&r<=R&&(T[h][0]&w)==(T[h][1]&w)){
            Max[h]+=w^(T[h][0]&w);
            T[h][0]|=w; T[h][1]|=w;
            tag[h][1]|=w;
            return;
        }
        pushdown(h);
        if(L<=mid) update_or(ls,lc,L,R,w);
        if(R>mid) update_or(rs,rc,L,R,w);
        pushup(h);
    }

    void update_and(int h,int l,int r,int L,int R,int w){
        if(L<=l&&r<=R&&(T[h][0]&(~w))==(T[h][1]&(~w))){
            Max[h]-=T[h][0]&(~w);
            T[h][0]&=w; T[h][1]&=w;
            tag[h][0]&=w; tag[h][1]&=w;
            return;
        }
        pushdown(h);
        if(L<=mid) update_and(ls,lc,L,R,w);
        if(R>mid) update_and(rs,rc,L,R,w);
        pushup(h);
    }

    int query(int h,int l,int r,int L,int R){
        if(L<=l&&r<=R) return Max[h];
        pushdown(h);
        int ret=0;
        if(L<=mid) chkmax(ret,query(ls,lc,L,R));
        if(R>mid) chkmax(ret,query(rs,rc,L,R));
        return ret;
    }
}

using namespace SGT;

int main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);

    read(n); read(q); init();

    int x;
    for(int i=1;i<=n;i++) read(x),update_or(1,1,n,i,i,x);

    for(int i=1;i<=q;i++){
        int op,l,r;
        read(op); read(l); read(r);

        if(op==1){
            read(x);
            update_and(1,1,n,l,r,x);
        }

        if(op==2){
            read(x);
            update_or(1,1,n,l,r,x);
        }

        if(op==3) printf("%d\n",query(1,1,n,l,r));
    }

    return 0;
}
