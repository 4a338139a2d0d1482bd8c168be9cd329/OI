#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=15;

int n,m;
int A[maxn][maxn];
int p[maxn];
bool vis[maxn];

bool check(){
    int sum=0;
    for(int i=1;i<=n;i++){
        if(A[i][p[i]]==-1) return 0;
        (sum+=A[i][p[i]])%=m;
    }
    return sum==0;
}

bool dfs(int u){
    if(u==n+1) return check();
    for(int i=1;i<=n;i++) if(!vis[i]){
        p[u]=i; vis[i]=1;
        if(dfs(u+1)) return 1;
        vis[i]=0;
    }
    return 0;
}

int main(){
    freopen("luckymoney.in","r",stdin);
    freopen("luckymoney.out","w",stdout);

    read(n); read(m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++) read(A[i][j]);

    puts(dfs(1)?"Yes":"No");

    return 0;
}
