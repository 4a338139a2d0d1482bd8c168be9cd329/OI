#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=200010;
int n, k;
vector<int> g[maxn], w[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

ll a[maxn*5], tot;
bool cmp(int x,int y){ return x>y; }
void dfs(int id,int x,int f,ll now){
	if(x>id) a[++tot]=now;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==f) continue;
		dfs(id,v,x,now+w[x][i]);
	}
}
void solve1(){
	for(int i=1;i<=n;i++) dfs(i,i,0,0);
	sort(a+1,a+1+tot,cmp);
	for(int i=1;i<=k;i++) printf("%lld ", a[i]); puts("");
}

int deg[maxn];
bool checkchain(){
	int ret=0;
	for(int i=1;i<=n;i++){
		if(deg[i]>2) return false;
		ret+=deg[i]==1;
	}
	return ret==2;
}
int pre[maxn], suf[maxn], vis[maxn], prew[maxn], sufw[maxn];
ll sum;
struct node{
	ll dis;
	int u, v;
	bool operator <(const node& A)const{ return dis<A.dis; }
};
void solve2(){
	int st=0, ed=0;
	for(int i=1;i<=n;i++) if(deg[i]==1){ st=i; break; }
	for(int i=1;i<=n;i++) if(deg[i]==1 && i!=st){ ed=i; break; }
	queue<int> q; q.push(st);
	while(!q.empty()){
		int x=q.front(); q.pop(); vis[x]=1;
		for(int i=0;i<g[x].size();i++){
			int v=g[x][i]; if(vis[v]) continue;
			pre[v]=x, suf[x]=v, q.push(v);
			prew[v]=w[x][i], sufw[x]=w[x][i];
		}
	}
	/*
	for(int i=1;i<=n;i++) printf("%d ", sufw[i]); puts("");
	for(int i=1;i<=n;i++) printf("%d ", prew[i]); puts("");
	*/
	int cnt=0, now=ed;
	priority_queue<node> Q;
	for(int i=1;i<n;i++){
		Q.push((node){sum,st,now});
		sum-=prew[now], now=pre[now];
	}
	while(!Q.empty()){
		node pi=Q.top(); Q.pop();
		int u=pi.u, v=pi.v;
		a[++cnt]=pi.dis;
		// printf("%d %d dis = %lld\n", u, v, pi.dis);
		if(cnt==k) break;
		if(u+1>=v) continue;
		Q.push((node){pi.dis-sufw[u],suf[u],v});
	}
	for(int i=1;i<=k;i++) printf("%lld ", a[i]); puts("");
}

int main(){
	//freopen("tree.in","r",stdin),freopen("tree.out","w",stdout);
	freopen("1.in","r",stdin),freopen("tree.out","w",stdout);

	read(n), read(k);
	int u, v, z;
	for(int i=1;i<n;i++){
		read(u), read(v), read(z); sum+=z;
		g[u].push_back(v), w[u].push_back(z);
		g[v].push_back(u), w[v].push_back(z);
		deg[u]++, deg[v]++;
	}
	if(checkchain()){ solve2(); return 0; }
	if(n<=1000){ solve1(); return 0; }
	return 0;
}
