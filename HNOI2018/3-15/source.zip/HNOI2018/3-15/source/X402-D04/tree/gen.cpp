#include<bits/stdc++.h>
using namespace std;

const int mod=1e9;
int n;

int main(){
	freopen("1.in","w",stdout);
	srand(time(0));
	printf("%d %d\n", n=200000, 1000);
	for(int i=1;i<n;i++){
		printf("%d %d %d\n", i, i+1, rand()%mod);
	}
	return 0;
}
