#include<bits/stdc++.h>
using namespace std;

const int maxn=110;
int n, k;
int a[maxn][maxn], p[maxn];

int main(){
	freopen("luckymoney.in","r",stdin),freopen("luckymoney.out","w",stdout);

	scanf("%d%d", &n, &k);
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) scanf("%d", &a[i][j]);
	int tot=1;
	for(int i=1;i<=n;i++) p[i]=i, tot*=i;
	while(tot--){
		int f=1, t=0;
		for(int i=1;i<=n;i++) if(!(~a[i][ p[i] ])){ f=0; break; }
		for(int i=1;i<=n;i++) t+=a[i][ p[i] ];
		if(f && (t%k==0)){ puts("Yes"); return 0; }
		next_permutation(p+1,p+1+n);
	}
	puts("No");
	return 0;
}
