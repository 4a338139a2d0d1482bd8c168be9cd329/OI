#include<bits/stdc++.h>
using namespace std;

const int maxn=200010;
const int all=(1<<20)-1;
int n, q;
int a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int Max[maxn<<2], taga[maxn<<2], tago[maxn<<2], suma[maxn<<2], sumo[maxn<<2];
void pushup(int o){
	suma[o]=suma[o<<1]&suma[o<<1|1];
	sumo[o]=sumo[o<<1]|sumo[o<<1|1];
	Max[o]=max(Max[o<<1],Max[o<<1|1]);
}
void build(int o,int l,int r){
	taga[o]=all; tago[o]=0;
	if(l==r){ suma[o]=sumo[o]=Max[o]=a[l]; return; }
	int mid=(l+r)>>1;
	build(o<<1,l,mid), build(o<<1|1,mid+1,r);
	pushup(o);
}
void pushdown(int o){
	if(taga[o]!=all){
		taga[o<<1]&=taga[o], taga[o<<1|1]&=taga[o];
		tago[o<<1]&=taga[o], tago[o<<1|1]&=taga[o];
		suma[o<<1]&=taga[o], suma[o<<1|1]&=taga[o];
		sumo[o<<1]&=taga[o], sumo[o<<1|1]&=taga[o];
		Max[o<<1]&=taga[o], Max[o<<1|1]&=taga[o];
		taga[o]=all;
	}
	if(tago[o]){
		tago[o<<1]|=tago[o], tago[o<<1|1]|=tago[o];
		suma[o<<1]|=tago[o], suma[o<<1|1]|=tago[o];
		sumo[o<<1]|=tago[o], sumo[o<<1|1]|=tago[o];
		Max[o<<1]|=tago[o], Max[o<<1|1]|=tago[o];
		tago[o]=0;
	}
}
void modifya(int o,int l,int r,int ql,int qr,int val){
	if(ql<=l && qr>=r && (sumo[o]&(~val))==(suma[o]&(~val))){
		Max[o]&=val; sumo[o]&=val, suma[o]&=val; tago[o]&=val, taga[o]&=val; return;
	}
	pushdown(o);
	int mid=(l+r)>>1;
	if(ql<=mid) modifya(o<<1,l,mid,ql,qr,val); if(qr>mid) modifya(o<<1|1,mid+1,r,ql,qr,val);
	pushup(o);
}
void modifyo(int o,int l,int r,int ql,int qr,int val){
	if(ql<=l && qr>=r && (sumo[o]&val)==(suma[o]&val)){
		Max[o]|=val; sumo[o]|=val, suma[o]|=val; tago[o]|=val; return;
	}
	pushdown(o);
	int mid=(l+r)>>1;
	if(ql<=mid) modifyo(o<<1,l,mid,ql,qr,val); if(qr>mid) modifyo(o<<1|1,mid+1,r,ql,qr,val);
	pushup(o);
}
int query(int o,int l,int r,int ql,int qr){
	if(ql<=l && qr>=r) return Max[o];
	pushdown(o);
	int mid=(l+r)>>1, ret=0;
	if(ql<=mid) ret=query(o<<1,l,mid,ql,qr); if(qr>mid) ret=max(ret,query(o<<1|1,mid+1,r,ql,qr));
	return ret;
}

int main(){
	freopen("sequence.in","r",stdin),freopen("sequence.out","w",stdout);

	read(n), read(q);
	for(int i=1;i<=n;i++) read(a[i]);
	build(1,1,n);
	int op, l, r, x;
	while(q--){
		read(op), read(l), read(r);
		if(op<=2) read(x);
		if(op==1) modifya(1,1,n,l,r,x);
		else if(op==2) modifyo(1,1,n,l,r,x);
		else printf("%d\n", query(1,1,n,l,r));
	}
	return 0;
}
