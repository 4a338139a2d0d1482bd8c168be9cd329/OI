#include<bits/stdc++.h>
using namespace std;

const int MAXN = 200010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

bool flag;

namespace Seg_T {
#define ls (p<<1)
#define rs (p<<1|1)
#define mid ((l+r)>>1)
	const int U = ((1<<20)-1);
	int mx[MAXN<<2];
	int tag[MAXN<<2][2], sum[MAXN<<2][2];
	inline void init() {
		for(int i = 1; i < MAXN<<2; i++) tag[i][0] = U;
	}
	inline void pushdown(int p) {
		if(tag[p][0] != U) {
			mx[ls] -= (sum[ls][0]&(~tag[p][0]));
			mx[rs] -= (sum[rs][0]&(~tag[p][0]));
			tag[ls][0] &= tag[p][0], tag[ls][1] &= tag[p][0];
			sum[ls][0] &= tag[p][0], sum[ls][1] &= tag[p][0]; 
			tag[rs][0] &= tag[p][0], tag[rs][1] &= tag[p][0];
			sum[rs][0] &= tag[p][0], sum[rs][1] &= tag[p][0];
			tag[p][0] = U;
		}
		if(tag[p][1]) {
			mx[ls] += tag[p][1]^(sum[ls][0]&tag[p][1]);
			mx[rs] += tag[p][1]^(sum[rs][0]&tag[p][1]);
			tag[ls][1] |= tag[p][1], tag[rs][1] |= tag[p][1];
			sum[ls][0] |= tag[p][1];
			sum[ls][1] |= tag[p][1];
			sum[rs][0] |= tag[p][1];
			sum[rs][1] |= tag[p][1];
			tag[p][1] = 0;
		}
	}
	inline void maintain(int p) {
		mx[p] = max(mx[ls], mx[rs]);
		sum[p][0] = sum[ls][0]&sum[rs][0];
		sum[p][1] = sum[ls][1]|sum[rs][1];
	}
	inline void land(int p, int l, int r, int x, int y, int val) {
		if(l == x && r == y && (sum[p][0]&(~val)) == (sum[p][1]&(~val))) {
			mx[p] -= (sum[p][0]&(~val));
			tag[p][0] &= val, tag[p][1] &= val;
			sum[p][0] &= val, sum[p][1] &= val;
			return;
		}
		pushdown(p);
		if(y <= mid) land(ls, l, mid, x, y, val);
		else if(x > mid) land(rs, mid+1, r, x, y, val);
		else {
			land(ls, l, mid, x, mid, val);
			land(rs, mid+1, r, mid+1, y, val);
		}
		maintain(p);
	}
	inline void lor(int p, int l, int r, int x, int y, int val) {
		if(l == x && r == y && (sum[p][0]&val) == (sum[p][1]&val)) {
			mx[p] += val^(sum[p][0]&val);
			tag[p][1] |= val;
			sum[p][0] |= val, sum[p][1] |= val;
			return;
		}
		pushdown(p);
		if(y <= mid) lor(ls, l, mid, x, y, val);
		else if(x > mid) lor(rs, mid+1, r, x, y, val);
		else {
			lor(ls, l, mid, x, mid, val);
			lor(rs, mid+1, r, mid+1, y, val);
		}
		maintain(p);
	}
	inline int query(int p, int l, int r, int x, int y) {
		if(l == x && r == y) return mx[p];
		pushdown(p);
		if(y <= mid) return query(ls, l, mid, x, y);
		if(x > mid) return query(rs, mid+1, r, x, y);
		return max(query(ls, l, mid, x, mid), query(rs, mid+1, r, mid+1, y));
	}
}

int n, Q;

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);

	int i;
	n = read(), Q = read();

	Seg_T::init();
	for(i = 1; i <= n; i++) 
		Seg_T::lor(1, 1, n, i, i, read());

	for(i = 1; i <= Q; i++) {
		int ty = read(), L = read(), R = read();
		if(ty == 1) 
			Seg_T::land(1, 1, n, L, R, read());
		else if(ty == 2) 
			Seg_T::lor(1, 1, n, L, R, read());
		else 
			printf("%d\n", Seg_T::query(1, 1, n, L, R));
	}
	return 0;
}
