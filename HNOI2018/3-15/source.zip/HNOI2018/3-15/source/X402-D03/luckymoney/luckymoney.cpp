#include<bits/stdc++.h>
using namespace std;

const int MAXN = 50;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, a[MAXN][MAXN], K;
bool done[MAXN];

void dfs(int u, int res) {
	if(u == n+1) {
		if(res == 0) {
			printf("Yes\n");
			exit(0);
		}
		return;
	}
	int i;
	for(i = 1; i <= n; i++) {
		if(done[i] || a[u][i] == -1) continue;
		done[i] = true;
		dfs(u+1, (res+a[u][i])%K);
		done[i] = false;
	}
}

int main() {
	freopen("luckymoney.in", "r", stdin);
	freopen("luckymoney.out", "w", stdout);

	int i, j;
	n = read(), K = read();
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++) a[i][j] = read();
	dfs(1, 0);
	printf("No\n");
	return 0;
}
