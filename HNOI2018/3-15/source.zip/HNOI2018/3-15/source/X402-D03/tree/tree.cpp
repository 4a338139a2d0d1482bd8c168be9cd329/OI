#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 200010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], nxt[MAXN<<1];
int to[MAXN<<1], w[MAXN<<1], e = 1;
inline void Add(int u, int v, int W) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e, w[e] = W;
	to[++e] = u, nxt[e] = st[v];
	st[v] = e, w[e] = W;
}

int n, K;

inline void chkmax(int &cur, int val) {
	if(val > cur) cur = val;
}

bool flag;
ll Lim;
vector<ll> ans;
namespace DAC {
	class GT {
#define ls(x) (ch[(x)][0])
#define rs(x) (ch[(x)][1])
#define rel(x) (rs(fa[(x)]) == (x))
		const double ALPHA = 0.75;
		int cnt, ch[MAXN][2];
		int size[MAXN], ct[MAXN];
		int cnn[MAXN], q[MAXN], qn;
		ll val[MAXN];
	public:
		int root;
		inline void clear() {
			root = cnt = 0;
		}
		inline void update(int x) {
			size[x] = ct[x]+size[ls(x)]+size[rs(x)];
			cnn[x] = 1+cnn[ls(x)]+cnn[rs(x)];
		}
		inline int newnode(ll x) {
			++cnt, size[cnt] = ct[cnt] = 1;
			val[cnt] = x, ch[cnt][0] = ch[cnt][1] = 0;
			return cnt;
		}
		inline void getseq(int u) {
			if(ls(u)) getseq(ls(u));
			q[++qn] = u;
			if(rs(u)) getseq(rs(u));
		}
		inline void build(int &u, int l, int r) {
			if(l > r) {
				u = 0;
				return;
			}
			int mid = (l+r)>>1;
			u = q[mid];
			build(ls(u), l, mid-1);
			build(rs(u), mid+1, r);
			update(u);
		}
		inline void rebuild(int &u) {
			qn = 0, getseq(u);
			build(u, 1, qn);
		}
		inline void insert(int &u, ll x) {
			if(!u) {
				u = newnode(x);
				return;
			}
			if(val[u] == x) {
				ct[u]++, size[u]++;
				return;
			}
			if(x < val[u]) insert(ls(u), x);
			else insert(rs(u), x);
			update(u);
			if(cnn[ls(u)] >= cnn[u]*ALPHA || cnn[rs(u)] >= cnn[u]*ALPHA) 
				rebuild(u);
		}
		inline int query(ll x) {
			if(!root) return 0;
			int p = root, res = 0;
			while(p) {
				if(val[p] > x) {
					res += size[rs(p)]+ct[p];
					if(!ls(p)) return res;
					p = ls(p);
				}
				else if(val[p] == x) {
					res += size[rs(p)]+ct[p];
					return res;
				}
				else {
					if(!rs(p)) return res;
					p = rs(p);
				}
			}
			return res;
		}
		void dfs(int u, ll x) {
			int i;
			for(i = 1; i <= ct[u]; i++)
				ans.push_back(Lim+val[u]-x);
			if(ls(u)) dfs(ls(u), x);
			if(rs(u)) dfs(rs(u), x);
		}
		inline void query2(ll x) {
			if(!root) return;
			int p = root;
			while(p) {
				if(val[p] < x) {
					p = rs(p);
				}
				else if(val[p] == x) {
					for(int i = 1; i <= ct[p]; i++)
						ans.push_back(Lim);
					p = rs(p);
				}
				else {
					dfs(rs(p), x);
					for(int i = 1; i <= ct[p]; i++)
						ans.push_back(Lim+val[p]-x);
					p = ls(p);
				}
			}
		}
		inline void output() {
			int i;
			for(i = 1; i <= cnt; i++)
				printf("%d %d %d %d %lld\n", ch[i][0], ch[i][1], size[i], ct[i], val[i]);
		}
	};
	int root, dp[MAXN];
	int cnt;
	ll val, res;
	bool ban[MAXN<<1];
	inline int DP(int u, int fa) {
		dp[u] = 0;
		int i, sz = 1;
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(ban[i] || v == fa) continue;
			int m = DP(v, u);
			chkmax(dp[u], m);
			sz += m;
		}
		chkmax(dp[u], cnt-sz);
		if(dp[u] < dp[root]) root = u;
		return sz;
	}
	int size[MAXN];
	ll t[MAXN];
	int tn;
	GT T;
	void getseq(int u, int fa, ll dist) {
		if(flag) {
			T.query2(val-dist);
		}
		else res += T.query(val-dist);
		t[++tn] = dist;
		int i;
		size[u] = 1;
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(ban[i] || v == fa) continue;
			getseq(v, u, dist+w[i]);
			size[u] += size[v];
		}
	}
	bool solve(int rt, int dep) {
		//printf("solve %d %d\n", rt, dep);
		int i, j;
		if(res >= K) return false;
		//if(rt == 9) cerr << clock() << endl;
		T.clear();
		T.insert(T.root, 0);
		//long double tmp = 0;
		for(i = st[rt]; i; i = nxt[i]) {
			int v = to[i];
			if(ban[i]) continue;
			tn = 0;
			getseq(v, rt, w[i]);
			if(res >= K) return false;
			//tmp -= clock();
			for(j = 1; j <= tn; j++) {
				T.insert(T.root, t[j]);
			}
			//tmp += clock();
		}
		/*if(rt == 9) {
			cerr << clock() << endl;
			cerr << tmp << endl;
		}*/
		for(i = st[rt]; i; i = nxt[i]) {
			int v = to[i];
			if(ban[i]) continue;
			ban[i] = ban[i^1] = true;
			cnt = size[v];
			root = 0, DP(v, rt);
			if(!solve(root, dep+1)) return false;
		}
		return true;
	}
	inline bool check(ll x) {
		val = x, cnt = n, res = 0;
		memset(ban, false, sizeof(ban));
		dp[0] = n+1;
		root = 0;
		DP(1, 0);
		/*(printf("%d\n", root);
		for(int i = 1; i <= n; i++)
			printf("%d ", dp[i]);
		printf("\n");
		exit(0);*/
		return solve(root, 1);
	}
	inline void test() {
		int i;
		T.clear();
		for(i = 1; i <= n; i++)
			T.insert(T.root, i);
	}
}

int root;

void dfs(int u, int fa, ll dis) {
	if(fa && u > root) ans.push_back(dis);
	int i;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa || w[i]+dis >= Lim) continue;
		//printf("??? %d, %lld %lld\n", u, dis+w[i], Lim);
		dfs(v, u, dis+w[i]);
	}
}

bool cmp(const ll &a, const ll &b) {
	return a > b;
}

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	n = read(), K = read();
	int i;
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		Add(u, v, read());
	}
	//printf("%d\n", DAC::check(22904945334LL));
	//DAC::test();
	//cerr << clock() << endl;
	//return 0;
	ll L = 1, R = 200000000000000LL;
	while(L < R) {
		ll mid = (L+R)>>1;
		if(DAC::check(mid)) R = mid;
		else L = mid+1;
		//cerr << L << ' ' << R << endl;
	}
	Lim = L;
	/*printf("%lld\n", Lim);
	printf("%d\n", DAC::check(Lim));
	printf("%d\n", DAC::check(Lim-1));
	return 0;*/
	flag = true;
	DAC::check(Lim);
	
	//printf("!%lld\n", Lim);
	sort(ans.begin(), ans.end(), cmp);
	for(i = 0; i < (int)ans.size(); i++)
		printf("%lld\n", ans[i]);
	for(i = 0; i < (int)(K-ans.size()); i++)
		printf("%lld\n", Lim-1);
	return 0;
}
