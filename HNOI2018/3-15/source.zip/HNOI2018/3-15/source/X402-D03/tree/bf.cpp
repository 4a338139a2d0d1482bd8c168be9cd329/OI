#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 200010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], nxt[MAXN<<1];
int to[MAXN<<1], w[MAXN<<1], e;
inline void Add(int u, int v, int W) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e, w[e] = W;
	to[++e] = u, nxt[e] = st[v];
	st[v] = e, w[e] = W;
}

vector<ll> ans;
int root;

void dfs(int u, int fa, ll dep) {
	int i;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		if(v > root) ans.push_back(dep+w[i]);
		dfs(v, u, dep+w[i]);
	}
}

int n, K;

bool cmp(const ll &a, const ll &b) {
	return a > b;
}

int main() {
	freopen("tree.in", "r", stdin);
	freopen("bf.out", "w", stdout);
	n = read(), K = read();
	int i;
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		Add(u, v, read());
	}
	for(i = 1; i <= n; i++) 
		dfs(root = i, 0, 0);
	sort(ans.begin(), ans.end(), cmp);
	for(i = 0; i < K; i++) printf("%lld\n", ans[i]);
	return 0;
}
