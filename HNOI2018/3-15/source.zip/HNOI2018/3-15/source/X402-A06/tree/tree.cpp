#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )

#define For(i, a, b) for(ll i = (a);i <= (b); ++i)
#define rep(i, a, b) for(ll i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

ll read() {
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const ll inf = 1e15;

const ll maxn = 400010;
//remember to larger the inf and shuzu
ll n, K, Begin[maxn], to[maxn], e, Next[maxn], w[maxn], rd[maxn];

void add(ll x,ll y,ll z) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
	w[e] = z;
}

void Get() {
	n = read(), K = read();
	For(i, 2, n) {
		ll x = read(), y = read(), z = read();
		add(x, y, z), add(y, x, z);//z is type of long long
		++ rd[x], ++ rd[y];
	}
}

priority_queue< ll , vector<ll> , greater<ll> > q;

ll cnt_bf, ans_bf[maxn];

void dfs_bf(ll h,ll father,ll dist,ll tmp) {
	if(h > tmp) {
		if(cnt_bf != K) {
			++ cnt_bf;
			q.push(dist);
		}
		else{
			ll now = q.top();
			if(dist > now) q.pop(), q.push(dist);
		}
	}

	for(ll i = Begin[h];i ;i = Next[i]) {
		ll v = to[i];
		if(v == father) continue;

		dfs_bf(v, h, dist+w[i], tmp);
	}
}

void solve_bf() {
	For(i, 1, n) {
		dfs_bf(i, -1, 0, i);
	}

	cnt_bf = 0;
	while(!q.empty()) ans_bf[++cnt_bf] = q.top(), q.pop();
	rep(i, cnt_bf, 1) printf("%lld\n", ans_bf[i]);
}

ll st[maxn], top, root, a[maxn], cnt, val[maxn];

void get_seq(ll h,ll father) {
	for(ll i = Begin[h];i ;i = Next[i]) {
		ll v = to[i];
		if(v == father) continue;

		get_seq(v, h);
		a[++cnt] = a[cnt-1] + w[i];
	}
}

bool check(ll h) {
	ll ans = 0;
	For(i, 1, cnt) {
		ll l = 1, r = i, nowans = 0;
		while(l <= r) {
			ll mid = l+r >> 1;
			if(a[i]-a[mid-1] >= h) l = mid+1, nowans = mid;
			else r = mid-1;
		}
		ans += nowans;
	}
	return ans >= K;
}

ll Ans[maxn], all;

bool cmp(ll x,ll y){return x > y;}

void solve_spe() {
	For(i, 1, n) if(rd[i] == 1) root = i;
	get_seq(root, -1);

	ll l = 0, r = inf, ans = 0;
	while(l <= r) {
		ll mid = l+r >> 1;
		if(check(mid) ) l = mid+1, ans = mid;
		else r = mid-1;
	}

	For(i, 1, cnt) {
		ll l = 1, r = i, nowans = 0;
		while(l <= r) {
			ll mid = l+r >> 1;
			if(a[i] - a[mid-1] >= ans) l = mid+1, nowans = mid;
			else r = mid-1;
		}
		For(j, 1, nowans) Ans[++ all] = a[i] - a[j-1];
	}

	sort(Ans + 1, Ans + all + 1, cmp);
	For(i, 1, K) printf("%lld\n", Ans[i]);
}

int main() {

	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	Get();
	if(n <= 1000) solve_bf();
	else solve_spe();

	return 0;
}
