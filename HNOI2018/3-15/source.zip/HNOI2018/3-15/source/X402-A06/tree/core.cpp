#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;
//remember to larger the inf and shuzu
int n, K, Begin[maxn], to[maxn], e, Next[maxn], w[maxn];

void add(int x,int y,int z) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
	w[e] = z;
}

void Get() {
	n = read(), K = read();
	For(i, 2, n) {
		int x = read(), y = read(), z = read();
		add(x, y, z), add(y, x, z);//z is type of long long
	}
}

priority_queue< int , vector<int> , greater<int> > q;

int cnt_bf, ans_bf[maxn];

void dfs_bf(int h,int father,int dist,int tmp) {
	if(h > tmp) {
		if(cnt_bf != K) {
			++ cnt_bf;
			q.push(dist);
		}
		else{
			int now = q.top();
			if(dist > now) q.pop(), q.push(dist);
		}
	}

	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father) continue;

		dfs_bf(v, h, dist+w[i], tmp);
	}
}

void solve_bf() {
	For(i, 1, n) {
		dfs_bf(i, -1, 0, i);
	}

	cnt_bf = 0;
	while(!q.empty()) ans_bf[++cnt_bf] = q.top(), q.pop();
	rep(i, cnt_bf, 1) printf("%d\n", ans_bf[i]);
}

int vis[maxn], Min, Max[maxn], root, Size[maxn];

void get_size(int h,int father) {
	Size[h] = 1;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father || vis[v]) continue;

		get_size(v, h);
		Size[h] += Size[v];
	}
}

void find_root(int h,int father,int tmp) {
	Max[h] = 0;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father || vis[v]) continue;

		find_root(v, h, tmp);
		Max[h] = max(Max[h], Size[v]);
	}

	Max[h] = max(Max[h], tmp - Size[h]);
	if(Max[h] < Min) Min = Max[h], root = h;
}

int cnt;

void calc(int h) {
	vis[h] = 1;
	for(int i = Begin[h];i ;i = Next[i]) {
		
	}
}

void solve() {
	get_root(1, -1);
	root = 1, Min = inf;
	find_root(1, -1, Size[1]);
	calc(root);
}

int main() {

	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);

	Get();
	solve_bf();
	solve();

	return 0;
}
