#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int maxm = 1010;

int n, K, a[maxm][maxm], ls[maxn];

void Get() {
	n = read(), K = read();
	For(i, 1, n) For(j, 1, n) a[i][j] = read();
}

void solve_bf() {
	For(i, 1, n) ls[i] = i;
	int Ans = 0;

	do{
		bool flag = 0;
		int ans = 0;

		For(i, 1, n) {
			if(a[i][ls[i]] == -1) {
				flag = 1;
				break;
			}
			ans += a[i][ls[i]];
		}

		if(flag || ans % K != 0) {}
		else ++ Ans;
		if(Ans) break;

	}while(next_permutation(ls+1, ls+n+1) );

	if(Ans) printf("Yes\n");
	else printf("No\n");
}

int main() {
	
	freopen("luckmoney.in", "r", stdin);
	freopen("luckmoney.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
