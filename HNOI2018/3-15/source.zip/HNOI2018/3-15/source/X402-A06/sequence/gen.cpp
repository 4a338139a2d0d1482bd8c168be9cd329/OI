#include<bits/stdc++.h>

#define For(i, a, b) for(int i = (a);i <= (b); ++i)

using namespace std;

const int maxn = (1 << 20) - 1;

int main() {
	
	freopen("sequence.in", "w", stdout);
	srand(time(NULL));
	int n = 200000, q = 200000;
	printf("%d %d\n", n, q);
	For(i, 1, n) {
		int x = rand() % maxn + 1;
		printf("%d ", x);
	}puts("");

	For(i, 1, q) {
		int tp = rand() % 3 + 1;
		int r = rand() % n + 1;
		int l = rand() % r + 1;
		if(tp != 3){
			int x = rand() % maxn + 1;
			printf("%d %d %d %d\n", tp, l, r, x);
		}
		else{
			printf("%d %d %d\n", tp, l, r);
		}
	}puts("");

	return 0;
}
