#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int n, q, a[maxn];

void Get() {
	n = read(), q = read();
	For(i, 1, n) a[i] = read();
}

int tag[maxn << 2], yu[maxn << 2], ho[maxn << 2], tree[maxn << 2];

const int maxm = 19;

inline void pushdown(int h,int l,int r) {
	/*if(tag[h] == 0 || l == r) return;
	tree[h<<1] += tag[h], tree[h<<1|1] += tag[h];
	yu[h<<1] += tag[h], yu[h<<1|1] += tag[h];
	ho[h<<1] += tag[h], ho[h<<1|1] += tag[h];
	tag[h<<1] += tag[h], tag[h<<1|1] += tag[h];
	tag[h] = 0;*/
	if(tag[h] == 0) return;
	tree[h] += tag[h];
	yu[h] += tag[h];
	ho[h] += tag[h];
	if(l == r) {tag[h] = 0; return;}
	tag[h<<1] += tag[h], tag[h<<1|1] += tag[h];
	tag[h] = 0;
}

inline void pushup(int h,int l,int r) {
	int mid = l+r >> 1;
	if(tag[h<<1] != 0) pushdown(h<<1, l, mid);
	if(tag[h<<1|1] != 0) pushdown(h<<1|1, mid+1, r);

	yu[h] = (yu[h<<1] & yu[h<<1|1]);
	ho[h] = (ho[h<<1] | ho[h<<1|1]);
	tree[h] = max(tree[h<<1], tree[h<<1|1]);
}

inline void build(int h,int l,int r) {
	if(l == r) {
		tree[h] = yu[h] = ho[h] = a[l];
		return;
	}

	int mid = l+r >> 1;
	build(h<<1, l, mid);
	build(h<<1|1, mid+1, r);

	pushup(h, l, r);
}

inline void change(int h,int l,int r,int val,int tp) {
	pushdown(h, l, r);
	if(tp == 1 && !(ho[h] & val) ) return;
	if(tp == 2 && (yu[h] & val) ) return;

	if(tp == 1) {
		if(yu[h] & val) {
	/*		tag[h] -= val;
			yu[h] -= val;
			ho[h] -= val;
			tree[h] -= val;*/
			tag[h] -= val;
			pushdown(h, l, r);
			return;
		}
	}
	else{
		if(!(ho[h] & val) ) {
	/*		tag[h] += val;
			yu[h] += val;
			ho[h] += val;
			tree[h] += val;*/
			tag[h] += val;
			pushdown(h, l, r);
			return;
		}
	}

	int mid = l+r >> 1;
	change(h<<1, l, mid, val, tp);
	change(h<<1|1, mid+1, r, val, tp);
	
	pushup(h, l, r);
}

inline void updada(int h,int l,int r,int s,int e,int val,int tp) {
	pushdown(h, l, r);
	if(tp == 1 && !(ho[h] & val) ) return;
	if(tp == 2 && (yu[h] & val) ) return;

	if(l == s && r == e) {
		change(h, l, r, val, tp);
		return;
	}

	int mid = l+r >> 1;
	if(e <= mid) updada(h<<1, l, mid, s, e, val, tp);
	else if(s > mid) updada(h<<1|1, mid+1, r, s, e, val, tp);
	else updada(h<<1, l, mid, s, mid, val, tp), updada(h<<1|1, mid+1, r, mid+1, e, val, tp);

	pushup(h, l, r);
}

inline int query(int h,int l,int r,int s,int e) {
	pushdown(h, l, r);
	if(l == s && r == e) return tree[h];

	int mid = l+r >> 1;
	if(e <= mid) return query(h<<1, l, mid, s, e);
	else if(s > mid) return query(h<<1|1, mid+1, r, s, e);
	else return max(query(h<<1, l, mid, s, mid), query(h<<1|1, mid+1, r, mid+1, e) );
}

void solve() {
	build(1, 1, n);
	while(q --) {
		int tp = read(), l = read(), r = read();
		if(tp != 3) {
			int x = read();
			For(i, 0, maxm) {
				if(tp == 1) {
					if(x & (1 << i) ) {}
					else updada(1, 1, n, l, r, (1 << i), tp);
				}
				else {
					if(x & (1 << i) ) updada(1, 1, n, l, r, (1 << i), tp);
				}
			}
		}
		else{
			printf("%d\n", query(1, 1, n, l, r) );
		}
	}
}

int main() {

	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);

	Get();
	solve();

	cerr << clock() << endl;

	return 0;
}
