#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=2e5+10;
int n,k;
vector<int> g[maxn],len[maxn];
vector<ll> vec;

namespace chain{
	int rt;
	ll a[maxn];
	priority_queue<pair<ll,pair<int,int> > > q;
	int main(){
		for(int i=1;i<=n;++i)
			if(g[i].size()>2)
				return 0;
			else if(g[i].size()==1&&!rt)
				rt=i;
		a[1]=0;
		for(int i=2,p=rt,last=0;i<=n;++i)
			for(int j=0;j<g[p].size();++j)
				if(g[p][j]!=last){
					a[i]=a[i-1]+len[p][j];
					last=p;
					p=g[p][j];
					break;
				}
		q.push(make_pair(a[n]-a[1],make_pair(1,n)));
		while(k--){
			int l=q.top().second.first,r=q.top().second.second;
			q.pop();
			while(!q.empty()&&q.top().second.first==l&&q.top().second.second==r)
				q.pop();
			printf("%lld\n",a[r]-a[l]);
			q.push(make_pair(a[r-1]-a[l],make_pair(l,r-1)));
			q.push(make_pair(a[r]-a[l+1],make_pair(l+1,r)));
		}
		exit(0);
	}
}
namespace plan{
#define vii vector<int>::iterator
#define vli vector<ll>::iterator
	vector<ll> vec[maxn],ans;
	priority_queue<ll,vector<ll>,greater<ll> > q;

	void dfs(int pos,int fa){
		for(int i=0,v;i<g[pos].size();++i)
			if((v=g[pos][i])!=fa){
				dfs(v,pos);
				for(vli j=vec[v].begin();j!=vec[v].end();++j)
					vec[pos].push_back((*j)+=len[pos][i]);
			}
		sort(vec[pos].begin(),vec[pos].end(),greater<ll>());
		for(vli i=vec[pos].begin();i!=vec[pos].end();++i)
			if((*i)>q.top())
				q.pop(),q.push(*i);
		vec[pos].push_back(0);
	}
	void dfss(int pos,int fa){
		for(vii u=g[pos].begin();u!=g[pos].end();++u)if((*u)!=fa)
			for(vii v=u+1;v!=g[pos].end();++v)if((*v)!=fa)
				for(vli x=vec[*u].begin();x!=vec[*u].end()&&(*x)+vec[*v].front()>q.top();++x)
					for(vli y=vec[*v].begin();y!=vec[*v].end()&&(*x)+(*y)>q.top();++y)
						q.pop(),q.push((*x)+(*y));
		for(int i=0;i<g[pos].size();++i)
			if(g[pos][i]!=fa)
				dfss(g[pos][i],pos);
	}
	int main(){
		for(int i=1;i<=k;++i)
			q.push(0);
		dfs(1,0);
		dfss(1,0);
		while(!q.empty())
			ans.push_back(q.top()),q.pop();
		for(vector<ll>::reverse_iterator i=ans.rbegin();i!=ans.rend();++i)
			printf("%lld\n",*i);
		exit(0);
	}
}
void dfs(int rt,int pos,int fa,ll dis){
	if(pos>rt)
		vec.push_back(dis);
	for(int i=0;i<g[pos].size();++i)
		if(g[pos][i]!=fa)
			dfs(rt,g[pos][i],pos,dis+len[pos][i]);
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1,u,v,w;i<n;++i){
		scanf("%d%d%d",&u,&v,&w);
		g[u].push_back(v);len[u].push_back(w);
		g[v].push_back(u);len[v].push_back(w);
	}
	chain::main();
	if(n>1000)
		plan::main();
	for(int i=1;i<=n;++i)
		dfs(i,i,0,0);
	sort(vec.begin(),vec.end(),greater<ll>());
	for(int i=0;i<k;++i)
		printf("%lld\n",vec[i]);
	return 0;
}
