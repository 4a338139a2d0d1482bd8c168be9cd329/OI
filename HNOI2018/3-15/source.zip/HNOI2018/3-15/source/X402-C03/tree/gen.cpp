#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("tree.in","w",stdout);
	int n=f(1,2e3),k=2e5,w=1e9,type=f(1,2);
	k=f(1,min(k,n*(n-1)/2));
//	n=2e5;
//	k=2e5;
	if(k>n*(n-1)/2)
		k=n*(n-1)/2;
	printf("%d %d\n",n,k);
	if(type==1){
		for(int i=2;i<=n;++i)
			printf("%d %d %d\n",f(1,i-1),i,f(1,w));
	}
	else{
		static int a[200010];
		for(int i=1;i<=n;++i)
			a[i]=i;
		random_shuffle(a+1,a+n+1);
		for(int i=1;i<n;++i)
			printf("%d %d %d\n",a[i],a[i+1],f(1,w));
	}
	return 0;
}
