#include<bits/stdc++.h>
using namespace std;

const int maxn=100+10;
int n,k,a[maxn][maxn];
bool vis[maxn];

void dfs(int pos,int now){
	if(pos>n){
		if(now==0){
			puts("Yes");
			exit(0);
		}
		return;
	}
	for(int i=1;i<=n;++i)
		if(!vis[i]&&a[pos][i]!=-1){
			vis[i]=true;
			dfs(pos+1,(now+a[pos][i])%k);
			vis[i]=false;
		}
}

int main(){
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			scanf("%d",&a[i][j]);
	dfs(1,0);
	puts("No");
	return 0;
}
