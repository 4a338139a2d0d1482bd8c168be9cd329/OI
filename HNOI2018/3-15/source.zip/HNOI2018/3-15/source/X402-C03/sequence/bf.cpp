#include<bits/stdc++.h>
using namespace std;

const int maxn=2e5+10;
int n,q,a[maxn];

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.txt","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	while(q--){
		int opt,l,r,x;
		scanf("%d%d%d",&opt,&l,&r);
		if(opt==1){
			scanf("%d",&x);
			for(int i=l;i<=r;++i)
				a[i]&=x;
		}
		else if(opt==2){
			scanf("%d",&x);
			for(int i=l;i<=r;++i)
				a[i]|=x;
		}
		else{
			int res=0;
			for(int i=l;i<=r;++i)
				if(res<a[i])
					res=a[i];
			printf("%d\n",res);
		}
	}
	return 0;
}
