#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("sequence.in","w",stdout);
	int n=f(1,3e3),q=3e3,bit=f(1,20);
//	n=q=2e5;bit=20;
	printf("%d %d\n",n,q);
	for(int i=1;i<=n;++i)
		printf("%d ",f(1,1<<bit)-1);
	puts("");
	while(q--){
		int opt=f(1,3),l=f(1,n),r=f(1,n),x=f(1,1<<bit)-1;
		if(l>r)swap(l,r);
		if(opt<=2)
			printf("%d %d %d %d\n",opt,l,r,x);
		else
			printf("%d %d %d\n",opt,l,r);
	}
	return 0;
}
