#include<bits/stdc++.h>

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}
inline int max_(int a,int b){return a>=b?a:b;}

const int maxn=2e5+10,xxx=(1<<20)-1;
int n,q;

namespace seg{
	int max[maxn<<2],tago[maxn<<2],taga[maxn<<2],same[maxn<<2],val[maxn<<2];

	inline void push_up(int rt){
		max[rt]=max_(max[rt<<1],max[rt<<1|1]);
		same[rt]=same[rt<<1]&same[rt<<1|1]&~(val[rt<<1]^val[rt<<1|1]);
		val[rt]=val[rt<<1];
	}
	inline void push_down(int rt){
		if(taga[rt]){
			max[rt<<1]-=taga[rt];
			max[rt<<1|1]-=taga[rt];
			val[rt<<1]&=xxx^taga[rt];
			val[rt<<1|1]&=xxx^taga[rt];
			same[rt<<1]|=taga[rt];
			same[rt<<1|1]|=taga[rt];
			taga[rt<<1]|=taga[rt]^taga[rt]&tago[rt<<1];
			tago[rt<<1]^=taga[rt]&tago[rt<<1];
			taga[rt<<1|1]|=taga[rt]^taga[rt]&tago[rt<<1|1];
			tago[rt<<1|1]^=taga[rt]&tago[rt<<1|1];
			taga[rt]=0;
		}
		if(tago[rt]){
			max[rt<<1]+=tago[rt];
			max[rt<<1|1]+=tago[rt];
			val[rt<<1]|=tago[rt];
			val[rt<<1|1]|=tago[rt];
			same[rt<<1]|=tago[rt];
			same[rt<<1|1]|=tago[rt];
			tago[rt<<1]|=tago[rt]^tago[rt]&taga[rt<<1];
			taga[rt<<1]^=tago[rt]&taga[rt<<1];
			tago[rt<<1|1]|=tago[rt]^tago[rt]&taga[rt<<1|1];
			taga[rt<<1|1]^=tago[rt]&taga[rt<<1|1];
			tago[rt]=0;
		}
	}
	inline void build(int rt,int l,int r){
		if(l==r){
			max[rt]=val[rt]=read();
			same[rt]=xxx;
			return;
		}
		int mid=l+r>>1;
		build(rt<<1,l,mid);
		build(rt<<1|1,mid+1,r);
		push_up(rt);
	}
	inline void modifyand(int rt,int l,int r,int x,int y,int p){
		if(l==x&&r==y&&(same[rt]&p)==p){
			int tmp=val[rt]&p;
			val[rt]&=xxx^tmp;
			max[rt]-=tmp;
			taga[rt]|=tmp^(tago[rt]&tmp);
			tago[rt]^=tago[rt]&tmp;
			return;
		}
		int mid=l+r>>1;
		push_down(rt);
		if(y<=mid)
			modifyand(rt<<1,l,mid,x,y,p);
		else if(x>mid)
			modifyand(rt<<1|1,mid+1,r,x,y,p);
		else{
			modifyand(rt<<1,l,mid,x,mid,p);
			modifyand(rt<<1|1,mid+1,r,mid+1,y,p);
		}
		push_up(rt);
	}
	inline void modifyor(int rt,int l,int r,int x,int y,int p){
		if(l==x&&r==y&&(same[rt]&p)==p){
			int tmp=~val[rt]&p;
			val[rt]|=tmp;
			max[rt]+=tmp;
			tago[rt]|=tmp^(taga[rt]&tmp);
			taga[rt]^=taga[rt]&tmp;
			return;
		}
		int mid=l+r>>1;
		push_down(rt);
		if(y<=mid)
			modifyor(rt<<1,l,mid,x,y,p);
		else if(x>mid)
			modifyor(rt<<1|1,mid+1,r,x,y,p);
		else{
			modifyor(rt<<1,l,mid,x,mid,p);
			modifyor(rt<<1|1,mid+1,r,mid+1,y,p);
		}
		push_up(rt);
	}
	inline int query(int rt,int l,int r,int x,int y){
		if(l==x&&r==y)
			return max[rt];
		int mid=l+r>>1;
		push_down(rt);
		if(y<=mid)
			return query(rt<<1,l,mid,x,y);
		else if(x>mid)
			return query(rt<<1|1,mid+1,r,x,y);
		else
			return max_(query(rt<<1,l,mid,x,mid),query(rt<<1|1,mid+1,r,mid+1,y));
	}
}

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	n=read();q=read();
	seg::build(1,1,n);
	while(q--){
		int opt=read(),l=read(),r=read();
		if(opt==1)
			seg::modifyand(1,1,n,l,r,xxx^read());
		else if(opt==2)
			seg::modifyor(1,1,n,l,r,read());
		else
			printf("%d\n",seg::query(1,1,n,l,r));
	}
	return 0;
}
