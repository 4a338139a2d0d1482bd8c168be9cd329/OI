#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 2e5+5, S = -1 ;
int n, m ;
struct Segment_Tree {
	int L, R, Max[maxn<<2] ;
	int tag[maxn<<2][2], sum[maxn<<2][2] ;
	void push_up ( int h ) {
		Max[h] = max(Max[h<<1], Max[h<<1|1]) ;
		sum[h][0] = sum[h<<1][0]&sum[h<<1|1][0] ;
		sum[h][1] = sum[h<<1][1]|sum[h<<1|1][1] ;
	}
	void push_down ( int h ) {
		if (tag[h][0] ^ S) {
			Max[h<<1] -= sum[h<<1][0]&(~tag[h][0]) ;
			Max[h<<1|1] -= sum[h<<1|1][0]&(~tag[h][0]) ;
			tag[h<<1][0] &= tag[h][0], tag[h<<1|1][0] &= tag[h][0] ;
			tag[h<<1][1] &= tag[h][0], tag[h<<1|1][1] &= tag[h][0] ;
			sum[h<<1][0] &= tag[h][0], sum[h<<1|1][0] &= tag[h][0] ;
			sum[h<<1][1] &= tag[h][0], sum[h<<1|1][1] &= tag[h][0] ;
			tag[h][0] = S ;
		}
		if (tag[h][1]) {
			Max[h<<1] += (tag[h][1]^(sum[h<<1][0]&tag[h][1])) ;
			Max[h<<1|1] += (tag[h][1]^(sum[h<<1|1][0]&tag[h][1])) ;
			tag[h<<1][1] |= tag[h][1], tag[h<<1|1][1] |= tag[h][1] ;
			sum[h<<1][0] |= tag[h][1], sum[h<<1|1][0] |= tag[h][1] ;
			sum[h<<1][1] |= tag[h][1], sum[h<<1|1][1] |= tag[h][1] ;
			tag[h][1] = 0 ;
		}
	}
	void create ( int h, int l, int r ) {
		tag[h][0] = S ;
		tag[h][1] = 0 ;
		if (l == r) {
			Read(Max[h]) ;
			sum[h][0] = sum[h][1] = Max[h] ;
			return ;
		}
		int mid = (l+r)>>1 ;
		create(h<<1, l, mid), create(h<<1|1, mid+1, r) ;
		push_up(h) ;
	}
	void create ( int l, int r ) { create(1, L = l, R = r) ; }
	void Update_And ( int h, int l, int r, int x, int y, int v ) {
		if (x <= l && r <= y && (sum[h][0]&(~v))==(sum[h][1]&(~v)) ) {
			Max[h] -= sum[h][0]&(~v) ;
			tag[h][0] &= v, tag[h][1] &= v ;
			sum[h][0] &= v, sum[h][1] &= v ;
			return ;
		}
		int mid = (l+r)>>1 ;
		push_down(h) ;
		if (y <= mid) Update_And(h<<1, l, mid, x, y, v) ;
		else if (x > mid) Update_And(h<<1|1, mid+1, r, x, y, v) ;
		else {
			Update_And(h<<1, l, mid, x, mid, v) ;
			Update_And(h<<1|1, mid+1, r, mid+1, y, v) ;
		}
		push_up(h) ;
	}
	void Update_Or ( int h, int l, int r, int x, int y, int v ) {
		if (x <= l && r <= y && (sum[h][0]&v)==(sum[h][1]&v) ) {
			Max[h] += v^(sum[h][0]&v) ;
			tag[h][1] |= v ;
			sum[h][0] |= v, sum[h][1] |= v ;
			return ;
		}
		int mid = (l+r)>>1 ;
		push_down(h) ;
		if (y <= mid) Update_Or(h<<1, l, mid, x, y, v) ;
		else if (x > mid) Update_Or(h<<1|1, mid+1, r, x, y, v) ;
		else {
			Update_Or(h<<1, l, mid, x, mid, v) ;
			Update_Or(h<<1|1, mid+1, r, mid+1, y, v) ;
		}
		push_up(h) ;
	}
	void Update_And ( int x, int y, int v ) { Update_And(1, L, R, x, y, v) ; }
	void Update_Or ( int x, int y, int v ) { Update_Or(1, L, R, x, y, v) ; }
	int Query ( int h, int l, int r, int x, int y ) {
		if (x <= l && r <= y) return Max[h] ;
		int mid = (l+r)>>1 ;
		push_down(h) ;
		if (y <= mid) return Query(h<<1, l, mid, x, y) ;
		else if (x > mid) return Query(h<<1|1, mid+1, r, x, y) ;
		return max(Query(h<<1, l, mid, x, mid), Query(h<<1|1, mid+1, r, mid+1, y)) ;
	}
	int Query ( int l, int r ) { return Query(1, L, R, l, r) ; }
} SGT ;
int main() {
	freopen ( "sequence.in", "r", stdin ) ;
	freopen ( "sequence.out", "w", stdout ) ;
	int x, y, v, _ ;
	Read(n), Read(_) ;
	SGT.create(1, n) ;
	while (_--) {
		Read(v), Read(x), Read(y) ;
		if (v == 1) {
			Read(v) ;
			SGT.Update_And(x, y, v) ;
		} else if (v == 2) {
			Read(v) ;
			SGT.Update_Or(x, y, v) ;
		} else printf ( "%d\n", SGT.Query(x, y) ) ;
	}
	cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
