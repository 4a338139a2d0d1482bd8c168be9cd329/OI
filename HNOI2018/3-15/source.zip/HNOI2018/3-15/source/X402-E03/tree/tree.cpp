#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1005 ;
int n, m, k, dis[maxn][maxn], s ;
int e, Begin[maxn], Next[maxn*2], To[maxn*2], W[maxn*2] ;
void add ( int x, int y, int z ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
	W[e] = z ;
}
bool vis[maxn] ;
priority_queue <int> Q ;
void dfs ( int x ) {
	if (x > s) Q.push(dis[s][x]) ;
	vis[x] = 1 ;
	int i, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (!vis[u]) {
			vis[u] = 1 ;
			dis[s][u] = dis[s][x]+W[i] ;
			dfs(u) ;
		}
	}
}
int main() {
	freopen ( "tree.in", "r", stdin ) ;
	freopen ( "tree.out", "w", stdout ) ;
	int i, x, u, v ;
	Read(n), Read(k) ;
	for ( i = 1 ; i ^ n ; i ++ ) {
		Read(x), Read(u), Read(v) ;
		add(x, u, v) ;
		add(u, x, v) ;
	}
	for ( s = 1 ; s <= n ; s ++ ) {
		memset (vis, 0, sizeof vis) ;
		dfs(s) ;
	}
	while (k--) {
		printf ( "%d\n", Q.top() ) ;
		Q.pop() ;
	}
	return 0 ;
}
