#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 15 ;
int n, m, a[maxn][maxn] ;
bool vis[maxn] ;
void dfs ( int stp, int sum ) {
	if (stp > n) {
		if (!sum) {
			puts("Yes") ;
			exit(0) ;
		}
		return ;
	}
	for ( int i = 1 ; i <= n ; i ++ )
		if (!vis[i] && a[stp][i] != -1) {
			vis[i] = 1 ;
			dfs(stp+1, (sum+a[stp][i])%m) ;
			vis[i] = 0 ;
		}
}
int main() {
	freopen ( "luckymoney.in", "r", stdin ) ;
	freopen ( "luckymoney.out", "w", stdout ) ;
	Read(n), Read(m) ;
	int i, j ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= n ; j ++ )
			Read(a[i][j]) ;
	dfs(1, 0) ;
	puts("No") ;
	return 0 ;
}
