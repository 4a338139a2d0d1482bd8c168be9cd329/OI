#include <bits/stdc++.h>

using namespace std;

#define ll 			long long
#define db			double
#define up(i,j,n)		for (int i = j; i <= n; i++)
#define down(i,j,n)	for (int i = j; i >= n; i--)
#define cadd(a,b)		a = add (a, b)
#define cpop(a,b)		a = pop (a, b)
#define cmul(a,b)		a = mul (a, b)
#define pr			pair<int, int>
#define fi			first
#define se			second
#define SZ(x)		(int)x.size()
#define bin(i)		(1 << (i))
#define Auto(i,node)	for (int i = LINK[node]; i; i = e[i].next)

template<typename T> inline bool cmax(T & x, T y){return y > x ? x = y, true : false;}
template<typename T> inline bool cmin(T & x, T y){return y < x ? x = y, true : false;}

const int MAXN = 105;

int mod;

inline int add(int a, int b){a += b; return a >= mod ? a - mod : a;}
inline int pop(int a, int b){a -= b; return a < 0 ? a + mod : a;}
inline int mul(int a, int b){return 1LL * a * b % mod;}

int qpow(int a, int b){
	int c = 1;
	while (b) {
		if (b & 1) cmul(c, a);
		cmul(a, a); b >>= 1;
	}
	return c;
}

inline int lrand(int l, int r){return l + 1LL * rand() * rand() % (r - l + 1);}

int N, K, a[MAXN][MAXN], e[MAXN][MAXN], xx[MAXN][MAXN];

inline bool isprime(int p){
	int n = sqrt(p);
	up (i, 2, n) if (p % i == 0) return 0;
	return 1;
}

inline bool vaild(int g){
	int n = sqrt(mod - 1), p = mod - 1;
	up (i, 2, n) if (p % i == 0) {
		if (qpow(g, (mod - 1) / i) == 1) return 0;
		while (p % i == 0) p /= i;
	}
	if (p > 1 && qpow(g, (mod - 1) / p) == 1) return 0;
	return 1;
}

int det(){
	int sum = 1;
	up (i, 1, N) {
		up (j, i, N) if (a[j][i]) {
			up (k, i, N) swap(a[i][k], a[j][k]);
			if (j > i) sum = pop(0, sum);
			break;
		} 
		if (!a[i][i]) return 0;
		int inv = qpow(a[i][i], mod - 2);
		up (j, i + 1, N) {
			int d = mul(a[j][i], inv);
			up (k, i, N) cpop(a[j][k], mul(a[i][k], d));
		}
	}
	up (i, 1, N) cmul(sum, a[i][i]);
	return sum;
}

int main(){
	freopen("luckymoney.in","r",stdin);
	freopen("luckymoney.out","w",stdout);
	srand(19260817);
	scanf("%d%d", &N, &K);
	up (i, 1, N) up (j, 1, N) scanf("%d", &e[i][j]);
	mod = (int)(1e9 / K) * K  + 1; 
	while (!isprime(mod)) mod -= K;
	int g = 2;
	while (!vaild(g)) g++;
	g = qpow(g, (mod - 1) / K);
	int T = 1;
	while (T--) {
		up (i, 1, N) up (j, 1, N) xx[i][j] = e[i][j] == -1 ? 0 : lrand(1, mod - 1); 
		int ans = 0;
		up (d, 0, K - 1) {
			up (i, 1, N) up (j, 1, N) {
				if (e[i][j] == -1) a[i][j] = 0;
				else a[i][j] = mul(xx[i][j], qpow(g, d * e[i][j]));
			}
			cadd(ans, det());
		}
		if (ans != 0) return 0 * puts("Yes");
	}
	puts("No");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
