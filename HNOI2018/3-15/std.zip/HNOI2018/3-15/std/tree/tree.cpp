#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<set>
#include<bitset>
#include<map>
 
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
 
using namespace std;
 
typedef long long LL;
typedef double db;
 
int get(){
    char ch;
    while(ch=getchar(),(ch<'0'||ch>'9')&&ch!='-');
    if (ch=='-'){
        int s=0;
        while(ch=getchar(),ch>='0'&&ch<='9')s=s*10+ch-'0';
        return -s;
    }
    int s=ch-'0';
    while(ch=getchar(),ch>='0'&&ch<='9')s=s*10+ch-'0';
    return s;
}
 
const int N = 200005;
 
int n,K;
struct edge{
    int x,l,nxt;
}e[N*2];
int h[N],tot;
LL dis[N][20];
int Fa[N],dep[N];
int que[N],mx[N],siz[N];
int fa[N];
int key;
bool bz[N];
int vis[N],tim;
int rt;
 
void inse(int x,int y,int l){e[++tot].x=y;e[tot].l=l;e[tot].nxt=h[x];h[x]=tot;}
 
void getkey(int st){
    int he=0,ta=1;
    vis[que[1]=st]=++tim;
    fa[st]=0;
    for(;he<ta;){
        int x=que[++he];
        mx[x]=siz[x]=0;
        for(int p=h[x];p;p=e[p].nxt)
        if (!bz[e[p].x]&&vis[e[p].x]<tim){
            fa[e[p].x]=x;
            vis[que[++ta]=e[p].x]=tim;
        }
    }
    key=0;
    fd(i,ta,1){
        int x=que[i];
        siz[x]++;
        mx[x]=max(mx[x],ta-siz[x]);
        if(fa[x])siz[fa[x]]+=siz[x],mx[fa[x]]=max(mx[fa[x]],siz[x]);
        if (!key||mx[x]<mx[key])key=x;
    }
}
 
int k;
struct node{
    int x;LL dis;
    node(const int x_=0,const LL dis_=0){x=x_;dis=dis_;}
    friend bool operator < (node a,node b){return a.dis!=b.dis?a.dis<b.dis:a.x<b.x;}
}kp[N],q[N*20];
int be[N][20],lst[N*20],he[N],ta[N];
int m;

void bfs(int st,int depth){
	int he=0,ta=1;
	vis[que[1]=st]=tim;
	for(;he<ta;){
		int x=que[++he];
		kp[++k]=node(x,dis[x][depth]);
		for(int p=h[x];p;p=e[p].nxt)
		if (vis[e[p].x]<tim&&!bz[e[p].x]){
			dis[e[p].x][depth]=dis[x][depth]+e[p].l;
			be[e[p].x][depth]=be[x][depth];
			vis[que[++ta]=e[p].x]=tim;
		}
	}
}
 
int build(int up,int depth){
    getkey(up);
    int x=key;
    bz[x]=1;
    dep[x]=depth;
    tim++;
    kp[k=1]=node(x,0);
    for(int p=h[x];p;p=e[p].nxt)
    if (!bz[e[p].x]){
        dis[e[p].x][depth]=e[p].l;
        be[e[p].x][depth]=e[p].x;
        bfs(e[p].x,depth);
    }
    sort(kp+1,kp+1+k);
    he[x]=m+1;
    fo(i,1,k)q[++m]=kp[i];
    ta[x]=m;
    fo(i,he[x]+1,ta[x]){
        if (be[q[i].x][depth]==be[q[i-1].x][depth])lst[i]=lst[i-1];
        else lst[i]=i-1;
    }
    for(int p=h[x];p;p=e[p].nxt)
    if (!bz[e[p].x])Fa[build(e[p].x,depth+1)]=x;
    return x;
}
LL f[N];
 
int getcnt(LL lim){
    int lcnt=0;
    fo(x,1,n)if (f[x]>=lim)lcnt++;
    if (lcnt>=K)return K;
    int cnt=0;
    fo(x,1,n)
    if (f[x]>=lim){
        int now=x;
        for(;now;now=Fa[now]){
            int w=ta[now];
            int depth=dep[now];
            while(w>=he[now]&&dis[x][depth]+q[w].dis>=lim){
                if (be[q[w].x][depth]==be[x][depth])w=lst[w];
                if (w>=he[now]&&dis[x][depth]+q[w].dis>=lim){
                    if (x<q[w].x)cnt++;
                    if (cnt>=K)return K;
                    w--;
                }
            }
        }
    }
    return cnt;
}
 
LL ans[N];
 
int len;
int digi[20];
 
void putll(LL x){
    if (!x)putchar('0'),putchar('\n');
    else{
        len=0;
        for(;x;x=x/10)digi[++len]=x%10;
        for(;len;len--)putchar('0'+digi[len]);
        putchar('\n');
    }
}
 
void getans(LL lim){
    int cnt=0;
    fo(x,1,n){
        int now=x;
        for(;now;now=Fa[now]){
            int w=ta[now];
            int depth=dep[now];
            while(w>=he[now]&&dis[x][depth]+q[w].dis>lim){
                if (be[q[w].x][depth]==be[x][depth])w=lst[w];
                if (w>=he[now]&&dis[x][depth]+q[w].dis>lim){
                    if (x<q[w].x)ans[++cnt]=dis[x][depth]+q[w].dis;
                    w--;
                }
            }
        }
    }
    fo(i,cnt+1,K)ans[i]=lim;
    sort(ans+1,ans+1+K);
    fd(i,K,1)putll(ans[i]);
}
 
LL d[1000005];
int tt;
 
void getall(int x,LL dis){
    vis[x]=tim;
    if (x<tim)d[++tt]=dis;
    for(int p=h[x];p;p=e[p].nxt)
    if (vis[e[p].x]<tim)getall(e[p].x,dis+e[p].l);
}
 
LL maxll(LL x,LL y){return x>y?x:y;}
 
void getf(){
    fo(x,1,n){
        int now=x;
        f[x]=0;
        for(;now;now=Fa[now]){
            int w=ta[now];
            int depth=dep[now];
            if (be[q[w].x][depth]==be[x][depth])w=lst[w];
            if (w>=he[now])f[x]=maxll(f[x],dis[x][depth]+q[w].dis);
        }
    }
}
 
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
    n=get();K=get();
    fo(i,2,n){
        int x=get(),y=get(),l=get();
        inse(x,y,l);
        inse(y,x,l);
    }
    rt=build(1,1);
    getf();
    LL l=1,r=2e14,ans;
    while(l<=r){
        LL mid=(l+r)/2;
        if (getcnt(mid)>=K)ans=mid,l=mid+1;
        else r=mid-1;
    }
    getans(ans);
	fclose(stdin);
	fclose(stdout);
    return 0;
}