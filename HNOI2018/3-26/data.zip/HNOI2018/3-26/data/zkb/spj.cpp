/*
* @Author: 逸闲
* @Date:   2016-07-05 14:40:37
* @Last Modified by:   逸闲
* @Last Modified time: 2016-07-05 14:55:30
*/

#include "cstdio"
#include "cstdlib"
#include "iostream"
#include "algorithm"
#include "cstring"
#include "queue"

using namespace std;

#define INF 0x3F3F3F3F
#define MAX_SIZE
#define Eps
#define Mod
#define Get(x, a) (x ? x -> a : 0)
#define Travel(x) for(typeof(x.begin()) it = x.begin(); it != x.end(); ++it)

inline int Get_Int()
{
	int Num = 0, Flag = 1;
	char ch;
	do
	{
		ch = getchar();
		if(ch == '-')
			Flag = -Flag;
	}
	while(ch < '0' || ch > '9');
	do
	{
		Num = Num * 10 + ch - '0';
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9');
	return Num * Flag;
}

int N, Num, Fullmark;

int main(int argc, char *argv[])
{
	FILE *Standard_Output = fopen(argv[3], "r");
	FILE *User_Output = fopen(argv[2], "r");
	FILE *Input = fopen(argv[1], "r");
	FILE *Score = fopen(argv[5], "w");
	FILE *Log = fopen(argv[6], "w");
	Fullmark = atoi(argv[4]);
	fscanf(Input, "%d", &N);
	for(int i = 1; i <= N; ++i)
	{
		int a, b;
		fscanf(User_Output, "%d", &a);
		fscanf(Standard_Output, "%d", &b);
		Num += (a != b);
	}
	if(N <= 1000)
		if(Num)
			fprintf(Score, "%d", 0);
		else
			fprintf(Score, "%d", Fullmark);
	else
		if(Num <= 20)
			fprintf(Score, "%d", Fullmark);
		else
			fprintf(Score, "%d", 0);
	if(Num)
		fprintf(Log, "%d numbers different.", Num);
	return 0;
}
