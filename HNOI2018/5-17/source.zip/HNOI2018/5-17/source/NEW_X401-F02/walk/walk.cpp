#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<queue>
using namespace std ;
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}
const int maxn=200010;
const int inf=1<<30;

int V[maxn],head[maxn],dis[maxn];

int n,m,ecnt;

bool vis[maxn];

struct edge{
	int u,v,next;
}E[maxn];

inline void addedge(int u,int v){
	E[++ecnt].u=u;
	E[ecnt].v=v;
	E[ecnt].next=head[u];
	head[u]=ecnt;
}

inline int bfs(int u){
	queue<int>q;q.push(1);
	for(int i=1;i<=n;i++) dis[i]=inf;
	memset(vis,0,sizeof(vis));
	dis[1]=0;vis[1]=1;
	while(!q.empty()){
		int x=q.front();q.pop();vis[x]=0;
		for(int i=head[x];~i;i=E[i].next){
			int v=E[i].v;
			if(dis[v]>dis[x]+1){
				dis[v]=dis[x]+1;
				if(!vis[v]){
					q.push(v);
					vis[v]=1;
				}
			}
		}
	}
	return dis[u]==inf?-1:dis[u];
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("walk.in","r",stdin);
    freopen("walk.out","w",stdout);
#endif
	read(n),read(m);
	for(int i=1;i<=n;i++) read(V[i]);
	memset(head,-1,sizeof(head));
	for(int i=1;i<=m;i++){
		int u,v;
		read(u),read(v);
		addedge(u,v);
	}
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if((V[i]&V[j])==V[j]) addedge(i,j);
	for(int i=1;i<=n;i++)
		printf("%d\n",bfs(i));
    return 0;
}

