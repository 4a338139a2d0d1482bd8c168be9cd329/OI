#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}
const int maxn=200;

int c[maxn][maxn][maxn];

char str[maxn],tmp[maxn];

int main()
{
#ifndef ONLINE_JUDGE
    freopen("master.in","r",stdin);
    freopen("master.out","w",stdout);
#endif
	int n,K,ans=0;
	read(n),read(K);
	scanf(" %s %s",str,tmp);
	for(int i=0;i<=n;i++){
		for(int j=0;j<=n;j++)
			for(int k=0;k<=min(i,j)&&k<=K;k++)
			if(i==0||j==0) c[i][j][k]=0;
			else if(str[i-1]==tmp[j-1]) c[i][j][k]=c[i-1][j-1][k]+1,ans=max(ans,c[i][j][k]);
			else if(k) c[i][j][k]=max(c[i][j][k],c[i-1][j-1][k-1]+1);
	}
	printf("%d\n",ans);
    return 0;
}

