#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}
const int maxn=2000;

struct edge{
	int u,v,next;
}E[maxn];

int main()
{
#ifndef ONLINE_JUDGE
    freopen("tour.in","r",stdin);
    freopen("tour.out","w",stdout);
#endif
	read(n);
	for(int i=1;i<=n;i++){
		scanf(" %s",str);
		int len=strlen(str);
		for(int i=1;i<=len;i++) if()
	}
    return 0;
}

