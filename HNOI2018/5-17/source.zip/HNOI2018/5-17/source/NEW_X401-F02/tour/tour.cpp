#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<bitset>
using namespace std ;
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}
const int MAXN=2000;
#define LL long long

int n,head[MAXN],cnt;

LL ans;

bitset<MAXN>S[MAXN];

struct edge{
	int v,next;
}e[MAXN];

void addedge(int x,int y){
	e[++cnt]=(edge){y,head[x]};
	head[x]=cnt;
	return;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("tour.in","r",stdin);
	freopen("tour.out","w",stdout);
#endif
	read(n);
	for(int i=1;i<=n;++i){
		char tmp[MAXN];
		scanf("%s",tmp+1);
		for(int j=1;j<=n;++j)
			if(tmp[j]=='1')addedge(i,j),S[i][j]=1;
	}
	for(int u=1;u<=n;++u)
		for(int i=head[u];i;i=e[i].next){
			int v=e[i].v;
			ans+=(S[u].count()-1)*(S[v].count()-1)-((S[u]&S[v]).count());
		}
	printf("%lld\n",ans);
	return 0;
}
