#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=1505;
int a[N][N],n,d[N];
char s[N];
int main(){
	freopen("tour.in","r",stdin);
	freopen("tour.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i){
		scanf("%s",s+1);
		for (int j=1;j<=n;++j){
			a[i][j]=s[j]-'0';
			d[j]+=a[i][j];
		}
	}
	long long ans=0;
	for (int i=1;i<=n;++i)
		for (int j=1;j<=n;++j)
			if (i!=j && a[i][j]){
				for (int t=1;t<=n;++t)
					if (a[i][t] && a[j][t]) --ans;
				ans+=(long long)(d[i]-1)*(long long)(d[j]-1);
			}
	printf("%lld\n",ans);
	return 0;
}
