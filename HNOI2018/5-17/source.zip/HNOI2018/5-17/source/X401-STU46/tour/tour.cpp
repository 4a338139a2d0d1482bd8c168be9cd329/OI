#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int n,book[1501];
long long ans;
struct node
{
	int top,road[1500];
}k[1501];
void dfs(int x,int step)
{
	if(step==4)
	{
		ans++;
		return;
	}
	for(int i=1;i<=k[x].top;i++)
		if(book[k[x].road[i]]==0)
		{
			book[k[x].road[i]]=1;
			dfs(k[x].road[i],step+1);
			book[k[x].road[i]]=0;
		}
	return;
}
int main()
{
	freopen("tour.in","r",stdin);
	freopen("tour.out","w",stdout);
	cin>>n;
	char s[1500];
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		for(int j=0;j<strlen(s);j++)
			if(s[j]=='1')
				k[i].road[++k[i].top]=j+1;
	}
	for(int i=1;i<=n;i++)
	{
		book[i]=1;
		dfs(i,1);
		book[i]=0;
	}
	cout<<ans;
}
