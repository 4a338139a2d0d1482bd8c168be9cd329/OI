#include<iostream>
#include<cstdio>
using namespace std;
int n,k,maxx;
char S[300],T[300];
int pd(int l1,int r1,int l2,int r2)
{
	int ans=0;
	for(int i=r1;i>=l1;i--)
	{
		int f=0;
		if(r1-i+1<=r2-l2)
			for(int j=0;j<=r1-i;j++)
			{
				if(S[i+j]!=T[l2+j])
				{
					f=1;
					break;
				}
			}
		else
			break;
		if(f==1)
			continue;
		ans=r1-i+1;
	}
	return ans;
}
int main()
{
	freopen("master.in","r",stdin);
	freopen("master.out","w",stdout);
	cin>>n>>k>>S>>T;
	for(int i=n-1;i>=0;i--)
		for(int j=0;j<=n-1;j++)
			if(pd(0,i,j,n-1))
				maxx=max(maxx,pd(0,i,j,n-1));
	if(k==0)
		cout<<maxx;
	if(k>1)
		cout<<maxx+k;
	int maxxx=0;
	if(k==1)
	{
		for(int k=0;k<n;k++)
			for(int l='a';l<='z';l++)
			{
				maxx=0;
				char p=S[k],q=T[k];
				S[k]=char(l);
				for(int i=n-1;i>=0;i--)
					for(int j=0;j<=n-1;j++)
						if(pd(0,i,j,n-1))
							maxx=max(maxx,pd(0,i,j,n-1));
				maxxx=max(maxx,maxxx);
				S[k]=p;
				T[k]=char(l);
				for(int i=n-1;i>=0;i--)
					for(int j=0;j<=n-1;j++)
						if(pd(0,i,j,n-1))
							maxx=max(maxx,pd(0,i,j,n-1));
				maxxx=max(maxx,maxxx);
				T[k]=q;
			}
		cout<<maxxx;
	}
}
