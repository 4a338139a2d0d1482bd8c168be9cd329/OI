#include<iostream>
#include<cstdio>
using namespace std;
int n,m,val[200001],road[2001][2001],w[200001],dis[200001];
int pd(int ooo)
{
	int ws=0,x=ooo;
	while(x!=0)
	{
		x/=2;
		ws++;
	}
	return ws;
}
bool compare(int a,int b)
{
	int x=val[a],y=val[b],flag=0;
	while(x!=0&&y!=0)
	{
		int xx=x%2,yy=y%2;
		if(xx==1&&yy==1)
		{
			x/=2;
			y/=2;
			continue;
		}
		if(xx==0)
		{
			x/=2;
			y/=2;
			continue;
		}
		flag=1;
		break;
	}
	if(flag)
		return false;
	return true;
}
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>val[i];
		w[i]=pd(val[i]);
		dis[i]=99999999;
	}
	dis[1]=0;
	int a,b;
	for(int i=1;i<=m;i++)
	{
		cin>>a>>b;
		road[a][b]=1;
		if(a==1)
			dis[b]=1;
		if(b==1)
			dis[a]=1;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(j!=i&&w[i]>=w[j])
				if(compare(j,i))
					road[i][j]=1;
	int now=1,u[200001],minn;
	for(int i=1;i<=n;i++)
		u[i]=0;
	u[1]=1;
	dis[0]=99999999;
	int flag=1;
	while(flag)
	{
		flag=0;
		minn=0;
		for(int i=1;i<=n;i++)
			if(road[now][i]&&u[i]==0)
			{
				dis[i]=min(dis[i],dis[now]+1);
				flag=1;
			}
		for(int i=1;i<=n;i++)
			if(road[now][i]==1&&dis[i]<dis[minn]&&u[i]==0)
				minn=i;
		now=minn;
		u[minn]=1;
	}
	for(int i=1;i<=n;i++)
		if(dis[i]==99999999)
			dis[i]=-1;
	for(int i=1;i<=n;i++)
		cout<<dis[i]<<endl;
}
