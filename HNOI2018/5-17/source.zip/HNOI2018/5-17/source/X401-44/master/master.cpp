#include<bits/stdc++.h>
using namespace std;
const int N=305;
int ans,n,k,f[N][N],g[N][N];
char a[N],b[N];
void cal(){
	for(int i=1;i<=n;i++)//p1==1,p2==i
		for(int p=1,q=i;q<=n;p++,q++){
			int pref=f[p-1][q-1],preg=g[p-1][q-1];
			int &nowf=f[p][q],&nowg=g[p][q];
			if(a[p]==b[q])nowf=pref+1,nowg=preg;
			else{
				if(preg<k)nowf=pref+1,nowg=preg+1;
				else{
					int s=p-pref,t=q-pref;
					while(a[s]==b[t])s++,t++;
					nowf=p-s,nowg=k;
				}
			}
			ans=max(ans,nowf);
		}
}
int main()
{
	freopen("master.in","r",stdin);
	freopen("master.out","w",stdout);
	cin>>n>>k;
	scanf("%s",a+1);
	scanf("%s",b+1);
	cal();
	memset(f,0,sizeof(f));
	memset(g,0,sizeof(g));
	for(int i=1;i<=n;i++)swap(a[i],b[i]);
	cal();
	cout<<ans<<endl;
	return 0;
}
