#include<bits/stdc++.h>
using namespace std;
int main()
{
	ofstream fout("master.in");
	srand(time(0));
	static char s[605];
	int n=10,k=3;
	fout<<n<<' '<<k<<endl;
	for(int i=1;i<=n*2;i++)s[i]='a'+rand()%26;
	for(int i=1;i<=n;i++)fout<<s[i];
	fout<<endl;
	cerr<<(s+1)<<endl;
	for(int i=1;i<=n;i++){
		int pos=rand()%(2*n)+1;
		s[pos]='a'+rand()%26;
	}
	int st=rand()%(n/2)+1;
	for(int i=1;i<=n;i++)fout<<s[i+st];
	fout<<endl;
	cerr<<(s+1)<<endl;
	cerr<<st<<endl;
	return 0;
}
