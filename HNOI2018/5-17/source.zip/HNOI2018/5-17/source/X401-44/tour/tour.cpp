#include<bits/stdc++.h>
using namespace std;
const int N=1510;
int n,f[N],d[N];
bitset<N>b[N],tmp;
char mp[N];
int main()
{
	freopen("tour.in","r",stdin);
	freopen("tour.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%s",mp+1);
		for(int j=1;j<=n;j++)if(mp[j]=='1')b[i].set(j);
		d[i]=b[i].count();
		for(int j=1;j<=n;j++)if(mp[j]=='1')f[j]+=d[i]-1;
	}
	//for(int i=1;i<=n;i++)cout<<f[i]<<endl;
	long long ans=0;
	for(int i=1;i<=n;i++)ans+=1ll*f[i]*(d[i]-1);
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)if(b[i].test(j)){
			tmp=b[i]&b[j];
			ans-=2*tmp.count();
		}
	cout<<ans<<endl;
	return 0;
}
