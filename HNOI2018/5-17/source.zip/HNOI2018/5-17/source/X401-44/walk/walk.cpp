#include<bits/stdc++.h>
using namespace std;
const int N=1300000,M=12000000;
struct edge{int v,nxt;}e[M];
int cnt,n,m,hd[N],dis[N];
bool vis[N];
inline void adde(int u,int v,bool w){e[++cnt]=(edge){v<<1|w,hd[u]},hd[u]=cnt;}
struct node{
	int u,d;
	bool operator < (const node &y)const{
		return d>y.d;
	}
};
void work(){
	memset(dis,0x3f,sizeof(dis));
	dis[1]=0;
	priority_queue<node>q;
	q.push((node){1,0});
	while(!q.empty()){
		int u=q.top().u;q.pop();
		if(vis[u])continue;
		vis[u]=1;
		for(int i=hd[u];i;i=e[i].nxt){
			int v=e[i].v>>1,ndis=dis[u]+(e[i].v&1);
			if(dis[v]<=ndis)continue;
			dis[v]=ndis;
			q.push((node){v,ndis});
		}
	}
}
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	cin>>n>>m;
	for(int i=1,a;i<=n;i++)scanf("%d",&a),adde(i,a+n+1,1),adde(a+n+1,i,0);
	for(int i=1,u,v;i<=m;i++)scanf("%d%d",&u,&v),adde(u,v,1);
	for(int i=0;i<1<<20;i++)
		for(int j=0;j<20;j++)
			if(i>>j&1)adde(i+n+1,(i^(1<<j))+n+1,0);
	work();
	for(int i=1;i<=n;i++)printf("%d\n",dis[i]==0x3f3f3f3f?-1:dis[i]);
	//cerr<<cnt<<endl;
	//cerr<<sizeof(e)<<endl;
	return 0;
}
