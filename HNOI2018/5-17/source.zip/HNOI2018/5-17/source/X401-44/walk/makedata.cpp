#include<bits/stdc++.h>
using namespace std;
int R(int l,int r){return rand()%(r-l+1)+l;}
int main()
{
	ofstream fout("walk.in");
	int n=200000,m=300000;
	fout<<n<<' '<<m<<endl;
	for(int i=1;i<=n;i++)fout<<R(0,(1<<20)-1)<<' ';
	fout<<endl;
	for(int i=1;i<=m;i++){
		int u=R(1,n),v=R(1,n);
		while(u==v)u=R(1,n),v=R(1,n);
		fout<<u<<' '<<v<<endl;
	}
	return 0;
}
