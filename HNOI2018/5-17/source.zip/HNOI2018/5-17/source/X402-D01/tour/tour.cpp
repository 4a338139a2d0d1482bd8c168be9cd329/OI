#include <bits/stdc++.h>
using namespace std;
const int maxn = 1500 + 10;
int n,ans,deg[maxn],edges[maxn][maxn];
int main() {
	freopen("tour.in","r",stdin);
	freopen("tour.out","w",stdout);
	cin >> n;
	for (int i = 1;i <= n;i++)
		for (int j = 1;j <= n;j++) {
			char ch;
			cin >> ch;
			if (ch == '1') {
				edges[i][j] = 1;
				deg[i]++;
			}
		}
	for (int i = 1;i <= n;i++)
		for (int j = 1;j <= n;j++)
			if (i != j && edges[i][j]) {
				ans += (deg[i]-1)*(deg[j]-1);
				for (int k = 1;k <= n;k++)
					if (edges[i][k] && edges[k][j] && k != i && k != j) ans--;
			}
	printf("%d",ans);
	return 0;
}
