#include <bits/stdc++.h>
using namespace std;
const int maxn = 2000 + 10;
int n,m,val[maxn],dis[maxn];
vector<int> edges[maxn];
queue<int> Q;
bool vis[maxn];
inline void spfa() {
	for (int i = 1;i <= n;i++) dis[i] = 9999999;
	dis[1] = 0;
	vis[1] = true;
	Q.push(1);
	while (Q.size()) {
		int now = Q.front(); Q.pop();
		vis[now] = false;
		for (size_t i = 0;i < edges[now].size();i++) {
			int to = edges[now][i];
			if (dis[to] > dis[now]+1) {
				dis[to] = dis[now]+1;
				if (!vis[to]) {
					vis[to] = true;
					Q.push(to);
				}
			}
		}
	}
}
int main() {
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i = 1;i <= n;i++) scanf("%d",&val[i]);
	for (int i = 1,u,v;i <= m;i++) {
		scanf("%d%d",&u,&v);
		edges[u].push_back(v);
	}
	for (int i = 1;i <= n;i++)
		for (int j = 1;j <= n;j++)
			if (i != j && (val[i]&val[j]) == val[j]) edges[i].push_back(j);
	spfa();
	for (int i = 1;i <= n;i++) printf("%d\n",dis[i] == 9999999 ? -1 : dis[i]);
	return 0;
}
