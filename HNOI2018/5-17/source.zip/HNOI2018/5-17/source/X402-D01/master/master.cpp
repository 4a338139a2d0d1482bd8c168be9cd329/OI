#include <bits/stdc++.h>
using namespace std;
const int maxn = 300 + 10;
int n,k,dp[maxn][maxn][maxn];
char a[maxn],b[maxn];
int main() {
	freopen("master.in","r",stdin);
	freopen("master.out","w",stdout);
	scanf("%d%d%s%s",&n,&k,a+1,b+1);
	for (int i = 1;i <= n;i++)
		for (int j = 1;j <= n;j++) {
			dp[i][j][0] = max(dp[i-1][j][0],dp[i][j-1][0]);
			if (a[i] == b[j]) dp[i][j][0] = max(dp[i][j][0],dp[i-1][j-1][0]+1);
		}
	for (int i = 1;i <= n;i++)
		for (int j = 1;j <= n;j++)
			for (int t = 1;t <= k;t++)
				if (a[i] == b[j]) dp[i][j][t] = dp[i-1][j-1][t]+1;
				else dp[i][j][t] = dp[i-1][j-1][t-1]+1;
	printf("%d",dp[n][n][k]);
	return 0;
}
