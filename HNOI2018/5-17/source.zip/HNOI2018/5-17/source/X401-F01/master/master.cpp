#include<bits/stdc++.h>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=310;
int n,K,f[MAXN][MAXN][MAXN],ans;
char a[MAXN],b[MAXN];
int main()
{
#ifndef ONLINE_JUDGE
	freopen("master.in","r",stdin);
	freopen("master.out","w",stdout);
#endif
	n=read();K=read();
	scanf("%s",a+1);scanf("%s",b+1);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			for(int k=0;k<=min(i,j)&&k<=K;++k)
			{
				if(a[i]==b[j])f[i][j][k]=max(f[i][j][k],f[i-1][j-1][k]+1);
				else if(k)f[i][j][k]=max(f[i][j][k],f[i-1][j-1][k-1]+1);
				ans=max(ans,f[i][j][k]);
			}
	printf("%d\n",ans);
	return 0;
}
