#include<bits/stdc++.h>
using namespace std;
int main()
{
	srand(time(0));
	int n=rand()%1500;
	printf("%d\n",n);
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)printf("%d",rand()%2);
		puts("");
	}
	return 0;
}
