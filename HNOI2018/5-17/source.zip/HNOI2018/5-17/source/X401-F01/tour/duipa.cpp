#include<bits/stdc++.h>
using namespace std;
int main()
{
	int T=100;
	while(T--)
	{
		system("./data >tour.in");
		system("./baoni");
		system("./tour");
		if(system("diff tour.out tour1.out"))break;
		puts("Correct!");
	}
	return 0;
}
