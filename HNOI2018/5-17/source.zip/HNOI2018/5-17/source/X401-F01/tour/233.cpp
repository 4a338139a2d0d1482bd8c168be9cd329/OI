#include<cstdio>
int main()
{
	printf("1500\n");
	for(int i=1;i<=1500;++i)
	{
		for(int j=1;j<=1500;++j)
			printf("1");
		puts("");
	}
	return 0;
}
