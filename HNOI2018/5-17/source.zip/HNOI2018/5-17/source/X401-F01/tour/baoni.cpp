#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<bitset>
#define N 2000
#define LL long long
using namespace std;
int n,m;
int point[N],nxt[N*N],v[N*N],size[N];
int belong[N],tot;
char s[N];
bitset<1503> t,sum[N];
void add(int x,int y)
{
	tot++; nxt[tot]=point[x]; point[x]=tot; v[tot]=y; size[x]++;
}
int main()
{
	freopen("tour.in","r",stdin);
	freopen("tour1.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	 belong[i]=(i-1)/32+1;
	for (int i=1;i<=n;i++)
	  {
	  	scanf("%s",s+1);
	  	for (int j=1;j<=n;j++)
	  	 if (s[j]=='1')  {
		   add(i,j);
		   sum[i][j]=1;
		}
	  }
	LL ans=0;
	for (int i=1;i<=n;i++)
	 {
	 	for (int j=point[i];j;j=nxt[j])
	 	 {
	 	 	ans+=(LL)(size[i]-1)*(LL)(size[v[j]]-1);
	 	 	t=sum[i]&sum[v[j]];
			ans-=(LL)t.count();
		 }
	 }
	printf("%lld\n",ans);
}
