#include<bits/stdc++.h>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1510;
int n,head[MAXN],cnt;
LL ans;
bitset<MAXN>S[MAXN];
struct edge
{
	int v,next;
}e[MAXN*MAXN];
void addedge(int x,int y)
{
	e[++cnt]=(edge){y,head[x]};
	head[x]=cnt;
	return;
}
int main()
{
#ifndef ONLINE_JUDGE
	freopen("tour.in","r",stdin);
	freopen("tour.out","w",stdout);
#endif
	n=read();
	for(int i=1;i<=n;++i)
	{
		char tmp[MAXN];
		scanf("%s",tmp+1);
		for(int j=1;j<=n;++j)
			if(tmp[j]=='1')addedge(i,j),S[i][j]=1;
	}
	for(int u=1;u<=n;++u)
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].v;
			ans+=(S[u].count()-1)*(S[v].count()-1)-((S[u]&S[v]).count());
		}
	printf("%lld\n",ans);
	return 0;
}
