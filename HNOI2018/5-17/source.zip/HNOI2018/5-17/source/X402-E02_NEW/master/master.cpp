#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
char a[305],b[305];
int n,k;
int main(){
	freopen("master.in","r",stdin);
	freopen("master.out","w",stdout);
	scanf("%d%d",&n,&k);
	scanf("%s",a+1);
	scanf("%s",b+1);
	int ans=0;
	for (int i=1;i<=n;++i){
		for (int j=1;j<=n;++j){
			int res=0;
			for (int l=1;i+l-1<=n && j+l-1<=n;++l){
				if (a[i+l-1]!=b[j+l-1]){
					++res;
					if (res>k){
						ans=max(ans,l-1);
						break;
					}
				}
			}
			if (res<=k) ans=max(ans,n-max(i,j)+1);
		}
	}
	printf("%d\n",ans);
	return 0;
}
