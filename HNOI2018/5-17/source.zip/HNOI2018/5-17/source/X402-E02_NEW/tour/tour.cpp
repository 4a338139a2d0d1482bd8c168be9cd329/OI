#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=1505;
int a[N][N],n,d[N];
char s[N];
long long ans;
void dfs(int x,int fa,int l,int s){
	if (l==3){
		++ans;
		return;
	}	
	for (int i=1;i<=n;++i)
		if (a[i][x] && i!=fa && i!=s)
			dfs(i,x,l+1,s);
}
int main(){
	freopen("tour.in","r",stdin);
	freopen("tour.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i){
		scanf("%s",s+1);
		for (int j=1;j<=n;++j){
			a[i][j]=s[j]-'0';
			d[j]+=a[i][j];
		}
	}
	if (n>300){
		ans=0;
		for (int i=1;i<=n;++i)
			dfs(i,0,0,i);
		printf("%lld\n",ans);
		return 0;
	}
	ans=0;
	for (int i=1;i<=n;++i)
		for (int j=1;j<=n;++j)
			if (i!=j && a[i][j]){
				for (int t=1;t<=n;++t)
					if (a[i][t] && a[j][t]) --ans;
				ans+=(long long)(d[i]-1)*(long long)(d[j]-1);
			}
	printf("%lld\n",ans);
	return 0;
}
