#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0;
	char ch=0;
	while (ch<'0' || ch>'9') ch=getchar();
	while (ch<='9' && ch>='0'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x;
}
struct node{
	int next,to;
}a[300010];
int head[200010],cnt;
void add(int u,int v){
	a[++cnt].to=v;
	a[cnt].next=head[u];
	head[u]=cnt;
}
int n,m,w[200010];
int d[200010],q[2000010];
void bfs(int s){
	int f=0,l=1;
	q[1]=s;
	memset(d,-1,sizeof(d));
	d[s]=0;
	while (f<l){
		int x=q[++f];
		for (int i=head[x];i;i=a[i].next){
			int y=a[i].to;
			if (d[y]!=-1) continue;
			d[y]=d[x]+1;
			q[++l]=y;
		}
		for (int i=1;i<=n;++i)
			if (d[i]==-1 && i!=x && (w[x]&w[i])==w[i]){
				d[i]=d[x]+1;
				q[++l]=i;
			}
	}
}
int main(){		
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=n;++i) w[i]=read();
	for (int i=1;i<=m;++i){
		int u=read(),v=read();
		add(u,v);
	}
	bfs(1);
	for (int i=1;i<=n;++i)
		printf("%d\n",d[i]);
	return 0;
}
