#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

const int N=105;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int n;
bool ban[N];
vector<int>ve[N];

void dfs1(int id,int u,int fa)
{
	if(id!=u) ve[id].pb(u);
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa||ban[v]) continue;
		dfs1(id,v,u);
	}
}
db dfs(int u,int tot,db p)
{
	dfs1(u,u,0);
	if(!ve[u].size()) return p*tot;
	db ans=0;
	for(int i=0,siz=ve[u].size();i<siz;++i)
	{
		ban[ve[u][i]]=1;
		for(int j=head[ve[u][i]];j;j=e[j].next)
		{
			int v=e[j].to;
			if(!ban[v]) ans+=dfs(v,tot+ve[u].size(),p/ve[u].size());
		}
		ban[ve[u][i]]=0;
	}
	ve[u].clear();
	return ans;
}

void wj()
{
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	/*for(int i=1;i<n;++i)
	{
		int x=read()+1,y=read()+1;
		add(x,y);
	}
	if(n<=7) {printf("%.4lf\n",dfs(1,0,1));return 0;}*/
	printf("%.4lf",n*(log(n)/log(2)));
	return 0;
}
