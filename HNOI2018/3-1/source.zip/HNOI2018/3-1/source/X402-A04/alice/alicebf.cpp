#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=105;
int dot[N][N],sum[N][N];
inline int calc(int xa,int ya,int xb,int yb)
{
	return sum[xb][yb]-sum[xa-1][yb]-sum[xb][ya-1]+sum[xa-1][ya-1];
}
int n,m,T;

void wj()
{
	freopen("alice.in","r",stdin);
	//freopen("alice.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); T=read();
	for(int i=1;i<=T;++i) sum[read()][read()]++;
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j)
		sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
	ll ans=0;
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) for(int k=i;k<=n;++k)
		for(int l=j;l<=m;++l) if(calc(i,j,k,l)) ans++;
	printf("%lld\n",ans);
	return 0;
}
