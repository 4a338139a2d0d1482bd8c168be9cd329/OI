#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=70050;
int n,m,T;
int minv[N<<2],addv[N<<2],add=0;
inline void pushdown(int o)
{
	if(addv[o])
	{
		addv[o<<1]+=addv[o]; addv[o<<1|1]+=addv[o];
		minv[o<<1]+=addv[o]; minv[o<<1|1]+=addv[o];
		addv[o]=0;
	}
}
inline void update(int o,int l,int r,int x,int y,int k)
{
	if(x<=l&&r<=y) {minv[o]+=k; addv[o]+=k; return ;}
	int mid=l+r>>1;
	//pushdown(o);
	if(x<=mid) update(o<<1,l,mid,x,y,k);
	if(y>mid) update(o<<1|1,mid+1,r,x,y,k);
	minv[o]=min(minv[o<<1],minv[o<<1|1]);
}
inline void modify(int o,int l,int r,int x,int k)
{
	if(l==r) {minv[o]=k; return ;}
	int mid=l+r>>1;
	//pushdown(o);
	if(x<=mid) modify(o<<1,l,mid,x,k);
	else modify(o<<1|1,mid+1,r,x,k);
	minv[o]=min(minv[o<<1],minv[o<<1|1]);
	//minv[o]=0;
}
inline int query(int o,int l,int r,int x)
{
	if(l==r) return minv[o];
	int mid=l+r>>1;
	//pushdown(o);
	if(x<=mid) return query(o<<1,l,mid,x);
	else return query(o<<1|1,mid+1,r,x);
}
int ret=0,found=0,val;
inline void gorig(int o,int l,int r,int x)
{
	if(l==r) {if(minv[o]<x) ret=l,found=1,val=minv[o];return ;}
	//pushdown(o);
	int mid=l+r>>1;
	if(minv[o<<1|1]<x) gorig(o<<1|1,mid+1,r,x);
	else gorig(o<<1,l,mid,x);
}
inline void findpre(int o,int l,int r,int x,int y,int k)
{
	if(found) return ;
	if(x<=l&&r<=y) 
	{
		if(minv[o]<k) gorig(o,l,r,k);
		return ;
	}
	//pushdown(o);
	int mid=l+r>>1;
	if(y>mid) findpre(o<<1|1,mid+1,r,x,y,k);
	if(x<=mid) findpre(o<<1,l,mid,x,y,k);
}
inline int getpre(int x,int y,int k)
{
	if(x>y) return 0;
	ret=0; found=0; val=0; findpre(1,1,m,x,y,k);
	return ret;
}
inline void golef(int o,int l,int r,int x)
{
	if(l==r) {if(minv[o]<x) ret=l,found=1,val=minv[o];return ;}
	//pushdown(o);
	int mid=l+r>>1;
	if(minv[o<<1]<x) golef(o<<1,l,mid,x);
	else golef(o<<1|1,mid+1,r,x);
}
inline void findnex(int o,int l,int r,int x,int y,int k)
{
	if(found) return ;
	if(x<=l&&r<=y) 
	{
		if(minv[o]<k) golef(o,l,r,k);
		return ;
	}
//	pushdown(o);
	int mid=l+r>>1;
	if(x<=mid) findnex(o<<1,l,mid,x,y,k);
	if(y>mid) findnex(o<<1|1,mid+1,r,x,y,k);
}
inline int getnex(int x,int y,int k)
{
	if(x>y) return m+1;
	ret=m+1; found=0; val=0; findnex(1,1,m,x,y,k);
	return ret;
}

pii stk[N],stk2[N]; int top=0,top2=0;
vector<int>ask[N];

void wj()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	n=read(); m=read(); T=read();
	for(int i=1;i<=T;++i) 
	{
		int x=read(),y=read();
		ask[x].pb(y);
	}
	ll ans=0,sum=0;
	for(int row=1;row<=n;++row)
	{
		/*for(int j=1;j<=m;++j)
		{
			pii v=pii(up[i][j],1);
			while(top&&stk[top].fi>=v.fi) 
			{
				sum-=1ll*stk[top].fi*stk[top].se;
				v.se+=stk[top].se;
				top--;
			}
			stk[++top]=v;
			sum+=1ll*v.fi*v.se;
			ans+=sum;
		}*/
		//update(1,1,m,1,m,1);
		add++;
		sum+=1ll*(m+1)*m/2;
		for(int i=0,siz=ask[row].size();i<siz;++i)
		{
			top=0; top2=0;
			int in=ask[row][i];
			ll tot=0;
			int hi=query(1,1,m,in);
			while(in)
			{
				int las=getpre(1,in-1,hi);
				stk2[++top2]=pii(hi,in-las);
				sum-=1ll*(hi+add)*(in-las);
				tot+=1ll*(hi+add)*(in-las);
				in=las; hi=val;
			}

			top=top2;
			for(int j=1;j<=top;++j) stk[top-j+1]=stk2[j];
			in=ask[row][i];

			hi=query(1,1,m,in);
			while(in<=m)
			{
				int las=getnex(in+1,m,hi);
				sum-=1ll*(las-in)*tot;
				//if(row==4) cerr<<in<<' '<<las<<' '<<tot<<' '<<sum<<endl;
				if(in==ask[row][i]) sum+=tot;

				if(las>m) break;
				pii v=pii((hi=val),0); //query(1,1,m,las)
				while(top&&stk[top].fi>=v.fi) 
				{
					tot-=1ll*(stk[top].fi+add)*stk[top].se;
					v.se+=stk[top].se;
					top--;
				}
				stk[++top]=v;
				tot+=1ll*(v.fi+add)*v.se;
				in=las;
				//if(row==4&&in==3) cerr<<tot<<endl;
			}
			modify(1,1,m,ask[row][i],-add);
		}
		ans+=sum;
		//cout<<sum<<endl;
	}
	printf("%lld\n",(1ll*n*(n+1)/2)*(1ll*m*(m+1)/2)-ans);
	//cerr<<(1ll*n*(n+1)/2)*(1ll*m*(m+1)/2)-ans<<endl;
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
