#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=2050;
int dot[N][N],up[N][N];
int n,m,T;
pii stk[N]; int top=0;

void wj()
{
	freopen("alice.in","r",stdin);
	//freopen("alice.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); T=read();
	for(int i=1;i<=T;++i) dot[read()][read()]=1;
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j)
		up[i][j]=(dot[i][j]?0:up[i-1][j]+1);
	ll ans=0;
	for(int i=1;i<=n;++i)
	{
		ll sum=0,tot=0;
		top=0;
		for(int j=1;j<=m;++j)
		{
			pii v=pii(up[i][j],1);
			while(top&&stk[top].fi>=v.fi) 
			{
				sum-=1ll*stk[top].fi*stk[top].se;
				v.se+=stk[top].se;
				top--;
			}
			stk[++top]=v;
			sum+=1ll*v.fi*v.se;
			ans+=sum;
			tot+=sum;
		}
	//	cerr<<tot<<endl;
	}
	printf("%lld\n",(1ll*n*(n+1)/2)*(1ll*m*(m+1)/2)-ans);
	return 0;
}
