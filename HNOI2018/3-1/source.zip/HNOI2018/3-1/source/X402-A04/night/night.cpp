#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=500050;
int a[5][N],n,m,b[N],tot=0;
ll ans[N];
int bel[N];
struct ASK
{
	int l,r,id,typ;
}ask[N];
inline bool cmp(ASK a,ASK b) 
{
	return a.typ<b.typ||(a.typ==b.typ&&
	(bel[a.l]<bel[b.l]||(bel[a.l]==bel[b.l]&&a.r<b.r)));
}

namespace md
{
	int nowl=1,nowr=0;
	ll nowans=0;
	int s[N];
	inline void add(int x,int k)
	{
		for(int i=x;i<=tot;i+=(i&-i)) s[i]+=k;
	}
	inline int qry(int l,int r)
	{
		int ans=0;
		for(int i=r;i;i-=(i&-i)) ans+=s[i];
		for(int i=l-1;i;i-=(i&-i)) ans-=s[i];
		return ans;
	}
	void move(int now,int i)
	{
		while(nowl<ask[now].l) nowans-=qry(1,a[i][nowl]-1),add(a[i][nowl],-1),nowl++;
		while(nowl>ask[now].l) nowl--,nowans+=qry(1,a[i][nowl]-1),add(a[i][nowl],1);
		while(nowr<ask[now].r) nowr++,nowans+=qry(a[i][nowr]+1,tot),add(a[i][nowr],1);
		while(nowr>ask[now].r) nowans-=qry(a[i][nowr]+1,tot),add(a[i][nowr],-1),nowr--;
		ans[ask[now].id]=nowans;
	}
}
namespace md3
{
	int nowl=1,nowr=0;
	ll nowans=0;
	int s[N];
	inline void add(int x,int k)
	{
		for(int i=x;i<=tot;i+=(i&-i)) s[i]+=k;
	}
	inline int qry(int l,int r)
	{
		int ans=0;
		for(int i=r;i;i-=(i&-i)) ans+=s[i];
		for(int i=l-1;i;i-=(i&-i)) ans-=s[i];
		return ans;
	}
	int s2[N];
	inline void add2(int x,int k)
	{
		for(int i=x;i<=tot;i+=(i&-i)) s2[i]+=k;
	}
	inline int qry2(int l,int r)
	{
		int ans=0;
		for(int i=r;i;i-=(i&-i)) ans+=s2[i];
		for(int i=l-1;i;i-=(i&-i)) ans-=s2[i];
		return ans;
	}
	void move(int now)
	{
		while(nowl<ask[now].l) 
		{
			nowans-=qry2(1,a[1][nowl]-1);
			nowans-=qry(1,a[1][nowl]-1),add(a[1][nowl],-1);
			nowans-=qry2(1,a[2][nowl]-1),add2(a[2][nowl],-1);
			nowl++;
		}
		while(nowl>ask[now].l) 
		{
			nowl--;
			nowans+=qry2(1,a[2][nowl]-1),add2(a[2][nowl],1);
			nowans+=qry(1,a[1][nowl]-1),add(a[1][nowl],1);
			nowans+=qry2(1,a[1][nowl]-1);
		}
		while(nowr<ask[now].r) 
		{
			nowr++;
			nowans+=qry(a[1][nowr]+1,tot),add(a[1][nowr],1);
			nowans+=qry(a[2][nowr]+1,tot);
			nowans+=qry2(a[2][nowr]+1,tot),add2(a[2][nowr],1);
		}
		while(nowr>ask[now].r) 
		{
			nowans-=qry(a[2][nowr]+1,tot);
			nowans-=qry2(a[2][nowr]+1,tot),add2(a[2][nowr],-1);
			nowans-=qry(a[1][nowr]+1,tot),add(a[1][nowr],-1);
			nowr--;
		}
		ans[ask[now].id]=nowans;
	}
}

void wj()
{
	freopen("night3.in","r",stdin);
	freopen("night3.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); int Q=read();
	//n=m;
	for(int i=1;i<=m;++i) a[1][i]=read(),b[++tot]=a[1][i];
	for(int i=1;i<=m;++i) a[2][i]=read(),b[++tot]=a[2][i];
	sort(b+1,b+1+tot);
	tot=unique(b+1,b+1+tot)-(b+1);
	for(int i=1;i<=m;++i) a[1][i]=lower_bound(b+1,b+1+tot,a[1][i])-b;
	for(int i=1;i<=m;++i) a[2][i]=lower_bound(b+1,b+1+tot,a[2][i])-b;

	int blksz=sqrt(n);
	for(int i=1;i<=n;++i) bel[i]=(i-1)/blksz+1;

	for(int cas=1;cas<=Q;++cas)
	{
		int u1=read();
		ask[cas].l=read();
		int u2=read();
		ask[cas].r=read();
		if(u1==1&&u2==1) ask[cas].typ=1;
		else if(u1==2&&u2==2) ask[cas].typ=2;
		else ask[cas].typ=3;
		ask[cas].id=cas;
	}
	sort(ask+1,ask+1+Q,cmp);

	int now=1;
	for(;now<=Q&&ask[now].typ==1;++now) md::move(now,1);
	memset(md::s,0,sizeof(md::s));
	md::nowl=1; md::nowr=0; md::nowans=0;

	for(;now<=Q&&ask[now].typ==2;++now) md::move(now,2);

	for(;now<=Q&&ask[now].typ==3;++now) md3::move(now);
	for(int i=1;i<=Q;++i) printf("%lld\n",ans[i]);
	return 0;
}
