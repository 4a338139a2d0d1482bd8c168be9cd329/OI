#include<bits/stdc++.h>
using namespace std;
const int maxn=110;
int a[maxn][maxn];
int sum[maxn][maxn];
int main(){
	freopen("alice.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int n,m,q;
	scanf("%d%d%d",&n,&m,&q);
	int x,y;
	for(int i=1;i<=q;i++){
		scanf("%d%d",&x,&y);
		a[x][y]=1;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+a[i][j];
	int ans=0;
	for(int i=0;i<n;i++)
		for(int j=i+1;j<=n;j++)
			for(int k=0;k<m;k++)
				for(int l=k+1;l<=m;l++)
					if(sum[j][l]-sum[i][l]-sum[j][k]+sum[i][k]>0)
						ans++;
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}
