#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=rand()%50+1,m=rand()%50+1,q=rand()%10000+1;
	printf("%d %d %d\n",n,m,q);
	for(int i=1;i<=q;i++)
		printf("%d %d\n",rand()%n+1,rand()%m+1);
}
int main(){
	srand(time(0)+getx());
	freopen("alice.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
