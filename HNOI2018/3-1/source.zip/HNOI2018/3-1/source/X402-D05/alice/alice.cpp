#include<bits/stdc++.h>
using namespace std;
const int maxn=2010;
int a[maxn][maxn];
int b[maxn][maxn];
struct node{
	int h,l;
}stk[maxn];
int top;
long long sum;
void Insert(int h,int l){
	while(top>0&&stk[top].h>=h){
		l=stk[top].l;
		sum-=(l-1)*(long long)(stk[top].h-stk[top-1].h);
		top--;
	}
	stk[++top]=(node){h,l};
	sum+=(l-1)*(long long)(stk[top].h-stk[top-1].h);
}
int main(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	int n,m,q;
	scanf("%d%d%d",&n,&m,&q);
	int x,y;
	for(int i=1;i<=q;i++){
		scanf("%d%d",&x,&y);
		a[x][y]=1;
	}
	for(int i=n;i>=1;i--){
		for(int j=1;j<=m;j++){
			if(a[i][j]) b[i][j]=0;
			else b[i][j]=b[i+1][j]+1;
		}
	}
	long long ans=0;
	for(int i=1;i<=n;i++){
		top=0,sum=0;
		for(int j=1;j<=m;j++){
			Insert(b[i][j],j);
			ans=ans+b[i][j]*j-sum;
		}
	}
	long long tot=n*(long long)(n+1)/2*m*(long long)(m+1)/2;
	printf("%lld\n",tot-ans);
	return 0;
}
