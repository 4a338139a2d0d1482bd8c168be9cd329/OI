#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
bool vis[maxn];
int getsiz(int u,int fa){
	int res=1;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[tto[i]]) continue;
		res+=getsiz(tto[i],u);
	}
	return res;
}
double dfs_solve(int u,int fa);
double dfs(int u){
	int siz=getsiz(u,-1);
	if(siz==1) return 1;
	double ans=siz;
	vis[u]=1;
	for(int i=beg[u];i;i=nex[i]){
		if(vis[tto[i]]) continue;
		siz=getsiz(tto[i],u);
		ans=ans+dfs_solve(tto[i],u)/siz;
	}
	vis[u]=0;
	return ans;
}
double dfs_solve(int u,int fa){
	double res=dfs(u);
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(vis[tto[i]]) continue;
		res+=dfs_solve(tto[i],u);
	}
	return res;
}
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	int n;
	scanf("%d",&n);
	int s,t;
	for(int i=1;i<n;i++){
		scanf("%d%d",&s,&t);
		s++,t++;
		putin(s,t);
		putin(t,s);
	}
	printf("%.4f\n",dfs_solve(1,-1)/n);
	return 0;
}
