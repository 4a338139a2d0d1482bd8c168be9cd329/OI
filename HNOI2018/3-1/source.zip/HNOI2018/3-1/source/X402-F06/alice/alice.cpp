#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=3e3+10;
int sum[maxn][maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
#endif
	int n=read(),m=read(),q=read();
	REP(i,1,q){
		int x=read(),y=read();
		sum[x][y]++;
	}
	REP(i,1,n)
		REP(j,1,m)
			sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
	ll ans=0;
	REP(i,1,n)
		REP(j,1,m)
			REP(a,i,n)
				REP(b,j,m)
					if(sum[a][b]-sum[a][j-1]-sum[i-1][b]+sum[i-1][j-1]>0)
						ans++;
	printf("%lld\n",ans);
	return 0;
}
