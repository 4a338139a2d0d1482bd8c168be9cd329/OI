#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void chkmin(int &a,int b){if(a>b)a=b;}

typedef long long ll;
const int N=2009;
const int K=59;

int n,m,q,rt;
int g[N][N],d[N][N],mind[N][N];

namespace pst
{
	const int M=N*100;

	int ls[M],rs[M],tot;
	ll t[M],cnts[M];

	inline int newnode()
	{
		assert(tot<M);
		tot++;ls[tot]=rs[tot]=t[tot]=cnts[tot]=0;
		return tot;
	}

	inline void clear(){tot=rt=0;rt=newnode();}

	inline int modify(int pre,int l,int r,int p,ll v,ll c)
	{
		int now=newnode();cnts[now]=cnts[pre]+c;t[now]=t[pre]+v;
		if(l==r)return now;int mid=l+r>>1;
		if(p<=mid)ls[now]=modify(ls[pre],l,mid,p,v,c),rs[now]=rs[pre];
		else ls[now]=ls[pre],rs[now]=modify(rs[pre],mid+1,r,p,v,c);
		return now;
	}

	inline int clean(int pre,int l,int r,int dl,int dr)
	{
		int now=newnode(),mid=l+r>>1;
		if(dl==l && r==dr)return now;
		ls[now]=ls[pre];rs[now]=rs[pre];
		if(dr<=mid)
			ls[now]=clean(ls[pre],l,mid,dl,dr),rs[now]=rs[pre];
		else if(mid<dl)
			ls[now]=ls[pre],rs[now]=clean(rs[pre],mid+1,r,dl,dr);
		else
		{
			ls[now]=clean(ls[pre],l,mid,dl,mid);
			rs[now]=clean(rs[pre],mid+1,r,mid+1,dr);
		}
		t[now]=t[ls[now]]+t[rs[now]];
		cnts[now]=cnts[ls[now]]+cnts[rs[now]];
		return now;
	}

	inline ll query(ll *tt,int x,int l,int r,int dl,int dr)
	{
		if(!x || dl==l && r==dr)return tt[x];int mid=l+r>>1;
		if(dr<=mid)return query(tt,ls[x],l,mid,dl,dr);
		else if(mid<dl)return query(tt,rs[x],mid+1,r,dl,dr);
		else return query(tt,ls[x],l,mid,dl,mid)+query(tt,rs[x],mid+1,r,mid+1,dr);
	}
}

int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);

	n=read();m=read();q=read();
	for(int i=1,x,y;i<=q;i++)
	{
		x=read();y=read();
		g[x][y]=1;
	}

	for(int i=1;i<=n;i++)
	{
		d[i][m+1]=m+1;
		for(int j=m;j>=1;j--)
			d[i][j]=g[i][j]?j:d[i][j+1];
	}
	
	ll ans=0;
	for(int j=1;j<=m;j++)
	{
		pst::clear();
		for(int i=n;i>=1;i--)
		{
			int cnt=pst::query(pst::cnts,rt,1,m+1,d[i][j],m+1);
			rt=pst::clean(rt,1,m+1,d[i][j],m+1);
			rt=pst::modify(rt,1,m+1,d[i][j],(ll)(cnt+1ll)*d[i][j],cnt+1ll);
			ans+=(ll)(m+1ll)*(n-i+1)-pst::t[rt];
		}
	}

	printf("%lld\n",ans);
	return 0;
}
