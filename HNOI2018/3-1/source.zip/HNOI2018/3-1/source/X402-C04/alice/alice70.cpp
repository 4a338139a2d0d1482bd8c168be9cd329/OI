#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void chkmin(int &a,int b){if(a>b)a=b;}

const int N=2009;
const int K=59;

int n,m,q,rt;
int g[N][N],d[N][N],mind[N][N];

namespace pst
{
	const int M=N*20;

	int ls[M],rs[M],t[M],tot;

	inline int newnode()
	{
		tot++;ls[tot]=rs[tot]=t[tot]=0;
		return tot;
	}

	inline void clear(){tot=rt=0;rt=newnode();}

	inline int modify(int pre,int l,int r,int p,int v)
	{
		int now=newnode();t[now]=t[pre]+v;
		if(l==r)return now;int mid=l+r>>1;
		if(p<=mid)ls[now]=modify(ls[pre],l,mid,p,v),rs[now]=rs[pre];
		else ls[now]=ls[pre],rs[now]=modify(rs[pre],mid+1,r,p,v);
		return now;
	}

	inline int clean(int pre,int l,int r,int dl,int dr)
	{
		int now=newnode(),mid=l+r>>1;
		if(dl==l && r==dr)
		{
			t[now]=ls[now]=rs[now]=0;
			return now;
		}
		if(dr<=mid)
			ls[now]=clean(ls[pre],l,mid,dl,dr),rs[now]=rs[pre];
		else if(mid<dl)
			ls[now]=ls[pre],rs[now]=clean(rs[pre],mid+1,r,dl,dr);
		else
		{
			ls[now]=clean(ls[pre],l,mid,dl,mid);
			rs[now]=clean(rs[pre],mid+1,r,mid+1,dr);
		}
		t[now]=t[ls[now]]+t[rs[now]];
		return now;
	}

	inline int query(int x,int l,int r,int dl,int dr)
	{
		if(dl==l && r==dr)return t[x];int mid=l+r>>1;
		if(dr<=mid)return query(ls[x],l,mid,dl,dr);
		else if(mid<dl)return query(rs[x],mid+1,r,dl,dr);
		else return query(ls[x],l,mid,dl,mid)+query(rs[x],mid+1,r,mid+1,dr);
	}
}

int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);

	n=read();m=read();q=read();
	for(int i=1,x,y;i<=q;i++)
	{
		x=read();y=read();
		g[x][y]=1;
	}

	for(int i=1;i<=n;i++)
	{
		d[i][n+1]=n+1;
		for(int j=n;j>=1;j--)
			d[i][j]=g[i][j]?j:d[i][j+1];
	}
	
	int ans=0;
	for(int j=1;j<=m;j++)
	{
		pst::clear();
		for(int i=n;i>=1;i--)
		{
			int cnt=pst::query(rt,1,m,1,d[i][j]);
			rt=pst::clean(rt,1,m,1,d[i][j]);
			rt=pst::modify(rt,1,m,d[i][j],cnt+1);
			ans+=(n+1)*(n-i+1)-pst::t[rt];
		}
	}

	printf("%d\n",ans);
	return 0;
}
