#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef long long ll;
set<pr> ha;

const int N=2009;
const int M=2009;

int g[N][M];

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("alice.in","w",stdout);

	int n=20,m=20,p=10;
	printf("%d %d %d\n",n,m,p);
	for(int i=1;i<=p;i++)
	{
		int u,v;
		re:;
		u=rand()%n+1;
		v=rand()%m+1;
		if(g[u][v])goto re;;
		printf("%d %d\n",u,v);
		g[u][v]=1;
	}
	return 0;
}
