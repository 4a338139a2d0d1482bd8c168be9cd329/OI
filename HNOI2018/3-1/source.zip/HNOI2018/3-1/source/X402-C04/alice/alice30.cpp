#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void chkmin(int &a,int b){if(a>b)a=b;}

typedef long long ll;
const int N=2009;

int n,m,q;
int g[N][N],u[N][N],d[N][N];

int main()
{
	freopen("alice.in","r",stdin);
	freopen("alices.out","w",stdout);

	n=read();m=read();q=read();
	for(int i=1,x,y;i<=q;i++)
	{
		x=read();y=read();
		g[x][y]=1;
	}

	for(int i=1;i<=n;i++)
	{
		d[i][m+1]=m+1;
		for(int j=m;j>=1;j--)
			d[i][j]=g[i][j]?j:d[i][j+1];
		u[i][0]=0;
		for(int j=1;j<=m;j++)
			u[i][j]=g[i][j]?j:u[i][j-1];
	}

	ll ans=0;
	for(int j=1;j<=m;j++)
		for(int i=n;i>=1;i--)
		{
			int mv=m+1,tot=0;
			for(int k=i;k<=n;k++)
			{
				chkmin(mv,d[k][j]);
				if(mv<=m)tot+=m-mv+1;
			}
			ans+=tot;
		}

	printf("%lld\n",ans);
	return 0;
}
