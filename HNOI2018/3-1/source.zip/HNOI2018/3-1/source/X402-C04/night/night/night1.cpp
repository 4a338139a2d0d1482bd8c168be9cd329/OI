#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int write(int x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

typedef long long ll;
const int N=2;
const int M=300009;

int n,m,q,L;
int a[N][M],rt[M];
map<int,int> ha;

namespace pst
{
	const int P=M*20;
	int ls[P],rs[P],tot;
	ll t[P];

	inline int add(int pre,int l,int r,int p,ll v)
	{
		int now=++tot;t[now]=t[pre]+v;
		if(l==r)return now;int mid=l+r>>1;
		if(p<=mid)ls[now]=add(ls[pre],l,mid,p,v),rs[now]=rs[pre];
		else ls[now]=ls[pre],rs[now]=add(rs[pre],mid+1,r,p,v);
		return now;
	}

	inline ll query(int t1,int t2,int l,int r,int dl,int dr)
	{
		if(dl==l && r==dr)return t[t2]-t[t1];
		int mid=l+r>>1;
		if(dr<=mid)return query(ls[t1],ls[t2],l,mid,dl,dr);
		else if(mid<dl)return query(rs[t1],rs[t2],mid+1,r,dl,dr);
		else return query(ls[t1],ls[t2],l,mid,dl,mid)+query(rs[t1],rs[t2],mid+1,r,mid+1,dr);
	}
}

int main()
{
	char filename[40];
	for(int i=1;i<=10;i++)
	{
		sprintf(filename,"night%d.in",i);
		if(fopen(filename,"r"))
		{
			freopen(filename,"r",stdin);
			sprintf(filename,"night%d.out",i);
			freopen(filename,"w",stdout);
			cerr<<filename<<endl;
			break;
		}
	}

	n=read();m=read();q=read();
	for(int j=1;j<=m;j++)
		ha[a[1][j]=read()];

	for(map<int,int>::iterator it=ha.begin();it!=ha.end();it++)
		(*it).second=++L;
	cerr<<L<<endl;
	for(int j=1;j<=m;j++)
		rt[j]=pst::add(rt[j-1],1,L,ha[a[1][j]],1);

	while(q--)
	{
		cerr<<q<<endl;
		ll ans=0;
		int lx,ly,rx,ry;
		lx=read();ly=read();
		rx=read();ry=read();
		
		for(int j=ly;j<=ry;j++)
			if(ha[a[1][j]]>1)
				ans+=pst::query(rt[j-1],rt[ry],1,L,1,ha[a[1][j]]-1);
		printf("%lld\n",ans);
	}

	return 0;
}
