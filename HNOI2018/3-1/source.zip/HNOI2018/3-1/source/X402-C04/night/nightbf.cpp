#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;

inline void write(ll x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

const int N=89;
const int M=89;

int n,m,q;
int a[N][M];

int main()
{
	char filename[40];
	for(int i=1;i<=10;i++)
	{
		sprintf(filename,"night%d.in",i);
		if(fopen(filename,"r"))
		{
			freopen(filename,"r",stdin);
			sprintf(filename,"night%d.out",i);
			freopen(filename,"w",stdout);
			cerr<<filename<<endl;
			break;
		}
	}

	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			a[i][j]=read();
	while(q--)
	{
		if(q%1000==0)cerr<<q<<endl;
		ll ans=0;int lx,ly,rx,ry;
		lx=read();ly=read();
		rx=read();ry=read();
		
		for(int i=lx;i<=rx;i++)
			for(int j=ly;j<=ry;j++)
				for(int k=i;k<=rx;k++)
					for(int l=j;l<=ry;l++)
						if(a[i][j]>a[k][l])
							ans++;
		write(ans);putchar('\n');
	}

	return 0;
}
/*
87572155
41776117
195337830
92505806
*/
