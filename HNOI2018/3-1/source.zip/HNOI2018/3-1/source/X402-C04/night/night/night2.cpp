#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int write(int x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

typedef long long ll;
const int N=6;
const int M=200009;
const int Q=1000009;

int n,m,q,L,blk;
int a[N][M];
ll anss[Q];
map<int,int> ha;

struct event
{
	int l,r,id;
	bool operator < (event o)const
	{
		if(l/blk==o.l/blk)
			return r<o.r;
		return l/blk<o.l/blk;
	}
};

vector<event> qu[N][N];

namespace bit
{
	ll b[N][N*M];

	inline void add(ll *bi,int p,int v)
	{
		for(int i=p;i<=L+2;i+=i&-i)
			bi[i]+=v;
	}
	
	inline ll query(ll *bi,int p)
	{
		ll ret=0;
		for(int i=p;i;i-=i&-i)
			ret+=bi[i];
		return ret;
	}
}

using namespace bit;

int main()
{
	char filename[40];
	for(int i=1;i<=10;i++)
	{
		sprintf(filename,"night%d.in",i);
		if(fopen(filename,"r"))
		{
			freopen(filename,"r",stdin);
			sprintf(filename,"night%d.out",i);
			freopen(filename,"w",stdout);
			cerr<<filename<<endl;
			break;
		}
	}

	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			ha[a[i][j]=read()];
	blk=sqrt(m)+1;

	for(map<int,int>::iterator it=ha.begin();it!=ha.end();it++)
		(*it).second=++L;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			a[i][j]=ha[a[i][j]];

	for(int i=1,xl,xr,l,r;i<=q;i++)
	{
		xl=read();l=read();xr=read();r=read();
		qu[xl][xr].push_back((event){l,r,i});
	}

	for(int lb=1;lb<=n;lb++)
		for(int rb=lb;rb<=n;rb++)
		{
			int qq=qu[lb][rb].size();
			if(!qq)continue;
			cerr<<lb<<" "<<rb<<" "<<qq<<endl;
			vector<event> &qs=qu[lb][rb];
			sort(qs.begin(),qs.end());

			for(int j=lb;j<=rb;j++)
				memset(b[j],0,sizeof(ll)*(L+6));
			
			int l=1,r=0;ll ans=0;
			for(int i=0;i<qq;i++)
			{
				if(i%1000==0)cerr<<i<<endl;
				while(r<qs[i].r)
				{
					r++;
					for(int j=lb;j<=rb;j++)
					{
						for(int k=lb;k<=j;k++)
							ans+=query(b[k],L)-query(b[k],a[j][r]);
						add(b[j],a[j][r],1);
					}
				}
				while(qs[i].r<r)
				{
					for(int j=rb;j>=lb;j--)
					{
						add(b[j],a[j][r],-1);
						for(int k=lb;k<=j;k++)
							ans-=query(b[k],L)-query(b[k],a[j][r]);
					}
					r--;
				}
				while(l<qs[i].l)
				{
					for(int j=lb;j<=rb;j++)
					{
						for(int k=j;k<=rb;k++)
							ans-=query(b[k],a[j][l]-1);
						add(b[j],a[j][l],-1);
					}
					l++;
				}
				while(qs[i].l<l)
				{
					l--;
					for(int j=rb;j>=lb;j--)
					{
						for(int k=j;k<=rb;k++)
							ans+=query(b[k],a[j][l]-1);
						add(b[j],a[j][l],1);
					}
				}
				anss[qs[i].id]=ans;	
			}
		}
	for(int i=1;i<=q;i++)
		printf("%lld\n",anss[i]);
	return 0;
}
