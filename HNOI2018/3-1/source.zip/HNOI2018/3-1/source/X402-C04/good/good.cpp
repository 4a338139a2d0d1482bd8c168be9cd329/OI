#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef double db;
const int N=3.5e4+9;

int n;
vector<int> g[N];
set<int> a,ta;

inline void dfs(int u,int fa,set<int> &p,set<int> v)
{
	p.insert(u);
	for(int i=0,e=g[u].size();i<e;i++)
		if(g[u][i]!=fa && v.count(g[u][i]))
			dfs(g[u][i],u,p,v);
}

inline db work(set<int> p)
{
	db per=1.0/(db)p.size(),tmp,ret=0;
	for(set<int>::iterator j=p.begin();j!=p.end();j++)
	{
		int u=(*j);tmp=0;
		for(int i=0,e=g[u].size();i<e;i++)
			if(p.count(g[u][i]))
			{
				ta.clear();
				dfs(g[u][i],u,ta,p);
				tmp+=work(ta);
			}
		ret+=tmp*per;
	}
	ret+=(db)p.size();
	return ret;
}

int main()
{
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);

	n=read();
	for(int i=1,u,v;i<n;i++)
	{
		u=read()+1;v=read()+1;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	for(int i=1;i<=n;i++)
		a.insert(i);

	printf("%.4f\n",work(a));
	return 0;
}
