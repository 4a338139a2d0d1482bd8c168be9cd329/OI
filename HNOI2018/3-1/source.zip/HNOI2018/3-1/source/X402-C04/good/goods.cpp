#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
typedef double db;
const int N=3.5e4+9;

int n;
ll g[N];
map<ll,db> ha;

inline void dfs(int u,int fa,ll &p,ll v)
{
	p|=(((p>>u)|1)<<u);
	ll son=g[u]&v;
	for(int i=0;i<n;i++)
		if(((son>>i)&1) && i!=fa)
			dfs(i,u,p,v);
}

inline void out(int x)
{
	for(int i=0;i<n;i++)
		putchar('0'+(x>>i&1));
	puts("");
}

inline void err(int x)
{
	for(int i=0;i<n;i++)
		cerr<<(char)('0'+(x>>i&1));
	cerr<<endl;
}

inline db work(ll state)
{
	if(ha.count(state))return ha[state];
	int sz=__builtin_popcount(state);
	db per=1.0/(db)sz,tmp,ret=(db)sz;
	for(int i=0;i<n;i++)
		if(state>>i&1)
		{
			ll son=g[i]&state,nst;tmp=0;
			for(int j=0;j<n;j++)
				if(son>>j&1)
				{
					nst=0;
					dfs(j,i,nst,state);
					tmp+=work(nst);
				}
			ret+=tmp*per;
		}
	return ha[state]=ret;
}

int main()
{
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);

	n=read();
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		g[u]|=(((g[u]>>v)|1)<<v);
		g[v]|=(((g[v]>>u)|1)<<u);
	}

	ll st=0;
	for(int i=1;i<=n;i++)
		st<<=1,st|=1;

	printf("%.4f\n",work(st));
	return 0;
}
