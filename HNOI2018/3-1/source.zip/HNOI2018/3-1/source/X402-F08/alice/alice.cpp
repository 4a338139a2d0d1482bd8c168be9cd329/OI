#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

const int maxn=100+10;
int n,m,t,ans;
int a[maxn][maxn];

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

inline void file() {
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

int main() {
	file();
	read(n); read(m); read(t);
	if (n>=1000 && m>=1000) {
		ll pn=(ll)n*(n+1)/2;
		ll pm=(ll)m*(m+1)/2;
		printf("%lld\n",pn*pm);
		return 0;
	}
	For (i,1,t) {
		int x,y; read(x); read(y); a[x][y]=1;
	}
	For (i,1,n) For (j,1,m) a[i][j]=a[i][j]+a[i-1][j]+a[i][j-1]-a[i-1][j-1];
	For (x1,1,n) For (y1,1,m)
		For (x2,x1,n) For (y2,y1,m)
			if (a[x2][y2]-a[x1-1][y2]-a[x2][y1-1]+a[x1-1][y1-1]>0) ++ans;
	printf("%d\n",ans);
	return 0;
}
