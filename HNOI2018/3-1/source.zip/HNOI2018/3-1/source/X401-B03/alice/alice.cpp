#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
int n,m,q;
int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	read(n);read(m);read(q);
	if(n<=100&&m<=100)
	{
		static int sum[110][110];
		while(q--)
		{
			static int x,y;
			read(x);read(y);
			sum[x][y]=1;
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
			sum[i][j]=sum[i][j]+sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
		int tot=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				for(int k=0;k+i<=n;k++)
					for(int w=0;w+j<=m;w++)
					if(sum[i+k][j+w]-sum[i+k][j-1]-sum[i-1][j+w]+sum[i-1][j-1]>=1)tot++;
		printf("%d\n",tot);
	}
	return 0;
}
