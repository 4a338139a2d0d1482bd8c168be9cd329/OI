#include<bits/stdc++.h>
#define ll long long
using namespace std;
template<typename T>inline void read(T &x){
	int p=1;x=0;char c=getchar();
	while(!isdigit(c)){
		if(c=='-')p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	x*=p;
}
inline void write(int x){  
    if(x==0){putchar(48);puts(" ");return;}
    int len=0,dg[20];
    while(x>0){dg[++len]=x%10;x/=10;}
    for(int i=len;i>=1;i--)putchar(dg[i]+48);
    puts(" ");
}
inline void fre_open(){
	freopen("night.in","r",stdin);
	freopen("night.out","w",stdout);
}
const int maxn=1000000;
ll ans;
ll T[maxn];
ll a[2][maxn];
ll A[maxn];
inline void merge_sort(int x,int y){
	if(y-x>1){
		int m=x+(y-x)/2,p,q,i;
		p=x,q=m,i=x;
		merge_sort(x,m);
		merge_sort(m,y);
		while(p<m||q<y){
			if(q>=y || (p<m && A[p]<=A[q]))T[i++]=A[p++];
			else T[i++]=A[q++],ans+=m-p;
		}
		for(i=x;i<y;++i)A[i]=T[i];
	}
}
ll n,m,q;
ll cnt;
int main(){
	fre_open();
	read(n),read(m),read(q);
	for(register int j=0;j<m;++j)
		read(A[j]);
	ll u1,u2,v1,v2;
	while(q--){
		ans=0;cnt=0;
		read(u1),read(v1),read(u2),read(v2);
		merge_sort(v1-1,v2-1);
		write(ans);
	}
	return 0;
}

