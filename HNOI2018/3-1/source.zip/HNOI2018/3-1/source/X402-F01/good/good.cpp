#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n;
int sz[100005];
double dp[100005];
int he[200005],to[200005],ne[200005],e;
vector<int>son[40005];
void add(int x,int y){
   to[++e]=y;
   ne[e]=he[x];
   he[x]=e;
}
void dfs(int x,int fa){
	sz[x]=1;
    for(int i=he[x];i;i=ne[i]){
	   int v=to[i];
       if(v==fa)continue;
	   dfs(v,x);
	   sz[x]+=sz[v];
       son[x].push_back(v);
	}
}
void Dfs(int x){
     double res=0.0000;
     F(i,1,x){
       if(!dp[i-1]&&i-1!=0)Dfs(i-1);
	   if(!dp[x-i]&&x-i!=0)Dfs(x-i);
	     res+=dp[i-1]+dp[x-i];
	 }
	 dp[x]=res/x+x;
}
int main () {
freopen("good.in","r",stdin);
freopen("good.out","w",stdout);
     n=read();
	  F(i,1,n-1){
	    int x=read(),y=read();
		x++;
		y++;
		add(x,y);
		add(y,x);
	  }
	  dp[1]=1.0000;
	  dp[2]=3.0000;
	  Dfs(n);
	  dfs(1,0);
	  printf("%.4lf\n",dp[n]);
	  return 0;
}
