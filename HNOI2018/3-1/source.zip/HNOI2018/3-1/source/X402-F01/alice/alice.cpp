#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n,m,q;
long long ans;
int a[2005][2005];
int sum[2005][2005];
#define mid ((l+r)>>1)
#define rmid ((lr+rr)>>1)
void bf(){
    F(i,1,n){
      F(j,1,m){
	    sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+a[i][j];
	  }
   }
	F(i,0,n){
	   F(j,0,m){
	      F(k,i+1,n){
		     F(l,j+1,m){
			    if(sum[k][l]-sum[k][j]-sum[i][l]+sum[i][j]>0)ans++;
			 }
		  }
	   }
	}
}
int main () {
freopen("alice.in","r",stdin);
freopen("alice.out","w",stdout);
   n=read();
   m=read();
   q=read();
   F(i,1,q){
      int x=read(),y=read();
	  a[x][y]=1;
   }
    bf();
    printf("%lld\n",ans);
    return 0;
}
