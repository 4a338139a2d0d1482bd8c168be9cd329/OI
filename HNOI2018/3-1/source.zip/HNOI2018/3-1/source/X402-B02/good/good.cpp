#include<bits/stdc++.h>
#define pb push_back
#define sz size
const int N=20;
using namespace std;

int n,e,ret;
int vis[N];
int o[N];
double ans;

namespace __{
	int bgn[N],to[N],nxt[N];
	
	void add(int x,int y){
		to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e;
	}

	void fdsz(int x,vector<int> &g){
		o[x]=1;
		g.pb(x); ret++;
		for(int i=bgn[x]; i; i=nxt[i]){
			if(!o[to[i]])
				fdsz(to[i],g);
		}
	}

	void F(int x,double p,int *t){
		for(int i=1; i<=n; ++i) o[i]=t[i];
		vector<int> g;
		g.clear(); ret=0;
		fdsz(x,g); ans+=ret*p;
		if(ret==1) {return;}
		int tmp[N];
		int all=g.sz();
		for(int i=0; i<g.sz(); ++i)if(!t[g[i]]){
			t[g[i]]=1;
			for(int j=1; j<=n; ++j) tmp[j]=t[j];
			for(int j=0; j<g.sz(); ++j){
				if(g[j]!=g[i]){
					F(g[j],p/all,tmp);
					break;
				}
			}
			t[g[i]]=0;
		}
	}

	void solve(){
		scanf("%d",&n);
		int x=0,y=0;
		for(int i=1; i<n; ++i){
			scanf("%d%d",&x,&y);
			++x; ++y;
			add(x,y); add(y,x);
		}
		F(1,1,vis);
		printf("%.5lf\n",ans);
	}
}
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	__::solve();
}
