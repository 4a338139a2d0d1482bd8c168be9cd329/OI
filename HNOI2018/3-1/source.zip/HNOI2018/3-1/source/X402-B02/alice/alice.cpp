#include<bits/stdc++.h>
const int N=2e5+10;
#define rep(i,a,b) for(register int i=a; i<=b; ++i)
#define drep(i,a,b) for(register int i=a; i>=b; --i)
#define rg register 
#define pb push_back
using namespace std;

int n,m,c;
long long ans;
struct node{
	int x,y;
	bool operator < (const struct node &p){
		if(x==p.x) return y<p.y;
		return x<p.x;
	}
};
struct node p[N];

bool cmp (struct node &p,struct node &q){
	return p.y<q.y;
}

namespace work1{
	int f(int x) {return x*(x+1)/2;}
	void solve(){
		scanf("%d%d%d",&n,&m,&c);
		for(int i=1; i<=c; ++i){
			scanf("%d%d",&p[i].x,&p[i].y);
		}
		sort(p+1,p+c+1);
		rep(i,1,n) rep(j,i,n){
			vector<node> g; g.clear();
			int fr=0,ed=0,ls=0;
			rep(h,1,c) if(i<=p[h].x&&p[h].x<=j){	
				g.pb(p[h]);
			}
			sort(g.begin(),g.end(),cmp);
			if(!g.size()) {continue;}
			ans+=f(m);
			if(g.size()){
				ans-=f(g[0].y-1);
				ans-=f(m-g[g.size()-1].y);
			}
			for(int k=1; k<g.size(); ++k){
				int v1=g[k-1].y,v2=g[k].y;
				ans-=f(v2-v1-1);
			}
		}
		printf("%lld\n",ans);
	}	
}

int main(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	work1::solve();	
}
