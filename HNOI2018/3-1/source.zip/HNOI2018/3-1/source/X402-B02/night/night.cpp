#include<bits/stdc++.h>
#define rg register
#define ll long long
#define upd add
const int N=1e5+10;
using namespace std;

int n,m,q;
int a[N+10],b[N+10];

namespace bit{
	int c[N+10];
	int lowbit(int x){
		return x&-x;
	}
	int sum(int x){
		int y=0;
		while(x){
			y+=c[x];
			x-=lowbit(x);
		}
		return y;
	}
	void add(int x,int v){
		while(x<=N){
			c[x]+=v;
			x+=lowbit(x);
		}
	}
}
using namespace bit;

map<int,int> mp;

int main(){
	freopen("night1.in","r",stdin);
	freopen("night1.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	
	for(int i=1; i<=m; ++i) scanf("%d",&a[i]),b[i]=a[i];
	
	sort(b+1,b+m+1);
	
	int cnt=0;
	for(int i=1; i<=m; ++i) if(!mp[b[i]]) mp[b[i]]=++cnt;

	for(int i=1; i<=m; ++i) a[i]=mp[a[i]];


	int x0=0,y0=0,x1=0,y1=0;
	for(int i=1; i<=q; ++i){
		scanf("%d%d%d%d",&x0,&y0,&x1,&y1);
		long long tmp=0;
		for(register int j=y0; j<=y1; ++j){
			upd(a[j],1);
			tmp+=y1-y0+1-sum(a[j]);
		}
		for(register int j=y0; j<=y1; ++j){
			upd(a[j],-1);
		}
		printf("%lld\n",tmp);
	}
	/*for(int i=1; i<=n; ++i)
		for(int j=1; j<=m; ++j)
			scanf("%d",&a[i][j]);
	
	int x=0,y=0,tmp=0,z=0,p=0;
	for(int i=1; i<=q; ++i){
		scanf("%d%d%d%d",&x,&z,&y,&p);
		tmp=0;
		for(rg int j=x; j<=y; ++j)
			for(rg int k=z; k<=p; ++k)	
				for(rg int j1=j; j1<=y; ++j1)
					for(rg int k1=k; k1<=p; ++k1){
						if(a[j][k]>a[j1][k1]) ++tmp;
					}
		printf("%d\n",tmp);
	}*/
}
