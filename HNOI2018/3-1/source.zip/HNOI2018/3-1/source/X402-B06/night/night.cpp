#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("night7.in","r",stdin);
	freopen("night7.out","w",stdout);
	#endif
}
const int MAXN=3e3+7;
static long long n,m,q;
static int a[MAXN][MAXN],sum[MAXN][MAXN];
int main(void){
	file();
    static long long x,y,u,v;
    static long long ans;
	read(n);read(m);read(q);
    Rep(i,1,n)Rep(j,1,m)
    {
        read(a[i][j]);
        sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
        if(a[i][j]==9)++sum[i][j],a[i][j]=0;
        else a[i][j]=1;
    }
    Rep(i,1,q)
    {
        if(i%10000==0)cerr<<100.0*i/q<<'%'<<endl;
        read(u);read(v);read(x);read(y);
        ans=0;
        Rep(i,u,x)Rep(j,v,y)if(a[i][j])
            ans+=sum[i][j]-sum[i][v-1]-sum[u-1][j]+sum[u-1][v-1];
        printf("%lld\n",ans);
    }
    return 0;
}

