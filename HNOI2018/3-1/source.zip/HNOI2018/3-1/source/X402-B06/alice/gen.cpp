#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("alice.in","w",stdout);
	#endif
}
static int n=70000,m=70000,q=350000;
typedef pair<int,int>Pr;
static map<Pr,bool>G;
int main(void){
	file();
    srand(time(NULL));
	cout<<n<<' '<<m<<' '<<q<<endl;
    static int x,y;
    Rep(i,1,q)
    {
        while(1)
        {
            x=rand()%n+1;y=rand()%m+1;
            if(!G[Pr(x,y)])
            {
                G[Pr(x,y)]=true;break;
            }
        }
        printf("%d %d\n",x,y);
    }
    return 0;
}

