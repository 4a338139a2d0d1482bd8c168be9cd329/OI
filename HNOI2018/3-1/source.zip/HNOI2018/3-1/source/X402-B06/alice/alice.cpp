#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	#endif
}
const int MAXN=7e4+7;
static int n,m,q;
static struct node
{
    int x,y;
    friend bool operator<(node a,node b)
    {return a.x^b.x?a.x<b.x:a.y<b.y;}
}Q[MAXN<<4];
inline void init()
{
    read(n);read(m);read(q);
    Rep(i,1,q)read(Q[i].x),read(Q[i].y);
    sort(Q+1,Q+q+1);
}
static int p[MAXN<<2],d[MAXN<<2];
static long long ans;
inline void pushup(int h)
{
    if(p[h<<1]>p[h<<1|1])p[h]=p[h<<1],d[h]=d[h<<1];
    else p[h]=p[h<<1|1],d[h]=d[h<<1|1];
}
void insert(int h,int l,int r,int x,int y)
{
    if(l==r){p[h]=y;d[h]=l;return;}
    static int mid;mid=(l+r)>>1;
    if(x<=mid)insert(h<<1,l,mid,x,y);
    else insert(h<<1|1,mid+1,r,x,y);
    pushup(h);
}
void query(int h,int l,int r,int x,int y,int &D,int &pos)
{
    if(l>=x&&r<=y){D=p[h],pos=d[h];return;}
    int mid=(l+r)>>1;
    if(x<=mid&&p[h<<1]>D)query(h<<1,l,mid,x,y,D,pos);
    if(y>mid&&p[h<<1|1]>D)query(h<<1|1,mid+1,r,x,y,D,pos);
}
inline void solve()
{
    static int l,r,h,ps,lash,lasps,lh,x,y;
    Rep(i,1,q)
    {
        x=Q[i].x;y=Q[i].y;
        l=1;r=m;
        lh=-1;
        while(r>=l)
        {
            do
            {
                ps=h=0;
                query(1,1,m,l,r,h,ps);
                if(h<x)break;
                if(ps<=y)l=ps+1;
                if(ps>=y)r=ps-1;
            }while(r>=l);
            if(r<l)break;
            if(lh>0)
                ans-=1ll*(n-x+1)*(x-lh)
                *(r-y+1)*(y-l+1);
            ans+=1ll*(n-x+1)*(x-h)
                *(r-y+1)*(y-l+1);
            lh=h;
            if(ps<=y)l=ps+1;if(ps>=y)r=ps-1;
            if(!h)break;
            if(h&&r>=l)do
            {
                lasps=lash=0;
                query(1,1,m,l,r,lash,lasps);
                if(lash!=h)break;
                if(lasps<=y)l=lasps+1;
                if(lasps>=y)r=lasps-1;
            }while(r>=l);
        }
        insert(1,1,m,y,x);
    }
    printf("%lld\n",ans);
}
int main(void){
	file();
    init();
    solve();
    cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}

