#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100;

int n;
int st[N + 5], nxt[N + 5], to[N + 5], e = 1;

void addedge(int u, int v) {
    to[++ e] = v; nxt[e] = st[u]; st[u] = e;
    to[++ e] = u; nxt[e] = st[v]; st[v] = e;
}

int a[N + 5];
bool vis[N + 5], mark[N + 5];

int dfs_count(int u, int f = -1) {
    int ret = 1;
    for (int i = st[u]; i; i = nxt[i]) if(!mark[i]) {
        if(to[i] == f) continue;
        ret += dfs_count(to[i], u);
    }
    return ret;
}

int calc() {
    int res = 0;
    memset(mark, 0, sizeof mark);
    for (int i = 0; i < n; ++ i) {
        res += dfs_count(a[i]); 
        for (int j = st[a[i]]; j; j = nxt[j]) mark[j] = mark[j ^ 1] = true;
    }
    return res;
}

double ans = 0;
void dfs(int u) {
    if (u == n) {
        ans += calc();
        return;
    }

    for (int i = 0; i < n; ++i) if(!vis[i]) {
        vis[i] = true; a[u] = i;
        dfs(u + 1);
        vis[i] = false;
    }
}

int main() {
    freopen("good.in", "r", stdin);
    freopen("good.out", "w", stdout);

    read(n);
    for (int i = 1; i < n; ++ i) {
        static int u, v;
        read(u), read(v); addedge(u, v);
    }

    dfs(0);
    for (int i = 1; i <= n; ++ i) ans = ans / i;
    printf("%.4lf\n", ans); 

    return 0;
}
