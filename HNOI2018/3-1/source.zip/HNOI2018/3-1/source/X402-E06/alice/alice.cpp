#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 2000;

int n, m, q;
vector<int> P[N + 5];

inline int max(int a, int b) { return a > b ? a : b; } 
inline int min(int a, int b) { return a < b ? a : b; } 

namespace SEG {
    const int SZ = N << 2;

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    ll sum[SZ + 5];
    bool tag[SZ + 5];
    int mx[SZ + 5], mn[SZ + 5];

    inline ll f(int x) { return 1ll * x * (x + 1) / 2; }

    inline void clear() { tag[1] = 1, sum[1] = f(n); }

    void push_down(int u, int l, int r) {
        if(tag[u]) {
            tag[lc] = tag[rc] = 1;
            sum[lc] = f(mid-l+1), sum[rc] = f(r-mid);

            mx[lc] = l - 1; mn[lc] = oo; 
            mx[rc] = -oo; mn[rc] = r + 1;

            tag[u] = 0;
        }
    }

    void modify(int u, int l, int r, int p) {
        if(l == r) {
            sum[u] = 0;
            mx[u] = mn[u] = l;
            return;
        }
        push_down(u, l, r);

        if(p <= mid) 
            modify(lc, l, mid, p);
        else 
            modify(rc, mid+1, r, p);

        mx[u] = max(mx[lc], mx[rc]);
        mn[u] = min(mn[lc], mn[rc]);
        sum[u] = sum[lc] + sum[rc] + ll(mn[rc]-mid-1) * (mid-mx[lc]);
    }
}

int main() {
    freopen("alice.in", "r", stdin);
    freopen("alice.out", "w", stdout);

    read(n), read(m), read(q);
    for(int i = 0; i < q; ++i) {
        static int x, y;
        read(x), read(y), P[x].pb(y);
    }

    for(int i = 1; i <= n; ++i) {
        P[i].pb(0); 
        std::sort(P[i].begin(), P[i].end());
    }

    ll ans = 0;
    vector<int> pos[N + 5];
    for(int r = 1; r <= m; ++r) {

        for(int i = 1; i <= n; ++i) 
            pos[*(-- std::upper_bound(P[i].begin(), P[i].end(), r))].pb(i);

        SEG::clear();

        int cur = r;
        for(int i = r; i >= 0; -- i) if(pos[i].size()) {

            ans += 1ll * SEG::sum[1] * (cur - i);
            cur = i;

            for(int k = 0; k < (int) pos[i].size(); ++k) SEG::modify(1, 1, n, pos[i][k]);
            pos[i].clear();
        }
    }

    ans = 1ll * n * (n + 1) / 2 * m * (m + 1) / 2 - ans;
    printf("%lld\n", ans);

    return 0;
}
