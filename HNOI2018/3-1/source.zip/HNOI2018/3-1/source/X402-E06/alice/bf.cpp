#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100;

int n, m, q;
int sum[N + 5][N + 5];

int main() {
    freopen("alice.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n), read(m), read(q);
    for (int i = 0; i < q; ++i) {
        static int x, y;
        read(x), read(y); sum[x][y] = 1;
    }

    for (int i = 1; i <= n; ++ i) {
        for (int j = 1; j <= m; ++ j) sum[i][j] += sum[i][j-1];
        for (int j = 1; j <= m; ++ j) sum[i][j] += sum[i-1][j];
    }

    int ans = 0, tot = 0;
    for (int i = 1; i <= n; ++ i) {
        for (int j = i; j <= n; ++ j) {
            for (int k = 1; k <= m; ++ k) {
                for (int l = k; l <= m; ++ l) {
                    ans += (sum[j][l] - sum[i-1][l] - sum[j][k-1] + sum[i-1][k-1] > 0);
                    ++ tot;
                }
            }
        }
    }
    printf("%d\n", ans);

    return 0;
}
