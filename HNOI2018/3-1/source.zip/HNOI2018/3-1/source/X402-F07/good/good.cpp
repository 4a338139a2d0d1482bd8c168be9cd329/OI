#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=35005;
int n,all;
vector<int>E[maxn];
lf dp[1<<20];
int dfs(int u,int s,int fa){
	if(!(s&(1<<u)))return 0;
	int res=1<<u;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(v!=fa)res|=dfs(v,s,u);
	}return res;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
#endif
	n=read(),all=(1<<n)-1;
	REP(i,1,n-1){
		int u=read(),v=read();
		E[u].pb(v),E[v].pb(u);
	}
	REP(i,0,n-1)dp[1<<i]=1;
	REP(i,3,all){
		int tmp=0;
		REP(j,0,n-1)
			if(i&(1<<j)){
				tmp=dfs(j,i,n);
				break;
			}
		if(tmp!=i)continue;
		int sz=__builtin_popcount(i);
		dp[i]=sz;
		REP(j,0,n-1)
			if(i&(1<<j))
				REP(k,0,E[j].size()-1){
					int v=E[j][k],tmp=dfs(v,i,j);
					dp[i]+=dp[tmp]/sz;
				}
	}
	printf("%.4lf\n",dp[all]);
	return 0;
}
