#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
#define mp make_pair
map<pair<int,int>,int>ma;
const int maxn=2010;
long long ans;
int n,m,q;
int gra[maxn][maxn];
int main(){
    freopen("alice.in","r",stdin);
    freopen("alice.out","w",stdout);
    read(n);read(m);read(q);
    for(register int i=1;i<=q;++i){
        int x,y;
        read(x);read(y);
        gra[x][y]=1;
    }
    for(register int i=1;i<=n;++i){
        for(register int j=1;j<=m;++j){
            gra[i][j]+=gra[i-1][j]+gra[i][j-1]-gra[i-1][j-1];
        }
    }
    for(register int xx1=1;xx1<=n;++xx1){
        for(register int yy1=1;yy1<=m;++yy1){
            for(register int xx2=xx1;xx2<=n;++xx2){
                for(register int yy2=yy1;yy2<=m;++yy2){
                    if((gra[xx2][yy2]-gra[xx1-1][yy2]-gra[xx2][yy1-1]+gra[xx1-1][yy1-1])>0)ans++;
                }
            }
        }
    }
    printf("%lld\n",ans);
    return 0;
}
