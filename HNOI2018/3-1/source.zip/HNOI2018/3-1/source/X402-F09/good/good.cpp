#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
const int maxn=105;
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
int head[maxn],sum,tot,n,fa[maxn],vis[maxn],num[maxn],Vis[maxn];
double ans,D;
struct edge{
    int to,next;
}e[maxn<<1];
inline void add(int u,int v){
	e[++tot].to=v;
    e[tot].next=head[u];
    head[u]=tot;
}
inline int solve(int rt){
	int num=0;
    bool viss[maxn];
	memset(viss,0,sizeof(viss));
	queue<int>qu;
	qu.push(rt);
    viss[rt]=1;
	while(!qu.empty()){
		int u=qu.front();
        qu.pop();
		num++;
		for(register int i=head[u];i;i=e[i].next){
			if(vis[e[i].to])continue;
			if(!viss[e[i].to]){
				viss[e[i].to]=1;
				qu.push(e[i].to);
			}
		}
	}
	return num;
}
inline void dfs(int rt,int tot){
	if(rt==n+1){
		sum+=tot;
		tot=0;
		return;				
	}
	for(register int i=1;i<=n;++i){
		if(vis[i])continue;
		vis[i]=1;
		dfs(rt+1,tot+solve(i));
		vis[i]=0;
	}
}
int main(){
	freopen("good.in","r",stdin);
    freopen("good.out","w",stdout);
	read(n);
	for(register int i=1;i<=n-1;++i){
		int u,v;
		read(u);u++;
        read(v);v++;
		add(u,v);add(v,u);
	}
	dfs(1,0);
	double ans,tmp=1;
	for(register int i=2;i<=n;++i){
        tmp*=(i*1.0);
    }
	ans=((double)sum)/tmp;
	printf("%.4lf\n",ans);
	return 0;
}
