#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int dp[2010][2010],a[2010][2010],f[1010][1010],g[1010][1010],n,m;
int main(){
	int i,j,k,q,x,y,sum=0;
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(i=1;i<=q;i++){
	    scanf("%d%d",&x,&y);
	    a[x][y]=1;
	}
	for(i=1;i<=n;i++)
	    for(j=1;j<=n;j++)
	        f[i][j]=f[i][j-1]+a[i][j];
	for(i=1;i<=n;i++)
	    for(j=1;j<=n;j++)
	        f[i][j]=f[i][j]+f[i-1][j];
	for(i=1;i<=n;i++)
	     for(j=1;j<=m;j++)
	         for(k=i;k<=n;k++){
	         	int r=j,l=m,ans=1000000100;
	         	while(r<=l){
	         		int mid=(r+l)/2;
	         		if(f[k][mid]-f[k][j-1]-f[i-1][mid]+f[i-1][j-1]>=1){ans=min(mid,ans);l=mid-1;}
	         		else r=mid+1;
	         	}
	         	if(ans<1000000100)
	         	sum+=m-ans+1;
	         }
    printf("%d\n",sum);
	return 0;
}
/*
5 5 4
0 1 0 0 0 
0 0 1 0 0
0 0 0 0 1
1 0 0 0 0
0 0 0 0 0
*/
