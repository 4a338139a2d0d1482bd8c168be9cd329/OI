#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int f[1010][1010];
int main(){
	int i,j,k,m,n,a,b,c,d,x1,y1,x2,y2;
	freopen("night.in","r",stdin);
	freopen("night.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(i=1;i<=n;i++)
	    for(j=1;j<=m;j++)
	        scanf("%d",&f[i][j]);
	for(i=1;i<=k;i++){
	    scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	    int ans=0;
	    for(a=x1;a<=x2;a++)
	        for(b=y1;b<=y2;b++)
	           for(c=a;c<=x2;c++)
	               for(d=b;d<=y2;d++)
	                   if(f[a][b]>f[c][d])ans++;
	    printf("%d\n",ans);
	}
	return 0;
}
/*
3 5 3
1 2 3 4 5
9 9 9 9 9
1 4 3 5 2
1 1 2 5
3 1 3 5
2 1 3 5
*/
