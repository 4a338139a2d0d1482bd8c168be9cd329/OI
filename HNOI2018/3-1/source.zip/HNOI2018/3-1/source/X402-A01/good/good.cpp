#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int q[10000010],v[100010],v1[1000010],a[1010][1010],n;
double dfs(int x,double y){
	int r=0,l=1,i,j;
	q[0]=x;
	for(i=0;i<=n;i++)v1[i]=0;
	v1[x]=1;
	while(r<l){
	    int x=q[r];
		r++;
		for(i=0;i<=n;i++)
		    if(a[x][i] && !v[i] && !v1[i]){
			     v1[i]=1;
			     q[l]=i;
			     l++;
			 }
	}
	int p=l;
	double ans=p*y;
    for(i=0;i<=n;i++)
	    if(!v[i]){
	    	v[i]=1;
	    	for(j=0;j<=n;j++)
	    	    if(a[i][j] &&!v[j])
                   ans+=dfs(j,y*1.0/l);
            v[i]=0;
		}
	return ans;
}
int main(){
	int i,j,k,m,x,y;
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<n;i++){
	    scanf("%d%d",&x,&y);
	    a[x][y]=1;
	    a[y][x]=1;
	}
	printf("%.4lf\n",dfs(0,1)); 
	return 0;
}

