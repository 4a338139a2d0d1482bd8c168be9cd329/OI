#include<bits/stdc++.h>
using namespace std;
#define ll long long
int ans,n,m,q,G[20][20];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	read(n);read(m);read(q);
	for(register int i=1;i<=q;++i)
	{
		int x,y;
		read(x);read(y);
		G[x][y]++;
	}
	for(register int i=1;i<=n;++i)
		for(register int j=1;j<=m;++j)G[i][j]=G[i][j]+G[i-1][j]+G[i][j-1]-G[i-1][j-1];
	for(register int i=1;i<=n;++i)
		for(register int j=1;j<=m;++j)
			for(register int k=i;k<=n;++k)
				for(register int p=j;p<=m;++p)
					if(G[k][p]-G[k][j-1]-G[i-1][p]+G[i-1][j-1]>=1)ans++;
	write(ans,'\n');
	return 0;
}
