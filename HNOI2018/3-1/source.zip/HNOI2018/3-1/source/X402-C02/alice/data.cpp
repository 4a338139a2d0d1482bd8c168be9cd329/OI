#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("alice.in","w",stdout);
	srand(time(0));
	int n=100,m=100,q=n*m;
	printf("%d %d %d\n",n,m,q);
	for(register int i=1;i<=n;++i)
		for(register int j=1;j<=m;++j)printf("%d %d\n",i,j);
	return 0;
}
