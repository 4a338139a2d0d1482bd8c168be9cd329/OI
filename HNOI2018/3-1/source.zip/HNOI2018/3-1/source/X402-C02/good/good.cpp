#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=2000+10;
int n,dep[MAXN],beg[MAXN],nex[MAXN<<1],to[MAXN<<1],e;
double ans;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline void insert(int x,int y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
inline void dfs(int x,int deep,int f)
{
	dep[x]=deep;
	for(register int i=beg[x];i;i=nex[i])
		if(to[i]==f)continue;
		else dfs(to[i],deep+1,x);
}
inline double E(int x)
{
	double res=0;
	dfs(x,1,0);
	for(register int i=1;i<=n;++i)res+=((double)(dep[i]-1)/(double)(dep[i]));
	return res;
}
int main()
{
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	read(n);
	for(register int i=1;i<n;++i)
	{
		int u,v;
		read(u);read(v);
		u++;v++;
		insert(u,v);
		insert(v,u);
	}
	for(register int i=1;i<=n;++i)ans+=E(i);
	ans=(double)n*n-ans;
	printf("%.4f\n",ans);
	return 0;
}
