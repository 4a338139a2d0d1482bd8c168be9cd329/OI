#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, Begin[maxn], to[maxn], e, Next[maxn], vis[maxn], dfn[maxn], dfs_clock, tid[maxn], Size[maxn];

double dp[maxn];

void add(int x,int y) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read();
	For(i, 2, n) {
		int x = read() + 1, y = read() + 1;
		add(x, y), add(y, x);
	}
}

void dfs(int h,int father) {
	dfn[++dfs_clock] = h; tid[h] = dfs_clock;
	Size[h] = 1;

	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father) continue;

		dfs(v, h);
		Size[h] += Size[v];
	}
}

double Ans;

void dfs_calc(int now,double poss) {
	if(vis[tid[now]] != 0){
		return;
	}

	Ans += poss;
	int cnt = 0;
	For(i, 1, n) if(!vis[i]) ++ cnt;

	For(i, 1, n) {
		if(!vis[i]) {
			int ls = dfn[i];
			For(j, i, i + Size[ls] - 1) {
				++ vis[j];
			}

			dfs_calc(now, poss / (1.0 * cnt) );

			For(j, i, i + Size[ls] - 1) {
				-- vis[j];
			}
		}
	}
}

void solve_bf(){
	For(i, 1, n) {
		For(j, 1, n) vis[j] = 0;
		dfs_clock = 0;
		dfs(i, -1);
		dfs_calc(i, 1.0);
	}

	printf("%.4f\n", Ans);
}

int main(){

	freopen("good.in", "r", stdin);
	freopen("good.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
