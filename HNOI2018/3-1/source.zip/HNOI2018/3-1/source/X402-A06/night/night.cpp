#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m, a[2010][2010], q;

int main(){

	freopen("night.in", "r", stdin);
	freopen("night.out", "w", stdout);

	n = read(), m = read(), q = read();
	For(i, 1, n) For(j, 1, m) a[i][j] = read();
	while(q --){
		ll Ans = 0;
		int u = read(), v = read(), x = read(), y = read();
		For(i, u, x) {
			For(j, v, y){
				For(o, i, x){
					For(p, j, y){
						if(i == o && j == p) continue;
						if(a[i][j] > a[o][p]) ++ Ans;
					}
				}
			}
		}
		printf("%lld\n", Ans);
	}

	return 0;
}
