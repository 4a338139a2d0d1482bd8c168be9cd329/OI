#include<bits/stdc++.h>

using namespace std;

int vis[2010][2010];

int main(){
	
	freopen("alice.in", "w", stdout);
	
	srand(time(NULL));

	int n = 2000, m = 2000, q = 10000;
	printf("%d %d %d\n", n, m, q);

	for(int i = 1;i <= q; ++i){
		while(1){
			int x = rand() % n + 1, y = rand() % m + 1;
			if(vis[x][y]) continue;
			else{
				vis[x][y] = 1;
				printf("%d %d\n", x, y);
				break;
			}
		}
	}

	return 0;
}
