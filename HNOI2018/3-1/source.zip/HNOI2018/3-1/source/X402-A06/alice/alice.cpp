#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m, q;

bool vis[2010][2010], a[2010][2010];

void Get(){
	n = read(), m = read(), q = read();
	For(i, 1, q) {
		int x = read(), y = read();
		vis[x][y] = 1;
	}
}

void solve_bf(){
	int Ans = 0;
	For(i, 1, n) {
		For(j, 1, m) {
			rep(u, i, 1) {
				rep(v, j, 1) {
					a[u][v] = vis[u][v];
					if(u + 1 <= i) a[u][v] |= a[u+1][v];
					if(v + 1 <= j) a[u][v] |= a[u][v+1];
					if(a[u][v] == 1) ++ Ans;
				}
			}

			rep(u, i, 1) {
				rep(v, j, 1) {
					a[u][v] = 0;
				}
			}
		}
	}

	printf("%d\n", Ans);
}

int pre[2010][2010];

void pre_work(){
	For(i, 1, n) {
		pre[i][m+1] = m+1;
		rep(j, m, 1) {
			if(vis[i][j]) pre[i][j] = j;
			else pre[i][j] = pre[i][j+1];
		}
	}
}

int tree[maxn * 4], tag[maxn * 4], sum[maxn * 4];

void pushdown(int h,int l,int r){
	if(tag[h] != 0){
		if(l == r){
			tag[h] = 0;	
		}
		else{
			tree[h<<1] = 0, tree[h<<1|1] = 0;
			sum[h<<1] = 0, sum[h<<1|1] = 0;
			tag[h<<1] = 1, tag[h<<1|1] = 1;
			tag[h] = 0;
		}
	}

	if(sum[h] != 0){
		tree[h] += (r - l + 1) * sum[h];
		if(l == r){
			sum[h] = 0;
			return;
		}
		sum[h<<1] += sum[h], sum[h<<1|1] += sum[h];
		sum[h] = 0;
	}
}

void pushup(int h,int l,int r){
	int mid = l+r >> 1;

	if(tag[h<<1] || sum[h<<1]) pushdown(h<<1, l, mid);
	if(tag[h<<1|1] || sum[h<<1|1]) pushdown(h<<1|1, mid+1, r);

	tree[h] = tree[h<<1] + tree[h<<1|1];
}

void updaval(int h,int l,int r,int s,int e){
	pushdown(h, l, r);
	if(l == s && r == e) {
		tag[h] = 1;
		tree[h] = 0, sum[h] = 0;
		pushdown(h, l, r);
		return;
	}

	int mid = l+r >> 1;
	if(e <= mid) updaval(h<<1, l, mid, s, e);
	else if(s > mid) updaval(h<<1|1, mid+1, r, s, e);
	else {
		updaval(h<<1, l, mid, s, mid), updaval(h<<1|1, mid+1, r, mid+1, e);
	}

	pushup(h, l, r);
}

void updada(int h,int l,int r,int s,int e,int val){
	pushdown(h, l, r);
	if(l == s && r == e) {
		sum[h] += val;
		pushdown(h, l, r);
		return;
	}

	int mid = l + r >> 1;
	if(e <= mid) updada(h<<1, l, mid, s, e, val);
	else if(s > mid) updada(h<<1|1, mid+1, r, s, e, val);
	else updada(h<<1, l, mid, s, mid, val), updada(h<<1|1, mid+1, r, mid+1, e, val);

	pushup(h, l, r);
}

int query(int h,int l,int r,int s,int e){
	pushdown(h, l, r);
	if(l == s && r == e){
		return tree[h];
	}

	int mid = l+r >> 1, ans = 0;
	if(e <= mid) ans = query(h<<1, l, mid, s, e);
	else if(s > mid) ans = query(h<<1|1, mid+1, r, s, e);
	else ans = query(h<<1, l, mid, s, mid) + query(h<<1|1, mid+1, r, mid+1, e);

	pushup(h, l, r);
	return ans;
}

void solve(){
	pre_work();

	ll Ans = 0;
	For(j, 1, m) {
		int Max = 0;
		updaval(1, 1, n, 1, n);
		rep(i, n, 1) {
			if(vis[i][j]) {
				if(Max != 0) updaval(1, 1, n, 1, Max);
				Max = 0;
			}
			else{
				if(pre[i][j] - j < Max) {
					updaval(1, 1, n, pre[i][j] - j + 1, Max);
					Max = pre[i][j] - j;
				}
				else if(pre[i][j] - j > Max){
					Max = pre[i][j] - j;
				}

				updada(1, 1, n, 1, Max, 1);
				Ans += query(1, 1, n, 1, Max);
			}
		}
	}

	ll ans = 0;
	For(i, 1, n) {
		For(j, 1, m) {
			ans += 1ll * i * j;
		}
	}

	printf("%lld\n", ans - Ans);
}

int main(){

	freopen("alice.in", "r", stdin);
	freopen("alice.out", "w", stdout);

	Get();
	solve();

	return 0;
}
