#include<cstdio>
#include<algorithm>
using namespace std;

int a[2012][2012],n,m,q,ans=0;

int main(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for (int i=1;i<=q;i++)
	{
	  int x,y;
	  scanf("%d%d",&x,&y);
	  a[x][y]=1;
	}
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=m;j++)
	  	a[i][j]=a[i-1][j]+a[i][j-1]-a[i-1][j-1]+a[i][j];
	int num=0;
	for (int i1=1;i1<=n;i1++)
	  for (int j1=1;j1<=m;j1++)
	    for (int i2=i1;i2<=n;i2++)
	      for (int j2=j1;j2<=m;j2++)
			if (a[i2][j2]-a[i2][j1-1]-a[i1-1][j2]+a[i1-1][j1-1]>0)
	      	  ans++;
	printf("%d\n",ans);
	return 0;
}
