#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;

vector<int> son[1012];
int n,m,tot,f[1012],vis[1012],in[1012];
double ans=0;



void dfs(int x,int fa){
	tot++;
	vis[x]=1;
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (!f[s]||s==fa)
	    continue;
	  dfs(s,x);
	}
}

void dfd(int x,int fa){
	in[x]=1;
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (!f[s]||s==fa)
	    continue;
	  dfd(s,x);
	}
}

int check(){
	for (int i=1;i<=n;i++)
	  in[i]=0;
	for (int i=1;i<=n;i++)
	{
	  if (f[i]&&in[i])
	    return 0;
	  if (f[i]&&!in[i])
	    dfd(i,0);
	}
	return 1;
}
	

int size(int x){
	tot=0;
	for (int i=1;i<=n;i++)
	  vis[i]=0;
	dfs(x,0);
	return tot;
}

void doing(int pos,int x,int num,double p){
	int siz=size(x);
	if (siz==1)
	{
	  return ;
	}
	for (int i=1;i<=n;i++)
	  if (vis[i]&&f[i])
	  {
		f[i]=0;
		if (check()==1)
		{
		  ans+=(num+siz+siz-1)*p;
		  f[i]=1;
		  continue;
		}
	  	for (int j=0;j<son[i].size();i++)
	  	{
	  	  int s=son[i][j];
	  	  if (f[s])
	  	    doing(pos+1,s,num+siz,p/siz);
	  	}
	  	f[i]=1;
	  }
}

int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n-1;i++)
	{
	  int a,b;
	  scanf("%d%d",&a,&b);
	  a++,b++;
	  son[a].push_back(b);
	  son[b].push_back(a);
	}
	for (int i=1;i<=n;i++)
	  f[i]=1;
	doing(0,1,0,1);
	printf("%.4lf\n",ans);
	return 0;
}
