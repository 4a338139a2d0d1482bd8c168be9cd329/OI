//2018-03-01
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register int i=a;i<=b;i++)
#define Forr(i,a,b) for(register int i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
}
inline void read(int &x)
{
	int p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}
#define N 110
int n,m,q,ans;
int t[N][N],sum[N][N];
int main()
{
//	File();
	read(n),read(m),read(q);
	For(i,1,q)
	{
		int x,y;
		read(x),read(y);
		t[x][y]=1;
	}
	sum[1][1]=t[1][1];
	For(i,1,n)For(j,1,m)sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+t[i][j];
	For(i,0,n)For(j,0,m)For(k,i,n)For(l,j,m)if((sum[k][l]-sum[i][l]-sum[k][j]+sum[i][j])>=1)ans++;
	printf("%d\n",ans);
	return 0;
}
