#include<bits/stdc++.h>
#define For(i,a,b) for(register int i=a;i<=b;++i)
using namespace std;
const int maxn=2e3+10;
int a[maxn][maxn],s[maxn][maxn];
long long ans;
inline void file(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
}

inline void read(int &x){
	int f=1;x=0;char c=getchar();
	while(c>'9'||c<'0'){
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0')
		x=x*10+c-'0',c=getchar();
	x*=f;
}

int main(){
	file();
	int x,y,n,m,q;
	read(n);read(m);read(q);
	for(int i=1;i<=q;++i){
		read(x);read(y);
		a[x][y]=1;
	}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
	for(int x1=1;x1<=n;++x1)
		for(int y1=1;y1<=m;++y1)
			for(int x2=x1;x2<=n;++x2)
				for(int y2=y1;y2<=m;++y2)
					if(s[x2][y2]-s[x1-1][y2]-s[x2][y1-1]+s[x1-1][y1-1])
						++ans;
	cout<<ans;
	return 0;
}
