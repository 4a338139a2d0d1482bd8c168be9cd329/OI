#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 2010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int vis[N][N];
int main(){
	freopen("alice.in","r",stdin);
	freopen("BF.out","w",stdout);
	int n, m, q;
	read(n), read(m), read(q);
	For(i, 1, q){
		int x, y;
		read(x), read(y);
		vis[x][y] = 1;
	}
	For(i, 1, n)
		For(j, 1, m)
			vis[i][j] = vis[i-1][j] + vis[i][j-1] - vis[i-1][j-1] + vis[i][j];
	ll ans = 0;
	For(i, 1, n)
		For(j, 1, m)
			For(k, i, n)
				For(l, j, m)
					if(vis[k][l] - vis[i-1][l] - vis[k][j-1] + vis[i-1][j-1] >= 1)ans++;
	printf("%lld\n",ans);
	return 0;
}
