#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 2010;


int main(){
	srand(time(0));
	int n = rand()%1000 + 1001, m = rand()%1000 + 1001, q = rand() %(min(n*m,350000)) + 1;
	freopen("alice.in","w",stdout);
	printf("%d %d %d\n", n, m, q);
	For(i, 1, q)
		printf("%d %d\n",rand()%n+1, rand()%m+1);
	return 0;
}
