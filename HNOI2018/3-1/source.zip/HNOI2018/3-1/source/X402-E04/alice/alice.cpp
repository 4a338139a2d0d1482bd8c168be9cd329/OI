#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 2010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
}
int n, m, Q, vis[N][N], p[N][N], q[N][N];
ll ans = 0;
void init(){
	read(n), read(m), read(Q);
	For(i, 1, Q){
		int x, y;
		read(x), read(y);
		vis[x][y] = 1;
	}
	For(i, 1, m)p[0][i] = i;
	For(i, 1, n){
		For(j, 1, m){
			p[i][j] = p[i][j - 1];
			if(vis[i][j] == 1)p[i][j] = j;
			int s = i - 1;
			while(p[s][j] < p[i][j]) s = q[s][j];
			q[i][j] = s;
		}
	}
	ans = 1ll * n * (n + 1) / 2 * (m + 1) * m / 2ll;
}
ll t[N][N];
void solve(){
	For(i, 1, n){
		For(j, 1, m){
			int s = q[i][j];
			t[i][j] = t[s][j] + (i - s) * (j - p[i][j]);
			if(vis[i][j])t[i][j] = 0;
			ans -= t[i][j];
		}
	}
	printf("%lld\n", ans);
}
int main(){
	file();
	init();
	solve();
	double T = clock() *1.0 /CLOCKS_PER_SEC;
	cerr<<T<<endl;
	assert(T < 1.0);
	return 0;
}
