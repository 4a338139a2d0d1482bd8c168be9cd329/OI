#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
int mp[3020][3020],l[3020][3020],r[3020][3020];
ll ans;
int n,m,q;
int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%d",&q);
	ll x,y;
	for (int i=1;i<=q;++i)
	{
		scanf("%lld%lld",&x,&y);
		mp[x][y]=i;
	}
	for (int i=1;i<=n;++i)
	{
		l[i][1]=1;
		for (int j=2;j<=m;++j)
		{
			if (mp[i][j-1]) l[i][j]=j;
			else l[i][j]=l[i][j-1];
		}
		r[i][m]=m;
		for (int j=m-1;j>=1;--j)
		{
			if (mp[i][j+1]) r[i][j]=j;
			else r[i][j]=r[i][j+1];
		}
	}
/*	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
			printf("%d ",l[i][j]);
		printf("\n");
	}
	printf("\n");
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
			printf("%d ",r[i][j]);
		printf("\n");
	}*/
	for (int i=1;i<=n;++i)
		for (int j=1;j<=m;++j)
		if (mp[i][j])
		{
			ll doe=n-i+1;
			x=l[i][j]; y=m;
			ans+=(doe*(y-j+1)*(j-x+1));
			int k=i-1;
			while (mp[k][j]==0 && k>=1)
			{
				x=max(x,(ll)l[k][j]);
				y=min(y,(ll)r[k][j]);
				ans+=( doe*(y-j+1)*(j-x+1) );
				--k;
			}
		}
	printf("%lld\n",ans);
	return 0;
}
