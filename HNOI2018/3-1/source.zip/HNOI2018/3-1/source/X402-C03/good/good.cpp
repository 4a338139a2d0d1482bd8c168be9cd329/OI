#include<bits/stdc++.h>
using namespace std;

const int maxn=3.5e4+10;
int n;
vector<int> g[maxn];
bool vis[maxn];
double ans;

int get(int pos,int fa){
	int now=1<<pos;
	for(int i=0;i<g[pos].size();++i)
		if(g[pos][i]!=fa&&!vis[g[pos][i]])
			now|=get(g[pos][i],pos);
	return now;
}
void dfs(int now,double p){
	ans+=__builtin_popcount(now)*p;
	for(int i=0;i<n;++i){
		if(now>>i&1^1)
			continue;
		vis[i]=true;
		for(int j=0;j<g[i].size();++j)
			if(!vis[g[i][j]])
				dfs(get(g[i][j],-1),p/__builtin_popcount(now));
		vis[i]=false;
	}
}

int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	scanf("%d",&n);
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs((1<<n)-1,1);
	printf("%.4f\n",ans);
	return 0;
}
