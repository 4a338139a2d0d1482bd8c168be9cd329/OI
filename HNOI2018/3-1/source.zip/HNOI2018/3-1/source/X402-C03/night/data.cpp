#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("night.in","w",stdout);
	srand(time(0)+clock()*clock()*clock());
	int n=rand()%1000+1,m=rand()%5+1,q=100;
	printf("%d %d %d\n",n,m,q);
	for(int i=1;i<=n;++i,puts(""))
		for(int j=1;j<=m;++j)
			printf("%d ",rand());
	while(q--){
		int a=rand()%n+1,b=rand()%n+1,c=rand()%m+1,d=rand()%m+1;
		a=1;
		printf("%d %d %d %d\n",min(a,b),min(c,d),max(a,b),max(c,d));
	}
	return 0;
}
