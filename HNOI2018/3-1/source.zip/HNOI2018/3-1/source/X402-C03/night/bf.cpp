#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}

const int maxn=5e5+10;
int n,m,q,*a[maxn];
int val[maxn*2],cnt;
int bit[maxn*2];

inline void add(int x,int val){
	while(x<=cnt){
		bit[x]+=val;
		x+=x&-x;
	}
}
inline int sum(int x){
	int res=0;
	while(x){
		res+=bit[x];
		x-=x&-x;
	}
	return res;
}
bool flag;

int main(){
	freopen("night10.in","r",stdin);
	freopen("night.txt","w",stdout);
	n=read();m=read();q=read();
	if(n>m){flag=true;swap(n,m);}
	for(int i=1;i<=n;++i)
		a[i]=new int[m+2]();
	if(flag)
		for(int j=1;j<=m;++j)
			for(int i=1;i<=n;++i)
				val[cnt++]=a[i][j]=read();
	else
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
				val[cnt++]=a[i][j]=read();
	sort(val,val+cnt);
	cnt=unique(val,val+cnt)-val;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			a[i][j]=cnt-(lower_bound(val,val+cnt,a[i][j])-val);
	while(q--){
		int x1=read(),y1=read(),x2=read(),y2=read();
		if(flag)swap(x1,y1),swap(x2,y2);
		long long ans=0;
		for(int i=x1;i<=x2;++i)
			for(int j=i;j<=x2;++j){
				for(int k=y1;k<=y2;++k){
					add(a[i][k],1);
					ans+=sum(a[j][k]-1);
				}
				for(int k=y1;k<=y2;++k)
					add(a[i][k],-1);
			}
		printf("%lld\n",ans);
		cerr<<q<<endl;
	}
	return 0;
}
