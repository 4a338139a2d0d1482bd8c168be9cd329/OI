#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}

const int maxn=5e5+10,maxq=1e6+10;
int n,m,q,*a[maxn];
int val[maxn*2],cnt;

int bit[maxn*2];
inline void add(int x,int val){
	while(x<=cnt){
		bit[x]+=val;
		x+=x&-x;
	}
}
inline int sum(int x){
	int res=0;
	while(x){
		res+=bit[x];
		x-=x&-x;
	}
	return res;
}
int bitt[maxn*2];
inline void addd(int x,int val){
	while(x<=cnt){
		bitt[x]+=val;
		x+=x&-x;
	}
}
inline int summ(int x){
	int res=0;
	while(x){
		res+=bitt[x];
		x-=x&-x;
	}
	return res;
}

typedef long long ll;
inline ll calc(ll fir,ll d,ll n){
	return fir*n+n*(n-1)/2*d;
}
ll res[maxq];
struct question{
	int x1,y1,x2,y2,id;
	void get(int a){
		x1=read();y1=read();x2=read();y2=read();
		id=a;
	}
	bool operator <(question o)const{
		return x2<o.x2;
	}
}qq[maxq];
int sqrtm;
bool cmp(question a,question b){
	int aa=a.y1/sqrtm,bb=b.y1/sqrtm;
	if(aa==bb)
		return aa&1?a.y2<b.y2:a.y2>b.y2;
	return aa<bb;
}
bool cmpp(question a,question b){
	int aa=a.x1/sqrtm,bb=b.x1/sqrtm;
	if(aa==bb)
		return aa&1?a.x2<b.x2:a.x2>b.x2;
	return aa<bb;
}

int main(){
	freopen("night.in","r",stdin);
	freopen("night.out","w",stdout);
	n=read();m=read();q=read();
	for(int i=1;i<=n;++i){
		a[i]=new int[m+2]();
		for(int j=1;j<=m;++j)
			val[cnt++]=a[i][j]=read();
	}
	sort(val,val+cnt);
	cnt=unique(val,val+cnt)-val;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			a[i][j]=cnt-(lower_bound(val,val+cnt,a[i][j])-val);
	int type=3;
	if(type<=5){
		if(n>m)
			goto rev;
		sqrtm=sqrt(m);
		for(int i=1;i<=q;++i)
			qq[i].get(i);
		sort(qq+1,qq+q+1,cmp);
		for(int i=1;i<=n;++i)
			for(int j=i;j<=n;++j){
				cerr<<i<<' '<<j<<endl;
				memset(bit,0,sizeof(bit));
				memset(bitt,0,sizeof(bitt));
				int l=1,r=0;
				ll ress=0;
				for(int k=1;k<=q;++k){
					if(k%10000==0)cerr<<k<<endl;
					if(i<qq[k].x1||qq[k].x2<j)
						continue;
					while(r<qq[k].y2){
						++r;
						add(a[i][r],1);
						ress+=sum(a[j][r]-1);
						addd(a[j][r],1);
					}
					while(l>qq[k].y1){
						--l;
						addd(a[j][l],1);
						ress+=(r-l+1)-summ(a[i][l]);
						add(a[i][l],1);
					}
					while(r>qq[k].y2){
						addd(a[j][r],-1);
						ress-=sum(a[j][r]-1);
						add(a[i][r],-1);
						--r;
					}
					while(l<qq[k].y1){
						add(a[i][l],-1);
						ress-=(r-l+1)-summ(a[i][l]);
						addd(a[j][l],-1);
						++l;
					}
					res[qq[k].id]+=ress;
				}
			}
		for(int i=1;i<=q;++i)
			printf("%lld\n",res[i]);
		return 0;
rev:
		sqrtm=sqrt(n);
		for(int i=1;i<=q;++i)
			qq[i].get(i);
		sort(qq+1,qq+q+1,cmpp);
		for(int i=1;i<=m;++i)
			for(int j=i;j<=m;++j){
				cerr<<i<<' '<<j<<endl;
				memset(bit,0,sizeof(bit));
				memset(bitt,0,sizeof(bitt));
				int l=1,r=0;
				ll ress=0;
				for(int k=1;k<=q;++k){
					if(k%10000==0)cerr<<k<<endl;
					if(i<qq[k].y1||qq[k].y2<j)
						continue;
					while(r<qq[k].x2){
						++r;
						add(a[r][i],1);
						ress+=sum(a[r][j]-1);
						addd(a[r][j],1);
					}
					while(l>qq[k].x1){
						--l;
						addd(a[l][j],1);
						ress+=(r-l+1)-summ(a[l][i]);
						add(a[l][i],1);
					}
					while(r>qq[k].x2){
						addd(a[r][j],-1);
						ress-=sum(a[r][j]-1);
						add(a[r][i],-1);
						--r;
					}
					while(l<qq[k].x1){
						add(a[l][i],-1);
						ress-=(r-l+1)-summ(a[l][i]);
						addd(a[l][j],-1);
						++l;
					}
					res[qq[k].id]+=ress;
				}
			}
		for(int i=1;i<=q;++i)
			printf("%lld\n",res[i]);
		return 0;

	}
	if(type==8||type==9){
		for(int i=1;i<=q;++i)
			qq[i].get(i);
		sort(qq+1,qq+q+1);
		for(int i=1;i<=m;++i,cerr<<i<<endl)
			for(int j=i;j<=m;++j){
				int p=1;
				ll ress=0;
				for(int k=1;k<=n;++k){
					add(a[k][i],1);
					ress+=sum(a[k][j]-1);
					while(p<=q&&qq[p].x2==k){
						if(qq[p].y1<=i&&j<=qq[p].y2)
							res[qq[p].id]+=ress;
						++p;
					}
				}
				for(int k=1;k<=n;++k)
					add(a[k][i],-1);
			}
		for(int i=1;i<=q;++i)
			printf("%lld\n",res[i]);
		return 0;
	}
	while(q--){
		int x1=read(),y1=read(),x2=read(),y2=read();
		ll ans=0;
		if(type==6){
			ll n=x2-x1+1,m=y2-y1+1;
			ans=(n+1)*n/2*m*(m+1)/2;
			ans-=n*m;
		}
		else if(type==7){
			ll n=x2-x1+1,m=y2-y1+1;
			if(a[x1][y1]==1){
				for(int i=1;i<=n;++i)
					if(i&1)
						ans+=calc(i,i,m/2);
					else
						ans+=calc(i/2,i,(m+1)/2);
			}
			else{
				for(int i=1;i<=n;++i)
					if(i&1)
						ans+=calc(i/2,i,(m+1)/2);
					else
						ans+=calc(i,i,m/2);
			}
		}
		printf("%lld\n",ans);
		if(q%100==0)
			cerr<<q<<endl;
	}
	return 0;
}
