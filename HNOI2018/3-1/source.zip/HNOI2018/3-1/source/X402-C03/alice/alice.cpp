#include<bits/stdc++.h>
using namespace std;

const int maxn=2e3+10;
int n,m,q,sum[maxn][maxn],ans;

int main(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	while(q--){
		int x,y;
		scanf("%d%d",&x,&y);
		++sum[x][y];
	}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
	for(int i=0;i<n;++i)
		for(int j=i+1;j<=n;++j)
			for(int k=0;k<m;++k)
				for(int l=k+1;l<=m;++l)
					if(sum[j][l]+sum[i][k]!=sum[j][k]+sum[i][l])
						++ans;
	printf("%d\n",ans);
	return 0;
}
