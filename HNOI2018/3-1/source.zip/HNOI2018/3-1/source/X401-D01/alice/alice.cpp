#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=100+10;
int a[maxn][maxn],s[maxn][maxn],b[maxn];
int main(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	int x,y;
	int ans=0;
	for(int i=1;i<=q;++i){
		scanf("%d%d",&x,&y);	
		a[x][y]=1;
	}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			s[i][j]=s[i][j-1]+a[i][j];
	for(int i=1;i<=m;++i)
		for(int j=i;j<=m;++j){
			for(int k=1;k<=n;++k){
				b[k]=b[k-1]+s[k][j]-s[k][i-1];
			}
			for(int k=1;k<=n;++k){
				for(int z=k;z<=n;++z)
					if(b[z]-b[k-1]>0) ++ans;
				b[k-1]=0;
			}
		}
	cout<<ans<<endl;	
	return 0;
}
