#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int a[2003][2003],b[2003][2003];
int main(){
	freopen("alice.in","r",stdin); freopen("alice.out","w",stdout);
	int n=read(),m=read(),q=read(),x,y,ans=0;
	For(i,1,q) x=read(),y=read(),b[x][y]=1;
	For(i,1,n)
		For(j,1,m) a[i][j]=b[i][j]+a[i-1][j]+a[i][j-1]-a[i-1][j-1];
	For(i,1,n)
		For(j,1,m)
			For(k,i,n)
				For(l,j,m)
					if ((a[k][l]-a[i-1][l]-a[k][j-1]+a[i-1][j-1])>0) ++ans;
	printf("%d\n",ans);
	return 0;
}
