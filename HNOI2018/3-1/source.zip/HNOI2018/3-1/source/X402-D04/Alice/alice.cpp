#include<bits/stdc++.h>
using namespace std;
const int maxn=150;
int f[maxn][maxn],g[maxn][maxn];
int main(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	int n,m,q,x,y;
	cin>>n>>m>>q;
	for(register int i=1;i<=q;++i)scanf("%d%d",&x,&y),f[x][y]=1;
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=m;++j){
			g[i][j]=g[i][j-1]+g[i-1][j]-g[i-1][j-1]+f[i][j];
		}
	}long long ans=0;
	for(register int i=0;i<n;++i){
		for(register int j=0;j<m;++j){
			for(register int k=i+1;k<=n;++k){
				for(register int l=j+1;l<=m;++l){
					if(g[k][l]-g[k][j]-g[i][l]+g[i][j]!=0)++ans;
				}
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}

