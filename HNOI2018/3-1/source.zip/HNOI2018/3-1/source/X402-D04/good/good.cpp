#include<bits/stdc++.h>
using namespace std;

const int maxn=11;
int n;
vector<int> g[maxn];
double ans;

int vis[maxn], cnt, del[maxn];
void dfs(int x,int f){
	cnt++; vis[x]=f;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(vis[v]==f || del[v]) continue;
		dfs(v,f);
	}
}
double solve(int x){
	// printf("x = %d : \n", x);
	double ret=0;
	int col[maxn]={0};
	cnt=0;
	dfs(x,x);
	for(int i=1;i<=n;i++) col[i]=vis[i];
	ret+=cnt;
	// printf("cnt = %d\n", cnt);
	for(int i=1;i<=n;i++) if(col[i]==x && !del[i]){
		// printf("%d\n", i);
		del[i]=1;
		ret+=(1.0/cnt)*solve(i);
		del[i]=0;
	}
	return ret;
}

int main(){
	freopen("good.in","r",stdin),freopen("good.out","w",stdout);

	scanf("%d", &n);
	int u, v;
	for(int i=1;i<n;i++){
		scanf("%d%d", &u, &v); u++; v++;
		g[u].push_back(v), g[v].push_back(u);
	}
	for(int i=1;i<=n;i++){
		del[i]=1;
		ans+=(1.0/n)*solve(i);
		del[i]=0;
		// printf("%lf\n", ans);
	}
	printf("%.4lf\n", ans);
	return 0;
}
