#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1000+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("night.in","r",stdin);
      freopen("night.out","w",stdout);
  #endif
}
/*
int n,m,q;
int a[N],b[N];
int sz,tim;
struct Q
{
	int l,r,id;
	bool operator < (const Q &s)const
	{
		return (l/tim)==(s.l/tim)?r<s.r:(l/tim)<(s.l/tim);
	}
}e[N];
void input()
{
	int x;
	n=read<int>(),m=read<int>(),q=read<int>();
	For(j,1,m)a[j]=b[j]=read<int>();
	For(i,1,q)
	{
		x=read<int>();
		e[i].l=read<int>();
		x=read<int>();
		e[i].r=read<int>();
		e[i].id=i;
		if(e[i].l>e[i].r)swap(e[i].l,e[i].r);
	}
}
void init()
{
	sort(b+1,b+m+1);
	sz=unique(b+1,b+m+1)-b-1;
	For(j,1,m)a[j]=lower_bound(b+1,b+sz+1,a[j])-b;
	tim=sqrt(m);
	sort(e+1,e+q+1);
}
ll ans[N],c[N];
void add(int x,int v)
{
	for(;x<=sz;x+=x&-x)c[x]+=v;
}
int cal(int x)
{
	ll res=0;
	for(;x;x-=x&-x)res+=c[x];
	return res;
}
int L=1,R=0;
ll now;
int vis[N];
void cal_lef(int x)
{
	if(!vis[x])
	{
		now+=cal(a[x]-1);
		add(a[x],1);
	}
	else
	{
		now-=cal(a[x]-1);
		add(a[x],-1);
	}
	vis[x]^=1;
}
void cal_rig(int x)
{
	if(!vis[x])
	{
		now+=cal(sz)-cal(a[x]);
		add(a[x],1);
	}
	else
	{
		now-=cal(sz)-cal(a[x]);
		add(a[x],-1);
	}
	vis[x]^=1;
}
void work()
{
	For(i,1,q)
	{
		while(L>e[i].l)cal_lef(--L);
		while(R<e[i].r)cal_rig(++R);
		while(L<e[i].l)cal_lef(L++);
		while(R>e[i].r)cal_rig(R--);
		ans[e[i].id]=now;
	}
	For(i,1,q)write(ans[i],'\n');
}
void solve()
{
	For(i,e[1].l,e[1].r)For(j,i+1,e[1].r)
	{
		if(a[i]>a[j])now++;
	}
	cout<<now<<endl;
}
*/
int n,m,q;
int sum[N][N];
void input()
{
	int x;
	n=read<int>();m=read<int>();q=read<int>();
	For(i,1,n)For(j,1,m)
	{
		x=read<int>();
	}
}
void init()
{
	
}
int main()
{
	file();
	input();
	init();
	return 0;
}
