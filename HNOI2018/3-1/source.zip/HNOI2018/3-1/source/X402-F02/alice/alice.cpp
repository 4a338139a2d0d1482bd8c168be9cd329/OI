#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=2e3+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("alice.in","r",stdin);
      freopen("alice.out","w",stdout);
  #endif
}
int n,m,k;
int sum[N][N];
void input()
{
	int x,y;
	n=read<int>(),m=read<int>(),k=read<int>();
	For(i,1,k)
	{
		x=read<int>(),y=read<int>();
		++sum[x][y];
	}
}
namespace sub1
{
	void init()
	{
		For(i,1,n)For(j,1,m)
			sum[i][j]=sum[i][j]+sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
	}
	int cal(int x1,int y1,int x2,int y2)
	{
		return sum[x2][y2]-sum[x2][y1-1]-sum[x1-1][y2]+sum[x1-1][y1-1];
	}
	ll ans;
	void solve()
	{
		init();
		int temp;
		For(i,1,n)For(j,1,m)
		{
			For(k1,0,n-i)
			{
				For(k2,0,m-j)
				{
					temp=cal(i,j,i+k1,j+k2);
					if(temp>=1)++ans;
				}
			}
		}
		write(ans,'\n');
	}
}
namespace sub2
{
	ll tot;
	void solve()
	{
		For(i,1,n)For(j,1,m)tot+=1ll*i*j,sum[i][j]^=1;	
		write(tot,'\n');
	}
}
void work()
{
	if(n<=100&&m<=100)sub1::solve();
	else  sub2::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
