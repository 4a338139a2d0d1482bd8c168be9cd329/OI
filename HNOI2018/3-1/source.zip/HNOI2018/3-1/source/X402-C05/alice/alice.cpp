#include<bits/stdc++.h>
using namespace std;
const int maxn=400;
int n,m,q;
int x[maxn],y[maxn];
long long ans;
void solve(){
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=q;++i){
		scanf("%d%d",&x[i],&y[i]);
	}
	for(int i=0;i<=n;++i)for(int j=0;j<=m;++j)
	for(int k=i+1;k<=n;++k)for(int l=j+1;l<=m;++l)
	for(int t=1;t<=q;++t)
	if(i<x[t]&&j<y[t]&&k>=x[t]&&l>=y[t]){++ans;break;}
	cout<<ans<<endl; 
}
int main(){
	freopen("alice.in","r",stdin);freopen("alice.out","w",stdout);
	solve();
	
	return 0;
}
