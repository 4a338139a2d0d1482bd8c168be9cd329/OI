#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
}

const int N=2e3+10;
int n,m,q,F[N][N],ans;

int main(){
	file();
	read(n),read(m),read(q);
	For(i,1,q){
		int x,y;
		read(x),read(y);
		F[x][y]=1;
	}
	For(i,1,n) For(j,1,m)
		F[i][j]+=F[i-1][j]+F[i][j-1]-F[i-1][j-1];
	For(i,1,n) For(j,1,m)
		For(ii,i,n) For(jj,j,m)
			if(F[ii][jj]-F[i-1][jj]-F[ii][j-1]+F[i-1][j-1]>0) ++ans;	
	printf("%d\n",ans);
	return 0;
}

