#include<bits/stdc++.h>
#define mem(a,b) memset(a,b,sizeof(a))
#define Travel(i,x) for(register int i=beg[x];i;i=nex[i])
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
}

const int N=100+10;
int e,beg[N<<1],nex[N<<1],to[N<<1],sum;
int cnt,n,fa[N],vis[N],num[N],Vis[N];
double ans,D;

inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}

int Do(int x){
	int S=0,V[N];
	mem(V,0);
	queue<int> Q;
	Q.push(x),V[x]=1;
	while(!Q.empty()){
		int s=Q.front();Q.pop();
		S++;
		Travel(i,s){
			int t=to[i];
			if(vis[t]) continue;
			if(!V[t]){
				V[t]=1;
				Q.push(t);
			}
		}
	}
	return S;
}

inline void dfs(int x,int tot){
	if(x==n+1){
		sum+=tot;
		tot=0;
		return;				
	}
	For(i,1,n){
		if(vis[i]) continue;
		vis[i]=1;
		dfs(x+1,tot+Do(i));
		vis[i]=0;
	}
}

int main(){
	file();
	read(n);
	For(i,1,n-1){
		int x,y;
		read(x),read(y);
		++x,++y;
		add(x,y),add(y,x);
	}
	dfs(1,0);
	D=1;
	For(i,2,n) D*=(i*1.0);
	ans=((double)sum)/D;
	printf("%.4lf\n",ans);
	return 0;
}

