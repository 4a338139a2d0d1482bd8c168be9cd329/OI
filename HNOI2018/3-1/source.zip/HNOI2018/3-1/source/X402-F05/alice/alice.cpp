#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int Read() {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 7e4 + 10, M = 4e5 + 10;

typedef long long LL;

int n, m, q;

struct Point {
	int x, y;

	bool operator < (const Point& A) const {
		return x < A.x;
	}
}P[M];

int val[N], fa[N];
int rk[N], sz[N];

int find(int x) { return x == fa[x] ? x : fa[x] = find(fa[x]); }

bool cmp(int x, int y) {
	return val[x] == val[y] ? x < y : val[x] < val[y];
}

int main() {

	freopen("alice.in", "r", stdin);
	freopen("alice.out", "w", stdout);

	n = Read(), m = Read(), q = Read();
	For(i, 1, q) P[i].x = Read(), P[i].y = Read();
	sort(P + 1, P + q + 1);

	int p = 0;
	LL ans = 0;
	For(i, 1, n) {
		while (p < q && P[p + 1].x == i) ++p, val[P[p].y] = i;
		For(j, 1, m) rk[j] = j, sz[j] = 1, fa[j] = j;
		sort(rk + 1, rk + m + 1, cmp);
		For(k, 1, m) {
			int j = rk[k];
			ans += val[j];
			if (j < m && val[j + 1] < val[j]) {
				int u = find(j + 1);
				ans += 1ll * sz[u] * sz[j] * val[j];
				sz[j] += sz[u];
				fa[u] = j;
			}
			if (j > 1 && val[j - 1] <= val[j]) {
				int u = find(j - 1);
				ans += 1ll * sz[u] * sz[j] * val[j];
				sz[j] += sz[u];
				fa[u] = j;
			}
		}
	}
	printf("%lld\n", ans);

	return 0;
}
