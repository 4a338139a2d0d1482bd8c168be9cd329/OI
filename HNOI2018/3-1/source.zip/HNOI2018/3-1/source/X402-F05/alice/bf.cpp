#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int Read() {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 210, M = 4e5 + 10;

typedef long long LL;

int n, m, q;
int c[N][N];

int main() {

	freopen("alice.in", "r", stdin);
	freopen("alice.ans", "w", stdout);

	n = Read(), m = Read(), q = Read();
	For(i, 1, q) {
		int x = Read(), y = Read();
		c[x][y]++;
	}
	For(i, 1, n) For(j, 1, m) c[i][j] += c[i - 1][j] + c[i][j - 1] - c[i - 1][j - 1];

	LL ans = 0;
	For(x, 0, n - 1) For(y, 0, m - 1)
		For(a, x + 1, n) For(b, y + 1, m)
			ans += bool(c[a][b] - c[x][b] - c[a][y] + c[x][y]);

	printf("%lld\n", ans);

	return 0;
}
