#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int main() {

	freopen("alice.in", "w", stdout);

	srand(time(0));

	int n = rand() % 2000 + 5, m = rand() % 2000 + 5, q = n * m / 10;
	printf("%d %d %d\n", n, m, q);
	while (q--) printf("%d %d\n", rand() % n + 1, rand() % m + 1);

	return 0;
}
