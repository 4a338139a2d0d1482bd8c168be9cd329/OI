#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 20;

int Begin[N], Next[N << 1], to[N << 1], e;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

double dp[1 << N];
int st[N], n;

void DFS(int o, int f = -1) {
	st[o] = 1 << o;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f) continue;
		DFS(u, o);
		st[o] |= st[u];
	}
}

int main() {

	freopen("good.in", "r", stdin);
	freopen("good.out", "w", stdout);

	scanf("%d", &n);
	For(i, 2, n) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}

	double ans = 0;
	For(o, 0, n - 1) {
		DFS(o);
		Forr(i, (1 << n) - 2, 0) {
			int sz = n - __builtin_popcount(i);
			dp[i] = 0;
			For(j, 0, n - 1) if (!(i & (1 << j)))
				dp[i] += dp[i | st[j]];
			dp[i] = dp[i] / sz + 1;
		}
		ans += dp[0];
	}
	printf("%.4lf\n", ans);

	return 0;
}
