#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define N 110
int n,m;ll q;
ll g[N][N];
int main()
{
	freopen("night.in","r",stdin);
	freopen("night.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j) 
			scanf("%lld",&g[i][j]);
	for(ll qq=1;qq<=q;++qq)
	{
		int u1,v1,u2,v2;
		scanf("%d%d%d%d",&u1,&v1,&u2,&v2);
		ll ans=0;
		for(int i=u1;i<=u2;++i)
			for(int j=v1;j<=v2;++j)
				for(int ii=u1;ii<=i;++ii)
					for(int jj=v1;jj<=j;++jj)
						if(g[ii][jj]>g[i][j])
							++ans;
		printf("%lld\n",ans);
	}
	return 0;
}
