#include<bits/stdc++.h>
using namespace std;
#define Temp template<typename T>
Temp inline void read(T &x)
{
	x=0;char c=getchar();T f=1;
	while(!isdigit(c)) {if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

#define N 2020
int n,m,q;
int g[N][N],ans;
int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	int xx,yy;
	read(n),read(m),read(q);
	for(int i=1;i<=q;++i)
	{
		read(xx),read(yy);
		g[xx][yy]=1;
	}
	for(int i=1;i<=n;++i) 
		for(int j=1;j<=m;++j)
		{
			g[i][j]+=g[i-1][j]+g[i][j-1]-g[i-1][j-1];
		}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			for(int ii=1;ii<=i;++ii)
				for(int jj=1;jj<=j;++jj)
				{
					if(g[i][j]-g[i][jj-1]-g[ii-1][j]+g[ii-1][jj-1]) ++ans;
				}
	printf("%d\n",ans);
	return 0;
}
