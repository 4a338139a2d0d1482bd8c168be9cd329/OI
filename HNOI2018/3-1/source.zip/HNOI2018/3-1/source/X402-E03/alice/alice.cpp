#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 2e3+5 ;
int s[maxn][maxn] ;
int n, m ;
int main() {
	freopen ( "alice.in", "r", stdin ) ;
	freopen ( "alice.out", "w", stdout ) ;
	int x1, y1, x2, y2, _, i, j, ans = 0 ;
	Read(n), Read(m), Read(_) ;
	while (_--) {
		Read(x1), Read(y1) ;
		s[x1][y1] = 1 ;
	}
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= m ; j ++ )
			s[i][j] += s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1] ;
	for ( x1 = 1 ; x1 <= n ; x1 ++ )
		for ( y1 = 1 ; y1 <= m ; y1 ++ )
			for ( x2 = x1 ; x2 <= n ; x2 ++ )
				for ( y2 = y1 ; y2 <= m ; y2 ++ )
					if (s[x2][y2] - s[x2][y1-1] - s[x1-1][y2] + s[x1-1][y1-1] > 0)
						ans ++ ;
	cout << ans << endl ;
	return 0 ;
}
