#include<cstdio>
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
#define rf(i,a,b) for(register int i=(a);i>=(b);i=~(-(i)))
int n;
int main()
{
	int x,y;
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	scanf("%d",&n);
	f(i,1,n-1)scanf("%d%d",&x,&y);
	printf("3.6667\n");
}
