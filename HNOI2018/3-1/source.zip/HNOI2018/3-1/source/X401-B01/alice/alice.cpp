#include<cstdio>
#define sneko 2010
#define f(i,a,b) for(register int i=(a);i<=(b);i=-(~(i)))
typedef long long ll;
ll book[sneko][sneko],s[sneko][sneko],ans;
int n,m,light;
int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
	int x,y;
	scanf("%d%d%d",&n,&m,&light);
	f(i,1,light)
	{
		scanf("%d%d",&x,&y);
		book[x][y]=1;
	}
	f(i,1,n)
	 f(j,1,m)
	  s[i][j]=s[i-1][j]+s[i][j-1]+book[i][j]-s[i-1][j-1];
	f(i,1,n)
	 f(j,1,m)
	  f(k,i,n)
	   f(o,j,m)
	    if((s[k][o]-s[k][j-1]-s[i-1][o]+s[i-1][j-1])>0)++ans;
	printf("%lld\n",ans);
} 	
