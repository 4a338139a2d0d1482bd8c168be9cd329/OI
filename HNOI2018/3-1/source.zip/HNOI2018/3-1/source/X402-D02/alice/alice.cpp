#include<iostream>
#include<cstdio>
#include<cstring>

typedef long long ll;

const int N=105,MOD=998244353;

ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

int fact[N],ifact[N];

int C(int n,int m){return (ll)fact[n]*ifact[m]%MOD*ifact[n-m]%MOD;}

void initialize()
{
	fact[0]=1;
	for(int i=1;i<N;i++)fact[i]=(ll)fact[i-1]*i%MOD;
	ifact[N-1]=qpow(fact[N-1],MOD-2);
	for(int i=N-1;i;i--)ifact[i-1]=(ll)ifact[i]*i%MOD;
}

bool ex[N];

int G[N][N];
int n,m,Q;

int main()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);

	initialize();
	scanf("%d%d%d",&n,&m,&Q);
	for(int x,y;Q--;)scanf("%d%d",&x,&y),G[x][y]=1;

	int ans=0;
	
	for(int i=1;i<=n;i++)
	{
		memset(ex,0,sizeof(ex));
		for(int j=i;j<=n;j++)
		{
			for(int k=1;k<=m;k++)
				ex[k]|=G[j][k];
			ans+=C(m+1,2);
			int cnt=0;
			for(int k=1;k<=m;k++)
				if(!ex[k])ans-=(cnt+1),cnt++;
				else cnt=0;
		}
	}

	printf("%d\n",ans);

	return 0;
}
