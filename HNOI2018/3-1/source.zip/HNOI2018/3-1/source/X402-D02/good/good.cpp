#include<iostream>
#include<cstdio>
#include<cstring>

namespace NanXiang_qwq
{
	typedef long long ll;
	const int N=100010,M=N*3,MOD=1004535809;

	ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

	int dec[M];
	void getdec(int n){for(int i=1;i<n;i++)dec[i]=(dec[i>>1]>>1)+(i&1?n>>1:0);}
	void ntt(int *y,int n,int rag)
	{
		for(int i=0;i<n;i++)if(i<dec[i])std::swap(y[i],y[dec[i]]);

		int *y0,*y1,ny0,ny1;
		for(int len=2;len<=n;len<<=1)
		{
			int delta=qpow(3,(MOD-1)/len),h=len>>1,x;
			if(rag<0)delta=inv(delta);

			for(int p=0;p<n;p+=len)
			{
				y0=y+p,y1=y0+h,x=1;
				for(int i=0;i<h;i++)
				{
					ny0=(y0[i]+(ll)x*y1[i])%MOD;
					ny1=(y0[i]-(ll)x*y1[i])%MOD;
					y0[i]=ny0,y1[i]=ny1;
					x=(ll)x*delta%MOD;
				}
			}
		}
	}

	int t0[10000000],end;

	struct polynomial{int *s,len;};

	polynomial beg(int len)
	{
		static polynomial ret;
		ret.s=t0+end,ret.len=len;
		end+=len;
		return ret;
	}

	polynomial operator * (polynomial u,polynomial v)
	{
		static int A[M],B[M],m;
		for(m=1;m<u.len+v.len-1;m<<=1);
		memcpy(A,u.s,u.len*4);for(int i=u.len;i<m;i++)A[i]=0;
		memcpy(B,v.s,v.len*4);for(int i=v.len;i<m;i++)B[i]=0;

		getdec(m);
		ntt(A,m,1),ntt(B,m,1);
		for(int i=0;i<m;i++)A[i]=(ll)A[i]*B[i]%MOD;
		ntt(A,m,-1);

		int dn=inv(m);
		polynomial w=beg(u.len+v.len-1);
		for(int i=0;i<w.len;i++)
			w.s[i]=((ll)A[i]*dn%MOD+MOD)%MOD;
		return w;
	}

	int begin[N],next[N*2],to[N*2];

	int n,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}

	void initialize()
	{
		scanf("%d",&n);
		for(int i=1,u,v;i<n;i++)
			scanf("%d%d",&u,&v),add(u+1,v+1);
	}

	bool vis[N];
	int siz[N],dep[N];

	int get_it(int p,int h,int cnt)
	{
		siz[p]=1;
		int ret=-1,flag=1;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !vis[q])
			{
				ret=get_it(q,p,cnt);
				if(ret>0)return ret;
				siz[p]+=siz[q];

				if(siz[q]>cnt/2)flag=0;
			}
		if(cnt-siz[p]>cnt/2)flag=0;

		if(flag)return p;
		return -1;
	}

	void dfs(int p,int h)
	{
		siz[p]=1;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !vis[q])
			{
				dep[q]=dep[p]+1;
				dfs(q,p);
				siz[p]+=siz[q];
			}
	}

	void count(int p,int h,polynomial &A)
	{
		A.s[dep[p]]++;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h && !vis[q])
				count(q,p,A);
	}

	int cnt[N];

	void DC(int p,int size)
	{
		p=get_it(p,0,size);
		dep[p]=0,dfs(p,0);

		polynomial all=beg(size+1),A;

		all.s[0]++,cnt[0]-=1;

		for(int i=begin[p],q;i;i=next[i])
			if(!vis[q=to[i]])
			{
				A=beg(siz[q]+1);
				count(q,p,A);

				for(int j=0;j<A.len;j++)
					all.s[j]+=A.s[j];

				A=A*A;
				for(int j=0;j<A.len;j++)
					cnt[j]-=A.s[j];
			}

		all=all*all;

		for(int i=0;i<all.len;i++)
			cnt[i]+=all.s[i];


		vis[p]=1;
		for(int i=begin[p],q;i;i=next[i])
			if(!vis[q=to[i]])DC(q,siz[q]);
	}

	void solve()
	{
		initialize();
		DC(1,n);

		double ans=0;

		for(int i=0;i<n;i++)
			ans+=(double)i/(i+1)*cnt[i];

		ans=(double)n*n-ans;

		printf("%.4lf\n",ans);
	}
}

int main()
{
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	NanXiang_qwq::solve();
	return 0;
}
