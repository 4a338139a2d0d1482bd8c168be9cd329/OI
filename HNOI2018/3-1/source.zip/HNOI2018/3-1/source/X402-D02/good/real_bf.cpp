#include<iostream>
#include<cstdio>
#include<cstring>
#include<set>

namespace O_O
{
	const int N=20;

	std::set<int> E[N];

	int n;

	int dfs(int p,int h=0)
	{
		int ret=1<<(p-1);
		for(auto q:E[p])
			if(q!=h)ret|=dfs(q,p);
		return ret;
	}

	double fuck(int p);

	double calc(int S)
	{
		int cnt=0;
		double sum=0;
		for(int i=1;i<=n;i++)
			if((S>>(i-1))&1)
			{
				cnt++;
				sum+=fuck(i);
			}
		return sum/cnt+cnt;
	}

	double fuck(int p)
	{
		std::set<int> T;

		double ret=0;

		T.clear();
		for(auto q:E[p])T.insert(q);

		for(auto q:T)E[p].erase(q),E[q].erase(p);
		for(auto q:T)ret+=calc(dfs(q));
		for(auto q:T)E[p].insert(q),E[q].insert(p); 

		return ret;
	}

	void solve()
	{
		scanf("%d",&n);
		for(int i=1,u,v;i<n;i++)
		{
			scanf("%d%d",&u,&v);
			u++,v++;
			E[u].insert(v),E[v].insert(u);
		}
		printf("%.4lf\n",calc((1<<n)-1));
	}
}

int main()
{
	freopen("good.in","r",stdin);
	freopen("good.ans","w",stdout);
	O_O::solve();
	return 0;
}
