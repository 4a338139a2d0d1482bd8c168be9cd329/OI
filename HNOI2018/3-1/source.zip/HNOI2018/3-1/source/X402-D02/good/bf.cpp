#include<iostream>
#include<cstdio>
#include<cstring>

namespace NanXiang_qwq
{
	const int N=2010;

	int begin[N],next[N*2],to[N*2];

	int n,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}

	void initialize()
	{
		scanf("%d",&n);
		for(int i=1,u,v;i<n;i++)
			scanf("%d%d",&u,&v),add(u+1,v+1);
	}

	int dep[N];

	void dfs(int p,int h=0)
	{
		dep[p]=dep[h]+1;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h)dfs(q,p);
	}

	double calc(int p)
	{
		dep[0]=-1,dfs(p);
		double ret=0;
		for(int i=1;i<=n;i++)
			ret+=(double)dep[i]/(dep[i]+1);
		return ret;
	}

	void solve()
	{
		initialize();
		double ans=0;
		for(int i=1;i<=n;i++)
			ans+=calc(i);
		ans=n*n-ans;
		printf("%.4lf\n",ans);
	}
}

int main()
{
	freopen("good.in","r",stdin);
	freopen("good.ans","w",stdout);
	NanXiang_qwq::solve();
	return 0;
}
