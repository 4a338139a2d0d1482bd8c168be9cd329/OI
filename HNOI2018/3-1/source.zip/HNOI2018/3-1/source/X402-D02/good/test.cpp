#include<iostream>
#include<cstdio>
#include<cstring>

const int N=50;

double fact[N];

double qpow(double a,int b)
{
	double c=1;
	for(;b;b>>=1,a=a*a)if(b&1)c=c*a;
	return c;
}

int main()
{
	fact[0]=1;
	for(int i=1;i<N;i++)fact[i]=fact[i-1]*i;

//	double p1=1.0/3,p0=p1,pe=p1,pb=p1,pnb=p1;
	double p1=1.0/3,p0=p1,pe=p1,pb=p1*2,pnb=0;

	double cnt=0;
	for(int i=1;i<N;i++)
		for(int j=0;i+j<N;j++)
			cnt+=qpow(p1,i)*i*qpow(p0,j)/fact[i]/fact[j]*fact[i+j];

	cnt*=pe;
	cnt*=pb/(1-pnb);

	printf("%lf\n",cnt);

	return 0;
}
