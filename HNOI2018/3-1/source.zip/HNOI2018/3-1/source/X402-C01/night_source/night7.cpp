/************************************************
 * Au: Hany01
 * Prob: night subtask7 10pts
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("night7.in", "r", stdin);
    freopen("night7.out", "w", stdout);
}

int n, m, k;
LL dp1[1005][1005], dp2[1005][1005];
int x1, y1, x2, y2;

int main()
{
    File();
	n = read(), m = read(), k = read();
	For(i, 1, n) For(j, 1, m) read();
	For(i, 1, n) For(j, 1, m) {
		if (!((i + j) & 1)) dp1[i][j] = dp1[i - 1][j] + dp1[i][j - 1] - dp1[i - 1][j - 1] + i / 2 * j + ((i & 1) ? j / 2 : 0);
		else dp1[i][j] = dp1[i - 1][j] + dp1[i][j - 1] - dp1[i - 1][j - 1];
	}
	For(i, 1, n) For(j, 1, m) {
		if ((i + j) & 1) dp2[i][j] = dp2[i - 1][j] + dp2[i][j - 1] - dp2[i - 1][j - 1] + i / 2 * j + ((i & 1) ? j / 2 : 0);
		else dp2[i][j] = dp2[i - 1][j] + dp2[i][j - 1] - dp2[i - 1][j - 1];
	}
	while (k --) {
		x1 = read(), y1 = read(), x2 = read(), y2 = read();
		if ((x1 + y1) & 1) printf("%lld\n", dp2[x2 - x1 + 1][y2 - y1 + 1]);
		else printf("%lld\n", dp1[x2 - x1 + 1][y2 - y1 + 1]);
	}
    return 0;
}
