/************************************************
 * Au: Hany01
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("night3.in", "r", stdin);
    freopen("night3.out", "w", stdout);
}

const int maxn = 200005, maxm = 500005;

int n, m, Q, a[2][maxn], tmp1, tmp2, tmp_, tmp__, l, r, bel[maxn], block, nn, b[maxn << 1], cnt1, cnt2, cnt3, cnt, tot;
LL Ans, ans[maxm];

struct Question
{
	int l, r, id;
}q1[maxm], q2[maxm], q3[maxm];
bool operator < (const Question& A, const Question& B) {
	return bel[A.l] < bel[B.l] || (bel[A.l] == bel[B.l] && A.r < B.r);
}

struct BIT
{
	int c[maxm];

	inline void clear() { Set(c, 0); }

#define lb(x) ((x) & -(x))
	inline void update(int pos, int dt) { for ( ; pos <= nn; pos += lb(pos)) c[pos] += dt; }

	inline LL query(int pos) { LL Ans = 0; for ( ; pos; pos -= lb(pos)) Ans += c[pos]; return Ans; }

}bit, bit_;

inline void Solve1()
{
	l = 1, r = 0, Ans = 0, bit.clear();
	For(i, 1, cnt1) {
		while (r < q1[i].r) {
			++ r;
			Ans += (r - l) - bit.query(a[0][r]);
			bit.update(a[0][r], 1);
		}
		while (r > q1[i].r) {
			Ans -= (r - l + 1) - bit.query(a[0][r]);
			bit.update(a[0][r], -1);
			-- r;
		}
		while (l > q1[i].l) {
			-- l;
			Ans += bit.query(a[0][l] - 1);
			bit.update(a[0][l], 1);
		}
		while (l < q1[i].l) {
			Ans -= bit.query(a[0][l] - 1);
			bit.update(a[0][l], -1);
			++ l;
		}
		ans[q1[i].id] = Ans;
		cerr << ++ cnt << endl;
	}
}

inline void Solve2()
{
	l = 1, r = 0, Ans = 0, bit.clear();
	For(i, 1, cnt2) {
		while (r < q2[i].r) {
			++ r;
			Ans += (r - l) - bit.query(a[1][r]);
			bit.update(a[1][r], 1);
		}
		while (r > q2[i].r) {
			Ans -= (r - l + 1) - bit.query(a[1][r]);
			bit.update(a[1][r], -1);
			-- r;
		}
		while (l > q2[i].l) {
			-- l;
			Ans += bit.query(a[1][l] - 1);
			bit.update(a[1][l], 1);
		}
		while (l < q2[i].l) {
			Ans -= bit.query(a[1][l] - 1);
			bit.update(a[1][l], -1);
			++ l;
		}
		ans[q2[i].id] = Ans;
		cerr << ++ cnt << endl;
	}
}

inline void Solve3()
{
	l = 1, r = 0, Ans = 0, bit.clear();
	For(i, 1, cnt3) {
		while (r < q3[i].r) {
			++ r;
			Ans += (r - l) - bit.query(a[0][r]);
			Ans += (r - l) - bit_.query(a[1][r]);
			Ans += (r - l) - bit.query(a[1][r]);
			if (a[1][r] < a[0][r]) ++ Ans;
			bit.update(a[0][r], 1);
			bit_.update(a[1][r], 1);
		}
		while (r > q3[i].r) {
			Ans -= (r - l + 1) - bit.query(a[0][r]);
			Ans -= (r - l + 1) - bit_.query(a[1][r]);
			Ans -= (r - l + 1) - bit.query(a[1][r]);
			bit.update(a[0][r], -1);
			bit_.update(a[1][r], -1);
			-- r;
		}
		while (l > q3[i].l) {
			-- l;
			Ans += bit.query(a[0][l] - 1);
			Ans += bit_.query(a[1][l] - 1);
			Ans += bit_.query(a[0][l] - 1);
			if (a[1][l] < a[0][l]) ++ Ans;
			bit.update(a[0][l], 1);
			bit_.update(a[1][l], 1);
		}
		while (l < q3[i].l) {
			Ans -= bit.query(a[0][l] - 1);
			Ans -= bit_.query(a[1][l] - 1);
			Ans -= bit_.query(a[0][l] - 1);
			bit.update(a[0][l], -1);
			bit_.update(a[1][l], -1);
			++ l;
		}
		ans[q3[i].id] = Ans;
		cerr << ++ cnt << endl;
	}
}

int main()
{
    File();
	n = read(), m = read(), Q = read();
	n = m;
	For(i, 0, 1) For(j, 1, n) a[i][j] = b[++ tot] = read();
	sort(b + 1, b + 1 + tot);
	nn = unique(b + 1, b + 1 + tot) - b - 1;
	For(i, 0, 1) For(j, 1, n) a[i][j] = lower_bound(b + 1, b + 1 + nn, a[i][j]) - b;
	For(i, 1, Q) {
		tmp_ = read(), tmp1 = read(), tmp__ = read(), tmp2 = read();
		if (tmp_ == 1 && tmp__ == 1) q1[++ cnt1].l = tmp1, q1[cnt1].r = tmp2, q1[cnt1].id = i;
		else if (tmp_ == 2 && tmp__ == 2) q2[++ cnt2].l = tmp1, q2[cnt2].r = tmp2, q2[cnt2].id = i;
		else q3[++ cnt3].l = tmp1, q3[cnt3].r = tmp2, q3[cnt3].id = i;
	}
	block = sqrt(n);
	For(i, 1, n) bel[i] = (i - 1) / block + 1;
	sort(q1 + 1, q1 + 1 + cnt1), sort(q2 + 1, q2 + 1 + cnt2), sort(q3 + 1, q3 + 1 + cnt3);
	Solve1();
	Solve2();
	Solve3();
	For(i, 1, Q) printf("%lld\n", ans[i]);
    return 0;
}
