#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

const int Base = 1;

struct Query {
	int l, r, id;
	Query(int l0 = 0, int r0 = 0, int id0 = 0): l(l0), r(r0), id(id0) {}
	bool operator < (const Query &rhs) const {
		return l/Base < rhs.l/Base || (l/Base == rhs.l/Base && r > rhs.r);
	}
};

vector<Query> q[1010][1010];
int n, m, A[1010][1010], Hash[10];
int cnt, Q;
ll res[1000010], C[1010][10], ans;

inline ll query(int id, int x) {
	ll r = 0;
	while(x) {
		r += C[id][x];
		x -= x & (-x);
	}
	return r;
}

inline void Add(int id, int x, int p) {
	while(x <= cnt) {
		C[id][x] += p;
		x += x & (-x);
	}
}

inline ll query(int id, int l, int r) {
	return query(id, r)-query(id, l-1);
}

inline void addr(int a, int b, int c) {
	int i, j;
	for(i = a; i <= b; i++) {
		for(j = a; j <= i; j++) 
			ans += query(j, A[i][c]+1, cnt);
		Add(i, A[i][c], 1);
	}
}

inline void addl(int a, int b, int c) {
	int i, j;
	for(i = b; i >= a; i--) {
		for(j = b; j >= i; j--) 
			ans += query(j, 1, A[i][c]-1);
		Add(i, A[i][c], 1);
	}
}

inline void delr(int a, int b, int c) {
	int i, j;
	for(i = b; i >= a; i--) {
		for(j = a; j <= i; j++) 
			ans -= query(j, A[i][c]+1, cnt);
		Add(i, A[i][c], -1);
	}
}

inline void dell(int a, int b, int c) {
	int i, j;
	for(i = a; i <= b; i++) {
		for(j = i; j <= b; j++) 
			ans -= query(j, 1, A[i][c]-1);
		Add(i, A[i][c], -1);
	}
}

inline void solve(int a, int b) {
	sort(q[a][b].begin(), q[a][b].end());
	int qn = q[a][b].size(), l, r, i;
	if(qn == 0) return;
	for(i = a; i <= b; i++) memset(C[i], 0, sizeof(C[i]));
	l = r = q[a][b][0].l;
	ans = 0;
	addr(a, b, r);
	//printf(":%lld\n", ans);
	for(i = 0; i < qn; i++) {
		int nl = q[a][b][i].l, nr = q[a][b][i].r;
		//printf(">>> %d %d\n", nl, nr);
		while(r < nr) {
			addr(a, b, ++r);
			//printf("1:%lld\n", ans);
		}
		while(l > nl) {
			addl(a, b, --l);
			//printf("2:%lld\n", ans);
		}
		while(r > nr) {
			delr(a, b, r--);
			//printf("3:%lld\n", ans);
		}
		while(l < nl) {
			dell(a, b, l++);
			//printf("4:%lld\n", ans);
		}
		res[q[a][b][i].id] = ans;
		//printf("%lld\n", ans);
		//cerr << i << endl;
	}
	cerr << a << ' ' << b << endl;
}

int main() {
	freopen("night.in", "r", stdin);
	freopen("night.out", "w", stdout);

	int i, j;
	n = read(), m = read(), Q = read();
	if(n > m) {
		swap(n, m);
		for(j = 1; j <= m; j++) 
			for(i = 1; i <= n; i++) 
				A[i][j] = read();
		for(i = 1; i <= Q; i++) {
			int u1 = read(), v1 = read();
			int u2 = read(), v2 = read();
			swap(u1, v1), swap(u2, v2);
			q[u1][u2].push_back(Query(v1, v2, i));
		}
	}
	else {
		for(i = 1; i <= n; i++) 
			for(j = 1; j <= m; j++) A[i][j] = read();
		for(i = 1; i <= Q; i++) {
			int u1 = read(), v1 = read();
			int u2 = read(), v2 = read();
			q[u1][u2].push_back(Query(v1, v2, i));
		}
	}
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= m; j++) Hash[++cnt] = A[i][j];
	sort(Hash+1, Hash+cnt+1);
	cnt = unique(Hash+1, Hash+cnt+1)-Hash-1;
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= m; j++) 
			A[i][j] = lower_bound(Hash+1, Hash+cnt+1, A[i][j])-Hash;
	for(i = 1; i <= n; i++) 
		for(j = i; j <= n; j++) 
			solve(i, j);
	for(i = 1; i <= Q; i++) printf("%lld\n", res[i]);
	return 0;
}
