#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, Q;

int main() {
	freopen("bf2.in", "r", stdin);
	freopen("bf2.out", "w", stdout);

	int i, j;
	n = read(), m = read(), Q = read();
	for(i = 1; i <= n; i++)
		for(j = 1; j <= m; j++) read();
	while(Q--) {
		int u1 = read(), v1 = read();
		int u2 = read(), v2 = read();
		ll N = u2-u1, M = v2-v1;
		printf("%lld\n", ((N*(N+1))>>1)*((M*(M+1))>>1)-N*M);
	}
	return 0;
}

