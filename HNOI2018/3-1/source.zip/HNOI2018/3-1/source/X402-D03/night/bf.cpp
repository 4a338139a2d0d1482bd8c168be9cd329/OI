#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, Q, a[110][110];

int main() {
	freopen("night.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j, x, y;
	n = read(), m = read(), Q = read();
	for(i = 1; i <= n; i++)
		for(j = 1; j <= m; j++) 
			a[i][j] = read();
	while(Q--) {
		int u1 = read(), v1 = read();
		int u2 = read(), v2 = read();
		int ans = 0;
		for(i = u1; i <= u2; i++) 
			for(j = v1; j <= v2; j++) 
				for(x = i; x <= u2; x++) 
					for(y = j; y <= v2; y++) 
						if(a[i][j] > a[x][y]) ans++;
		printf("%d\n", ans);
	}
	return 0;
}
