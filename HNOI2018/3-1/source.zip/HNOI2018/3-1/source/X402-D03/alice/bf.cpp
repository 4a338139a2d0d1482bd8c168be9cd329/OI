#include<bits/stdc++.h>
using namespace std;

const int MAXN = 110;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, q, sum[MAXN][MAXN];
int ans;

int main() {
	freopen("alice.in", "r", stdin);
	freopen("alice.out", "w", stdout);

	n = read(), m = read(), q = read();
	int i, j, x, y;
	for(i = 1; i <= q; i++) {
		x = read(), y = read();
		sum[x][y] = 1;
	}
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= m; j++) 
			sum[i][j] += sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= m; j++) 
			for(x = i; x <= n; x++) 
				for(y = j; y <= m; y++) {
					//printf("%d %d %d %d %d\n", i, j, x, y, sum[x][y]-sum[x][j-1]-sum[i-1][y]+sum[i-1][j-1]);
					if(sum[x][y]-sum[x][j-1]-sum[i-1][y]+sum[i-1][j-1]) ans++;
				}
	printf("%d\n", ans);
	return 0;
}
