#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 2010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, q, s[MAXN];
bool a[MAXN][MAXN];
ll ans, cur;
int st[MAXN], top;

int main() {
	freopen("alice.in", "r", stdin);
	freopen("alice.out", "w", stdout);

	n = read(), m = read(), q = read();
	int i, j;
	for(i = 1; i <= q; i++) {
		int x = read(), y = read();
		a[x][y] = 1;
	}
	for(i = 1; i <= n; i++) s[i] = n+1;
	for(j = m; j >= 1; j--) {
		for(i = 1; i <= n; i++) 
			if(a[i][j]) s[i] = j;
		cur = top = 0;
		st[0] = n+1;
		for(i = n; i >= 1; i--) {
			while(top && s[i] <= s[st[top]]) {
				cur -= (ll)(st[top-1]-st[top])*(n-s[st[top]]+1);
				top--;
			}
			st[++top] = i;
			cur += (ll)(st[top-1]-st[top])*(n-s[i]+1);
			ans += cur;
			//printf(">>> %lld\n", cur);
		}
		//printf("%lld\n", ans);
	}
	printf("%lld\n", ans);
	return 0;
}
