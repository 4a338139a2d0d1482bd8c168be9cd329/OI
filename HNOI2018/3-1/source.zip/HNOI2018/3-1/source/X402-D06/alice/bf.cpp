#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=2e3+10;
int G[maxn][maxn],sum[maxn][maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,q;
#ifndef ONLINE_JUDGE
	freopen("alice.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	n=read();m=read();q=read();
	int x1,x2,y1,y2;
	for(i=1;i<=q;i++){
		int x=read(),y=read();
		G[x][y]=1;
	}
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			sum[i][j]=sum[i][j-1]+sum[i-1][j]-sum[i-1][j-1]+G[i][j];
	ll ans=0;
	for(x1=1;x1<=n;x1++)
		for(y1=1;y1<=m;y1++)
			for(x2=x1;x2<=n;x2++)
				for(y2=y1;y2<=m;y2++)
					if(sum[x2][y2]-sum[x1-1][y2]-sum[x2][y1-1]+sum[x1-1][y1-1]>0)ans++;
	printf("%lld\n",ans);
	cerr<<ans<<endl;
	return 0;
}

