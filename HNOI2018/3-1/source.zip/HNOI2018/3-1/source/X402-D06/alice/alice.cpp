#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=2e3+10;
const int maxq=3.5e5+10;
int G[maxn][maxn],v[maxn];
int val=0,top=0;
struct node{
	int x,y;
}stk[maxq];
deque <int> pos[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void Insert(int x,int y){
	while(top>=2 && stk[top].x<=x)val-=stk[top].x*(stk[top].y-stk[top-1].y),top--;
	top++;stk[top]=(node){x,y};val+=x*(y-stk[top-1].y);
}
int main(){
	int i,j,k,m,n,q;
#ifndef ONLINE_JUDGE
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
#endif
	n=read();m=read();q=read();
	for(i=1;i<=q;i++){
		int x=read(),y=read();
		G[x][y]=1;pos[y].push_back(x);
	}
	ll ans=0;
	Insert(n+1,0);
	for(i=1;i<=n;i++){
		top=1;val=0;
		for(j=1;j<=m;j++){
			if(!G[i][j]){
				if(v[j])Insert(v[j],j);
				ans+=1ll*val;
			}
			else{
				ans+=1ll*i*j;
				Insert(i,j);
				v[j]=i;pos[j].pop_front();
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}

