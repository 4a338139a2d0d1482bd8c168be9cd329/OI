#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define lowbit(x) (x&-x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int B=710;
const int N=500010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("night.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,m,Q,FLAG,Block;
int cnt,bel[N],tot;
int a[6][N],t[2][N];
int da[N*10],len;
struct Query
{
	int u1,v1,u2,v2;LL ans;
	Query(){ans=0;}
	Query(int u1,int v1,int u2,int v2):u1(u1),v1(v1),u2(u2),v2(v2){ans=0;}
}q[N];
struct query
{
	int l,r,id;
	query(){}
	query(int l,int r,int id):l(l),r(r),id(id){}
}h[N];
inline bool operator<(const query&A,const query&B){return bel[A.l]!=bel[B.l]?bel[A.l]<bel[B.l]:A.r<B.r;}
int nl,nr,nx,ny;
LL nans;
inline void Add(int p,int x,int y){if(!x)return;for(;x<=len;x+=lowbit(x))t[p][x]+=y;}
inline int Sum(int p,int x)
{
	if(!x)return 0;
	int ret=0;
	for(;x;x-=lowbit(x))
		ret+=t[p][x];
	return ret;
}
inline void Dell(int pos)
{
	nans-=Sum(1,a[nx][pos]-1);
	tot--;
	Add(0,a[nx][pos],-1);
	Add(1,a[ny][pos],-1);
}
inline void Delr(int pos)
{
	nans-=tot-Sum(0,a[ny][pos]);
	tot--;
	Add(0,a[nx][pos],-1);
	Add(1,a[ny][pos],-1);
}
inline void Addl(int pos)
{
	Add(0,a[nx][pos],1);
	Add(1,a[ny][pos],1);
	++tot;
	nans+=Sum(1,a[nx][pos]-1);
}
inline void Addr(int pos)
{
	Add(0,a[nx][pos],1);
	Add(1,a[ny][pos],1);
	++tot;
	nans+=tot-Sum(0,a[ny][pos]);
}
inline void Solve()
{
	sort(h+1,h+cnt+1);
	mem(t,0);tot=0;
	nl=h[1].l,nr=h[1].l-1,nans=0;
	For(i,1,cnt)
	{
		while(nl<h[i].l)Dell(nl++);
		while(nl>h[i].l)Addl(--nl);
		while(nr<h[i].r)Addr(++nr);
		while(nr>h[i].r)Delr(nr--);
		q[h[i].id].ans+=nans;
		//printf("(%d %d)id:%d %lld\n",h[i].l,h[i].r,h[i].id,nans);
	}
}
int main()
{
	int u1,v1,u2,v2;
	file();
	read(n),read(m),read(Q);
	if(n>m)swap(n,m),FLAG=1;
	Block=(int)(sqrt(m)+1);
	For(i,1,m)bel[i]=i/Block+1;
	if(FLAG)
	For(i,1,m)For(j,1,n)read(a[j][i]);
	else
	For(i,1,n)For(j,1,m)read(a[i][j]);
	For(i,1,n)For(j,1,m)da[++len]=a[i][j];
	sort(da+1,da+len+1);
	len=unique(da+1,da+len+1)-da-1;
	For(i,1,n)For(j,1,m)a[i][j]=lower_bound(da+1,da+len+1,a[i][j])-da;
	For(i,1,Q)
	{
		read(u1),read(v1),read(u2),read(v2);
		if(FLAG)swap(u1,v1),swap(u2,v2);
		q[i]=Query(u1,v1,u2,v2);
	}
	For(l,1,n)For(r,l,n)
	{
		nx=l,ny=r;
		//printf("%d %d:\n",nx,ny);
		cnt=0;
		For(i,1,Q)
		if(q[i].u1<=l&&r<=q[i].u2)
			For(x,q[i].v1,q[i].v2)
				For(y,x,q[i].v2)
					if(a[l][x]>a[r][y])
						q[i].ans++;
	}
	For(i,1,Q)printf("%lld\n",q[i].ans);
	return 0;
}
