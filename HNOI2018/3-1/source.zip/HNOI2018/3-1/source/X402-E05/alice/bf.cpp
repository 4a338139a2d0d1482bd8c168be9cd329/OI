#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=2010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("alice.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,m,Q,a[N][N],ans;
int main()
{
	int x,y;
	file();
	read(n),read(m),read(Q);
	For(i,1,Q)read(x),read(y),a[x][y]++;
	For(i,1,n)
	{
		For(j,1,m)a[i][j]+=a[i][j-1];
		For(j,1,m)a[i][j]+=a[i-1][j];
	}
	For(x,1,n)For(y,1,m)
	For(u,0,x)For(v,0,y)
		if(a[x][y]-a[x][v]-a[u][y]+a[u][v]>0)
			ans++;
	printf("%d\n",ans);
	return 0;
}
