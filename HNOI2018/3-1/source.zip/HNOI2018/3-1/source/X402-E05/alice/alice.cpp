#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ft first
#define sd second
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=2010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
}
int n,m,Q;
LL ans;
int a[N][N];
vector<int>G[N];
vector<pii>F[N];
int main()
{
	int x,y;
	file();
	read(n),read(m),read(Q);
	For(i,1,Q)read(x),read(y),G[x].pb(y);
	For(i,1,n)sort(G[i].begin(),G[i].end());
	For(i,1,n)
	{
		int now=-1;
		/*
		For(j,0,SZ(G[i])-1)printf("%d ",G[i][j]);
		puts("");
		*/
		For(j,1,m)
		{
			while(now+1<SZ(G[i])&&G[i][now+1]<=j)
				now++;
			int pos=now==-1?0:G[i][now];
			//printf("(%d %d):%d\n",i,j,pos);
			while(!F[j].empty()&&pos>=F[j].back().sd)
				F[j].pop_back();
			int pre=F[j].empty()?0:F[j].back().ft;
			a[i][j]=a[pre][j]+(j-pos)*(i-pre);
			if(pos)F[j].push_back(pii(i,pos));
		}
	}
	/*
	For(i,1,n)
	{
		For(j,1,m)
			printf("%d ",a[i][j]);
		puts("");
	}
	*/
	For(i,1,n)For(j,1,m)ans+=i*j-a[i][j];
	printf("%lld\n",ans);
	cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	assert((double)clock()/CLOCKS_PER_SEC<=0.9);
	return 0;
}
