#include<bits/stdc++.h>
const int maxn=2e3+10;
using namespace std;

template<typename T>inline bool chkmax(T &a,T b){return a<b?a=b,1:0;}
template<typename T>inline bool chkmin(T &a,T b){return a>b?a=b,1:0;}

template<typename T>inline void read(T &x)
{
	x=0;T c=getchar(),p=1;
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}

void File()
{
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);	
}

int n,m,q,ans;
int sum[maxn][maxn];

struct node{
	int x,y;
	bool operator < (const node &ch)const{
		return x==ch.x?y<ch.y:x<ch.x;
	}
}a[maxn];

int main(){
	File();
	read(n);read(m);read(q);
	for(int i=1;i<=q;i++)
		read(a[i].x),read(a[i].y),sum[a[i].x][a[i].y]++;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			int x=i,y=j;
			sum[x][y]+=sum[x-1][y]+sum[x][y-1]-sum[x-1][y-1];
		}
	for(int x1=1;x1<=n;x1++)
		for(int y1=1;y1<=m;y1++)
			for(int x2=x1;x2<=n;x2++)
				for(int y2=y1;y2<=m;y2++)
					if(sum[x2][y2]-sum[x1-1][y2]-sum[x2][y1-1]+sum[x1-1][y1-1]>=1)ans++;
	printf("%d\n",ans);
	return 0;
}


