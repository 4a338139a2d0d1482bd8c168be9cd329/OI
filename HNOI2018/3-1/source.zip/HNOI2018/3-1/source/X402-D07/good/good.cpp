#include<bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define SZ(x) (int((x).size()))

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef pair<int,int> PII;

const int maxn=7;

int n;

int head[maxn],nxt[maxn<<1],to[maxn<<1],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}

bool vis[maxn];

void calc(vector<int>& t,int u,int fa){
    t.pb(u);
    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(v!=fa&&!vis[v]) calc(t,v,u);
    }
}

double dfs(int h){
    double ret=0;
    vector<int> t; calc(t,h,0);

    if(SZ(t)==1) return 1;

    for(int i=0;i<SZ(t);i++){
        int u=t[i];

        vis[u]=1;

        for(int j=head[u];j;j=nxt[j]){
            int v=to[j];
            if(vis[v]) continue;
            ret+=dfs(v);
        }

        vis[u]=0;
    }

    ret/=SZ(t); ret+=SZ(t);
    return ret;
}

int main(){
    freopen("good.in","r",stdin);
    freopen("good.out","w",stdout);

    read(n);
    for(int i=1;i<n;i++){
        int u,v;
        read(u)++; read(v)++;
        ae(u,v); ae(v,u);
    }

    printf("%.4lf\n",dfs(1));
    return 0;
}
