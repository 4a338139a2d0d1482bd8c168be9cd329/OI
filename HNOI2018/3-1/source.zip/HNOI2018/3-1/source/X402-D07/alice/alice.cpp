#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=2010;

int n,m,q;
bool G[maxn][maxn];
int H[maxn][maxn];

struct node{
    int l,r,w;
    node():l(0),r(0),w(0){}
    node(int _l,int _r,int _w):l(_l),r(_r),w(_w){}
} stk[maxn];


int top,sum;
long long ans;

void Modify(int w,int pos){
    while(top&&w>stk[top].w){
        sum-=stk[top].w*(stk[top].r-stk[top].l+1);
        --top;
    }
    stk[top+1]=node(top?stk[top].r+1:1,pos,w);
    ++top; sum+=stk[top].w*(stk[top].r-stk[top].l+1);
}

int main(){
    freopen("alice.in","r",stdin);
    freopen("alice.out","w",stdout);

    read(n); read(m); read(q);

    for(int i=1;i<=q;i++){
        int x,y;
        G[read(x)][read(y)]=1;
    }

    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++) H[i][j]=G[i][j]?i:H[i-1][j];

    for(int i=1;i<=n;i++){
        top=0; sum=0;
        for(int j=1;j<=m;j++){
            Modify(H[i][j],j);
            ans+=sum;
        }
    }

    printf("%lld\n",ans);

    return 0;
}
