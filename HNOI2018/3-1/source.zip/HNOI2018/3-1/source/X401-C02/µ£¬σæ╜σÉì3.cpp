#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define rint register int 
#define mem(a,b) memset(a,(b),a,b) memset(a,(b),sizeof(a))
using namespace std;
inline void read(int &x){
    x=0;int w=1;char ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
const int maxn=50000+10;
int n,sum=0;
int a[maxn],tmp[maxn];
inline void merge(int l,int r){
    if(l==r)return;
    int mid=((l+r)>>1);
    merge(l,mid);
    merge(mid+1,r);
    int i=l,j=mid+1,k=l;
    while(i<=mid&&j<=r){
        if(a[i]<a[j])tmp[k++]=a[i++];
        else tmp[k++]=a[j++],sum+=mid-i+1;
    }
    while(i<=mid)tmp[k++]=a[i++];
    while(j<=r)tmp[k++]=a[j++];
    for(rint e=l;e<=r;e++){
        a[e]=tmp[e];
    }
    return;
}
int main(){
    read(n);
    for(rint i=1;i<=n;i++){
        read(a[i]);
    }
    merge(1,n);	
    printf("%d\n",sum);
    return 0;
}
