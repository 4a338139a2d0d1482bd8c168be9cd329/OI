#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Sint static int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
Temp inline void write(T x){
    T y=10,len=1;
    if(x<0)putchar('-'),x=-x;
    while(y<=x)y=(y<<3)+(y<<1),len++;
    while(len--)y/=10,putchar(x/y+'0'),x%=y;
}
inline void File(){
    freopen("alice.in","r",stdin);
    freopen("alice.out","w",stdout);
}

const int maxn=2000+10;
int n,m,q;
bool a[maxn][maxn];
LL dp[maxn][maxn];

int main(){
	read(n);read(m);read(q);
	for(Rint i=1;i<=q;i++){
		int x,y;read(x);read(y);
		a[x][y]=1;
	}
	for(Rint i=1;i<=n;i++){
		for(Rint j=1;j<=m;j++){
			
		}
	}
    return 0;
}
