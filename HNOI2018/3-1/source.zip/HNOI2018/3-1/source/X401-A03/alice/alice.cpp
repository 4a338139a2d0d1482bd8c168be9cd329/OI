#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#define ll long long
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
void File(){
	freopen("alice.in","r",stdin);
	freopen("alice.out","w",stdout);
}
const int maxn=2000+10;
int n,m,q;
ll sum[maxn][maxn],ans;
bool a[maxn][maxn];
ll get(int x1,int y1,int x2,int y2){
	return sum[x2][y2]-sum[x1-1][y2]-sum[x2][y1-1]+sum[x1-1][y1-1];
}
int main(){
	File();
	scanf("%d%d%d",&n,&m,&q);
	REP(i,1,q){
		int x,y;
		scanf("%d%d",&x,&y);
		a[x][y]=1;
	}
	REP(i,1,n)sum[i][1]=sum[i-1][1]+a[i][1];
	REP(i,1,m)sum[1][i]=sum[1][i-1]+a[1][i];
	REP(i,2,n)REP(j,2,m)
		sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+a[i][j];
	REP(i,1,n)REP(j,1,m){
		ll cnt=0ll;
		REP(ii,i,n){
			if(a[ii][j])break;
			REP(jj,j,m){
				if(get(i,j,ii,jj))break;
				++cnt;
			}
		}
		ans+=(n-i+1)*(m-j+1)-cnt;
	}
	printf("%lld\n",ans);
	return 0;
}
