#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

inline bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
inline bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("alice.in", "r", stdin);
	freopen ("alice.out", "w", stdout);
}

int n, m, q;

const int N = 2010;
vector<int> Point[N];

int L[N], R[N], Ban[N], Blank;
inline void Delete(int x) { L[R[x]] = L[x]; R[L[x]] = R[x]; }

int nl, nr;
#define lson o << 1, l, mid
#define rson o << 1 | 1, mid + 1, r
struct Segment_Tree {
	int Lv[N << 2], Rv[N << 2];
	int Setlv[N << 2], Setrv[N << 2];

	inline void Push_Down(int o) {
		int ls = o << 1, rs = ls | 1;
		if (Setlv[o]) { 
			Lv[ls] = Lv[rs] = Setlv[ls] = Setlv[rs] = Setlv[o];
			Setlv[o] = 0;
		}
		if (Setrv[o]) { 
			Rv[ls] = Rv[rs] = Setrv[ls] = Setrv[rs] = Setrv[o];
			Setrv[o] = 0;
		}
	}
	
	void Build (int o, int l, int r) {
		Lv[o] = 1; Rv[o] = m; Setlv[o] = Setrv[o] = 0;
		if (l == r) return ; int mid = (l + r) >> 1; Build (lson); Build (rson);
	}

	void Update(int o, int l, int r, int ul, int ur, int uv) {
		if (ul <= l && r <= ur) {
			if (uv <= 0) { Lv[o] = Setlv[o] = -uv; }
			else { Rv[o] = Setrv[o] = uv; } 
			return ; 
		}
		Push_Down(o);
		int mid = (l + r) >> 1; 
		if (ul <= mid) Update(lson, ul, ur, uv); 
		if (ur > mid) Update(rson, ul, ur, uv);
	}

	void Query(int o, int l, int r, int qp) {
		if (l == r) { nl = Lv[o]; nr = Rv[o]; return ; } Push_Down(o);
		int mid = (l + r) >> 1; if (qp <= mid) Query(lson, qp); else Query(rson, qp);
	}
} T;

bool Mat[N][N];

inline int DAC(int pos) {
	if (Ban[pos]) return 0;
	Ban[pos] = true;
	static int res, len1, len2;
	Delete(pos);
	nr = 1; nl = m;
	T.Query(1, 1, m, pos);
	len1 = (pos - nl + 1);
	len2 = (nr - pos + 1);

	res = len1 * len2;

	T.Update(1, 1, m, nl, pos, +(pos - 1));
	T.Update(1, 1, m, pos, nr, -(pos + 1));
	return res;
}

int main () {
	File();
	n = read(); m = read(); q = read();
	For (i, 1, q) {
		int x = read(), y = read();
		Point[x].push_back(y);
		Mat[x][y] = true;
	}
	long long ans = 0;
	For (i, 1, n) For (j, 1, m) ans += (n - i + 1) * (m - j + 1);

	For (xl, 1, n) {
		T.Build(1, 1, m); Blank = m; For (i, 0, m) L[i] = i - 1, R[i] = i + 1, Ban[i] = false;
		int last_ans = m * (m - 1) / 2 + m;
		For (xr, xl, n) {
			if (Blank < (int)Point[xr].size()) {
				for (register int pos = R[0]; pos <= m; pos = R[pos]) {
					if (Mat[xr][pos]) last_ans -= DAC(pos);
				}
			} else {
				For (i, 0, Point[xr].size() - 1) last_ans -= DAC(Point[xr][i]);
			}
			ans -= last_ans;
	//		cerr << xl << ' ' << xr << endl;
		}
	}
	printf ("%lld\n", ans);
    return 0;
}
