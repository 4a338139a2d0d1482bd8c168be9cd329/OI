#include <bits/stdc++.h>

using std :: vector;
using std :: pair;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for(; !isdigit(c); c = getchar()) _f |= (c == '-');
	for(;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

typedef long long ll;
typedef pair<int, int> pii;
#define fst first
#define snd second

const int N = 2e3, Q = 3.5e5;

int n, m, q;
vector<int> lx[N + 5];
pii stk[N + 5];

int Deleter(pii *p, int l, int r, int y)
{
	int ret = 0;
	for (int i = r; i > l; --i){
		ret += (p[i-1].snd - p[i].snd) * (p[i].fst - y);
	}
	return ret;
}

int main()
{
	freopen("alice.in", "r", stdin);
	freopen("alice.out", "w", stdout);

	n = read(), m = read(), q = read();
	for (int i = 1; i <= q; ++i){
		int x = read(), y = read();
		lx[x].push_back(y);
	}

	for (int i = 1; i <= m; ++i){
		std::sort(lx[i].begin(), lx[i].end());
	}

	ll ans = 0;
	for (int y = n; y >= 1; --y){
		int top = 0;
		for (int x = m; x >= 1; --x){
			int sz = lx[x].size();
			int dy = sz && lx[x][sz-1] >= y?  lx[x][std::lower_bound(lx[x].begin(), lx[x].end(), y) - lx[x].begin()] : n + 1;

			if (dy <= n){
				if (top && stk[top].fst < dy){
				}
				else if (top){
					top = lower_bound(stk + 1, stk + top + 1, pii(dy, 0)) - stk - 1;
				}
				stk[++top] = pii(dy, x);
			}

			int l = 1, r = top;
			if (dy > n){
				stk[++r] = pii(n + 1, x);
			}
			if (!top || stk[1].fst != y){
				stk[0] = pii(0/***/, m + 1);
				l = 0;
			}

			int del = Deleter(stk, l, r, y);
			ans += (m + 1 - x) * (n + 1 - y) - del;
		}
	}

	printf("%lld\n", ans);
	return 0;
}
