#include <bits/stdc++.h>

bool vis[2005][2005] = {1};

int main()
{
	freopen("alice.in", "w", stdout);

	int n = 2000, m = 2000, q = 100000;
	printf("%d %d %d\n", n, m, q);

	for (int i = 1; i <= q; ++i){
		int x = 0, y = 0;
		while(vis[x][y]){
			x = rand() % n + 1;
			y = rand() % m + 1;
		}
		printf("%d %d\n", x, y);
	}
	return 0;
}
