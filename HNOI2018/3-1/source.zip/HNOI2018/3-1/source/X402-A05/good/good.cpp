#include <bits/stdc++.h>

typedef double lf;

const int N = 5;

int n;
bool G[N + 5][N + 5];

lf ans;

int DFS_init(int u, bool *vis)
{
	vis[u] = true;
	int size = 1; 
	for (int i = 0; i < n; ++i){
		if (G[u][i] && !vis[i]){
			size += DFS_init(i, vis);
		}
	}
	return size;
}

void DFS_calc(int u, lf p)
{
	bool vis[N + 5] = {false};
	int tot = DFS_init(u, vis);
	ans += p * tot;
	if (tot == 1) return ;

	for (int i = 0; i < n; ++i){
		if (vis[i]){
			for (int v = 0; v < n; ++v){
				if (G[i][v]){
					G[i][v] = G[v][i] = false;
					DFS_calc(v, p / tot);
					G[i][v] = G[v][i] = true;
				}
			}
		}
	}
}

int main()
{
	freopen("good.in", "r", stdin);
	freopen("good.out", "w", stdout);

	scanf("%d", &n);
	for (int i = 1; i <= n; ++i){
		int u, v;
		scanf("%d%d", &u, &v);
		G[u][v] = G[v][u] = true;
	}

	DFS_calc(1, 1);

	printf("%.4lf\n", ans);
	return 0;
}
