//2018-2-19
//miaomiao
//
//For test 8 - 9
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000 + 5)

int n, m, Q, nn, num[N * N], a[N][N];
LL f[N][N], sum[N][N], ans[N][N], c[N * N];

inline int Lowbit(int x){return x & (-x);}

void Add(int x, int ad){
	while(x <= nn) c[x] += ad, x += Lowbit(x);
}
LL Sum(int x){
	LL ret = 0;
	while(x > 0) ret += c[x], x -= Lowbit(x);
	return ret;
}

LL Solve(int o1, int o2){
	LL ret = 0;
	For(i, 1, n){
		Add(a[i][o1], 1);
		ret += Sum(nn) - Sum(a[i][o2]);
	}
	For(i, 1, n) Add(a[i][o1], -1);
	
	return ret;
}

int main(){
	freopen("night9.in", "r", stdin);
	freopen("night9.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &Q);
	For(i, 1, n) For(j, 1, m) scanf("%d", &a[i][j]), num[++nn] = a[i][j];

	sort(num + 1, num + nn + 1);
	nn = unique(num + 1, num + nn + 1) - num - 1;
	For(i, 1, n) For(j, 1, m)
		a[i][j] = lower_bound(num + 1, num + nn + 1, a[i][j]) - num;

	For(i, 1, m) For(j, i, m){
	//	cerr<<i<<" "<<j<<endl;
		f[i][j] = Solve(i, j); sum[i][j] = sum[i - 1][j] + f[i][j];
	//	printf("f[%d][%d] = %lld\n", i, j, f[i][j]);
	}
	For(i, 1, m) For(j, i, m)
		ans[i][j] = ans[i][j - 1] + (sum[j][j] - sum[i - 1][j]);
	
	int u1, v1, u2, v2;

	while(Q--){
		scanf("%d%d%d%d", &u1, &v1, &u2, &v2);
		printf("%lld\n", ans[v1][v2]);
	}

	return 0;
}
