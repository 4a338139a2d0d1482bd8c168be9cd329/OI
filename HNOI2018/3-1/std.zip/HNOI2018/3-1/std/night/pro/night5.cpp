//2018-2-19
//miaomiao
//
//For test 10
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (80 + 5)

int r[N][N];
LL b[N][N][N][N], c[N][N][N][N];

int main(){
	freopen("night10.in", "r", stdin);
	freopen("night10.out", "w", stdout);
	
	int n, m, Q;

	scanf("%d%d%d", &n, &m, &Q);
	For(i, 1, n) For(j, 1, m) scanf("%d", &r[i][j]); 
	
	For(i, 1, n) For(j, 1, m) For(u, i, n) For(v, j, m){
		b[i][j][u][v] = b[i][j][u - 1][v] + b[i][j][u][v - 1] - b[i][j][u - 1][v - 1] + (r[i][j] > r[u][v]);
	}
	Forr(i, n, 1) Forr(j, m, 1) For(u, i, n) For(v, j, m){
		c[i][j][u][v] = c[i + 1][j][u][v] + c[i][j + 1][u][v] - c[i + 1][j + 1][u][v] + b[i][j][u][v];
	}

	int u1, v1, u2, v2;

	while(Q--){
		scanf("%d%d%d%d", &u1, &v1, &u2, &v2);
		printf("%lld\n", c[u1][v1][u2][v2]);
	}

	return 0;
}
