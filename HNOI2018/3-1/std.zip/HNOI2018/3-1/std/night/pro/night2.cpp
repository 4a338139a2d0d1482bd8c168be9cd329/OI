//2018-2-18
//miaomiao
//
//For test 6
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int main(){
	freopen("night6.in", "r", stdin);
	freopen("night6.out", "w", stdout);

	int n, m, Q, rt;
	
	scanf("%d%d%d", &n, &m, &Q);
	For(i, 1, n) For(j, 1, m) scanf("%d", &rt);

	int u1, v1, u2, v2;
	while(Q--){
		scanf("%d%d%d%d", &u1, &v1, &u2, &v2);
		long long n = u2 - u1 + 1, m = v2 - v1 + 1;
		long long c = 1ll * n * (n + 1) / 2,
		          d = 1ll * m * (m + 1) / 2;

		printf("%lld\n", c * d - n * m);
	}

	return 0;
}
