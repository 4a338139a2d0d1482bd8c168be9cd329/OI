//2018-2-19
//miaomiao
//
//For test 7
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000 + 5)

int num[N][N];
LL f0[N][N], f1[N][N];

int Calc(int n, int m){
	return ((n + 1) / 2) * (m / 2) + (n / 2) * ((m + 1) / 2);
}

int main(){
	freopen("night7.in", "r", stdin);
	freopen("night7.out", "w", stdout);
	
	int n, m, Q;

	scanf("%d%d%d", &n, &m, &Q);
	For(i, 1, n) For(j, 1, m){
		scanf("%d", &num[i][j]);
		if(num[i][j] == 5) num[i][j] = 0;
		else num[i][j] = 1;
	}

	For(i, 1, n) For(j, 1, m){
		f0[i][j] = f1[i - 1][j] + f1[i][j - 1] - f0[i - 1][j - 1];
		f1[i][j] = f0[i - 1][j] + f0[i][j - 1] - f1[i - 1][j - 1] + Calc(i, j);
//		printf("f[%d][%d] = (%lld %lld)\n", i, j, f0[i][j], f1[i][j]);
	}

	int u1, u2, v1, v2;

	while(Q--){
		scanf("%d%d%d%d", &u1, &v1, &u2, &v2);

		int u = u2 - u1 + 1, v = v2 - v1 + 1;
		printf("%lld\n", num[u1][v1]? f1[u][v]: f0[u][v]);
	}

	return 0;
}
