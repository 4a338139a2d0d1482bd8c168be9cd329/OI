//2018-2-18
//miaomiao
//
//For test 1 - 5
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (10 + 5)
#define M (1000000 + 5)

int n, m, Q, nn, BLO, a[N][M], num[N * M], bnum[M];
LL Ans[M];

struct Qus{
	int id, tl, tr, l, r;
	
	bool operator <(const Qus &rhs)const{
		if(bnum[l] != bnum[rhs.l]) return bnum[l] < bnum[rhs.l];
		return bnum[r] > bnum[rhs.r]; //rever it!
	}	
}qus[M];

struct Bit{
	LL c[M];
	
	inline void Init(){memset(c, 0, sizeof c);}
	inline int Lowbit(int x){return x & (-x);}
	
	void Add(int x, int ad){
		while(x <= nn) c[x] += ad, x += Lowbit(x);
	}
	LL Sum(int x){
		LL ret = 0;
		while(x > 0) ret += c[x], x -= Lowbit(x);
		return ret;
	}

	LL Big(int x){
		return Sum(nn) - Sum(x);
	}
	LL Small(int x){
		return Sum(x - 1);
	}
}t1, t2;

int o1, o2;
LL ans;

void Moy(int lr, int op, int now){
	if(op == 0) op = -1;

	if(!lr){
		if(op == -1){
			ans -= t2.Small(a[o1][now]);
			t1.Add(a[o1][now], op); t2.Add(a[o2][now], op);
		}else{
			t1.Add(a[o1][now], op); t2.Add(a[o2][now], op);
			ans += t2.Small(a[o1][now]);	
		}
	}else{
		if(op == -1){
			ans -= t1.Big(a[o2][now]);
			t1.Add(a[o1][now], op); t2.Add(a[o2][now], op);
		}else{
			t1.Add(a[o1][now], op); t2.Add(a[o2][now], op);
			ans += t1.Big(a[o2][now]);
		}
	}
}

void Solve(){
	int L = 1, R = 0, nl, nr;
	
	ans = 0;
	t1.Init(); t2.Init();

	For(i, 1, Q){
		cerr<<i<<endl;
		nl = qus[i].l, nr = qus[i].r;
		if(o1 < qus[i].tl || o2 > qus[i].tr) continue;
	//	printf("o1 = %d o2 = %d\n", o1, o2);
		
		while(L > nl) Moy(0, 1, --L); while(R < nr) Moy(1, 1, ++R);
		while(L < nl) Moy(0, 0, L++); while(R > nr) Moy(1, 0, R--);
		
		Ans[qus[i].id] += ans;	
	}
}

int main(){
	freopen("night2.in", "r", stdin);
	freopen("night2.out", "w", stdout);

	bool rev = false;

	scanf("%d%d%d", &n, &m, &Q);
	if(n > m) rev = true;

	For(i, 1, n) For(j, 1, m){
		if(!rev) scanf("%d", &a[i][j]), num[++nn] = a[i][j];
		else scanf("%d", &a[j][i]), num[++nn] = a[j][i];
	}
	if(rev) swap(n, m);
	
	sort(num + 1, num + nn + 1);
	nn = unique(num + 1, num + nn + 1) - num - 1;
	For(i, 1, n) For(j, 1, m)
		a[i][j] = lower_bound(num + 1, num + nn + 1, a[i][j]) - num;
	
	int u1, v1, u2, v2;
	For(i, 1, Q){
		scanf("%d%d%d%d", &u1, &v1, &u2, &v2);
		if(rev) swap(u1, v1), swap(u2, v2);
		qus[i] = (Qus){i, u1, u2, v1, v2};
	}

	BLO = sqrt(m);
	For(i, 1, m) bnum[i] = (i - 1) / BLO + 1;
	sort(qus + 1, qus + Q + 1);

	for(o1 = 1; o1 <= n; ++o1) 
	  for(o2 = o1; o2 <= n; ++o2) Solve();

	For(i, 1, Q) printf("%lld\n", Ans[i]);

	return 0;
}
