//2018-1-4
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (70000+5)
#define N (350000+5)

int n, m, q;
vector<int> G[M];

#define lc ch[o][0]
#define rc ch[o][1]

int st[N], tp;

namespace Treap{
    int rt, hn, ch[M][2], fa[M], siz[M], h[M], tag[M];
    LL inf[M], sum[M];

    inline void Calc(int o){
        inf[o] = 1ll * siz[o] * (siz[o]+1) / 2 * (h[o]-h[fa[o]]);
        sum[o] = inf[o] + sum[lc] + sum[rc];
    }

    void Put_tag(int o, int ov){
        tag[o] += ov; h[o] += ov;
        Calc(o);
    }

    void Pushup(int o){
        if(lc) Calc(lc); if(rc) Calc(rc);
        siz[o] = siz[lc] + siz[rc] + 1;
        Calc(o);
    }

    void Pushdown(int o){
        if(!tag[o]) return;
        if(lc) Put_tag(lc, tag[o]); if(rc) Put_tag(rc, tag[o]);
        tag[o] = 0;
    }
    
    void Rotate(int o){
        int f = fa[o], g = fa[f];
        int c = ch[f][1] == o;

        if(g) ch[g][ch[g][1]==f] = o;
        fa[o] = g; fa[f] = o; fa[ch[o][c^1]] = f;
        ch[f][c] = ch[o][c^1]; ch[o][c^1] = f;

        Pushup(f);
        if(f == rt) rt = o;
    }

    int Build(int L, int R){
        if(L > R) return 0;
        
        int o = (L + R) >> 1;
        lc = Build(L, o-1); rc = Build(o+1, R);

        if(lc) fa[lc] = o; if(rc) fa[rc] = o;
        siz[o] = R - L + 1;

        return o;
    }

    void Modify(int o){
        st[tp=1] = o;
        for(int i = o; i != rt; i = fa[i]) st[++tp] = fa[i];
        while(tp) Pushdown(st[tp--]);

        h[o] = 0;
        while(o != rt) Rotate(o);
        Pushup(o);
    }
};

#undef lc
#undef rc

using namespace Treap;

LL calc(int a){
    return 1ll * a * (a+1) / 2;
}

int main(){
    freopen("alice.in", "r", stdin);
    freopen("alice.out", "w", stdout);

    int x, y;
    scanf("%d%d%d", &n, &m, &q);
    For(i, 1, q){
        scanf("%d%d", &x, &y); G[x].pb(y);
    }
    For(i, 1, n) if(G[i].size() != 0) sort(G[i].begin(), G[i].end());

    rt = Build(1, m);

    LL ans = 0;
    For(i, 1, n){
        Put_tag(rt, 1);
        For(j, 0, G[i].size()-1) Modify(G[i][j]);
        ans += sum[rt];
    }

    LL all = calc(n) * calc(m);
    printf("%lld\n", all-ans);

    return 0;
}
