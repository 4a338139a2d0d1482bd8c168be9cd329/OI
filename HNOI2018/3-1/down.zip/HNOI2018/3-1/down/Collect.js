(function() {
    var students = [], classFail = 0, classV = [], subjectList = [], Counter = 0;
    var _examId = $('.bd.topSlt .on').attr('href').match(/examId=(.+)&/)[1];

    function finishAll() {
        var i, t, k, _result = "", final = [];
        _result += '����\t�༶\t�Ա�\t';
        for(i in subjectList) {
            _result += subjectList[i] + '\t';
        }
        _result += '\n';
        for(i in students) final.push([students[i].name, students[i].score, students[i].totscore, students[i].clsname, students[i].gender]);
        final.sort(function(a, b) {
            return b[2] - a[2];
        });

        for(i in final) {
            t = final[i];
            _result += t[0] + '\t' + t[3] + '\t' + (t[4] == 0 ? 'Ů' : '��') + '\t';
            for(k in subjectList) {
                subName = subjectList[k];
                _result += (typeof(t[1][subName]) == "undefined" ? '--' : t[1][subName]) + '\t';
            }
            _result += '\n';
        }
        console.log(_result);
    }
    function getScore(stu) {
        $.ajax({
            url: "/zhixuebao/zhixuebao/personal/studentPkData/",
            method: "GET",
            data: {
                examId: _examId,
                pkId: students[stu].id
            },
            success: function(data) {
                data = JSON.parse(data);
                if(data) {
                    var i, info = data[1], scr;
                    for(i in info['subjectList']) {
                        scr = info['subjectList'][i];
                        students[stu].score[ scr['subjectName'] ] = scr['score'];
                        if(!scr['subjectCode']) students[stu].totscore = scr['score'];
                        if(subjectList.indexOf(scr['subjectName']) == -1) subjectList.push(scr['subjectName']);
                    }
                    if(++Counter == students.length) finishAll();
                }
                else {
                    if(++students[stu].fail <= 3) getScore(stu);
                    else {
                        if(++Counter == students.length) finishAll();
                    }
                }
            },
            error: function() {
                if(++students[stu].fail <= 3) getScore(stu);
                else {
                    if(++Counter == students.length) finishAll();
                }
            }
        });
    }
    function getStu(cls) {
        $.ajax({
            url: '/zhixuebao/zhixuebao/getClassStudent/',
            method: "GET",
            data: {
                classId: classV[cls].id
            },
            success: function(data) {
                data = JSON.parse(data);
                var i, stu;
                for(i in data) {
                    stu = data[i];
                    students.push({
                        id: stu.id, examid: stu.code, clsname: classV[cls].name, name: stu.name, gender: stu.gender, score:{}, totscore: -1, fail: 0
                    });
                    getScore(students.length - 1);
                }
            },
            error: function() {
                if(++classV[cls].fail <= 3) getStu(cls);
            }
        });
    }
    function getClass() {
        $.ajax({
            url: '/zhixuebao/zhixuebao/friendmanage/',
            method: "GET",
            success: function(data) {
                data = JSON.parse(data);
                var i, cls = data.clazzs;
                for(i in cls) {
                    classV.push({id: cls[i]['id'], name: cls[i]['name'], fail: 0});
                    getStu(classV.length - 1);
                }
            },
            error: function() {
                if(++classFail <= 3) getStu();
            }
        });
    }

    console.log("[Ver3.0 Alpha] ��ʼ�ռ������Ժ� -- Code By One");
    getClass();
})();