//2018-2-24
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

struct node{
	int x, y;
	bool operator <(const node &rhs)const{
		if(x != rhs.x) return x < rhs.x;
		return y < rhs.y;
	}
};

map<node, int> ms;

int main(){
	freopen("alice1.in", "w", stdout);
	
	srand(time(NULL));
	int n = rand() % 100 + 866, m = rand() % 200 + 799;
	n *= 2, m <<= 2;
	n = 9, m = 10;

	int q = 73;

	printf("%d %d %d\n", n, m, q);
	For(i, 1, q){
		int x = rand() % n + 1, y = rand() % m + 1;
		while(ms.count((node){x, y})){
		//	cerr<<"??"<<endl;
			x = rand() % n + 1, y = rand() % m + 1;
		}

		node now = (node){x, y};
		ms[now] = true;
		printf("%d %d\n", x, y);
	}

	return 0;
}
