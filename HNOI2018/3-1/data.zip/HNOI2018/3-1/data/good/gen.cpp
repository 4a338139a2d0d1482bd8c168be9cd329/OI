//2018-2-25
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)
int id[N];

int main(){
	freopen("good7.in", "w", stdout);

	srand(time(NULL));
/*
	int n = 67 + 30;
	
	printf("%d\n", n);
	For(i, 0, 65) printf("%d %d\n", i, i + 1);
	For(i, 67, n - 1) printf("%d %d\n", 66, i);
*/

	int n = 32222;
	printf("%d\n", n);
	For(i, 1, n) id[i] = i;
	For(i, 1, 100000) swap(id[rand() % n + 1], id[rand() % n + 1]);
	
	For(i, 2, n) printf("%d %d\n", id[i] - 1, id[rand() % (i - 1) + 1] - 1);

/*
	int m = 186;
	int n = m * m + m + 1;
	printf("%d\n", n);

	For(i, 1, m) printf("0 %d\n", i);
	
	int tmp = m;
	For(i, 1, m){
		For(j, 1, m){
			++tmp; printf("%d %d\n", i, tmp);
		}
	}
*/
	return 0;
}
