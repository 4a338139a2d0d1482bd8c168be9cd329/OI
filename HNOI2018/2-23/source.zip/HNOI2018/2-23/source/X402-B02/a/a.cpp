#include<bits/stdc++.h>
#define rg register
using namespace std;
const int N=4e5+10;
const int M=4e5+10;
map<int,int> ma,mb;
int n,m,a[N];

namespace A{
	void buf(){
		int l=0,r=0;
		scanf("%d",&n);
		
		for(rg int i=1; i<=n; ++i) scanf("%d",&a[i]);
		scanf("%d",&m);	
		for(rg int i=1; i<=m; ++i){
			scanf("%d%d",&l,&r);
			ma.clear();
			int flag=0;
			for(rg int j=l; j<=r; ++j) ma[a[j]]++;
			for(rg int j=l; j<=r; ++j){
				int f=j;
				for(rg int c=1; c<=r-l+1; ++c){
					mb.clear();
					for(rg int p=j; p<=r; p+=c){
						if(a[p]!=a[j]) break;
						mb[a[p]]++;		
					}
					if(ma[a[f]]==mb[a[f]]) {flag=1; break;}
				}
				if(flag)break;
			}
		
			int sz=0;
			for(rg int j=l; j<=r; ++j) sz+=(bool)(ma[a[j]]>=1),ma[a[j]]=0;
			if(flag)printf("%d\n",sz);else printf("%d\n",sz+1);
		}
	}
}

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	A::buf();
}
