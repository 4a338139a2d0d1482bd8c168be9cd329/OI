#include<bits/stdc++.h>
#define ll long long
#define rg register
const int N=2e3+20;
const int M=1e5+10;
using namespace std;
int a[N][N];
int g[5][5];//w g r y
int n,m;
int h[M],p[M];

namespace C{
	void ct(){
		int tp,ps,ct,flag=0;
		for(int i=1; i<=m; ++i){
			scanf("%d%d%d",&tp,&ps,&ct);
			if(tp==1) h[ps]=g[h[ps]][ct];
			if(tp==2) p[ps]=g[p[ps]][ct],flag=1;
		}

		if(!flag){
			ll r1=0,r2=0,r3=0,r4=0;
			for(int i=1; i<=n; ++i){
				r1+=1ll*n*(bool)(h[i]==0);
				r2+=1ll*n*(bool)(h[i]==1);
				r3+=1ll*n*(bool)(h[i]==2);
				r4+=1ll*n*(bool)(h[i]==3);
			}
			printf("%lld %lld %lld %lld\n",r1,r2,r3,r4);
			return;
		}
		
		ll c1=0,c2=0,c3=0,z1=0,z2=0,z3=0,as0=0,as1=0,as2=0,as3=0;
		ll y1=0,y2=0;
		for(int i=1; i<=n; ++i){
			if(h[i]==1) ++c1,++y1;if(h[i]==2)++c2,++y1;if(h[i]==3)++c3,++y1;
			if(p[i]==1) ++z1,++y2;if(p[i]==2)++z2,++y2;if(p[i]==3)++z3,++y2;
		}
		
		as1=1ll*(c1)*(n-y2)+1ll*(z1)*(n-y1);
		as2=1ll*(c2)*(n-y2)+1ll*(z2)*(n-y1);
		as3=1ll*(c3)*(n-y2)+1ll*(z3)*(n-y1);
		
		as1+=1ll*c1*z1;
		as2+=1ll*c2*z2;
		as3+=1ll*c3*(z1+z2+z3)+1ll*z3*(c1+c2+c3)-1ll*c3*z3;
		as0=1ll*n*n-as1-as2-as3;
		printf("%lld %lld %lld %lld\n",as0,as1,as2,as3);
	}
	void buf(){
		g[0][0]=1; g[0][1]=2;
		g[1][0]=1; g[1][1]=3;
		g[2][0]=3; g[2][1]=2;
		g[3][0]=3; g[3][1]=3;
		scanf("%d%d",&n,&m);
		if(n >= 100000) {ct(); return;}	
		
		int tp=0,ps=0,cl=0;
		for(int i=1; i<=m; ++i){
			scanf("%d%d%d",&tp,&ps,&cl);
			if(tp==1){
				for(int j=1; j<=n; ++j) a[ps][j]=g[a[ps][j]][cl];
			}
			if(tp==2){
				for(int j=1; j<=n; ++j) a[j][ps]=g[a[j][ps]][cl];	
			}
			if(tp==3){
				for(int j=1; j<=n; ++j) 
					if(ps-j>=1) a[j][ps-j]=g[a[j][ps-j]][cl];
			}
		}
		int c0=0,c1=0,c2=0,c3=0;
		for(int i=1; i<=n; ++i) 
			for(int j=1; j<=n; ++j){
				c0+=(bool)(a[i][j]==0);
				c1+=(bool)(a[i][j]==1);
				c2+=(bool)(a[i][j]==2);
				c3+=(bool)(a[i][j]==3);
			}
		printf("%d %d %d %d\n",c0,c1,c2,c3);
	}
}

int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	C::buf();
}
