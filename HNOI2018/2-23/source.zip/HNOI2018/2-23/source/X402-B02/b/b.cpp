#include<bits/stdc++.h>
#define rg register
#define ll long long
const int N=1e5+10;
const int mo=1e9+7;
using namespace std;

int n,k,p;
int a[N];
int b[N];
bool vis[N];
bool vit[N];
int ans[N];
map<int,bool> mp;

namespace B{
	void ck(){
		mp.clear();
		int z=0;
		for(int i=1; i<=n; ++i)
			for(int j=i; j<=n; ++j)
				if(j-i+1>=k){
					int cnt=0,z=0;
					for(int p=1; p<=n; ++p) vit[p]=0;
					for(int p=i; p<=j; ++p) vit[a[p]]=1;
					for(int p=1; p<=n; ++p){
						if(vit[p]) ++cnt,z|=(1<<(p-1));
						if(cnt>=k) break;
					}	
					mp[z]=1;
				}
		ans[(int)mp.size()]++;
	}
	void dfs(int x){
		for(int i=1; i<=n; ++i){
			if(vis[i]) continue;
			vis[i]=1;
			a[x]=i; if(x<n) dfs(x+1); else ck();
			vis[i]=0;
		}
	}
	void buf(){
		scanf("%d%d%d",&n,&k,&p);
		if(n<=8){
			dfs(1);
			printf("%d\n",ans[p]);
		}
		else if(k+p-1==n){
			ll ret=1;
			for(int i=1; i<=n; ++i) ret=ret*i%mo;
			printf("%lld\n",ret);
		}
		else puts("0");
	}
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	B::buf();
}
