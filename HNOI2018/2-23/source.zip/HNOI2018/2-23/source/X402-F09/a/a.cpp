#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=400005;
struct node{
    int l,r,id;
}qu[maxn];
int n,q,a[maxn],cnt[maxn],ll[maxn],rr[maxn],L[maxn],R[maxn],inb[maxn],l=1,r=0,ans,tmp,A[maxn],Tmp[maxn];
inline bool cmp(node a,node b){
    return inb[a.l]==inb[b.l]?a.r<b.r:inb[a.l]<inb[b.l];
}
int main(){
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    read(n);
    for(register int i=1;i<=n;++i){
        read(a[i]);
        L[i]=Tmp[a[i]];
        Tmp[a[i]]=i;
        if(L[L[i]]-L[i]==L[i]-i||L[i]==0)ll[i]=ll[L[i]];
        else ll[i]=L[L[i]];
    }
    for(register int i=1;i<=n;++i){
        Tmp[i]=n+1;
    }
    rr[n+1]=n+1;
    for(register int i=n;i>=1;--i){
        R[i]=Tmp[a[i]];
        Tmp[a[i]]=i;
        if(R[R[i]]-R[i]==R[i]-i||R[i]==n+1)rr[i]=rr[R[i]];
        else rr[i]=R[R[i]];
    }
    read(q);
    l=1,r=0;
    for(register int i=1;i<=q;++i){
        read(qu[i].l);
        read(qu[i].r);
        qu[i].id=i;
    }
    int size=sqrt(n);
    for(register int i=1;i<=n;++i){
        inb[i]=(i-1)/size+1;
    }
    sort(qu+1,qu+1+q,cmp);
    for(register int i=1;i<=q;++i){
        for(register int j=l-1;j>=qu[i].l;--j){
            if(!cnt[a[j]]){
                ans++;
                tmp++;
                cnt[a[j]]++;
            }
            else{
                if(rr[j]<=r&&rr[R[j]]>r)ans--;
                cnt[a[j]]++;
            }
        }
        for(register int j=l;j<qu[i].l;++j){
            if(cnt[a[j]]==1){
                ans--;
                tmp--;
                cnt[a[j]]--;
            }
            else{
                if(rr[j]<=r&&rr[R[j]]>r)ans++;
                cnt[a[j]]--;
            }
        }
        for(register int j=r;j>qu[i].r;--j){
            if(cnt[a[j]]==1){
                ans--;
                tmp--;
                cnt[a[j]]--;
            }
            else{
                if(ll[j]>=qu[i].l&&ll[L[j]]<qu[i].l)ans++;
                cnt[a[j]]--;
            }
        }
        for(register int j=r+1;j<=qu[i].r;++j){
            if(!cnt[a[j]]){
                ans++;
                tmp++;
                cnt[a[j]]++;
            }
            else{
                if(ll[j]>=qu[i].l&&ll[L[j]]<qu[i].l)ans--;
                cnt[a[j]]++;
            }
        }
        //cout<<ans<<' '<<tmp<<endl;
        l=qu[i].l;r=qu[i].r;
        A[qu[i].id]=ans>0?-1:0;
        A[qu[i].id]+=tmp+1;
    }
    for(register int i=1;i<=q;++i){
        printf("%d\n",A[i]);
    }
    return 0;
}
