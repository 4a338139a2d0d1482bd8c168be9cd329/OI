#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=2005;
int gra[maxn][maxn],n,m;
long long ans1,ans2,ans3,ans4;
int main(){
    freopen("c.in","r",stdin);
    freopen("c.out","w",stdout);
    read(n);read(m);
    while(m--){
        int opt,pos,col;
        read(opt);read(pos);read(col);
        if(col==0)col=1;
        else col=2;
        if(opt==1){
            for(register int i=1;i<=n;++i){
                if(gra[pos][i]>=3)continue;
                if(gra[pos][i]==col)continue;
                else gra[pos][i]+=col;
            }
        }
        else if(opt==2){
            for(register int i=1;i<=n;++i){
                if(gra[i][pos]>=3)continue;
                if(gra[i][pos]==col)continue;
                else gra[i][pos]+=col;
            }
        }
        else{
            for(register int i=1;i<=pos-1;++i){
                if(gra[i][pos-i]>=3)continue;
                if(gra[i][pos-i]==col)continue;
                else gra[i][pos-i]+=col;
            }
        }
    }
    for(register int i=1;i<=n;++i){
        for(register int j=1;j<=n;++j){
            if(gra[i][j]==0)ans1++;
            else if(gra[i][j]==1)ans2++;
            else if(gra[i][j]==2)ans3++;
            else ans4++;
        }
    }
    printf("%lld %lld %lld %lld\n",ans1,ans2,ans3,ans4);
    return 0;
}
