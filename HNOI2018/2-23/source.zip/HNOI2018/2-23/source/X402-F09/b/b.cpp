#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const long long mod=1e9+7;
const int maxn=1005;
int n,k,p,ans,tot,e;
int a[maxn],tmp[maxn],ma[maxn];
bool check(){	
	for(register int i=1;i<=n-k+1;++i){
        for(register int j=i+k-1;j<=n;++j){
		    for(register int t=i;t<=j;++t){
			    tmp[t]=a[t];
			    sort(tmp+i,tmp+j+1);	
			    int hash=0;
			    for(register int now=i;now<=i+k-1;++now){
                    hash+=(1<<(tmp[now]));	
                }
			    ma[hash]=1;
	        }
        }
    }
	for(register int i=1;i<=600;++i){
        if(ma[i])tot++;
    }
	if(tot==p)return 1;
	else return 0;
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	read(n),read(k),read(p);
	for(register int i=1;i<=n;++i){
		a[i]=i;
	}
	if(n<=8){
		do{	
			memset(ma,0,sizeof(ma));
			tot=0;
			if(check())ans++;
		}while(next_permutation(a+1,a+1+n));
		printf("%d\n",ans);
	}
	else{
		if(k==1&&p==n||k==n&&p==1){
			long long A=1;
			for(register int i=2;i<=n;++i){
                (A*=i)%=mod;
            }
			printf("%lld\n",A);
			return 0;
		}
		if(p>(n*(n+1)/2)){
			printf("0\n");
			return 0;
		}
	}
	return 0;
}
