#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=4e5+10;
inline bool chkmax(int &x,int y){return (y>x)?(x=y,1):0;}
vector<int> vc[maxn];
int sz[maxn];
int a[maxn],f[maxn],pre[maxn];
bool vis[maxn],p[maxn];
struct point{
	int l,r;
	bool operator <(const point &rhs) const{
		return l<rhs.l || (l==rhs.l && r<rhs.r);
	}
}Ques[maxn];
int ans[maxn],sum[11][maxn],g[11][maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
#endif
	int n=read(),Max=0;
	REP(i,1,n){
		a[i]=read();
		chkmax(Max,a[i]);
		vc[a[i]].push_back(i);
		sz[a[i]]++;
		if(sz[a[i]]>1) pre[i]=vc[a[i]][sz[a[i]]-2];
		if(sz[a[i]]>2 && i-vc[a[i]][sz[a[i]]-2]!=vc[a[i]][sz[a[i]]-2]-vc[a[i]][sz[a[i]]-3])
			f[i]=1;
	}
	int q=read();
	if(n<=100 && q<=100){
		while(q--){
			int l=read(),r=read(),num=0;
			REP(i,1,Max) vis[i]=0;
			REP(i,l,r)
				if(!vis[a[i]]) vis[a[i]]=1,num++;
			int flag=0;
			REP(i,1,Max) if(vis[i]){
				flag=1;
				REP(j,l,r) if(a[j]==i && f[j]){
					flag=0;
					break;
				}
				if(flag) break;
			}
			printf("%d\n",num-flag+1);
		}
		return 0;
	}
	else if(Max<=10){
		REP(i,1,n){
			REP(j,1,Max) sum[j][i]=sum[j][i-1],g[j][i]=g[j][i-1];
			sum[a[i]][i]++,g[a[i]][i]+=f[i];
		}
		while(q--){
			int l=read(),r=read(),num=0,flag=0;
			REP(i,1,Max)
				if(sum[i][r]-sum[i][l-1]){
					num++;
					if(g[i][r]-g[i][l-1]==0) flag=1;
				}
			printf("%d\n",num-flag+1);
		}
		return 0;
	}
	else{
		int num=0,sum=0;
		REP(i,1,n){
			if(!vis[a[i]]) vis[a[i]]=p[a[i]]=1,num++,sum++;
			else if(f[i] && p[a[i]]) p[a[i]]=0,sum--;
			ans[i]=num-(sum>0)+1;
		}
		while(q--){
			int l=read(),r=read();
			if(l==1) printf("%d\n",ans[r]);
		}
		return 0;
	}
	REP(i,1,q) Ques[i].l=read(),Ques[i].r=read();
	sort(Ques+1,Ques+q+1);
	return 0;
}
