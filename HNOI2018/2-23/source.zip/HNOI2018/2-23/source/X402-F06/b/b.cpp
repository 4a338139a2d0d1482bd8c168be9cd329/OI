#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int mod=1e9+7,maxn=1e3+10;
int fac(int x){
	int res=1;
	REP(i,2,x) res=1ll*res*i%mod;
	return res;
}
int a[maxn];
int b[maxn];
int f[1<<8];
int n,k,p;
int work(int x){
	int res=0;
	memset(f,0,sizeof(f));
	REP(i,1,n-k+1)
		REP(j,i+k-1,n){
			int len=j-i+1;
			REP(l,i,j) b[l-i+1]=a[l];
			sort(b+1,b+len+1);
			int x=0;
			REP(i,1,k) x|=(1<<b[i]-1);
			if(!f[x]) f[x]=1,res++;
		}
	return res;
}
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return res;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
#endif
	n=read(),k=read(),p=read();
	if((k==1 && n==p) || (k==n && p==1)){
		printf("%d\n",fac(n));
		return 0;
	}
	if(p>1ll*n*(n+1)/2){
		printf("0\n");
		return 0;
	}
	if(p==n-k+1){
		int res=1;
		REP(i,1,n-k) res=2ll*res%mod;
		REP(i,1,k) res=1ll*res*i%mod;
		printf("%d\n",res);
		return 0;
	}
	if(n<=8){
		int ans=0;
		REP(i,1,n) a[i]=i;
		REP(i,1,fac(n)){
			if(work(k)==p){
				ans++;
			}
			next_permutation(a+1,a+n+1);
		}
		printf("%d\n",ans);
		return 0;
	}
	printf("%d\n",ksm(2,n));
	return 0;
}
