#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const LL mod=1e9+7;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("b.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,k,p;
LL fac[N],to[N];
int dp[2][N];
LL x[N];
inline void Add(int&x,int y){x=x+y<mod?x+y:x+y-mod;}
inline void init()
{
	fac[0]=1;
	For(i,1,n)fac[i]=fac[i-1]*i%mod;
}
inline int Solve()
{
	if(p>n*(n+1)/2)return 0;
	dp[k&1][1]=fac[k];
	x[k]=k;
	int flag=-1;
	For(i,k+1,n)
	{
		x[i]=x[i-1]+flag;
		if(x[i]==1)flag=1;
	}
	For(i,k+1,n)
	{
		int now=(i&1)^1,nxt=(i&1);
		For(j,1,k)to[j]=0;
		For(x,1,i)to[min(min(x,i-x+1),min(i-k+1,k))]++;
		For(j,0,p)
		{
			For(x,1,min(p-j,k))Add(dp[nxt][j+x],dp[now][j]*to[x]%mod);
			dp[now][j]=0;
		}
	}
	return dp[n&1][p];
}
int main()
{
	file();
	read(n),read(k),read(p);
	init();
	printf("%d\n",Solve());
	return 0;
}
