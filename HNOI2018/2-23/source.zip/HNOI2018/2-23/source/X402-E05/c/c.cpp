#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}
int n,m,a[5010][5010];
int h[N],l[N],x[N];
LL s[10],hs[10],ls[10],xs[10];
inline void Solve_bf()
{
	int type,pos,col;
	while(m--)
	{
		read(type),read(pos),read(col);
		col++;
		if(type==1)For(i,1,n)a[pos][i]|=col;
		if(type==2)For(i,1,n)a[i][pos]|=col;
		if(type==3)For(i,1,n)if(1<=pos-i&&pos-i<=n)a[i][pos-i]|=col;
	}
	For(i,1,n)For(j,1,n)s[a[i][j]]++;
	For(i,0,3)printf("%lld ",s[i]);
	puts("");
}
inline void Solve()
{
	cerr<<"nice"<<endl;
	int type,pos,col;
	while(m--)
	{
		read(type),read(pos),read(col);
		col++;
		if(type==1)h[pos]|=col;
		if(type==2)l[pos]|=col;
		if(type==3)x[pos]|=col;
	}
	For(i,1,n)hs[h[i]]++,ls[l[i]]++;
	For(i,0,3)For(j,0,3)s[i|j]+=hs[i]*ls[j];
	For(i,0,3)printf("%lld ",s[i]);
	puts("");
}
int main()
{
	file();
	read(n),read(m);
	if(n<=1000&&m<=1000)Solve_bf();
	else Solve();
	return 0;
}
