#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define lc p<<1
#define rc p<<1|1
#define ls l,mid
#define rs mid+1,r
#define lowbit(x) (x&-x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=400010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}
int n,Q,a[N],ans[N];
int pre[N],len[N],pos[N],nxt[N];
multiset<int>S;
multiset<int>::iterator it;
struct Query
{
	int l,r;
	Query(){}
	Query(int l,int r):l(l),r(r){}
}q[N];
vector<int>G[N];
int t[N];
inline void Add(int x,int y){for(;x<=n;x+=lowbit(x))t[x]+=y;}
inline int Sum(int x)
{
	if(!x)return 0;
	int ret=0;
	for(;x;x-=lowbit(x))ret+=t[x];
	return ret;
}
int Min[N<<3];
inline void Build_tree(int l,int r,int p)
{
	Min[p]=inf;
	if(l==r)return;
	int mid=(l+r)>>1;
	Build_tree(ls,lc);Build_tree(rs,rc);
}
inline void Set_tree(int l,int r,int p,int x,int y)
{
	if(l==r){Min[p]=y;return;}
	int mid=(l+r)>>1;
	if(x<=mid)Set_tree(ls,lc,x,y);
	else Set_tree(rs,rc,x,y);
	Min[p]=min(Min[lc],Min[rc]);
}
inline int Query_tree(int l,int r,int p,int x,int y)
{
	if(x<=l&&r<=y)return Min[p];
	int mid=(l+r)>>1,ret=inf;
	if(x<=mid)chkmin(ret,Query_tree(ls,lc,x,y));
	if(y> mid)chkmin(ret,Query_tree(rs,rc,x,y));
	return ret;
}
int main()
{
	int x,y;
	file();
	read(n);
	For(i,1,n)read(a[i]);
	read(Q);
	For(i,1,Q)read(x),read(y),q[i]=Query(x,y),G[y].pb(i);
	Build_tree(1,n,1);
	For(i,1,n)
	{
		int x=a[i];
		if(pre[x])
		{
			if(i-pre[x]+1==len[x]);
			else len[x]=i-pre[x]+1,pos[x]=nxt[pre[x]]+1;
		}
		else pos[x]=1;
		nxt[i]=pre[x];
		if(pre[x])
		{
			Add(pre[x],-1);
			Set_tree(1,n,1,pre[x],inf);
		}
		Add(i,1);
		pre[x]=i;
		Set_tree(1,n,1,i,pos[x]);
		For(j,0,SZ(G[i])-1)
		{
			int l=q[G[i][j]].l;
			int cnt=Sum(n)-Sum(l-1);
			ans[G[i][j]]=cnt+(Query_tree(1,n,1,l,i)>l);
		}
	}
	For(i,1,n)printf("%d\n",ans[i]);
	return 0;
}
