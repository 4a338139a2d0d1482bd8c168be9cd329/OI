/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-23 10:00
#
# Filename: a.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 400010;

int n, a[maxn], q;
bool f[maxn];

int main()
{
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    scanf("%d", &n); 
    REP(i, 1, n) scanf("%d", &a[i]);
    scanf("%d", &q);
    REP(i, 1, q)
    {
        int l, r, sum = 0;
        scanf("%d%d", &l, &r);
        mem(f);
        bool flag = false;
        REP(i, l, r)
            if ( f[a[i]] == false ) 
            {
                f[a[i]] = true;
                ++ sum;
            }
        mem(f);
        REP(i, l, r)
        {
            if ( f[a[i]] == false ) 
            {
                f[a[i]] = true;
                REP(j, 1, r - l + 1)
                {
                    int k = j;
                    while ( a[i + k] == a[i] && i + k <= r ) 
                    {
                        k += k; 
                    }
                    REP(t, k - j + 1, r - i)
                    {
                        if ( a[i + t] == a[i] ) 
                        {
                            goto no;
                        }
                    }
                    flag = true;
                    goto yep;
                }
            }
no:;
        }
yep:;
        if ( flag == true ) printf("%d\n", sum);
        else printf("%d\n", sum + 1);
    }
    return 0;
}

