/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-02-23 08:38
#
# Filename: c.cpp
#
# CopyRight 
#
#
# 如果你喜欢我的代码的话，可以通过我的博客：ljf-cnyali.cn来支持我的学习哦！
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

const int maxn = 1010;
const int maxm = 100010;

int n, m, a[maxn][maxn], sum[5];

int Color(int x, int color)
{
    if ( color == 2 ) 
    {
        if ( x == 1 ) { -- sum[x]; ++ sum[color]; return color; }
        if ( x == 2 ) { return x; }
        if ( x == 3 ) { return 3; }
        if ( x == 4 ) { -- sum[x]; ++ sum[3]; return 3; }
    }
    else
    {
        if ( x == 1 ) { -- sum[x]; ++ sum[color]; return color; }
        if ( x == 2 ) { -- sum[x]; ++ sum[3]; return 3; }
        if ( x == 3 ) { return 3; }
        if ( x == 4 ) { return x; }
    }
    return 0;
}

void PF()
{
    int type[maxm], pos[maxm], color[maxm];
    bool flag1 = true, flag2 = true;
    REP(i, 1, m) 
    {
        scanf("%d%d%d", &type[i], &pos[i], &color[i]);
        if ( type[i] != 1 ) flag1 = false;
        if ( color[i] != 0 ) flag2 = false;
    }
    if ( flag1 == true ) 
    {
        int sum1[maxm], sum2[maxm];
        mem(sum1); mem(sum2);  
        REP(i, 1, m)
        {
            if ( color[i] == 0 ) sum1[pos[i]] ++;
            else sum2[pos[i]] ++;
        }
        REP(i, 1, m)
        {
            if ( sum1[i] && sum2[i] ) sum[3] += n;
            if ( sum1[i] && !sum2[i] ) sum[2] += n;
            if ( !sum1[i] && sum2[i] ) sum[4] += n;
            if ( !sum1[i] && !sum2[i] ) sum[1] += n;
        }
        REP(i, 1, 4)
        {
            printf("%d ", sum[i]);
        }
        puts("");
    }
}

int main()
{
    freopen("c.in", "r", stdin);
    freopen("c.out", "w", stdout);
    scanf("%d%d", &n, &m); 
    if ( n <= 1000 && m <= 1000 ) 
    {
        sum[1] = n * n;
        REP(i, 1, n) REP(j, 1, n) a[i][j] = 1;
        REP(t, 1, m)
        {
            int type, pos, color;
            scanf("%d%d%d", &type, &pos, &color);
            color = color == 0 ? 2 : 4;
            if ( type == 1 ) 
            {
                REP(j, 1, n) a[pos][j] = Color(a[pos][j], color);
            }
            if ( type == 2 ) 
            {
                REP(i, 1, n) a[i][pos] = Color(a[i][pos], color);
            }
            if ( type == 3 )
            {
                REP(i, 1, n) 
                {
                    if ( pos - i > n || pos - i < 1 ) continue ;
                    a[i][pos - i] = Color(a[i][pos - i], color);
                }
            }
        }
        REP(i, 1, 2) printf("%d ", sum[i]);
        printf("%d %d\n", sum[4], sum[3]);
        return 0;
    }
    PF();
    return 0;
}

