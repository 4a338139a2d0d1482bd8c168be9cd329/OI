#include<bits/stdc++.h>
using namespace std;
const int maxn=(int)5e2+10;
int a[maxn],n,q,f[maxn],vis[maxn],len;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	for(register int i=1;i<=n;++i)scanf("%d",&a[i]);
	cin>>q;
	int l,r;
	while(q--){
		scanf("%d%d",&l,&r);
		int ans=0;
		memset(vis,0,sizeof(vis));
		for(register int i=l;i<=r;++i){
			int k=a[i];
			if(!vis[i])++ans;
			vis[i]=1;
			for(register int j=i+1;j<=r;++j){
				if(k==a[j]){
					vis[j]=1;
					int dis=j-i;
					int ll=j+dis;
					while(ll<=r&&a[ll]==a[j])vis[ll]=1,ll+=dis;
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
