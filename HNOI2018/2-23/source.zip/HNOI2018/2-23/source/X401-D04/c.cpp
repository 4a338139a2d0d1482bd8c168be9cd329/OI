#include<bits/stdc++.h>
using namespace std;
const int maxn=(int)1e3+10;
const int maxm=(int)1e5+10;
typedef long long ll;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch))x=x*10+ch-48,ch=getchar();
	return x*f;
}
int cl[maxn][maxn],n,m;
ll ans[4];
struct query{
	int Type,Pos,Color;
}q[maxm];
void dye(int x,int y,int color){
	if(cl[x][y]==color)return;
	if(!cl[x][y])cl[x][y]=color;
	else cl[x][y]=3;
}
void Dye(int type,int pos,int color){
	switch(type){
		case 1:{
			for(register int i=1;i<=n;++i)dye(pos,i,color);
			break;
		}
		case 2:{
			for(register int i=1;i<=n;++i)dye(i,pos,color);
			break;
		}
		case 3:{
			for(register int i=1;i<pos;++i)dye(i,pos-i,color);
		}
	}
}
void cal1(){
	for(register int i=1;i<=n;++i)for(register int j=1;j<=n;++j)++ans[cl[i][j]];
}
void bf1(){
	for(register int i=1;i<=m;++i)Dye(q[i].Type,q[i].Pos,q[i].Color+1);
	cal1();
	for(register int i=0;i<=3;++i)printf("%lld ",ans[i]);
}
int Dye2[maxm];
void bf2(){
	for(register int i=1;i<=m;++i){
		if(q[i].Color+1==Dye2[q[i].Pos])continue;
		if(!Dye2[q[i].Pos])Dye2[q[i].Pos]=q[i].Color+1;
		else Dye2[q[i].Pos]=3;
	}
	for(register int i=1;i<=n;++i)ans[Dye2[i]]+=n;
	for(register int i=0;i<=3;++i)printf("%lld ",ans[i]);
}
int hen[maxm],shu[maxm];
int ans1[4],ans2[4];
void bf3(){
	for(register int i=1;i<=m;++i){
		if(q[i].Type==1){
			if(q[i].Color+1==hen[q[i].Pos])continue;
			if(!hen[q[i].Pos])hen[q[i].Pos]=q[i].Color+1;
			else hen[q[i].Pos]=3;
		}
		if(q[i].Type==2){
			if(q[i].Color+1==shu[q[i].Pos])continue;
			if(!shu[q[i].Pos])shu[q[i].Pos]=q[i].Color+1;
			else shu[q[i].Pos]=3;
		}
	}
	for(register int i=1;i<=n;++i)++ans1[hen[i]];
	for(register int i=1;i<=n;++i){
		if(shu[i]==3)ans[3]+=n;
		if(shu[i]==2){
			ans[3]+=(ans1[3]+ans1[1]);
			ans[2]+=(n-ans1[3]-ans1[1]);
		}
		if(shu[i]==1){
			ans[3]+=(ans1[3]+ans1[2]);
			ans[1]+=(n-ans1[3]-ans1[2]);
		}
		if(shu[i]==0){
			for(register int j=0;j<=3;++j)ans[j]+=ans1[j];
		}
	}
	for(register int j=0;j<=3;++j)printf("%lld ",ans[j]);
}
void bf4(){
}
bool flag1=true,flag2=true,flag3=true;
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	n=read();m=read();
	for(register int i=1;i<=m;++i){
		q[i].Type=read(),q[i].Pos=read(),q[i].Color=read();
		if(q[i].Type>=2)flag1=false;
		if(q[i].Type>2)flag2=false;
		if(q[i].Color)flag3=false;
	}
	if(n<=1000&&m<=1000)bf1();
	else if(flag1)bf2();
	else if(flag2)bf3();
	else if(flag3)bf4();
	else{
		srand(time(NULL));
		cout<<rand()<<" "<<rand()<<" "<<rand()<<" "<<rand()<<endl;
	}return 0;
}
