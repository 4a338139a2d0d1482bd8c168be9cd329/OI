#include<bits/stdc++.h>
using namespace std;
const int maxn=(int)1e5+10,mod=(int)1e9+7;
const int maxk=25;
int f[maxk],g[maxk],h[maxn],n,q,p;
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>n>>k>>p;
	if(n==k&&p==1||k==1&&p==n){
		int Ans=1;
		for(register int i=2;i<=n;++i)Ans=(Ans*i)%mod;
		cout<<Ans%mod<<endl;
		return 0;
	}
	srand(time(NULL));
	cout<<rand()%mod<<endl;
	return 0;
}

