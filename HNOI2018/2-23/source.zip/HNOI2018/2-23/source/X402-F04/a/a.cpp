//2018-2-23
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (100000 + 5)

int a[N], w[N], v[N], sum[N];

int main(){
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
	
	int n, l, r, q;
	scanf("%d", &n);
	int h = 0;
	For(i, 1, n){
	    scanf("%d", &a[i]); h = max(h,a[i]);
	}

	scanf("%d", &q);
	while(q--){
		int ans = 0;
		scanf("%d%d", &l, &r);
		For(i, l, r){
			if(v[a[i]] != q+1){ans++;v[a[i]]=q+1;}
			w[a[i]]++;
		}
		int d = 1;
		For(j, 1, r - l){
			sum[a[l]] = 1;
			For(i, l + j, r){
				if(a[i] == a[i-j]) sum[a[i]]++;
				else{
					if(w[a[i-j]] == sum[a[i-j]]){
						d = 0; break;
					}
					sum[a[i-j]]=0; sum[a[i]]=1;
				}
			}
			if(sum[a[r]]==w[a[r]]){d=0;sum[a[r]]=0;}
		}
		if(r==l) d = 0;
		ans += d;
		printf("%d\n", ans);

		For(i, l, r) w[a[i]] = 0;
	}

	return 0;
}
