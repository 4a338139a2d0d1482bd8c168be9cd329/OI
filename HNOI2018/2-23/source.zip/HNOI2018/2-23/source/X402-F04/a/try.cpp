//2018-2-23
//miaomiao
//Read()
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (100 + 5)
#define N (400000 + 5)

int n, m, Q, a[N], cnt[M][N], id[M][N], id2[M][N];

void Bf(){
	For(i, 1, n){
		For(j, 1, m) cnt[j][i] = cnt[j][i - 1];
		++cnt[a[i]][i];
	}
	For(i, 1, m){
		int len = -1, lst = -1, tmp = 1;

		For(j, 1, n) if(a[j] == i){
			id[i][j] = tmp;
			if(lst == -1){
				lst = len = j; continue;
			}
			if(j - lst == len){
				len = j - lst; lst = j; continue;
			}
			
			id2[i][j] = id[i][j]; id[i][j] = ++tmp;
		}
	}

	int l, r, ans = 0;
	bool flag;

	while(Q--){
		scanf("%d%d", &l, &r);
		
		flag = false;
		For(i, 1, m) if(cnt[i][r] - cnt[i][l - 1]){
			++ans; if(flag) continue;
			
			if(id[i][r] == id[i][l]) flag = true;
			else if(id2[i][r] == id[i][l]) flag = true;
		}
		if(flag) --ans;

		printf("%d\n", ans);
	}
}

int main(){
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
	
	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &a[i]), m = max(m, a[i]);
	scanf("%d", &Q);
	
	if(m <= 100) Bf();
	else{
	}

	return 0;
}
