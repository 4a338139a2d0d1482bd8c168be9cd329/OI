//2018-2-23
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000 + 5)
const int P = 1e9 + 7;

int fac(int n){
	int ret = 1;
	For(i, 1, n) ret = 1ll * ret * i % P;
	return ret;
}

int n, m, p, ans, a[N], tmp[N];
bool use[N], vis[1 << 9];

int Calc(){
	memset(vis, 0, sizeof vis);
	
	int tn, now, ret = 0;
	For(l, 1, n) For(r, l + m - 1, n){
		tn = now = 0;
		For(i, l, r) tmp[++tn] = a[i];
		sort(tmp + 1, tmp + tn + 1);
		For(i, 1, m) now |= 1 << (tmp[i] - 1);
		
		if(!vis[now]){
			++ret; vis[now] = true;
		}
	}

	return ret;
}

void Dfs(int now){
	if(now > n){
		if(Calc() == p) ++ans;
		return;
	}

	For(i, 1, n) if(!use[i]){
		use[i] = true; a[now] = i;
		Dfs(now + 1);
		use[i] = false;
	}
}

void Bf(){
	Dfs(1);
	printf("%d\n", ans);
}

int main(){
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &p);
	if(n <= 8) Bf();
	else{
		if(m == 1 && p == n) printf("%d\n", fac(n));
		else if(m == n && p == 1) printf("%d\n", fac(n));
		else if(p > n * (n - 1) / 2) printf("0\n");
		else{
			
		}
	}

	return 0;
}
