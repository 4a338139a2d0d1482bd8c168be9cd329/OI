//2018-2-23
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (1000 + 5)
#define N (100000 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

int n, m, mc[M][M];

void Add(int &me, int av){
	if(me == av || me == 3) return;
	me += av; //printf("%d -> %d\n", me - av, me);
}

void Bf(){
	int type, pos, col;

	while(m--){
		scanf("%d%d%d", &type, &pos, &col);
		if(type == 1){
			For(i, 1, n) Add(mc[pos][i], col + 1);
		}else if(type == 2){
			For(i, 1, n) Add(mc[i][pos], col + 1);
		}else{
			//++pos;
			For(i, 1, n)
				if(pos - i > 0 && pos - i <= n)
					Add(mc[i][pos - i], col + 1);
		}
	}

	int ans[5] = {0};
	For(i, 1, n) For(j, 1, n) ++ans[mc[i][j]];
	printf("%d %d %d %d\n", ans[0], ans[1], ans[2], ans[3]);
}

struct Qus{
	int type, pos, col;
}qus[N];

int a1[N], a2[N];
void Cheat1(){
	For(i, 1, m) Add(a1[qus[i].pos], qus[i].col + 1);
	
	LL ans[5] = {0};
	For(i, 1, n) ans[a1[i]] += n;
	printf("%lld %lld %lld %lld\n", ans[0], ans[1], ans[2], ans[3]);
}

void Cheat2(){
	For(i, 1, m)
		if(qus[i].type == 1) Add(a1[qus[i].pos], qus[i].col + 1);
	For(i, 1, m)
		if(qus[i].type == 2) Add(a2[qus[i].pos], qus[i].col + 1);
	
	LL tot11, tot12, tot21, tot22, tot31, tot32, ans[5] = {0};
	
//Calc 1
	tot11 = 0, tot12 = 0;
	For(i, 1, n) if(a1[i] == 1) ++tot11;
	For(i, 1, n) if(a2[i] == 1) ++tot12;
	ans[1] += 1ll * n * (tot11 + tot12) - 1ll * tot11 * tot12;
//Calc 2
	tot21 = 0, tot22 = 0;
	For(i, 1, n) if(a1[i] == 2) ++tot21;
	For(i, 1, n) if(a2[i] == 2) ++tot22;
	ans[2] += 1ll * n * (tot21 + tot22) - 1ll * tot21 * tot22;
//Calc 3
	tot31 = 0, tot32 = 0;
	For(i, 1, n) if(a1[i] == 3) ++tot31;
	For(i, 1, n) if(a2[i] == 3) ++tot32;
	ans[3] += 1ll * n * (tot31 + tot32) - 1ll * tot31 * tot32;

//Calc 1 + 2
	ans[3] += tot11 * tot22;
	scanf("%d%d", &n, &m);
	ans[1] -= tot11 * tot22; ans[2] -= tot11 * tot22;
//Calc 2 + 1
	ans[3] += tot21 * tot12;
	ans[1] -= tot21 * tot12; ans[2] -= tot21 * tot12;
//other
	ans[1] -= tot11 * tot32 + tot12 * tot31;
	ans[2] -= tot21 * tot32 + tot22 * tot31;
	
	ans[0] = 1ll * n * n - ans[1] - ans[2] - ans[3];
	printf("%lld %lld %lld %lld\n", ans[0], ans[1], ans[2], ans[3]);
}

int sum1[N], sum2[N];
bool vis[N << 1];

void Getlr(int pos, int &l, int &r){
	if(pos == n + 1) l = 1, r = n;
	else if(pos <= n) l = 1, r = pos - 1;
	else l = pos - n, r = n;
}

void Cheat0(){
	For(i, 1, m) if(qus[i].type == 1) a1[qus[i].pos] = 1;
	For(i, 1, m) if(qus[i].type == 2) a2[qus[i].pos] = 1;
	For(i, 1, n) sum1[i] = sum1[i - 1] + a1[i], sum2[i] = sum2[i - 1] + a2[i];
	LL ans = 1ll * n * (sum1[n] + sum2[n]) - 1ll * sum1[n] * sum2[n];

	int l, r;
	For(i, 1, m) if(qus[i].type == 3 && !vis[qus[i].pos]){
		vis[qus[i].pos] = true;
		Getlr(qus[i].pos, l, r);
		
		ans += r - l + 1;
		ans -= (sum1[r] - sum1[l - 1]) + (sum2[r] - sum2[l - 1]);
	}

	printf("%lld %lld 0 0\n", 1ll * n * n - ans, ans);
}

int main(){
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);
	
	Read(n); Read(m);
	if(n <= 1000 && m <= 1000){Bf(); return 0;}
	
	bool ok1 = true, ok2 = true, ok0 = true;
	For(i, 1, m){
		Read(qus[i].type), Read(qus[i].pos), Read(qus[i].col);
		
		if(qus[i].type != 1) ok1 = false;
		if(qus[i].type == 3) ok2 = false;
		if(qus[i].col) ok0 = false;
	}

	if(ok1){Cheat1(); return 0;}
	if(ok2){Cheat2(); return 0;}
	if(ok0){Cheat0(); return 0;}

	return 0;
}
