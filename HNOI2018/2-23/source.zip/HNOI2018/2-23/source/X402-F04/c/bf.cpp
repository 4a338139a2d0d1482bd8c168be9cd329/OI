//2018-2-23
//miaomiao
//Read()
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (1000 + 5)
#define N (100000 + 5)

int n, m, mc[M][M];

void Add(int &me, int av){
	if(me == av || me == 3) return;
	me += av; //printf("%d -> %d\n", me - av, me);
}

void Bf(){
	int type, pos, col;

	while(m--){
		scanf("%d%d%d", &type, &pos, &col);
		if(type == 1){
			For(i, 1, n) Add(mc[pos][i], col + 1);
		}else if(type == 2){
			For(i, 1, n) Add(mc[i][pos], col + 1);
		}else{
			//++pos;
			For(i, 1, n)
				if(pos - i > 0 && pos - i <= n)
					Add(mc[i][pos - i], col + 1);
		}
	}

	int ans[5] = {0};
	For(i, 1, n) For(j, 1, n) ++ans[mc[i][j]];
	printf("%d %d %d %d\n", ans[0], ans[1], ans[2], ans[3]);
}

int main(){
	freopen("c.in", "r", stdin);
	freopen("c2.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	Bf();

	return 0;
}
