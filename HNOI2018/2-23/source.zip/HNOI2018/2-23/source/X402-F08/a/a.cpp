#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<map>
#include<vector>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=400000+100;
int n,m,tot;
int a[maxn],b[maxn],ma[maxn],pd[maxn];
vector<int>s[maxn];
vector<int>d[maxn];

inline void file() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void init() {
	read(n);
	For (i,1,n) read(a[i]),b[i]=a[i];
	sort(b+1,b+n+1);
	For (i,1,n) if (!ma[b[i]]) ma[b[i]]=++tot;
	For (i,1,n) a[i]=ma[a[i]];
	read(m);
}

inline void solve1() {
	while (m--) {
		int l,r,cnt=0,flag=0; read(l); read(r);
		For (i,1,tot) { s[i].clear(); ma[i]=0; }
		For (i,l,r) {
			s[a[i]].push_back(i);
			if (!ma[a[i]]) {
				cnt++; ma[a[i]]=1;
			}
		}
		For (i,1,tot)
			if (s[i].size()) {
				if (s[i].size()<=2) {
					flag=1; break;
				}
				int d=s[i][1]-s[i][0],f=1;
				For (j,2,s[i].size()-1)
					if (s[i][j]-s[i][j-1]!=d) {
						f=0; break;
					}
				if (f) {
					flag=1; break;
				}
			}
		if (flag) printf("%d\n",cnt);
		else printf("%d\n",cnt+1);
	}
}

inline void solve2() {
	int cnt=0;
	Set(ma,0);
	For (i,1,n) {
		s[a[i]].push_back(i);
		int ss=s[a[i]].size();
		if (ss==1) { cnt++; pd[a[i]]=1; ma[i]=1; }
		else if (ss==2) ma[i]=1;
		else {
			if (pd[a[i]] &&
			s[a[i]][ss-1]-s[a[i]][ss-2]!=s[a[i]][ss-2]-s[a[i]][ss-3]) {
				pd[a[i]]=0; cnt--;
			}
			if (cnt>0) ma[i]=1;
		}
	}
	For (i,0,n+1) For (j,1,tot+2) d[i].push_back(0);
	For (i,1,n) For (j,1,tot) {
		if (a[i]==j) d[i][j]=d[i-1][j]+1;
		else d[i][j]=d[i-1][j];
	}
	while (m--) {
		int l,r,cntt=0; read(l); read(r);
		For (i,1,tot)
			if (d[r][i]-d[l-1][i]>0) cntt++;
		if (l==1) {
			if (ma[r]) printf("%d\n",cntt);
			else printf("%d\n",cntt+1);
		}
		else printf("%d\n",cntt);
	}
}

int main() {
	file();
	init();
	if (n<=100 && m<=100) {
		solve1();
		return 0;
	}
	solve2();
	return 0;
}
