#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const ll modd=1e9+7;
const int maxn=1000+10;
int n,k,p;
ll jc[maxn];

inline void file() {
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}

int main() {
	file();
	scanf("%d%d%d",&n,&k,&p);
	jc[0]=1;
	For (i,1,n) jc[i]=jc[i-1]*i%modd;
	if (k==1) {
		if (p==n) printf("%lld",jc[n]);
		else printf("0");
		return 0;
	}
	if (k==n) {
		if (p==1) printf("%lld",jc[n]);
		else printf("0");
		return 0;
	}
	if (p==n-k+1) {
		printf("1\n");
		return 0;
	}
	printf("%lld\n",jc[n]);
	return 0;
}
