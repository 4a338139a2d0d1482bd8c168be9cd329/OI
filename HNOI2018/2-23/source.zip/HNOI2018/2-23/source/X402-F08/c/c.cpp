#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=1000+10;
const int maxN=100000+10;
int n,m;
ll cnt[5]={0};
int h[maxN],l[maxN];
int s[maxn][maxn];

inline void file() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline int change(int col1,int col2) {
	if (col1==col2) return col2;
	if (col1==-1) return col2;
	if (col2==-1) return col1;
	if (col1==2 || col2==2) return 2;
	return 2;
}

int main() {
	file();
	read(n); read(m);
	if (n<=1000 && m<=1000) {
		Set(s,-1);
		while (m--) {
			int w,p,col; read(w); read(p); read(col);
			if (w==1) For (i,1,n) s[p][i]=change(s[p][i],col);
			else if (w==2) For (i,1,n) s[i][p]=change(s[i][p],col);
			else if (w==3) For (i,max(p-n,1),min(n,p-1)) s[i][p-i]=change(s[i][p-i],col);
		}
		For (i,1,n) For (j,1,n) cnt[s[i][j]+1]++;
		For (i,0,3) printf("%lld ",cnt[i]);
		return 0;
	}
	int check1=0,check2=0,check3=0;
	Set(h,-1); Set(l,-1);
	For (i,1,m) {
		int w,p,col; read(w); read(p); read(col);
		if (w==1) { check1=1; h[p]=change(h[p],col); }
		else if (w==2) { check2=1; l[p]=change(l[p],col); }
		else if (w==3) { check3=1; continue; }
	}
	if (check1 && !check2 && !check3) {
		For (i,1,n) cnt[h[i]+1]+=(ll)n;
		For (i,0,3) printf("%lld ",cnt[i]);
		return 0;
	}
	if (check1 && check2 && !check3) {
		ll cnth[5]={0},cntl[5]={0};
		For (i,1,n) {
			cnth[h[i]+1]++; cntl[l[i]+1]++;
		}
		For (i,0,3) For (j,0,3)
			cnt[change(i-1,j-1)+1]+=cnth[i]*cntl[j];
		For (i,0,3) printf("%lld ",cnt[i]);
		return 0;
	}
	printf("oo oo oo oo");
	return 0;
}
