#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("a.in", "r", stdin);
	freopen ("a.out", "w", stdout);
}

const int N = 4e5 + 1e3;
int n, q;
int a[N];
vector<int> V[N];

int mr[N];

const int inf = 0x3f3f3f3f;
#define lson o << 1, l, mid
#define rson o << 1 | 1, mid + 1, r
struct Seg1{
	int mxv[N << 2], uv, up;
	Seg1() {Set(mxv, 0);}

	void Update(int o, int l, int r) {
		if (l == r) { mxv[o] = uv; return ; } 
		int mid = (l + r) >> 1; if (up <= mid) Update(lson); else Update(rson); mxv[o] = max(mxv[o << 1], mxv[o << 1 | 1]); }
};
Seg1 T1;

void Calc_mr() {
	For (i, 1, n) V[a[i]].push_back(i);
	For (i, 1, n) {
		V[i].push_back(n + 1);
		Fordown(j, V[i].size() - 2, 0) {
			if (j < (int)V[i].size() - 2) mr[V[i][j]] = V[i][j + 2] - 1;
			else mr[V[i][j]] = n;
			if (j < (int)V[i].size() - 3)
				if (V[i][j] + V[i][j + 2] == 2 * V[i][j + 1]) mr[V[i][j]] = mr[V[i][j + 1]];
		}
	}
	For (i, 1, n) V[i].clear();
}

void Solve1() {
	q = read();
	For (i, 1, q) {
		int l = read(), r = read();
		For (j, l, r) 
			V[a[j]].push_back(j);
		int res = 0, cur = 1;
		For (i, 1, n) 
			if ((int)V[i].size()) {
				++ res; 
				if ((int)(V[i].size()) <= 2) cur = 0; 
				else {
					int gap = 0;
					For (j, 1, V[i].size() - 1) {
						if (!gap) gap = V[i][j] - V[i][j - 1];
						if (gap != V[i][j] - V[i][j - 1]) {gap = -1; break;}
					}
					if (gap != -1) cur = 0;
				}
				V[i].clear();
			}
		printf ("%d\n", res + cur);
	}
}

int maxv = 0;
int bas[N];
void Solve2() {
	For (i, 1, n) V[a[i]].push_back(i);
	q = read();
	For (i, 1, q) {
		int l = read(), r = read();
		int res = 0, cur = 1;
		For (j, 1, maxv) if ((int)V[j].size() && V[j][V[j].size() - 1] >= l) { 
				int pos = lower_bound(V[j].begin(), V[j].end(), l) - V[j].begin(); 
				if (V[j][pos] <= r) { ++ res; if (mr[V[j][pos]] >= r) cur = 0; }
			}
		printf ("%d\n", res + cur);
	}
}

int ans[N];
bool vis[N];
void Solve3() {
	int tot = 0;
	For (i, 1, n) {
		T1.uv = mr[i]; T1.up = a[i];
		T1.Update(1, 1, n);
		int cur = T1.mxv[1] >= i ? 0 : 1;
		if (!vis[a[i]]) {vis[a[i]] = true; ++tot;}
		ans[i] = tot + cur;
	}
	q = read();
	//cout << q << endl;
	For (i, 1, q) {
		int l = read(), r = read();
		printf ("%d\n", ans[r]);
	}
}

int Hash[N];

int main () {
	File();
	n = read();
	For (i, 1, n) {Hash[i] = a[i] = read(); chkmax(maxv, a[i]);}
	sort(Hash + 1, Hash + 1 + n);
	int len = unique(Hash + 1, Hash + 1 + n) - Hash - 1;
	For (i, 1, n) a[i] = lower_bound(Hash + 1, Hash + 1 + len, a[i]) - Hash;

	Calc_mr();
	if (n <= (int)(5e4)) Solve1(); 
	else if (maxv <= 10) Solve2();
	else Solve3();
    return 0;
}
