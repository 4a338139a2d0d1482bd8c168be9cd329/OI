#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

int n, m;

void File() {
	freopen ("c.in", "r", stdin);
	freopen ("c.out", "w", stdout);
}

const int N = 1e3 + 1e2;
int Col[N][N];
int ans[4];

int Paint[4][2] = {
	{1, 2},
	{1, 3},
	{3, 2},
	{3, 3}
};

//white 0 green 1 red 2 yellow 3

int main () {
	File();
	n = read();
	m = read();
	For (q, 1, m) {
		int type = read(), pos = read(), color = read();
		if (type == 1) {
			For (i, 1, n) 
				Col[pos][i] = Paint[Col[pos][i]][color];
		}
		if (type == 2) {
			For (i, 1, n) 
				Col[i][pos] = Paint[Col[i][pos]][color];
		}
		if (type == 3) {
			For (i, 1, n) {
				int j = pos - i; if (j <= 0 || j > n) continue ;
				Col[i][j] = Paint[Col[i][j]][color];
			}
		}
	}
	For (i, 1, n) For (j, 1, n) ++ans[Col[i][j]];

	For (i, 0, 3)
		printf ("%d ", ans[i]);
	putchar ('\n');
    return 0;
}
