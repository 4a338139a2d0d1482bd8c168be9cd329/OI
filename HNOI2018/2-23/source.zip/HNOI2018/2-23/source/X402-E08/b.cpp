#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("b.in", "r", stdin);
	freopen ("b.out", "w", stdout);
}

int n, k, p;

const int N = 10;
int a[N], sum[N], ans, b[N];

bool app[1 << N];

inline bool Judge() {
	int res = 0;
	Set(app, false);
	For (i, 1, n) { 
		int cnt = 0;
		For (j, i, n) {
			b[++ cnt] = a[j];
			if (cnt < k) continue ;
			sort(b + 1, b + 1 + cnt);
			int num = 0; For (q, 1, k) num |= 1 << (b[q] - 1);
			if (!app[num]) {++ res; app[num] = true;}
		}
	}
	return res == p;
}

void Solve1() {
	int fac = 1;
	For (i, 1, n) a[i] = i, fac *= i;
	For (i, 1, fac) {
		if (Judge()) ++ ans;
		next_permutation(a + 1, a + 1 + n);
	}
	printf ("%d\n", ans);
}

long long res = 1;
const long long Mod = 1e9 + 7;

int main () {
	File();
	cin >> n >> k >> p;
	if ((k == 1 && p == n) || (k == n && p == 1)) { For (i, 1, n) (res *= i) %= Mod; return printf("%lld\n", res), 0; }
	if (p > n * (n + 1) / 2) return puts("0"), 0;
	Solve1();
	return 0;
}
