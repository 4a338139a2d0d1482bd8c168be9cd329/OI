#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=rand()%100000+1,m=rand()%100000+1;
	printf("%d %d\n",n,m);
	int op;
	for(int i=1;i<=m;i++){
		op=rand()%3+1;
		if(op==1||op==2)
			printf("%d %d %d\n",op,rand()%n+1,rand()%2);
		else
			printf("%d %d %d\n",op,rand()%(n*2-1)+2,rand()%2);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("c.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
