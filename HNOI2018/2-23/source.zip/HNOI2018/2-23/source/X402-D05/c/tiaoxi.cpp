#include<bits/stdc++.h>
using namespace std;
int main(){
	int l=1,n=300000;
	return 0;
}
