#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
int a[maxn],d[maxn],c[maxn<<1];
void paint(int *A,int p,int x){
	if(!A[p]) A[p]=x+1;
	else if(A[p]==x+1) A[p]=x+1;
	else A[p]=3;
}
bitset<100002> bitr,bitb,r,b,bit,lb,lr;
int main(){
	freopen("c.in","r",stdin);
	freopen("save.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	int op,p,v;
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&op,&p,&v);
		if(op==1) paint(a,p,v);
		else if(op==2) paint(d,p,v);
		else paint(c,p,v);
	}
	for(int i=1;i<=n;i++){
		if(d[i]==1) bitb.set(i-1);
		else if(d[i]==2) bitr.set(i-1);
		else if(d[i]==3) bitb.set(i-1),bitr.set(i-1);
		if(c[i]==1) b.set(i-1);
		else if(c[i]==2) r.set(i-1);
		else if(c[i]==3) b.set(i-1),r.set(i-1);
	}
	long long cntb=0,cntr=0,cnty=0,x;
	for(int i=1;i<=n;i++){
		b=b>>1,r=r>>1;
		if(c[n+i]==1) b.set(n-1);
		else if(c[n+i]==2) r.set(n-1);
		else if(c[n+i]==3) b.set(n-1),r.set(n-1);
		if(a[i]==0){
			lb=b|bitb,lr=r|bitr;
			x=(lb&lr).count();
			cnty+=x;
			cntb+=lb.count()-x;
			cntr+=lr.count()-x;
		}
		else if(a[i]==1){
			x=(r|bitr).count();
			cnty+=x;
			cntb+=n-x;
		}
		else if(a[i]==2){
			x=(b|bitb).count();
			cnty+=x;
			cntr+=n-x;
		}
		else if(a[i]==3)
			cnty+=n;
	}
	long long cntw=n*(long long)n;
	cntw=cntw-cntb-cntr-cnty;
	printf("%lld %lld %lld %lld\n",cntw,cntb,cntr,cnty);
//	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
	cerr<<cntw<<endl;
	return 0;
}
