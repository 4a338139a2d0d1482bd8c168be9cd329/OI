#include<bits/stdc++.h>
using namespace std;
const int maxn=800100;
const long long md=998244353;
int A[maxn],B[maxn],C[maxn];
void paint(int *a,int p,int x){
	if(!a[p]) a[p]=x+1;
	else if(a[p]==x+1) a[p]=x+1;
	else a[p]=3;
}
long long dg[maxn],dr[maxn],dy[maxn];
long long wn[100],rwn[100];
int rev[maxn];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
void csh(int &n){
	int l=1,ws=0;
	while(l<n) l<<=1,ws++;
	n=l;
	for(int i=0;i<n;i++)
		rev[i]=(rev[i>>1]>>1|((i&1)<<(ws-1)));
	for(int i=1;i<=ws;i++){
		wn[i]=powd(3,(md-1)>>i);
		rwn[i]=powd(wn[i],md-2);
	}
}
void NTT(long long *a,int n,int op){
	for(int i=0;i<n;i++)
		if(i<rev[i]) swap(a[i],a[rev[i]]);
	int id=0;
	long long w,t1,t2;
	for(int l=2;l<=n;l<<=1){
		id++;
		for(int i=0;i<n;i+=l){
			w=1;
			for(int j=i;j<i+(l>>1);j++){
				t1=a[j],t2=w*a[j+(l>>1)]%md;
				a[j]=(t1+t2)%md;
				a[j+(l>>1)]=(t1-t2+md)%md;
				w=w*((op==1)?wn[id]:rwn[id])%md;
			}
		}
	}
	if(op==-1){
		w=powd(n,md-2);
		for(int i=0;i<n;i++)
			a[i]=a[i]*w%md;
	}
}
void Mult(long long *a,long long *b,int n){
	static long long dA[maxn],dB[maxn];
	csh(n);
	for(int i=0;i<n;i++)
		dA[i]=a[i],dB[i]=b[i],a[i]=0;
	NTT(dA,n,1);
	NTT(dB,n,1);
	for(int i=0;i<n;i++)
		a[i]=dA[i]*dB[i]%md;
	NTT(a,n,-1);
}
int sumg[maxn],sumr[maxn],sumy[maxn];
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	int op,p,v;
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&op,&p,&v);
		if(op==1) paint(A,p,v);
		else if(op==2) paint(B,p,v);
		else paint(C,p,v);
	}
	static long long dA[maxn],dB[maxn];
	for(int i=0;i<=n*4;i++)
		dA[i]=0,dB[i]=0;

	for(int i=1;i<=n;i++)
		dA[i-1]=(B[i]==1||B[i]==3);
	for(int i=2;i<=n*2;i++)
		dB[i-2]=(C[i]==1||C[i]==3);
	reverse(dA,dA+n);
	Mult(dA,dB,n*2);
	for(int i=1;i<=n;i++)
		dg[i]=dA[n-1+i-1];

	for(int i=0;i<=n*4;i++)
		dA[i]=0,dB[i]=0;

	for(int i=1;i<=n;i++)
		dA[i-1]=(B[i]==2||B[i]==3);
	for(int i=2;i<=n*2;i++)
		dB[i-2]=(C[i]==2||C[i]==3);
	reverse(dA,dA+n);
	Mult(dA,dB,n*2);
	for(int i=1;i<=n;i++)
		dr[i]=dA[n-1+i-1];

	for(int i=0;i<=n*4;i++)
		dA[i]=0,dB[i]=0;

	for(int i=1;i<=n;i++)
		dA[i-1]=B[i]==1;
	for(int i=2;i<=n*2;i++)
		dB[i-2]=C[i]==2;
	reverse(dA,dA+n);
	Mult(dA,dB,n*2);
	for(int i=1;i<=n;i++)
		dy[i]=dA[n-1+i-1];

	for(int i=0;i<=n*4;i++)
		dA[i]=0,dB[i]=0;

	for(int i=1;i<=n;i++)
		dA[i-1]=B[i]==2;
	for(int i=2;i<=n*2;i++)
		dB[i-2]=C[i]==1;
	reverse(dA,dA+n);
	Mult(dA,dB,n*2);
	for(int i=1;i<=n;i++)
		dy[i]+=dA[n-1+i-1];

	for(int i=0;i<=n*4;i++)
		dA[i]=0,dB[i]=0;

	for(int i=1;i<=n;i++)
		dA[i-1]=B[i]==3;
	for(int i=2;i<=n*2;i++)
		dB[i-2]=C[i]==3;
	reverse(dA,dA+n);
	Mult(dA,dB,n*2);
	for(int i=1;i<=n;i++)
		dy[i]-=dA[n-1+i-1];

	for(int i=2;i<=n*2;i++){
		sumg[i]=sumg[i-1]+(C[i]==1||C[i]==3);
		sumr[i]=sumr[i-1]+(C[i]==2||C[i]==3);
		sumy[i]=sumy[i-1]+(C[i]==3);
	}
	int vg=0,vr=0,vy=0;
	for(int i=1;i<=n;i++){
		if(B[i]==1) vg++;
		if(B[i]==2) vr++;
		if(B[i]==3) vy++,vg++,vr++;
	}
	long long cntg=0,cntr=0,cnty=0,cntw,x;
	for(int i=1;i<=n;i++){
		if(A[i]==0){
			x=dy[i]+sumy[n+i]-sumy[i]+vy;
			cnty+=x;
			cntg+=sumg[n+i]-sumg[i]+vg-dg[i]-x;
			cntr+=sumr[n+i]-sumr[i]+vr-dr[i]-x;
		}
		else if(A[i]==1){
			x=sumr[n+i]-sumr[i]+vr-dr[i];
			cnty+=x;
			cntg+=n-x;
		}
		else if(A[i]==2){
			x=sumg[n+i]-sumg[i]+vg-dg[i];
			cnty+=x;
			cntr+=n-x;
		}
		else{
			cnty+=n;
		}
	}
	cntw=n*(long long)n-cntg-cntr-cnty;
	printf("%lld %lld %lld %lld\n",cntw,cntg,cntr,cnty);
	return 0;
}
