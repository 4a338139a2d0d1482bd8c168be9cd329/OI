#include<bits/stdc++.h>
using namespace std;
const long long md=1e9+7;
long long getfac(int n){
	long long res=1;
	for(int i=1;i<=n;i++)
		res=res*i%md;
	return res;
}
int n,k,p;
int a[10];
bool vis[10];
int ans;
bool pd(){
	static priority_queue<int> q;
	int cnt=0;
	for(int i=1;i<=n;i++){
		while(!q.empty()) q.pop();
		for(int j=i;j<=n;j++){
			if(j-i+1<=k)
				q.push(a[j]);
			else{
				if(a[j]<q.top()){
					if(q.top()==a[i]) break;
					q.pop();
					q.push(a[j]);
					cnt++;
				}
			}
			if(j-i+1==k) cnt++;
		}
	}
	if(cnt==p) return 1;
	return 0;
}
void dfs(int w){
	if(w>n){
		ans+=pd();
		return;
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			vis[i]=1;
			a[w]=i;
			dfs(w+1);
			vis[i]=0;
		}
	}
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);
	if(n>8){
		if(k==1&&p==n) printf("%lld\n",getfac(n));
		else if(k==n&&p==1) printf("%lld\n",getfac(n));
		else printf("0\n");
		return 0;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
