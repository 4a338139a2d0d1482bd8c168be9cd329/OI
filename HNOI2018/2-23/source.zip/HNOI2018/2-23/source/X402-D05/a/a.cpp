#include<bits/stdc++.h>
using namespace std;
#define mid ((l+r)>>1)
const int maxn=500100;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
int Max(int x,int y){
	return x>y?x:y;
}
struct node{
	int l,r,id;
}q[maxn];
struct Ret{
	int sum,mx;
}tr[maxn<<2];
bool cmp(const node &A,const node &B){
	return A.l>B.l;
}
int n,m;
int a[maxn],b[maxn],hi[maxn];
int Ans[maxn],nex[maxn];
vector<int> vec[maxn];
Ret Merge(const Ret &A,const Ret &B){
	Ret res;
	res.sum=A.sum+B.sum;
	res.mx=Max(A.mx,B.mx);
	return res;
}
void push_up(int h){
	tr[h]=Merge(tr[h<<1],tr[h<<1|1]);
}
void updata(int h,int l,int r,int p,const Ret &A){
	if(l==r){
		tr[h]=A;
		return;
	}
	if(p<=mid) updata(h<<1,l,mid,p,A);
	else updata(h<<1|1,mid+1,r,p,A);
	push_up(h);
}
Ret Query(int h,int l,int r,int s,int t){
	if(s<=l&&r<=t)
		return tr[h];
	if(t<=mid) return Query(h<<1,l,mid,s,t);
	else if(s>mid) return Query(h<<1|1,mid+1,r,s,t);
	else
		return Merge(Query(h<<1,l,mid,s,mid),Query(h<<1|1,mid+1,r,mid+1,t));
}
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int Maxai=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		vec[a[i]].push_back(i);
		chkmax(Maxai,a[i]);
	}
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&q[i].l,&q[i].r);
		q[i].id=i;
	}
	sort(q+1,q+m+1,cmp);

	int num,r;
	for(int i=1;i<=Maxai;i++){
		num=0;
		for(vector<int>::iterator it=vec[i].begin();it!=vec[i].end();it++)
			b[++num]=*it;
		b[num+1]=n+1;
		r=1;
		for(int j=1;j<=num;j++){
			while(r<num&&b[r+1]-b[r]==b[j+1]-b[j])
				r++;
			hi[b[j]]=b[r+1];
			nex[b[j]]=b[j+1];
		}
	}
	Ret ret;
	r=1;
	for(int i=n;i>=1;i--){
		updata(1,1,n,i,(Ret){1,hi[i]});
		if(nex[i]<=n)
			updata(1,1,n,nex[i],(Ret){0,0});
		while(r<=m&&q[r].l==i){
			ret=Query(1,1,n,1,q[r].r);
			Ans[q[r].id]=ret.sum;
			if(ret.mx<=q[r].r) Ans[q[r].id]++;
			r++;
		}
	}
	for(int i=1;i<=m;i++)
		printf("%d\n",Ans[i]);
	return 0;
}
