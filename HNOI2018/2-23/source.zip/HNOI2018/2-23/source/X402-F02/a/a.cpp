#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=4e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
#define getchar getchar_unlocked
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("a.in","r",stdin);
      freopen("a.out","w",stdout);
  #endif
}
vector<int>q[N];
#define pb push_back
int n,m,a[N],size[N];
void input()
{
	n=read<int>();
	For(i,1,n)a[i]=read<int>();
}
int rig[N];
void init()
{
	For(i,1,n)q[a[i]].pb(i),++size[a[i]];
	int pos;
	For(i,1,n)
	{
		For(j,0,size[i]-1)
		{
			if(j&&q[i][j]<rig[q[i][j-1]])rig[q[i][j]]=rig[q[i][j-1]];
			else
			{
				pos=j+1;
				while(pos<size[i]-1&&q[i][pos+1]-q[i][pos]==q[i][pos]-q[i][pos-1])++pos;
				if(pos>=size[i]-1)rig[q[i][j]]=n+1;
				else rig[q[i][j]]=pos;
			}
		}
	}
	For(i,1,n)
	{
		if(rig[i]>=size[a[i]]-1)rig[i]=n+1;
		else rig[i]=q[a[i]][rig[i]+1]-1;
	}
}
int w[N],max_d,sum,cnt;
namespace sub1
{
	void solve()
	{
		int l,r;
		m=read<int>();
		while(m--)
		{
			l=read<int>();r=read<int>();
			++cnt;sum=0,max_d=0;
			For(i,l,r)if(w[a[i]]^cnt)w[a[i]]=cnt,++sum,cmax(max_d,rig[i]);
			if(max_d>=r)write(sum,'\n');
			else write(sum+1,'\n');
		}
	}
}
namespace sub2
{
	int ans[N];
	void solve()
	{
		For(i,1,n)
		{
			if(!w[a[i]])w[a[i]]=1,++sum,cmax(max_d,rig[i]);
			if(max_d>=i)ans[i]=sum;
			else ans[i]=sum+1;
		}
		int l,r;
		m=read<int>();
		while(m--)
		{
			l=read<int>();r=read<int>();
			write(ans[r],'\n');
		}
	}
}
void work()
{
	if(n<=50000)sub1::solve();
	else sub2::solve();
}
int main()
{
	file();
	input();
	init();
	work();
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
