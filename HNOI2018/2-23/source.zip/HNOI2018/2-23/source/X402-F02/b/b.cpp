#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("b.in","r",stdin);
      freopen("b.out","w",stdout);
  #endif
}
int n,p,k;
void input()
{
	n=read<int>(),k=read<int>(),p=read<int>();
}
const int mo=1e9+7;
namespace sub2
{
	void solve()
	{
		ll ans=1;
		For(i,1,n)ans=ans*1ll*i%mo;
		write(ans,'\n');
	}
}
int a[10],book[10],ans,c[10];
namespace sub1
{
	int cnt,t[10],vis[1<<10],top,l;
	void cal()
	{
		//For(i,1,n)cout<<a[i]<<' ';puts("");
		++cnt;
		int res=0;
		For(i,1,n)
		{
			For(j,i+k-1,n)
			{
				top=0;
				For(v,i,j)c[++top]=a[v];
				sort(c+1,c+top+1);
				l=0;
				For(v,1,k)l|=t[c[v]];
				if(vis[l]^cnt)vis[l]=cnt,++res;
			}
		}
		//cout<<res<<endl;
		if(res==p)++ans;
	}
	void dfs(int dep)
	{
		if(dep>n){cal();return;}
		For(i,1,n)
		{
			if(!book[i])book[i]=1,a[dep]=i,dfs(dep+1),book[i]=0;
		}
	}
	void init()
	{
		t[1]=1;For(i,2,n)t[i]=t[i-1]<<1;
	}
	void solve()
	{
		init();
		dfs(1);
		write(ans,'\n');
	}
}
void work()
{
	if(n<=8)sub1::solve();
	else if((k==1&&p==n)||(k==n&&p==1))sub2::solve();
	else puts("0");
}
int main()
{
	file();
	input();
	work();
	return 0;
}
