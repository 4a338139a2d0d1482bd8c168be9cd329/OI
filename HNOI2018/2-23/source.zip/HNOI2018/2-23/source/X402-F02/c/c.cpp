#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("c.in","r",stdin);
      freopen("c.out","w",stdout);
  #endif
}
int m,n;
int data_type,data_color;
int type[N],pos[N],cl[N];
void input()
{
	data_type=data_color=1;
	n=read<int>(),m=read<int>();
	For(i,1,m)
	{
		type[i]=read<int>(),pos[i]=read<int>(),cl[i]=read<int>()+1;
		if(type[i]==3)data_type=0;
		if(cl[i]!=1)data_color=0;
	}
}
namespace sub1
{
	int mp[1000+5][1000+5];
	int num[5];
	void solve()
	{
		For(k,1,m)
		{
			if(type[k]==1)For(j,1,n)mp[pos[k]][j]|=cl[k];
			else if(type[k]==2)For(j,1,n)mp[j][pos[k]]|=cl[k];
			else if(type[k]==3)For(j,max(1,pos[k]-n),min(pos[k]-1,n))mp[pos[k]-j][j]|=cl[k];
		}
		For(i,1,n)For(j,1,n)++num[mp[i][j]];
		For(i,0,3)write(num[i],' ');
	}
}
namespace sub2
{
	int w[N],h[N];
	ll ww[5],hh[5],num[5];
	void solve()
	{
		ww[0]=n,hh[0]=n;
		For(k,1,m)
		{
			if(type[k]==1)
			{
				--ww[w[pos[k]]];
				w[pos[k]]|=cl[k];
				++ww[w[pos[k]]];
			}
			else if(type[k]==2)
			{
				--hh[h[pos[k]]];
				h[pos[k]]|=cl[k];
				++hh[h[pos[k]]];
			}
		}
		num[3]=1ll*n*ww[3]+1ll*n*hh[3]-ww[3]*hh[3];
		num[3]+=ww[1]*hh[2]+ww[2]*hh[1];
		num[2]=ww[2]*hh[2]+hh[2]*ww[0]+ww[2]*hh[0];	
		num[1]=(ww[0]+ww[1])*(hh[0]+hh[1])-ww[0]*hh[0];
		num[0]=ww[0]*hh[0];
		For(i,0,3)write(num[i],' ');
	}
}
void work()
{
	if(n<=1000)sub1::solve();
	else if(data_type)sub2::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
