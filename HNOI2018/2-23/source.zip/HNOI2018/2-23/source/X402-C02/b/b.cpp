#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=1000+10,Mod=1e9+7;
int n,k,p,res,ans[MAXN],cnt,sum,tmp[MAXN],A[MAXN];
ll fac[MAXN];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void init()
{
	fac[0]=1;
	for(register int i=1;i<MAXN;++i)fac[i]=(fac[i-1]*i)%Mod;
}
inline void bf()
{
	res=0;
	for(register int i=1;i<=n;++i)A[i]=i;
	do{
		sum=0;
		memset(ans,0,sizeof(ans));
		for(register int len=k;len<=n;++len)
			for(register int l=1;l+len-1<=n;++l)
			{
				int r=l+len-1;
				cnt=0;
				for(register int i=l;i<=r;++i)tmp[++cnt]=A[i];
				sort(tmp+1,tmp+cnt+1);
				++sum;
				for(register int i=1;i<=k;++i)ans[sum]|=(1<<tmp[i]-1);
			}
		sort(ans+1,ans+sum+1);
		unique(ans+1,ans+sum+1);
		for(register int i=1;i<=sum;++i)
			if(ans[i]>=ans[i+1])
			{
				sum=i;
				break;
			}
		if(sum==p)res=(res+1)%Mod;
	}while(next_permutation(A+1,A+n+1));
	printf("%d\n",res);
}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	read(n);read(k);read(p);
	init();
	if(k==1&&p==n)printf("%lld\n",fac[n]);
	else if(k==n&&p==1)printf("%lld\n",fac[n]);
	else if(p==n-k+1)printf("%lld\n",fac[k]*qexp(2,p-1)%Mod);
	else if(p>n*(n+1)/2)printf("0\n");
	else bf();
	return 0;
}
