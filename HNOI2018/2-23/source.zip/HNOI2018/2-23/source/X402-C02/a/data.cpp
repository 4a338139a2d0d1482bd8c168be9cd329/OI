#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("a.in","w",stdout);
	srand(time(0));
	int n=400000;
	printf("%d\n",n);
	for(register int i=1;i<=n;++i)printf("%d ",rand()%400000+1);
	int q=400000;
	printf("%d\n",q);
	for(register int i=1;i<=q;++i)
	{
		int r=rand()%n+1;
		int l=rand()%r+1;
		printf("%d %d\n",l,r);
	}
	return 0;
}
