#include<bits/stdc++.h>
using namespace std;
const int MAXN=400000+10;
int n,q,A[MAXN],d,las[MAXN],C1[MAXN],C2[MAXN],ans[MAXN];
struct node{
	int l,r,id;
	inline bool operator < (const node &A) const {
		return r<A.r;
	};
};
node que[MAXN];
vector<int> G[MAXN];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void write(int x,char c)
{
	printf("%d",x);
	putchar(c);
}
inline void chkmax(int &x,int y){x=y>x?y:x;}
inline void chkmin(int &x,int y){x=y<x?y:x;}
inline int lowbit(int x)
{
	return x&(-x);
}
inline void add(int C[],int x,int k)
{
	while(x<MAXN)
	{
		C[x]+=k;
		x+=lowbit(x);
	}
}
inline int sum(int C[],int x)
{
	int res=0;
	while(x>0)
	{
		res+=C[x];
		x-=lowbit(x);
	}
	return res;
}
inline void findlas(int app,int now)
{
	if(app==1)
	{
		las[now]=1;
		return ;
	}
	if(app==2||G[A[now]][app]-G[A[now]][app-1]==G[A[now]][app-1]-G[A[now]][app-2])
	{
		las[now]=las[G[A[now]][app-1]];
		return ;
	}
	las[now]=G[A[now]][app-2]+1;
	add(C2,las[G[A[now]][app-1]],-1);
	add(C2,las[now],1);
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	read(n);
	for(register int i=1;i<=n;++i)read(A[i]);
	read(q);
	for(register int i=1;i<=q;++i)read(que[i].l),read(que[i].r),que[i].id=i;
	sort(que+1,que+q+1);
	for(register int i=1;i<MAXN;++i)G[i].push_back(0);
	int j=1;
	for(register int i=1;j<=q&&i<=n;++i)
	{
		G[A[i]].push_back(i);
		int s=G[A[i]].size()-1;
		add(C2,G[A[i]][s-1]+1,1);
		add(C2,i+1,-1);
		add(C1,G[A[i]][s-1]+1,1);
		add(C1,i+1,-1);
		findlas(s,i);
		while(j<=q&&que[j].r==i)ans[que[j].id]=sum(C1,que[j].l)+(sum(C2,que[j].l)?0:1),++j;
	}
	for(register int i=1;i<=q;++i)write(ans[i],'\n');
	cerr<<clock()/1e6<<endl;
	return 0;
}
