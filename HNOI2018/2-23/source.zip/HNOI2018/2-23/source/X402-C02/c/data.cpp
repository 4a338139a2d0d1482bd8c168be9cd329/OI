#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("c.in","w",stdout);
	srand(time(0));
	int n=rand()%100+1,m=rand()%100+1;
	printf("%d %d\n",n,m);
	for(register int i=1;i<=m;++i)printf("1 %d %d\n",rand()%n+1,rand()%2);
	return 0;
}
