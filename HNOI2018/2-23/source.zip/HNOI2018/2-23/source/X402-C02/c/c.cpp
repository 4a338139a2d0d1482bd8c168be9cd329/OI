#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=100000+10;
int G[1010][1010],n,m,sub1line[MAXN];
ll ans[5];
struct node{
	int opt,pos,col;
};
node que[MAXN];
inline void read(int &x)
{
	int data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
inline void chkmax(int &x,int y){x=y>x?y:x;}
inline void chkmin(int &x,int y){x=y<x?y:x;}
inline void color(int x,int y,int col)
{
	if(x>n||x<1||y>n||y<1)return ;
	if(G[x][y]==0)
	{
		G[x][y]=col;
		return ;
	}
	if(G[x][y]!=col)
	{
		G[x][y]=3;
		return ;
	}
}
inline void bf()
{
	for(register int i=1;i<=m;++i)
	{
		int opt=que[i].opt,pos=que[i].pos,col=que[i].col;
		if(opt==1)
			for(register int i=1;i<=n;++i)color(pos,i,col+1);
		if(opt==2)
			for(register int i=1;i<=n;++i)color(i,pos,col+1);
		if(opt==3)
			for(register int i=1;i<pos;++i)color(i,pos-i,col+1);
	}
	for(register int i=1;i<=n;++i)
		for(register int j=1;j<=n;++j)ans[G[i][j]]++;
	for(register int i=0;i<4;++i)printf("%lld ",ans[i]);
}
inline void sub1()
{
	for(register int i=1;i<=m;++i)
	{
		int pos=que[i].pos,col=que[i].col+1;
		if(sub1line[pos]==0)sub1line[pos]=col;
		else if(sub1line[pos]!=col)sub1line[pos]=3;
	}
	for(register int i=1;i<=n;++i)ans[sub1line[i]]+=n;
	for(register int i=0;i<4;++i)printf("%lld ",ans[i]);
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	read(n);read(m);
	int mark=1;
	for(register int i=1;i<=m;++i)
	{
		read(que[i].opt),read(que[i].pos),read(que[i].col);
		chkmax(mark,que[i].opt);
	}
	if(mark==1)sub1();
	else bf();
	return 0;
}
