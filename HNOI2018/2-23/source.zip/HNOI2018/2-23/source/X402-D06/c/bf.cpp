#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const double Pi=acos(-1.0);
const int maxn=1e5+10;
struct Complex{
	double re,im;
}A[maxn<<2],B[maxn<<2];
Complex operator + (const Complex &lhs,const Complex &rhs){
	return (Complex){lhs.re+rhs.re,lhs.im+rhs.im};
}
Complex operator - (const Complex &lhs,const Complex &rhs){
	return (Complex){lhs.re-rhs.re,lhs.im-rhs.im};
}
Complex operator * (const Complex &lhs,const Complex &rhs){
	return (Complex){lhs.re*rhs.re-lhs.im*rhs.im,lhs.re*rhs.im+lhs.im*rhs.re};
}
ll Col[3][maxn],sum[maxn<<1],Ans[maxn<<1],Sum[4][2];
ll ans[4],r[maxn<<2],N;
inline ll read(){
	ll x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void FFT(Complex P[],ll opt){
	ll i,j,k;
	for(i=0;i<N;i++)if(i<r[i])swap(P[i],P[r[i]]);
	for(i=2;i<=N;i<<=1){
		ll p=i>>1;
		Complex Wi=(Complex){cos(2*Pi/i),opt*sin(2*Pi/i)};
		for(j=0;j<N;j+=i){
			Complex x=(Complex){1,0};
			for(k=0;k<p;k++,x=x*Wi){
				Complex u=P[j+k],v=x*P[j+k+p];
				P[j+k]=u+v;P[j+k+p]=u-v;
			}
		}
	}
}
namespace Solve{
	const int Maxn=2e3+10;
	int mp[Maxn][Maxn],ans[4];
	inline void solve(int n,int q){
		int i,j;
		while(q--){
			int opt=read(),pos=read(),col=read();
			if(opt==1)for(i=1;i<=n;i++)mp[pos][i]|=(1<<col);
			if(opt==2)for(i=1;i<=n;i++)mp[i][pos]|=(1<<col);
			if(opt==3)for(i=1;i<=n;i++)mp[i][pos-i]|=(1<<col);
		}
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				ans[mp[i][j]]++;
		printf("%d %d %d %d\n",ans[0],ans[1],ans[2],ans[3]);
	}
}
int main(){
	ll i,j,k,m,n,q;
#ifndef ONLINE_JUDGE
	freopen("c.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	n=read();q=read();
/*	if(n<=1000 && q<=1000){
		Solve::solve(n,q);
		return 0;
	}
*/	int flag=0;
	while(q--){
		ll opt=read(),pos=read(),col=read();
		Col[opt-1][pos] |= (1<<col);
		if(opt==3)flag=1;
	}
	for(i=1;i<=n;i++){
		Sum[Col[0][i]][0]++;
		Sum[Col[1][i]][1]++;
	}
	ans[0]=Sum[0][0]*Sum[0][1];
	ans[1]=Sum[0][0]*Sum[1][1]+Sum[1][0]*Sum[0][1]+Sum[1][0]*Sum[1][1];
	ans[2]=Sum[0][0]*Sum[2][1]+Sum[2][0]*Sum[0][1]+Sum[2][0]*Sum[2][1];
	ans[3]=n*n-ans[0]-ans[1]-ans[2];
	if(!flag)return printf("%lld %lld %lld %lld\n",ans[0],ans[1],ans[2],ans[3]),0;
	for(j=0;j<n;j++){
		A[j].re=(Col[0][j+1]==0);
		B[j].re=(Col[1][j+1]==0);
	}
	ll cnt=0;m=n+n;
	for(N=1;N<=m;N<<=1)cnt++;
	for(j=0;j<N;j++)r[j]=r[j>>1]>>1 | (j & 1)*(1<<(cnt-1));
	FFT(A,1);FFT(B,1);
	for(j=0;j<N;j++)A[j]=A[j]*B[j];
	FFT(A,-1);
	for(j=0;j<2*n-1;j++)sum[j]=(ll)(A[j].re*1.0/N+0.5);
	for(i=2;i<=2*n;i++){
		if(Col[2][i]==0)continue;
		if(Col[2][i]==1){
			ans[0]-=sum[i-2];
			ans[1]+=sum[i-2];
		}
	}
	printf("%lld %lld %lld %lld\n",ans[0],ans[1],ans[2],ans[3]);
	cerr<<ans[0]<<" "<<ans[1]<<" "<<ans[2]<<" "<<ans[3]<<endl;
	return 0;
}

