#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=1e9+7;
const int maxn=1e3+10;
int fac[maxn],vis[maxn],a[maxn],Vis[(1<<8)+10],tmp[maxn];
int ans=0,K,p,n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline bool chk(){
	int i,j,k;
	memset(Vis,0,sizeof(Vis));
	for(i=1;i<=n-K+1;i++){
		for(j=i+K-1;j<=n;j++){
			for(k=i;k<=j;k++)
				tmp[k-i+1]=a[k];
			sort(tmp+1,tmp+j-i+2);
			int sum=0;
			for(k=1;k<=K;k++)
				sum|=(1<<(tmp[k]-1));
			Vis[sum]=1;
		}
	}
	int cnt=0;
	for(i=0;i<(1<<n);i++)if(Vis[i])cnt++;
	if(cnt==p)return 1;
	else return 0;
}
void dfs(int cur,int tot){
	int i;
	if(cur>tot){
		if(chk())ans++;
		return;
	}
	for(i=1;i<=n;i++){
		if(vis[i])continue;
		a[cur]=i;vis[i]=1;
		dfs(cur+1,tot);
		vis[i]=0;
	}
}
int main(){
	int i,j,k,m;
#ifndef ONLINE_JUDGE
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
#endif
	n=read();K=read();p=read();
	if(n<=8){
		dfs(1,n);
		printf("%d\n",ans);
	}
	else{
		fac[0]=1;
		for(i=1;i<=n;i++)fac[i]=1ll*fac[i-1]*i%mod;
		if((K==1 && p==n) || (K==n && p==1))printf("%d\n",fac[n]);
		else if(p>n*(n+1)/2)printf("0\n");
	}
	return 0;
}

