#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int a[1003][1003],c[100003],d[100003]; long long mo[4],ha[4],w[4];
int main(){
	freopen("c.in","r",stdin); freopen("c.out","w",stdout);
	int n=read(),m=read(),fl,x,y,l,r;
	if (n<=1000&&m<=1000){
		while(m--){
			fl=read(),x=read(),y=read();
			if (fl==1) For(i,1,n) a[x][i]|=(1<<y);
			else if (fl==2) For(i,1,n) a[i][x]|=(1<<y);
			else{
				if (x>n+1) r=n,l=x-n;
				else l=1,r=x-1;
				for(int i=l,j=r;i<=n&&j>=1;++i,--j) a[i][j]|=(1<<y);
			}
		}
		For(i,1,n)
			For(j,1,n) ++w[a[i][j]];
		For(i,0,3) printf("%lld ",w[i]); return 0;
	}
	while(m--){
		fl=read(),x=read(),y=read();
		if (fl==1) c[x]|=(1<<y);
		else d[x]|=(1<<y);
	}
	For(i,1,n) ++mo[c[i]],++ha[d[i]];
	w[0]=mo[0]*ha[0];
	w[1]=mo[1]*ha[0]+ha[1]*mo[0]+mo[1]*ha[1];
	w[2]=mo[2]*ha[0]+ha[2]*mo[0]+mo[2]*ha[2];
	w[3]=(long long)n*n-w[0]-w[1]-w[2];
	For(i,0,3) printf("%lld ",w[i]);
	return 0;
}
