#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=400005;
int a[N],b[N],c[N],d[N],an[N];
struct node{
	int l,r;
}p[N];
int main(){
	freopen("a.in","r",stdin); freopen("a.out","w",stdout);
	int n=read(),q,x,y,z,l,r,ans,f=0,s,ma=0;
	For(i,1,n) a[i]=read(),ma=max(a[i],ma); //q=1;
	q=read();
	if (n<=50000&&q<=50000){
	For(_,1,q){
		//x=25835,y=26104;
		x=read(),y=read();
		ans=0,f=0,s=0;
		memset(b,0,(ma+1)<<2); memset(c,0,(ma+1)<<2);
		For(i,x,y){
			if (!b[a[i]]) ++ans,++s;
			else if (b[a[i]]==2) --s;
			++b[a[i]];
		}
		if (!s){
			For(i,x,y){
				z=a[i];
				if (c[z]==0) c[z]=i;
				else if (c[z]>0){
					l=i-c[z],r=i,s=2;
					while(a[r+l]==z&&r+l<=y) ++s,r+=l;
					if (s==b[z]) {f=1; break;}
					c[z]=-1;
				}
			}
			if (!f) printf("%d\n",ans+1);
			else printf("%d\n",ans);
		}
		else printf("%d\n",ans);
	}
	return 0;
	}
	For(i,1,q) p[i].l=read(),p[i].r=read(),f=(p[i].l==1)?0:1;
	if (!f){
		s=0;
		For(i,1,n){
			x=a[i]; ++b[x]; an[i]=an[i-1];
			if (b[x]==1){
				if (s||i==1) ++an[i];
				++s; c[x]=i;
			}
			else if (b[x]==2) d[x]=i-c[x],c[x]=i;
			else if (c[x]){
				if (i==d[x]+c[x]) c[x]=i;
				else{
					--s,c[x]=0;
					if (!s) ++an[i];
				}
			}
		}
		For(i,1,q) printf("%d\n",an[p[i].r]);
		return 0;
	}
	return 0;
}
