#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=1000000007;
int a[11],b[11]; bool c[257];
int main(){
	freopen("b.in","r",stdin); freopen("b.out","w",stdout);
	int x,s,n=read(),k=read(),p=read(),ans=0; long long an=1;
	if (n<=8){
		For(i,1,n) a[i]=i;
		do{
			s=0; memset(c,0,sizeof(c));
			For(i,1,n-k+1)
				For(j,i+k-1,n){
					For(l,i,j) b[l-i+1]=a[l];
					sort(b+1,b+j-i+2); x=0;
					For(l,1,k) x|=(1<<(b[l]-1)); if (!c[x]) c[x]=1,++s;
				}
			if (s==p) ++ans;
		}while(next_permutation(a+1,a+1+n));
		printf("%d\n",ans);
	}
	else if (k==1&&p==n){
		For(i,2,n) an=an*i%mo; printf("%lld\n",an);
	}
	else if (p==n-k+1){
		For(i,2,k) an=an*i%mo; For(i,1,p-1) an=an*2%mo; printf("%lld\n",an);
	}
	else if (p>(n+1)*n/2) printf("0\n");
	return 0;
}
