#include <bits/stdc++.h>

const int N = 400;
const int mod = 1000000007;

int n, k, ex;

int p[N + 5];
int ans;

bool occur[(1 << 8) + 5];
bool vis[8 + 5];

void DFS_calc(int step)
{
	if(step > n){
		memset(occur, 0, sizeof occur);
		int cnt = 0;

		for(int i = 1; i <= n; ++i){
			std::vector<int> G;
			for(int j = i; j <= i + k - 2; ++j){
				G.push_back(p[j]);
			}
			for(int j = i + k - 1; j <= n; ++j){
				G.push_back(p[j]);
				std::sort(G.begin(), G.end());
				int s = 0;
				for(int l = 0; l < k; ++l) s |= 1 << (G[l]-1);
				if(!occur[s]){
					occur[s] = true;
					cnt ++;
				}
			}
		}
		ans += (cnt == ex);
		return ;
	}
	for(int i = 1; i <= n; ++i)
		if(!vis[i]){
			p[step] = i;
			vis[i] = true;
			DFS_calc(step + 1);
			vis[i] = false;
		}
}

int dp[N + 5][N * N + 5];
int C[N + 5][N + 5];

int main()
{
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	scanf("%d%d%d", &n, &k, &ex);
	if(n <= 8){
		DFS_calc(1);
		printf("%d\n", ans);
	}else if(ex > n * (n + 1) / 2)
		puts("0");
	else
	{
		long long ans = 1;
		for(int i = 1; i <= n; ++i)
			ans = ans * i % mod;
		printf("%lld\n", ans);
	}

	return 0;
}
