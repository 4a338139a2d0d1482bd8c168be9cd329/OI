#include <bits/stdc++.h>

const int N = 100000;
const int B = 1000;

int read(int x = 0, int f = 0)
{
	char c = getchar();
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return f? -x : x;
}

int n, m;
int A[B + 5][B + 5];

struct Query
{
	int ty, p, color;
	void input()
	{
		ty = read(), p = read(), color = read();
	}
}q[N + 5];

void Init()
{
	n = read(); m = read();
}

bool Save_query()
{
	bool flag = false;
	for(int i = 1; i <= m; ++i){
		q[i].input();
		if(q[i].ty > 2) flag = true;
	}
	return flag;
}

int col[N + 5];

void Exec()
{
	if(n <= 1000 && m <= 1000){
		for(int cases = 1; cases <= m; ++cases){
			int ty = read();
			int p = read();
			int color = read();
			if(ty == 1){
				for(int i = 1; i <= n; ++i)
					A[p][i] |= color + 1;
			}else if(ty == 2){
				for(int i = 1; i <= n; ++i)
					A[i][p] |= color + 1;
			}else if(ty == 3)
			{
				for(int i = 1; i < p; ++i)
					if(i <= n && p-i <= n)
						A[i][p-i] |= color + 1;
			}
		}
		int ans[4] = {0};
		for(int i = 1; i <= n; ++i)
			for(int j = 1; j <= n; ++j)
				ans[A[i][j]] ++;
		for(int i = 0; i < 4; ++i)
			printf("%d%c", ans[i], i != 3? ' ':'\n');
	}else
	{
		long long ans[4] = {1ll * n * n};
		if(!Save_query()){
			for(int i = 1; i <= m; ++i){
				int r = q[i].p;
				if(col[r] == 0){
					ans[col[r]] -= n;
					col[r] |= q[i].color + 1;
					ans[col[r]] += n;
				}else if(col[r] != 3){
					if(q[i].color + 1 != col[r]){
						ans[col[r]] -= n;
						col[r] |= q[i].color + 1;
						ans[col[r]] += n;
					}
				}
			}
			for(int i = 0; i < 4; ++i)
				printf("%lld%c", ans[i], i != 3? ' ':'\n');
		}else
		{
			printf("0 %lld 0 0\n", 1ll * n * n);
		}
	}
}

int main()
{
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	Init();
	Exec();

	return 0;
}
