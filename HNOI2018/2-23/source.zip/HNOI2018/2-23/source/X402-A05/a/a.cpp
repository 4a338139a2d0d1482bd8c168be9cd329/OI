#include <bits/stdc++.h>

bool chkmax(int &a, int b) 
{ 
	return a < b? a = b, 1 : 0; 
}
int read(int x = 0, int f = 0)
{
	char c = getchar();
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return f? -x : x;
}

const int N = 400000;

int n, q, maxa;
int A[N + 5];
int pre[N + 5];
int lst[N + 5];

std::vector<int> G[N + 5];
int far[N + 5];

int root[N + 5];
struct ValTree
{
#define mid ((l + r) >> 1)

	static const int NLOG = N << 5;

	int tot, sum[NLOG + 5];
	int lc[NLOG + 5], rc[NLOG + 5];

	int Insert(int lst, int l, int r, int p)
	{
		int h = ++tot;
		sum[h] = sum[lst] + 1;
		if(l == r) return h;
		if(p <= mid){
			lc[h] = Insert(lc[lst], l, mid, p);
			rc[h] = rc[lst];
		}else
		{
			rc[h] = Insert(rc[lst], mid + 1, r, p);
			lc[h] = lc[lst];
		}
		return h;
	}

	int query(int v, int u, int l, int r, int ql, int qr)
	{
		if(ql <= l && r <= qr) return sum[v] - sum[u];
		return (ql <= mid? query(lc[v], lc[u], l, mid, ql, qr) : 0) +
			(qr > mid? query(rc[v], rc[u], mid + 1, r, ql, qr) : 0);
	}

#undef mid
}VT;

struct CoverTree
{
#define mid ((l + r) >> 1)
#define lc (h << 1)
#define rc (lc | 1)

	int tag[(N << 2) + 5];
	int sum[(N << 2) + 5];

	void push_down(int h, int l, int r)
	{
		if(tag[h]){
			sum[lc] = mid - l + 1;
			sum[rc] = r - mid;
			tag[rc] = tag[lc] = tag[h];
			tag[h] = 0;
		}
	}

	void cover(int h, int l, int r, int ql, int qr)
	{
		if(qr < ql) return ;
		if(ql <= l && r <= qr){
			sum[h] = r - l + 1;
			tag[h] = 1;
		}
		else
		{
			push_down(h, l, r);
			if(ql <= mid) cover(lc, l, mid, ql, qr);
			if(qr > mid) cover(rc, mid + 1, r, ql, qr);
			sum[h] = sum[lc] + sum[rc];
		}
	}

	int query(int h, int l, int r, int ql, int qr)
	{
		if(ql <= l && r <= qr) return sum[h];
		push_down(h, l, r);
		return (ql <= mid? query(lc, l, mid, ql, qr) : 0) +
			(qr > mid? query(rc, mid + 1, r, ql, qr) : 0);
	}
}CT;

void Init()
{
	n = read();
	for(int i = 1; i <= n; ++i){
		A[i] = read();
		chkmax(maxa, A[i]);

		pre[i] = lst[A[i]];
		lst[A[i]] = i;
		G[A[i]].push_back(i);
	}

	for(int v = 1; v <= maxa; ++v){
		int L = G[v].size();
		for(int i = 0; i < L; ++i){
			int &cur = far[G[v][i]];
			if(i != L - 1){
				cur = G[v][i+1];
				if(i && chkmax(cur, far[G[v][i-1]])){
				}else
				{
					int d = G[v][i+1] - G[v][i], j = i + 1;
					while(j+1 < L && G[v][j+1] - G[v][j] == d)
						j ++;
					cur = G[v][j];
				}
			}else
			{
				cur = G[v][i];
			}
		}
	}
	for(int i = 1; i <= n; ++i){
		root[i] = VT.Insert(root[i-1], 0, n, pre[i]);
		if(pre[i] == 0){
			CT.cover(1, 1, n, i, far[i]);
			int j = 0, ed = 0;
			if(G[A[i]][int(G[A[i]].size())-1] == far[i]) ed = n;
			else
				j = upper_bound(G[A[i]].begin(), G[A[i]].end(), far[i]) - G[A[i]].begin();
			if(!ed) ed = G[A[i]][j] - 1;
//			if(A[i] == 1) std::cerr << G[A[i]][j] << std::endl;
			CT.cover(1, 1, n, i, ed);
//			std::cerr << i << " " << ed << std::endl;
		}
	}
}

void Exec()
{
	q = read();
	for(int cases = 1; cases <= q; ++cases){
		int l = read();
		int r = read();
		bool flag = true;
		if(n <= 100 && q <= 100){
			int ans = 0;
			for(int i = l; i <= r; ++i){
				if(pre[i] < l){
					bool can = true;
					for(int j = far[i] + 1; j <= r; ++j)
						if(A[j] == A[i]){
							can = false; 
							break;
						}
					if(can) flag = false;
					ans ++;
				}
			}
			printf("%d\n", ans + flag);
		}else if(maxa <= 10){
			for(int i = 1; i <= maxa; ++i){
				int L = G[i].size();
				if(!L || (G[i][L-1] < l || G[i][0] > r)) continue;
				int j = lower_bound(G[i].begin(), G[i].end(), l) - G[i].begin();
				if(G[i][j] > r) continue;
				int should_reach = G[i][L-1] <= r? G[i][L-1] : 
					G[i][upper_bound(G[i].begin(), G[i].end(), r) - G[i].begin() - 1];
				if(far[G[i][j]] >= should_reach) flag = false;
			}
			printf("%d\n", VT.query(root[r], root[l-1], 0, n, 0, l - 1) + flag);
		}else if(l == 1){
			flag = CT.query(1, 1, n, r, r);
			printf("%d\n", VT.query(root[r], root[l-1], 0, n, 0, 0) + flag);
		}else if(n <= 50000){
			for(int i = maxa; i >= 1; --i){
				int L = G[i].size();
				if(!L || (G[i][L-1] < l || G[i][0] > r)) continue;
				int j = lower_bound(G[i].begin(), G[i].end(), l) - G[i].begin();
				if(G[i][j] > r) continue;
				int should_reach = G[i][L-1] <= r? G[i][L-1] : 
					G[i][upper_bound(G[i].begin(), G[i].end(), r) - G[i].begin() - 1];

				if(far[G[i][j]] >= should_reach){
					flag = false;
					break;
				}
			}
			printf("%d\n", VT.query(root[r], root[l-1], 0, n, 0, l - 1) + flag);
		}
		else
		{
			printf("%d\n", VT.query(root[r], root[l-1], 0, n, 0, l - 1));
		}
	}
}

int main()
{
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);

	Init();
	Exec();
//	std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;

	return 0;
}
