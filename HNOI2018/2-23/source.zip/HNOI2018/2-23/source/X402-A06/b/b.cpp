#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, k, p, a[maxn], Hash[maxn], ls[maxn], cnt, st[maxn], top;

const int mod = 1e9 + 7;

void Get(){
	n = read(), k = read(), p = read();
}

void bf(){
	int MOD = 23333, ans = 0;
	For(i, 1, n) a[i] = i;
	do{
		int Ans = 0;
		For(i, 1, top) Hash[st[i]] = 0;
		top = 0;

		For(i, 1, n){
			cnt = 0;
			For(j, i, n){
				ls[++cnt] = a[j];
				if(cnt < k) continue;
				sort(ls+1, ls+cnt+1);
				int val = 0;
				For(o, 1, k) val = 1ll * val * MOD % mod + ls[o];
				if(!Hash[val]) ++ Ans, st[++top] = val, Hash[val] = 1;
			}
		}
		if(Ans == p) ++ ans;
	}while(next_permutation(a+1, a+n+1) );
	printf("%d\n", ans);
}

int dp[410][400 * 401 / 2 + 10], dpp[1005][40005];

void solve(){
	int jie = 1;
	For(i, 1, k) jie = 1ll * jie * i % mod;
	dp[k][1] = jie;

	For(i, k, n - 1){
		int lim = min(p, i * (i+1) / 2);
		For(j, 1, lim){
			if(dp[i][j] == 0) continue;
			int tot = (i+1) - k + 1;

			if(tot >= k) (dp[i+1][j+k] += 1ll * dp[i][j] * (i + 3 - 2 * k) % mod) %= mod;
			else (dp[i+1][j+tot] += 1ll * dp[i][j] * (2 * k - i - 1) % mod) %= mod;
			
			For(o, 1, min(tot, k) - 1) (dp[i+1][j+o] += dp[i][j] * 2ll % mod) %= mod;
		}
	}

	printf("%d\n", dp[n][p]);
}

void solve_spe(){
	int jie = 1;
	For(i, 1, k) jie = 1ll * jie * i % mod;
	dpp[k][1] = jie;

	For(i, k, n - 1){
		int lim = min(p, i * (i+1) / 2);
		For(j, 1, lim){
			if(dpp[i][j] == 0) continue;
			int tot = (i+1) - k + 1;

			if(tot >= k) (dpp[i+1][j+k] += 1ll * dpp[i][j] * (i + 3 - 2 * k) % mod) %= mod;
			else (dpp[i+1][j+tot] += 1ll * dpp[i][j] * (2 * k - i - 1) % mod) %= mod;
			
			For(o, 1, min(tot, k) - 1) (dpp[i+1][j+o] += dpp[i][j] * 2ll % mod) %= mod;
		}
	}

	printf("%d\n", dpp[n][p]);
}

int main(){

	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	Get();
	if(p > n * (n + 1) / 2) {
		puts("0"); return 0;
	}
	if(k == 1){
		if(p != n) puts("0");
		else {
			int jie = 1;
			For(i, 1, n) jie = 1ll * jie * i % mod;
			printf("%d\n", jie);
		}
		return 0;
	}
	if(k == n){
		if(p != 1) puts("0");
		else {
			int jie = 1;
			For(i, 1, n) jie = 1ll * jie * i % mod;
			printf("%d\n", jie);
		}
		return 0;
	}

	if(n <= 400) solve();
	else solve_spe();

	return 0;
}
