#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m, a[1010][1010], Ans[maxn];

void Get(){
	n = read(), m = read();
}

void bf(){
	while(m --){
		int type = read(), pos = read(), color = read() + 1; 
		if(type == 1){
			For(i, 1, n){
				if(!a[pos][i]) a[pos][i] = color;
				else if(a[pos][i] != color) a[pos][i] = 3;
			}
		}
		else if(type == 2){
			For(i, 1, n){
				if(!a[i][pos]) a[i][pos] = color;
				else if(a[i][pos] != color) a[i][pos] = 3;
			}
		}
		else{
			For(i, max(1, pos-n), min(pos-1, n) ){
				if(!a[i][pos-i]) a[i][pos-i] = color;
				else if(a[i][pos-i] != color) a[i][pos-i] = 3;
			}
		}
	}

	For(i, 1, n) For(j, 1, n) Ans[a[i][j]] ++;

	For(i, 0, 3) printf("%d ", Ans[i]); printf("\n");
}

int vis[maxn];

ll ans[maxn];

void solve_spe(){
	while(m --){
		int type = read(), pos = read(), color = read() + 1;
		if(vis[pos] == 0) vis[pos] = color;
		else if(vis[pos] != color) vis[pos] = 3;
	}

	For(i, 1, n){
		ans[vis[i]] += 1ll * n;
	}

	For(i, 0, 3) printf("%lld ", ans[i]); puts("");
}

int main(){
	
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	Get();
	if(n <= 1000) bf();
	else solve_spe();

	return 0;
}
