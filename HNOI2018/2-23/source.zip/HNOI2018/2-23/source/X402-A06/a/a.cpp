#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 400010;

int n, a[maxn], q, vis[maxn], ls[maxn * 30];

void Get(){
	n = read();
	For(i, 1, n) a[i] = read();
	q = read();
}

void solve_bf(){
	while(q --){
		int l = read(), r = read();
		For(i, 0, 100) vis[i] = 0;
		int cnt = 0, ans = 0;

		For(i, l, r){
			if(!vis[a[i]]) ls[++cnt] = a[i], ++ ans;
			vis[a[i]] ++;
		}

		bool flag = 0;
		For(i, 1, cnt){
			if(vis[ls[i]] <= 2){
				flag = 1; 
				break;
			}
			int tot = 0, Last = 0, cha = 0;
			bool pd = 0;
			
			For(j, l, r){
				if(a[j] == ls[i]){
					++ tot;
					if(tot == 2){
						cha = j - Last;
					}
					else if(tot >= 3){
						if(j - Last != cha){
							pd = 1;
							break;
						}
					}
					Last = j;
				}
			}
			if(!pd){
				flag = 1;
				break;
			}
		}
		if(flag) printf("%d\n", ans);
		else printf("%d\n", ans + 1);
	}
}

int root[maxn], sum[maxn * 30], Next[maxn], tot, rs[maxn * 30];

void insert(int &x,int y,int l,int r,int pos){
	x = ++ tot;
	ls[x] = ls[y];
	rs[x] = rs[y];
	sum[x] = sum[y] + 1;
	if(l == r) return;

	int mid = l+r >> 1;
	if(pos <= mid) insert(ls[x], ls[y], l, mid, pos);
	else insert(rs[x], rs[y], mid+1, r, pos);
}

void pre_work(){
	For(i, 1, n) vis[i] = n+1;
	rep(i, n, 1){
		Next[i] = vis[a[i]];
		vis[a[i]] = i;
	}

	For(i, 1, n){
		insert(root[i], root[i-1], 1, n+1, Next[i]);
	}
}

int query(int h,int l,int r,int s,int e){
	if(l == s && r == e) return sum[h];
	int mid = l+r >> 1;
	if(e <= mid) return query(ls[h], l, mid, s, e);
	else if(s > mid) return query(rs[h], mid+1, r, s, e);
	else return query(ls[h], l, mid, s, mid) + query(rs[h], mid+1, r, mid+1, e);
}

void solve_spe(){
	pre_work();
	while(q --){
		int l = read(), r = read();
		printf("%d\n", query(root[r], 1, n+1, r+1, n+1) - query(root[l-1], 1, n+1, r+1, n+1) );
	}
}

int main(){

	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
	
	Get();
	if(n <= 100) solve_bf();
	else solve_spe();

	return 0;
}
