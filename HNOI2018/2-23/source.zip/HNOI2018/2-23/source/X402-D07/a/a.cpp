#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=400010;

int n,m,a[maxn];

struct query{
    int l,r;
} q[maxn];

struct point{
    int x,y,w,id;
    point(){}
    point(int _x,int _y,int _w):x(_x),y(_y),w(_w){ id=0; }
    point(int _x,int _y,int _w,int _id):x(_x),y(_y),w(_w),id(_id){}
} p[maxn*5];
int cnt;

bool cmp1(point u,point v){
    return u.x>v.x||(u.x==v.x&&u.y>v.y)||(u.x==v.x&&u.y==v.y&&abs(u.w)>abs(v.w));
}

bool cmp2(point u,point v){
    return u.x>v.x||(u.x==v.x&&u.y<v.y)||(u.x==v.x&&u.y==v.y&&abs(u.w)>abs(v.w));
}

int lst[maxn],nxt[maxn],tail[maxn];
int f[maxn];

int sum[maxn];

namespace BIT{
    int T[maxn];

    void add(int k,int x){ for(;k<=n;k+=k&-k) T[k]+=x; }

    int query(int k){ int ret=0; for(;k;k-=k&-k) ret+=T[k]; return ret; }
}

int main(){
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++) read(a[i]);

    read(m);
    for(int i=1;i<=m;i++) read(q[i].l),read(q[i].r);

    for(int i=1;i<=n;i++) nxt[i]=n+1;

    for(int i=1;i<=n;i++){
        lst[i]=tail[a[i]];
        nxt[tail[a[i]]]=i;
        tail[a[i]]=i;
    }

    for(int i=1;i<=n;i++){
        if(lst[i]&&(f[lst[i]]==lst[i]||i-lst[i]==lst[i]-lst[lst[i]])) f[i]=f[lst[i]];
        else f[i]=i;

        int x_0=min(lst[lst[i]]+1,lst[f[i]]+1),y_0=i;
        int x_1=i,y_1=nxt[i]-1;

        p[++cnt]=point(x_1,y_1,1);
        if(x_0>1&&y_0>1) p[++cnt]=point(x_0-1,y_0-1,1);
        if(x_0>1) p[++cnt]=point(x_0-1,y_1,-1);
        if(y_0>1) p[++cnt]=point(x_1,y_0-1,-1);
    }

    for(int i=1;i<=m;i++) p[++cnt]=point(q[i].l,q[i].r,0,i);

    sort(p+1,p+cnt+1,cmp1);

    for(int i=1;i<=cnt;i++){
        if(p[i].w) BIT::add(n-p[i].y+1,p[i].w);
        else sum[p[i].id]=BIT::query(n-p[i].y+1)?1:0;
    }

    cnt=0; memset(BIT::T,0,sizeof BIT::T);

    for(int i=1;i<=n;i++) if(nxt[i]!=n+1) p[++cnt]=point(i,nxt[i],1);
    for(int i=1;i<=m;i++) p[++cnt]=point(q[i].l,q[i].r,0,i);

    sort(p+1,p+cnt+1,cmp2);

    for(int i=1;i<=cnt;i++){
        if(p[i].w) BIT::add(p[i].y,p[i].w);
        else sum[p[i].id]+=BIT::query(p[i].y);
    }
    
    for(int i=1;i<=m;i++) printf("%d\n",q[i].r-q[i].l+2-sum[i]);

    return 0;
}
