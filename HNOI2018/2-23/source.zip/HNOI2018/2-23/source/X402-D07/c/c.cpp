#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

int n,m;
int G[1010][1010],cnt[4];

int main(){
    freopen("c.in","r",stdin);
    freopen("c.out","w",stdout);

    read(n); read(m);

    if(n<=1000&&m<=1000){
        while(m--){
            int type,pos,color;
            read(type); read(pos); read(color);

            if(type==1) for(int i=1;i<=n;i++) G[pos][i]|=(color+1);
            if(type==2) for(int i=1;i<=n;i++) G[i][pos]|=(color+1);
            if(type==3) for(int i=1;i<=n;i++) if(pos-i<=n&&pos-i>=1) G[i][pos-i]|=(color+1);
        }

        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++) ++cnt[G[i][j]];

        printf("%d %d %d %d\n",cnt[0],cnt[1],cnt[2],cnt[3]);
    }

    else{
        while(m--){
            int type,pos,color;
            read(type); read(pos); read(color);

            G[pos][0]|=(color+1);
        }

        for(int i=1;i<=n;i++) cnt[G[i][0]]+=n;

        printf("%d %d %d %d\n",cnt[0],cnt[1],cnt[2],cnt[3]);
    }

    return 0;
}
