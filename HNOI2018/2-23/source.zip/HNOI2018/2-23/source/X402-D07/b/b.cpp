#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

#define pb push_back
#define pp pop_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(),(x).end()

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=10,mo=1e9+7;

int n,k,p,ans;
int vis[maxn],a[maxn];

map<vector<int>,bool> book;

bool check(){
    book.clear(); int ret=0;
    for(int i=1;i<=n-k+1;i++)
        for(int j=i+k-1;j<=n;j++){
            vector<int> t;
            for(int l=i;l<=j;l++) t.pb(a[l]);
            sort(ALL(t));
            while(SZ(t)>k) t.pp();
            if(!book.count(t)) book[t]=1,++ret;
        }

    return ret==p;
}

void dfs(int u){
    if(u==n+1) return void(ans+=check());
    for(int i=1;i<=n;i++) if(!vis[i]){
        vis[i]=1; a[u]=i;
        dfs(u+1); vis[i]=0;
    }
}

int fpm(int x,int K){
    int ret=1;
    for(;K;K>>=1,x=1ll*x*x%mo)
        if(K&1) ret=1ll*ret*x%mo;
    return ret;
}

int main(){
    freopen("b.in","r",stdin);
    freopen("b.out","w",stdout);

    read(n); read(k); read(p);

    if(n<=8){
        dfs(1); printf("%d\n",ans);
        return 0;
    }

    else{
        int w=1;
        for(int i=1;i<=n;i++) w=1ll*w*i%mo;

        if(k==1&&p==n||k==n&&p==1) printf("%d\n",w),exit(0);

        if(p==n-k+1){
            w=1; for(int i=1;i<=k;i++) w=1ll*w*i%mo;
            printf("%lld\n",1ll*w*fpm(2,n-k)%mo);
            return 0;
        }

        if(p>n*(n+1)/2) puts("0"),exit(0);
    }

    return 0;
}
