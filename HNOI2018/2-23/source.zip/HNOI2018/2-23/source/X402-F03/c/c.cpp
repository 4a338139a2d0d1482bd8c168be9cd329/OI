#include<cstdio>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
int amp[1010][1010],bmp[1010][1010];
int a1[101010],a2[101010],b1[101010],b2[101010];
ll n,m;
struct node
{
	int t,pos,col;
}a[101010];
bool cmp(node u,node w)
{
	return u.t<w.t||(u.t==w.t && u.pos<w.pos);
}
void bl()
{
	int t,x,c;
	for (int ii=1;ii<=m;++ii)
	{
		scanf("%d%d%d",&t,&x,&c);
		if (t==1)
		{
			if (c==0)
				for (int i=1;i<=n;++i)
					amp[x][i]=1;
			else
				for (int i=1;i<=n;++i)
					bmp[x][i]=1;
		}
		else if (t==2)
		{
			if (c==0)
				for (int i=1;i<=n;++i)
					amp[i][x]=1;
			else 
				for (int i=1;i<=n;++i)
					bmp[i][x]=1;
		}
		else
		{
			if (c==0)
			{
				for (int i=1;i<=n;++i)
					if (x-i>=1 && x-i<=n)
						amp[i][x-i]=1;
			}
			else
			{
				for (int i=1;i<=n;++i)
					if (x-i>=1 && x-i<=n)
						bmp[i][x-i]=1;
			}
		}
	}
	x=0;
	int y=0,z=0;
	for (int i=1;i<=n;++i)
		for (int j=1;j<=n;++j)
		{
			if (amp[i][j]==1 && bmp[i][j]==1) ++z;
			else if (amp[i][j]==1) ++x;
			else if (bmp[i][j]==1) ++y;
		}
	printf("%lld %d %d %d\n",n*n-x-y-z,x,y,z);
}
void part1()
{
	for (int i=1;i<=m;++i)
	{
		if (a[i].t==1)
		{
			if (a[i].col==0)
				a1[a[i].pos]=1;
			else b1[a[i].pos]=1;
		}
		else
		{
			if (a[i].col==0)
				a2[a[i].pos]=1;
			else b2[a[i].pos]=1;
		}
	}
	ll x1=0,y1=0,z1=0,x2=0,y2=0,z2=0;
	for (int i=1;i<=n;++i)
	{
		if (a1[i]==1 && b1[i]==1) ++z1;
		else if (a1[i]==1) ++x1;
		else if (b1[i]==1) ++y1;
	}
	for (int i=1;i<=n;++i)
	{
		if (a2[i]==1 && b2[i]==1) ++z2;
		else if (a2[i]==1) ++x2;
		else if (b2[i]==1) ++y2;
	}
//	printf("%lld %lld %lld\n",x1,y1,z1);
//	printf("%lld %lld %lld\n",x2,y2,z2);
	ll xx,yy,zz;
	zz=n*z1+n*z2-z1*z2+x1*y2+x2*y1;
	xx=n*x1+n*x2-x1*x2-x1*y2-x2*y1-x1*z2-x2*z1;
	yy=n*y1+n*y2-y1*y2-x1*y2-x2*y1-y1*z2-y2*z1;
	printf("%lld %lld %lld %lld\n",n*n-xx-yy-zz,xx,yy,zz);
}
void part2()
{

}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if (n<=2100 && m<=2100)
	{
		bl();
		return 0;
	}

	for (int i=1;i<=m;++i) 
		scanf("%d%d%d",&a[i].t,&a[i].pos,&a[i].col);
	sort(a+1,a+1+m,cmp);
	if (a[m].t!=3) part1();
	else part1();

	return 0;
}
