#include<cstdio>
#include<iostream>
using namespace std;
int n,m,ans;
int a[404040];
int now[404040],nxt[404040],col[404040];
inline void read(int &x)
{
    int data=0,w=1;
    char ch=0;
    while (ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
    if (ch=='-') w=-1,ch=getchar();
    while (ch>='0'&&ch<='9') data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
    x=data*w;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
		read(a[i]);
	for (int i=n;i>=1;--i)
		nxt[i]=now[a[i]],now[a[i]]=i;
//	for (int i=1;i<=n;++i) printf("%d ",nxt[i]);
//	printf("\n");
	scanf("%d",&m);
	int l,r;
	for (int i=1;i<=m;++i)
	{
		bool flag=0;
		ans=0;
		read(l); read(r);
		for (int j=l;j<=r;++j)
			if (col[a[j]]!=i)
			{
				bool br=0;
				++ans;
				col[a[j]]=i;
				int x=j;
				if (flag==0)
					while (nxt[nxt[x]]!=0 && nxt[nxt[x]]<=r)
					{
						if (nxt[nxt[x]]-nxt[x]!=nxt[x]-x)
						{
							br=1;
							break;
						}
						x=nxt[x];
					}
				if (br==0) flag=1;
			}
		if (flag==0) ++ans;
		printf("%d\n",ans);
	}
	return 0;
}
