#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
const ll mod=1e9+7;
int n,k,p,ans;
int a[20];
bool br[20];
void check()
{
	for (int i=1;i<=n;++i)
		printf("%d ",a[i]);
	printf("\n");

	int sss;
	for (int i=1;i<=n;++i)
		if (a[i]<=k) 
		{
			sss=i;
			break;
		}
	for (int i=n;i>=1;--i)
		if (a[i]<=k)
		{
			sss*=(n-i+1);
			break;
		}
	printf("%d %d\n",sss,p);
	if (sss==p) ++ans;
}
ll jc(int x)
{
	ll sss=1;
	for (int i=1;i<=x;++i)
		sss=sss*i%mod;
	return sss;
}
void dfs(int deep)
{
	if (deep>n)
	{
		check();
		return;
	}
	for (int i=1;i<=n;++i)
		if (br[i]==0)
		{
			br[i]=1;
			a[deep]=i;
			dfs(deep+1);
			br[i]=0;
		}
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);
	ll cc=jc(n);
	if (k==1 && p==n)
	{
		printf("%lld\n",cc);
		return 0;
	}
	if (k==n && p==1)
	{
		printf("%lld\n",cc);
		return 0;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}


