#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int ans[10010],h[10010],v1[1000010],v2[1000010],s[10010],a[1010][1010],n,m;
void zz1(){
	int i,j,type,pos,color;
	for(i=1;i<=n;i++)
	    for(j=1;j<=n;j++)
	         a[i][j]=-1;
	for(i=1;i<=m;i++){
	    scanf("%d",&type);
	    if(type==1){
	    	scanf("%d%d",&pos,&color);
	    	for(j=1;j<=n;j++){
	    	    if(a[pos][j]==-1)a[pos][j]=color;
	    	    else if(a[pos][j]!=color)a[pos][j]=2;
	    	}
	    }
	    if(type==2){
	    	scanf("%d%d",&pos,&color);
	    	for(j=1;j<=n;j++){
	    		if(a[j][pos]==-1)a[j][pos]=color;
	    		else if(a[j][pos]!=color)a[j][pos]=2;
	    	}
	    }
	    if(type==3){
	    	scanf("%d%d",&pos,&color);
	    	for(j=1;j<=n;j++)
	    	     if(pos-j>0 && pos-j<=n){
	    	     	int x=pos-j;
	    	     	if(a[j][x]==-1)a[j][x]=color;
	    	     	else if(a[j][x]!=color)a[j][x]=2;
	    	     }
	    }
	}
	for(i=1;i<=n;i++)
	    for(j=1;j<=n;j++)
	         ans[a[i][j]+1]++;
	for(i=1;i<=n;i++){
	    for(j=1;j<=n;j++)
	         printf("%d ",a[i][j]+2);
	         puts("");
	     }
	for(i=0;i<=3;i++)
	     printf("%d ",ans[i]);
	puts("");
}
void zz2(){
	int type,pos,color;
	for(int i=1;i<=m;i++){
	    scanf("%d",&type);
	    if(type==1){
	    	scanf("%d%d",&pos,&color);
	    	if(!v1[pos])
	    	    h[color]++;
	    	v1[pos]=1;
	    }
	    if(type==2){
	    	scanf("%d%d",&pos,&color);
	    	if(!v2[pos])
	    	    s[color]++;
	    	v2[pos]=1;
	    }
	}
	int s2=h[0]*n+s[0]*n-h[0]*s[0];
	int s3=h[1]*n+s[1]*n-h[1]*s[1];
	int s4=h[0]*s[1]+h[1]*s[0];
	s2-=s4;
	s3-=s4;
	int s1=n*n-s2-s3-s4;
	printf("%d %d %d %d\n",s1,s2,s3,s4);
}
int main(){
	int i,j,k;
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=1000 && m<=1000)zz1();
	else zz2();
	return 0;
}/*
5 6
2 4 1
2 1 1
1 3 1
1 5 0
2 4 1
2 2 0
*/

