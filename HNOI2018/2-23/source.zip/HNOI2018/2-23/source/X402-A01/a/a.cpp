# include<cstdio>
# include<cstdlib>
# include<algorithm>
# include<iostream>
using namespace std;
int a[1000010],w[1000010],v[100010],sum[1000010];
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n,i,l,r,q;
	scanf("%d",&n);
	int h=0;
	for(i=1;i<=n;i++){
	    scanf("%d",&a[i]);
	    h=max(h,a[i]);
	}
	scanf("%d",&q);
	if(n<=210 && q<=210){
	    while(q--){
		    int ans=0;
			scanf("%d%d",&l,&r);
			for(i=l;i<=r;i++){
		    	if(v[a[i]]!=q+1){ans++;v[a[i]]=q+1;}
		    	w[a[i]]++;
			}
			int d=1;
			for(int j=1;j<=r-l;j++){
				sum[a[l]]=1;
				for(i=l+j;i<=r;i++){
		   	        if(a[i]==a[i-j])sum[a[i]]++;
		   	        else {if(w[a[i-j]]==sum[a[i-j]]){d=0;break;}sum[a[i-j]]=0;sum[a[i]]=1;}
		   	    }
		   	    if(sum[a[r]]==w[a[r]]){d=0;sum[a[r]]=0;}
		   	}
		   	if(r==l)d=0;
		   	ans+=d;
			printf("%d\n",ans);
			for(i=l;i<=r;i++)w[a[i]]=0;
		}
		return 0;
	}	
}/*
5
1 2 1 2 1
1
1 5
*/
		
