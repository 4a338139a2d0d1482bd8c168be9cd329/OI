#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int v[100010],ansd=0,op1=0,a[100010],v2[100010],v1[100010],g[100010],n,k,p;
int mod=1e9+7;
int pd(){
	op1++;
	int ans=0,sum=0,i,j,k1;
	for(i=1;i<=n;i++)v1[i]=0;
	for(i=1;i<=n;i++){
	    for(j=i+k-1;j<=n;j++){
	    	for(k1=1;k1<=n;k1++)
	    	     v1[k1]=0;
	    	for(k1=i;k1<=j;k1++)
	    	     v1[a[k1]]=1;
	    	ans=0;
	    	int op=0;
	    	for(k1=1;k1<=n;k1++)
	    	    if(v1[k1]){ans+=g[k1];op++;if(op==k)break;}
	        if(v2[ans]!=op1)sum++;
	        v2[ans]=op1;
	    }
	}
	return sum==p?1:0;
}
void dfs(int x){
	 if(x==n+1){
	 	if(pd()){
	 		ansd++;
	 		ansd%=mod;
	 	}
	 	return;
	 }
	 for(int i=1;i<=n;i++){
	 	if(!v[i]){
	 		v[i]=1;
	 		a[x]=i;
	 		dfs(x+1);
	 		v[i]=0;
	 	}
	 }
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	int i,j,m;
	scanf("%d%d%d",&n,&k,&p);
	long long ansx=1;
	if((k==1 && p==n)||(k==n && p==1)){
		for(i=1;i<=n;i++)
		    ansx=(ansx*i)%mod;
		printf("%lld\n",ansx);
		return 0;
	}
	g[1]=1;
	for(i=2;i<=n;i++)
	     g[i]=g[i-1]*2;
	dfs(1);
	printf("%d\n",ansd);
	return 0;
}
/*
3 2 3
*/
