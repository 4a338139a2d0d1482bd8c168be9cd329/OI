/**********************************************************
	File:b.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-23 10:04:04
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 1000000007
#define N 110
long long ans=1;
int n,k,p,vis[N],q[1<<20],a[N],b[N];
void dfs(int x)
{
	if(x==n+1)
	{
		int cnt=0;
		fr(i,1,n-k+1)
		{
			fr(j,i,n)b[j]=a[j];
//			fr(_,i,n)printf("%d%c",b[_],_==n?'\n':' ');
			fr(j,i+k-1,n)
			{
				sort(b+i,b+j+1);
				int kk=0;
				fr(_,1,k)
					kk|=(1<<(b[i+_-1]-1));
				//fr(_,1,k)
				//	printf("%d%c",b[i+_],_==k?'\n':' ');
				//printf("%d\n",kk);
				q[kk]=1;
//				putchar('-');
//				fr(_,i,j)printf("%d%c",b[_],_==j?'\n':' ');
//				printf("%d\n",kk);
			}
//			putchar(10);
		}
//		putchar(10);
		fr(i,0,(1<<n)-1)
		{
//			printf("%d%c",q[i],i==_end_?'\n':' ');
			cnt+=q[i];
			q[i]=0;
		}
		ans=(ans+(cnt==p))%mod;
		return;
	}
	fr(i,1,n)
		if(!vis[i])
		{
			a[x]=i;
			vis[i]=1;
			dfs(x+1);
			vis[i]=0;
		}
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	n=read();
	k=read();
	p=read();
	if(p>n*(n+1)/2)
	{
		printf("0\n");
		return 0;
	}
	if((p==1&&k==n)||(p==n&&k==1))
	{
		fr(i,2,n)
			ans=ans*i%mod;
		printf("%lld\n",ans);
	}
	ans=0;
	dfs(1);
	printf("%lld\n",ans);
	return 0;
}