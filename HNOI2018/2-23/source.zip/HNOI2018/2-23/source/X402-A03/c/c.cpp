/**********************************************************
	File:c.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-23 10:07:21
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 100010
int n,m;
struct query
{
	int type,pos,color;
}q[N];
namespace main1
{
	int ap[1010][1010],ans[10];
	int main()
	{
		fr(i,1,m)
			if(q[i].type==1)
				fr(j,1,n)
					ap[q[i].pos][j]|=q[i].color;
			else if(q[i].type==2)
				fr(j,1,n)
					ap[j][q[i].pos]|=q[i].color;
			else
				fr(j,1,n)
					if(q[i].pos-j>=1&&q[i].pos-j<=n)
					ap[j][q[i].pos-j]|=q[i].color;
//		fr(i,1,n)
//			fr(j,1,n)
//				printf("%d%c",ap[i][j],j==n?'\n':' ');
		fr(i,1,n)
			fr(j,1,n)
				ans[ap[i][j]]++;
		fr(i,0,3)printf("%d%c",ans[i],i==3?'\n':' ');
		return 0;
	}
}
namespace main2
{
	bool cmp(query a,query b)
	{
		if(a.pos==b.pos)return a.type<b.type;
		return a.pos<b.pos;
	}
	int p[N];
	long long ans[4];
	int main()
	{
		sort(q+1,q+n+1,cmp);
		fr(i,1,m)p[q[i].pos]|=q[i].color;
		fr(i,1,n)ans[p[i]]+=n;
		fr(i,0,3)printf("%lld%c",ans[i],i==3?'\n':' ');
		return 0;
	}
}
namespace main3
{
	long long h[10],l[10];
	int hh[N],ll[N];
	int main()
	{
		fr(i,1,m)
			if(q[i].type==1)
				ll[q[i].pos]|=q[i].color;
			else
				hh[q[i].pos]|=q[i].color;
		fr(i,1,n)
		{
			h[hh[i]]++;
			l[ll[i]]++;
		}
//		printf("%lld %lld %lld %lld  %lld %lld %lld %lld\n",h[0],h[1],h[2],h[3],l[0],l[1],l[2],l[3]);
		printf("%lld %lld %lld %lld\n",
		h[0]*l[0],h[1]*l[0]+h[0]*l[1]+h[1]*l[1],
		h[2]*l[0]+h[0]*l[2]+h[2]*l[2],
		h[3]*n+l[3]*n-h[3]*l[3]+h[1]*l[2]+h[2]*l[1]);
		return 0;
	}
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	n=read();
	m=read();
	int flag1=1,flag2=1;
	fr(i,1,m)
	{
		q[i].type=read();
		q[i].pos=read();
		q[i].color=read()+1;
		if(q[i].type==3)flag1=flag2=0;
		if(q[i].type==2)flag1=0;
	}
	if(n<=1000&&m<=1000)return main1::main();
	if(flag1)return main2::main();
	if(flag2)return main3::main();
	return 0;
}