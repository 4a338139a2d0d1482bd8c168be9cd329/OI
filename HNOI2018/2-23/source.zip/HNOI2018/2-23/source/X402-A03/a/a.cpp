/**********************************************************
	File:a.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-2-23 08:32:16
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 400010
int n,t,a[N],fir[N],lst[N],nex[N],ans[N],num,cnt[N],che[N],sum,len,pre[N],c[N],lls[N];
struct query
{
	int l,r,pos;
}q[N];
int cmp(query a,query b)
{
	if(a.l/len==b.l/len)
		return a.r<b.r;
	return a.l<b.l;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	n=read();
	len=sqrt(n)+2;
	fr(i,1,n)
	{
		a[i]=read();
		nex[pre[a[i]]]=i;
		pre[a[i]]=i;
	}
	fr(i,1,n)pre[nex[i]]=i;
	t=read();
	fr(i,1,t)
	{
		q[i].l=read();
		q[i].r=read();
		q[i].pos=i;
	}
	sort(q+1,q+n+1,cmp);
	fd(i,n,1)
		if(nex[i])
		{
			c[i]=nex[i]-i;
			lst[i]=c[i]==c[nex[i]]?lst[nex[i]]:nex[i];
		}
		else
			lst[i]=i;
	q[0].l=1;
	fr(i,1,t)
	{
		int l=q[i].l,ll=q[i-1].l,r=q[i].r,rr=q[i-1].r;
//		printf("%d %d %d %d\n",l,ll,r,rr);
		while(ll>l)
		{
			ll--;
			fir[a[ll]]=ll;
			if(!cnt[a[ll]])
			{
				sum++;
				lls[a[ll]]=ll;
				num++;
				che[a[ll]]=1;
			}
			cnt[a[ll]]++;
			if(lst[ll]<lls[a[ll]]&&che[a[ll]])
			{
				che[a[ll]]=0;
//				printf("- %d %d\n",ll,a[ll]);
				num--;
			}
		}
//		printf("%d %d\n",sum,num);
		while(rr<r)
		{
			rr++;
			lls[a[rr]]=rr;
			if(!cnt[a[rr]])
			{
//				printf("- %d %d\n",rr,a[rr]);
				sum++;
				fir[a[rr]]=rr;
				num++;
				che[a[rr]]=1;
			}
			cnt[a[rr]]++;
			if(lst[fir[a[rr]]]<lls[a[rr]]&&che[a[rr]])
			{
				che[a[rr]]=0;
//				printf("- %d %d\n",rr,a[rr]);
				num--;
			}
		}
//		printf("%d %d\n",sum,num);
		while(ll<l)
		{
			cnt[a[ll]]--;
			if(!cnt[a[ll]])
			{
				fir[a[ll]]=lls[a[ll]]=0;
				sum--;
				if(che[a[ll]])
				{
					che[a[ll]]=0;
					num--;
				}
				ll++;
				continue;
			}
			fir[a[ll]]=nex[ll];
			if(lst[nex[ll]]>=lls[a[ll]]&&!che[a[ll]])
			{
				che[a[ll]]=1;
				num++;
			}
			ll++;
		}
//		printf("%d %d\n",sum,num);
		while(rr>r)
		{
//			printf("- %d %d\n",rr,a[rr]);
			cnt[a[rr]]--;
			if(!cnt[a[rr]])
			{
				fir[a[rr]]=lls[a[rr]]=0;
				sum--;
				if(che[a[rr]])
				{
					che[a[rr]]=0;
					num--;
				}
				rr--;
				continue;
			}
			lls[a[rr]]=pre[rr];
			if(lst[fir[a[rr]]]>=lls[a[rr]]&&!che[a[rr]])
			{
				che[a[rr]]=1;
				num++;
			}
			rr--;
		}
//		printf("%d %d\n",sum,num);
//		printf("%d %d  %d %d\n",l,r,sum,num);
//		fr(i,1,3)printf("%d %d\n",cnt[i],che[i]);
		ans[q[i].pos]=sum+1-(!!num);
	}
	fr(i,1,t)printf("%d\n",ans[i]);
	return 0;
}
/*
5
2 2 1 1 2
5
1 5
1 1
2 2
1 3
2 3
*/