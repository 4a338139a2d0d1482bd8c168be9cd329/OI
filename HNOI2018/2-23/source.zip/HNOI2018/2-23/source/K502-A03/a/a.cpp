#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register char ch(getchar());
	register T sum(0), fg(1);
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = int(4e5);

int n, m;

int a[MAXN + 5];

struct query
{
	int l, r, ans;
}qry[MAXN + 5];

inline void input()
{
	n = read<int>();
	for(int i = 1; i <= n; ++i) a[i] = read<int>();
	m = read<int>();
	for(int i = 1; i <= m; ++i) qry[i].l = read<int>(), qry[i].r = read<int>();
}

namespace SCAN
{
	vector<int> point[MAXN + 5];
	vector< pair<pii, int> > ins[MAXN + 5], del[MAXN + 5];

	inline void init()
	{
		static int lst[MAXN + 5];
		for(int i = 1; i <= n; ++i)
		{
			if(lst[a[i]]) point[lst[a[i]]].push_back(i);
			lst[a[i]] = i;
		}

		for(int i = 1; i <= m; ++i)
		{
			del[qry[i].l].push_back(mp(mp(qry[i].l, qry[i].r), i));
			ins[qry[i].r].push_back(mp(mp(qry[i].l, qry[i].r), i));
		}
	}

	struct BIT
	{
		int sum[MAXN + 5];

		inline void init() { memset(sum, 0, sizeof sum); }
		inline void add(int p, int val) { for(; p <= n; p += p & -p) sum[p] += val;  }
		inline int prefix(int p) { int res = 0; for(; p; p -= p & -p) res += sum[p]; return res; }
	}t0, t1;

	inline void solve()
	{
		t0.init(), t1.init();
		for(int i = n; i; --i)
		{
			for(vector<int>::iterator it = point[i].begin(); it != point[i].end(); ++it) t0.add(*it, 1), t1.add(*it, n - i + 1);
			for(vector< pair<pii, int> >::iterator it = ins[i].begin(); it != ins[i].end(); ++it)
			{
				int res = t0.prefix(it->fst.snd) - t0.prefix(it->fst.fst - 1);
				qry[it->snd].ans -= res * (n - i);
			}
			for(vector< pair<pii, int> >::iterator it = del[i].begin(); it != del[i].end(); ++it)
			{
				int res = t1.prefix(it->fst.snd) - t1.prefix(it->fst.fst - 1);
				qry[it->snd].ans += res;
			}
		}
	}
}

inline void solve()
{
	SCAN::init();
	SCAN::solve();
	for(int i = 1; i <= m; ++i) printf("%d\n", qry[i].r - qry[i].l + 1 - qry[i].ans);
}

int main()
{
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);

	input();
	solve();

	return 0;
}

