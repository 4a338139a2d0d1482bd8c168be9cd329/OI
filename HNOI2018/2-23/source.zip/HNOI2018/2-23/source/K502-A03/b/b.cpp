#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register char ch(getchar());
	register T sum(0), fg(1);
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MOD = int(1e9 + 7);
const int MAXN = int(1e3), MAXP = MAXN * MAXN;

int n, k, p;

int f[2][MAXP + 5];

inline void input()
{
	n = read<int>(), k = read<int>(), p = read<int>();
}

inline void solve()
{
	static int contrib[MAXN + 5][MAXN + 5] = {0};

	for(int i = 1; i < n; ++i)
		for(int j = 0; j <= i; ++j)
		{
			if(i < k - 1) contrib[i][j] = 0;
			else contrib[i][j] = min(j + k, i + 1) - k + 1 - max(1, j - (k - 1) + 1) + 1;
		}

	f[0][0] = 1;
	for(int i = 0; i < n; ++i)
	{
		memset(f[(i + 1) & 1], 0, sizeof f[(i + 1) & 1]);
		for(int j = 0; j <= i; ++j)
			for(int p0 = 0; p0 <= p; ++p0)
				(f[(i + 1) & 1][p0 + contrib[i][j]] += f[i & 1][p0]) %= MOD;
	}
	printf("%d\n", f[n & 1][p]);
}

inline void spe1_solve()
{
	int ans = 1;
	for(int i = 1; i <= n; ++i) ans = LL(ans) * i % MOD;
	printf("%d\n", ans);
}

inline void spe2_solve()
{
	int ans = 1;
	for(int i = 1; i <= k; ++i) ans = LL(ans) * i % MOD;
	for(int i = 1; i <= n - k; ++i) ans = ans * 2ll % MOD;
	printf("%d\n", ans);
}

int main()
{
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	input();
	if(p > n * (n + 1) / 2) { puts("0"); return 0; }
	else if((k == 1 && p == n) || (k == n && p == 1)) spe1_solve();
	else if(p == n - k + 1) spe2_solve();
	else solve();

	return 0;
}

