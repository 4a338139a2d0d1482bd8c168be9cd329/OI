#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register char ch(getchar());
	register T sum(0), fg(1);
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = int(1e3);

int n, m;

inline void input()
{
	n = read<int>(), m = read<int>();
}

int a[MAXN + 5][MAXN + 5], cnt[4];

inline void solve()
{
	while(m--)
	{
		int type = read<int>(), pos = read<int>(), color = 1 << read<int>();
		if(type == 1) for(int i = 1; i <= n; ++i) a[pos][i] |= color;
		if(type == 2) for(int i = 1; i <= n; ++i) a[i][pos] |= color;
		if(type == 3)
			for(int i = 1; i <= n; ++i)
				if(pos - i > 0 && pos - i <= n) a[i][pos - i] |= color;
	}

	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= n; ++j)
			++cnt[a[i][j]];
	for(int i = 0; i <= 3; ++i) printf("%d%c", cnt[i], i == 3 ? '\n' : ' ');
}

int line[int(1e5) + 5];

inline void spe_solve()
{
	while(m--)
	{
		read<int>();
		int pos = read<int>(), color = 1 << read<int>();
		line[pos] |= color;
	}

	for(int i = 1; i <= n; ++i) cnt[line[i]] += n;
	for(int i = 0; i <= 3; ++i) printf("%d%c", cnt[i], i == 3 ? '\n' : ' ');
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("c.in", "r", stdin);
	freopen("c.spe", "w", stdout);
#endif

	input();
	spe_solve();

	return 0;
}

