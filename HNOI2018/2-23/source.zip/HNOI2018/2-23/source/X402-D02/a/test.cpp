#include<iostream>
#include<cstdio>
#include<cstring>

int s[1000];
bool vis[110000];

int main()
{
	freopen("temp","r",stdin);
	int n=17396-17234+1;
	printf("n = %d\n",n);

	for(int i=1;i<=n;i++)
		scanf("%d",s+i),vis[s[i]]=1;

	int cnt=0;
	for(int i=1;i<=100;i++)
		cnt+=vis[i];

	printf("cnt = %d\n",cnt);
	
	return 0;
}
