#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>

namespace dbt
{
	typedef std::vector<int>::iterator vit;
	const int N=401000,M=N*17,INF=1000000007;

	struct bit
	{
		int s[N];
		inline int lowbit(int x){return x&(-x);}
		inline void inc(int p,int x){for(;p<N;p+=lowbit(p))s[p]+=x;}
		inline int ask(int p){int ret=0;for(;p;p-=lowbit(p))ret+=s[p];return ret;}
		inline void modify(int L,int R,int x){inc(L,x),inc(R+1,-x);}
	}BT;

	struct node
	{
		int x,y,y0,ty;
		node(int a=0,int b=0,int c=0,int d=0):x(a),y(b),y0(c),ty(d){}
	};

	bool operator < (node A,node B)
	{
		return (A.x==B.x)?A.ty>B.ty:A.x<B.x;
	}

	struct point_counter
	{
		node s[N*4];
		int tot;

		void paint(int x0,int x1,int y0,int y1,int w)
		{
			s[++tot]=node(x0,y0,y1,w);
			s[++tot]=node(x1+1,y0,y1,-w);
		}
		void add_query(int L,int R,int id)
		{
			s[++tot]=node(L,R,id,-2);
		}

		void calc(bool *ans)
		{
			std::sort(s+1,s+tot+1);
			for(int i=1;i<=tot;i++)
			{
				if(s[i].ty==-2)
					ans[s[i].y0]=BT.ask(s[i].y)>0;
				else
					BT.modify(s[i].y,s[i].y0,s[i].ty);
			}
		}
	}PC;

#define lt(p) (st[p][0])
#define rt(p) (st[p][1])
#define mid ((L+R)>>1)
#define lcq lt(p),L,mid
#define rcq rt(p),mid+1,R
	int st[M][2],w[M];
	int e;

	inline int copy(int p)
	{
		e++;
		lt(e)=lt(p),rt(e)=rt(p);
		w[e]=w[p];
		return e;
	}

	struct segment_tree
	{
		inline void upd(int p){w[p]=w[lt(p)]+w[rt(p)];}
		void modify(int x,int y,int &p,int L=0,int R=N-1)
		{
			p=copy(p);
			if(L==R){w[p]+=y;return;}
			x<=mid?modify(x,y,lcq):modify(x,y,rcq);
			upd(p);
		}
		int query(int s,int t,int p,int L=0,int R=N-1)
		{
			if(!p)return 0;
			if(L>=s && R<=t)return w[p];
			int ret=0;
			if(s<=mid)ret+=query(s,t,lcq);
			if(t>mid)ret+=query(s,t,rcq);
			return ret;
		}
	}T;

	int root[N];

	inline int calc(int L,int R)
	{
		int ret=T.query(0,L-1,root[R]);
		ret-=T.query(0,L-1,root[L-1]); //??? is this euqal L-1
		return ret;
	}

	std::vector<int> V[N];

	int lst[N];
	int n,m;

	void initialize()
	{
		scanf("%d",&n);
		for(int i=1,x;i<=n;i++)
		{
			scanf("%d",&x),V[x].push_back(i);
		}

		scanf("%d",&m);

		//prepare for point counter
		int L,R,dl,dr;
		for(int i=1,len;i<N;i++)
		{
			if(!(len=V[i].size()))continue;

			lst[V[i][0]]=0;
			for(int j=1;j<len;j++)
				lst[V[i][j]]=V[i][j-1];

			if(len==1)
			{
				PC.paint(1,V[i][0],V[i][0],n,1);
				continue;
			}

			for(L=R=0;R<len-1;L=R)
			{
				for(R++;V[i][R+1]-V[i][R]==V[i][R]-V[i][R-1];R++);

				dl=L?V[i][L-1]:0;dr=R<len-1?V[i][R+1]:n+1;
				dl++,dr--;

				PC.paint(dl,V[i][R],V[i][L],dr,1);

				for(int k=L;k<R;k++)
					PC.paint(V[i][k]+1,V[i][k+1]-1,V[i][k]+1,V[i][k+1]-1,-1);
			}
		}

		//perpare for president tree ........ fuck , i dont need it ,but i have done it. 

		for(int i=1;i<=n;i++)
		{
			root[i]=root[i-1];
			T.modify(lst[i],1,root[i]);
		}
	}

	bool f[N];
	int ans[N];

	void solve()
	{
		initialize();
		for(int i=1,L,R;i<=m;i++)
		{
			scanf("%d%d",&L,&R);
			ans[i]=calc(L,R);
			PC.add_query(L,R,i);
		}
		PC.calc(f);
		for(int i=1;i<=m;i++)ans[i]+=(!f[i]);

		for(int i=1;i<=m;i++)printf("%d\n",ans[i]);
	}
}

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	dbt::solve();
	return 0;
}
