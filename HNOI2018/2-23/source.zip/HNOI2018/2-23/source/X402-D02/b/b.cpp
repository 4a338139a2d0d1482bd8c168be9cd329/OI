#include<iostream>
#include<cstdio>
#include<cstring>


int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	printf("0\n");
	return 0;
}
