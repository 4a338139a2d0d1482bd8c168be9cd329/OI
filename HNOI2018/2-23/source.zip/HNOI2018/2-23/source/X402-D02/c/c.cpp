#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

struct node
{
	int ty,pos,col;
	node(int a=0,int b=0,int c=0):ty(a),pos(b),col(c){}
};

typedef long long ll;
const int M=101000;

node t[M];
int n,m;

namespace bf
{
	const int N=5010;

	int s[N][N],ans[4];

	void solve()
	{
		int ty,pos,col;
		for(int i=1;i<=m;i++)
		{
			ty=t[i].ty,pos=t[i].pos,col=t[i].col;
			if(ty==1)for(int i=1;i<=n;i++)s[pos][i]|=1<<col;
			else if(ty==2)for(int i=1;i<=n;i++)s[i][pos]|=1<<col;
			else for(int x=1,y=pos-1;y;x++,y--)
				{
					if(y>n || x>n)continue;
					s[x][y]|=1<<col;
				}
		}

		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				ans[s[i][j]]++;
		for(int i=0;i<4;i++)
			printf("%d ",ans[i]);
		printf("\n");
	}
}

namespace type_12
{
	const int N=101000;
	int A[N],B[N];

	int R0,G0,Y0,R1,G1,Y1;

	void initialize()
	{
		for(int i=1;i<=m;i++)
		{
			if(t[i].ty==1)A[t[i].pos]|=1<<t[i].col;
			else B[t[i].pos]|=1<<t[i].col;
		}
		R0=G0=Y0=R1=G1=Y1=0;
		for(int i=1;i<=n;i++)
		{
			if(A[i]==1)G0++;
			else if(A[i]==2)R0++;
			else if(A[i]==3)Y0++;

			if(B[i]==1)G1++;
			else if(B[i]==2)R1++;
			else if(B[i]==3)Y1++;
		}
	}

	void solve()
	{
		initialize();

		ll W,R,G,Y;

		R=(ll)R0*(n-G1-Y1)+(ll)R1*(n-R0-G0-Y0);
		G=(ll)G0*(n-R1-Y1)+(ll)G1*(n-R0-G0-Y0);
		Y=(ll)Y0*n+(ll)Y1*(n-Y0)+(ll)R0*G1+(ll)G0*R1;
		W=(ll)n*n-R-G-Y;

		printf("%lld %lld %lld %lld \n",W,G,R,Y);
	}
}

namespace color_0
{
	const int N=M*5,MOD=998244353;

	ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

	int dec[M];
	void getdec(int n){for(int i=1;i<n;i++)dec[i]=(dec[i>>1]>>1)+(i&1?n>>1:0);}
	void ntt(int *y,int n,int rag)
	{
		for(int i=0;i<n;i++)if(i<dec[i])std::swap(y[i],y[dec[i]]);

		int *y0,*y1,ny0,ny1;
		for(int len=2;len<=n;len<<=1)
		{
			int delta=qpow(3,(MOD-1)/len),h=len>>1,x;
			if(rag<0)delta=inv(delta);

			for(int p=0;p<n;p+=len)
			{
				y0=y+p,y1=y0+h,x=1;
				for(int i=0;i<h;i++,x=(ll)x*delta%MOD)
				{
					ny0=(y0[i]+(ll)x*y1[i])%MOD;
					ny1=(y0[i]-(ll)x*y1[i])%MOD;
					y0[i]=ny0,y1[i]=ny1;
				}
			}
		}
	}

	void mul(int *A,int *B,int n)
	{
		getdec(n);
		ntt(A,n,1),ntt(B,n,1);
		for(int i=0;i<n;i++)A[i]=(ll)A[i]*B[i]%MOD;
		ntt(A,n,-1);

		int dn=inv(n);
		for(int i=0;i<n;i++)A[i]=((ll)A[i]*dn%MOD+MOD)%MOD;
	}
	
	int u[M],v[M],w[M];
	int cntu,cntv,cntw;
	int A[N],B[N];

	void solve()
	{
		for(int i=1;i<=m;i++)
			if(t[i].ty==1)u[++cntu]=t[i].pos;
			else if(t[i].ty==2)v[++cntv]=t[i].pos;
			else w[++cntw]=t[i].pos;

		std::sort(u+1,u+cntu+1),std::sort(v+1,v+cntv+1),std::sort(w+1,w+cntw+1);
		cntu=std::unique(u+1,u+cntu+1)-u-1;
		cntv=std::unique(v+1,v+cntv+1)-v-1;
		cntw=std::unique(w+1,w+cntw+1)-w-1;

		for(int i=1;i<=cntu;i++)A[u[i]]=1;
		for(int i=1;i<=cntv;i++)B[v[i]]=1;
		int len;
		for(len=1;len<=n*2;len<<=1);
		mul(A,B,len);

		ll ans=(ll)(cntu+cntv)*n;
		ans-=(ll)cntu*cntv;
		for(int i=1;i<=cntw;i++)
		{
			ans+=w[i]-1;
			ans-=std::lower_bound(u+1,u+cntu+1,w[i])-u-1;
			ans-=std::lower_bound(v+1,v+cntv+1,w[i])-v-1;
			ans+=A[w[i]];
		}

		printf("%lld %lld 0 0 \n",(ll)n*n-ans,ans);
	}
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%d%d",&n,&m);
	bool flag1=1,flag2=1;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&t[i].ty,&t[i].pos,&t[i].col);
		if(t[i].ty==3)flag1=0;
		if(t[i].col!=0)flag2=0;
	}

	if(flag1)type_12::solve();
	else if(flag2)color_0::solve();
	else if(n<=5000 && m<=6000)bf::solve();
	else printf("nyg ak!\n");

	return 0;
}
