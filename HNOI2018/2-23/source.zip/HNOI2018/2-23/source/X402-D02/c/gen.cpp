#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("c.in","w",stdout);//look at here

	int n=5000,m=6000;
	printf("%d %d\n",n,m);

	int k=rand()%7;

	if(k==0)
	{
		while(m--)
		{
			int ty=rand()%3+1,pos=rand()%n+1,col=rand()%2;
			printf("%d %d %d\n",ty,pos,col);
		}
	}
	else if(k<=3)
	{
		while(m--)
		{
			int ty=rand()%2+1,pos=rand()%n+1,col=rand()%2;
			printf("%d %d %d\n",ty,pos,col);
		}
	}
	else 
	{
		while(m--)
		{
			int ty=rand()%3+1,pos=rand()%n+1,col=rand()%1;
			printf("%d %d %d\n",ty,pos,col);
		}
	}
		

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
