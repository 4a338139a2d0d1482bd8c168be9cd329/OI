#include<iostream>
#include<cstdio>
#include<cstring>

const int N=5010;

int s[N][N],ans[4];
int n,m;

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.ans","w",stdout);
	scanf("%d%d",&n,&m);
	int ty,pos,col;
	while(m--)
	{
		scanf("%d%d%d",&ty,&pos,&col);
		if(ty==1)
		{
			for(int i=1;i<=n;i++)
				s[pos][i]|=1<<col;
		}
		else if(ty==2)
		{
			for(int i=1;i<=n;i++)
				s[i][pos]|=1<<col;
		}
		else 
		{
			for(int x=1,y=pos-1;y;x++,y--)
			{
				if(y>n || x>n)continue;
				s[x][y]|=1<<col;
			}
		}
	}

	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			ans[s[i][j]]++;
	for(int i=0;i<4;i++)
		printf("%d ",ans[i]);
	printf("\n");
	return 0;
}
