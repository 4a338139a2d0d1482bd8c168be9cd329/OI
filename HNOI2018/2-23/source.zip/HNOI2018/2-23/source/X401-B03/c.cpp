#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
inline void print(long long x)
{
	if(!x)
	{
		putchar('0');putchar(' ');
		return ;
	}
	static long long cnt,a[10];
	cnt=0;
	while(x){a[++cnt]=x%10;x/=10;}
	for(long long i=cnt;i>=1;i--)putchar(a[i]+48);
	putchar(' ');
}
const long long col[4][4]={
	{0,1,2,0},
	{0,1,3,0},
	{0,3,2,0},
	{0,3,3,0}
};
struct Cheater
{
	long long tp,pos,col;
}e[100100];
long long n,m;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	read(n);read(m);
	if(n<=1000&&m<=1000)
	{
		static long long mapp[1010][1010]={0};
		while(m--)
		{
			static long long type,pos,colo;
			read(type);read(pos);read(colo);
			colo=colo==0?1:2;
			if(type==1)
			{
				for(long long i=1;i<=n;i++)
				mapp[pos][i]=col[mapp[pos][i]][colo];
			}
			else if(type==2)
			{
				for(long long i=1;i<=n;i++)
				mapp[i][pos]=col[mapp[i][pos]][colo];
			}
			else if(type==3)
			{
				for(long long i=1;i<=pos;i++)
				{
					if(pos-i>n)continue;
					if(i>n)break;
					mapp[i][pos-i]=col[mapp[i][pos-i]][colo];
					if(i!=pos-i)mapp[pos-i][i]=col[mapp[pos-i][i]][colo];
				}
			}
		}
		long long tot[4]={0};
		for(long long i=1;i<=n;i++)
			for(long long j=1;j<=n;j++)
			tot[mapp[i][j]]++;
		for(long long i=0;i<3;i++)print(tot[i]);
		printf("%lld\n",tot[3]);
		return 0;
	}
	else 
	{
		long long pd=1;
		for(long long i=1;i<=m;i++)		
		{
			read(e[i].tp);read(e[i].pos);read(e[i].col);
			e[i].col=e[i].col==0?1:2;
			if(e[i].tp!=1)pd=0;
		}
		if(pd)
		{
			static long long coll[100010]={0},tot[4];
			for(long long i=1;i<=m;i++)coll[e[i].pos]=col[coll[e[i].pos]][e[i].col];
			for(long long i=1;i<=n;i++)
				tot[coll[i]]+=n;
			for(long long i=0;i<3;i++)print(tot[i]);
			printf("%lld\n",tot[3]);
			return 0;
		}
	}
	return 0;
}
