#include<bits/stdc++.h>
#define N 4000100
using namespace std;
inline void read(int &x)
{
	x=0;
	static int p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
inline void print(int x)
{
	if(!x)
	{
		putchar('0');putchar('\n');
		return ;
	}
	static int cnt,a[10];
	cnt=0;
	while(x){a[++cnt]=x%10;x/=10;}
	for(int i=cnt;i>=1;i--)putchar(a[i]+48);
	putchar('\n');
}
int n,q,tot;
int A[N],vis[N];
int cnt[N<<2],lson[N<<2],rson[N<<2],T[N<<2];
typedef pair<int,int> pi;
vector<int>vec[N];
set<pi>s[N];
#define Mid ((l+r)>>1)
int build(int l,int r)
{
	int rt=tot++;
	cnt[rt]=0;
	if(l==r)return rt;
	lson[rt]=build(l,Mid);
	rson[rt]=build(Mid+1,r);
}
int update(int rt,int pos,int val)
{
	int now=tot++,tmp=now;
	int l=1,r=n;
	cnt[now]=cnt[rt]+val;
	while(l<r)
	{
		if(pos<=Mid)r=Mid,lson[now]=tot++,rson[now]=rson[rt],now=lson[now],rt=lson[rt];
		else l=Mid+1,rson[now]=tot++,lson[now]=lson[rt],now=rson[now],rt=rson[rt];
		cnt[now]=cnt[rt]+val;
	}
	return tmp;
}
int query(int rt,int pos)
{
	int l=1,r=n,ans=0;
	while(pos>l)
	{
		if(pos<=Mid)r=Mid,rt=lson[rt];
		else l=Mid+1,ans+=cnt[lson[rt]],rt=rson[rt];
	}
	return ans;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++)read(A[i]);
	T[0]=build(1,n);
	for(int i=1;i<=n;i++)
	{
		if(vis[A[i]])
		{
			int now=update(T[i-1],vis[A[i]],-1);
			T[i]=update(now,i,1);
		}
		else T[i]=update(T[i-1],i,1);
		vis[A[i]]=i;
	}
	set<pi>::iterator it;
	for(int i=1;i<=n;i++)
	{
		if((int)vec[A[i]].size()==0)vec[A[i]].push_back(i),s[A[i]].insert(pi(i,i));
		else
		{
			vec[A[i]].push_back(i);
			static int len;
			len=vec[A[i]].size();
			if(len==2)s[A[i]].erase(pi(vec[A[i]][0],vec[A[i]][0])),s[A[i]].insert(pi(vec[A[i]][0],i));
			else
			{
				it=--s[A[i]].end();
				if(vec[A[i]][len-1]-vec[A[i]][len-2]==vec[A[i]][len-2]-vec[A[i]][len-3])
				{
					s[A[i]].erase(it);
					s[A[i]].insert(pi(it->first,i));
				}
				else s[A[i]].insert(pi(it->second,i));
			}
		}
	}
	set<int>::iterator IT;
/*	if(pd)
	{
		read(q);
		while(q--)
		{
			static int l,r,x,flag,ans;
			read(l);read(r);
			ans=cnt[T[r]]-query(T[r],l);
			flag=0;
			for(int i=1;i<=10;i++)
			{
				x=*lower_bound(vec[i].begin(),vec[i].end(),l);
				if(x==*vec[i].end()||!(x>=l&&x<=r))continue;
				else 
				{
					IT=rr[x].lower_bound(r);
					if(IT==rr[x].end()||*IT==r){print(ans);flag=1;break;}
					else continue;
				}
			}
			if(!flag)print(ans+1);
		}
		return 0;
	}
 */
	read(q);
	while(q--)
	{
		static int l,r,ans;
		read(l);read(r);
		ans=cnt[T[r]]-query(T[r],l);
		static int flag;
		flag=0;
		for(int i=l;i<=r;i++)
		{
			it=s[A[i]].lower_bound(pi(l,-0x7f7f7f7f));
			if(it==s[A[i]].end()||it->first>r)it--;
			if(it->first<=l)
			{
				static int x;
				if(it->second>=r)
				{
					x=*lower_bound(vec[A[i]].begin(),vec[A[i]].end(),l);
					if(x>=l&&x<=r){print(ans);flag=1;break;}
					else continue;
				}
				else if(it->second>=l&&it->second<=r)
				{
					x=*upper_bound(vec[A[i]].begin(),vec[A[i]].end(),it->second);
					if(x>r||!x){print(ans);flag=1;break;}
					else continue;
				}
				else continue;
			}
			else 
			{
				static int x;
				if(it->second>=r)
				{
					x=*lower_bound(vec[A[i]].begin(),vec[A[i]].end(),l);
					if(x<it->first&&x>=l)continue;
					else {print(ans);flag=1;break;}
				}
				else if(it->second<r)
				{
					x=*lower_bound(vec[A[i]].begin(),vec[A[i]].end(),l);
					if(x<it->first&&x>=l)continue;
					else
					{
						x=*upper_bound(vec[A[i]].begin(),vec[A[i]].end(),it->second);
						if(x>=it->second&&x<=r)continue;
						else {print(ans);flag=1;break;}
					}
				}
			}
		}
	if(!flag)print(ans+1);
	}
	return 0;
}
