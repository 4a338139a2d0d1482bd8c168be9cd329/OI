#include<bits/stdc++.h>
#include<cctype>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	#endif
}
const int MAXN=4e5+7;
static int n,m,a[MAXN];
static struct quer
{
    int l,r,id;
    friend bool operator<(quer a,quer b)
    {
        return a.l^b.l?a.l<b.l:a.r<b.r;
    }
}q[MAXN];
static int rb[MAXN],las[MAXN],nx[MAXN],pr[MAXN];
static vector<int>G[MAXN];
static int ccc[MAXN];
static int ans[MAXN];
static int p[MAXN<<2];
void input(int h,int l,int r,int pos,int z)
{
    if(l==r){p[h]=z;return;}
    static int mid;mid=(l+r)>>1;
    pos<=mid?input(h<<1,l,mid,pos,z):input(h<<1|1,mid+1,r,pos,z);
    p[h]=max(p[h<<1],p[h<<1|1]);
}
using namespace __gnu_pbds; 
tree<int,null_type,less<int>,rb_tree_tag,tree_order_statistics_node_update>K;
inline void init()
{
    read(n);Rep(i,1,n)
    {
        read(a[i]),nx[pr[i]=las[a[i]]]=i,las[a[i]]=i;
        G[a[i]].push_back(i);
    }
    nx[0]=0;
    static int j,t;
    Rep(i,1,n)if(!rb[i])
    {
        j=nx[i];
        while(nx[j]&&j-pr[j]==nx[j]-j)j=nx[j];
        if(!nx[j])
        {
            j=i;
            while(j)rb[j]=n+1,j=nx[j];
        }
        else
        {
            rb[t=i]=nx[j]-1;
            while(t!=j)rb[t]=nx[j]-1,t=nx[t];
        }
    }
    read(m);Rep(i,1,m)read(q[i].l),read(q[i].r),q[i].id=i;
    sort(q+1,q+m+1);
    Rep(i,1,4e5)if(!G[i].empty())
    {
        input(1,1,n,G[i][ccc[i]],rb[G[i][ccc[i]]]);
        K.insert(G[i][ccc[i]]);
    }
}
#define Chkmax(a,b) a=a>b?a:b
int query(int h,int l,int r,int x,int y)
{
    if(!p[h])return 0;
    if(l>=x&&r<=y)return p[h];
    int mid=(l+r)>>1,as=0;
    if(x<=mid)as=query(h<<1,l,mid,x,y);
    if(y>mid)Chkmax(as,query(h<<1|1,mid+1,r,x,y));
    return as;
}
inline void solve()
{
    int l=1;
    Rep(i,1,m)
    {
        while(l<q[i].l)
        {
            ++ccc[a[l]];K.erase(l);
            if((unsigned)ccc[a[l]]<G[a[l]].size())
            {
                int npos=G[a[l]][ccc[a[l]]];
                input(1,1,n,npos,rb[npos]);
                K.insert(npos);
            }
            ++l;
        }
        ans[q[i].id]=(int)K.order_of_key(q[i].r+1)
            +(query(1,1,n,q[i].l,q[i].r)<q[i].r);
    }
    Rep(i,1,m)printf("%d\n",ans[i]);
}
int main(void){
	file();
    init();
    solve();
	return 0;
}
