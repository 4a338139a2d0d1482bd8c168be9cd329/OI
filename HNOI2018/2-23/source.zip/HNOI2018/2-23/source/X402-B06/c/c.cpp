#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	#endif
}
const int MAXN=1e5+7;
static struct modi
{
    int ty,ps;
}p[2][MAXN];
static int e[2],n,m;
static bool flag[3]={1,1,1};
inline void init()
{
    read(n);read(m);
    static int u,v,w;
    Rep(i,1,m)
    {
        read(u);read(v);read(w);
        if(u>1)flag[0]=false;
        if(u>2)flag[1]=false;
        if(w)flag[2]=false;
        p[w][++e[w]].ty=u;p[w][e[w]].ps=v;
    }
}
namespace Cheat1
{
    void main()
    {
        int a[1011][1011]={0};
        Rep(i,1,e[0])
            switch(p[0][i].ty)
            {
                case 1:Rep(j,1,n)a[p[0][i].ps][j]=1;break;
                case 2:Rep(j,1,n)a[j][p[0][i].ps]=1;break;
                case 3:Rep(j,1,p[0][i].ps-1)a[j][p[0][i].ps-j]=1;break;
            }
        Rep(i,1,e[1])
            switch(p[0][i].ty)
            {
                case 1:Rep(j,1,n)a[p[1][i].ps][j]|=2;break;
                case 2:Rep(j,1,n)a[j][p[1][i].ps]|=2;break;
                case 3:Rep(j,1,p[1][i].ps-1)a[j][p[1][i].ps-j]|=2;break;
            }
        int ans[4]={0};
        Rep(i,1,n)Rep(j,1,n)++ans[a[i][j]];
        cout<<ans[0]<<' '<<ans[1]<<' '<<ans[2]<<' '<<ans[3]<<endl;
    }
}
namespace Cheat2
{
    void main()
    {
        int col[MAXN]={0},ans[4]={0};
        Rep(i,1,e[0])col[p[0][i].ps]=1;
        Rep(i,1,e[1])col[p[1][i].ps]|=2;
        Rep(i,1,n)++ans[col[i]];
        cout<<1ll*ans[0]*n<<' '<<1ll*ans[1]*n<<' '<<1ll*ans[2]*n<<' '<<1ll*ans[3]*n<<endl;
    }
}
inline void solve()
{
    if(n<=1e3&&m<=1e3)return Cheat1::main();
    if(flag[0])return Cheat2::main();
}
int main(void){
	file();
    init();
    solve();
	return 0;
}

