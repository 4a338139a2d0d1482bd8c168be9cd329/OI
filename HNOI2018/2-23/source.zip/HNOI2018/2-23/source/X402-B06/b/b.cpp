#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	#endif
}
const int MAXN=1011;
static int n,k,p;
const int mod=1e9+7;
#define Chkmax(a,b) a=a>b?a:b
int main(void){
	file();
    read(n);read(k);read(p);
	if(n<=20)
    {
        int ans=0,a[MAXN];
        Rep(i,1,n)a[i]=i;
        bitset<1<<21>vis;
        do
        {
            vis.reset();
            int cnt=0,pos=0,ma;
            Rep(i,1,n-k+1)
            {
                pos=0;
                ma=0;
                Rep(j,i,i+k-1)
                {
                    pos|=1<<(a[j]-1);
                    Chkmax(ma,a[j]-1);
                }
                if(!vis[pos])vis.set(pos),++cnt;
                if(cnt>p)goto nx;
                Rep(j,i+k,n)if(a[j]<ma+1)
                {
                    pos^=1<<ma;
                    pos|=1<<(a[j]-1);
                    while(!(pos&(1<<ma)))--ma;
                    if(!vis[pos])
                    {
                        vis.set(pos),++cnt;
                        if(cnt>p)goto nx;
                    }
                }
            }
            if(cnt==p)++ans;
            nx:;
        }while(next_permutation(a+1,a+n+1));
        printf("%d\n",ans);
    }
    return 0;
}

