#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 10, Mod = 1e9+7 ;
int n, m, k, p, ans, rec ;
int a[maxn], b[maxn] ;
bool vis[maxn] ;
int t[maxn*maxn] ;
int ch[maxn][maxn], tot ;
void insert() {
	int i, c = 1 ;
	for ( i = 1 ; i <= k ; i ++ ) {
		if (ch[c][b[i]]) c = ch[c][b[i]] ;
		else {
			ch[c][b[i]] = ++tot ;
			c = tot ;
		}
		t[c] ++ ;
	}
	if (t[c] == 1) rec ++ ;
}
int solve() {
	int i, j, l ;
	rec = 0 ;
	memset (ch, 0, sizeof ch) ;
	memset (t, 0, sizeof t) ;
	tot = 1 ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = i+k-1 ; j <= n ; j ++ ) {
			for ( m = 0, l = i ; l <= j ; l ++ )
				b[++m] = a[l] ;
			sort(b+1, b+m+1) ;
			insert() ;
		}
	return rec ;
}
void dfs ( int stp ) {
	if (stp > n) {
		if (solve() == p)
			ans ++ ;
		return ;
	}
	for ( int i = 1 ; i <= n ; i ++ )
		if (!vis[i]) {
			vis[i] = 1 ;
			a[stp] = i ;
			dfs(stp+1) ;
			vis[i] = 0 ;
		}
}
void Force() {
	ans = 0 ;
	dfs(1) ;
	cout << ans << endl ;
}
void Fac() {
	for ( int i = rec = 1 ; i <= n ; i ++ )
		rec = (LL)i*rec%Mod ;
	cout << rec << endl ;
}
int main() {
	//Force
	freopen ( "b.in", "r", stdin ) ;
	freopen ( "b.out", "w", stdout ) ;
	Read(n), Read(k), Read(p) ;
	if (n <= 8) Force() ;
	else if ((k==1 && p==n) || (p==1 && k==n)) Fac() ;
	else if (p > n*(n+1)/2) puts("0") ;
	return 0 ;
}
