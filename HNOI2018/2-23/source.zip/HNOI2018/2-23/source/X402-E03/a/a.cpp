#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 4e5+5, block = sqrt(maxn) ;
int n, m, p, a[maxn], b[maxn] ;
int L[maxn], R[maxn], Last[maxn] ;
int as[maxn], f[maxn], c[maxn] ;
struct node {
	int l, r, id ;
	friend bool operator < ( node A, node B ) {
		if (A.l ^ B.l) return A.l < B.l ;
		if (A.r ^ B.r) return A.r < B.r ;
		return A.id < B.id ;
	}
} q[maxn] ;
void init() {
	sort(b+1, b+n+1) ;
	m = unique(b+1, b+n+1)-b-1 ;
	int i ;
	for ( i = 1 ; i <= n ; i ++ )
		a[i] = lower_bound(b+1, b+m+1, a[i])-b ;
	for ( i = 1 ; i <= n ; i ++ ) {
		(L[i] = Last[a[i]])[R] = i ;
		Last[a[i]] = i ;
	}
	R[0] = 0 ;
	//for ( i = 1 ; i <= n ; i ++ ) printf ( "[%d] L=%d R=%d\n", i, L[i], R[i] ) ;
}
void Force() {
	int ans, i, j, l, r ;
	bool ok ;
	for ( i = 1 ; i <= p ; i ++ ) {
		l = q[i].l, r = q[i].r ;
		for ( j = 1 ; j <= m ; j ++ ) c[j] = 0 ;
		f[l] = 0 ;
		ans = 0 ;
		ok = 1 ;
		for ( j = l ; j <= r ; j ++ ) {
			if (!j[L] || j[L] <= l) f[j] = 0 ;
			else if (j[L][L] < l || (j[L][L] >= l && j-j[L] == j[L]-j[L][L]))
				f[j] = f[j[L]] ;
			else f[j] = j[L] ;
			++ c[a[j]] ;
			if (c[a[j]] == 1) ans ++ ;
			if ((!R[j] || R[j] > r) && f[j] <= l)
				ok = 0 ;
		}
		ans += ok ;
		as[q[i].id] = ans ;
		if (q[i].id==55)
			cerr<<q[i].l<<" "<<q[i].r<<endl ;
	}
	for ( i = 1 ; i <= p ; i ++ )
		printf ( "%d\n", as[i] ) ;
}
int t[maxn] ;
void Update ( int x, int v ) {
	for ( ; x <= n ; x += (x&-x) )
		t[x] += v ;
}
int Query ( int x, int rec = 0 ) {
	for ( ; x ; x -= (x&-x) )
		rec += t[x] ;
	return rec ;
}
void solve1() {
	int lst = 0, i, j, rec = 0 ;
	memset (c, 0, sizeof c) ;
	for ( i = 1 ; i <= p ; i ++ ) {
		for ( j = lst+1 ; j <= q[i].r ; j ++ ) {
			if (!j[L]) f[j] = 0 ;
			else if (!j[L][L] || (j[L][L] && j-j[L] == j[L]-j[L][L]))
				f[j] = f[j[L]] ;
			else f[j] = j[L] ;
			if (j[L]) {
				if (Query(j[L]) - Query(j[L]-1) == 1)
					Update(j[L], -1) ;
			}
			if (f[j] == 0) Update(j, 1) ;
		}
		lst = q[i].r ;
		++c[a[i]] ;
		if (c[a[i]] == 1) ++ rec ;
		if (Query(n) > 0) as[q[i].id] = rec ;
		else as[q[i].id] = rec+1 ;
	}
	for ( i = 1 ; i <= p ; i ++ )
		printf ( "%d\n", as[i] ) ;
}
int curL, curR, rec ;
bool cmp ( node A, node B ) {
	if (A.l/block != B.l/block) return A.l < B.l ;
	if (A.r ^ B.r) return A.r < B.r ;
	return A.id < B.id ;
}
void add ( int x ) {
	c[a[x]] ++ ;
	if (c[a[x]] == 1) ++ rec ;
}
void remove ( int x ) {
	c[a[x]] -- ;
	if (c[a[x]] == 0) -- rec ;
}
void solve2() {
	sort(q+1, q+p+1, cmp) ;
	int i ;
	rec = c[a[1]] = 1 ;
	add(curL = curR = 1) ;
	for ( i = 1 ; i <= p ; i ++ ) {
		while (curL < q[i].l) remove(curL++) ;
		while (curL > q[i].r) add(--curL) ;
		while (curR < q[i].r) add(++curR) ;
		while (curR > q[i].r) remove(curR--) ;
		as[q[i].id] = rec ;
	}
	for ( i = 1 ; i <= p ; i ++ )
		printf ( "%d\n", as[i] ) ;
}
int main() {
	//Combined
	freopen ( "a.in", "r", stdin ) ;
	freopen ( "a.out", "w", stdout ) ;

	Read(n) ;
	int i ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(a[i]), b[i] = a[i] ;
	Read(p) ;
	for ( i = 1 ; i <= p ; i ++ )
		Read(q[i].l), Read(q[i].r), q[i].id = i ;
	sort(q+1, q+p+1) ;
	init() ;
	if (n <= 5e4 || p <= 10) Force() ;
	else if (q[p].l == 1) solve1() ;
	else solve2() ;
	return 0 ;
}
