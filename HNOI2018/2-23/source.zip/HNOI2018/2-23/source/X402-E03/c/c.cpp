#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
LL n, m ;
LL change ( LL &a, LL b ) {
	if (b == 1) {
		if (a <= 1) return a = 1 ;
		return a = 3 ;
	} else {
		if (a&1) return a = 3 ;
		return a = 2 ;
	}
}
void Force() {
	const LL maxn = 1e3+5 ;
	LL g[maxn][maxn], c[4] ;
	LL i, _ = m, tp, clr, pos ;
	memset (g, 0, sizeof g) ;
	memset (c, 0, sizeof c) ;
	c[0] = n*n ;
	while (_--) {
		Read(tp), Read(pos), Read(clr) ;
		++ clr ;
		if (tp == 1) {
			for ( i = 1 ; i <= n ; i ++ ) {
				c[g[pos][i]] -- ;
				c[change(g[pos][i], clr)] ++ ;
			}
		} else if (tp == 2) {
			for ( i = 1 ; i <= n ; i ++ ) {
				c[g[i][pos]] -- ;
				c[change(g[i][pos], clr)] ++ ;
			}
		} else {
			for ( i = 1 ; i <= n ; i ++ )
				if (pos - i > 0 && pos - i <= n) {
					c[g[i][pos-i]] -- ;
					c[change(g[i][pos-i], clr)] ++ ;
				}
		}
	}
	printf ( "%lld %lld %lld %lld\n", c[0], c[1], c[2], c[3] ) ;
}
void solve1() {
	const LL maxn = 1e5+5 ;
	LL g[maxn], c[4] ;
	LL _ = m, tp, clr, pos ;
	memset (g, 0, sizeof g) ;
	memset (c, 0, sizeof c) ;
	c[0] = n ;
	while (_--) {
		Read(tp), Read(pos), Read(clr) ;
		c[g[pos]] -- ;
		c[change(g[pos], clr)] ++ ;
	}
	printf ( "%lld %lld %lld %lld\n", c[0]*n, c[1]*n, c[2]*n, c[3]*n ) ;
}
int main() {
	//Combined
	freopen ( "c.in", "r", stdin ) ;
	freopen ( "c.out", "w", stdout ) ;
	Read(n), Read(m) ;
	if (n <= 1e3) Force() ;
	else solve1() ;
	return 0 ;
}
