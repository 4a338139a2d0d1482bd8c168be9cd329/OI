#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1010, INF = 0x3f3f3f3f, Mod = 1e9 + 7;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
#endif 
}
int n, k, fac[N], p;
void init(){
	read(n), read(k), read(p);
	fac[0] = 1;
	For(i, 1, n)fac[i] = fac[i - 1] * 1ll * i % Mod;
}
int ans = 0;
int V[N], P[N], st[N], vis[N];
int Get(int l,int r){
	For(i, l, r)st[i] = P[i];
	sort(st + l, st + r + 1);
	int sta = 0;
	For(i, l, l + k - 1)sta |= (1<<(st[i] -1));
	return sta; 
}
void dfs(int now){
	if(now > n){
		int ret = 0;
		For(l, 1, n - k + 1)
			For(r, l + k - 1, n){
				int t = Get(l, r);
				if(!vis[t])vis[t] = 1, ret++;
			}
		For(l, 1, n - k + 1)
			For(r, l + k - 1, n){
				int t = Get(l, r);
				vis[t] = 0;
			}
		if(ret == p)ans ++ ;
		return ;
	}
	For(i, 1, n)if(!V[i]){
		V[i] = 1;P[now] = i;
		dfs(now + 1);
		V[i] = 0;
	}
}
void solve(){
	if(n <= 9){
		dfs(1);
		printf("%d\n",ans);
		return ;
	}
	if(k == 1 && p == n){
		return void (printf("%d\n", fac[n]));
	}else if(k == n && p == 1){
		return void (printf("%d\n", fac[n]));
	}else if(p > 1ll * n * (n + 1) / 2){
		return void (puts("0"));
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
