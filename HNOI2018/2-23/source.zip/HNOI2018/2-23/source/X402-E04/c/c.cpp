#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100100, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char  c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
#endif 
}
int n, m, q;
namespace BF1{
	const int N = 2e3 + 10;
	int a[N][N];
	int solve(){
		int w = n * n, g = 0, y = 0, r = 0;
		For(i, 1, n)For(j, 1, n)a[i][j] = 0;
		For(i, 1, m){
			int tp, ps, cl, v;
			read(tp), read(ps), read(cl);
			if(cl == 0)v = 2;else v = 1;
			if(tp == 1){
				For(j, 1, n){
					g -= (a[ps][j] == 2), y -= (a[ps][j] == 3);
					r -= (a[ps][j] == 1), w -= (a[ps][j] == 0);
				}
				For(j, 1, n)a[ps][j] |= v;
				For(j, 1, n){
					g += (a[ps][j] == 2), y += (a[ps][j] == 3);
					r += (a[ps][j] == 1), w += (a[ps][j] == 0);
				}
			}else if(tp == 2){
				For(j, 1, n){
					g -= (a[j][ps] == 2), y -= (a[j][ps] == 3);
					r -= (a[j][ps] == 1), w -= (a[j][ps] == 0);
				}
				For(j, 1, n)a[j][ps] |= v;
				For(j, 1, n){
					g += (a[j][ps] == 2), y += (a[j][ps] == 3);
					r += (a[j][ps] == 1), w += (a[j][ps] == 0);
				}
			}
			else if(tp == 3){
				For(j, 1, min(ps - 1, n))if(ps - j > 0 && ps - j <= n){
					g -= (a[j][ps - j] == 2), y -= (a[j][ps - j] == 3);
					r -= (a[j][ps - j] == 1), w -= (a[j][ps - j] == 0);
				}
				For(j, 1, min(ps - 1, n))if(ps - j > 0 && ps - j <= n)a[j][ps - j] |= v;
				For(j, 1, min(ps - 1, n))if(ps - j > 0 && ps - j <= n){
					g += (a[j][ps - j] == 2), y += (a[j][ps - j] == 3);
					r += (a[j][ps - j] == 1), w += (a[j][ps - j] == 0);
				}
			}

		}
		printf("%d %d %d %d\n",w,g,r,y);
	}
}
namespace BF2{
	ll cnth, cntl;
	int cth[N], ctl[N],ccl[4];
	void solve(){
		ll w = n * n, g = 0, y = 0, r = 0;
		cnth = cntl = 0;
		memset(cth, 0, sizeof(cth));
		memset(ctl, 0, sizeof(ctl));

		For(i, 1, m){
			int tp, ps, cl, v;
			read(tp), read(ps), read(cl);

			if(cl == 0)v = 2;else v = 1;
			if(tp == 1){
				if(!cth[ps])cnth ++ ;
				cth[ps] |= v;
			}else if(tp == 2){
				if(!ctl[ps])cntl ++ ;
				ctl[ps] |= v;
			}

		}
		For(i, 1, n)ccl[ctl[i]] ++;
		For(i, 1, n){
			if(cth[i] == 3){
				y += n;
			}else if(cth[i] == 1){
				r += n;
				int dy = ccl[2] + ccl[3];
				r -= dy, y += dy;
			}else if(cth[i] == 2){
				g += n;
				int dy = ccl[1] + ccl[3];
				g -= dy, y += dy;
			}else if(cth[i] == 0){
				g += ccl[2], r += ccl[1], y += ccl[3];
			}
		}
		w = n * n - g - r - y;
		printf("%lld %lld %lld %lld\n",w,g,r,y);
	}
}
void init(){
	read(n), read(m);

}	
void solve(){
	if(n<=1000)BF1::solve();
	else BF2::solve();
}
int main(){
	file();
	init();
	solve();
	return 0;
}
