#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 400010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c)) c = getchar();
	while( isdigit(c)) x = x * 10 + c - 48, c = getchar();
}
int a[N], n;
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
#endif 
}
int q;
struct Qu{
	int l, r, id;
	bool operator < (const Qu & R)const {
		return r < R.r;
	}
}Q[N];
int ans[N];
vector<int>P[N];
struct Bit{
	int t[N];
	inline int lowbit(int x){return x & -x;}
	void add(int x, int v){for(; x; x -= lowbit(x))t[x] += v;}
	int Querys(int x){
		int r = 0;
		for(; x <= n; x += lowbit(x))r += t[x];
		return r;
	}
}T1, T2;
int maxa;
int pos[N];
vector<int>p[N];
vector<int>pp[N];
void init(){
	read(n);
	For(i, 1, n)read(a[i]), P[a[i]].push_back(i), maxa = max(maxa, a[i]);
	read(q);
	For(i, 1, q)
		read(Q[i].l), read(Q[i].r), Q[i].id = i;
	sort(Q + 1, Q + q + 1);
	For(i, 1, maxa){
		int S = P[i].size();
		int lst = -1;
		For(j, 0, S - 1){
			int l = j, r = j + 1;
			while(r < S - 1 && P[i][r + 1] - P[i][r] == P[i][j + 1] - P[i][j]) r++;
			j = r - 1;
			if(lst > 0){
				if(P[i][lst - 1] == p[i].back()){
					if(lst < 2)pp[i].push_back(-1);
					else pp[i].push_back(P[i][lst - 2]);
				}else pp[i].push_back(P[i][lst - 1]);
			}else pp[i].push_back(-1);
			p[i].push_back(P[i][l]);
			lst = l;
		}
	}
}
int last[N],lst[N];
void solve(){
	int nowr = 0;
	For(i, 1, maxa)pos[i] = -1;
	For(i, 1, q){
		while(nowr < Q[i].r){
			nowr++;
			int v = a[nowr];
			if(last[v])
				T2.add(last[v], -1);
			T2.add(nowr, 1);
			last[v] = nowr;
			if(lst[v])
				T1.add(lst[v], -1);
			T1.add(nowr, 1);lst[v] = nowr;
			while(pos[v] + 1< p[v].size() && p[v][pos[v] + 1] <= nowr){
				if(pos[v] >= 0 && pp[v][pos[v]] > 0)
					T1.add(pp[v][pos[v]], 1);
				if(++pos[v] >= 0 && pp[v][pos[v]] > 0)
					T1.add(pp[v][pos[v]], -1);
			}
		}
		ans[Q[i].id] = T2.Querys(Q[i].l) + 1 - 
			(T1.Querys(Q[i].l) > 0);
	}
	For(i, 1, q)printf("%d\n", ans[i]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
