#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 400010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c)) c = getchar();
	while( isdigit(c)) x = x * 10 + c - 48, c = getchar();
}
int a[N], n;
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("a.in","r",stdin);
	freopen("BF.out","w",stdout);
#endif 
}
void init(){
	read(n);
	For(i, 1, n)read(a[i]);
}
int vis[N];
void solve(){
	int q;
	read(q);
	while(q--){
		int l, r, ans = 1;
		read(l), read(r);
		For(i, l, r)if(!vis[a[i]])vis[a[i]] = 1, ans ++;
		For(i, l, r)vis[a[i]] = 0;
		vector<int>P;
		For(i, l, r)
			if(!vis[a[i]]){
				vis[a[i]] = 1;
				P.clear();
				For(j, l, r)if(a[j] == a[i])P.push_back(j);
				int S = P.size(), ok = 1;
				For(j, 2, S - 1)
					if(P[j] - P[j - 1] != P[j - 1] - P[j - 2]){ok = 0;break;}
				if(ok){ans -= ok;break;}
			}
		For(i, l, r)vis[a[i]] = 0;
		printf("%d\n",ans);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
