#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int Mod=1e9+7;
int n,p,k;
long long dp[2][1000010];
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	n=read();k=read();p=read();
	if ((k==1 && p==n) || (k==n && p==1)){
		long long ans=1;
		for (int i=1;i<=n;++i)
			ans=(ans*i)%Mod;
		printf("%lld\n",ans);
		return 0;
	}
	if (p==n-k+1){
		printf("1\n");
		return 0;	
	}
	if (p>n*(n+1)/2){
		printf("0\n");
		return 0;	
	}
	int now=k%2;
	dp[now][1]=1;
	for (int i=1;i<=k;++i)
		dp[now][1]=(dp[now][1]*i)%Mod;
	for (int i=k;i<n;++i){
		if (i!=k) dp[now][1]=0;
		for (int j=1;j<=p;++j)
			dp[now^1][j]=0;
		for (int j=1;j<=i+1;++j){
			int l,r;
			l=j-k+1;
			l=max(l,1);
			r=i+1-k+1;
			r=min(r,j);
			r=r-l+1;
			//printf("%d\n",r);
			for (int t=1;t<=p-r;++t)
				dp[now^1][t+r]=(dp[now^1][t+r]+dp[now][t])%Mod;	
		}
	/*	for (int j=1;j<=p;++j)
			printf("%d %d %lld\n",i,j,dp[now][j]);*/
		now^=1;
	}
	printf("%lld\n",dp[now][p]);
	return 0;
}

