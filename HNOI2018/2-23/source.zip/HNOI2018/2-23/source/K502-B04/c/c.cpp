#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int N=1e5+5;
int a[1010][1010];
int n,m,cnt[4];
long long ans[4];
struct node{
	int t,p,c;
}s[N];
int flag=1,flag2=1;
int u[N],v[N],p1[N],p2[2*N];
int l1[N],l2[N],tot1,tot2;
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	n=read();m=read();
	if (n<=1000 && m<=1000){
		while (m--){
			int t=read(),p=read(),c=read()+1;
			if (t==1){
				for (int i=1;i<=n;++i){
					if (a[p][i]==0) a[p][i]=c;
					else if (a[p][i]!=c) a[p][i]=3;
				}
			}
			if (t==2){
				for (int i=1;i<=n;++i){
					if (a[i][p]==0) a[i][p]=c;
					else if (a[i][p]!=c) a[i][p]=3;
				}	
			}
			if (t==3){
				for (int i=1;i<=n;++i){
					int j=p-i;
					if (j<=0 || j>n) continue;
					if (a[i][j]==0) a[i][j]=c;
					else if (a[i][j]!=c) a[i][j]=3;
				}
			}
		}
		for (int i=1;i<=n;++i)
			for (int j=1;j<=n;++j)
				cnt[a[i][j]]++;
		for (int i=0;i<3;++i)
			printf("%d ",cnt[i]);
		printf("%d\n",cnt[3]);
		return 0; 
	}
	for (int i=1;i<=m;++i){
		s[i].t=read();
		s[i].p=read();
		s[i].c=read()+1;
		if (s[i].t==3) flag=0;	
		if (s[i].c!=1) flag2=0;
	}
	if (flag){
		for (int i=1;i<=m;++i){
			if (s[i].t==1){
				if (u[s[i].p]==0) u[s[i].p]=s[i].c;
				else if (u[s[i].p]!=s[i].c) u[s[i].p]=3;
			}else{
				if (v[s[i].p]==0) v[s[i].p]=s[i].c;
				else if (v[s[i].p]!=s[i].c) v[s[i].p]=3;
			}
		}
		for (int i=1;i<=n;++i)
			cnt[v[i]]++;
		for (int i=1;i<=n;++i){
			int c=u[i];
			if (c==3) ans[3]+=n;
			else if (c==0){
				for (int j=0;j<=3;++j)
					ans[j]+=cnt[j];
			}else if (c==2){
				int k=cnt[1]+cnt[3];
				ans[3]+=k;
				ans[2]+=n-k;	
			}else{
				int k=cnt[2]+cnt[3];
				ans[3]+=k;
				ans[1]+=n-k;
			}
		}
		for (int i=0;i<3;++i)
			printf("%lld ",ans[i]);
		printf("%lld\n",ans[3]);
		return 0; 
	}
	return 0;
}

