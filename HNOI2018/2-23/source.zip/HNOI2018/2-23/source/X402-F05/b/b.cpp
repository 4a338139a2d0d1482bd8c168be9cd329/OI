#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int Mod = 1e9 + 7;
const int N = 10;

int n, k, p;
int P[N];
int S[1 << N];

int main() {

	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	scanf("%d%d%d", &n, &k, &p);
	
	if ((k == 1 && p == n) || (k == n && p == 1)) {
		int ans = 1;
		For(i, 1, n) ans = 1ll * ans * i % Mod;
		printf("%d\n", ans);
	} else if (p > 1ll * n * (n + 1) / 2) {
		puts("0");
	} else if (p == n - k + 1) puts("2");

	int m = 1, ans = 0;
	For(i, 1, n) P[i] = i, m *= i;
	while (m--) {

		int c = 0;
		For(l, 1, n) For(r, l + k - 1, n) {
			int num = 0, cnt = 0;
			For(i, l, r) num |= 1 << P[i];
			For(i, 1, n) if (num & (1 << i)) {
				if (cnt < k) ++cnt;
				else num ^= (1 << i);
			}
			S[++c] = num;
		}

		sort(S + 1, S + c + 1);
		c = unique(S + 1, S + c + 1) - S - 1;

		ans += c == p;

		next_permutation(P + 1, P + n + 1);
	}

	printf("%d\n", ans);

	return 0;
}
