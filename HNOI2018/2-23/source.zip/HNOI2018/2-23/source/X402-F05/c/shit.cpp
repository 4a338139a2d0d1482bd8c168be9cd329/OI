#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 300010;
const int Mod = 998244353, r = 3;

int n, m;
int cx[N], cy[N], cz[N];
int cntx[N], cnty[N];
int crx[N], cgx[N], cry[N], cgy[N];

int main() {

	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, m) {
		int ty, x, c;
		scanf("%d%d%d", &ty, &x, &c);
		if (ty == 1) cx[x] |= 1 << c;
		else if (ty == 2) cy[x] |= 1 << c;
		else cz[x] |= 1 << c;
	}

	// white
	LL ret = 0, white, green;
	For(i, 1, n) cntx[i] = cntx[i - 1] + (cx[i] > 0);
	For(i, 1, n) cnty[i] = cnty[i - 1] + (cy[i] > 0);
	For(i, 2, 2 * n) if (cz[i]) ret += min(i - 1, 2 * n - i + 1);
	ret += 1ll * (cntx[n] + cnty[n]) * n - 1ll * cntx[n] * cnty[n];
	
	For(i, 2, n) if (cz[i]) ret -= cntx[i - 1] + cnty[i - 1];
	For(i, n + 1, 2 * n) if(cz[i]) ret -= cntx[n] - cntx[i - n - 1] + cnty[n] - cnty[i - n - 1];
	For(i, 1, n) if (cx[i]) For(j, 1, n) if (cy[j] && cz[i + j]) ++ret;

	printf("%lld ", white = 1ll * n * n - ret);
	ret = 0;

	#define red(x) ((x) && ((x) != 1))

	// green
	For(i, 1, n) cgx[i] = cgx[i - 1] + (cx[i] == 1);
	For(i, 1, n) cgy[i] = cgy[i - 1] + (cy[i] == 1);
	For(i, 2, 2 * n) if (red(cz[i])) ret += min(i - 1, 2 * n - i + 1);
	ret += 1ll * (cgx[n] + cgy[n]) * n - 1ll * cgx[n] * cnty[n] - 1ll * cgy[n] * cntx[n] + 1ll * cgx[n] * cgy[n];
	
	For(i, 2, n) if (cz[i] == 1) ret -= cntx[i - 1] + cnty[i - 1];
	For(i, n + 1, 2 * n) if(cz[i] == 1) ret -= cntx[n] - cntx[i - n - 1] + cnty[n] - cnty[i - n - 1];
	For(i, 2, n) if (red(cz[i])) ret -= cgx[i - 1] + cgy[i - 1];
	For(i, n + 1, 2 * n) if(red(cz[i])) ret -= cgx[n] - cgx[i - n - 1] + cgy[n] - cgy[i - n - 1];

	For(i, 1, n) if (cx[i]) For(j, 1, n) if (cy[j] && cz[i + j])
		ret += (red(cx[i]) + red(cy[j]) + red(cz[i + j])) <= 1;
	printf("%lld ", green = ret);
	
	#undef red

	return 0;
}
