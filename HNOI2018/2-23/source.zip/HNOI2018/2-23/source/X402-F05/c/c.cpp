#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 300010;
const int Mod = 998244353, r = 3;

int n, m;
int cx[N], cy[N], cz[N];

namespace BF {
	
	LL ans[4];

	void main() {
		For(i, 1, n) For(j, 1, n) ans[cx[i] | cy[j] | cz[i + j]]++;
		For(i, 0, 3) printf("%lld%c", ans[i], i == 3 ? '\n' : ' ');
	}
};

namespace Solver {

	int rev[N], s = 1, inv;

	int Pow(int x, int e) {
		int ret = 1;
		while (e) {
			if (e & 1) ret = 1ll * ret * x % Mod;
			x = 1ll * x * x % Mod;
			e >>= 1;
		}
		return ret;
	}

	int w[N];

	void DFT(int *A, int f) {
		For (i, 0, s - 1) if (i < rev[i]) swap(A[i], A[rev[i]]);
		for (int i = 1; i < s; i <<= 1) {
			w[1] = Pow(r, (Mod - 1) / (i << 1)), w[0] = 1;
			if (f == -1) w[1] = Pow(w[1], Mod - 2);
			for (int j = 2; j < i; ++j) w[j] = 1ll * w[1] * w[j - 1] % Mod;
			
			for (int j = 0; j < s; j += (i << 1))
				for (int k = 0; k < i; ++k) {
					int x = A[j + k], y = 1ll * A[i + j + k] * w[k] % Mod;
					A[j + k] = (x + y) % Mod, A[i + j + k] = (x - y + Mod) % Mod;
				}
		}
	}

	void mult(int *A, int *B) {
		DFT(A, 1), DFT(B, 1);
		For(i, 0, s - 1) A[i] = 1ll * A[i] * B[i] % Mod;
		DFT(A, -1);
		For(i, 0, s - 1) A[i] = 1ll * A[i] * inv % Mod;
	}

	LL ans[4];
	int A[N], B[N];

	void main() {

		while (s <= n) s <<= 1;
		s <<= 1;
		For(i, 0, s - 1) rev[i] = (rev[i >> 1] >> 1) | ((i & 1) * (s >> 1));
		inv = Pow(s, Mod - 2);

		For(i, 0, 3) For(j, 0, 3) if ((i | j) != 3){
			For(p, 0, s - 1) A[p] = B[p] = 0;
			For(p, 1, n) A[p] = cx[p] == i, B[p] = cy[p] == j;
			mult(A, B);
			For(p, 2, 2 * n) ans[i | j | cz[p]] += A[p];
		}

		ans[3] = 1ll * n * n;
		For(i, 0, 2) ans[3] -= ans[i];
		For(i, 0, 3) printf("%lld%c", ans[i], i == 3 ? '\n' : ' ');
	}

};

int main() {

	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	scanf("%d%d", &n, &m);

	int stype = 0, sc = 0;
	For(i, 1, m) {
		int ty, x, c;
		scanf("%d%d%d", &ty, &x, &c);
		if (ty == 1) cx[x] |= 1 << c;
		else if (ty == 2) cy[x] |= 1 << c;
		else cz[x] |= 1 << c;

		--ty;
		stype |= 1 << ty, sc |= 1 << c;
	}

	if (n <= 1000) BF::main();
	else Solver::main();

	return 0;
}
