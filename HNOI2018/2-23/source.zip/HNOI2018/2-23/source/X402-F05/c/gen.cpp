#include <bits/stdc++.h>

int limt = 3, limc = 1;

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("c.in", "w", stdout);
	int n = 50000, q = 50000;
	printf("%d %d\n", n, q);

	while (q--) printf("%d %d %d\n", randint(1, limt), randint(1, n), randint(0, limc));
	
	
	return 0;
}
