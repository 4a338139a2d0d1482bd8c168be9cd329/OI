#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 4e5 + 10;
const int SZ = 300;

typedef long long LL;

int n, q, A[N];
int pre[N], suc[N], head[N], tail[N];

struct Query {

	int l, r, id;

	bool operator < (const Query& B) const {
		return l / SZ == B.l / SZ ? (l / SZ % 2 ? r < B.r : r > B.r) : l < B.l;
	}
}Q[N];

int answer[N];

namespace BF {

	LL sqr[N];
	int cnt[N], val[N];
	bool ok[N];
	int ans, cexp;

	void check(int x) {
		bool f = val[x] * (cnt[x] - 1) == tail[x] - head[x] && 1ll * val[x] * val[x] * (cnt[x] - 1) == sqr[x];
		if (ok[x] && !f) --cexp;
		if (!ok[x] && f) ++cexp;
		ok[x] = f;
	}

	void add(int x) {
		int v = A[x];
		++cnt[v];
		if (cnt[v] == 1) {
			++cexp, ++ans, ok[v] = true;
			head[v] = tail[v] = x;
			return;
		}

		int d;
		if (x < head[v]) d = head[v] - x, head[v] = x;
		else d = x - tail[v], tail[v] = x;
		sqr[v] += 1ll * d * d, val[v] = d;
		check(v);
	}

	void del(int x) {
		int v = A[x];
		--cnt[v];
		if (!cnt[v]) {
			--cexp, --ans, ok[v] = false;
			return;
		}

		int d;
		if (x == head[v]) d = suc[x] - x, head[v] = suc[x];
		else d = x - pre[x], tail[v] = pre[x];
		sqr[v] -= 1ll * d * d, val[v] = tail[v] - pre[tail[v]];
		check(v);
	}


	void main() {
		sort(Q + 1, Q + q + 1);
		int l = 1, r = 0;
		
		For(i, 1, q) {
			while (l > Q[i].l) add(--l);
			while (r < Q[i].r) add(++r);
			while (l < Q[i].l) del(l++);
			while (r > Q[i].r) del(r--);
			answer[Q[i].id] = ans + (cexp == 0);
		}
		For(i, 1, q) printf("%d\n", answer[i]);
	}

};

namespace Cheat {

	int c[N];

	int lowbit(int x) {
		return x & (-x);
	}

	void add(int x, int v) {
		while (x <= n) {
			c[x] += v;
			x += lowbit(x);
		}
	}

	int sum(int x) {
		int ret = 0;
		while (x) {
			ret += c[x];
			x -= lowbit(x);
		}
		return ret;
	}

	bool cmp(const Query& A, const Query& B) {
		return A.l < B.l;
	}

	void main() {
		sort(Q + 1, Q + q + 1, cmp);
		int p = 1;
		For(i, 1, n) if (!pre[i]) add(i, 1);
		For(i, 1, n) {
			while (p <= q && Q[p].l == i) answer[Q[p].id] = sum(Q[p].r), ++p;
			add(i, -1);
			if(suc[i]) add(suc[i], 1);
		}
		For(i, 1, q) printf("%d\n", answer[i]);
	}

};

int main() {

	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &A[i]), pre[i] = head[A[i]], head[A[i]] = i;
	Forr(i, n, 1) suc[i] = tail[A[i]], tail[A[i]] = i;

	scanf("%d", &q);

	bool l1 = true;
	For(i, 1, q) scanf("%d%d", &Q[i].l, &Q[i].r), Q[i].id = i, l1 &= Q[i].l == 1;

	if (n <= 60000 || l1) BF::main();
	else Cheat::main();
	
	return 0;
}
