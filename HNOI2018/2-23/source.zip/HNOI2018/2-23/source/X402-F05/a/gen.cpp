#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int main() {

	freopen("a.in", "w", stdout);

	int n = 100000, q = 100000;
	printf("%d\n", n);
	For(i, 1, n) printf("%d%c", rand() % 100000 + 1, i == n ? '\n' : ' ');
	printf("%d\n", q);
	For(i, 1, q) {
		int l = rand() % n + 1, r = rand() % n + 1;
		if (l > r) swap(l, r);
		printf("%d %d\n", l, r);
	}

	return 0;
}
