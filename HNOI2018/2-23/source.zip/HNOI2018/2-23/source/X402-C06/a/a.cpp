#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

template<typename T>
inline void write(T &x){
	int flag=0;
	if(x==0){
		putchar('0');
		return;
	}
	if(x<0) x=-x,flag=-1;
	int dg[20],len=0;
	while(x){
		dg[++len]=x%10;
		x/=10;
	}
	if(flag==-1) putchar('-');
	Forr(i,len,1) putchar(dg[i]+'0');
	putchar('\n');
}

inline void file(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}

const int maxn=4e5+10;
int a[maxn],n,q,L,R,temp[maxn];
int	op[maxn],tot,vis[maxn];
vector<int> pos[maxn];
int uni[maxn],sum,flag,Flag;
int Begin,End;

inline void Init(){
	read(n);
	For(i,1,n){
		read(a[i]);	
		if(!op[a[i]]) tot++;
		op[a[i]]++;
		pos[a[i]].push_back(i);
	}
}

inline void Solve(){
	read(q);
	while(q--){
		memset(uni,0,sizeof(uni));
		memset(vis,0,sizeof(vis));
		sum=Flag=0;
		read(L),read(R);
		For(i,L,R){
			if(!uni[a[i]]) sum++;
			uni[a[i]]++;
		}	
		For(i,1,n){
			if(vis[a[i]]) continue;
			vis[a[i]]=1,flag=0;	
			Begin=INT_MAX,End=INT_MIN;
			int f1=0;
			For(j,0,pos[a[i]].size()-1){
				if(L<=pos[a[i]][j] && pos[a[i]][j]<=R) 
					Begin=min(Begin,j),End=max(End,j),f1=1;	
				if(pos[a[i]][j]>R) break;
			}
			if(!f1) continue;
			if(Begin==End && Begin+1==End){
				Flag=1;break;;
			}	
			int cha=pos[a[i]][Begin+1]-pos[a[i]][Begin];
			For(j,Begin+1,End){
				if(pos[a[i]][j]-pos[a[i]][j-1]!=cha){
					flag=1;break;
				}
			}	
			if(!flag){Flag=1;break;}
		}
		if(Flag) printf("%d\n",sum);
		else printf("%d\n",sum+1);
	}
}

int main(){
	file();
	Init();
	Solve();
	return 0;
}

