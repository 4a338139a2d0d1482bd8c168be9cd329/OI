#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}

typedef long long ll;
const ll mod=1e9+7;
const int maxn=1e3+10;
int n,k,p,ans,tot,e;
int a[maxn],temp[maxn],mp[maxn];

inline void Init(){
	read(n),read(k),read(p);
	For(i,1,n) a[i]=i;
}

inline void Clear(){
	memset(mp,0,sizeof(mp));
	tot=0;
}

bool check(){	
	For(i,1,n-k+1) For(j,i+k-1,n){
		For(t,i,j)
			temp[t]=a[t];
			sort(temp+i,temp+j+1);	
			int hash=0;
			For(now,i,i+k-1) hash+=(1<<(temp[now]));	
			mp[hash]=1;
	}
	For(i,1,600) if(mp[i]) tot++;
	if(tot==p) return true;
	else return false;
}

inline void BF_Solve(){
	do{
		Clear();
		if(check()) ans++;
	}while(next_permutation(a+1,a+1+n));
	printf("%d\n",ans);
	return;
}

ll ksm(ll a,ll b){
	ll res=1;
	while(b){
		if(b&1) (res*=a)%=mod;
		(a*=a)%=mod;
		b>>=1;
	}
	return res;
}

inline void Cheat(){
	if(k==1 && p==n || k==n && p==1){
		ll ans=1;
		For(i,2,n) (ans*=i)%=mod;
		printf("%lld\n",ans);
		return;
	}
	if(p>(n*(n+1)/2)){ 
		printf("0\n");
		return;
	}
	if(p==n-k+1){
		ll ans=ksm(2,n-1);
		for(register ll i=2;i<=k;++i)
			ans=(ans*i)%mod*ksm(2,mod-2)%mod;
		printf("%lld\n",ans);
		return;
	}
}

int main(){
	file();
	Init();
	if(n<=8) BF_Solve();
	else Cheat();
	return 0;
}

