#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}

typedef long long ll;
const int N=1e3+10,maxn=1e5+10;
int n,m,a[N][N],cnt[5];
int op,pos,color;
int S[maxn];
ll ans[5];

int update(int x,int y){
	if(x==0) return y;
	if(x==3) return x;
	if(x==y) return x;
	if(x==1 && y==2 || x==2 && y==1) return 3;
}

inline void BF_Solve(){
	while(m--){
		read(op),read(pos),read(color),color++;
		if(op==1){ 
			For(i,1,n) 
				a[pos][i]=update(a[pos][i],color);
		}else if(op==2){
			For(i,1,n)
				a[i][pos]=update(a[i][pos],color);
		}else{
			For(i,1,pos-1)
				a[i][pos-i]=update(a[i][pos-i],color);	
		}
	}
	For(i,1,n) For(j,1,n) cnt[a[i][j]]++;
	For(i,0,3) printf("%d ",cnt[i]);
	putchar('\n');
}

inline void Cheat(){
	ans[0]=(ll)n*(ll)n;
	while(m--){
		read(op),read(pos),read(color),color++;
		ans[S[pos]]-=(ll)n;
		S[pos]=update(S[pos],color);
		ans[S[pos]]+=(ll)n;
	}
	For(i,0,3) printf("%lld ",ans[i]);
	putchar('\n');
}

int main(){
	file();
	read(n),read(m);
	if(n<=1001)	BF_Solve();
	else Cheat();
	return 0;
}

