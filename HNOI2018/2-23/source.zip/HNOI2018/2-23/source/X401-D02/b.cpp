#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Sint static int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	x=x*w;
}
Temp inline void write(T x){
	T y=10,len=1;
	if(x<0)putchar('-'),x=-x;
	while(y<=x)y=(y<<3)+(y<<1),len++;
	while(len--)y/=10,putchar(x/y+'0'),x%=y;
}
inline void File(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}


int main(){
	File();
	cout<<2<<endl;
	return 0;
}
