#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Sint static int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
using namespace std;
Temp inline void read(T &x){
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	x=x*w;
}
Temp inline void write(T x){
	T y=10,len=1;
	if(x<0)putchar('-'),x=-x;
	while(y<=x)y=(y<<3)+(y<<1),len++;
	while(len--)y/=10,putchar(x/y+'0'),x%=y;
}
inline void File(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}

const int maxn=1e5+10;
int n,m;
int x[maxn],y[maxn],z[maxn<<1];

inline void do1(){
	int W=0,G=0,R=0,Y=0;
	for(Rint i=1;i<=n;i++){
		for(Rint j=1;j<=n;j++){
			if(x[i]==3||y[j]==3||z[i+j]==3){Y++;continue;}
			int k[5]={0};
			k[x[i]]++;k[y[j]]++;k[z[i+j]]++;
			if(k[1]>=1&&k[2]>=1){Y++;continue;}
			if(k[1]>=1&&k[2]==0){G++;continue;}
			if(k[2]>=1&&k[1]==0){R++;continue;}
			if(k[1]==0&&k[2]==0){W++;continue;}
		}
	}
	write(W);putchar(' ');
	write(G);putchar(' ');
	write(R);putchar(' ');
	write(Y);putchar('\n');
}
inline void do2(){
	int W=0,G=0,R=0,Y=0;
	for(Rint i=1;i<=n;i++){
		if(x[i]==1)G+=n;
		else if(x[i]==2)R+=n;
		else if(x[i]==3)Y+=n;
		else W+=n;
	}
	write(W);putchar(' ');
	write(G);putchar(' ');
	write(R);putchar(' ');
	write(Y);putchar('\n');
}
inline void do3(){
	int W=0,G=0,R=0,Y=0;
	int W1=0,G1=0,R1=0,Y1=0;
	for(Rint i=1;i<=n;i++){
		if(x[i]==1)G+=n,G1++;
		else if(x[i]==2)R+=n,R1++;
		else if(x[i]==3)Y+=n,Y1++;
		else W+=n,W1++;
	}
	for(Rint i=1;i<=n;i++){
		if(y[i]==1){
			W-=W1;G+=W1;
			R-=R1;Y+=R1;
		}
		else if(y[i]==2){
			W-=W1;R+=W1;
			G-=G1;Y+=G1;
		}
		else if(y[i]==3){
			W-=W1;Y+=W1;
			G-=G1;Y+=G1;
			R-=R1;Y+=R1;
		}
	}
	write(W);putchar(' ');
	write(G);putchar(' ');
	write(R);putchar(' ');
	write(Y);putchar('\n');
}
inline void do4(){
	
}

bool flag1,flag2,flag3;

int main(){
	File();
	read(n);read(m);
	for(Rint i=1;i<=m;i++){
		int opt,p,c;
		read(opt);read(p);read(c);c++;
		if(c!=1)flag3=1;
		if(opt==1&&x[p]!=c){
			if(x[p]==3)continue;
			x[p]+=c;
		}
		else if(opt==2&&y[p]!=c){
			flag1=1;
			if(y[p]==3)continue;
			y[p]+=c;
		}
		else if(opt==3&&z[p]!=c){
			flag1=1;flag2=1;
			if(z[p]==3)continue;
			z[p]+=c;
		}
	}
	if(n<=1000&&m<=1000)do1();
	else if(flag1==0)do2();
	else if(flag2==0)do3();
	else if(flag3==0)do4();
	return 0;
}
