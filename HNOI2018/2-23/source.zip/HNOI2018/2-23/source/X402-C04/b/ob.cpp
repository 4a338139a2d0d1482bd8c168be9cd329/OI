#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int P=1e7+9;
const int md=1e9+7;

int n,k,p;
int f[2][P];

inline void chk(int &a){if(a>=md)a-=md;}

int main()
{
	freopen("b.in","r",stdin);
	freopen("bs.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);

	f[k&1][1]=1;
	for(int i=2;i<=k;i++)
		f[k&1][1]=(ll)f[k&1][1]*(ll)i%md;

	for(int i=k;i<n;i++)
	{
		memset(f[i&1^1],0,sizeof(f[i&1^1][0])*(p+4));
		for(int j=1;j<k && j+k-2<=i;j++)
			for(int l=0;l+j<=p;l++)
				chk(f[i&1^1][l+j]+=2ll*f[i&1][l]%md);
		if(k+k-2<=i)
			for(int l=0;l+k<=p;l++)
				chk(f[i&1^1][l+k]+=(ll)(i+3ll-2ll*k)*f[i&1][l]%md);
		else
			for(int l=0;l+(i+2-k)<=p;l++)
				chk(f[i&1^1][l+(i+2-k)]+=(ll)(2ll*k-i-3ll)*f[i&1][l]%md);
	}

	printf("%d\n",f[n&1][p]);
	return 0;
}
