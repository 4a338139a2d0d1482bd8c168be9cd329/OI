#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int P=1e7+9;
const int md=1e9+7;

int n,k,p;
int f[2][P],buc[P];

inline void chk(int &a){if(a>=md)a-=md;}

int main()
{
	freopen("b.in","r",stdin);
	freopen("bs.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);

	f[k&1][1]=1;
	for(int i=2;i<=k;i++)
		f[k&1][1]=(ll)f[k&1][1]*(ll)i%md;

	for(int i=k,maxp;i<n;i++)
	{
		memset(f[i&1^1],0,sizeof(f[i&1^1][0])*(p+4));
		memset(buc,0,sizeof(buc[0])*(p+4));

		maxp=min(k-1,i+2-k);
		for(int j=0;j<=p;j++)
		{
			chk(buc[j+1]+=f[i&1][j]);
			chk(buc[j+maxp+1]+=md-f[i&1][j]);
		}
		for(int j=1;j<=p;j++)
			chk(buc[j]+=buc[j-1]);
		for(int j=0;j<=p;j++)
			chk(f[i&1^1][j]+=2ll*buc[j]%md);
		if(k+k-2<=i)
			for(int l=0;l+k<=p;l++)
				chk(f[i&1^1][l+k]+=(ll)(i+3ll-2ll*k)*f[i&1][l]%md);
		else
			for(int l=0;l+(i+2-k)<=p;l++)
				chk(f[i&1^1][l+(i+2-k)]+=(ll)(2ll*k-i-3ll)*f[i&1][l]%md);
	}

	printf("%d\n",f[n&1][p]);
	return 0;
}
