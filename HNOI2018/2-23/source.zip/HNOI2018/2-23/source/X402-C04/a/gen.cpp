#include<bits/stdc++.h>
using namespace std;

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("a.in","w",stdout);
	int n=500,q=500;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%20);
	printf("\n%d\n",q);
	for(int i=1;i<=q;i++)
	{
		int l=rand()%n+1,r=rand()%n+1;
		if(l>r)swap(l,r);
		printf("%d %d\n",l,r);
	}

	return 0;
}
