#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=4e5+9;
const int M=5e4+9;

int n,q,t;
int a[N],b[N],c[N],d[N],e[N],f[N];

namespace mo
{
	int blk,sum,num;
	int pre[N],nxt[N],cnt[N],p[N],ans[N];
	struct query
	{
		int l,r,p;
		bool operator < (query b)
		{
			if(l/blk==b.l/blk)
				return r<b.r;
			return l<b.l;
		}
	}qu[N];

	int main()
	{
		blk=sqrt(n);
		for(int i=1;i<=q;i++)
			qu[i].l=read(),qu[i].r=read(),qu[i].p=i;
		sort(qu+1,qu+q+1);
		for(int i=1;i<=n;i++)
		{
			nxt[pre[a[i]]]=i;
			pre[a[i]]=i;
		}
		for(int i=1;i<=n;i++)
			pre[nxt[i]]=i;

		for(int i=n;i>=1;i--)
			if(nxt[i])
			{
				c[i]=nxt[i]-i;
				if(c[i]==c[nxt[i]])
					f[i]=f[nxt[i]];
				else
					f[i]=nxt[i];
			}
			else
				f[i]=i;

		int cl=1,cr=0;
		for(int i=1;i<=q;i++)
		{
			int l=qu[i].l,r=qu[i].r;
			while(cl>l)
			{
				cl--;
				e[a[cl]]=cl;
				if(!cnt[a[cl]])
				{
					sum++,b[a[cl]]=cl;
					num++,p[a[cl]]=1;
				}
				cnt[a[cl]]++;
				if(f[cl]<b[a[cl]] && p[a[cl]])
					p[a[cl]]=0,num--;
			}
			while(cr<r)
			{
				cr++;
				b[a[cr]]=cr;
				if(!cnt[a[cr]])
				{
					sum++,e[a[cr]]=cr;
					num++,p[a[cr]]=1;
				}
				cnt[a[cr]]++;
				if(f[e[a[cr]]]<b[a[cr]] && p[a[cr]])
					p[a[cr]]=0,num--;
			}
			while(cl<l)
			{
				cnt[a[cl]]--;
				if(!cnt[a[cl]])
				{
					e[a[cl]]=b[a[cl]]=0;
					sum--;
					if(p[a[cl]])
						p[a[cl]]=0,num--;
					cl++;continue;
				}
				e[a[cl]]=nxt[cl];
				if(f[nxt[cl]]>=b[a[cl]] && !p[a[cl]])
					p[a[cl]]=1,num++;
				cl++;
			}
			while(cr>r)
			{
				cnt[a[cr]]--;
				if(!cnt[a[cr]])
				{
					e[a[cr]]=b[a[cr]]=0;
					sum--;
					if(p[a[cr]])
						p[a[cr]]=0,num--;
					cr--;continue;
				}
				b[a[cr]]=pre[cr];
				if(f[e[a[cr]]]>=b[a[cr]] && !p[a[cr]])
					p[a[cr]]=1,num++;
				cr--;
			}
			ans[qu[i].p]=sum+1-(!!num);
		}
		for(int i=1;i<=q;i++)
			printf("%d\n",ans[i]);
		return 0;
	}
}

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);

	n=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	q=read();
	if(101<=n)
		return mo::main();
	for(int qq=1,l,r;qq<=q;qq++)
	{
		l=read();r=read();
		int flag=0,cnt=0;

		for(int i=l;i<=r;i++)
		{
			if(b[a[i]]!=qq)
				b[a[i]]=qq,c[a[i]]=0,f[a[i]]=1,cnt++;

			if(f[a[i]]==0)
				continue;

			c[a[i]]++;
			if(c[a[i]]==1)
				d[a[i]]=i,flag++;
			else if(c[a[i]]==2)
			{
				e[a[i]]=i-d[a[i]];
				d[a[i]]=d[a[i]]-e[a[i]];
			}
			else if((i-d[a[i]])%e[a[i]] || (i-d[a[i]])/e[a[i]]!=c[a[i]])
				flag--,f[a[i]]=0;
		}
		if(!flag)cnt++;
		printf("%d\n",cnt);
	}

	return 0;
}
