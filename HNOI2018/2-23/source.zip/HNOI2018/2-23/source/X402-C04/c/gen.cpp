#include<bits/stdc++.h>
using namespace std;

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("c.in","w",stdout);
	int n=10,m=10;
	printf("%d %d\n",n,m);
	for(int i=1;i<=m;i++)
		printf("%d %d %d\n",rand()%2+1,rand()%n+1,rand()%2);

	return 0;
}
