#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=1e5+9;

struct query
{
	int ty,pos,col;
}q[N];

int n,m,a[N],b[N];
int g[1009][1009];

inline void mark(int i,int j,int k)
{
	if(g[i][j]==-1)
		g[i][j]=k;
	else if(g[i][j]==2 || g[i][j]==k)
		return;
	else
		g[i][j]=2;
}

inline int trans(int a,int b)
{
	if(a==b)return b;
	else if(a==2 || b==2 || (a|b)==1)return 2;
	else if(a==-1)return b;
	else if(b==-1)return a;
}

inline int bf()
{
	memset(g,-1,sizeof(g));
	for(int i=1;i<=m;i++)
	{
		if(q[i].ty==1)
			for(int j=1;j<=n;j++)
				mark(q[i].pos,j,q[i].col);
		else if(q[i].ty==2)
			for(int j=1;j<=n;j++)
				mark(j,q[i].pos,q[i].col);
		else for(int j=max(1,q[i].pos-n);j<=n && j<=q[i].pos;j++)
			mark(j,q[i].pos-j,q[i].col);
	}
	int ans[]={0,0,0,0};
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			ans[g[i][j]+1]++;
	printf("%d %d %d %d\n",ans[0],ans[1],ans[2],ans[3]);
	return 0;
}

inline int sp()
{
	memset(a,-1,sizeof(a));
	memset(b,-1,sizeof(b));
	for(int i=1;i<=m;i++)
	{
		if(q[i].ty==1)
			a[q[i].pos]=trans(a[q[i].pos],q[i].col);
		else
			b[q[i].pos]=trans(b[q[i].pos],q[i].col);
	}
	ll ans1[]={0,0,0,0},ans2[]={0,0,0,0};
	for(int i=1;i<=n;i++)
		ans1[a[i]+1]++;
	for(int i=1;i<=n;i++)
		for(int j=-1;j<=2;j++)
			ans2[trans(b[i],j)+1]+=ans1[j+1];
	printf("%lld %lld %lld %lld\n",ans2[0],ans2[1],ans2[2],ans2[3]);
	return 0;
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);

	n=read();m=read();
	bool flag=0;
	for(int i=1;i<=m;i++)
	{
		q[i].ty=read();
		q[i].pos=read();
		q[i].col=read();
		if(q[i].ty>=3)flag=1;
	}

	if(n<=1001 && m<=1001)return bf();
	return sp();

	return 0;
}
