/*
Author: CNYALI_LK
LANG: C++
PROG: a.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
#define x first
#define y second
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
//#define int long long
int a[460817];
vector<pii> ask[460817];
int cxf[460817],ans[460817],dc[460817];
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n,q,l,r,cls=0;
	n=read();
	for(int i=1;i<=n;++i){
		a[i]=read();
		chkmax(cls,a[i]);
	}
	q=read();
	for(int t=1;t<=q;++t){
		l=read();r=read();
		ask[l].push_back(make_pair(r,t));
	}
	for(int i=1;i<=n;++i)if(ask[i].size()){
		sort(all(ask[i]));
		for(int j=1;j<=cls;++j)cxf[j]=dc[j]=0;
		int ncl=0,ok=0;
		vector<pii>::iterator py=ask[i].begin();
		for(int j=i;py!=ask[i].end();++j){
			if(!cxf[a[j]]){
				++ncl;
				++ok;
				cxf[a[j]]=j;
			}
			else {
				if(!dc[a[j]]){
					dc[a[j]]=j-cxf[a[j]];
				}
				else if(dc[a[j]]!=j-cxf[a[j]]){
					if(~dc[a[j]])--ok;		
					dc[a[j]]=-1;
				}
				cxf[a[j]]=j;
			}
			while(j==py->x){
				ans[py->y]=ncl+!ok;
				++py;
			}
		}	
	}
	for(int i=1;i<=q;++i)printf("%d\n",ans[i]);
	return 0;
}

