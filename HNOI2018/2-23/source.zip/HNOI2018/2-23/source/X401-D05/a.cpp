#include<bits/stdc++.h>
using namespace std;
#define N 400050
int n,q;
int a[N],ka[N],app[N],difn;
bool p[N],ok[N];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	scanf("%d",&q);
	for(int cas=1;cas<=q;++cas)
	{
		int l,r;
		bool flag=0;
		scanf("%d%d",&l,&r);
		difn=0;
		for(int i=l;i<=r;++i) app[a[i]]=0,ka[a[i]]=0,p[a[i]]=0,ok[a[i]]=1;
		for(int i=l;i<=r;++i)
		{
			if(!p[a[i]]) difn++,app[a[i]]=i;
			p[a[i]]++;
			if(p[a[i]]==2) ka[a[i]]=i-app[a[i]];
			if(p[a[i]]>2) if(i-app[a[i]]!=(p[a[i]]-1)*ka[a[i]]) ok[a[i]]=0;
		}
		for(int i=l;i<=r;++i) if(ok[a[i]]) {printf("%d\n",difn);flag=1;break;}
		if(!flag)printf("%d\n",difn+1);

	}
	return 0;
}
