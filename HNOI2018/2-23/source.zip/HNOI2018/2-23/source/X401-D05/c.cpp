#include<bits/stdc++.h>
using namespace std;
#define Temp template<typename T>
Temp inline void read(T &x)
{
	x=0;char c=getchar();T f=1;
	while(!isdigit(c)) {if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

#define N 1050
#define M 100010
int n,m;
int g[N][N];//0�ף�1�̣�2�죬3��
void get_c(int x,int y,int col)
{
	if(!g[x][y]) {g[x][y]=col+1;return ;}
	if(g[x][y]==col+1){ return ;}
	if(g[x][y]!=col+1) {g[x][y]=3;return ;}
}
void pian25()
{
	for(int i=1;i<=m;++i) 
	{
		int type,pos,col;
		scanf("%d%d%d",&type,&pos,&col);
		if(type==1) 
			for(int i=1;i<=n;++i) 
				get_c(pos,i,col);
		if(type==2)
			for(int i=1;i<=n;++i) 
				get_c(i,pos,col);
		if(type==3) 
			for(int i=1;i<=pos;++i) 
				if(i>=1 &&i<=n && pos-i>=1 &&pos-i<=n)
					get_c(i,pos-i,col);
	}
	int ans0=0,ans1=0,ans2=0,ans3=0;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j) 
			if(!g[i][j])ans0++;
			else if(g[i][j]==1)ans1++;
			else if(g[i][j]==2) ans2++;
			else ans3++;
	printf("%d %d %d %d\n",ans0,ans1,ans2,ans3);
}

struct ask
{
	int tp,ps,c;
}A[M];
int hang[M],lie[M];
void piantype()
{
	int ans0=0,ans1=0,ans2=0,ans3=0;
	for(int i=1;i<=m;++i) 
		if(!hang[A[i].ps])hang[A[i].ps]=A[i].c+1;
		else if(hang[A[i].ps]==A[i].c+1) continue;
		else if(hang[A[i].ps]!=A[i].c+1) hang[A[i].ps]=3;
	for(int i=1;i<=n;++i)
	{
		if(!hang[i]) ans0+=n;
		else if(hang[i]==1) ans1+=n;
		else if(hang[i]==2) ans2+=n;
		else ans3+=n;
	}
	printf("%d %d %d %d\n",ans0,ans1,ans2,ans3);
}
void piantype2()
{
	int l1=0,l2=0,l3=0;
	int ans0=0,ans1=0,ans2=0,ans3=0;
	for(int i=1;i<=m;++i) 
		if(A[i].tp==2) 
		{
			if(!lie[A[i].ps])lie[A[i].ps]=A[i].c+1;
			else if(lie[A[i].ps]==A[i].c+1) continue;
			else if(lie[A[i].ps]!=A[i].c+1) lie[A[i].ps]=3;
		}
		else if(A[i].tp==1) 	
		{
			if(!hang[A[i].ps]){hang[A[i].ps]=A[i].c+1;}
			else if(hang[A[i].ps]==A[i].c+1) continue;
			else if(hang[A[i].ps]!=A[i].c+1) hang[A[i].ps]=3;
		}
	for(int i=1;i<=n;++i) 
		if(lie[i]==1) l1++,ans1+=n;
		else if(lie[i]==2) l2++,ans2+=n;
		else if(lie[i]==3) l3++,ans3+=n;
	for(int i=1;i<=n;++i) 
		if(hang[i]==1) {ans3+=l2,ans1+=(n-l2-l3-l1),ans2-=l2;}
		else if(hang[i]==2) ans3+=l1,ans2+=(n-l2-l3-l1),ans1-=l1;
		else if(hang[i]==3) ans3+=(n-l3),ans2-=l2,ans1-=l1;
	printf("%d %d %d %d\n",n*n-ans1-ans2-ans3,ans1,ans2,ans3);
}
void pianqita()
{
	bool ft,fc,lfuck=1;
	int ftype=0,fcol=0;
	for(int i=1;i<=m;++i)
	{
		int type,pos,col;
		read(type),read(pos),read(col);
		if(type==3) lfuck=0;
		if(i==1) ftype=type,fcol=col;
		else 
		{
			if(ftype!=type) ft=1;
			if(fcol!=col) fc=1;
		}
		A[i].tp=type,A[i].ps=pos,A[i].c=col;
	}
	if(!ft) piantype();
	else if(lfuck) piantype2();
	
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	read(n),read(m);
	if(n<=1000 && m<=1000)
		pian25();
	else pianqita();
	return 0;
}
