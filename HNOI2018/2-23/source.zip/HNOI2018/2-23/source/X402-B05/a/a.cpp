#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=4e5+100;
int n;
int a[maxn];
int m;
struct node
{
	int l,r;
} q[maxn];
int cnt[110][110];
int ne[maxn],po[maxn],co[110];
void work1()
{
	for (int i=1;i<=n;i++)
		cnt[i][a[i]]++;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=100;j++)
			cnt[i][j]+=cnt[i-1][j];
	memset(po,0x3f3f3f,sizeof(po));
	for (int i=n;i>=1;i--)
	{
		ne[i]=po[a[i]];
		po[a[i]]=i;
	}
	int l,r;
	for (int i=1;i<=m;i++)
	{
		l=q[i].l;
		r=q[i].r;
		memset(co,0,sizeof(co));
		bool flag=false;
		for (int j=l;j<=r;j++)
		{
			if (co[a[j]]!=0) continue;
			co[a[j]]++;
			if (ne[j]>r) {flag=true;continue;}
			if (flag) continue;
			flag=true;
			int k=ne[j]-j;int lst=j;
			for (int l=ne[j];l<=r;l=ne[l])
			{
				if ((l-lst)!=k) {flag=false;break;}
				lst=l;
			}
		}
		int c=0;
		for (int j=1;j<=100;j++) if (co[j]) c++;
		if (flag) printf("%d\n",c); else printf("%d\n",c+1);
	}
}
const int N=10;
int c[maxn][14];
int f[maxn][14];
void work2()
{
	for (int i=1;i<=n;i++) c[i][a[i]]++;
	for (int i=1;i<=n;i++)
	{
		for (int j=1;j<=N;j++)
			c[i][j]+=c[i-1][j];
	}

	memset(po,0x3f3f3f3f,sizeof(po));
	for (int i=n;i>=1;i--)
	{
		ne[i]=po[a[i]];
		po[a[i]]=i;
	}
	int f3[14];
	memset(f3,0,sizeof(f3));
	for (int i=1;i<=n;i++)
	{
		if (i<f3[a[i]]) continue;
		if (ne[i]>n) continue;
		int l=i,r=ne[i],k=r-l,lst=i,t=n+1,lls=f3[a[i]];
		for (int j=ne[i];j<=n;j=ne[j])
		{
			if (j-lst!=k)
			{
				r=lst;
				t=j;
				break;
			}
			lls=lst;
			lst=j;
		}
		l=f3[a[i]];
		for (int j=l;j<=lls;j++)
		{
			f[j][a[i]]=t-1;
		}
		f3[a[i]]=lls+1;
	}
	for (int i=1;i<=N;i++)
	{
		for (int j=f3[i];j<=n;j++) f[j][i]=n;
	}
	for (int i=1;i<=m;i++)
	{
		int sum=0;
		int l=q[i].l,r=q[i].r;
		bool flag=false;
		for (int j=1;j<=N;j++)
		{
			if (c[r][j]-c[l-1][j]>0) 
			{
				sum++;
				if (f[l][j]>=r||c[r][j]-c[l-1][j]==1) 
				{
					flag=true;
				}
			}
		}
		if (flag)
		{
			printf("%d\n",sum);
		} else printf("%d\n",sum+1);
	}
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	n=read();
	bool f2=true;
	for (int i=1;i<=n;i++) 
	{
		a[i]=read();
		if (a[i]>N) f2=false;
	}
	m=read();
	for (int i=1;i<=m;i++)
	{
		q[i].l=read();
		q[i].r=read();
	}

	if (f2)
	{
		work2();
		return 0;
	}
	if (n<=100)
	{
		work1();
		return 0;
	}
	return 0;
}
