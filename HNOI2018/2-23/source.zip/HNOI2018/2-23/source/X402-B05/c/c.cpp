#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e5+10000;
int n,m;
struct node
{
	int type,x,y;
} q[maxn];
int a[1010][1010];
void color(int x,int y,int c)
{
	if (a[x][y]==0) 
	{
		a[x][y]=c;
		return;
	}
	if (c==2)
	{
		if (a[x][y]==1) a[x][y]=3;
		return;
	}
	if (c==1)
	{
		if (a[x][y]==2) a[x][y]=3;
		return;
	}
}
void work1()
{
	memset(a,0,sizeof(a));
	for (int i=1;i<=m;i++)
	{
		if (q[i].y==0) q[i].y=2;
		int c=q[i].y;
		int pos=q[i].x;
		if (q[i].type==1)
		{
			for (int j=1;j<=n;j++) color(pos,j,c);
		} else
		if (q[i].type==2)
		{
			for (int j=1;j<=n;j++) color(j,pos,c);
		} else
		{
			int x,y;
			for (int j=1;j<=n;j++)
			{
				y=j;
				if (j>=pos) break;
				x=pos-y;
				if (x>=1&&x<=n) color(x,y,c);
			}
		}
	}
	int cnt[5]={0};
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
		{
			cnt[a[i][j]]++;
		}
	printf("%d %d %d %d\n",cnt[0],cnt[2],cnt[1],cnt[3]);
}
bool cmp(node aa,node bb)
{
	if (aa.type!=bb.type) return aa.type<bb.type;
	if (aa.x!=bb.x) return aa.x<bb.x;
	return aa.y<bb.y;
}
ll c[maxn],r[maxn];//r：行 c:列
void work2()
{
	sort(q+1,q+m+1,cmp);
	int i;
	for (i=1;i<=m;i++)
	{
		if (q[i].type==2) break;
		int x=q[i].x;
		if (c[x]!=q[i].y&&c[x]<3) c[x]+=q[i].y;
	}
	ll cnt[5]={0};
	for (int i=1;i<=n;i++) cnt[c[i]]++;
	ll sum[5]={0};
	for (int i=0;i<=3;i++) sum[i]=cnt[i]*n;
	ll s=cnt[1]+cnt[2]+cnt[3];
	for (;i<=m;i++)
	{
		int x=q[i].x;
		if (r[x]!=q[i].y&&r[x]<3) r[x]+=q[i].y;
	}
	ll c1[5]={0};
	for (int i=1;i<=n;i++) 
	{
		if (r[i]==3)
		{
			sum[3]+=(n-cnt[3]);
			sum[1]-=cnt[1];
			sum[2]-=cnt[2];
			sum[0]-=cnt[0];
			continue;
		}
		if (r[i]==2)
		{
			sum[3]+=cnt[1];
			sum[2]+=cnt[0];
			sum[1]-=cnt[1];
			sum[0]-=cnt[0];
			continue;
		}
		if (r[i]==1)
		{
			sum[3]+=cnt[2];
			sum[2]-=cnt[2];
			sum[1]+=cnt[0];
			sum[0]-=cnt[0];
		}
	}
	printf("%lld %lld %lld %lld\n",sum[0],sum[2],sum[1],sum[3]);
}
bitset<maxn*2> yyb;
bitset<maxn*2> zsy;
void work3()//r:行 c:列
{
	sort(q+1,q+m+1,cmp);
	int i;
	for (i=1;i<=m;i++)//行
	{
		if (q[i].type==2) break;
		zsy[q[i].x]=1;
		r[q[i].x]=1;
	}
	ll sum[4]={0};
	int l=i;
	ll cnt=0;
	for (int j=1;j<=n;j++)
		sum[2]+=r[j]*n,cnt+=r[j]==1;
	for (int j=1;j<=n;j++) r[j]+=r[j-1];
	for (;i<=m;i++)
	{
		if (q[i].type==3) break;
		c[q[i].x]=1;
	}
	for (int j=1;j<=n;j++)
	{
		sum[2]+=c[j]*(n-cnt);
		c[j]+=c[j-1];
	}
	for (;i<=m;i++) 
	{
		yyb[q[i].x]=1;
		int xx,yy;
		if (q[i].x<=n+1) xx=1,yy=q[i].x-1; else xx=q[i].x-n,yy=n;
		sum[2]+=(yy-xx+1)-(r[yy]-r[xx-1])-(c[yy]-c[xx-1]);
	}
	for (int j=1;j<=n;j++)
	{
		if (c[i])
		{
			sum[2]+=((zsy<<i)&yyb).count();
		}
	}
	printf("%lld %lld 0 0",(ll)(n)*n-sum[2],sum[2]);
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	n=read();m=read();
	bool f1=true;
	bool f2=true;
	for (int i=1;i<=m;i++)
	{
		q[i].type=read();
		q[i].x=read();q[i].y=read();
		if (q[i].y!=0) f2=false;
		if (q[i].y==0) q[i].y=2;
		if (q[i].type==3) f1=false;
	}

	if (n<=1000&&m<=1000)
	{
		work1();
		return 0;
	}

	if (f1)
	{
		work2();
		return 0;
	}

	if (f2)
	{
		work2();
		return 0;
	}
	return 0;
}
