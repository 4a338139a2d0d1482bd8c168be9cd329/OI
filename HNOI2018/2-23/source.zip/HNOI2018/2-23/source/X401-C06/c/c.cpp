#include<bits/stdc++.h>
using namespace std;
int ans[5],p[10001][10001];
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int i,j,k,m,n,a,b,c,l;
	scanf("%d%d",&n,&m);
	ans[0]=n*n;
	for(i=1;i<=m;++i){
		scanf("%d%d%d",&a,&b,&c);c++;
		if(a==1)
			for(j=1;j<=n;++j){
				if(p[b][j]==3)continue;
				if(p[b][j]+c==3)ans[p[b][j]]--,p[b][j]=3,ans[3]++;
				else ans[p[b][j]]--,ans[c]++,p[b][j]=c;
			}
		else if(a==2)
			for(j=1;j<=n;++j){
				if(p[j][b]==3)continue;
				if(p[j][b]+c==3)ans[p[j][b]]--,p[j][b]=3,ans[3]++;
				else ans[p[j][b]]--,ans[c]++,p[j][b]=c;
			}
		else {
			if(b>n)k=b-n,l=n+1;
			else k=1,l=b;
			for(j=k;j<l;++j){
				if(p[j][b-j]==3)continue;
				if(p[j][b-j]+c==3)ans[p[j][b-j]]--,p[j][b-j]=3,ans[3]++;
				else ans[p[j][b-j]]--,ans[c]++,p[j][b-j]=c;
			}
		}
	}
	for(k=0;k<4;++k)printf("%d ",ans[k]);
	return 0;
}

