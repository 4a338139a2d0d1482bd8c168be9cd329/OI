#include<bits/stdc++.h>
using namespace std;

const int maxn=400010;
int n, q;
int a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int ans, Ans[maxn];
int p[maxn], d[maxn], f[maxn], pre[maxn];

int c[maxn];
int lowbit(int x){ return x&(-x); }
void add(int x,int v){ while(x<maxn){ c[x]+=v; x+=lowbit(x); } }
int query(int x){
	int ret=0;
	while(x){ ret+=c[x]; x-=lowbit(x); }
	return ret;
}

int L[maxn], R[maxn];

void solve(){
	ans=0;
	for(int i=1;i<=n;i++){
		if(!p[ a[i] ]){ p[ a[i] ]=1; ans++; f[ a[i] ]=1; add(a[i], 1); }
		if(!d[ a[i] ] && pre[ a[i] ]) d[ a[i] ]=i-pre[ a[i] ];
		if(pre[ a[i] ]){
			if(d[ a[i] ]!=i-pre[ a[i] ] && f[ a[i] ]) f[ a[i] ]=0, add(a[i], -1);
		}
		pre[ a[i] ]=i;
		Ans[i]=ans+(query(n)==0);
	}
	int l, r;
	for(int i=1;i<=q;i++){
		l=L[i], r=R[i];
		printf("%d\n", Ans[r]);
	}
}

int sum[15][maxn], to[15][maxn];
void solve1(){
	for(int i=1;i<=10;i++) for(int j=1;j<=n;j++) sum[i][j]=sum[i][j-1]+(a[j]==i);
	for(int i=1;i<=10;i++){
		int lst=0;
		for(int j=n;j>=1;j--)if(a[j]==i){
			pre[j]=n+1;
			if(lst) d[j]=lst-j, pre[j]=lst; lst=j;
		}
		to[i][n+1]=n+1;
		for(int j=n;j>=1;j--){
			if(a[j]!=i) to[i][j]=to[i][j+1];
			else if(d[j]==d[ pre[j] ]) to[i][j]=to[i][j+1];
			else to[i][j]=pre[ pre[j] ]-1;
		}
	}
	// for(int i=1;i<=3;i++,puts("")){ for(int j=1;j<=n;j++) printf("%d ", to[i][j]); }
	int l, r;
	while(q--){
		read(l), read(r);
		ans=0;
		for(int i=1;i<=10;i++){ if(sum[i][r]-sum[i][l-1]) ans++; }
		int flag=1;
		for(int i=1;i<=10;i++){ if(to[i][l]>=r){ flag=0; break; } }
		printf("%d\n", ans+flag);
	}
}


namespace solve2{
	int cnt = 0;
	struct Node{ int l,r,sum; }p[maxn*300];

	int la[maxn];
	int root[maxn];

	int build(int l,int r){
		int nc = ++cnt;
		p[nc].sum = 0;
		p[nc].l = p[nc].r = 0;
		if (l == r) return nc;
		int m = l + r >> 1;
		p[nc].l = build(l,m);
		p[nc].r = build(m+1,r);
		return nc;
	}

	int update(int pos,int c,int v,int l,int r){
		int nc = ++cnt;
		p[nc] = p[c];
		p[nc].sum += v;
		if (l == r) return nc;
		int m = l+r>>1;
		if (m >= pos){
			p[nc].l = update(pos,p[c].l,v,l,m);
		}
		else {
			p[nc].r = update(pos,p[c].r,v,m+1,r);
		}
		return nc;
	}

	int query(int pos,int c,int l,int r){
		if (l == r) return p[c].sum;
		int m = l + r >> 1;
		if (m >= pos){
			return p[p[c].r ].sum + query(pos,p[c].l,l,m);
		}
		else return query(pos,p[c].r,m+1,r);
	}

	void main(){
		memset(la,-1,sizeof la);
		root[0] = build(1,n);

		for (int i = 1 ; i <= n; ++i){
			int v = a[i];
			if (la[v] == -1){
				root[i] = update(i,root[i-1],1,1,n);
			}
			else{
				int t = update(la[v],root[i-1],-1,1,n);
				root[i] = update(i,t,1,1,n);
			}
			la[v] = i;
		}

		for(int i=1;i<=q;i++){
			int x,y;
			x=L[i], y=R[i];
			printf("%d\n",query(x,root[y],1,n));
		}
	}
}

int main(){
	freopen("a.in","r",stdin),freopen("a.out","w",stdout);

	read(n);
	int Max=0;
	for(int i=1;i<=n;i++) read(a[i]), Max=max(Max, a[i]);
	read(q);
	// solve1(); return 0;
	if(Max<=10 && q>1000){ solve1(); return 0; }
	//solve(); return 0;
	int flag=1;
	for(int i=1;i<=q;i++) read(L[i]), read(R[i]), flag &= L[i]==1;
	// solve2::main(); return 0;
	if(q>1000 && flag){ solve(); return 0; }
	if(q>10000){ solve2::main(); return 0; }
	int l, r;
	for(int i=1;i<=q;i++){
		l=L[i], r=R[i];
		ans=0;
		for(int i=l;i<=r;i++){
			if(!p[ a[i] ]){ p[ a[i] ]++; ans++; f[ a[i] ]=1; }
			if(!d[ a[i] ] && pre[ a[i] ]){ d[ a[i] ]=i-pre[ a[i] ]; }
			// printf("%d ", f[ a[i] ]);
			if(pre[ a[i] ]) f[ a[i] ] &= d[ a[i] ]==i-pre[ a[i] ]; pre[ a[i] ]=i;
		}
		int flag=1;
		for(int i=l;i<=r;i++){
			if(f[ a[i] ]) flag=0;
			p[ a[i] ]=d[ a[i] ]=pre[ a[i] ]=0;
		}
		// printf("ans = %d flag = %d\n", ans, flag);
		printf("%d\n", ans+flag);
	}
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
