#include<bits/stdc++.h>
using namespace std;

const int maxn=400010;
int n, q;
int a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int ans;
int p[maxn], d[maxn], f[maxn], pre[maxn];

int main(){
	freopen("a3.in","r",stdin),freopen("a.out","w",stdout);

	read(n);
	for(int i=1;i<=n;i++) read(a[i]);
	read(q);
	int l, r;
	while(q--){
		read(l), read(r);
		ans=0;
		for(int i=l;i<=r;i++){
			if(!p[ a[i] ]){ p[ a[i] ]++; ans++; f[ a[i] ]=1; }
			if(!d[ a[i] ] && pre[ a[i] ]){ d[ a[i] ]=i-pre[ a[i] ]; }
			// printf("%d ", f[ a[i] ]);
			if(pre[ a[i] ]) f[ a[i] ] &= d[ a[i] ]==i-pre[ a[i] ]; pre[ a[i] ]=i;
		}
		int flag=1;
		for(int i=l;i<=r;i++){
			if(f[ a[i] ]) flag=0;
			p[ a[i] ]=d[ a[i] ]=pre[ a[i] ]=0;
		}
		// printf("ans = %d flag = %d\n", ans, flag);
		printf("%d\n", ans+flag);
	}
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
