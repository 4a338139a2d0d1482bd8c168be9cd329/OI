#include<bits/stdc++.h>
using namespace std;

const int maxn=400010;
int n, q;
int a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int ans, Ans[maxn];
int p[maxn], d[maxn], f[maxn], pre[maxn];

int c[maxn];
int lowbit(int x){ return x&(-x); }
void add(int x,int v){ while(x<maxn){ c[x]+=v; x+=lowbit(x); } }
int query(int x){
	int ret=0;
	while(x){ ret+=c[x]; x-=lowbit(x); }
	return ret;
}

void solve(){
	ans=0;
	for(int i=1;i<=n;i++){
		if(!p[ a[i] ]){ p[ a[i] ]=1; ans++; f[ a[i] ]=1; add(a[i], 1); }
		if(!d[ a[i] ] && pre[ a[i] ]) d[ a[i] ]=i-pre[ a[i] ];
		if(pre[ a[i] ]){
			if(d[ a[i] ]!=i-pre[ a[i] ] && f[ a[i] ]) f[ a[i] ]=0, add(a[i], -1);
		}
		pre[ a[i] ]=i;
		Ans[i]=ans+(query(n)==0);
	}
	int l, r;
	while(q--){
		read(l), read(r);
		printf("%d\n", Ans[r]);
	}
}

int main(){
	freopen("a.in","r",stdin),freopen("a.out","w",stdout);

	read(n);
	int Max=0;
	for(int i=1;i<=n;i++) read(a[i]), Max=max(Max, a[i]);
	read(q);
	//solve(); return 0;
	if(q>1000){ solve(); return 0; }
	int l, r;
	while(q--){
		read(l), read(r);
		ans=0;
		for(int i=l;i<=r;i++){
			if(!p[ a[i] ]){ p[ a[i] ]++; ans++; f[ a[i] ]=1; }
			if(!d[ a[i] ] && pre[ a[i] ]){ d[ a[i] ]=i-pre[ a[i] ]; }
			// printf("%d ", f[ a[i] ]);
			if(pre[ a[i] ]) f[ a[i] ] &= d[ a[i] ]==i-pre[ a[i] ]; pre[ a[i] ]=i;
		}
		int flag=1;
		for(int i=l;i<=r;i++){
			if(f[ a[i] ]) flag=0;
			p[ a[i] ]=d[ a[i] ]=pre[ a[i] ]=0;
		}
		// printf("ans = %d flag = %d\n", ans, flag);
		printf("%d\n", ans+flag);
	}
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
