#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int maxm=1010;
int n, m;

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int a[maxm][maxm];
ll ans[10], p1[maxn], p2[maxn];
int a1[maxn], a2[maxn];

void solve(){
	int type, pos, c, flag=0;
	while(m--){
		read(type), read(pos), read(c); c++;
		if(type==1) a1[pos]|=c;
		else if(type==2) a2[pos]|=c;
	}
	for(int i=1;i<=n;i++) p1[ a1[i] ]++, p2[ a2[i] ]++;
	for(int i=0;i<4;i++) for(int j=0;j<4;j++) ans[i|j]+=1ll*p1[i]*p2[j];
	for(int i=0;i<4;i++) printf("%lld ", ans[i]); puts("");
}

int main(){
	freopen("c.in","r",stdin),freopen("c.out","w",stdout);

	read(n), read(m);
	ans[0]=1ll*n*n;
	int type, pos, c, flag=0;
	if(m>1000){ solve(); return 0; }
	while(m--){
		read(type), read(pos), read(c); c++;
		if(type==1){
			if(flag){ ans[ a[pos][1] ]-=n; a[pos][1]|=c; ans[ a[pos][1] ]+=n; continue; }
			for(int i=1;i<=n;i++){
				ans[ a[pos][i] ]--; a[pos][i]|=c; ans[ a[pos][i] ]++;
			}
		}else if(type==2){
			for(int i=1;i<=n;i++){
				ans[ a[i][pos] ]--; a[i][pos]|=c; ans[ a[i][pos] ]++;
			}
		}else{
			for(int i=max(pos-n, 1);i<=min(pos-1,n);i++){
				ans[ a[i][pos-i] ]--; a[i][pos-i]|=c; ans[ a[i][pos-i] ]++;
			}
		}
		// for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=n;j++) printf("%d ", a[i][j]); puts("");
	}
	for(int i=0;i<4;i++) printf("%lld ", ans[i]); puts("");
	return 0;
}
