#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=110;
const int mod=1e9+7;
int n,k,p;
int b[maxn], P[maxn], ans;
ll fac[maxn], Pow[maxn];
map<vector<int>,int> mp;
vector<int> a;
ll f[maxn][maxn][maxn*maxn/2];

void solve(){
	for(int i=1;i<=n;i++) for(int j=2;j<=i;j++){
		f[i][j][i+1-j]=fac[j]*Pow[i-j]%mod;
		// printf("%d %d %d %lld\n", i, j, i+1-j, f[i][j][i+1-j]);
		for(int k=i+1-j+1;k<=i*(i-1)>>1;k++) f[i][j][k]=f[i-1][j][k-1]*2%mod;
	}
	printf("%lld\n", f[n][k][p]);
}

int main(){
	freopen("b.in","r",stdin),freopen("b.out","w",stdout);

	scanf("%d%d%d", &n, &k, &p);
	fac[0]=1; Pow[0]=1;
	for(int i=1;i<=n;i++) fac[i]=fac[i-1]*i%mod;
	for(int i=1;i<=n;i++) Pow[i]=Pow[i-1]*2%mod;
	if(k==1){
		if(p==n) printf("%lld\n", fac[n]);
		else puts("0");
		return 0;
	}
	if(p>n*(n+1)>>1){ puts("0"); return 0; }
	if(p+k==n+1){
		if(k==1 || k==n) printf("%lld\n", fac[n]);
		else{ printf("%lld\n", fac[k]*Pow[n-k]%mod); }
		return 0;
	}
	if(n>8){ solve(); return 0; }
	for(int i=1;i<=n;i++) P[i]=i;
	int t=fac[n];
	while(t--){
		int tot=0;
		mp.clear();
		for(int i=1;i<=n;i++) for(int j=i+k-1;j<=n;j++){
			int len=j-i+1;
			a.clear();
			for(int l=1;l<=len;l++) b[l]=P[i+l-1];
			sort(b+1, b+1+len);
			for(int l=1;l<=k;l++) a.push_back(b[l]);
			if(!mp.count(a)) tot++; mp[a]=1;
		}
		if(tot==p){
			ans++;
			for(int i=1;i<=n;i++) printf("%d ", P[i]); puts("");
		}
		next_permutation(P+1,P+1+n);
	}
	printf("%d\n", ans);
	return 0;
}
