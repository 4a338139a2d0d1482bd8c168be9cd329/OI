#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<set>
#include<vector>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
void File(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}
template<typename T>T checkmax(T _,T __){return _>__ ? _ : __;}
template<typename T>T checkmin(T _,T __){return _<__ ? _ : __;}
template<typename T>
void read(T &x){
	T _=0,chen=1;char __=getchar();
	while(!isdigit(__))chen*= __=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	x=_*chen;
}
template<typename T>
void write(T x){
	if(x<0)putchar('-'),x=-x;
	if(x==0){putchar('0');putchar('\n');return;}
	T _=1,__=0;
	while(_<=x)_=(_<<1)+(_<<3),++__;
	while(__--){
		_/=10;
		putchar(x/_+48);
		x%=_;
	}
	putchar('\n');
}
const int maxn=4e5+10;
int n,q,a[maxn],l[maxn],r[maxn],num,a_max;
vector<int>v[maxn];
struct node{
	int L,R,len;
	bool operator < (const node & t) const{
		if(L!=t.L)return L<t.L;
		else return R<t.R;
	}
}b[maxn];
bool pd(int L,int R){
	REP(i,1,num){
		vector<int>::iterator it1=lower_bound(v[i].begin(),v[i].end(),L);
		vector<int>::iterator it2=upper_bound(v[i].begin(),v[i].end(),R)-1;
		if(it1==v[i].end() || *it1>R || *it1<L)continue;
		if(it1==it2 || it1+1==it2)return true;
		int d=*(it1+1)-*it1;
		bool flag=1;
		it1++;
		while(it1!=it2){
			if(*(it1+1)-*it1!=d){
				flag=0;
				break;
			}
			it1++;
		}
		if(flag)return true;
	}
	return false;
}
int vis[maxn],dd[maxn],o[maxn],ans[maxn];
bool can[maxn];
int main(){
	File();
	bool sub=1;
	read(n);
	REP(i,1,n){
		read(a[i]);
		v[a[i]].push_back((int)i);
		a_max=checkmax(a_max,a[i]);
	}
	read(q);
	REP(i,1,q){
		read(l[i]),read(r[i]);
		if(l[i]!=1)sub=0;
	}
	if(sub){
		memset(can,0,sizeof(can));
		int yes=0;
		set<int>s;
		REP(i,1,q)b[i].L=l[i],b[i].R=r[i],b[i].len=i;
		sort(b+1,b+q+1);
		int f=1;
		REP(i,1,q){
			while(f<=b[i].R){
				s.insert(a[f]);
				++vis[a[f]];
				if(vis[a[f]]==1)++yes,o[a[f]]=f;
				else if(vis[a[f]]==2){
					dd[a[f]]=f-o[a[f]];
					o[a[f]]=f;
				}
				else if(vis[a[f]]>2 && can[a[f]]){
					if(f-o[a[f]]!=dd[a[f]])
						yes--,can[a[f]]=0;
					else o[a[f]]=f;
				}
				++f;
			}
			int c=s.size();
			ans[b[i].len]=(yes>0 ? 0 : 1)+c;
		}
		REP(i,1,q)write(ans[i]);
		return 0;
	}
	if(n<=1000 && q<=1000){
		REP(i,1,a_max){
			int len=v[i].size()-1;
			if(len==-1)continue;
			if(len==0){
				++num;
				b[num].L=b[num].R=v[i][0];
				b[num].len=1;
			}
			else if(len==1){
				++num;
				b[num].L=v[i][0];
				b[num].R=v[i][1];
				b[num].len=2;
			}
			else{
				int d=v[i][1]-v[i][0],p=0,f=0;
				while(p<=len){
					++num;
					b[num].L=v[i][p];
					while(p+1<=len && v[i][p+1]-v[i][p]==d)++p;
					b[num].R=v[i][p];
					b[num].len=p-f+1;
					if(p==len)break;
					else if(p+1==len){
						++num;
						b[num].L=v[i][p];
						b[num].R=v[i][p+1];
						b[num].len=2;
						break;
					}
					else f=p,d=v[i][p+1]-v[i][p];
				}
			}
		}
		REP(i,1,q){
			bool c[maxn]={0};
			int cnt=0;
			REP(j,l[i],r[i])
				if(!c[a[j]])++cnt,c[a[j]]=1;
			write(cnt+1-pd(l[i],r[i]));
		}
	}
	else REP(i,1,q)write(a_max);
	return 0;
}
