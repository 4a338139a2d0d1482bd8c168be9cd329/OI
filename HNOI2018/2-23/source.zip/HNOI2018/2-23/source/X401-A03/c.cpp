#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<set>
#define ll long long
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
void File(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}
template<typename T>T checkmax(T _,T __){return _>__ ? _ : __;}
template<typename T>T checkmin(T _,T __){return _<__ ? _ : __;}
template<typename T>
void read(T &x){
	T _=0,chen=1;char __=getchar();
	while(!isdigit(__))chen*= __=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	x=_*chen;
}
template<typename T>
void write(T x){
	if(x<0)putchar('-'),x=-x;
	if(x==0){putchar('0');putchar(' ');return;}
	T _=1,__=0;
	while(_<=x)_=(_<<1)+(_<<3),++__;
	while(__--){
		_/=10;
		putchar(x/_+48);
		x%=_;
	}
	putchar(' ');
}
const int maxn=1000+10;
int n,m,c[maxn][maxn],cc[maxn*100];
void paint(int x,int y,int co){
	++co;
	if(c[x][y]==0)c[x][y]=co;
	else if(c[x][y]==1)c[x][y]= co==1 ? 1 : 3;
	else if(c[x][y]==2)c[x][y]= co==1 ? 3 : 2;
	else if(c[x][y]==3)c[x][y]=3;
}
void paint1(int x,int co){
	++co;
	if(cc[x]==0)cc[x]=co;
	else if(cc[x]==1)cc[x]= co==1 ? 1 : 3;
	else if(cc[x]==2)cc[x]= co==1 ? 3 : 2;
	else if(cc[x]==3)cc[x]=3;
}
set<int>b[4];
int main(){
	File();
	bool sub1=1,sub2=1,sub3=1;
	read(n);read(m);
	REP(i,1,m){
		int type,pos,color;
		read(type);read(pos);read(color);
		if(sub1){
			if(type==1)REP(j,1,n)paint(pos,j,color);
			else if(type==2)REP(j,1,n)paint(j,pos,color);
			else REP(j,1,pos-1){
				if(j>=1 && j<=n && pos-j>=1 && pos-j<=n)paint(j,pos-j,color);
			}
		}
		if(type!=1)sub2=0;
		if(sub2)paint1(pos,color);
		if(color!=0)sub3=0;
		if(sub3)b[type].insert(pos);
	}
	if(sub1){
		int ans1=0,ans2=0,ans3=0,ans4=0;
		REP(i,1,n)REP(j,1,n){
			if(c[i][j]==0)ans1++;
			else if(c[i][j]==1)ans2++;
			else if(c[i][j]==2)ans3++;
			else ans4++;
		}
		write(ans1);write(ans2);write(ans3);write(ans4);
		return 0;
	}
	if(sub2){
		ll ans1=0ll,ans2=0ll,ans3=0ll,ans4=0ll;
		REP(i,1,n){
			if(cc[i]==0)ans1+=n;
			else if(cc[i]==1)ans2+=n;
			else if(cc[i]==2)ans3+=n;
			else ans4+=n;
		}
		write(ans1);write(ans2);write(ans3);write(ans4);
		return 0;
	}
	return 0;
}

