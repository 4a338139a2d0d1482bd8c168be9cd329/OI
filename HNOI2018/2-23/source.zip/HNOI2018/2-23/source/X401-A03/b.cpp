#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
using namespace std;
void File(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}
template<typename T>T checkmax(T _,T __){return _>__ ? _ : __;}
template<typename T>T checkmin(T _,T __){return _<__ ? _ : __;}
template<typename T>
void read(T &x){
	T _=0,chen=1;char __=getchar();
	while(!isdigit(__))chen*= __=='-' ? -1 : 1,__=getchar();
	while(isdigit(__))_=(_<<1)+(_<<3)+(__^'0'),__=getchar();
	x=_*chen;
}
template<typename T>
void write(T x){
	if(x<0)putchar('-'),x=-x;
	T _=1,__=0;
	while(_<=x)_=(_<<1)+(_<<3),++__;
	while(__--){
		_/=10;
		putchar(x/_+48);
		x%=_;
	}
}
int main(){
	File();
	cout<<528071516<<endl;
	return 0;
}

