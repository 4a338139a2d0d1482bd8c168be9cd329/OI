//2018-02-22
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register int i=a;i<=b;i++)
#define Forr(i,a,b) for(register int i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}
inline void read(int &x)
{
	int p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}
#define N 10010
int n,q;
vector<int> vec[N];
int a[N],qwq[N],OmO[N],OwO[N][2];
int main()
{
	File();
	read(n);
	For(i,1,n)read(a[i]);
	read(q);
	while(q--)
	{
		memset(qwq,0,sizeof(qwq));
		int l,r,cnt=0,EoE=0;
		read(l),read(r);
		For(i,l,r)
		{
			if(!qwq[a[i]])cnt++,qwq[a[i]]=1,OmO[cnt]=a[i];
			else qwq[a[i]]++;
		}
		stack<int> s[N];
		int flag=0;
		For(i,l,r)if(qwq[a[i]]>1)s[a[i]].push(i);
		For(i,1,cnt)
		{
			if(!s[OmO[i]].empty())
			{
			int op=s[OmO[i]].top();
			s[OmO[i]].pop();
			int oq=s[OmO[i]].top();
			int cz=op-oq;
			s[OmO[i]].pop();
			while(!s[OmO[i]].empty())
			{
				if(s[OmO[i]].top()-oq!=cz)break;
				s[OmO[i]].pop();		
			}
			if(s[OmO[i]].empty())flag=1;
		}
		}
		printf("%d\n",flag+cnt);
	}
	return 0;
}


