//2018-02-23
//LZYeah
//
#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(register ll i=a;i<=b;i++)
#define Forr(i,a,b) for(register ll i=a;i>=b;i--)
using namespace std;
inline void File()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}
inline void read(ll &x)
{
	ll p=1;
	x=0;
	char c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^'0');c=getchar();}
	x*=p;
}
#define N 100010
ll n,m;
ll a[1010][1010];
ll c[N],line[N],row[N];
ll c1,c2,c3,c4;
struct node
{
	ll t,p,c;
	bool operator<(const node &rhs)const{
		return t==rhs.t?p<rhs.p:t<rhs.t;
	}
}op[N];
inline void paint1(ll x,ll y,ll c)
{
	ll k=x;
	while(k<=n)
	{		
		if(a[k][y]==3){k++;continue;}
		if(c==0)
		{
			if(a[k][y]==0)a[k][y]=1,c1--,c2++;
			if(a[k][y]==2)a[k][y]=3,c3--,c4++;
		}
		else
		{
			if(a[k][y]==0)a[k][y]=2,c1--,c3++;
			if(a[k][y]==1)a[k][y]=3,c2--,c4++;
		}
		k++;
	}
}
inline void paint2(ll x,ll y,ll c)
{
	ll k=y;
	while(k<=n)
	{		
		if(a[x][k]==3){k++;continue;}
		if(c==0)
		{
			if(a[x][k]==0)a[x][k]=1,c1--,c2++;
			if(a[x][k]==2)a[x][k]=3,c3--,c4++;
		}
		else
		{
			if(a[x][k]==0)a[x][k]=2,c1--,c3++;
			if(a[x][k]==1)a[x][k]=3,c2--,c4++;
		}
		k++;
	}
}
inline void paint3(ll x,ll y,ll c)
{
	ll k=x,b=y;
	while(k<=n&&b)
	{		
		if(a[k][b]==3){k++,b--;continue;}
		if(c==0)
		{
			if(a[k][b]==0)a[k][b]=1,c1--,c2++;
			if(a[k][b]==2)a[k][b]=3,c3--,c4++;
		}
		else
		{
			if(a[k][b]==0)a[k][b]=2,c1--,c3++;
			if(a[k][b]==1)a[k][b]=3,c2--,c4++;
		}
		k++,b--;
	}
}
int main()
{
	File();
	read(n),read(m);
	if(n<=1e3&&m<=1e3)
	{
		c1=n*n;
		For(i,1,m)
		{
			ll t,p,c;
			read(t),read(p),read(c);
			if(t==1)
			{
				ll x=1,y=p;
				paint1(x,y,c);
			}
			if(t==2)
			{
				ll x=p,y=1;
				paint2(x,y,c);
			}
			if(t==3)
			{
				ll x,y;
				x=p<=n+1?1:p-n;
				y=p-x;
				paint3(x,y,c);
			}
		}
		printf("%lld %lld %lld %lld\n",c1,c2,c3,c4);
		return 0;
	}
	else
	{
		ll flag1=0,flag2=0,flag3=0;
		For(i,1,m)
		{
			read(op[i].t),read(op[i].p),read(op[i].c);
			if(op[i].t==2)flag1=1;
			if(op[i].t==3)flag2=1;
			if(op[i].c==1)flag3=1;
			if(op[i].t==1)
			{
				if(op[i].c==0)
				{
					if(line[op[i].p]==2) line[op[i].p]=3;
					else if(line[op[i].p]!=3) line[op[i].p]=1;
				}
				else 
				{
					if(line[op[i].p]==1) line[op[i].p]=3;
					else if(line[op[i].p]!=3) line[op[i].p]=2;
				}
			}
			else if(op[i].t==2)
			{
				if(op[i].c==0)
				{
					if(row[op[i].p]==2) row[op[i].p]=3;
					else if(row[op[i].p]!=3) row[op[i].p]=1;
				}
				else 
				{
					if(row[op[i].p]==1) row[op[i].p]=3;
					else if(row[op[i].p]!=3) row[op[i].p]=2;
				}
			}
		}
		if(!flag1)
		{
			c1=n;
			For(i,1,m)
			{
				if(c[op[i].p]==3)continue;
				if(op[i].c==0)
				{
					if(c[op[i].p]==0)c[op[i].p]=1,c1--,c2++;
					if(c[op[i].p]==2)c[op[i].p]=3,c3--,c4++;
				}
				else
				{
					if(c[op[i].p]==0)c[op[i].p]=2,c1--,c3++;
					if(c[op[i].p]==1)c[op[i].p]=3,c2--,c4++;
				}
			}
			printf("%lld %lld %lld %lld\n",c1*n,c2*n,c3*n,c4*n);
		}
		if(!flag2)
		{
			ll ans1=0,ans2=0,ans3=0,ans4=0,ans5=0,ans6=0,ans7=0,ans8=0;
			for(register ll i=1;i<=n;i++){
				if(line[i]==0) ans7++;
				else if(line[i]==1) ans1++;
				else if(line[i]==2) ans3++;
				else ans5++;

				if(row[i]==0) ans8++;
				else if(row[i]==1) ans2++;
				else if(row[i]==2) ans4++;
				else ans6++;
			}
			
			c1=ans7*n+ans8*n-ans7*ans8-ans1*ans8-ans3*ans8-ans5*ans8-ans2*ans7-ans4*ans7-ans6*ans7;
			c2=ans1*n+ans2*n-ans1*ans2-ans3*ans2-ans5*ans2-ans4*ans1-ans6*ans1;
			c3=ans3*n+ans4*n-ans3*ans4-ans1*ans4-ans5*ans4-ans2*ans3-ans6*ans3;
			c4=ans5*n+ans6*n+ans1*ans4+ans2*ans3;
			printf("%lld %lld %lld %lld\n",c1,c2,c3,c4);		
		}
		if(!flag3)
		{
		
		}
	}
	return 0;
}


