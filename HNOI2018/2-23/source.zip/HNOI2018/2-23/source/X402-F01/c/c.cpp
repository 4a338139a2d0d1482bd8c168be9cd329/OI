#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int he[100005],sh[100005],cnt[200005];
int n,m;
struct node{
   int opt,pos,col;
}query[100005];
void bf(){
   static int col[1005][1005];
   Set(col,-1);
   F(i,1,m){
      if(query[i].opt==1){
	      F(j,1,n){
	      if(col[query[i].pos][j]==-1||col[query[i].pos][j]==query[i].col)col[query[i].pos][j]=query[i].col;
		  else col[query[i].pos][j]=2;
		  }
	  }
	  if(query[i].opt==2){
	     F(j,1,n){
		 if(col[j][query[i].pos]==-1||col[j][query[i].pos]==query[i].col)col[j][query[i].pos]=query[i].col;
		 else col[j][query[i].pos]=2;
		 }
	  }
      if(query[i].opt==3){
	      F(j,1,n){
			  if(query[i].pos-j>n||query[i].pos-j<=0)continue;
		   if(col[j][query[i].pos-j]==-1||col[j][query[i].pos-j]==query[i].col)col[j][query[i].pos-j]=query[i].col;
		   else col[j][query[i].pos-j]=2;
		  }
	  }
   }
   int f=0,s=0,t=0,fo=0;
   F(i,1,n){
     F(j,1,n){
	    if(col[i][j]==-1)f++;
		if(col[i][j]==0)s++;
		if(col[i][j]==1)t++;
		if(col[i][j]==2)fo++;
	 }
   }
   printf("%d %d %d %d\n",f,s,t,fo);
}
void sub1(){
  Set(he,-1);
  F(i,1,m){
     if(he[query[i].pos]==-1||he[query[i].pos]==query[i].col)he[query[i].pos]=query[i].col;
	 else he[query[i].pos]=2;
  }
  long long f=0,s=0,t=0,fo=0;
  F(i,1,n){
     if(he[i]==-1)f+=n;
	 if(he[i]==0)s+=n;
	 if(he[i]==1)t+=n;
	 if(he[i]==2)fo+=n;
  }
  printf("%lld %lld %lld %lld\n",f,s,t,fo);
}
void sub2(){
    Set(he,-1);
	Set(sh,-1);
	F(i,1,m){
	    if(query[i].opt==1){
	      if(he[query[i].pos]==-1||he[query[i].pos]==query[i].col)he[query[i].pos]=query[i].col;
		  else he[query[i].pos]=2;
		  
	  }
	  if(query[i].opt==2){
		 if(sh[query[i].pos]==-1||sh[query[i].pos]==query[i].col)sh[query[i].pos]=query[i].col;
		 else sh[query[i].pos]=2;
	  }
	}
	int st[10]={0},ed[10]={0};
	F(i,1,n){
	   st[he[i]+1]++;
	   ed[sh[i]+1]++;
	}
	long long f,s,t,fo;
	f=1ll*st[0]*(n-ed[1]-ed[2]-ed[3])+1ll*ed[0]*(n-st[1]-st[2]-st[3])-1ll*st[0]*ed[0];
	s=1ll*st[1]*(n-ed[2]-ed[3])+1ll*ed[1]*(n-st[2]-st[3])-1ll*st[1]*ed[1];
	t=1ll*st[2]*(n-ed[1]-ed[3])+1ll*ed[2]*(n-st[1]-st[3])-1ll*st[2]*ed[2];
	fo=1ll*n*n-f-s-t;
	printf("%lld %lld %lld %lld\n",f,s,t,fo);
}
void sub3(){
	 F(i,1,m){
	   if(query[i].opt==1){
	       he[query[i].pos]=1;
	   }   
	   if(query[i].opt==2){
	       sh[query[i].pos]=1;
	   }
	   else cnt[query[i].pos]=1;
	 }
     
}
int main () {
    freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	n=read();
	m=read();
	bool flag1=1,flag2=1,flag3=1;
	F(i,1,m){
	    query[i].opt=read();
		query[i].pos=read();
		query[i].col=read();
		if(query[i].opt!=1)flag1=0;
		if(query[i].opt!=1&&query[i].opt!=2)flag2=0;
		if(query[i].col!=0)flag3=0;
	}
	if(n<=1000)bf();
	else if(flag1)sub1();
	else if(flag2)sub2();
	else if(flag3)sub3();
    return 0;
}
