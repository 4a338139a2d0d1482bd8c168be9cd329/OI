#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n,m,p;
const int mod=1e9+7;
int fst[1005];
int b[1005];
int vis[1<<21];
int a[1005];
int tot;
int check(int x){
	F(i,0,tot)vis[i]=0;
	int cnt=0,res=0;
	F(i,1,n)
		F(j,i+m-1,n){
			cnt=0;
			F(k,i,j)
				b[++cnt]=a[k];
			sort(b+1,b+1+cnt);
			int s=0,ts;
			F(i,1,m)
				s|=(1<<(b[i]-1));
			if(!vis[s])vis[s]=1,++res;
		}
	return res==x;
}
void sol(){
	 tot=(1<<n)-1;
  int ans=0;
   F(i,1,n)a[i]=i;
   F(i,1,fst[n]){
      if(check(p))ans++;
      next_permutation(a+1,a+1+n);
   }
   printf("%d\n",ans);
}
int main () {
freopen("b.in","r",stdin);
freopen("b.out","w",stdout);
    n=read();
	m=read();
	p=read();
	fst[1]=1;
    F(i,2,n){
	   fst[i]=fst[i-1]*i%mod;
	}
    if(m==1&&p==n){
	   printf("%d\n",fst[n]);
	   return 0;
	}
	if(m==n&&p==1){
	    printf("%d\n",fst[n]);
		return 0;
	}
	if(p>n*(n+1)/2){
	    printf("%d\n",0);
		return 0;
	}
	else if(n<=8){
	   sol();
	}
	else printf("%d\n",fst[n]);
    return 0;
}
