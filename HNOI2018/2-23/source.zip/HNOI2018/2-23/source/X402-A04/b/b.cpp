#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<set>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=1e9+7;
const int N=1050;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int n,k,p;
int a[N],fac[N];
int f[405][405*405],b[405],s[405];

void wj()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}
int main()
{
	wj();
	n=read(); k=read(); p=read();
	fac[0]=1;
	for(int i=1;i<=n;++i) fac[i]=1ll*fac[i-1]*i%mod;
	if(k==1&&p==n) {printf("%d\n",fac[n]);return 0;}
	if(k==n&&p==1) {printf("%d\n",fac[n]);return 0;}
	if(p==n-k+1) {printf("%lld\n",1ll*fac[k]*qpow(2,p-1)%mod);return 0;}
	if(p>n*(n+1)/2) {printf("0\n");return 0;}
	if(p+k<=n) {printf("0\n");return 0;}

	f[k][1]=fac[k];
	for(int i=k;i<n;++i) 
	{
		for(int j=1;j<=k;++j) s[j]=0;
		for(int j=1;j<=i+1;++j) b[j]=min(j,i-k+2)-max(j-k+1,1)+1,s[b[j]]++;
		//cerr<<endl;,cerr<<b[j]<<' '
		for(int j=1,maxn=(i-k)*k+1;j<=maxn;++j) if(f[i][j])
		{
			for(int l=1;l<=k&&j+l<=p;++l)
				f[i+1][j+l]=(f[i+1][j+l]+1ll*f[i][j]*s[l])%mod;
		}
	}
	printf("%d\n",f[n][p]);
	return 0;
}
