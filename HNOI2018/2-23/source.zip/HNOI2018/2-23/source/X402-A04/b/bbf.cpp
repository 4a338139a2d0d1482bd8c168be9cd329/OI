#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<set>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=1e9+7;
const int N=1050;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int n,k,p;
int a[N],fac[N];

void wj()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}
int main()
{
	wj();
	n=read(); k=read(); p=read();
	fac[0]=1;
	for(int i=1;i<=n;++i) fac[i]=1ll*fac[i-1]*i%mod;
	if(k==1&&p==n) {printf("%d\n",fac[n]);return 0;}
	if(k==n&&p==1) {printf("%d\n",fac[n]);return 0;}
	if(p==n-k+1) {printf("%lld\n",1ll*fac[k]*qpow(2,p-1)%mod);return 0;}
	if(p>n*(n+1)/2) {printf("0\n");return 0;}
	if(p+k<=n) {printf("0\n");return 0;}

	for(int i=1;i<=n;++i) a[i]=i;
	int ans=0;
	do
	{
		int val=0;
		for(int i=1;i<=n-k+1;++i)
		{
			int s=0;
			for(int j=i;j<i+k-1;++j) s|=1<<a[j];
			for(int j=i+k-1;j<=n;++j)
			{
				s|=1<<a[j];
				while(__builtin_popcount(s)>k) s^=1<<(31-__builtin_clz(s));
				if((s&1<<a[i])&&(s&1<<a[j])) val++;
			}
		}
		if(val==p) ans++;
	}while(next_permutation(a+1,a+1+n));
	printf("%d\n",ans);
	return 0;
}
