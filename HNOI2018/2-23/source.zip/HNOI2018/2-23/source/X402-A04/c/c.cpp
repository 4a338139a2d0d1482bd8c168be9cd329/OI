#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=998244353;
const int N=100050;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int rev[N<<2];
void NTT(int *a,int n,int dft)
{
	for(int i=0;i<n;++i) if(i<rev[i]) swap(a[i],a[rev[i]]);
	for(int step=1;step<n;step<<=1)
	{
		int wn=qpow(3,(mod-1)/(step*2));
		if(dft==-1) wn=qpow(wn,mod-2);
		for(int j=0;j<n;j+=(step<<1))
		{
			int wnk=1;
			for(int k=j;k<j+step;++k)
			{
				int x=a[k],y=1ll*a[k+step]*wnk%mod;
				a[k]=(x+y)%mod; a[k+step]=(x-y+mod)%mod;
				wnk=1ll*wnk*wn%mod;
			}
		}
	}
	if(dft==-1)
	{
		int inv=qpow(n,mod-2);
		for(int i=0;i<n;++i) a[i]=1ll*a[i]*inv%mod;
	}
}

int n,m;
int row[N<<2],colu[N<<2],ang[N<<1];
ll num[5],sum[5];
int ls[1050][1050];

namespace colall0
{
	int srow[N],scolu[N];
	void solve()
	{
		for(int i=1;i<=n;++i) srow[i]=srow[i-1]+row[i];
		for(int i=1;i<=n;++i) scolu[i]=scolu[i-1]+colu[i];

		int bit=1,s=2;
		for(;(1<<bit)-1<n+n;bit++) s<<=1;
		for(int i=0;i<s;++i) rev[i]=(rev[i>>1]>>1)|((i&1)<<bit-1);
		NTT(row,s,1); NTT(colu,s,1);
		for(int i=0;i<s;++i) row[i]=1ll*row[i]*colu[i]%mod;
		NTT(row,s,-1);

		for(int i=2;i<=(n<<1);++i) if(ang[i])
		{
			int y=min(i-1,n),x=i-y;
			sum[1]+=y-x+1-(srow[y]-srow[x-1])-(scolu[y]-scolu[x-1])+row[i];
		}
		sum[0]=1ll*n*n-sum[1];
		for(int i=0;i<4;++i) printf("%lld ",sum[i]);
	}
}

namespace all
{
	int srow[4][N],scolu[4][N];
	int row1[4][N<<2],colu1[4][N<<2],xie[4][N<<2];
	void solve()
	{
		for(int j=0;j<4;++j)
		{
			for(int i=1;i<=n;++i) 
			{
				srow[j][i]=srow[j][i-1]+(row[i]==j);
				row1[j][i]=row[i]==j;
			}
			for(int i=1;i<=n;++i) 
			{
				scolu[j][i]=scolu[j][i-1]+(colu[i]==j);
				colu1[j][i]=colu[i]==j;
			}
		}

		int bit=1,s=2;
		for(;(1<<bit)-1<n+n;bit++) s<<=1;
		for(int i=0;i<s;++i) rev[i]=(rev[i>>1]>>1)|((i&1)<<bit-1);

		for(int i=0;i<4;++i) NTT(row1[i],s,1);
		for(int i=0;i<4;++i) NTT(colu1[i],s,1);
		for(int i=0;i<4;++i) for(int j=0;j<4;++j) 
		{
			for(int k=0;k<s;++k) 
				xie[i|j][k]=(xie[i|j][k]+1ll*row1[i][k]*colu1[j][k])%mod;
		}
		for(int i=0;i<4;++i) NTT(xie[i],s,-1);

		for(int i=2;i<=(n<<1);++i) if(ang[i])
		{
			int y=min(i-1,n),x=i-y;
			for(int j=0;j<4;++j)
			{
				sum[j]-=y-x+1-(srow[j][y]-srow[j][x-1])-(scolu[j][y]-scolu[j][x-1])
				+xie[j][i];
			}
			for(int j=0;j<4;++j)
			{
				sum[j|ang[i]]+=y-x+1-(srow[j|ang[i]][y]-srow[j|ang[i]][x-1])
				-(scolu[j|ang[i]][y]-scolu[j|ang[i]][x-1])+xie[j|ang[i]][i];
			}
		}
		for(int i=0;i<4;++i) printf("%lld ",sum[i]);
	}
}

void wj()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	if(n<=1000&&m<=1000)
	{
		for(int cas=1;cas<=m;++cas)
		{
			int typ=read(),pos=read(),col=read();
			col++;
			if(typ==1) for(int i=1;i<=n;++i) ls[pos][i]|=col;
			else if(typ==2) for(int i=1;i<=n;++i) ls[i][pos]|=col;
			else for(int i=1;i<=n;++i) if(1<=pos-i&&pos-i<=n) ls[i][pos-i]|=col;
		}
		for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) sum[ls[i][j]]++;
		for(int i=0;i<4;++i) printf("%lld ",sum[i]);
		return 0;
	}
	int all12=1,col0=1;
	for(int i=1;i<=m;++i) 
	{
		int typ=read(),pos=read(),col=read();
		if(col) col0=0;
		col++;
		if(typ==3) all12=0;

		if(typ==1) row[pos]|=col;
		else if(typ==2) colu[pos]|=col;
		else ang[pos]|=col;
	}

	for(int i=1;i<=n;++i) num[row[i]]++;
	for(int i=1;i<=n;++i)
	{
		for(int j=0;j<4;++j) sum[j|colu[i]]+=num[j];
	}

	if(all12)
	{
		for(int i=0;i<4;++i) printf("%lld ",sum[i]);
		return 0;
	}
	if(col0)
	{
		colall0::solve();
		return 0;
	}
	all::solve();
	return 0;
}
