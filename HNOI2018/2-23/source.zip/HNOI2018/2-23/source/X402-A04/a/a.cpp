#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=400050;

int n,a[N],ans[N],pre[N];
vector<int>V[N];

struct node
{
	int l,r,k;
	node(int l=0,int r=0,int k=0) :l(l),r(r),k(k) { }
};
vector<node>ve[N];
vector<pii>qry[N];

namespace bit
{
	int s[N];
	inline void add(int x,int k)
	{
		for(int i=x;i<=n;i+=(i&-i)) s[i]+=k;
	}
	inline int ask(int l,int r)
	{
		int ans=0;
		for(int i=r;i;i-=(i&-i)) ans+=s[i];
		for(int i=l-1;i;i-=(i&-i)) ans-=s[i];
		return ans;
	}
}
void wj()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) 
	{
		a[i]=read();
		if(!V[a[i]].size()) V[a[i]].pb(0);
		V[a[i]].pb(i);
	}
	for(int i=1;i<=400000;++i)
	{
		int p2=1,d=0;
		if(V[i].size()) V[i].pb(n+1);
		for(int j=1,siz=V[i].size()-2;j<=siz;++j)
		{
			if(j==p2&&p2<siz) p2++,d=V[i][p2]-V[i][j];
			while(p2<siz&&V[i][p2+1]-V[i][p2]==d) p2++;
			//(V[i][j-1]+1,V[i][j])  (V[i][j],V[i][p2+1]-1)
			ve[V[i][j]].pb(node(V[i][j-1]+1,V[i][j],1));
			ve[V[i][p2+1]-1+1].pb(node(V[i][j-1]+1,V[i][j],-1));
		}
	}

	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		int l=read(),r=read();
		ve[r].pb(node(l,0,cas+1));
		qry[r].pb(pii(l,cas));
	}

	for(int i=1;i<=n;++i)
	{
		int siz=ve[i].size();
		for(int j=0;j<siz;++j)
		{
			if(ve[i][j].k>1) //ask
			{
				int sum=bit::ask(1,ve[i][j].l);
				if(sum) ans[ve[i][j].k-1]=0;
				else ans[ve[i][j].k-1]=1;
			}
			else //modify
			{
				bit::add(ve[i][j].l,ve[i][j].k);
				bit::add(ve[i][j].r+1,-ve[i][j].k);
			}
		}
	}

	memset(bit::s,0,sizeof(bit::s));
	for(int i=1;i<=n;++i)
	{
		if(pre[a[i]]) bit::add(pre[a[i]],-1);
		pre[a[i]]=i; bit::add(i,1);
		int siz=qry[i].size();
		for(int j=0;j<siz;++j)
			ans[qry[i][j].se]+=bit::ask(qry[i][j].fi,i);
	}

	for(int i=1;i<=T;++i) printf("%d\n",ans[i]);
	return 0;
}
