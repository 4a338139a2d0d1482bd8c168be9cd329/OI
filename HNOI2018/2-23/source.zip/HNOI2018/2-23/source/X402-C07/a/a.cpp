#include<cstdio>
#include<algorithm>
using namespace std;
#define rint register int
int n,a[400012],f[400012],fir[400012],h[400012],tot=0,nex[400012][21];
int now[400012],q;


long long read(){
	long long x=0,f=1;
	char ch=getchar();
	while (ch>'9'||ch<'0')
	{
	  if (ch=='-')
	    f=-1;
	  ch=getchar();
	}
	while (ch>='0'&&ch<='9')
	{
	  x=(x<<1)+(x<<3)+(ch^'0');
	  ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	n=read();
	for (rint i=1;i<=n;i++)
	{
	  a[i]=read();
	  if (f[a[i]]==0)
	  {
	    f[a[i]]=1;
	    fir[a[i]]=i;
	    h[++tot]=a[i];
	  }
	  if (now[a[i]]!=0)
	    nex[now[a[i]]][0]=i;
	  now[a[i]]=i;
	}
	for (rint i=1;i<=19;i++)
	  for (rint j=1;j<=n;j++)
	    nex[j][i]=nex[nex[j][i-1]][i-1];
	q=read();
	for (rint kace=1;kace<=q;kace++)
	{
	  int l,r;
	  l=read(),r=read();
	  int ok=0,num=0;
	  for (rint j=1;j<=tot;j++)
	  {
	  	if (fir[h[j]]>r)
	  	  break;
	  	if (now[h[j]]<l)
	  	  continue;
	  	int pos=fir[h[j]];
		for (int i=19;i>=0;i--)
	  	  if (nex[pos][i]!=0&&nex[pos][i]<l)
	  	  	pos=nex[pos][i];
		if (pos<l)
		  if (nex[pos][0]>r||nex[pos][0]==0)
		    continue;
	  	pos=nex[pos][0];
		int x=nex[pos][0]-pos,oknow=1;
		pos=nex[pos][0];
		num++;
		if (ok==1)
		  continue;
		while (pos!=0&&nex[pos][0]<=r&&nex[pos][0]!=0)
	  	{
	  	  if (nex[pos][0]-pos!=x)
	  	  {
			oknow=0;
			break;
	  	  }
	  	  pos=nex[pos][0];
		}
		if (oknow==1)
		  ok=1;
	  }
	  if (ok==1)
	    printf("%d\n",num);
	  else
	    printf("%d\n",num+1);
	}
	return 0;
}
