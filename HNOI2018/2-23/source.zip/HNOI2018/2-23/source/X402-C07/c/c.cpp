#include<cstdio>
#include<algorithm>
using namespace std;

//��0 ��1 ��2 ��3
long long n,m,a[1012][1012];
long long ans[12];
long long q[100012];

int add(int w,int c){
	if (w==0)
	  return c;
	if (w==1)
	{
	  if (c==1)
	    return 1;
	  if (c==2)
	    return 3;
	}
	if (w==2)
	{
	  if (c==1)
	    return 3;
	  if (c==2)
	    return 2;
	}
	if (w==3)
	  return w;
}

int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if (n>1000)
	{
	  while (m--)
	  {
	  	long long type,pos,color;
	  	scanf("%lld%lld%lld",&type,&pos,&color);
	  	color++;
		if (type==1)
	  	  q[pos]=add(q[pos],color);
	  }
	  for (int i=1;i<=n;i++)
	    ans[q[i]]++;
	  printf("%lld",ans[0]*n);
	  for (int i=1;i<=3;i++)
	    printf(" %lld",ans[i]*n);
	  return 0;
	}
	while (m--)
	{
	  int type,pos,color;
	  scanf("%lld%lld%lld",&type,&pos,&color);
	  color++;
	  if (type==1)
	  	for (int i=1;i<=n;i++)
	  	  a[pos][i]=add(a[pos][i],color);
	  if (type==2)
	    for (int i=1;i<=n;i++)
	      a[i][pos]=add(a[i][pos],color);
	  if (type==3)
	  {
		int x,y;
	  	if (n+1>=pos)
	  	  x=pos-1,y=1;
	  	else
	  	  x=n,y=pos-n;
	  	while (x>=1&&y<=n)
	  	{
	  	  a[x][y]=add(a[x][y],color);
	  	  x--,y++;
	    }
	  }
	  //for (int i=1;i<=n;i++,printf("\n"))
	  //  for (int j=1;j<=n;j++)
	  //    printf("%d",a[i][j]);
	}
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=n;j++)
	    ans[a[i][j]]++;
	printf("%lld",ans[0]);
	for (int i=1;i<=3;i++)
	  printf(" %lld",ans[i]);
	return 0;
}
