#include<cstdio>
#include<algorithm>
using namespace std;
const int mod=1e9+7;
int n,k,p,ans=0,f[1012],a[1012],b[1012];
int h[1025];


long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);
	if ((k==1&&p==n)||(k==n&&p==1))
	{
	  long long ans=1;
	  for (long long i=1;i<=n;i++)
	    ans=ans*i%mod;
	  printf("%lld\n",ans);
	  return 0;
	}
	if (p==n-k+1)
	{
	  long long ans=mi(2,n-1);
	  for (int i=3;i<=k;i++)
	  	ans=ans*i%mod*mi(2,mod-2)%mod;
	  printf("%lld\n",ans);
	  return 0;
	}
	if (p>n*(n+1)/2)
	{
	  printf("%d\n",0);
	  return 0;
	}
	for (int i=1;i<=n;i++)
	  a[i]=i;
	int tot=0;
	for (int i=0;i<=1025;i++)
	  h[i]=0;
	for (int l=1;l<=n;l++)
	  for (int r=l+k-1;r<=n;r++)
	  {
		for (int i=l;i<=r;i++)
	  	  b[i]=a[i];
		sort(b+l,b+1+r);
	  	int x=0;
		for (int i=l;i<=l+k-1;i++)
	  	  x=x+(1<<b[i]);
		if (!h[x])
	  	{
	  	  h[x]=1;
	  	  tot++;
	  	}
	  }
	if (tot==p)
	  ans++;
	while (next_permutation(a+1,a+1+n))
	{
	  int tot=0;
	  for (int i=0;i<=1025;i++)
	    h[i]=0;
	  for (int l=1;l<=n;l++)
	    for (int r=l+k-1;r<=n;r++)
	    {
	  	  
		  for (int i=l;i<=r;i++)
	  	    b[i]=a[i];
		  sort(b+l,b+1+r);
	  	  //for (int i=l;i<=l+k-1;i++)
	  	  //  printf("%d",b[i]);printf("\n");
	  	  int x=0;
		  for (int i=l;i<=l+k-1;i++)
	  	    x=x+(1<<b[i]);
	  	  //printf(" %d\n",x);
		  if (!h[x])
	  	  {
	  	    h[x]=1;
	  	    tot++;
	  	  }
	    }
	  //printf("tot is %d\n",tot);
	  if (tot==p)
	    ans++;
	}
	printf("%d\n",ans);
	return 0;
}
