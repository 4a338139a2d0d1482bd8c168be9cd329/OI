#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 1 << 20;
const int mo = 998244353;

int fpm(int x, int y) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1)
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

namespace Poly {
    const int G = 3;

    int len;
    void init(int l) {
        len = l;
        while(len > (len & -len)) len += (len & -len);
    }

    void dft(int *x, int ty) {
        for(int i = 0, j = 0; i < len; ++ i) {
            if(i < j) std::swap(x[i], x[j]); 
            for(int l = len >> 1; (j ^= l) < l; l >>= 1);
        }

        for(int l = 1; l < len; l <<= 1) {
            int wn = fpm(G, (mo-1)/l/2);
            if(!~ty) wn = fpm(wn, mo - 2);

            for(int i = 0; i < len; i += (l << 1)) {
                int w = 1;
                for(int j = 0; j < l; ++j) {
                    int u = x[i + j];
                    int v = 1ll * x[i + j + l] * w % mo;

                    x[i + j] = (u + v) % mo;
                    x[i + j + l] = (u - v + mo) % mo;
                    w = 1ll * w * wn % mo;
                }
            }
        }

        if(!~ty) {
            int inv = fpm(len, mo - 2);
            for(int i = 0; i < len; ++i) x[i] = 1ll * x[i] * inv % mo;
        }
    }
}

int n, m;
int r[N + 5], c[N + 5], x[N + 5];
int a[4][N + 5], b[4][N + 5], res[4][N + 5];

int main() {
    freopen("c.in", "r", stdin);
    freopen("c.out", "w", stdout);

    read(n), read(m);
    for(int i = 1; i <= m; ++i) {
        static int op, p, co;
        read(op), read(p), read(co);

        if(op == 1) r[p] |= 1 << co;
        if(op == 2) c[p] |= 1 << co;
        if(op == 3) x[p] |= 1 << co;
    }

    for (int i = 1; i <= n; ++i) { a[c[i]][n-i] = 1; }
    for (int i = 2; i <= n*2; ++i) { b[x[i]][i] = 1; }

    using namespace Poly;

    init(3 * n + 5);

    dft(a[0], 1); dft(a[1], 1); dft(a[2], 1); dft(a[3], 1);
    dft(b[0], 1); dft(b[1], 1); dft(b[2], 1); dft(b[3], 1);
    
    for(int i = 0; i < 4; ++i) {
        for(int j = 0; j < 4; ++j) {
            for(int k = 0; k < len; ++k) {
                res[i|j][k] = (res[i|j][k] + 1ll * a[i][k] * b[j][k]) % mo;
            }
        }
    }

    dft(res[0], -1); dft(res[1], -1); dft(res[2], -1); dft(res[3], -1);

    ll col[4] = {0};

    for(int i = 1; i <= n; ++i) {
        if(r[i] == 0) { 
            col[0] += res[0][n + i], col[1] += res[1][n + i];
            col[2] += res[2][n + i], col[3] += res[3][n + i];
        }
        if(r[i] == 1) { 
            col[1] += res[0][n + i] + res[1][n + i];
            col[3] += res[2][n + i] + res[3][n + i];
        }
        if(r[i] == 2) { 
            col[2] += res[0][n + i] + res[2][n + i];
            col[3] += res[1][n + i] + res[3][n + i];
        }
        if(r[i] == 3) { col[3] += n; }
    }
    for(int i = 0; i < 4; ++i) printf("%lld ", col[i]);

    return 0;
}
