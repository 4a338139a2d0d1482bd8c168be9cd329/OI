#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 400;
const int mo = 1e9 + 7;

int n, k, p;
int fac[N + 5];
int dp[N + 5][N + 5], temp[N + 5];

int calc() {
    dp[k][1] = fac[k]; 

    for (int i = k + 1; i <= n; ++ i) {
        for (int j = 1; j <= k; ++ j) temp[j] = 0;
        for (int j = 1; j <= i; ++ j) {
            int tmp = std::min(std::min(j, i-j+1), std::min(k, i-k+1));
            ++ temp[tmp];
        }
        for (int j = 1; j <= p; ++ j) if (dp[i-1][j]) {
            for (int t = 0; t + j <= p; ++ t) {
                dp[i][t + j] = (dp[i][t + j] + 1ll * dp[i-1][j] * temp[t]) % mo;
            }
        }
    }
    return dp[n][p];
}

int main() {
    freopen("b.in", "r", stdin);
    freopen("b.out", "w", stdout);

    read(n), read(k), read(p);

    fac[0] = 1;
    for(int i = 1; i <= n; ++ i) fac[i] = 1ll * fac[i-1] * i % mo;

    if(k == 1 && p == n) {
        printf("%d\n", fac[n]);
    } else if(k == n && p == 1) {
        printf("%d\n", fac[n]);
    } else if(p > n * (n + 1) / 2) {
        printf("%d\n", 0);
    } else printf("%d\n", calc());

    return 0;
}
