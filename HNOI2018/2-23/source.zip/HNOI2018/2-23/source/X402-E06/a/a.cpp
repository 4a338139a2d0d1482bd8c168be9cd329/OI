#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 400000;

struct Query {
    int l, r, id;

    bool operator < (const Query& rhs) const {
        return l < rhs.l;
    }
} Q[N + 5];

namespace SEG {
    const int SZ = N << 2;

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    int s[SZ + 5], mx[SZ + 5];

    void modify(int u, int l, int r, int x, int p, int q) {
        if(l == r) { 
            s[u] += p;
            mx[u] = q; 
            return; 
        }

        if(x <= mid) modify(lc, l, mid, x, p, q);
        else modify(rc, mid+1, r, x, p, q);

        s[u] = s[lc] + s[rc];
        mx[u] = mx[lc] > mx[rc] ? mx[lc] : mx[rc];
    }

    inline pii merge(const pii& a, const pii& b) {
        return mp(a.fst + b.fst, a.snd > b.snd ? a.snd : b.snd);
    }

    inline pii query(int u, int l, int r, int x, int y) {
        if(y < l || x > r) return mp(0, 0);
        if(x <= l && r <= y) return mp(s[u], mx[u]);
        return merge(query(lc, l, mid, x, y), query(rc, mid+1, r, x, y));
    }
}

int n, q;
int a[N + 5];

vector<int> pos[N + 5];
int nxt[N + 5], to[N + 5], ans[N + 5];

int main() {
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);

    read(n);
    for(int i = 1; i <= n; ++i) {
        read(a[i]);
        pos[a[i]].pb(i);
    }
    read(q);
    for(int i = 1; i <= q; ++i) {
        Q[i].id = i;
        read(Q[i].l), read(Q[i].r);
    }
    std::sort(Q + 1, Q + q + 1);

    for(int i = 1; i <= N; ++i) if(pos[i].size()) {
        int sz = pos[i].size();
        for(int j = pos[i].size()-1; j >= 0; --j) {

            nxt[pos[i][j]] = (j == sz - 1) ? n + 1 : pos[i][j + 1];

            if(j == sz - 1 || j == sz - 2) {
                to[pos[i][j]] = n + 1;
            } else {
                if(2 * pos[i][j+1] == pos[i][j+2] + pos[i][j]) {
                    to[pos[i][j]] = to[pos[i][j+1]];
                } else {
                    to[pos[i][j]] = pos[i][j + 2];
                }
            }
        }
    }

    for(int i = 1; i <= n; ++i) {
        if(i == pos[a[i]][0]) {
            SEG::modify(1, 1, n, i, 1, to[i]);
        }
    }

    for(int i = 1, j = 1; i <= n; ++i) {
        while (Q[j].l == i) {
            pii tmp = SEG::query(1, 1, n, Q[j].l, Q[j].r);
            ans[Q[j].id] = tmp.fst + (tmp.snd <= Q[j].r);
            ++ j;
        }

        SEG::modify(1, 1, n, i, -1, 0);
        if(nxt[i] <= n) 
            SEG::modify(1, 1, n, nxt[i], 1, to[nxt[i]]);
    }
    for(int i = 1; i <= q; ++i) printf("%d\n", ans[i]);

    return 0;
}
