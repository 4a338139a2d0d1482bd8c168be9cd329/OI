/************************************************
 * Au: Hany01
 * Date: Feb 23th, 2018
 * Prob: A
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define psb(a) push_back(a)
#define psf(a) push_front(a)
#define ppb() pop_back()
#define ppf() pop_front()
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
}

const int maxn = 400010;

int n, a[maxn], bel[maxn], block, Ans[maxn], cnt1, cnt2, cnt[maxn], isdc[maxn], L, R, qn;
deque<int> q[maxn];

struct Question
{
	int l, r, id;
}Q[maxn];
bool operator < (const Question& q1, const Question& q2) {
	return bel[q1.l] < bel[q2.l] || (bel[q1.l] == bel[q2.l] && q1.r < q2.r);
}

inline bool chk(int x)
{
	static int a[maxn], cnt, flag;
	cnt = 0, flag = 1;
	while (!q[x].empty()) a[++ cnt] = q[x].front(), q[x].ppf();
	For(i, 3, cnt) if (a[i] - a[i - 1] != a[i - 1] - a[i - 2]) { flag = 0; break; }
	For(i, 1, cnt) q[x].psb(a[i]);
	return flag;
}

int main()
{
    File();
	n = read();
	For(i, 1, n) a[i] = read();
	block = sqrt(n);
	For(i, 1, n) bel[i] = (i - 1) / block;
	qn = read();
	For(i, 1, qn) Q[i].l = read(), Q[i].r = read(), Q[i].id = i;
	sort(Q + 1, Q + 1 + qn);
	L = R = Q[1].l, q[1].psb(Q[1].l), ++ cnt[a[Q[1].l]], ++ cnt1, ++ cnt2, isdc[a[Q[1].l]] = 1;
	For(i, 1, qn) {
		while (L < Q[i].l) {
			q[a[L]].ppf();
			-- cnt[a[L]];
			if (!cnt[a[L]]) { isdc[a[L]] = 0; -- cnt2; -- cnt1; }
			else if (!isdc[a[L]])
				if (cnt[a[L]] < 3 || chk(a[L])) { isdc[L] = 1; ++ cnt2; }
			++ L;
		}
		while (R > Q[i].r) {
			q[a[R]].ppb();
			-- cnt[a[R]];
			if (!cnt[a[R]]) { isdc[a[R]] = 0; -- cnt2; -- cnt1; }
			else if (!isdc[a[R]])
				if (cnt[a[R]] < 3 || chk(a[R])) { isdc[R] = 1; ++ cnt2; }
			-- R;
		}
		while (L > Q[i].l) {
			-- L;
			q[a[L]].psf(L);
			++ cnt[a[L]];
			if (cnt[a[L]] == 1) { isdc[a[L]] = 1; ++ cnt2; ++ cnt1; }
			else if (isdc[a[L]] && cnt[a[L]] > 2 && !chk(a[L])) { isdc[a[L]] = 0; -- cnt2; }
		}
		while (R < Q[i].r) {
			++ R;
			q[a[R]].psf(R);
			++ cnt[a[R]];
			if (cnt[a[R]] == 1) { isdc[a[R]] = 1; ++ cnt2; ++ cnt1; }
			else if (isdc[a[R]] && cnt[a[R]] > 2 && !chk(a[R])) { isdc[a[R]] = 0; -- cnt2; }
		}
		Ans[Q[i].id] = cnt1 + (cnt2 == 0);
	}
	For(i, 1, qn) printf("%d\n", Ans[i]);
	return 0;
}
