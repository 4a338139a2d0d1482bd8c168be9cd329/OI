/************************************************
 * Au: Hany01
 * Date: Feb 23th, 2018
 * Prob: B
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("b.in", "r", stdin);
    freopen("b.out", "w", stdout);
}

const int maxn = 1005;

int n, k, p, a[maxn], cnt;

inline LL fac(LL x) {
	LL Ans = 1;
	For(i, 2, x) (Ans *= i) %= Mod;
	return Ans;
}

set<int> S;
map<int, bool> mp;

inline int update()
{
	LL t = 0;
	for (set<int>::iterator it = S.begin(); it != S.end(); ++ it) t = (t * 998244353ll % Mod + (*it)) % Mod;
	if (mp[t]) return 0;
	mp[t] = 1; return 1;
}

inline void check()
{
	mp.clear();
	int sum = 0;
	For(i, 1, n - k + 1) {
		S.clear();
		For(j, i, i + k - 1) S.insert(a[j]);
		sum += update();
		For(j, i + k, n) S.insert(a[j]), S.erase(-- S.end()), sum += update();
	}
	if (sum == p) ++ cnt;
}

int main()
{
    File();
	n = read(), k = read(), p = read();
	if (k == 1 && p == n || k == n && p == 1) { cout << fac(n) << endl; return 0; }
	if (p == n - k + 1) { cout << fac(k) * 2 * (p - 1) % Mod << endl; return 0; }
	if (p > n * (n + 1) / 2) { puts("0"); return 0; }
	For(i, 1, n) a[i] = i;
	For(i, 1, fac(n)) check(), next_permutation(a + 1, a + 1 + n);
	printf("%d\n", cnt);
    return 0;
}
