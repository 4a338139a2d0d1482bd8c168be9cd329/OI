#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
const lf pi=acos(-1.0);
int n,m;
int tag[3][maxn<<1],cnt[4];
ll ans[4];
complex<lf>A[4][maxn<<2],B[4][maxn<<2];
int C[4][maxn<<1];
complex<lf>a[maxn<<2],b[maxn<<2];
int rev[maxn<<2];
void getrev(int n){
	REP(i,0,n-1)
		rev[i]=(rev[i>>1]>>1)|((i&1)*(n>>1));
}
void DFT(complex<lf>*y,int n,int flag){
	REP(i,0,n-1)
		if(rev[i]<i)swap(y[i],y[rev[i]]);
	for(int k=2;k<=n;k<<=1){
		complex<lf>wn(cos(2*pi/k),sin(flag*2*pi/k));
		for(int i=0;i<n;i+=k){
			complex<lf>x(1,0),y0,y1;
			for(int j=0;j<(k>>1);++j,x*=wn){
				y0=y[i+j],y1=x*y[i+j+(k>>1)];
				y[i+j]=y0+y1,y[i+j+(k>>1)]=y0-y1;
			}
		}
	}
}
void FFT(complex<lf>*A,complex<lf>*B,int *C,int N){
	REP(i,0,N-1)a[i]=A[i]*B[i];
	DFT(a,N,-1);
	REP(i,2,2*n)C[i]+=(int)(a[i].real()/N+0.5);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,m){
		int type=read(),p=read(),c=read();
		tag[type-1][p]|=(1<<c);
	}
	REP(i,1,n){
		cnt[tag[0][i]]++;
		ans[tag[0][i]]+=n;
	}
	REP(i,1,n){
		REP(j,0,3){
			ans[j]-=cnt[j];
			ans[j|tag[1][i]]+=cnt[j];
		}
	}
	REP(i,1,n){
		REP(j,0,3){
			A[j][i]=tag[0][i]==j;
			B[j][i]=tag[1][i]==j;
		}
	}
	int N=1;
	while(N<=2*n)N<<=1;
	getrev(N);
	REP(i,0,3){
		DFT(A[i],N,1);
		DFT(B[i],N,1);
	}
	REP(i,0,3)
		REP(j,0,3)
			FFT(A[i],B[j],C[i|j],N);
//	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	REP(i,2,2*n){
		REP(j,0,3){
			ans[j]-=C[j][i];
			ans[j|tag[2][i]]+=C[j][i];
		}
	}
	REP(i,0,3)
		write(ans[i],i==iend?'\n':' ');
	return 0;
}
