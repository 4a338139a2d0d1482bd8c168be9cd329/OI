#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1005,mod=1e9+7;
int n,m,p,a[maxn],b[maxn],all;
bool vis[1<<20];
int calc(){
	REP(i,0,all)vis[i]=0;
	int cnt=0,res=0;
	REP(i,1,n)
		REP(j,i+m-1,n){
			cnt=0;
			REP(k,i,j)
				b[++cnt]=a[k];
			sort(b+1,b+1+cnt);
			int s=0,ts;
			REP(i,1,m)
				s|=(1<<(b[i]-1));
			if(!vis[s])vis[s]=1,++res;
		}
	return res;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
#endif
	n=read(),m=read(),p=read();
	if(n<=8){
		all=(1<<n)-1;
		REP(i,1,n)a[i]=i;
		int tot=1,ans=0;
		REP(i,1,n)tot*=i;
		REP(i,1,tot){
			if(calc()==p)++ans;
			next_permutation(a+1,a+1+n);
		}
		write(ans,'\n');
	}else{
		int ans=1;
		REP(i,1,n)ans=1ll*ans*i%mod;
		write(ans,'\n');
	}
	return 0;
}
