#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=400005;
int n,m,a[maxn],q_cnt;
struct bitree{
	int c[maxn];
	void update(int x,int val){
		while(x<=n)
			c[x]+=val,x+=x&-x;
	}
	int query(int x){
		int res=0;
		while(x)
			res+=c[x],x-=x&-x;
		return res;
	}
}T1,T2;
int ans[maxn],nxt[maxn],pos[maxn];
struct Query{
	int l,r,id,cnt;
	bool operator < (const Query &A) const {
		return l<A.l;
	}
}q[maxn];
struct segment{
	int l,r,x;
};
vector<int>ve[maxn];
vector<segment>s[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
#endif
	n=read();
	REP(i,1,n){
		a[i]=read();
		if(pos[a[i]])nxt[pos[a[i]]]=i;
		else T1.update(i,1);
		ve[a[i]].pb(i);
		pos[a[i]]=i;
	}
	q_cnt=read();
	REP(i,1,q_cnt)
		q[i].l=read(),q[i].r=read(),q[i].id=i;
	sort(q+1,q+1+q_cnt);
	int cur=1;
	REP(i,1,n){
		while((cur<=q_cnt)&&(q[cur].l==i))q[cur].cnt=T1.query(q[cur].r),++cur;
		T1.update(i,-1);
		if(nxt[i])T1.update(nxt[i],1);
	}
	REP(i,1,4e5){
		if(!ve[i].size())continue;
		if(ve[i].size()==1){
			s[1].pb((segment){ve[i][0],n,1});
			s[ve[i][0]+1].pb((segment){ve[i][0],n,-1});
		}
		REP(j,0,ve[i].size()-2){
			int k=j+1;
			while((k<ve[i].size()-1)&&(ve[i][k+1]-ve[i][k]==ve[i][j+1]-ve[i][j]))++k;
			s[j==0?1:ve[i][j-1]+1].pb((segment){ve[i][j],k==ve[i].size()-1?n:ve[i][k+1]-1,1});
			REP(l,j,k)s[ve[i][l]+1].pb((segment){ve[i][l],l==ve[i].size()-1?n:ve[i][l+1]-1,-1});
			j=k-1;
		}
	}
	cur=1;
	int cur1=1,r=0;
	REP(i,1,n){
		REP(j,0,s[i].size()-1){
			int l=s[i][j].l,r=s[i][j].r,x=s[i][j].x;
			T2.update(l,x),T2.update(r+1,-x);
		}
		while((cur<=q_cnt)&&(q[cur].l==i))ans[q[cur].id]=q[cur].cnt+(T2.query(q[cur].r)==0),++cur;
	}
	REP(i,1,q_cnt)
		write(ans[i],'\n');
	return 0;
}
