sample2满足$m\equiv3(mod\ 4)$

sample3满足$m\equiv5(mod\ 8)$

