#include <cstring>
#include <cstdio>
#include <algorithm>
const int MAXN = 50010;
using namespace std;

inline void read(int &x) {
    char ch; while((ch = getchar()), (ch < '0' || ch > '9'));
    x = ch - '0'; while((ch = getchar()), (ch >= '0' && ch <= '9')) x = x * 10 + (ch - '0');
}

struct Dis {
    int DS[8*MAXN], NDS = 0;
    inline void ins(int x) { DS[++NDS] = x; }
    inline void init() { sort(DS + 1, DS + NDS + 1); NDS = unique(DS + 1, DS + NDS + 1) - DS; }
    inline int find(int x) { return lower_bound(DS + 1, DS + NDS + 1, x) - DS; }
} DX, DY, DZ;

namespace trie {
    const int MAXLOG = 17;
    const int MAXNODE = MAXN * (MAXLOG + 1) * (MAXLOG + 1);

    int ch[MAXNODE][2], size[MAXNODE], pool;
    inline int newnode() {
        ch[pool][0] = ch[pool][1] = 0, size[pool] = 0;
        return pool++;
    }

    inline void ins_in(int u, int x) {
        int i; bool v;
        for(i = MAXLOG - 1; i >= 0; i--) {
            v = (x >> i) & 1;
            if(!ch[u][v]) ch[u][v] = newnode();
            u = ch[u][v];
            size[u]++;
        }
    }
    inline int querylte_in(int u, int x) {
        int i, ret = 0; bool v;
        x++; for(i = MAXLOG - 1; i >= 0; i--) {
            v = (x >> i) & 1;
            if(v == 1) ret += size[ ch[u][0] ];
            u = ch[u][v];
            if(!u) break;
        }
        return ret;
    }

    //Interface
    inline void clear() {
        ch[1][0] = ch[1][1] = 0, size[1] = 0, pool = 2;
    }
    inline void ins(int x, int y) {
        int i, u = 1; bool v;
        for(i = MAXLOG - 1; i >= 0; i--) {
            v = (x >> i) & 1;
            if(!ch[u][v]) ch[u][v] = newnode();
            u = ch[u][v];

            if(!size[u]) size[u] = newnode();
            ins_in(size[u], y);
        }
    }
    inline int query(int x, int y) {
        int i, u = 1, ret = 0; bool v;
        x++; for(i = MAXLOG - 1; i >= 0; i--) {
            v = (x >> i) & 1;
            if((v == 1) && size[ ch[u][0] ]) ret += querylte_in(size[ ch[u][0] ], y);

            u = ch[u][v];
            if(!u) break;
        }
        return ret;
    }
}

struct query {
    int x, y, z, id, sgn;
    inline bool operator<=(query rhs) const {
        return x <= rhs.x;
    }
} Q[8*MAXN], T[8*MAXN];
int M, NQ, NID = 0, Ans[MAXN];

void solve(int l, int r) { //[l, r)
    if(r - l <= 1) return;

    //recursive
    int m = (l + r) >> 1;
    solve(l, m); solve(m, r);

    //solve
    int pL = l, pR = m, n = 0;
    trie::clear();
    while((pL < m) || (pR < r)) {
        if((!(pR < r)) || ((pL < m) && (Q[pL] <= Q[pR]))) { //left
            if(Q[pL].id == -1) trie::ins(Q[pL].y, Q[pL].z);
            T[n++] = Q[pL++];
        }
        else {
            if(Q[pR].id != -1) Ans[Q[pR].id] += Q[pR].sgn * trie::query(Q[pR].y, Q[pR].z);
            T[n++] = Q[pR++];
        }
    }
    for(int i = 0; i < n; i++) Q[i + l] = T[i];
}

int main() {
    freopen("b.in", "rt", stdin);
    freopen("b.out", "wt", stdout);

    int i, op, xL, yL, zL, xR, yR, zR;
    read(M);
    for(i = 1; i <= M; i++) {
        read(op), read(xL), read(yL), read(zL);
        if(op == 1) {
            xL++, yL++, zL++;
            Q[++NQ] = {xL, yL, zL, -1, 0};
        }
        else {
            read(xR), read(yR), read(zR);
            xR++, yR++, zR++;

            NID++;
            Q[++NQ] = {xR, yR, zR, NID, 1};
            Q[++NQ] = {xR, yR, zL, NID, -1};
            Q[++NQ] = {xR, yL, zR, NID, -1};
            Q[++NQ] = {xR, yL, zL, NID, 1};

            Q[++NQ] = {xL, yR, zR, NID, -1};
            Q[++NQ] = {xL, yR, zL, NID, 1};
            Q[++NQ] = {xL, yL, zR, NID, 1};
            Q[++NQ] = {xL, yL, zL, NID, -1};
        }
    }

    //Discrete!!!
    for(i = 1; i <= NQ; i++) DX.ins(Q[i].x), DY.ins(Q[i].y), DZ.ins(Q[i].z);
    DX.init(), DY.init(), DZ.init();
    for(i = 1; i <= NQ; i++) Q[i].x = DX.find(Q[i].x), Q[i].y = DY.find(Q[i].y), Q[i].z = DZ.find(Q[i].z);

    //Solve && print Ans
    solve(1, NQ + 1);
    for(i = 1; i <= NID; i++) printf("%d\n", Ans[i]);
}
