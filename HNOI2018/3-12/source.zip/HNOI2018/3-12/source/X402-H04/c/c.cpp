#include <cstring>
#include <cstdio>
#include <algorithm>
#define ll long long
inline int mul(int x, int y, int m) { return (ll)x * (ll)y % m; }
inline int add(int x, int y, int m) { int r = x + y; if(r >= m) r -= m; return r; }
using namespace std;

int T, C, M;
namespace SolveBF {
    void Solve() {
        int x;
        while(T--) {
            scanf("%d%d", &C, &M); C %= M;
            if(C < 0) C = M - C;

            bool haveRoot = 0;
            for(x = 0; x < M; x++) if(mul(x, x, M) == C) {
                haveRoot = 1;
                printf("%d ", x);
            }

            if(!haveRoot) printf("no");
            putchar('\n');
        }
    }
}
namespace SolveQAQ {
    const int Scan = 1000;

    int Root;
    inline void findroot(int l, int r) {
    	if(Root != -1) return;
    	
        if(l < 0) l = 0;
        if(r > (M - 1)) r = M - 1;

        for(int i = l; i <= r; i++) if(mul(i, i, M) == C) {
            Root = i;
            break;
        }
    }

    void Solve() {
        while(T--) {
            scanf("%d%d", &C, &M); C %= M;
            if(C < 0) C = M - C;

            Root = -1;
            findroot(0, Scan);
            findroot((M / 2) - Scan, M / 2);

            findroot(C, C + Scan);
            findroot(C - Scan, C);

            if(Root == -1) printf("no\n");
            else {
                int minroot = Root, maxroot = (M - Root) % M;
                if(minroot > maxroot) swap(minroot, maxroot);

                if(minroot == maxroot) printf("%d\n", minroot);
                else printf("%d %d\n", minroot, maxroot);
            }
        }
    }
}

int main() {
    freopen("c.in", "rt", stdin);
    freopen("c.out", "wt", stdout);

    scanf("%d", &T);
    if(T <= 1000) SolveBF::Solve();
    else SolveQAQ::Solve();
}
