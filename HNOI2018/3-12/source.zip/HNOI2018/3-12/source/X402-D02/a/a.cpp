#include<iostream>
#include<cstdio>
#include<cstring>

const int N=101000;

int A[N],B[N],C[N];

int n;

void output(int *s)
{
	for(int i=0;i<=n;i++)
		if(s[i])printf("%d ",i);
	printf("\n");
}

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);

	C[0]=1;
	for(int i=1;i<=n;i++)
		if(i&1)C[i]=-C[i/2];
		else C[i]=C[i/2];
	for(int i=0;i<=n;i++)
	{
		if(C[i]==1)A[i]=1;
		else B[i]=1;
	}

	if(A[1]==1)output(A);
	else output(B);

	return 0;
}
