#include<iostream>
#include<cstdio>
#include<cstring>

const int N=23333;

int A[N];

bool check(int sum)
{
	int cnt=0;
	for(int i=0;i<=sum;i++)
	{
		if(i==sum-i)continue;
		if(A[i] && A[sum-i])cnt++;
		if(!A[i] && !A[sum-i])cnt--;
	}
	return cnt==0;
}

int main()
{
	freopen("a.out","r",stdin);
	int n,x;
	scanf("%d",&n);
	while(~scanf("%d",&x))A[x]=1;

	for(int i=1;i<=n;i++)
		if(!check(i)){printf("fuck you\n");return 1;}

	printf("so\n");
	return 0;
}
