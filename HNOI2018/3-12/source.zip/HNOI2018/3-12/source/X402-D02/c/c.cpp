#include<iostream>
#include<cstdio>
#include<cstring>

typedef long long ll;

int n,m;

ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%m)if(b&1)c=c*a%m;return c;}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;)
	{
		scanf("%d%d",&n,&m);
		bool flag=0;
		for(int i=0;i<m;i++)
			if((ll)i*i%m==n)printf("%d ",i),flag=1;
		if(!flag)printf("no\n");
		else printf("\n");
	}
	return 0;
}
