#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}
void write(int x)
{
	if(x>=10)write(x/10);
	putchar((x%10)^'0');
}

const int N=401000;

struct node
{
	int ty,x,y,z,id;
	node(int a=0,int b=0,int c=0,int d=0,int e=0):ty(a),x(b),y(c),z(d),id(e){}
};
bool cmpx(node A,node B){return A.x!=B.x?A.x<B.x:A.ty<B.ty;}
bool cmpy(node A,node B){return A.y!=B.y?A.y<B.y:A.ty<B.ty;}
bool cmpz(node A,node B){return A.z!=B.z?A.z<B.z:A.ty<B.ty;}

int ans[N];

namespace Fucker
{
	struct BIT
	{
#define lowbit(x) ((x)&(-(x)))
		int w[N];
		inline void inc(int p,int x){for(;p<N;p+=lowbit(p))w[p]+=x;}
		inline int ask(int p){int ret=0;for(;p;p-=lowbit(p))ret+=w[p];return ret;}
	}T;

	int mw[N*2],tot;

	inline int getid(int x){return std::lower_bound(mw+1,mw+tot+1,x)-mw;}

	node s[N];
	int n;

	void calc(node *ds,int dn)
	{
		if(!dn)return;

		n=dn,tot=0;
		for(int i=1;i<=n;i++)
			s[i]=ds[i],mw[++tot]=s[i].x,mw[++tot]=s[i].y;
		std::sort(mw+1,mw+tot+1);
		tot=std::unique(mw+1,mw+tot+1)-mw-1;
		for(int i=1;i<=n;i++)
			s[i].x=getid(s[i].x),s[i].y=getid(s[i].y);
//		std::sort(s+1,s+n+1,cmpx);

		for(int i=1;i<=n;i++)
		{
			if(s[i].ty==1)T.inc(s[i].y,1);
			else if(s[i].ty==2)ans[s[i].id]-=T.ask(s[i].y);
			else ans[s[i].id]+=T.ask(s[i].y);
		}
		for(int i=1;i<=n;i++)
			if(s[i].ty==1)T.inc(s[i].y,-1);
	}
}

namespace Worker
{
	node s[N],t[N];

	void DC(int L,int R)
	{
		if(L==R)return;

		int mid=(L+R)>>1;

		DC(L,mid),DC(mid+1,R);

		static node u[N],v[N];
		int cu=0,cv=0,cnt=0;

		for(int i=L;i<=mid;i++)
			if(s[i].ty==1)u[++cu]=s[i];
		for(int i=mid+1;i<=R;i++)
			if(s[i].ty>=2)v[++cv]=s[i];

		int iu=1,iv=1;
		while(iu<=cu || iv<=cv)
		{
			if(iu>cu)t[++cnt]=v[iv++];
			else if(iv>cv)t[++cnt]=u[iu++];
			else if(cmpx(u[iu],v[iv]))t[++cnt]=u[iu++];
			else t[++cnt]=v[iv++];
		}

		Fucker::calc(t,cnt);

		iu=L,iv=mid+1,cnt=0;
		while(iu<=mid || iv<=R)
		{
			if(iu>mid)t[++cnt]=s[iv++];
			else if(iv>R)t[++cnt]=s[iu++];
			else if(cmpx(s[iu],s[iv]))t[++cnt]=s[iu++];
			else t[++cnt]=s[iv++];
		}
		for(int i=1;i<=cnt;i++)
			s[L+i-1]=t[i];
	}
	void calc(node *ds,int n)
	{
		if(!n)return;

		for(int i=1;i<=n;i++)
			s[i]=ds[i];
//		std::sort(s+1,s+n+1,cmpz);

		DC(1,n);
	}
}

namespace FuckFuckFuck
{
	node s[N];

	int n,m,tot;
	void initialize()
	{
		read(m),tot=n=0;
		int ty,x0,y0,z0,x1,y1,z1;
		for(int i=1;i<=m;i++)
		{
			read(ty),read(x0),read(y0),read(z0);
			if(ty==1)s[++n]=node(ty,x0,y0,z0,-1);
			else
			{
				tot++;
				read(x1),read(y1),read(z1);
				s[++n]=node(3,x1,y1,z1,tot);
				s[++n]=node(2,x1,y1,z0-1,tot);

				s[++n]=node(2,x1,y0-1,z1,tot);
				s[++n]=node(3,x1,y0-1,z0-1,tot);
  			
				s[++n]=node(2,x0-1,y1,z1,tot);
				s[++n]=node(3,x0-1,y1,z0-1,tot);

				s[++n]=node(3,x0-1,y0-1,z1,tot);
				s[++n]=node(2,x0-1,y0-1,z0-1,tot);
			}
		}
	}

	node t[N];
	void DC(int L,int R)
	{
		if(L==R)return;
		int mid=(L+R)>>1;
		DC(L,mid),DC(mid+1,R);

		static node u[N],v[N];

		int cu=0,cv=0,cnt=0;

		for(int i=L;i<=mid;i++)
			if(s[i].ty==1)u[++cu]=s[i];
		for(int i=mid+1;i<=R;i++)
			if(s[i].ty>=2)v[++cv]=s[i];

		int iu=1,iv=1;
		while(iu<=cu || iv<=cv)
		{
			if(iu>cu)t[++cnt]=v[iv++];
			else if(iv>cv)t[++cnt]=u[iu++];
			else if(cmpz(u[iu],v[iv]))t[++cnt]=u[iu++];
			else t[++cnt]=v[iv++];
		}

		Worker::calc(t,cnt);

		iu=L,iv=mid+1,cnt=0;
		while(iu<=mid || iv<=R)
		{
			if(iu>mid)t[++cnt]=s[iv++];
			else if(iv>R)t[++cnt]=s[iu++];
			else if(cmpz(s[iu],s[iv]))t[++cnt]=s[iu++];
			else t[++cnt]=s[iv++];
		}
		for(int i=1;i<=cnt;i++)
			s[L+i-1]=t[i];
	}

	void solve()
	{
		initialize();

		DC(1,n);
		for(int i=1;i<=tot;i++)
			write(ans[i]),putchar('\n');
	}
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);

	FuckFuckFuck::solve();

//	fprintf(stderr,"faster time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
