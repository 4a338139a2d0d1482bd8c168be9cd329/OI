#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int rd(){return rand()%1000000000;}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("b.in","w",stdout);//look at here

	int n=50000;
	printf("%d\n",n);
	while(n--)
	{
		int ty=rand()%2+1;
		if(ty==1)
			printf("%d %d %d %d\n",ty,rd(),rd(),rd());
		else
		{
			int x0=rd(),y0=rd(),z0=rd(),x1=rd(),y1=rd(),z1=rd();
			if(x0>x1)std::swap(x0,x1);
			if(y0>y1)std::swap(y0,y1);
			if(z0>z1)std::swap(z0,z1);
			printf("%d %d %d %d %d %d %d\n",ty,x0,y0,z0,x1,y1,z1);
		}
	}

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
