

/* You can use this program to move out the programs int everyone's dictory */

#include<iostream>  
#include<stdio.h>  
#include<unistd.h>  
#include<dirent.h>  
#include<stdlib.h>  
#include<sys/stat.h>  
#include<string.h>  
using namespace std;  
  
/***** Global Variables *****/  
const int MAX_STR_LEN = 200;  
const int num_of_problems=3;
char Dir[MAX_STR_LEN] = "/home/yali/warning/contest/2018/2-23/source/";
/* Need '/' at the End */

char T[num_of_problems][MAX_STR_LEN]={"a","b","c"};
/* The name of the problems */





/* Show all files under dir_name , do not show directories ! */  
void showAllFiles( const char * dir_name )  
{  
   // check the parameter !  
	if( NULL == dir_name )  {  
		cout<<" dir_name is null ! "<<endl;  
		return;  
	}  
  
	// check if dir_name is a valid dir  
	struct stat s;  
	lstat( dir_name , &s );  
	if( ! S_ISDIR( s.st_mode ) )  
	{  
		cout<<"dir_name is not a valid directory !"<<endl;  
		return;  
	}  
	  
	struct dirent * filename;    // return value for readdir()  
	DIR * dir;                   // return value for opendir()  
	dir = opendir( dir_name );  
	if( NULL == dir )  
	{  
		cout<<"Can not open dir "<<dir_name<<endl;  
		return;  
	}  
	cout<<"Successfully opened the dir !"<<endl;  
	  
	char strrr[10010];
	char strr[100100];
	while( ( filename = readdir(dir) ) != NULL )  
	{  
		// get rid of "." and ".."  
		if( strcmp( filename->d_name , "." ) == 0 ||   
			strcmp( filename->d_name , "..") == 0    )  
			continue;
		sprintf(strrr,"%s%s",Dir,filename ->d_name);
		printf("%s\n",strrr);
		for(int i=0;i<num_of_problems;i++){
			sprintf(strr,"cp %s/%s/%s.cpp %s/%s.cpp",strrr,T[i],T[i],strrr,T[i]);
			system(strr);
		}
	}
}   
  
int main(){ 
	showAllFiles( Dir );  
	return 0;  
}  
