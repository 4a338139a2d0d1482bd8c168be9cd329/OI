#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+10;
int n,a[maxn],c1[maxn],c2[maxn];
void work1(){
	for(int i=0;i<=n;++i)a[i]=i;
	do{
		for(int i=0;i<=n;++i)c1[i]=c2[i]=0;
		for(int i=0;i<=n/2;++i)
			for(int j=i+1;j<=n/2;++j)
				if(a[i]+a[j]<=n)++c1[a[i]+a[j]];
		for(int i=n/2+1;i<=n;++i)
			for(int j=i+1;j<=n;++j)
				if(a[i]+a[j]<=n)++c2[a[i]+a[j]];
		for(int i=0;i<=n;++i)if(c1[i]!=c2[i])goto G;
		sort(a,a+n/2+1);sort(a+n/2+1,a+n+1);
		for(int i=0;i<=n/2;++i)if(a[i]==1)goto H;
		for(int i=n/2+1;i<=n;++i)if(a[i]==1)goto I;
		H:for(int i=0;i<=n/2;++i)cout<<a[i]<<" ";break;
		I:for(int i=n/2+1;i<=n;++i)cout<<a[i]<<" ";break;
		G:;
	}while(next_permutation(a,a+n+1));
	exit(0);
}
vector<int> A,B;
void work2(){
	A.push_back(1);A.push_back(2);
	B.push_back(0);B.push_back(3);
	c1[3]=1;c2[3]=1;
	for(int i=4;i<=n;++i){
		if(c1[i]==c2[i]){
			for(int j=0;j<A.size();++j)++c1[A[j]+i];
			A.push_back(i);
		}else{
			for(int j=0;j<B.size();++j)++c2[B[j]+i];
			B.push_back(i);
		}
	}
	for(int i=0;i<A.size();++i)printf("%d ",A[i]);
}
void solve(){
	scanf("%d",&n);
	if(n<=10)work1();
	work2();
}
int main(){
	freopen("a.in","r",stdin);freopen("a.out","w",stdout);
	solve();
	return 0;
}
