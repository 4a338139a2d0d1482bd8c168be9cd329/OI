#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll fpm(ll a,ll b,ll p){ 
	ll ret=1ll;
	for(;b;b>>=1,a=a*a%p)
		if(b&1)ret=ret*a%p;
	return ret;
}
int t,c,m;
void solve(){
	for(scanf("%d",&t);t--;){
		scanf("%d%d",&c,&m);
		c%=m;(c+=m)%=m;
		for(int i=0;i<m;++i)if(1ll*i*i%m==c){
			if(!i)puts("0");
			else printf("%d %d\n",i,m-i);
			goto G;
		}
		puts("no");G:;
	}
}

int main(){
	freopen("c.in","r",stdin);freopen("c.out","w",stdout);
	solve();
	return 0;
}
