#include<bits/stdc++.h>
using namespace std;
int m;
struct data{
	int x,y,z;
};
struct query{
	int op,x1,y1,z1,x2,y2,z2;
};
vector<data> v;
vector<query> q;
int a[21][21][21];
void work1(){
	for(int qq=0,ans;qq<q.size();++qq){
		if(q[qq].op==1)++a[q[qq].x1][q[qq].y1][q[qq].z1];
		else{
			ans=0;
			for(int i=q[qq].x1;i<=q[qq].x2;++i)
				for(int j=q[qq].y1;j<=q[qq].y2;++j)
					for(int k=q[qq].z1;k<=q[qq].z2;++k)
						ans+=a[i][j][k];
			printf("%d\n",ans);
		}
	}
}
void work2(){
	for(int qq=0,ans;qq<q.size();++qq){
		if(q[qq].op==1)v.push_back((data){q[qq].x1,q[qq].y1,q[qq].z1});
		else{
			ans=0;
			for(int i=0;i<v.size();++i)
				if( q[qq].x1<=v[i].x&&v[i].x<=q[qq].x2&&
					q[qq].y1<=v[i].y&&v[i].y<=q[qq].y2&&
					q[qq].z1<=v[i].z&&v[i].z<=q[qq].z2)
					++ans;
			printf("%d\n",ans);
		}
	}

}
void solve(){
	int flag=0;
	scanf("%d",&m);
	for(int op,x1,y1,z1,x2,y2,z2;m--;){
		scanf("%d",&op);
		if(op==1){
			scanf("%d%d%d",&x1,&y1,&z1);
			q.push_back((query){op,x1,y1,z1,0,0,0});
			if(x1>20||y1>20||z1>20)flag=1;
		}
		else{
			scanf("%d%d%d%d%d%d",&x1,&y1,&z1,&x2,&y2,&z2);
			if(x1>20||y1>20||z1>20||x2>20||y2>20||z2>20)flag=1;
			q.push_back((query){op,x1,y1,z1,x2,y2,z2});
		}
	}
	if(!flag)work1();
	else work2();
}
int main(){
	freopen("b.in","r",stdin);freopen("b.out","w",stdout);
	solve();
	return 0;
}
