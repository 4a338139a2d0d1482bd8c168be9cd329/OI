#include<bits/stdc++.h>
using namespace std;

const char s[]="121<123Z121<1<d<121<123Z123[gZ3Z121<123Z121<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<123Z123[gZ3Z121<123Z123[gZ3[gdg[gZ3Z123[gZ3Z121<123Z121<1<d<121<123Z123[gZ3Z121<123Z121<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<1<d<gdd<1<d<gdg[gdd<gdd<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<123Z123[gZ3Z121<123Z121<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<123Z123[gZ3Z121<123Z123[gZ3[gdg[gZ3Z123[gZ3Z121<123Z121<1<d<121<123Z123[gZ3Z121<123Z123[gZ3[gdg[gZ3Z123[gZ3[gdg[gdd<gdg[gZ3[gdg[gZ3Z123[gZ3Z121<123Z123[gZ3[gdg[gZ3Z123[gZ3Z121<123Z121<1<d<121<123Z123[gZ3Z121<123Z121<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<123Z123[gZ3Z121<123Z123[gZ3[gdg[gZ3Z123[gZ3Z121<123Z121<1<d<121<123Z123[gZ3Z121<123Z121<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<1<d<gdd<1<d<gdg[gdd<gdd<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<123Z123[gZ3Z121<123Z121<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<1<d<gdd<1<d<gdg[gdd<gdd<1<d<121<1<d<gdd<1<d<gdg[gdd<gdg[gZ3[gdg[gdd<gdd<1<d<gdg[gdd<gdd<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121<1<d<gdd<1<d<gdg[gdd<gdd<1<d<121<1<d<gdd<1<d<121<123Z121<1<d<121";
int n;
vector<int> vec1,vec2;

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	for(int i=0;s[i];++i)
		vec1.push_back(s[i]);
	for(int i=0;i<vec1.size();++i){
		vec1[i]-=48;
		char s[]="13EDkegd";
		vec2.push_back(s[vec1[i]>>3]);
		vec2.push_back(s[vec1[i]&7]);
	}
	vec1.clear();
	for(int i=0;i<vec2.size();++i){
		vec2[i]-=48;
		char s[]="124=LJge";
		vec1.push_back(s[vec1[i]>>3]);
		vec1.push_back(s[vec1[i]&7]);
	}
	vec2.clear();
	for(int i=0;i<vec1.size();++i){
		vec1[i]-=48;
		char s[]="KMGgF]ef";
		vec2.push_back(s[vec1[i]>>3]);
		vec2.push_back(s[vec1[i]&7]);
	}
	vec1.clear();
	for(int i=0;i<vec2.size();++i){
		vec2[i]-=48;
		for(int j=7;~j;--j)
			vec1.push_back(vec2[i]>>j&1);
	}
	vec2.clear();
	for(int i=0,last=2;i<vec1.size();++i){
		if(last==1)
			if(vec1[i]==0)
				vec2.push_back(2);
			else
				vec2.push_back(3);
		if(last==2)
			if(vec1[i]==0)
				vec2.push_back(1);
			else
				vec2.push_back(3);
		if(last==3)
			if(vec1[i]==0)
				vec2.push_back(1);
			else
				vec2.push_back(2);
		last=vec2.back();
	}
	for(int i=0;i<vec2.size();++i)
		cout<<vec2[i]<<' ';
	vec1.clear();
	vec1.push_back(1);
	for(int i=0;i<vec2.size();++i)
		vec1.push_back(vec1.back()+vec2[i]);
	scanf("%d",&n);
	for(int i=0;i<vec1.size();++i)
		if(vec1[i]<=n)
			printf("%d\n",vec1[i]);
		else
			break;
	puts("");
	return 0;
}
