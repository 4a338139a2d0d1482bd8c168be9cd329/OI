#include<bits/stdc++.h>
using namespace std;

int n,x;
vector<int> a,b;
int aa[1000000],bb[1000000];

int main(){
	FILE*in=fopen("a.in","r"),*out=fopen("a.out","r");
	fscanf(in,"%d",&n);
	while(fscanf(out,"%d",&x)==1)
		a.push_back(x);
	for(int i=0,j=0;i<=n;++i)
		if(j<a.size()&&i==a[j])
			++j;
		else
			b.push_back(i);
	for(int i=0;i<a.size();++i)
		for(int j=i+1;j<a.size();++j)
			++aa[a[i]+a[j]];
	for(int i=0;i<b.size();++i)
		for(int j=i+1;j<b.size();++j)
			++bb[b[i]+b[j]];
	for(int i=1;i<=n;++i)
		if(aa[i]!=bb[i])
			cerr<<"####"<<i<<"####"<<endl;
	cerr<<"DONE"<<endl;
	return 0;
}
