#include<bits/stdc++.h>
using namespace std;

int main(){
	for(int i='0';i<='z';++i)
		cout<<(char)i<<' ';
	/*
	if(1,0){
		freopen("a.txt","r",stdin);
		freopen("a.out","w",stdout);
		int a,b,c,d;
		while(scanf("%d%d%d%d",&a,&b,&c,&d)==4){
			--a;--b;--c;--d;
			char x=(48+a*27+b*9+c*3+d);
			putchar(x);
		}
	}
	else{
		freopen("a.out","r",stdin);
		freopen("a.txt","w",stdout);
		int a,b,c;
		map<char,int> mp;
		mp['?']=3;
		mp['p']=2;
		mp['q']=1;
		mp['@']=0;
		while(a=getchar(),b=getchar(),c=getchar(),c!=EOF){
			a=mp[a];
			b=mp[b];
			c=mp[c];
			putchar('0'+a*16+b*4+c);
		}
	}*/
	if(0){
		freopen("a.txt","r",stdin);
		freopen("a.out","w",stdout);
		int last=2,x;
		while(scanf("%d",&x)==1){
			if(last==1)
				printf("%d ",x-2);
			else if(last==2)
				printf("%d ",x==1?0:1);
			else
				printf("%d ",x-1);
		}
	}
	if(0){
		freopen("a.out","r",stdin);
		freopen("a.txt","w",stdout);
		int x[6];
		while(scanf("%d%d%d%d%d%d",x,x+1,x+2,x+3,x+4,x+5)==6){
			int a=0;
			for(int i=0;i<6;++i)
				a=a*2+x[i];
			putchar(48+a);
		}
	}
	if(0){
		freopen("a.txt","r",stdin);
		freopen("a.out","w",stdout);
		map<char,int> mp;
		mp['K']=0;
		mp['M']=1;
		mp['G']=2;
		mp['g']=3;
		mp['F']=4;
		mp[']']=5;
		mp['e']=6;
		mp['f']=7;
		char a,b;
		while(a=getchar(),b=getchar(),b!=EOF){
			putchar(48+mp[a]*8+mp[b]);
		}
	}
	if(0){
		freopen("a.out","r",stdin);
		freopen("a.txt","w",stdout);
		map<char,int> mp;
		mp['1']=0;
		mp['2']=1;
		mp['4']=2;
		mp['=']=3;
		mp['L']=4;
		mp['J']=5;
		mp['g']=6;
		mp['e']=7;
		char a,b;
		while(a=getchar(),b=getchar(),b!=EOF){
			putchar(48+mp[a]*8+mp[b]);
		}
	}
	if(1){
		freopen("a.txt","r",stdin);
		freopen("a.out","w",stdout);
		map<char,int> mp;
		mp['1']=0;
		mp['3']=1;
		mp['E']=2;
		mp['D']=3;
		mp['k']=4;
		mp['e']=5;
		mp['g']=6;
		mp['d']=7;
		char a,b;
		while(a=getchar(),b=getchar(),b!=EOF){
			putchar(48+mp[a]*8+mp[b]);
		}
	}
}
