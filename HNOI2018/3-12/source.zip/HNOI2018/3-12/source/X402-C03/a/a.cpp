#include<bits/stdc++.h>
using namespace std;

const char s[]="idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCTgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCTgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCTgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCTgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCTgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCTgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidgWCTgWCNCWCTgTidgWCTgTidi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCTgTidgWCTgWCNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNCWCTgWCNCWCNM>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=i>M>CNM=i>M>CNCWCNM>CNM=i>M=idi=i>M>CNM=i>M=idi=idgTidi=i>M=idi=idgTidgWCTgTidi=idgTidi=i>M=idi=i>M>CNM=i>M=idi=idgTid";
const int maxn=1e5+100;
int n;
vector<int> vec1,vec2,vec3;

inline void decode(){
	for(int i=0;s[i];++i){
		vec1.push_back("@qp?"[(s[i]-48)/16]);
		vec1.push_back("@qp?"[(s[i]-48)/4%4]);
		vec1.push_back("@qp?"[(s[i]-48)%4]);
	}
	for(int i=0;i<vec1.size();++i){
		vec2.push_back(1+(vec1[i]-48)/27);
		vec2.push_back(1+(vec1[i]-48)/9%3);
		vec2.push_back(1+(vec1[i]-48)/3%3);
		vec2.push_back(1+(vec1[i]-48)%3);
	}
	vec3.push_back(1);
	for(int i=0;i<vec2.size();++i)
		vec3.push_back(vec3.back()+vec2[i]);
}

int main(){
	decode();
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<vec3.size();++i)
		if(vec3[i]<=n)
			printf("%d ",vec3[i]);
		else
			break;
	puts("");
	return 0;
}
