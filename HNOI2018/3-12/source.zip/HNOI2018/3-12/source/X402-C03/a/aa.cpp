#include<bits/stdc++.h>
using namespace std;

int n;
vector<int> a,b;

int main(){
	freopen("a.in","r",stdin);
	freopen("a.txt","w",stdout);
	scanf("%d",&n);
	b.push_back(0);
	for(int i=1;i<=n;++i){
		int x,y,cnta=0,cntb=0;
		x=0,y=a.size()-1;
		while(x<y)
			if(a[x]+a[y]==i)
				++cnta,++x,--y;
			else if(a[x]+a[y]<i)
				++x;
			else
				--y;
		x=0,y=b.size()-1;
		while(x<y)
			if(b[x]+b[y]==i)
				++cntb,++x,--y;
			else if(b[x]+b[y]<i)
				++x;
			else
				--y;
		if(cnta==cntb)
			a.push_back(i);
		else
			b.push_back(i);
	}
//	for(int i=0;i<a.size();++i)
//		printf("%d ",a[i]);
//	puts("");
	for(int i=1;i<a.size();++i){
		printf("%d ",a[i]-a[i-1]);
		if(i%8==0)
			puts("");
	}
	return 0;
}
