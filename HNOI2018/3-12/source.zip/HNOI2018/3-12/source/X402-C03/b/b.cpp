#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}
void write(int x){
	if(x>9)write(x/10);
	putchar(x%10+48);
}

const int maxn=5e4+10;
int m,qn,n,ans[maxn];
struct point{
	bool t1,t2;
	int x,y,z,id;
	inline point(){}
	inline point(int b,int c,int d,int e):x(b),y(c),z(d),id(e){}
}p[maxn*8];

namespace getindex{
	map<int,int> mpx,mpy,mpz;
	struct quest{
		int opt,x1,y1,z1,x2,y2,z2;
		inline void input(){
			if((opt=read())==1)
				mpx[x1=read()],mpy[y1=read()],mpz[z1=read()];
			else
				x1=read(),y1=read(),z1=read(),mpx[x2=read()],mpy[y2=read()],mpz[z2=read()];
		}
		inline void get(){
			if(opt==1)
				p[++n]=point(mpx[x1],mpy[y1],mpz[z1],0);
			else{
				x1=mpx.lower_bound(x1)->second-1;
				y1=mpy.lower_bound(y1)->second-1;
				z1=mpz.lower_bound(z1)->second-1;
				x2=mpx[x2];y2=mpy[y2];z2=mpz[z2];
				++qn;
				p[++n]=point(x1,y1,z1,-qn);
				p[++n]=point(x1,y1,z2,qn);
				p[++n]=point(x1,y2,z1,qn);
				p[++n]=point(x1,y2,z2,-qn);
				p[++n]=point(x2,y1,z1,qn);
				p[++n]=point(x2,y1,z2,-qn);
				p[++n]=point(x2,y2,z1,-qn);
				p[++n]=point(x2,y2,z2,qn);
			}
		}
	}xxx[maxn];
	inline void work(){
		for(int i=1;i<=m;++i)
			xxx[i].input();
		int cnt;
		cnt=1;
		for(map<int,int>::iterator i=mpx.begin();i!=mpx.end();++i)
			i->second=++cnt;
		cnt=1;
		for(map<int,int>::iterator i=mpy.begin();i!=mpy.end();++i)
			i->second=++cnt;
		cnt=1;
		for(map<int,int>::iterator i=mpz.begin();i!=mpz.end();++i)
			i->second=++cnt;
		for(int i=1;i<=m;++i)
			xxx[i].get();
		mpx.clear();mpy.clear();mpz.clear();
	}
}
namespace bit{
	int a[maxn];
	inline void add(int x){
		while(x<maxn){
			++a[x];
			x+=x&-x;
		}
	}
	inline void del(int x){
		while(x<maxn){
			--a[x];
			x+=x&-x;
		}
	}
	inline int sum(int x){
		int res=0;
		while(x){
			res+=a[x];
			x-=x&-x;
		}
		return res;
	}
}

inline bool cmpx(point a,point b){
	return a.x<b.x||a.x==b.x&&a.t1<b.t1;
}
inline bool cmpy(point a,point b){
	return a.y<b.y||a.y==b.y&&a.t2<b.t2;
}
inline void brute2(int l,int r){
	for(int i=l+1;i<=r;++i)
		if(p[i].t1&&p[i].id){
			int tmp=0;
			for(int j=l;j<i;++j)
				if(!p[j].t1&&!p[j].id&&p[j].y<=p[i].y&&p[j].z<=p[i].z)
					++tmp;
			if(p[i].id>0)
				ans[p[i].id]+=tmp;
			else
				ans[-p[i].id]-=tmp;
		}
}
void cdq2(int l,int r){
	if(l+250>r){
		brute2(l,r);
		return;
	}
	int mid=l+r>>1;
	cdq2(l,mid);
	cdq2(mid+1,r);
	for(int i=l;i<=mid;++i)
		p[i].t2=false;
	for(int i=mid+1;i<=r;++i)
		p[i].t2=true;
	sort(p+l,p+r+1,cmpy);
	for(int i=l;i<=r;++i)
		if(p[i].t1&&p[i].t2&&p[i].id)
			if(p[i].id>0)
				ans[p[i].id]+=bit::sum(p[i].z);
			else
				ans[-p[i].id]-=bit::sum(p[i].z);
		else if(!p[i].t1&&!p[i].t2&&!p[i].id)
			bit::add(p[i].z);
	for(int i=l;i<=r;++i)
		if(!p[i].t1&&!p[i].t2&&!p[i].id)
			bit::del(p[i].z);
}
inline void brute1(int l,int r){
	for(int i=l+1;i<=r;++i)
		if(p[i].id){
			int tmp=0;
			for(int j=l;j<i;++j)
				if(!p[j].id&&p[j].x<=p[i].x&&p[j].y<=p[i].y&&p[j].z<=p[i].z)
					++tmp;
			if(p[i].id>0)
				ans[p[i].id]+=tmp;
			else
				ans[-p[i].id]-=tmp;
		}
}
void cdq1(int l,int r){
	if(l+1300>r){
		brute1(l,r);
		return;
	}
	int mid=l+r>>1;
	cdq1(l,mid);
	cdq1(mid+1,r);
	for(int i=l;i<=mid;++i)
		p[i].t1=false;
	for(int i=mid+1;i<=r;++i)
		p[i].t1=true;
	sort(p+l,p+r+1,cmpx);
	cdq2(l,r);
}

int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	m=read();
	getindex::work();
	cdq1(1,n);
	for(int i=1;i<=qn;++i)
		write(ans[i]),putchar('\n');
	return 0;
}
