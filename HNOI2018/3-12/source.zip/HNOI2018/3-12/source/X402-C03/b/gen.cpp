#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("b.in","w",stdout);
	int n=5e4,w=1e9;
//	n=1e3;
	printf("%d\n",n);
	while(n--){
		if(rand()&1)
			printf("1 %d %d %d\n",f(0,w),f(0,w),f(0,w));
		else{
			int a=f(0,w),b=f(0,w),c=f(0,w),d=f(0,w),e=f(0,w),x=f(0,w);
			printf("2 %d %d %d %d %d %d\n",min(a,b),min(c,d),min(e,x),max(a,b),max(c,d),max(e,x));
		}
	}
	return 0;
}
