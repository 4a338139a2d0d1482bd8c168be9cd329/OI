#include<bits/stdc++.h>
using namespace std;

const int maxn=5e4+10;
int n,cnt;
struct point{
	int x,y,z;
}p[maxn];

int main(){
	freopen("b.in","r",stdin);
	freopen("b.txt","w",stdout);
	scanf("%d",&n);
	while(n--){
		int opt;
		scanf("%d",&opt);
		if(opt==1){
			++cnt;
			scanf("%d%d%d",&p[cnt].x,&p[cnt].y,&p[cnt].z);
		}
		else{
			int x1,y1,z1,x2,y2,z2,ans=0;
			scanf("%d%d%d%d%d%d",&x1,&y1,&z1,&x2,&y2,&z2);
			for(int i=1;i<=cnt;++i)
				if(x1<=p[i].x&&p[i].x<=x2&&y1<=p[i].y&&p[i].y<=y2&&z1<=p[i].z&&p[i].z<=z2)
					++ans;
			printf("%d\n",ans);
		}
	}
	return 0;
}
