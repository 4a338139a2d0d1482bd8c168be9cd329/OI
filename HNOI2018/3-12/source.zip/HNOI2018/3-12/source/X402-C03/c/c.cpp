#include<bits/stdc++.h>
using namespace std;

int t,c,m;

int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		bool ans=false;
		scanf("%d%d",&c,&m);
		c=(c%m+m)%m;
		for(int i=0;i<m;++i)
			if(i*i%m==c)
				printf("%d ",i),ans=true;
		if(ans)
			puts("");
		else
			puts("no");
	}
	return 0;
}
