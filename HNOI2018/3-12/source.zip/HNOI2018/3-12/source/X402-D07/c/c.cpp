#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

int c,mo;

int main(){
    freopen("c.in","r",stdin);
    freopen("c.out","w",stdout);

    int _; read(_);
    while(_--){
        read(c); read(mo); bool flag=0;
        for(int i=0;i<mo;i++) if(i*i%mo==c) flag=1,printf("%d ",i);
        puts(flag?"":"no");
    }

    return 0;
}
