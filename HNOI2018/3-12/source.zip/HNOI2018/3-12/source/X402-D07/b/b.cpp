#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=50010;

int n,m,ans[maxn];

struct Info{
    int t,x,yl,zl,yr,zr,op,id,coe;

    Info(){}
    Info(int _t,int _x,int _y,int _z,int _op):t(_t),x(_x),yl(_y),zl(_z),op(_op){ yr=zr=id=coe=0; }
    Info(int _t,int _x,int _yl,int _zl,int _yr,int _zr,int _op,int _id,int _coe):
        t(_t),x(_x),yl(_yl),zl(_zl),yr(_yr),zr(_zr),op(_op),id(_id),coe(_coe){}

    bool operator < (const Info& rhs) const{
        return x==rhs.x?op<rhs.op:x<rhs.x;
    }
} q[maxn<<1],tmp[maxn<<1];

int cnt,s[maxn*5];

namespace SGT{
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    struct node{
        int ls,rs,sum;
        node():ls(0),rs(0),sum(0){}
    } T[20000000];

    int cur;

    void update(int& h,int l,int r,int p,int w){
        if(!h) h=++cur;
        if(l==r) return void(T[h].sum+=w);
        if(p<=mid) update(T[h].ls,lc,p,w);
        else update(T[h].rs,rc,p,w);
        T[h].sum=T[T[h].ls].sum+T[T[h].rs].sum;
    }

    int query(int h,int l,int r,int L,int R){
        if(!h) return 0;
        if(L<=l&&r<=R) return T[h].sum;
        int ret=0;
        if(L<=mid) ret+=query(T[h].ls,lc,L,R);
        if(R>mid) ret+=query(T[h].rs,rc,L,R);
        return ret;
    }

#undef mid
#undef lc
#undef rc
}

namespace BIT{
    int rt[maxn<<2];

    void add(int p,int p0,int w){ for(;p<=s[0];p+=p&-p) SGT::update(rt[p],1,s[0],p0,w); }

    int sum(int p,int l,int r){ int ret=0; for(;p;p-=p&-p) ret+=SGT::query(rt[p],1,s[0],l,r); return ret; }
}

void solve(int L,int R){
    if(L>=R) return;

    int mid=((L+R)>>1);

    for(int i=L;i<=R;i++)
        if(q[i].op==1&&q[i].t<=mid) BIT::add(q[i].yl,q[i].zl,1);
        else if(q[i].op==2&&q[i].t>mid) ans[q[i].id]+=q[i].coe*(BIT::sum(q[i].yr,q[i].zl,q[i].zr)-BIT::sum(q[i].yl-1,q[i].zl,q[i].zr));

    for(int i=L;i<=R;i++) if(q[i].op==1&&q[i].t<=mid) BIT::add(q[i].yl,q[i].zl,-1);

    int p1=L-1,p2=mid;
    for(int i=L;i<=R;i++)
        if(q[i].t<=mid) tmp[++p1]=q[i];
        else tmp[++p2]=q[i];

    for(int i=L;i<=R;i++) q[i]=tmp[i];

    solve(L,mid); solve(mid+1,R);
}

int main(){
    freopen("b.in","r",stdin);
    freopen("b.out","w",stdout);

    read(n);

    for(int i=1;i<=n;i++){
        int op; read(op);
        if(op==1){
            int x,y,z;
            read(x);
            s[++s[0]]=read(y);
            s[++s[0]]=read(z);
            q[++cnt]=Info(cnt,x,y,z,1);
        }

        if(op==2){
            int x,y,z,x2,y2,z2;
            read(x); s[++s[0]]=read(y); s[++s[0]]=read(z);
            read(x2); s[++s[0]]=read(y2); s[++s[0]]=read(z2);
            q[++cnt]=Info(cnt,x-1,y,z,y2,z2,2,++m,-1);
            q[++cnt]=Info(cnt,x2,y,z,y2,z2,2,m,1);
        }
    }

    sort(s+1,s+s[0]+1);
    s[0]=unique(s+1,s+s[0]+1)-s-1;

    sort(q+1,q+cnt+1);

    for(int i=1;i<=cnt;i++){
        q[i].yl=lower_bound(s+1,s+s[0]+1,q[i].yl)-s;
        q[i].zl=lower_bound(s+1,s+s[0]+1,q[i].zl)-s;
        q[i].yr=lower_bound(s+1,s+s[0]+1,q[i].yr)-s;
        q[i].zr=lower_bound(s+1,s+s[0]+1,q[i].zr)-s;
    }

    solve(1,cnt);

    for(int i=1;i<=m;i++) printf("%d\n",ans[i]);

    return 0;
}
