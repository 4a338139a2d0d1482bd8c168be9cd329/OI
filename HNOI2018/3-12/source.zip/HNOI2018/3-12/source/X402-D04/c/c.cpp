#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=50010;
ll c, m;

int main(){
	freopen("c.in","r",stdin),freopen("c.out","w",stdout);

	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%lld%lld", &c, &m);
		c=(c%m+m)%m;
		int f=0;
		for(ll i=0;i<m;i++){
			if(i*i%m==c){ f=1; printf("%lld ", i);}
		}
		if(f) puts("");
		else puts("no");
	}
	return 0;
}
