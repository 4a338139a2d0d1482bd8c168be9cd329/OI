#include<bits/stdc++.h>
using namespace std;

const int maxn=20;
int n;
int a[maxn], b[maxn];
int cnt1, cnt2;

int calc(int* a,int x,int m){
	// printf("x = %d\n", x);
	// for(int i=1;i<=m;i++) printf("%d ", a[i]); puts("");
	int ret=0;
	for(int i=1;i<=m;i++){
		for(int j=i+1;j<=m;j++) if(a[i]+a[j]==x) ret++;
	}
	// printf("ret = %d\n", ret);
	return ret;
}

int main(){
	freopen("a.in","r",stdin),freopen("a.out","w",stdout);

	scanf("%d", &n);
	for(int i=0;i<(1<<(n+1));i++){
		if(!(i & (1<<1))) continue;
		cnt1=cnt2=0;
		for(int j=0;j<=n;j++) if(i & (1<<j)) a[++cnt1]=j; else b[++cnt2]=j;
		int f=1;
		// printf("%d %d\n", cnt1, cnt2);
		for(int j=1;j<=n;j++) if(calc(a,j,cnt1)!=calc(b,j,cnt2)){ f=0; break; }
		if(f){
			for(int j=1;j<=cnt1;j++) printf("%d ", a[j]); puts("");
		}
	}
	return 0;
}
