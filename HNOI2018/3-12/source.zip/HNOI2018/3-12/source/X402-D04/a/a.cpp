#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
int n;
int a[maxn], b[maxn];
int cnt1, cnt2;

int calc(int* a,int x,int m){
	// printf("x = %d\n", x);
	// for(int i=1;i<=m;i++) printf("%d ", a[i]); puts("");
	int ret=0;
	for(int i=1;i<=m;i++){
		for(int j=i+1;j<=m;j++) if(a[i]+a[j]==x) ret++;
	}
	// printf("ret = %d\n", ret);
	return ret;
}

int c[maxn], d[maxn], c1, c2;
void solve(){
	a[++c1]=1, a[++c1]=2, b[++c2]=0, b[++c2]=3;
	for(int i=4;i<=n && i+1<=n;i+=2){
		// printf("i = %d %d %d\n", i, c[i], d[i]);
		if(c[i]==d[i]){
			a[++c1]=i; b[++c2]=i+1;
			for(int j=1;j<c1;j++) if(i+a[j]<maxn) c[i+a[j]]++; 
			for(int j=1;j<c2;j++) if(i+1+b[j]<maxn) d[i+1+b[j]]++;
		}else{
			b[++c2]=i; a[++c1]=i+1;
			for(int j=1;j<c1;j++){
				if(i+1+a[j]<maxn) c[i+1+a[j]]++; 
			}
			for(int j=1;j<c2;j++) if(i+b[j]<maxn) d[i+b[j]]++;
		}
	}
	// printf("cnt = %d\n", c1);
	for(int i=1;i<=c1;i++) printf("%d ", a[i]); puts("");
	// for(int i=1;i<=c1;i++) printf("%d ", a[i]&1); puts("");
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
}

int main(){
	freopen("a.in","r",stdin),freopen("a.out","w",stdout);

	scanf("%d", &n);
	if(n>10){ solve(); return 0; }
	for(int i=0;i<(1<<(n+1));i++){
		if(!(i & (1<<1))) continue;
		cnt1=cnt2=0;
		for(int j=0;j<=n;j++) if(i & (1<<j)) a[++cnt1]=j; else b[++cnt2]=j;
		int f=1;
		// printf("%d %d\n", cnt1, cnt2);
		for(int j=1;j<=n;j++) if(calc(a,j,cnt1)!=calc(b,j,cnt2)){ f=0; break; }
		if(f){
			for(int j=1;j<=cnt1;j++) printf("%d ", a[j]); puts("");
		}
	}
	return 0;
}
