#include <bits/stdc++.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxn = 50010;
inline int lowbit (int x)
{
    return x & -x;
}
int c[maxn*9],MAX;
void add(int x,int d)
{
    while (x <= MAX)
    {
        c[x] += d;
        x += lowbit(x);
    }
}
int sum(int x)
{
    int ans = 0;
    while (x)
    {
        ans += c[x];
        x -= lowbit (x);
    }
    return ans;
}
struct Point
{
    int x,y,z;
    int kind,idx,delt;
    Point() {}
    Point(int _x,int _y,int _z,int _delt,int _kind,int _idx):
        x(_x), y(_y), z(_z), delt(_delt), kind(_kind), idx(_idx) {}

} star[maxn << 4],star3[maxn << 4];
int ans[maxn<<1];
bool cmp1(const Point &p1,const Point &p2)
{
    //return p1.x < p2.x || ((p1.x == p2.x) && (p1.idx < p2.idx) );
    return p1.x < p2.x ;
}
bool cmp2(const Point &p1,const Point &p2)
{
    return p1.y < p2.y || ((p1.y == p2.y) && (p1.idx < p2.idx) );
}
void CDQ2(int l,int r)
{
    if (l >= r)
        return;
    int mid = (l + r) >> 1;
    CDQ2(l,mid);
    CDQ2(mid+1,r);
    int j = l;
    for (int i = mid + 1; i <= r; i++)
    {
        if (star3[i].kind == 1)
        {
            for ( ; j <= mid  && (star3[j].y <= star3[i].y); j++)
            {
                if (star3[j].kind == 0)
                    add(star3[j].z,star3[j].delt);
            }
            ans[star3[i].idx] += sum(star3[i].z) * star3[i].delt;
        }
    }
    for (int i = l; i < j; i++)
    {
        if (star3[i].kind == 0)
            add(star3[i].z,-star3[i].delt);
    }
    inplace_merge(star3+l,star3+mid+1,star3+r+1,cmp2);
	// for(int i=l;i<=r;i++) printf("%d %d\n", star3[i].y, star3[i].z); puts("");
}
void CDQ1(int l,int r)
{
    if (l == r)
        return;
    int mid = (l + r) >> 1;
    CDQ1(l, mid);
    CDQ1(mid+1, r);
    int tot = 1;
    for (int j = l; j <= mid ; j++)
        if (star[j].kind == 0)
            star3[tot++] = star[j];
    for (int i = mid + 1; i <= r; i++)
    {
        if (star[i].kind == 1)
            star3[tot++] = star[i];
    }
    sort(star3+1,star3+tot,cmp1);
    CDQ2(1,tot-1);
}
int vec[maxn << 4],idx;
void hash_(int tot)
{
    sort(vec,vec+idx);
    idx = unique(vec,vec+idx) - vec;
    MAX = idx + 1;
    for (int i = 1; i <= tot; i++)
        star[i].z = lower_bound(vec,vec+idx,star[i].z) - vec + 1;
}
int main(void)
{
#ifndef ONLINE_JUDGE
    freopen("2.in","r",stdin);
	freopen("1.out","w",stdout);
#endif // ONLINE_JUDGE
    int T,Q;
        scanf ("%d",&Q);
        int tot = 1;
        int totq = 0;
        idx = 0;
        memset(c,0,sizeof (c));
        memset(ans,0,sizeof(ans));
		int ttt=0;
        for (int i = 1; i <= Q; i++)
        {
            int op,x1,y1,z1,x2,y2,z2;
            scanf ("%d",&op);
            if (op == 1)
            {
                scanf ("%d%d%d",&x1,&y1,&z1);
                star[tot] = Point(x1,y1,z1,1,0,totq);
                vec[idx++] = z1;
                ans[totq] = -1;
                tot++;
                totq++;
            }
            if (op == 2)
            {
				cerr<<++ttt<<endl;
                scanf ("%d%d%d%d%d%d",&x1,&y1,&z1,&x2,&y2,&z2);
                star[tot] = Point(x1-1, y1-1, z1-1, -1, 1, totq),  vec[idx++] = z1-1, tot++;
                star[tot] = Point(x2,   y1-1, z1-1,  1, 1, totq),  vec[idx++] = z1-1, tot++;
                star[tot] = Point(x2 ,  y2  , z1-1, -1, 1, totq),  vec[idx++] = z1-1, tot++;
                star[tot] = Point(x1-1, y2,   z1-1,  1, 1, totq),  vec[idx++] = z1-1, tot++;
                star[tot] = Point(x1-1, y2,   z2  , -1, 1, totq),  vec[idx++] = z2  , tot++;
                star[tot] = Point(x2  , y2,   z2  ,  1, 1, totq),  vec[idx++] = z2  , tot++;
                star[tot] = Point(x2  , y1-1, z2  , -1, 1, totq),  vec[idx++] = z2  , tot++;
                star[tot] = Point(x1-1, y1-1, z2  ,  1, 1, totq),  vec[idx++] = z2  , tot++;
                totq++;
            }
        }
        hash_(tot);
        CDQ1(1,tot-1);
        for (int i = 0; i < totq; i++)
            if (~ans[i])
                printf("%d\n",ans[i]);
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
    return 0;
}
