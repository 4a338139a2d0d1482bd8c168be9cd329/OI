#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
int n,m,ans[maxn];
int idx[3][maxn],idx_cnt[3];
struct data{
	int type,x,y,z,id;
	int y1,z1;
}q[maxn],q2[maxn];
int Root[maxn],tot;
struct node{
	int lc,rc,sum;
};
struct seg_tree{
	node tr[maxn*100];
	int newnode(){
		++tot;
		tr[tot].lc=tr[tot].rc=tr[tot].sum=0;
		return tot;
	}
	void update(int &p,int l,int r,int pos){
		if(!p)p=newnode();
//		cout<<"!!!"<<' '<<p<<' '<<l<<' '<<r<<' '<<pos<<endl;
		tr[p].sum++;
		if(l==r)return;
		int mid=(l+r)>>1;
		if(pos<=mid)update(tr[p].lc,l,mid,pos);
		else update(tr[p].rc,mid+1,r,pos);
	}
	int query(int &p,int l,int r,int L,int R){
		if(!p)return 0;
		int mid=(l+r)>>1,res=0;
		if((L<=l)&&(R>=r)){
//			cout<<"FUCK"<<' '<<p<<' '<<l<<' '<<r<<' '<<L<<' '<<R<<' '<<tr[p].sum<<endl;
			return tr[p].sum;
		}
		if(L<=mid)res+=query(tr[p].lc,l,mid,L,R);
		if(R>mid)res+=query(tr[p].rc,mid+1,r,L,R);
		return res;
	}
}T;
void Update(int y,int z){
//	cout<<"UPDATE"<<' '<<y<<' '<<z<<endl;
	while(y<=idx_cnt[1])
//		cout<<"----"<<y<<endl,
		T.update(Root[y],1,idx_cnt[2],z),y+=y&-y;
}
int Query(int y1,int y2,int z1,int z2){
//	cout<<y1<<' '<<y2<<' '<<z1<<' '<<z2<<' '<<endl;
	int res=0;
	while(y1)res-=T.query(Root[y1],1,idx_cnt[2],z1,z2),y1-=y1&-y1;
	while(y2)res+=T.query(Root[y2],1,idx_cnt[2],z1,z2),y2-=y2&-y2;
//	cout<<res<<endl;
	return res;
}
void Reset(int y){
	while(y<=idx_cnt[1])
		Root[y]=0,y+=y&-y;
}
void solve(int l,int r){
	if(l==r)return;
	int mid=(l+r)>>1;
	solve(l,mid),solve(mid+1,r);
	static data tmp[maxn];
	int curl=l,curr=mid+1,cur=l,cnt=0;
	while((curl<=mid)&&(curr<=r)){
		if(q[curl].x<=q[curr].x){
			tmp[cur]=q[curl];
			if(q[curl].type==1)q2[++cnt]=q[curl];
			++curl,++cur;
		}else{
			tmp[cur]=q[curr];
			if(q[curr].type!=1)q2[++cnt]=q[curr];
			++curr,++cur;
		}
	}
	while(curl<=mid){
		tmp[cur]=q[curl];
		if(q[curl].type==1)q2[++cnt]=q[curl];
		++curl,++cur;
	}
	while(curr<=r){
		tmp[cur]=q[curr];
		if(q[curr].type!=1)q2[++cnt]=q[curr];
		++curr,++cur;
	}
	REP(i,l,r)q[i]=tmp[i];
//	if(l>1||r<15)return;
//	puts("-----");
//	cout<<"l,r="<<l<<' '<<r<<endl;
	tot=0;
	REP(i,1,cnt){
//		cout<<q2[i].type<<' '<<q2[i].id<<' '<<q2[i].x<<' '<<q2[i].y<<' '<<q2[i].z<<' '<<q2[i].y1<<' '<<q2[i].z1<<' '<<Query(q2[i].y,q2[i].y1,q2[i].z,q2[i].z1)<<endl;
		if(q2[i].type==1){
			Update(q2[i].y,q2[i].z);
		}else if(q2[i].type==2){
			ans[q2[i].id]-=Query(q2[i].y,q2[i].y1,q2[i].z,q2[i].z1);
		}else{
			ans[q2[i].id]+=Query(q2[i].y,q2[i].y1,q2[i].z,q2[i].z1);
		}
	}
//	puts("-----");
	REP(i,1,cnt)if(q2[i].type==1)Reset(q2[i].y);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	freopen("b.ans","w",stdout);
#endif
	n=read();
	REP(i,1,n){
		int type=read(),x=read(),y=read(),z=read();
		if(type==1){
			idx[0][++idx_cnt[0]]=x;
			idx[1][++idx_cnt[1]]=y;
			idx[2][++idx_cnt[2]]=z;
			q[++m]=(data){1,x,y,z,i};
			ans[i]=-1;
		}else{
			int x1=read(),y1=read(),z1=read();
			q[++m]=(data){2,x,y,z,i,y1,z1};
			q[++m]=(data){3,x1,y,z,i,y1,z1};
		}
	}
	REP(i,0,2){
		sort(idx[i]+1,idx[i]+1+idx_cnt[i]);
		idx_cnt[i]=unique(idx[i]+1,idx[i]+1+idx_cnt[i])-idx[i]-1;
	}
	REP(i,1,m){
		if(q[i].type==1){
			q[i].x=lower_bound(idx[0]+1,idx[0]+1+idx_cnt[0],q[i].x)-idx[0];
			q[i].y=lower_bound(idx[1]+1,idx[1]+1+idx_cnt[1],q[i].y)-idx[1];
			q[i].z=lower_bound(idx[2]+1,idx[2]+1+idx_cnt[2],q[i].z)-idx[2];
		}else{
			if(q[i].type==2)q[i].x=lower_bound(idx[0]+1,idx[0]+1+idx_cnt[0],q[i].x)-idx[0]-1;
			else q[i].x=upper_bound(idx[0]+1,idx[0]+1+idx_cnt[0],q[i].x)-idx[0]-1;
			q[i].y=lower_bound(idx[1]+1,idx[1]+1+idx_cnt[1],q[i].y)-idx[1]-1;
			q[i].z=lower_bound(idx[2]+1,idx[2]+1+idx_cnt[2],q[i].z)-idx[2];
			q[i].y1=upper_bound(idx[1]+1,idx[1]+1+idx_cnt[1],q[i].y1)-idx[1]-1;
			q[i].z1=upper_bound(idx[2]+1,idx[2]+1+idx_cnt[2],q[i].z1)-idx[2]-1;
		}
	}
	solve(1,m);
	REP(i,1,n)
		if(ans[i]!=-1)
//			cout<<i<<' ',
			write(ans[i],'\n');
	return 0;
}
