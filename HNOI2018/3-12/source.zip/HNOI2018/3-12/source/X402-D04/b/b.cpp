#include<bits/stdc++.h>
using namespace std;

const int maxn=800010;
const int inf=1e9;
int n, m;
struct node{ 
	int x, y, z; 
	int type, delt, id;
}a[maxn], s[maxn], b[maxn];

bool cmp1(node A,node B){ return A.x<B.x || (A.x==B.x && A.id<B.id); }
bool cmp2(node A,node B){ return A.y<B.y || (A.y==B.y && A.id<B.id); }

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int num[maxn], ans[maxn], cnt;
int c[maxn];
int lowbit(int x){ return x&(-x); }
void add(int x,int val){ while(x<=cnt){ c[x]+=val; x+=lowbit(x); } }
int query(int x){
	int ret=0;
	while(x){
		ret+=c[x];
		x-=lowbit(x);
	}
	return ret;
}

void solve(int l,int r){
	if(l>=r) return;
	// cerr<<l<<' '<<r<<endl;
	int mid=(l+r)>>1;
	solve(l,mid), solve(mid+1,r);
	int t1=l, t2=mid+1;
	for(int i=l;i<=r;i++){
		if(t2>r || (t1<=mid && (s[t1].y<s[t2].y || (s[t1].y==s[t2].y && s[t1].id<s[t2].id)))){
			b[i]=s[t1++];
			if(b[i].type==0) add(b[i].z,1);
		}else{
			b[i]=s[t2++];
			if(b[i].type==1){
				ans[ b[i].id ]+=b[i].delt*query(b[i].z);
				// printf("%d ", b[i].id);
			}
		}
	}
	for(int i=l;i<=mid;i++) if(s[i].type==0) add(s[i].z,-1);
	for(int i=l;i<=r;i++) s[i]=b[i];
	// for(int i=l;i<=r;i++) printf("%d %d\n", s[i].y, s[i].z); puts("");
}

void cdq(int l,int r){
	if(l==r) return;
	int mid=(l+r)>>1;
	cdq(l,mid); cdq(mid+1,r);
	int tot=0;
	for(int i=l;i<=mid;i++) if(a[i].type==0) s[++tot]=a[i];
	for(int i=mid+1;i<=r;i++) if(a[i].type==1) s[++tot]=a[i];
	sort(s+1,s+1+tot,cmp1);
	solve(1,tot);
}

int main(){
	freopen("b.in","r",stdin),freopen("b.out","w",stdout);

	read(m);
	int op, x, y, z, x2, y2, z2;
	for(int i=1;i<=m;i++){
		read(op); read(x), read(y), read(z);
		if(op==1){
			a[++n]=(node){x,y,z,0,1,i};
			ans[i]=-inf;
			num[++cnt]=z;
		}else{
			read(x2), read(y2), read(z2);
			a[++n]=(node){x-1,y-1,z-1,1,-1,i};
			a[++n]=(node){x2 ,y-1,z-1,1, 1,i};
			a[++n]=(node){x2 ,y2 ,z-1,1,-1,i};
			a[++n]=(node){x-1,y2 ,z-1,1, 1,i};
			
			a[++n]=(node){x-1,y2 ,z2,1,-1,i};
			a[++n]=(node){x2 ,y2 ,z2,1, 1,i};
			a[++n]=(node){x2 ,y-1,z2,1,-1,i};
			a[++n]=(node){x-1,y-1,z2,1, 1,i};
			num[++cnt]=z-1; num[++cnt]=z2;
		}
	}
	// cerr<<ttt<<endl;
	sort(num+1,num+1+cnt);
	cnt=unique(num+1,num+1+cnt)-num-1;
	// printf("n = %d\n", n);
	for(int i=1;i<=n;i++){
		a[i].z=lower_bound(num+1,num+1+cnt,a[i].z)-num;
		// printf("%d ", a[i].z);
	}
	// puts("");
	cdq(1,n);
	// printf("n = %d\n", m);
	for(int i=1;i<=m;i++) if(ans[i]>=0) printf("%d\n", ans[i]);
	return 0;
}
