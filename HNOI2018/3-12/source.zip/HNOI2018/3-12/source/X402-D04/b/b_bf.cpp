#include<bits/stdc++.h>
using namespace std;

const int maxn=50010;
int n, m;
struct node{ int x, y, z; }a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int main(){
	freopen("1.in","r",stdin),freopen("b.out","w",stdout);

	read(m);
	int op, x, y, z, x2, y2, z2;
	for(int i=1;i<=m;i++){
		read(op); read(x), read(y), read(z);
		if(op==1){
			a[++n]=(node){x, y, z};
		}else{
			read(x2), read(y2), read(z2);
			int ans=0;
			for(int j=1;j<=n;j++){
				if(a[j].x>=x && a[j].x<=x2 && a[j].y>=y && a[j].y<=y2 && a[j].z>=z && a[j].z<=z2) ans++;
			}
			printf("%d\n", ans);
		}
	}
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
