#include<bits/stdc++.h>
using namespace std;

const int mod=1e6;
const int modd=1e6;
int T;

int main(){
	freopen("1.in","w",stdout);

	srand(time(0));
	printf("%d\n", T=50000);
	while(T--){
		int op=rand()&1;
		if(op==1){
			printf("1 %d %d %d\n", rand()%mod, rand()%mod, rand()%mod);
		}else{
			int x=rand()%mod, y=rand()%mod, z=rand()%mod;
			int xx=x+rand()%modd, yy=y+rand()%modd, zz=z+rand()%modd;
			printf("2 %d %d %d %d %d %d\n",x,y,z,xx,yy,zz);
		}
	}
	return 0;
}
