#include<bits/stdc++.h>
const int N=1e5+10;
using namespace std;

struct node{
	int x,y,z;
};
struct node p[N];

inline int read(){
	char ch=getchar();
	int x=0;
	while(!isdigit(ch))ch=getchar();
	while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
	return x;
}

namespace buf{
	void solve(){
		int m;
		freopen("b.in","r",stdin);
		freopen("b.out","w",stdout);
		scanf("%d",&m);
		int cnt;
		int x,y,z,x0,y0,z0,op,x1,y1,z1;
		for(int i=1; i<=m; ++i){
			scanf("%d",&op);
			if(op==1){
				x=read();y=read();z=read();
				p[++z].x=x;p[z].y=y;p[z].z=z;
			}
			if(op==2){
				x0=read();y0=read();z0=read();
				x1=read();y1=read();z1=read();
				int ret=0;
				for(int j=1;j<=z;++j){
					if(x0<=p[j].x&&p[j].x<=x1&&y0<=p[j].y&&p[j].y<=y1&&z0<=p[j].z&&p[j].z<=z1){
						++ret;
					}
				}
				printf("%d\n",ret);
			}
		}
	}
}

int main(){
	buf::solve();
}
