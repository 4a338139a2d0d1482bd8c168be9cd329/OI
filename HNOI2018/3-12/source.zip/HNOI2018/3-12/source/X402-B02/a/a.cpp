#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int n,m;
int cnta[N];
int cntb[N];
int a[N];
int b[N];
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n); m=n; 
	if(!(n & 1)) --n;
	a[1]=0; a[2]=3;
	b[1]=1; b[2]=2; cnta[3]++; cntb[3]++;
	int p = 2;
	for(int i=4; i<=2*(n/2); i+=2){
		a[++p] = i;
		b[p] = i+1;
		for(int j=1; j<p; ++j) cnta[a[p]+a[j]]++,cntb[b[p]+b[j]]++;
		int flag=1;
		for(int j=1; j<=i+1; ++j) if(cnta[j]!=cntb[j]) {flag=0; break;}
		if(!flag){
			for(int j=1; j<p; ++j) cnta[a[p]+a[j]]--,cntb[b[p]+b[j]]--;
			a[p]=i+1;
			b[p]=i;
			for(int j=1; j<p; ++j) cnta[a[p]+a[j]]++,cntb[b[p]+b[j]]++;
		}
	}
	for(int i=1; i<=p; i++) printf("%d ",b[i]); 
	if(m%2==0){
		if(cnta[m]>=cntb[m]){
			printf("%d",m);
		}
	}
}
