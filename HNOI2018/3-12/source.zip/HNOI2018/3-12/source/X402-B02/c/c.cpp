#include<bits/stdc++.h>
#define ll long logn
using namespace std;

int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int t,c,m,flag=1;
	scanf("%d",&t);
	for(int i=1; i<=t; ++i){
		scanf("%d%d",&c,&m);
		flag=0;
		for(int j=0; j<m; ++j){
			if((1ll*j*j%m-1ll*c%m+m)%m==0){
				flag=1;
				printf("%d ",j);
			}
		}
		if(flag)puts("");else puts("no");
	}
}
