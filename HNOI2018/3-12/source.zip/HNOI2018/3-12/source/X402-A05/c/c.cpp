#include <bits/stdc++.h>

int main()
{
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	int T; scanf("%d", &T);
	while (T--) {
		static int c, mod;
		scanf("%d%d", &c, &mod); c = (c % mod + mod) % mod;

		bool can = false;
		for (int x = 0; x < mod; ++x) {
			if (x * x % mod == c) {
				printf("%d ", x);
				can = true;
			}
		}
		if (can)
			printf("\n");
		else 
			printf("no\n");
	}

	return 0;
}
