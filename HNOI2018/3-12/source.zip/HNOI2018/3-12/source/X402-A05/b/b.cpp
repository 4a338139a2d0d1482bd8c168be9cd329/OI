#include <bits/stdc++.h>

//using std :: sort;
//using std :: unique;
//using std :: lower_bound;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int N = 5e4;

struct Point
{
	int sx, sy, sz, opt;
	int tx, ty, tz;
	int divid, id;
	void Input(int _opt)
	{
		opt = _opt;
		sx = read(), sy = read(), sz = read();
		if (opt == 2) {
			tx = read(); ty = read(); tz = read();
		}
	}
}P[N + 5];

int n, m, range;

namespace SubTask1
{
	void main()
	{
		for (int i = 1; i <= m; ++i) {
			if (P[i].opt == 2) {
				int ans = 0;
				for (int j = 1; j < i; ++j) {
					if (P[j].opt != 1) continue;
					if (P[i].sx <= P[j].sx && P[i].sy <= P[j].sy && P[i].sz <= P[j].sz)
						if (P[j].sx <= P[i].tx && P[j].sy <= P[i].ty && P[j].sz <= P[i].tz)
							ans ++;
				}
				printf("%d\n", ans);
			}
		}
	}
}

namespace SubTask2
{
	const int X = 20;

	int sum[X + 5][X + 5][X + 5];

	void main()
	{
		for (int c = 1; c <= m; ++c) {
			if (P[c].opt == 1) {
				sum[P[c].sx][P[c].sy][P[c].sz] ++;
			}
			else {
				int ans = 0;
				for (int x = P[c].sx; x <= P[c].tx; ++x) {
					for (int y = P[c].sy; y <= P[c].ty; ++y) {
						for (int z = P[c].sz; z <= P[c].tz; ++z)
							ans += sum[x][y][z];
					}
				}
				printf("%d\n", ans);
			}
		}
	}
}

namespace SubTask3
{
/*	int xi[N + 5], xl;
	int yi[N + 5], yl;
	int zi[N + 5], zl;
	int ans[N + 5];

	bool cmpx(const Point& a, const Point& b)
	{
		return a.x < b.x;
	}
	bool cmpy(const Point& a, const Point& b)
	{
		return a.y < b.y;
	}

	void reid(int &x, int *p, int l)
	{
		x = lower_bound(p + 1, p + l + 1, x) - p;
	}

	#define lowbit(x) (x & -x)
	int c[N + 5];
	void add(int x, int f)
	{
		for (int i = x; i <= max(yl, zl); ++i)
			c[i] += f;
	}
	int ask(int x, int ret = 0)
	{
		for (int i = x; i > 0; i -= lowbit(i)) 
			ret += c[i];
		return ret;
	}
	#undef lowbit

	void solve2(int l, int r)
	{
	}

	//deal array P (t) -> (x, y, z)
	//[l, mid], insert
	//[mid+1, r], query
	//calc the insert's influence to the query
	void sovle1(int l, int r)
	{
		if (l == r) return ;
		int mid = (l + r) >> 1, cnt(0);
		for (int i = l; i <= mid; ++i) {
			if (P[i].opt == 1) Q[++cnt] = P[i];
		}
		for (int i = mid + 1; i <= r; ++i) {
			if (P[i].opt == 2) Q[++cnt] = P[i];
		}
		sort(Q + 1, Q + cnt + 1, cmpx);
		sort(Q + l, Q + r + 1, cmpy);
		for (int i = l; i <= r; ++i) {
			if (Q[i].opt == 1) add(Q[i].sz, +1);
			else 
				ans[Q[i].id] += ask(Q[i].tz);
		}
		for (int i = l i <= r; ++i) 
			if (Q[i].opt == 1) add(Q[i].sz, -1);
		for (int i = r; i >= l; --i) {
			if (Q[i].opt == 1) add(Q[i].sz, +1);
			else 
				ans[Q[i].id] += ask(Q[i].tz);
		}

		solve1(l, mid), solve1(mid + 1, r);
	}
	*/

	void main()
	{
/*		for (int i = 1; i <= m; ++i) {
			xi[++xl] = P[i].sx; yi[++yl] = P[i].sy; zi[++zl] = P[i].sz;
			if (P[i].opt != 1) {
				xi[++xl] = P[i].tx; yi[++yl] = P[i].ty; zi[++zl] = P[i].tz;
			}
		}
		sort(xi + 1, xi + xl + 1); xl = unique(xi + 1, xi + xl + 1) - xi;
		sort(yi + 1, yi + yl + 1); yl = unique(yi + 1, yi + yl + 1) - yi;
		sort(zi + 1, zi + zl + 1); zl = unique(zi + 1, zi + zl + 1) - zi;
		for (int i = 1; i <= m; ++i) {
			reid(P[i].sx, xi, xl); reid(P[i].sy, yi, yl); reid(P[i].sz, zi, zl);
			if (P[i].opt == 2) {
				reid(P[i].tx, xi, xl); reid(P[i].ty, yi, yl); reid(P[i].tz, zi, zl);
			}
		}

		solve1(1, m);
		for (int i = 1; i <= m; ++i) {
			if (P[i].opt == 2) {
				printf("%d\n", ans[i]);
			}
		}*/
	}
}

int main()
{
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	scanf("%d", &m);
	for (int i = 1; i <= m; ++i) {
		int opt = read();
		P[i].Input(opt);
		P[i].id = i;
//		range = max(max(P[i].sx, P[i].sy), P[i].sz);
	}

	if (m <= 1000) {
		SubTask1 :: main();
	}
	else {
		SubTask2 :: main();
	}

	return 0;
}
