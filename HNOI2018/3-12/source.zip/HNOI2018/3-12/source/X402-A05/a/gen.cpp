#include <bits/stdc++.h>

int main()
{
	freopen("a.in", "w", stdout);
	srand(time(NULL));
	int n = 1ll*rand()*rand() % 7000 + 3;
	printf("%d\n", n);
	return 0;
}
