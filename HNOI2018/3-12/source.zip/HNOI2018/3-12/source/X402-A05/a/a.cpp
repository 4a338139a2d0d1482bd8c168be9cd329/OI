#include <bits/stdc++.h>

using std :: vector;

const int N = 4e5;

int n;
bool seq[N + 5];
vector<int> A, B;

int main()
{
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);

	scanf("%d", &n);

	seq[1] = 0;
	for (int l = 1; l <= n; l <<= 1) {
		for (int i = 1; i <= l; ++i)
			seq[i + l] = seq[i] ^ 1;
	}
	for (int i = 0; i < (n+1)/2; ++i) {
		A.push_back(2*i + ( seq[i+1]));
		B.push_back(2*i + (!seq[i+1]));
	}

	if (!(n & 1)) {
		if (seq[(n+1)/2+1]) B.push_back(n);
		else A.push_back(n);
	}

	for (int i = 0; i < (int)B.size(); ++i)
		printf("%d%c", B[i], i == (int)B.size()-1? '\n':' ');

	return 0;
}
