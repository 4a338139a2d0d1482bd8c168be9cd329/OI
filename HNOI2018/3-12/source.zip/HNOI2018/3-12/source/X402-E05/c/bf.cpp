#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define pll pair<LL,LL>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ft first
#define sd second
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}
int T;
LL c,m,a,w;
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%m)
		if(b&1)ret=ret*a%m;
	return ret;
}
inline pll mult(pll A,pll B)
{
	return pll((A.ft*B.ft%m+A.sd*B.sd%m*w%m)%m,(A.sd*B.ft+A.ft*B.sd)%m);
}
inline pll qpow(pll a,LL b)
{
	pll ret=pll(1,0);
	for(;b;b>>=1,a=mult(a,a))
		if(b&1)ret=mult(ret,a);
	return ret;
}
inline void Solve()
{
	while(1)
	{
		a=rand()%m;
		w=(a*a+m-c)%m;
		if(qpow(w,(m-1)>>1)==m-1)
			break;
	}
	pll ret=pll(a,1); 
	ret=qpow(ret,(m+1)>>1);
	int l=ret.ft,r=m-ret.ft;
	if(l>r)swap(l,r);
	if(l==r)printf("%lld\n",l);
	else printf("%lld %lld\n",l,r);
}
int main()
{
	file();
	read(T);
	while(T--)
	{
		read(c),read(m);
		if(m==2)
		{
			For(i,0,1)if(i*i%m==c)printf("%d ",i);
			puts("");
		}
		else
		{
			if(c==0)puts("0");
			else
			if(qpow(c,(m-1)>>1)==m-1)puts("no");
			else Solve();
		}
	}
	return 0;
}
