#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(register int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(register int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1<<18;
const LL mod=998244353;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("a.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,Base,len,rev[N];
int a[N],b[N],cnta,cntb;
LL x[N],y[N];
inline void init(int n)
{
	for(Base=1,len=0;Base<=n;Base<<=1)len++;
	For(i,1,Base-1)rev[i]=rev[i>>1]>>1|(i&1)<<(len-1);
}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void Add(LL&x,LL y){x=x+y<mod?x+y:x+y-mod;}
inline void NTT(LL *x,int Base,int flag)
{
	For(i,0,Base-1)if(i<rev[i])swap(x[i],x[rev[i]]);
	for(int K=2;K<=Base;K<<=1)
	{
		LL wn=qpow(3,mod/K);
		if(flag)wn=qpow(wn,mod-2);
		for(int M=0;M<Base;M+=K)
		{
			LL w=1,l,r,*a=x+M,*b=x+M+(K>>1);
			For(i,0,(K>>1)-1)
			{
				l=*a,r=*b*w%mod;
				Add(*a=l,r),Add(*b=l,mod-r);
				w=w*wn%mod,++a,++b;
			}
		}
	}
	if(flag)
	{
		LL inv=qpow(Base,mod-2);
		For(i,0,Base-1)x[i]=x[i]*inv%mod;
	}
}
inline void Solve()
{
	a[++cnta]=1;
	a[++cnta]=2;
	a[++cnta]=4;
	b[++cntb]=0;
	b[++cntb]=3;
	For(i,1,cnta)x[a[i]]=1;
	For(i,1,cntb)y[b[i]]=1;
	For(i,5,n)
	{
		int ret=0;
		For(j,1,cnta)
		{
			if(a[j]<<1>=i)break;
			ret+=x[i-a[j]];
		}
		For(j,1,cntb)
		{
			if(b[j]<<1>=i)break;
			ret-=y[i-b[j]];
		}
		!ret?x[a[++cnta]=i]=1:y[b[++cntb]=i]=1;
	}
	For(i,1,cnta)printf("%d ",a[i]);
}
int main()
{
	file();
	read(n);
	if(n==3)
		printf("1 2\n");
	else
	if(n==4)
		printf("1 2 4\n");
	else
		Solve();
	cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
