#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
int n,a[N],b[N],na,nb;
bool visa[N],visb[N];

void wj()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	if(n==3) {puts("1 2");return 0;}
	a[++na]=1; a[++na]=2; visa[1]=1; visa[2]=1;
	b[++nb]=0; b[++nb]=3; visb[0]=1; visb[3]=1;
	for(int i=4;i<=n;++i)
	{
		int cnta=0,cntb=0;
		for(int j=0;j<(i+1>>1);++j) if(visa[j]&&visa[i-j]) cnta++;
		for(int j=0;j<(i+1>>1);++j) if(visb[j]&&visb[i-j]) cntb++;
		if(cnta==cntb) a[++na]=i,visa[i]=1;
		else if(cnta-1==cntb) b[++nb]=i,visb[i]=1;
		else cp;
	}
	for(int i=1;i<=na;++i) printf("%d ",a[i]);
	//ln; for(int i=1;i<=nb;++i) printf("%d ",b[i]);
	/*for(int i=1;i<=na;i+=4) 
	{
		char c; int x=0;
		if(a[i]>b[i]) x|=1<<0;
		if(a[i+1]>b[i+1]) x|=1<<1;
		if(a[i+2]>b[i+2]) x|=1<<2;
		if(a[i+3]>b[i+3]) x|=1<<3;
		if(x<=9) c=x+48;
		else c=x-10+'a';
		printf("%c",c);
	}*/
	return 0;
}
