#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
int bx[N],by[N],bz[N],nx,ny,nz,m;
struct node
{
	int typ,x,y,z,x2,y2,z2;
	node(int typ=0,int x=0,int y=0,int z=0,int x2=0,int y2=0,int z2=0) :typ(typ),
	x(x),y(y),z(z),x2(x2),y2(y2),z2(z2) { }
}ask[N];
int sum[N*20],ch[N*20][9];
int qxl,qxr,qyl,qyr,qzl,qzr,rt,sz=0;
void update(int &o,int xl,int xr,int yl,int yr,int zl,int zr)
{
	if(xl>xr||yl>yr||zl>zr) return ;
	if(!o) o=++sz;
	sum[o]++;
	if(xl==xr&&yl==yr&&zl==zr) return ;
	int xmid=xl+xr>>1,ymid=yl+yr>>1,zmid=zl+zr>>1;
	if(qxl<=xmid&&qyl<=ymid&&qzl<=zmid) update(ch[o][0],xl,xmid,yl,ymid,zl,zmid);
	if(qxl<=xmid&&qyl<=ymid&&qzr>zmid) update(ch[o][1],xl,xmid,yl,ymid,zmid+1,zr);
	if(qxl<=xmid&&qyr>ymid&&qzl<=zmid) update(ch[o][2],xl,xmid,ymid+1,yr,zl,zmid);
	if(qxl<=xmid&&qyr>ymid&&qzr>zmid) update(ch[o][3],xl,xmid,ymid+1,yr,zmid+1,zr);

	if(qxr>xmid&&qyl<=ymid&&qzl<=zmid) update(ch[o][4],xmid+1,xr,yl,ymid,zl,zmid);
	if(qxr>xmid&&qyl<=ymid&&qzr>zmid) update(ch[o][5],xmid+1,xr,yl,ymid,zmid+1,zr);
	if(qxr>xmid&&qyr>ymid&&qzl<=zmid) update(ch[o][6],xmid+1,xr,ymid+1,yr,zl,zmid);
	if(qxr>xmid&&qyr>ymid&&qzr>zmid) update(ch[o][7],xmid+1,xr,ymid+1,yr,zmid+1,zr);
}
node stk[2000050]; int top=0;
int tot=0;
int query()
{
	int ans=0;
	top=0;
	stk[++top]=node(rt,1,nx,1,ny,1,nz);
	while(top)
	{
		//tot++;
		node u=stk[top]; top--;
		int o=u.typ ,xl=u.x,xr=u.y ,yl=u.z,yr=u.x2 ,zl=u.y2,zr=u.z2;
		if(xl>xr||yl>yr||zl>zr) continue;
		//if(!o) continue;
		if(qxl<=xl&&xr<=qxr&&qyl<=yl&&yr<=qyr&&qzl<=zl&&zr<=qzr) {ans+=sum[o];continue;}
		int xmid=xl+xr>>1,ymid=yl+yr>>1,zmid=zl+zr>>1;
		if(ch[o][0]&&qxl<=xmid&&qyl<=ymid&&qzl<=zmid) 
			stk[++top]=node(ch[o][0],xl,xmid,yl,ymid,zl,zmid);
		if(ch[o][1]&&qxl<=xmid&&qyl<=ymid&&qzr>zmid) 
			stk[++top]=node(ch[o][1],xl,xmid,yl,ymid,zmid+1,zr);
		if(ch[o][2]&&qxl<=xmid&&qyr>ymid&&qzl<=zmid) 
			stk[++top]=node(ch[o][2],xl,xmid,ymid+1,yr,zl,zmid);
		if(ch[o][3]&&qxl<=xmid&&qyr>ymid&&qzr>zmid) 
			stk[++top]=node(ch[o][3],xl,xmid,ymid+1,yr,zmid+1,zr);

		if(ch[o][4]&&qxr>xmid&&qyl<=ymid&&qzl<=zmid) 
			stk[++top]=node(ch[o][4],xmid+1,xr,yl,ymid,zl,zmid);
		if(ch[o][5]&&qxr>xmid&&qyl<=ymid&&qzr>zmid) 
			stk[++top]=node(ch[o][5],xmid+1,xr,yl,ymid,zmid+1,zr);
		if(ch[o][6]&&qxr>xmid&&qyr>ymid&&qzl<=zmid) 
			stk[++top]=node(ch[o][6],xmid+1,xr,ymid+1,yr,zl,zmid);
		if(ch[o][7]&&qxr>xmid&&qyr>ymid&&qzr>zmid) 
			stk[++top]=node(ch[o][7],xmid+1,xr,ymid+1,yr,zmid+1,zr);
	}
	return ans;
}

void wj()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	m=read();
	for(int i=1;i<=m;++i)
	{
		int typ=read(),x=read(),y=read(),z=read(),x2=0,y2=0,z2=0;
		bx[++nx]=x; by[++ny]=y; bz[++nz]=z;
		if(typ==2) 
		{
			x2=read(),y2=read(),z2=read();
			bx[++nx]=x2; by[++ny]=y2; bz[++nz]=z2;
		}
		ask[i]=(node){typ,x,y,z,x2,y2,z2};
	}

	sort(bx+1,bx+1+nx);
	nx=unique(bx+1,bx+1+nx)-(bx+1);
	for(int i=1;i<=m;++i)
	{
		ask[i].x=lower_bound(bx+1,bx+1+nx,ask[i].x)-bx;
		if(ask[i].typ==2) ask[i].x2=lower_bound(bx+1,bx+1+nx,ask[i].x2)-bx;
	}

	sort(by+1,by+1+ny);
	ny=unique(by+1,by+1+ny)-(by+1);
	for(int i=1;i<=m;++i)
	{
		ask[i].y=lower_bound(by+1,by+1+ny,ask[i].y)-by;
		if(ask[i].typ==2) ask[i].y2=lower_bound(by+1,by+1+ny,ask[i].y2)-by;
	}

	sort(bz+1,bz+1+nz);
	nz=unique(bz+1,bz+1+nz)-(bz+1);
	for(int i=1;i<=m;++i)
	{
		ask[i].z=lower_bound(bz+1,bz+1+nz,ask[i].z)-bz;
		if(ask[i].typ==2) ask[i].z2=lower_bound(bz+1,bz+1+nz,ask[i].z2)-bz;
	}

	for(int i=1;i<=m;++i)
	{
		if(ask[i].typ==1) 
		{
			qxl=ask[i].x; qyl=ask[i].y; qzl=ask[i].z;
			qxr=ask[i].x; qyr=ask[i].y; qzr=ask[i].z;
			update(rt,1,nx,1,ny,1,nz);
		}
		else
		{
			qxl=ask[i].x; qyl=ask[i].y; qzl=ask[i].z;
			qxr=ask[i].x2; qyr=ask[i].y2; qzr=ask[i].z2;
			printf("%d\n",query());
		}
	}
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	//cerr<<tot<<endl;
	return 0;
}
