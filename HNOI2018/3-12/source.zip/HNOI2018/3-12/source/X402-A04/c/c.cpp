#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=20050;
inline ll qpow(ll a,int n,int mod)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
void exgcd(int a,int b,int &x,int &y)
{
	if(!b) {x=1;y=0;return ;}
	exgcd(b,a%b,y,x); y-=a/b*x;
}
int divi[N],tot=0;
bool isg(int g,int m)
{
	for(int i=1;i<=tot;++i) if(qpow(g,divi[i],m)==1) return 0;
	return 1;
}
int mp[100000051];
int BSGS(int g,int c,int mod)
{
	int n=sqrt(mod),inv,mul=1,ans=-1;
	for(int i=0;i<n;++i)
	{
		mp[mul]=i+1;
		mul=1ll*mul*g%mod;
	}
	inv=qpow(qpow(g,n,mod),mod-2,mod);
	mul=c;
	for(int i=0;i*n<mod;++i)
	{
		if(mp[mul]) {ans=i*n+mp[mul]-1;break;}
		mul=1ll*mul*inv%mod;
	}
	mul=1;
	for(int i=0;i<n;++i)
	{
		mp[mul]=0;
		mul=1ll*mul*g%mod;
	}
	return ans;
}


void wj()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}
int main()
{
	wj();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		//if(cas%100==0) cerr<<cas<<endl;
		int c=read(),m=read();
		c=(c%m+m)%m;
		if(!c) {puts("0");continue;}
		if(m<=50)
		{
			bool can=0;
			for(int i=0;i<m;++i) if(1ll*i*i%m==c) printf("%d ",i),can=1;
			if(!can) printf("no");
			printf("\n");
			continue;
		}
		tot=0;
		for(int i=2;i*i<=m-1;++i) if(!((m-1)%i))
		{
			divi[++tot]=i;
			if(i*i!=m-1) divi[++tot]=(m-1)/i;
		}
		int g=0;
		for(int i=1;i<m;++i) if(isg(i,m)) {g=i;break;}
		int b=BSGS(g,c,m);
		if(b==-1||b%2==1) {puts("no");continue;}
		int y=0,K=0;
		exgcd(2,m-1,y,K);
		y=1ll*y*(b/2)%(m-1);
		int x1=qpow(g,y,m),x2=m-x1;
		if(x1>x2) swap(x1,x2);
		printf("%d %d \n",x1,x2);
	}
	return 0;
}
