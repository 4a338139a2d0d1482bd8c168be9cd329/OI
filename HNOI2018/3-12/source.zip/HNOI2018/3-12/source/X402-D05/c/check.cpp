#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	return 0;
}
