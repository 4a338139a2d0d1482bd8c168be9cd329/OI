#include<bits/stdc++.h>
using namespace std;
long long md,c;
long long powd(long long x,long long y,long long p){
	long long res=1;
	while(y){
		if(y&1) res=res*x%p;
		x=x*x%p;
		y>>=1;
	}
	return res;
}
struct node{
	long long r,i,w;
	void print(){
		printf("%lld+%lldi\n",r,i);
	}
};
node operator * (const node &A,const node &B){
	node res;
	res.w=A.w;
	res.r=(A.r*B.r%md+A.i*B.i%md*A.w)%md;
	res.i=(A.r*B.i+A.i*B.r)%md;
	return res;
}
node powd(node x,long long y){
	node res=(node){1,0,x.w};
	while(y){
		if(y&1) res=res*x;
		x=x*x;
		y>>=1;
	}
	return res;
}
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0));
	int T;
	scanf("%d",&T);
	long long x;
	while(T--){
		scanf("%lld%lld",&c,&md);
		if(c<0) c=md-((-c)%md);
		c%=md;
		if(md==2){
			if(c==1)
				printf("1\n");
			else
				printf("0\n");
			continue;
		}
		if(powd(c,(md-1)/2,md)==md-1){
			printf("no\n");
			continue;
		}
		if(c==0){
			printf("0\n");
			continue;
		}
		x=rand()%md;
		while(powd((x*x-c+md)%md,(md-1)/2,md)!=md-1)
			x=rand()%md;
		node st;
		st.r=x,st.i=md-1,st.w=(x*x-c+md)%md;
		st=powd(st,(md+1)/2);
		if(st.r<md-st.r)
			printf("%lld %lld\n",st.r,md-st.r);
		else
			printf("%lld %lld\n",md-st.r,st.r);
	}
	return 0;
}
