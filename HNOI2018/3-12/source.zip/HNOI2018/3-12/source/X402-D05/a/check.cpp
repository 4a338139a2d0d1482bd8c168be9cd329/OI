#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
int n=100000;
int a[maxn],b[maxn];
int numa,numb;
int cnta[maxn],cntb[maxn];
bool vis[maxn];
int main(){
	freopen("a.in","r",stdin);
	scanf("%d",&n);
	fclose(stdin);
	freopen("a.out","r",stdin);
	while(scanf("%d",&b[++numb])!=EOF)
		vis[b[numb]]=1;
	numb--;
	for(int i=0;i<=n;i++)
		if(!vis[i])
			a[++numa]=i;
	for(int i=1;i<=numb;i++)
		for(int j=1;j<=numb;j++){
			if(i==j) continue;
			cntb[b[i]+b[j]]++;
		}
	for(int i=1;i<=numa;i++)
		for(int j=1;j<=numa;j++){
			if(i==j) continue;
			cnta[a[i]+a[j]]++;
		}
	for(int i=1;i<=n;i++)
		if(cnta[i]!=cntb[i]){
			cerr<<i<<endl;
			printf("fuck\n");
			return 0;
		}
	printf("ok.\n");
	return 0;
}
