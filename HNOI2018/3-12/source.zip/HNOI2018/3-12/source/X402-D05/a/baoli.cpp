#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
int cnta[maxn],cntb[maxn];
int a[maxn],b[maxn];
int numa,numb;
bool vis[maxn];
void Adda(int x){
	for(int i=0;i<=numa;i++)
		cnta[a[i]+x]++;
	a[++numa]=x;
}
void Addb(int x){
	vis[x]=1;
	for(int i=1;i<=numb;i++)
		cntb[b[i]+x]++;
	b[++numb]=x;
}
int main(){
	freopen("a.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		if(cnta[i]==cntb[i])
			Addb(i);
		else
			Adda(i);
	}
	for(int i=1;i<=numb;i++)
		printf("%d ",b[i]);
	printf("\n");
	return 0;
}
