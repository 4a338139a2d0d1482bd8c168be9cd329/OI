#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxv=1e9;
void solve(){
	int n=50000;
	printf("%d\n",n);
	int op;
	int x,y,z,xx,yy,zz;
	for(int i=1;i<=n;i++){
		op=(i>(n/2))+1;
		if(op==1){
			x=rand()%maxv,y=rand()%maxv,z=rand()%maxv;
			printf("%d %d %d %d\n",op,x,y,z);
		}
		else{
			x=rand()%maxv,y=rand()%maxv,z=rand()%maxv;
			xx=rand()%maxv,yy=rand()%maxv,zz=rand()%maxv;
			if(x>xx) swap(x,xx);
			if(y>yy) swap(y,yy);
			if(z>zz) swap(z,zz);
			printf("%d %d %d %d %d %d %d\n",op,x,y,z,xx,yy,zz);
		}
	}
}
int main(){
	srand(time(0)+getx());
	freopen("b.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
