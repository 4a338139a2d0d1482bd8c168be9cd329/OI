#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
const int maxv=1e9;
int n;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
void chkmin(int &x,int y){
	x=x<y?x:y;
}
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
struct point{
	int x,y,z;
};
struct node{
	int x,y,z,xx,yy,zz,v;
	int l,r;
}tr[maxn*60];
struct Range{
	int x,y,z,xx,yy,zz;
	int midx(){
		return (x+xx)/2;
	}
	int midy(){
		return (y+yy)/2;
	}
	int midz(){
		return (z+zz)/2;
	}
	void print(){
		printf("[%d,%d] [%d,%d] [%d,%d]\n",x,xx,y,yy,z,zz);
	}
}ls;
int num;
int newnode(const point &st){
	num++;
	tr[num].x=tr[num].xx=st.x;
	tr[num].y=tr[num].yy=st.y;
	tr[num].z=tr[num].zz=st.z;
	return num;
}
void chk(int h,const point &st){
	chkmin(tr[h].x,st.x),chkmax(tr[h].xx,st.x);
	chkmin(tr[h].y,st.y),chkmax(tr[h].yy,st.y);
	chkmin(tr[h].z,st.z),chkmax(tr[h].zz,st.z);
}
void Insert(int dr,int &h,const point &st){
	if(!h)
		h=newnode(st);
	else chk(h,st);
	tr[h].v++;
	if(ls.x==ls.xx&&ls.y==ls.yy&&ls.z==ls.zz) return;
	if(dr==0){
		if(st.x<=ls.midx()){
			ls.xx=ls.midx();
			Insert(1,tr[h].l,st);
		}
		else{
			ls.x=ls.midx()+1;
			Insert(1,tr[h].r,st);
		}
	}
	else if(dr==1){
		if(st.y<=ls.midy()){
			ls.yy=ls.midy();
			Insert(2,tr[h].l,st);
		}
		else{
			ls.y=ls.midy()+1;
			Insert(2,tr[h].r,st);
		}
	}
	else{
		if(st.z<=ls.midz()){
			ls.zz=ls.midz();
			Insert(0,tr[h].l,st);
		}
		else{
			ls.z=ls.midz()+1;
			Insert(0,tr[h].r,st);
		}
	}
}
int Query(int dr,int h,const Range &st){
	if(!h||!tr[h].v) return 0;
	if(st.xx<tr[h].x||st.x>tr[h].xx) return 0;
	if(st.yy<tr[h].y||st.y>tr[h].yy) return 0;
	if(st.zz<tr[h].z||st.z>tr[h].zz) return 0;
	if(st.xx>=tr[h].xx&&st.x<=tr[h].x&&
	   st.yy>=tr[h].yy&&st.y<=tr[h].y&&
	   st.zz>=tr[h].zz&&st.z<=tr[h].z) return tr[h].v;
	return Query((dr+1)%3,tr[h].l,st)+Query((dr+1)%3,tr[h].r,st);
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d",&n);
	point st;
	Range stt;
	int op,rt=0;
	for(int i=1;i<=n;i++){
		scanf("%d",&op);
		if(op==1){
			readl(st.x),readl(st.y),readl(st.z);
			ls.x=0,ls.y=0,ls.z=0;
			ls.xx=maxv,ls.yy=maxv,ls.zz=maxv;
			Insert(0,rt,st);
		}
		else{
			ls.x=0,ls.y=0,ls.z=0;
			ls.xx=maxv,ls.yy=maxv,ls.zz=maxv;
			readl(stt.x),readl(stt.y),readl(stt.z),readl(stt.xx),readl(stt.yy),readl(stt.zz);
			printf("%d\n",Query(0,rt,stt));
		}
	}
	return 0;
}
