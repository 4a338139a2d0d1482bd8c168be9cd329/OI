#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
#define mid ((l+r)>>1)
int opera[maxn];
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
struct node{
	int op,x,y,z,xx,yy,zz,id;
	void Readl(){
		scanf("%d",&op);
		if(op==1)
			readl(x),readl(y),readl(z);
		else
			readl(x),readl(y),readl(z),readl(xx),readl(yy),readl(zz);
	}
}a[maxn];
int ans[maxn];
struct Tree{
	int l,r,v;
}tr[maxn*200];
int num,n;
int newnode(){
	num++;
	tr[num].l=tr[num].r=tr[num].v=0;
	return num;
}
int rt[maxn];
void Insert(int &h,int l,int r,int p){
	if(!h) h=newnode();
	tr[h].v++;
	if(l==r) return;
	if(p<=mid) Insert(tr[h].l,l,mid,p);
	else Insert(tr[h].r,mid+1,r,p);
}
int Query(int h,int l,int r,int s,int t){
	if(!h) return 0;
	if(s<=l&&r<=t) return tr[h].v;
	if(t<=mid) return Query(tr[h].l,l,mid,s,t);
	else if(s>mid) return Query(tr[h].r,mid+1,r,s,t);
	else
		return Query(tr[h].l,l,mid,s,mid)+Query(tr[h].r,mid+1,r,mid+1,t);
}
void Insert(int x,int y){
	while(x<=n){
		Insert(rt[x],1,n,y);
		x+=x&(-x);
	}
}
int Query(int x,int y,int yy){
	int res=0;
	while(x){
		res+=Query(rt[x],1,n,y,yy);
		x-=x&(-x);
	}
	return res;
}
void clear(int x){
	while(x<=n){
		rt[x]=0;
		x+=x&(-x);
	}
}
void CDQ(int l,int r){
	if(l==r) return;
	CDQ(l,mid),CDQ(mid+1,r);
	static node b[maxn];
	int p1=l,p2=mid+1;
	int cnt=0;
	num=0;
	while(p1<=mid||p2<=r){
		if(p2>r||(p1<=mid&&a[p1].z<a[p2].z)){
			if(a[p1].op==1)
				Insert(a[p1].x,a[p1].y);
			b[++cnt]=a[p1];
			p1++;
		}
		else{
			if(a[p2].op==2)
				ans[a[p2].id]+=Query(a[p2].x,a[p2].y,a[p2].yy)-Query(a[p2].xx,a[p2].y,a[p2].yy);
			b[++cnt]=a[p2];
			p2++;
		}
	}
	for(int i=l;i<=mid;i++)
		clear(a[i].x);
	for(int i=1;i<=cnt;i++)
		a[l+i-1]=b[i];
}
int main(){
	freopen("b.in","r",stdin);
	static int b[maxn];
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		a[i].Readl();
		a[i].id=i;
		opera[i]=a[i].op;
	}
	int cnt;
	cnt=0;
	for(int i=1;i<=n;i++)
		b[++cnt]=a[i].x;
	for(int i=1;i<=n;i++)
		a[i].x=lower_bound(b+1,b+cnt+1,a[i].x)-b;

	cnt=0;
	for(int i=1;i<=n;i++)
		b[++cnt]=a[i].y;
	for(int i=1;i<=n;i++)
		a[i].y=lower_bound(b+1,b+cnt+1,a[i].y)-b;
	CDQ(1,n);
	for(int i=1;i<=n;i++)
		if(opera[i]==2)
			printf("%d\n",ans[i]);
	return 0;
}
