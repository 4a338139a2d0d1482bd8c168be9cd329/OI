#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;

int n, m, p, q;
struct Point {
    int x, y, z, ti, ty, id;
    Point(int _x = 0, int _y = 0, int _z = 0, int _ti = 0, int _ty = 0, int _id = 0): 
        x(_x), y(_y), z(_z), ti(_ti), ty(_ty), id(_id) { }
};

bool cmp1(const Point& a, const Point& b) { return a.x < b.x || (a.x == b.x && a.ty < b.ty); }
bool cmp2(const Point& a, const Point& b) { return a.y < b.y || (a.y == b.y && a.ty < b.ty); }
bool cmp3(const Point& a, const Point& b) { return a.z < b.z || (a.z == b.z && a.ty < b.ty); }
bool cmp4(const Point& a, const Point& b) { return a.ti < b.ti; }

Point P[N + 5];
typedef std::bitset<N/2 + 5> bset;
bset ans[N + 5], anscur[N + 5], cur;

int main() {
    freopen("b.in", "r", stdin);
    freopen("b.out", "w", stdout);

    read(m);
    for(int i = 1; i <= m; ++i) {
        static int op, x, y, z, x1, y1, z1;
        read(op); read(x); read(y); read(z);

        if(op == 1) {
            ++ p;
            P[++ n] = Point(x, y, z, i, 0, p);
        } else {
            ++ q;
            read(x1), read(y1), read(z1);

            if(x > x1 || y > y1 || z > z1) {
                continue;
            }

            P[++ n] = Point(x, y, z, i, -1, q);
            P[++ n] = Point(x1, y1, z1, i, +1, q);
        }
    }

    cur.reset(); std::sort(P + 1, P + n + 1, cmp1);
    for(int i = 1; i <= n; ++i) if(P[i].ty == 0) cur[P[i].id] = 1; else anscur[P[i].id] ^= cur;
    for(int i = 1; i <= q; ++i) { ans[i] = anscur[i]; anscur[i].reset(); }

    cur.reset(); std::sort(P + 1, P + n + 1, cmp2);
    for(int i = 1; i <= n; ++i) if(P[i].ty == 0) cur[P[i].id] = 1; else anscur[P[i].id] ^= cur;
    for(int i = 1; i <= q; ++i) { ans[i] &= anscur[i]; anscur[i].reset(); }

    cur.reset(); std::sort(P + 1, P + n + 1, cmp3);
    for(int i = 1; i <= n; ++i) if(P[i].ty == 0) cur[P[i].id] = 1; else anscur[P[i].id] ^= cur;
    for(int i = 1; i <= q; ++i) { ans[i] &= anscur[i]; anscur[i].reset(); }

    cur.reset(); std::sort(P + 1, P + n + 1, cmp4);
    for(int i = 1; i <= n; ++i) if(P[i].ty == 0) cur[P[i].id] = 1; else if(P[i].ty == 1) anscur[P[i].id] ^= cur;
    for(int i = 1; i <= q; ++i) ans[i] &= anscur[i], printf("%lu\n", ans[i].count());

    return 0;
}
