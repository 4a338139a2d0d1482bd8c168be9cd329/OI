#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;

int n, m;

struct Point {
    int x, y, z;
    Point(int _x = 0, int _y = 0, int _z = 0): x(_x), y(_y), z(_z){ }

    inline bool operator <= (const Point& rhs) const {
        return x <= rhs.x && y <= rhs.y && z <= rhs.z;
    }
};

Point P[N + 5];
int cnt[25][25][25];

int main() {
    freopen("b.in", "r", stdin);
    freopen("b.ans", "w", stdout);

    read(m);

    if(m <= 1000) {
        for(int i = 1; i <= m; ++ i) {
            static Point l, r;
            static int op, x, y, z, x2, y2, z2;

            read(op), read(x), read(y), read(z);
            if(op == 2) read(x2), read(y2), read(z2);

            if(op == 1) {
                P[++ n] = Point(x, y, z);
            } else {
                int ans = 0;
                l = Point(x, y, z), r = Point(x2, y2, z2);
                for(int j = 1; j <= n; ++j) ans += ((l <= P[j]) && (P[j] <= r));
                printf("%d\n", ans);
            }
        }
    } else {
        while(m--) {
            static int op, x, y, z, x2, y2, z2;

            read(op), read(x), read(y), read(z);
            if(op == 2) read(x2), read(y2), read(z2);

            if(op == 1) {
                ++ cnt[x][y][z];
            } else {
                int ans = 0;
                for(int i = x; i <= x2; ++i) 
                    for(int j = y; j <= y2; ++j) 
                        for(int k = z; k <= z2; ++k) ans += cnt[i][j][k];
                printf("%d\n", ans);
            }
        }
    }

    return 0;
}
