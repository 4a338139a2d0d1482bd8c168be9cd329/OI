#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

int t, c, m;
int fpm(int x, int y, int mo) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1)
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

int main() {
    freopen("c.in", "r", stdin);
    freopen("c.out", "w", stdout);

    read(t);
    while(t--) {
        read(c), read(m);
        c = (c % m + m) % m;

        vector<int> ans;

        if(m % 4 == 3) {
            int x = fpm(c, ((m-1)/2+1)/2, m), x0 = m - x;
            if(1ll * x * x % m == c) ans.pb(x), ans.pb(x0);
        } else {
            for(int i = 0; i < m; ++i) {
                if(1ll * i * i % m == c) ans.pb(i);
            }
        }

        if(!ans.size()) {
            puts("no");
        } else {
            for (int i = 0; i < (int) ans.size(); ++i) {
                printf("%d ", ans[i]);
            }
            puts("");
        }
    }

    return 0;
}
