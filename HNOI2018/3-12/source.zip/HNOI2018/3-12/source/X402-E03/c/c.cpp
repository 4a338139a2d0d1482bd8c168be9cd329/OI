#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
LL n, m, c ;
int main() {
	freopen ( "c.in", "r", stdin ) ;
	freopen ( "c.out", "w", stdout ) ;
	
	LL _, i ;
	bool fg ;
	Read(_) ;
	while (_--) {
		Read(c), Read(m) ;
		c = (m+c)%m ;
		fg = 1 ;
		for ( i = 0 ; i < m ; i ++ )
			if (i*i%m == c) printf ( "%lld ", i ), fg = 0 ;
		if (fg) puts("no") ;
		else puts("") ;
	}
	return 0 ;
}
