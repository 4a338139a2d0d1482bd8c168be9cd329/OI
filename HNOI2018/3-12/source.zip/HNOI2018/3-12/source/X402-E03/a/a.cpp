#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 12 ;
int n, S ;
bool v[2][maxn] ;
void calc ( int x ) {
	int i, j, val, c1 = 0, c2 = 0 ;
	for ( i = 0 ; i <= n ; i ++, x >>= 1 ) {
		v[0][i] = x&1 ;
		v[1][i] = (x&1)^1 ;
	}
	for ( i = 0 ; i <= n ; i ++ ) {
		c1 = c2 = 0 ;
		for ( j = 0 ; j <= i ; j ++ ) {
			val = i-j ;
			if (val ^ j) {
				c1 += v[0][j]&v[0][val] ;
				c2 += v[1][j]&v[1][val] ;
			}
		}
		if (c1 ^ c2) return ;
	}
	c1 = v[0][1]?0:1 ;
	for ( i = 0 ; i <= n ; i ++ )
		if (v[c1][i]) printf ( "%d ", i ) ;
	exit(0) ;
}
int main() {
	freopen ( "a.in", "r", stdin ) ;
	freopen ( "a.out", "w", stdout ) ;
	Read(n) ;
	S = (1<<(n+1))-1 ;
	for ( int i = 0 ; i <= S ; i ++ )
		calc(i) ;
	return 0 ;
}
