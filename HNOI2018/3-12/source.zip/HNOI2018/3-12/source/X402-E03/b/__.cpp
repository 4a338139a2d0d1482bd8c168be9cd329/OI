#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 5e4+5 ;
struct node {
	int t, x, y, z, tp, id ;
	void check() {
		printf ( "t=%d (%d,%d,%d) tp=%d id=%d\n", t, x, y, z, tp, id ) ;
	}
} s[maxn*16], a[maxn*16] ;
int n, m, ans[maxn], b[maxn*16] ;
int tree[maxn*100], ch[maxn*100][2], tot ;
int rt[maxn], Maxx, Maxy, Maxz ;
bool vis[maxn] ;
#define L ch][0
#define R ch][1
void push_up ( int x ) {
	tree[x] = 0 ;
	if (x[L]) {
		tree[x] += x[L][tree] ;
		if (!x[L][tree]) x[L] = 0 ;
	}
	if (x[R]) {
		tree[x] += x[R][tree] ;
		if (!x[R][tree]) x[R] = 0 ;
	}
}
int insert ( int l, int r, int x, int v ) {
	//printf ( "insert [%d,%d] [%d] [%d]\n", l, r, x, v ) ;
	int h = ++tot ;
	if (l == r) {
		tree[h] = v ;
		return h ;
	}
	int mid = (l+r)>>1 ;
	if (x <= mid) {
		h[L] = insert(l, mid, x, v) ;
		h[R] = 0 ;
	} else {
		h[R] = insert(mid+1, r, x, v) ;
		h[L] = 0 ;
	}
	push_up(h) ;
	return h ;
}
int Query ( int h, int l, int r, int x, int y ) {
	if (!h) return 0 ;
	if (x <= l && r <= y) return tree[h] ;
	int mid = (l+r)>>1 ;
	if (y <= mid) return Query(h[L], l, mid, x, y) ;
	else if (x > mid) return Query(h[R], mid+1, r, x, y) ;
	else return Query(h[L], l, mid, x, mid)+Query(h[R], mid+1, r, mid+1, y) ;
}
void Update ( int h, int l, int r, int x, int v ) {
	//printf ( "UPDATE %d [%d,%d] [%d] %d\n", h, l, r, x, v ) ;
	if (l == r) {
		tree[h] += v ;
		return ;
	}
	int mid = (l+r)>>1 ;
	if (x <= mid) {
		if (h[L]) Update(h[L], l, mid, x, v) ;
		else h[L] = insert(l, mid, x, v) ;
	} else {
		if (h[R]) Update(h[R], mid+1, r, x, v) ;
		else h[R] = insert(mid+1, r, x, v) ;
	}
	push_up(h) ;
}

void Update ( int x, int p, int v ) {
	for ( ; x <= Maxy ; x += (x&-x) )
		Update(rt[x], 1, Maxz, p, v) ;
}
int Query ( int x, int p, int rec = 0 ) {
	for ( ; x ; x -= (x&-x) )
		rec += Query(rt[x], 1, Maxz, 1, p) ;
	return rec ;
}
void Merge ( int l, int r ) {
	int mid = (l+r)>>1, t1, t2, i ;
	for ( t1 = l, t2 = mid+1, i = l ; i <= r ; i ++ ) {
		if (t2 > r || (t1 <= mid && s[t1].x <= s[t2].x)) a[i] = s[t1 ++] ;
		else a[i] = s[t2 ++] ;
	}
	for ( i = l ; i <= r ; i ++ )
		s[i] = a[i] ;
}
void solve ( int l, int r ) {
	if (l == r) return ;
	int val, i, mid = (l+r)>>1 ;
	solve(l, mid), solve(mid+1, r) ;
	Merge(l, r) ;
	//printf ( "solve [%d,%d]\n", l, r ) ;
	for ( i = l ; i <= r ; i ++ ) {
		//s[i].check() ;
		if (s[i].t <= mid && s[i].tp == 0) {
			Update(s[i].y, s[i].z, 1) ;
			//printf ( "Update %d %d\n", s[i].y, s[i].z ) ;
		}
		else if (s[i].t > mid && s[i].tp != 0) {
			val = Query(s[i].y, s[i].z) ;
			ans[s[i].id] += s[i].tp*val ;
			//printf ( "Get %d\n", val ) ;
		}
	}
	for ( i = l ; i <= r ; i ++ )
		if (s[i].t <= mid && s[i].tp == 0)
			Update(s[i].y, s[i].z, -1) ;
	tot = Maxy+1 ;
	memset (ch, 0, sizeof ch), memset (tree, 0, sizeof tree) ;
	memset (rt, 0, sizeof rt) ; tot = 0 ;
}

int main() {
	freopen ( "b.in", "r", stdin ) ;
	freopen ( "b.out", "w", stdout ) ;
	int i, op, _, t, x1, x2, y1, y2, z1, z2 ;
	Read(_) ;
	for ( t = 1 ; t <= _ ; t ++ ) {
		Read(op) ;
		if (op == 1) {
			vis[t] = 0 ;
			Read(x1), Read(y1), Read(z1) ;
			s[++n] = (node){n, x1, y1, z1, 0, t} ;
		} else {
			vis[t] = 1 ;
			Read(x2), Read(y2), Read(z2) ;
			Read(x1), Read(y1), Read(z1) ;
			s[++n] = (node){n, x1, y1, z1, 1, t} ;
			s[++n] = (node){n, x2-1, y1, z1, -1, t} ;
			s[++n] = (node){n, x1, y2-1, z1, -1, t} ;
			s[++n] = (node){n, x1, y1, z2-1, -1, t} ;
			s[++n] = (node){n, x2-1, y2-1, z1, 1, t} ;
			s[++n] = (node){n, x2-1, y1, z2-1, 1, t} ;
			s[++n] = (node){n, x1, y2-1, z2-1, 1, t} ;
			s[++n] = (node){n, x2-1, y2-1, z2-1, -1, t} ;
		}
	}

	//for ( i = 1 ; i <= n ; i ++ ) s[i].check() ;

	for ( Maxx = 0, i = 1 ; i <= n ; i ++ )
		b[++Maxx] = s[i].x ;
	sort(b+1, b+Maxx+1) ;
	Maxx = unique(b+1, b+Maxx+1)-b-1 ;
	for ( i = 1 ; i <= n ; i ++ )
		s[i].x = lower_bound(b+1, b+Maxx+1, s[i].x)-b ;

	for ( Maxy = 0, i = 1 ; i <= n ; i ++ )
		b[++Maxy] = s[i].y ;
	sort(b+1, b+Maxy+1) ;
	Maxy = unique(b+1, b+Maxy+1)-b-1 ;
	for ( i = 1 ; i <= n ; i ++ )
		s[i].y = lower_bound(b+1, b+Maxy+1, s[i].y)-b ;

	for ( Maxz = 0, i = 1 ; i <= n ; i ++ )
		b[++Maxz] = s[i].z ;
	sort(b+1, b+Maxz+1) ;
	Maxz = unique(b+1, b+Maxz+1)-b-1 ;
	for ( i = 1 ; i <= n ; i ++ )
		s[i].z = lower_bound(b+1, b+Maxz+1, s[i].z)-b ;

	//printf ( "Max=(%d,%d,%d)\n", Maxx, Maxy, Maxz ) ;
	//for ( i = 1 ; i <= n ; i ++ ) s[i].check() ;
	//puts("") ;

	for ( i = 1 ; i <= Maxy ; i ++ )
		rt[i] = i ;
	solve(1, n) ;
	for ( i = 1 ; i ^ t ; i ++ )
		if (vis[i]) printf ( "%d\n", ans[i] ) ;
	return 0 ;
}
