#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 5e4+5 ;
struct node {
	int x, y, z ;
	friend bool operator <= ( node A, node B ) {
		return A.x<=B.x && A.y<=B.y && A.z<=B.z ;
	}
} s[maxn], A, B ;
int n, m, b[maxn], t, g[30][30][30] ;
int main() {
	freopen ( "b.in", "r", stdin ) ;
	freopen ( "b.out", "w", stdout ) ;

	int _, op, i, cnt ;
	Read(_) ;
	if (_ <= 1000) {
		while (_--) {
			Read(op) ;
			if (op == 1) {
				++ m ;
				Read(s[m].x), Read(s[m].y), Read(s[m].z) ;
			} else {
				Read(A.x), Read(A.y), Read(A.z) ;
				Read(B.x), Read(B.y), Read(B.z) ;
				cnt = 0 ;
				for ( i = 1 ; i <= m ; i ++ )
					if (A <= s[i] && s[i] <= B)
						++ cnt ;
				printf ( "%d\n", cnt ) ;
			}
		}
	} else {
		int x, y, z ;
		int x1, x2, y1, y2, z1, z2 ;
		while (_--) {
			Read(op) ;
			if (op == 1) {
				Read(x), Read(y), Read(z) ;
				++g[x][y][z] ;
			} else {
				Read(x1), Read(y1), Read(z1) ;
				Read(x2), Read(y2), Read(z2) ;
				cnt = 0 ;
				for ( x = x1 ; x <= x2 ; x ++ )
					for ( y = y1 ; y <= y2 ; y ++ )
						for ( z = z1 ; z <= z2 ; z ++ )
							cnt += g[x][y][z] ;
				printf ( "%d\n", cnt ) ;
			}
		}
	}
	return 0 ;
}
