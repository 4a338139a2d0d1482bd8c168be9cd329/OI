#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int mina()
{
	int c=read(),m=read(),fl=0;
	for(int i=0;i<m;i++)
		if(((i*i-c)%m+m)%m==0)
			printf("%d ",i),fl=1;
	if(!fl)
		puts("no");
	else
		puts("");
	return 0;
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);

	for(int T=read();T;T--)
		mina();

	return 0;
}
