#include<bits/stdc++.h>
using namespace std;

int n;
int stk[100000],top;
int stks[100000],tops;
int pack[200000],packs[200000];

inline int r(int n,int *s,int top)
{
	int ret=0;
	for(int i=1;i<=top;i++)
		for(int j=i+1;j<=top;j++)
			if(s[i]+s[j]==n)
				ret++;
	return ret;
}

inline bool judge()
{
	for(int i=1;i<=n;i++)
		if(r(i,stk,top)!=r(i,stks,tops))
			return false;
	return true;
}

inline void write(int x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);

	scanf("%d",&n);

	stks[++tops]=0;
	for(int i=1;i<=n;i++)
	{
		//cerr<<i<<endl;
		if(pack[i]==packs[i])
		{
			stk[++top]=i;
			for(int j=1;j<top && stk[j]+i<=n;j++)
				pack[stk[j]+i]++;
		}
		else
		{
			stks[++tops]=i;
			for(int j=1;j<tops && stks[j]+i<=n;j++)
				packs[stks[j]+i]++;
		}
	}
	cerr<<clock()<<endl;

	//printf("%d\n",judge());

	int mx=3;
	for(int i=1;i<=top;i++)
	{
		write(stk[i]),putchar(' ');
		mx=min(mx,stk[i]-stk[i-1]);
	}
	puts("");
	printf("%d %d\n",mx,top);
	return 0;
}
