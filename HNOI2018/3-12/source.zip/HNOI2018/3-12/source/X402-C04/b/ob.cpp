#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=50009;

int main_d;

inline int minn(int a,int b){if(a<b)return a;return b;}
inline int maxx(int a,int b){if(a>b)return a;return b;}

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9'){x=x*10+(ch^48);ch=getchar();}
	return x*f;
}

struct point
{
	int coord[4],mn[4],id,l,r,sum,v,f;

	int &operator [](int x)
	{
		return coord[x];
	}

	void init()
	{
		for(int i=0;i<=3;i++)
			mn[i]=coord[i];
		v=sum=f=0;
	}
};

bool operator <(point a,point b)
{
	return a[main_d]<b[main_d];
}

inline bool ecmp(point a,point b)
{
	for(int i=0;i<=3;i++)
		if(a[i]!=b[i])
			return 0;
	return 1;
}

inline bool judge(point a,point b)
{
	for(int i=0;i<=3;i++)
		if(a[i]>b[i])
			return 0;
	return 1;
}

inline bool checks(point a,point b)
{
	for(int i=0;i<=3;i++)
		if(a.mn[i]>b[i])
			return 0;
	return 1;
}

int p[N];
int sumt[5];

struct k_dimensional_tree
{
	int root,maxval;
	point t[N];

	void push(int x)
	{
		t[x].sum=t[x].v+t[t[x].l].sum+t[t[x].r].sum;
	}

	void update(int x)
	{
		for(int i=0;i<=3;i++)
			t[x].mn[i]=minn(t[x].mn[i],minn(t[t[x].l].mn[i],t[t[x].r].mn[i]));
		push(x);
	}

	inline int check(int x,point p)
	{
		if(!x)return x;
		int ret=1;
		for(int i=0;i<=3;i++)
			if(p[i]<t[x].mn[i])
				ret=0;
		return ret;
	}

	int biu(int l,int r,int d)
	{
		main_d=d;

		int mid=l+r>>1,nxt;
		nth_element(t+l,t+mid,t+r+1);

		nxt=d+1;
		if(nxt==4)
			nxt=1;
		t[mid].init();

		if(l<mid)
			t[mid].l=biu(l,mid-1,nxt),t[t[mid].l].f=mid;
		if(mid<r)
			t[mid].r=biu(mid+1,r,nxt),t[t[mid].r].f=mid;

		update(mid);
		return mid;
	}

	int query(int x,point p,int d)
	{
		sumt[0]++;int ret=0;
		if(judge(t[x],p))
			ret+=t[x].v;

		int nxt=d+1;
		if(nxt==4)
			nxt=1;
		if(p[d]>=t[x][d])
		{
			int a=t[x].l,b=t[x].r;
			if(t[a].sum<t[b].sum)
				swap(a,b);

			if(checks(t[a],p))
				ret+=query(a,p,nxt);
			if(checks(t[b],p))
				ret+=query(b,p,nxt);
		}
		else
			if(checks(t[t[x].l],p))
				ret+=query(t[x].l,p,nxt);
		return ret;
	}

	void modify(int x,int v)
	{
		t[x].v+=v;
		push(x);
		while(x=t[x].f)
			push(x);
	}
}b;	

bool pcmp(int a,int b)
{	
	for(int i=0;i<=3;i++)
		if(b.t[a][i]!=b.t[b][i])
			return b.t[a][i]<b.t[b][i];
	return 0;
}

int main()
{
	int n=read();
	for(int i=1;i<=n;i++)
	{
		p[i]=i;
		for(int j=0;j<=3;j++)
			b.t[i][j]=read();
		b.t[i].id=i;
	}

	b.root=b.biu(1,n,1);
	sort(p+1,p+n+1,pcmp);

	for(int i=1;i<=n;i++)
	{
		b.maxval=0;
		int o=p[i];
		//printf("querying %d:%d %d %d %d\n",p[i],b.t[o][0],b.t[o][1],b.t[o][2],b.t[o][3]);
		b.query(b.root,b.t[p[i]],1);
		b.modify(p[i],b.maxval+1);
		//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	}

	printf("%d\n",b.t[b.root].sum);

	//cerr<<"my"<<sumt[0]<<endl;
	return 0;
}
