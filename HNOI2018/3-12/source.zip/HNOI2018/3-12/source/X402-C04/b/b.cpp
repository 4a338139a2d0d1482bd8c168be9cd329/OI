#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=5e4+9;
const int M=N*300;

int n,m,ans[N],rt,etot;
map<int,int> ha;

namespace segt
{
	int t[M],ls[M],rs[M],totc;

	inline int newnode()
	{
		assert(totc<M);
		int ret=++totc;
		t[ret]=ls[ret]=rs[ret]=0;
		return ret;
	}

	inline void modifys(int &x,int l,int r,int p,int v)
	{
		if(!x)x=newnode();t[x]+=v;
		if(l==r)return;int mid=l+r>>1;
		if(p<=mid)modifys(ls[x],l,mid,p,v);
		else modifys(rs[x],mid+1,r,p,v);
	}

	inline void modify(int &x,int l,int r,int px,int py,int v)
	{
		if(!x)x=newnode();modifys(t[x],1,n,py,v);
		if(l==r)return;int mid=l+r>>1;
		if(px<=mid)modify(ls[x],l,mid,px,py,v);
		else modify(rs[x],mid+1,r,px,py,v);
	}

	inline int querys(int x,int l,int r,int dl,int dr)
	{
		if(!x)return 0;int mid=l+r>>1;
		if(dl==l && r==dr)return t[x];
		if(dr<=mid)
			return querys(ls[x],l,mid,dl,dr);
		else if(mid<dl)
			return querys(rs[x],mid+1,r,dl,dr);
		else 
			return querys(ls[x],l,mid,dl,mid)+querys(rs[x],mid+1,r,mid+1,dr);
	}

	inline int query(int x,int l,int r,int dlx,int drx,int dly,int dry)
	{
		if(!x)return 0;int mid=l+r>>1;
		if(dlx==l && drx==r)
			return querys(t[x],1,n,dly,dry);
		if(drx<=mid)
			return query(ls[x],l,mid,dlx,drx,dly,dry);
		else if(mid<dlx)
			return query(rs[x],mid+1,r,dlx,drx,dly,dry);
		else 
			return query(ls[x],l,mid,dlx,mid,dly,dry)+query(rs[x],mid+1,r,mid+1,drx,dly,dry);
	}
}

struct event
{
	int ty,tim,x,y,z;
}e[N*8],tmp[N*8];

inline void cdq(int l,int r)
{
	if(l==r)return;int mid=l+r>>1;

	cdq(l,mid);cdq(mid+1,r);

	int lp=l,rp,tmps;
	for(int i=mid+1;i<=r;i++)
	{
		while(lp<=mid && e[lp].x>=e[i].x)
		{
			if(e[lp].ty==0)
				segt::modify(rt,1,n,e[lp].y,e[lp].z,1);
			++lp;
		}
		if(e[i].ty==0)continue;
		else
		{
			if(e[i].ty==1)
				ans[e[i].tim]+=(tmps=segt::query(rt,1,n,e[i].y,n,e[i].z,n));
			else
				ans[e[i].tim]-=(tmps=segt::query(rt,1,n,e[i].y,n,e[i].z,n))*(e[i].ty-1);
		}
	}

	segt::totc=rt=0;

	lp=l,rp=mid+1;
	for(int i=l;i<=r;i++)
	{
		if(lp<=mid && (rp>r || e[rp].x<=e[lp].x))
			tmp[i]=e[lp++];
		else
			tmp[i]=e[rp++];
	}
	for(int i=l;i<=r;i++)
		e[i]=tmp[i];
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);

	m=read();int pcnt=0;
	for(int i=1,ty,x,y,z,x2,y2,z2;i<=m;i++)
	{
		ty=read();
		if(ty==1)
		{
			ha[x=read()];ha[y=read()];ha[z=read()];
			e[++etot]=(event){0,i,x,y,z};
			pcnt++;ans[i]=-1;
		}
		else
		{
			x=read();y=read();z=read();
			x2=read();y2=read();z2=read();
			
			e[++etot]=(event){1,i,x,y,z};
			e[++etot]=(event){2,i,x2+1,y,z};
			e[++etot]=(event){2,i,x,y2+1,z};
			e[++etot]=(event){2,i,x,y,z2+1};
			e[++etot]=(event){1,i,x2+1,y2+1,z};
			e[++etot]=(event){1,i,x2+1,y,z2+1};
			e[++etot]=(event){1,i,x,y2+1,z2+1};
			e[++etot]=(event){2,i,x2+1,y2+1,z2+1};
			ha[x];ha[y];ha[z];ha[x2+1];ha[y2+1];ha[z2+1];
			ans[i]=0;
		}
	}

	n=0;
	for(map<int,int>::iterator it=ha.begin();it!=ha.end();it++)
		(*it).second=++n;
	for(int i=1;i<=etot;i++)
		e[i]=(event){e[i].ty,e[i].tim,ha[e[i].x],ha[e[i].y],ha[e[i].z]};

	cdq(1,etot);
	for(int i=1;i<=m;i++)
		if(~ans[i])
			printf("%d\n",ans[i]);

	return 0;
}
