#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef long long ll;
set<pr> ha;

const int N=30009;
const int M=1e9;
const int P=1e5;

int a[N];

inline int urand()
{
	return abs((int)rand()<<15|rand()&2147483647);
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("b.in","w",stdout);
	int n=50000,fl=0;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
	{
		int ty=rand()%2+1;
		if(fl==0)ty=1,fl=1;
		if(ty==1)
			printf("%d %d %d %d\n",ty,urand()%M,urand()%M,urand()%M);
		else
		{
			int x=urand()%P,y=urand()%P,z=urand()%P;
			printf("%d %d %d %d",ty,x,y,z);
			x+=urand()%M-P,y+=urand()%M-P,z+=urand()%M-P;
			printf(" %d %d %d\n",x,y,z);
		}
			
	}


	return 0;
}
