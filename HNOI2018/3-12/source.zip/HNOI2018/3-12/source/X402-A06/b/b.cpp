#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int m, cnt;

struct node {
	int x, y, z, tp, id;
}a[maxn];

void Get() {
	m = read();
}

int comp(node c,node d) {
	return c.x <= d.x && c.y <= d.y && c.z <= d.z;
}

void solve_bf() {
	while(m --) {
		int tp = read();
		if(tp == 1) {
			int x = read(), y = read(), z = read();
			a[++cnt].x = x, a[cnt].y = y, a[cnt].z = z;
		}
		else{
			node T1, T2;
			T1.x = read(), T1.y = read(), T1.z = read();
			T2.x = read(), T2.y = read(), T2.z = read();
			int Ans = 0;
			For(i, 1, cnt) {
				if(comp(T1, a[i]) && comp(a[i], T2) ) ++ Ans;
			}printf("%d\n", Ans);
		}
	}
}

const int maxm = 20;

int tree[25][25][25];

int lowbit(int x){return x & -x;}

void add(int x,int y,int z) {
	while(z <= maxm) {
		++ tree[x][y][z];
		z += lowbit(z);
	}
}

int query(int x,int y,int z) {
	int Ans = 0;
	while(z) {
		Ans += tree[x][y][z];
		z -= lowbit(z);
	}
	return Ans;
}

int ans[maxn], Maxx;

void solve_spe() {
	for(int i = 1;i <= cnt; ++i){
		int tp = a[i].tp;
		int x = a[i].x, y = a[i].y, z = a[i].z;

		if(tp == 1) {
			add(x, y, z);
		}
		else {
			int Ans = 0;
			int x2 = a[i+1].x, y2 = a[i+1].y, z2 = a[i+1].z;
			For(j, x, x2) {
				For(k, y, y2) {
					Ans += query(j, k, z2);
					if(z) Ans -= query(j, k, z-1);
				}
			}
			++ i;
			printf("%d\n", Ans);
		}
	}
}

void Input() {
	For(i, 1, m) {
		int tp = read();
		if(tp == 1) {
			a[++cnt].x = read(), a[cnt].y = read(), a[cnt].z = read();
			a[cnt].tp = 1, a[cnt].id = i;
		}
		else{
			a[++cnt].x = read(), a[cnt].y = read(), a[cnt].z = read(), a[cnt].tp = 2, a[cnt].id = i;
			a[++cnt].x = read(), a[cnt].y = read(), a[cnt].z = read(), a[cnt].tp = 3, a[cnt].id = i;
		}
	}
}

int main() {

	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	Get();
	if(m <= 1000) solve_bf();
	else {
		Input();
		solve_spe();
	}

	return 0;
}
