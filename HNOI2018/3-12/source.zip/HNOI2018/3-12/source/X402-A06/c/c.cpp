#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int c, m;

void solve_bf() {
	bool have = 0;
	For(i, 0, m - 1) {
		ll now = 1ll * i * i - 1ll * c;
		now = (now % m + m) % m;
		if(now == 0) {printf("%d ", i); have = 1;}
	}

	if(have == 1) puts("");
	else printf("no\n");
}

int main() {

	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	int _ = read();
	while(_ --) {
		c = read(), m = read();
		solve_bf();
	}

	return 0;
}
