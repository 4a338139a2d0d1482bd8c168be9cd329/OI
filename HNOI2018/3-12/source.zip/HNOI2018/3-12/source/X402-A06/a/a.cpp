#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int n, a[maxn], b[maxn];

void Get() {
	n = read();
}

void solve_bf() {
	int tmp = (1 << n + 1) - 1;
	For(i, 1, tmp) {
		int cnta = 0, cntb = 0;
		For(j, 0, n) {
			if(i & (1 << j) ) a[++cnta] = j;
			else b[++cntb] = j;
		}

		bool flag = 0;
		For(j, 1, n) {
			int ta = 0, tb = 0;
			For(u, 1, cnta) {
				For(v, u+1, cnta) {
					if(a[u] + a[v] == j) ++ ta;
				}
			}

			For(u, 1, cntb) {
				For(v, u+1, cntb) {
					if(b[u] + b[v] == j) ++ tb;
				}
			}

			if(ta != tb) {
				flag = 1;
				break;
			}
		}

		if(!flag) {
			For(j, 1, cnta) if(a[j] == 1) {
				For(k, 1, cnta) printf("%d ", a[k]); puts("");
				return;
			}
			
			For(k, 1, cntb) printf("%d ", b[k]); puts(""); return;
		}
	}
}

int visa[maxn], visb[maxn];

void solve() {
	int cnta = 1, cntb = 1;
	a[1] = 1, b[1] = 0;
	For(i, 2, n) {
		if(visa[i] == visb[i]) {
			a[++cnta] = i;
			For(j, 1, cnta-1) visa[a[j] + i] ++;
		}
		else {
			b[++cntb] = i;
			For(j, 1, cntb-1) visb[b[j] + i] ++;
		}
	}

	For(i, 1, cnta) printf("%d ", a[i]); puts("");
}

int main() {

	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);

	Get();
	solve();

	return 0;
}
