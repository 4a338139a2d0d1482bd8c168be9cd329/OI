#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std ;
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}
#define LL long long

int c,p;

inline void work(){
	//if(c==0)
	bool f=1;
	for(int i=0;i<p;++i)
		if((long long)i*i%p==c) printf("%d ",i),f=0;
	if(f) printf("no");
	puts("");
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int t;read(t);
	while(t--){
		read(c),read(p);
		while(c<0) c+=p;
		work();
	}
    return 0;
}
