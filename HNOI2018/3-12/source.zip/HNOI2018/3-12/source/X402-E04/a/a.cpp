#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=j;i<=k;++i)
#define Forr(i,j,k) for(register int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c = getchar();
	while( isdigit(c))x = x * 10 + c - 48, c = getchar();
}
inline void file(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
}
int n;
void init(){
	read(n);
}
int a[N], b[N], x[N], y[N], sa[N];
void solve(){
	For(i, 0, n){
		if(i * 2 <= n)y[i * 2] ++;
		y[i] -= i + 1;
	}
	a[0] = 0;
	a[1] = 1;
	x[2] = 2;
	sa[2] = 1;
	For(i, 2, n){
		y[i] += sa[i] * 2;
		if(x[i] == y[i])
			a[i] = 0;
		else {
			a[i] = 1;
			if(i * 2 <= n)x[i * 2] += 2;
		}
		sa[i + 1] = sa[i] + a[i];
	}
	For(i, 1, n)if(a[i])printf("%d ", i);puts("");
}
int main(){
	file();
	init();
	solve();
	return 0;
}
