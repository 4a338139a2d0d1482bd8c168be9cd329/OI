#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=j;i<=k;++i)
#define Forr(i,j,k) for(register int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c = getchar();
	while( isdigit(c))x = x * 10 + c - 48, c = getchar();
}
inline void file(){
	freopen("a.in","r",stdin);
	freopen("a1.out","w",stdout);
}
int n;
void init(){
	read(n);
}
int a[N], b[N], x[N], y[N];
void solve(){
	a[0] = 0; b[0] = 1;
	a[1] = 1; b[1] = 0;
	For(i, 2, n){
		For(j, 1, (i - 1) / 2)
			x[i] += a[j] * a[i - j], y[i] += b[j] * b[i - j];
		if(y[i] == x[i])a[i] = 1;else b[i] = 1;
	}
	For(i, 1, n)if(a[i])printf("%d ", i);puts("");
	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
}
int main(){
	file();
	init();
	solve();
	return 0;
}
