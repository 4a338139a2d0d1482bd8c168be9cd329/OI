#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0; char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("a.in","r",stdin);
	freopen("a1.out","w",stdout);
}
int n;
void init(){
	read(n);
}
int a[N], b[N], x[N*N], y[N*N];
bool check(){
	For(i, 0, n)x[i] = y[i] = 0;
	For(i, 0, n)
		For(j, 0, n)if(i ^ j)
			x[i + j] = (x[i + j] + a[i] * a[j]);
	For(i, 0, n)
		For(j, 0, n)if(i ^ j)
			y[i + j] = (y[i + j] + b[i] * b[j]);
	For(i, 1, n)if(x[i] != y[i])return 0;
	return 1;
}
void dfs(int now){
	if(now > n){
		For(i, 0, n)
			b[i] = a[i] ^ 1;
		if(check()){
			For(i, 0, n)
				if(a[i])printf("%d ", i);
			exit(0);
		}
		return ;
	}
	a[now] = 1;
	dfs(now + 1);
	if(now != 1){
		a[now] = 0;
		dfs(now + 1);
	}
}
void solve(){
	dfs(0);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
