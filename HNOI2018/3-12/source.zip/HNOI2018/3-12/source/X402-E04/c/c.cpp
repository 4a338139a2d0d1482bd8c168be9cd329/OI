#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
ll qpow(ll a,ll b,ll mod){
	ll ret=1;
	for(;b;b>>=1,a=a*a%mod)if(b&1)ret=ret*a%mod;
	return ret;
}
namespace Cipolla{
	ll mod;
	struct Complex{
		ll a,b,w;
		Complex(ll a0=0,ll b0=0,ll w0=0):a(a0),b(b0),w(w0){}
		inline Complex operator *(const Complex &r)const {
			return Complex((a*r.a+b*r.b%mod*w)%mod,(a*r.b+b*r.a)%mod,w);
		} 
	};
	ll pow(Complex a,ll b){
		Complex ret(1,0,a.w);
		for(;b;b>>=1,a=a*a)if(b&1)ret=ret*a;
		return ret.a;
	}
	inline int legendre(ll x){
		return qpow(x,(mod-1)/2,mod);
	}
	ll solve(ll n,ll p){
		ll a=rand()%(p-1)+1,w=(a*a-n)%p;mod=p;
		if(legendre(n)==p-1)return -1;
		while(legendre(w)==1)a=rand()%(p-1)+1,w=(a*a%p+p-n)%p;
		return pow(Complex(a,1,w),(p+1)/2);
	}
}namespace Cip=Cipolla;
inline void file(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
}
int c, m;
void init(){
	read(c), read(m);
	((c %= m) += m) %= m;
}	
void solve(){
	srand(20170312);
	if(c == 0)return void (puts("0"));
	if(m == 2){
		if(c == 1)puts("1");
	}else {
		int ans = Cip::solve(c, m);
		if(ans != -1){
			if(ans > m - ans)ans = m - ans;
			printf("%d", ans);
			if(m - ans != ans)printf(" %d",m - ans);
		}else printf("no");
		puts("");
	}
}
int main(){
	file();
	int T;
	read(T);
	while(T--)init(),solve();
	return 0;
}
