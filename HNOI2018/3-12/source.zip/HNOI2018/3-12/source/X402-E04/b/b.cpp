#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 50010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
}
int m, x[N], y[N], z[N], tot;
void init(){
	read(m);
}
void solve(){
	For(t, 1, m){
		int tp;
		read(tp);
		if(tp == 1){
			read(x[++tot]), read(y[tot]), read(z[tot]);
		}else {
			int X, Y, Z, a, b, c, ans = 0;
			read(a), read(b), read(c), read(X), read(Y), read(Z);
			For(i, 1, tot)
				if(x[i] <= X && y[i] <= Y && z[i] <= Z && a <= x[i] && b <= y[i] && c <= z[i])ans ++;
			printf("%d\n", ans);
		}
	}
}

int main(){
	file();
	init();
	solve();
	return 0;
}
