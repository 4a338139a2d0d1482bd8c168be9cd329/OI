#include<bits/stdc++.h>
using namespace std;

const int MAXN = 20;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n;
bool p[MAXN];
vector<int> s1, s2;
int c1[35], c2[35];

void dfs(int cur) {
	if(cur == n+1) {
		int i, j;
		s1.clear(), s2.clear();
		for(i = 0; i <= n; i++) {
			if(p[i]) s1.push_back(i);
			else s2.push_back(i);
		}
		memset(c1, 0, sizeof(c1));
		memset(c2, 0, sizeof(c2));
		for(i = 0; i < (int)s1.size(); i++) 
			for(j = i+1; j < (int)s1.size(); j++) 
				c1[s1[i]+s1[j]]++;
		for(i = 0; i < (int)s2.size(); i++) 
			for(j = i+1; j < (int)s2.size(); j++) 
				c2[s2[i]+s2[j]]++;
		for(i = 1; i <= n; i++) if(c1[i] != c2[i]) break;
		if(i == n+1) {
			sort(s1.begin(), s1.end());
			for(i = 0; i < (int)s1.size(); i++) printf("%d ", s1[i]);
			printf("\n");
			exit(0);
		}
		return;
	}
	p[cur] = true;
	dfs(cur+1);
	p[cur] = false;
	if(cur == 1) return;
	dfs(cur+1);
}

int main() {
	freopen("a.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	n = read();
	dfs(0);
	return 0;
}
