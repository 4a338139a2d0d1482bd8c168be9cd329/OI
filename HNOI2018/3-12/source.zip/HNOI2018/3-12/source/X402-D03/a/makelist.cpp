#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, cnt0, cnt1;
int s0[MAXN], s1[MAXN];
int c0[MAXN<<1], c1[MAXN<<1];

int main() {
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);

	int i, j;
	n = read();
	s0[2] = 3;
	s1[1] = 1;
	s1[2] = 2;
	cnt0 = cnt1 = 2;
	c0[3]++, c1[3]++;
	for(i = 4; i <= n; i++) {
		if(c0[i] == c1[i]) {
			for(j = 1; j <= cnt1; j++) {
				if(s1[j]+i > n) break;
				c1[s1[j]+i]++;
			}
			s1[++cnt1] = i;
		}
		else {
			for(j = 0; j <= cnt0; j++) {
				if(s0[j]+i > n) break;
				c0[s0[j]+i]++;
			}
			s0[++cnt0] = i;
		}
	}
	for(i = cnt1; i >= 1; i--)
		s1[i] = s1[i]-s1[i-1];
	for(i = 1; i <= cnt1; i += 10) {
		unsigned int res = 0;
		for(j = i; j <= i+9; j++) {
			res = res * 3 + s1[j]-1;
		}
		printf("%d,", res);
	}
	printf("\n");
	return 0;
	for(i = 1; i <= cnt1; i++)
		printf("%d ", s1[i]-s1[i-1]);
	printf("\n");
	cerr << clock() << endl;
	return 0;
}
