#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline ll read() {
	ll x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int main() {
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	int T = read();
	while(T--) {
		ll c = read(), m = read(), a;
		c = (c % m + m)%m;
		bool flag = false;
		for(a = 0; a < m; a++) 
			if(a * a % m == c) {
				if(flag) printf("%lld\n", a);
				else printf("%lld ", a), flag = true;
			}
		if(!flag) printf("no\n");
	}
	return 0;
}
