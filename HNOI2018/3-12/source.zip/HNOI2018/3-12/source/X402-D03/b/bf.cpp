#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int m;
struct Tuple {
	int x, y, z;
	Tuple(int x0, int y0, int z0): x(x0), y(y0), z(z0) {}
	bool operator >= (const Tuple &rhs) const {
		return x >= rhs.x && y >= rhs.y && z >= rhs.z;
	}
};
vector<Tuple> S;

int main() {
	freopen("b.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i;
	m = read();
	while(m--) {
		int op = read();
		int x1 = read(), y1 = read(), z1 = read();
		Tuple p(x1, y1, z1);
		if(op == 1) S.push_back(p);
		else {
			int ans = 0;
			int x2 = read(), y2 = read(), z2 = read();
			Tuple q(x2, y2, z2);
			for(i = 0; i < (int)S.size(); i++) 
				if(S[i] >= p && q >= S[i]) ans++;
			printf("%d\n", ans);
		}
	}
	cerr << clock() << endl;
	return 0;
}
