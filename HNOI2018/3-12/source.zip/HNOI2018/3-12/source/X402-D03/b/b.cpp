#include<bits/stdc++.h>
using namespace std;

const int MAXN = 50010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmin(int &cur, int val) {
	if(val < cur) cur = val;
}

inline void chkmax(int &cur, int val) {
	if(val > cur) cur = val;
}

bool flag;

int root;
namespace TD_T {
	const double ALPHA = 0.75;
	int D;
	struct node {
		int x[3], l[3], r[3];
		int val, sum, sz;
	}P[MAXN];
	bool cmp(const int &a, const int &b) {
		return P[a].x[D] < P[b].x[D];
	}
	int ch[MAXN][2], cnt;
	inline void maintain(int p) {
		int i;
		P[p].sum = P[p].val+P[ch[p][0]].sum+P[ch[p][1]].sum;
		P[p].sz = 1+P[ch[p][0]].sz+P[ch[p][1]].sz;
		for(i = 0; i < 3; i++) {
			P[p].l[i] = P[p].r[i] = P[p].x[i];
			if(ch[p][0]) chkmin(P[p].l[i], P[ch[p][0]].l[i]);
			if(ch[p][1]) chkmin(P[p].l[i], P[ch[p][1]].l[i]);
			chkmax(P[p].r[i], P[ch[p][0]].r[i]);
			chkmax(P[p].r[i], P[ch[p][1]].r[i]);
		}
	}
	inline int build(int *q, int len, int d) {
		if(len == 0) return 0;
		if(len == 1) {
			ch[q[1]][0] = ch[q[1]][1] = 0;
			maintain(q[1]);
			return q[1];
		}
		D = d;
		int mid = ((len+1)>>1);
		nth_element(q+1, q+mid, q+len+1, cmp);
		//printf("build %d %d\n", len, d);
		/*for(int i = 1; i <= len; i++) printf("%d ", q[i]);
		printf("\n");*/
		ch[q[mid]][0] = build(q, mid-1, (d+1)%3);
		ch[q[mid]][1] = build(q+mid, len-mid, (d+1)%3);
		maintain(q[mid]);
		return q[mid];
	}
	int q[MAXN], qn;
	inline void getseq(int p) {
		if(ch[p][0]) getseq(ch[p][0]);
		q[++qn] = p;
		if(ch[p][1]) getseq(ch[p][1]);
	}
	inline void rebuild(int &p, int d) {
		qn = 0;
		getseq(p);
		/*for(int i = 1; i <= qn; i++) {
			printf("%d ", q[i]);
		}
		printf("\n");
		printf("??%d\n", d);*/
		p = build(q, qn, d);
		//printf("!%d\n", p);
	}
	inline void insert(int &p, int *x, int d) {
		if(!p) {
			p = ++cnt;
			P[p].sz = P[p].sum = P[p].val = 1;
			P[p].x[0] = x[0], P[p].x[1] = x[1], P[p].x[2] = x[2];
			P[p].l[0] = P[p].r[0] = x[0];
			P[p].l[1] = P[p].r[1] = x[1];
			P[p].l[2] = P[p].r[2] = x[2];
			return; 
		}
		if(P[p].x[0] == x[0] && P[p].x[1] == x[1] && P[p].x[2]== x[2]) {
			P[p].val++, P[p].sum++;
			return;
		}
		if(x[d] < P[p].x[d]) insert(ch[p][0], x, (d+1)%3);
		else insert(ch[p][1], x, (d+1)%3);
		maintain(p);
		if(P[ch[p][0]].sz > P[p].sz*ALPHA || P[ch[p][1]].sz > P[p].sz*ALPHA) rebuild(p, d);
	}
	inline bool in(int *l, int *r, int *L, int *R) {
		if(l[0] < L[0] || r[0] > R[0]) return false;
		if(l[1] < L[1] || r[1] > R[1]) return false;
		if(l[2] < L[2] || r[2] > R[2]) return false;
		return true;
	}
	inline bool out(int *l, int *r, int *L, int *R) {
		if(r[0] < L[0] || l[0] > R[0]) return true;
		if(r[1] < L[1] || l[1] > R[1]) return true;
		if(r[2] < L[2] || l[2] > R[2]) return true;
		return false;
	}
	inline bool in(int *x, int *L, int *R) {
		if(x[0] < L[0] || x[0] > R[0]) return false;
		if(x[1] < L[1] || x[1] > R[1]) return false;
		if(x[2] < L[2] || x[2] > R[2]) return false;
		return true;
	}
	inline int query(int p, int *l, int *r) {
		//if(flag) printf("query %d\n", p);
		if(out(P[p].l, P[p].r, l, r)) return 0;
		if(in(P[p].l, P[p].r, l, r)) return P[p].sum;
		int res = 0;
		if(in(P[p].x, l, r)) res += P[p].val;
		if(ch[p][0]) res += query(ch[p][0], l, r);
		if(ch[p][1]) res += query(ch[p][1], l, r);
		return res;
	}
	inline void output() {
		int i;
		for(i = 1; i <= cnt; i++) {
			printf("(%d %d %d) (%d %d %d) (%d %d %d) %d %d %d\n", P[i].x[0], P[i].x[1], P[i].x[2], P[i].l[0], P[i].l[1], P[i].l[2], P[i].r[0], P[i].r[1], P[i].r[2], ch[i][0], ch[i][1], P[i].sz);
		}
		printf("\n");
	}
}

int m;

int main() {
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	m = read();
	while(m--) {
		int op = read();
		int x[3];
		x[0] = read(), x[1] = read(), x[2] = read();
		if(op == 1) 
			TD_T::insert(root, x, 0);
		if(op == 2) {
			int y[3];
			y[0] = read(), y[1] = read(), y[2] = read();
			printf("%d\n", TD_T::query(root, x, y));
		}
		//TD_T::output();
	}
	/*flag = true;
	int x[3], y[3];
	x[0] = 414245397, x[1] = 594660400, x[2] = 229028893;
	y[0] = 966897854, y[1] = 623066495, y[2] = 585153506;
	TD_T::query(root, x, y);
	printf("%d\n", root);*/
	//TD_T::output();
	//cerr << clock() << endl;
	return 0;
}
