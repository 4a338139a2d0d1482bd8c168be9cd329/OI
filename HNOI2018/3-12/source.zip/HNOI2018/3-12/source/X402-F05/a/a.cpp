#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;

int n;
int del[N];

int main() {

	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);

	scanf("%d", &n);

	del[0] = 1;

	bool fst = true;
	For(i, 1, n) {
		del[i] = i & 1 ? del[i >> 1] ^ 1 : del[i >> 1];
		if (!del[i]) {
			if (!fst) putchar(' ');
			else fst = false;
			printf("%d", i);
		}
	}
	puts("");

	return 0;
}
