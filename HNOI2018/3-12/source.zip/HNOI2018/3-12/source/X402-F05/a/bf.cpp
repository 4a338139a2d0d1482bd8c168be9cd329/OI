#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;

int calc(int *A, int n, int x) {
	int ret = 0;
	For(i, 1, n) For(j, i + 1, n) ret += (A[i] + A[j]) == x;
	return ret;
}

int p, q;
int A[N], B[N];

int main() {

	freopen("a.in", "r", stdin);
	freopen("a.ans", "w", stdout);

	For(n, 1, 22) {
		For(i, 0, (1 << n) - 1) {
			p = 0, q = 0;
			B[q = 1] = 0;
			For(j, 0, n - 1) if (i & (1 << j)) A[++p] = j + 1; else B[++q] = j + 1;

			bool flag = true;
			For(j, 1, n) if (calc(A, p, j) != calc(B, q, j)) { flag = false; break; }
			if (flag) {
				For(j, 1, p) printf("%d%c", A[j], j == p ? '\n' : ' ');
				//For(j, 1, q) printf("%d%c", B[j], j == q ? '\n' : ' ');
			}
		}
	}

	return 0;
}
