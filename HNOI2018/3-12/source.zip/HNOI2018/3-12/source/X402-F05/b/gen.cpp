#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int rand(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("b.in", "w", stdout);

	srand(time(0));

	int q = 50000;
	printf("%d\n", q);
	For(i, 1, q) {
		int op = rand() % 2 + 1;
		if (op == 1) printf("%d %d %d %d\n", op, rand(), rand(), rand());
		else printf("%d %d %d %d %d %d %d\n", op, rand(1, 1e9), rand(1, 1e9), rand(1, 1e9), rand(1e9, 2e9) , rand(1e9, 2e9), rand(1e9, 2e9));
	}

	return 0;
}
