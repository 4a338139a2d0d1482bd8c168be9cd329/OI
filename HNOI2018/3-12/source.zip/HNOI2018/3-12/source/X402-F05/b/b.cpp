#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 5e4 + 10;

typedef bitset<N> Info;

Info ans[N], now, rev;

int n, m, q, c;

struct Pos {

	bool add;
	int x, id;

	bool operator < (const Pos& A) const {
		return x == A.x ? id < A.id : x < A.x;
	}

};

void work(Pos* A) {
	sort(A + 1, A + c + 1);
	now.reset(), rev = ~now;
	For(i, 1, c) {
		int x = A[i].id;
		if (x < 0) now[-x] = 1, rev[-x] = 0;
		else if (A[i].add) ans[A[i].id] &= now;
		else ans[A[i].id] &= rev;
	}
}

Pos qx[N << 1], qy[N << 1], qz[N << 1];

int main() {

	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	scanf("%d", &q);
	For(i, 1, q) {
		int op;
		scanf("%d", &op);
		if (op == 1) {
			++n;
			int x, y, z;
			scanf("%d%d%d", &x, &y, &z);
			qx[++c] = (Pos){false, x, -n};
			qy[c] = (Pos){false, y, -n};
			qz[c] = (Pos){false, z, -n};
			now[n] = 1;
		} else {
			++m;
			ans[m] = now;
			int x1, y1, z1, x2, y2, z2;
			scanf("%d%d%d%d%d%d", &x1, &y1, &z1, &x2, &y2, &z2);
			qx[++c] = (Pos){false, x1 - 1, m}, qx[++c] = (Pos){true, x2, m};
			qy[c - 1] = (Pos){false, y1 - 1, m}, qy[c] = (Pos){true, y2, m};
			qz[c - 1] = (Pos){false, z1 - 1, m}, qz[c] = (Pos){true, z2, m};
		}
	}

	work(qx), work(qy), work(qz);
	For(i, 1, m) printf("%lu\n", ans[i].count());

	return 0;
}
