#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;

int ans[N], n;

int main() {

	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	int Case;
	scanf("%d", &Case);
	
	while (Case--) {
		int c, m;
		scanf("%d%d", &c, &m);
	
		n = 0;

		For(i, 0, m - 1) 
			if (1ll * i * i % m == c) ans[++n] = i;
		if (!n) puts("no");
		For(i, 1, n) printf("%d%c", ans[i], i == n ? '\n' : ' ');
	}

	return 0;
}
