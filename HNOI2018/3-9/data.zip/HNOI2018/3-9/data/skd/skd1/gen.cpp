#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <set>
#include      <map>
using namespace std;

int random()
{
	return (rand()<<15)^rand();
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("2.in","w",stdout);
#endif
	srand(time(0));
	int n=500,m=670,k=random()%500+1;
	cout<<n<<" "<<m<<" "<<k<<endl;
	for(int i=2;i<=n;i++)
		cout<<i<<" "<<max(1,i-random()%5-1)<<" "<<random()%((int)1e9)<<endl;
	for(int i=n;i<=m;i++)
	{
		int u=random()%(n-1)+2;
		cout<<u<<" "<<max(1,u-random()%5-1)<<" "<<random()%((int)1e9)<<endl;
	}
	return 0;
}

