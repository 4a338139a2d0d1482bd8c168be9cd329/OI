#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <set>
#include      <map>
using namespace std;

int random()
{
	return ((rand()<<15)^rand());
}

const int N=30005;

int a[N],b[N],c[N];

int main()
{
#ifndef ONLINE_JUDGE
	freopen("2.in","w",stdout);
#endif
	srand(time(0));
	int n=30000-random()%10,r=random()%(n-1)+1,k=1;//random()%((n-r)*(n-r+1)/2);
	cout<<n<<" "<<r<<" "<<k<<endl;
	for(int i=1;i<=n;i++)
	{
		a[i]=random()%1000000+1;
		b[i]=random()%1000000+1;
		while(b[i]==a[i])
			b[i]=random()%1000000+1;
		c[i]=random()%1000000+1;
		while(c[i]==a[i]||c[i]==b[i])
			c[i]=random()%1000000+1;
		if(a[i]>b[i])
			swap(a[i],b[i]);
		if(a[i]>c[i])
			swap(a[i],c[i]);
		if(b[i]>c[i])
			swap(b[i],c[i]);
	}
	for(int i=1;i<=n;i++)
		cout<<a[i]<<" ";
	cout<<endl;
	for(int i=1;i<=n;i++)
		cout<<b[i]<<" ";
	cout<<endl;
	for(int i=1;i<=n;i++)
		cout<<c[i]<<" ";
	cout<<endl;
	return 0;
}

