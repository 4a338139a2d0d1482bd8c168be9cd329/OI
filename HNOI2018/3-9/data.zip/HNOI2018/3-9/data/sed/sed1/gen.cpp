#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long u64;

std::mt19937_64 gen;

u64 a[100];

int main() {
	
	for(int n = 1;n<=20;n++)
	{
		char s[20]="";
		sprintf(s,"%d",n);
		int len=strlen(s);
		s[len]='.';
		s[len+1]='i';
		s[len+2]='n';
		s[len+3]=0;
		FILE *A=fopen(s,"w");
	fprintf(A,"%d\n", n);
	u64 c = gen();
	while (!(c & 1)) c = gen();
	u64 ss=0;
	for (int i = 0; i < n; ++i)
	{
	//	cout<<i<<" "<<((1ULL<<(n-i))-1)<<" "<<(ss+1)<<" "<<(ss+1)*((1ULL<<(n-i))-1)<<endl;
		a[i]=(u64)gen()%(((u64)(-1)-(ss)*((1ULL<<(n-i))))/((1ULL<<(n-i))-1)-1)+1+ss;
		ss+=a[i];
	//	fprintf(A,"%llu %llu\n",a[i],ss);
		fprintf(A,"%llu\n", c*a[i]);
	}
	ss=0;
	//fprintf(A,"%llu\n",ss);
	s[len+1]='o';
	s[len+2]='u';
	s[len+3]='t';
	s[len+4]=0;
		FILE *B=fopen(s,"w");
	for(int i=0;i<n;i++)
	{
		int t=(gen()&1);
		ss+=t*a[i];
		fprintf(B,"%d",t);
	}
	fprintf(A,"%llu\n", ss*c);
	
	//fprintf(A,"%llu\n", c * ((gen() & ((1ULL << n) - 1)) << 2));
	//fprintf(stderr, "c = %llu\n", c);
	}
	return 0;
}
