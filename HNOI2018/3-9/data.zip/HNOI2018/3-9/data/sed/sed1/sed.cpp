#include <bits/stdc++.h>

typedef unsigned long long u64;

const int N = 64, M = 1 << 22;

int n;
u64 b[N], c;

void init(u64 x, u64 cur[], int m, std::pair<u64, int> u[]) {
	u[0] = {x, 0};
	for (int i = 0; i < m; ++i) {
		int tot = 1 << i;
		static std::pair<u64, int> temp[M];
		std::copy(u, u + tot, temp);
		std::copy(u, u + tot, temp + tot);
		for (int j = tot; j < 2 * tot; ++j) temp[j].first += cur[i], temp[j].second |= 1 << i;
		std::rotate(temp + tot, std::min_element(temp + tot, temp + 2 * tot), temp + 2 * tot);
		std::merge(temp, temp + tot, temp + tot, temp + 2 * tot, u);
	}
}

void print(u64 x) {
	for (int i = 0; i < n; ++i) putchar('0' + (x >> i & 1));
	putchar('\n');
//	for (int i = 0; i < n; ++i) if (x >> i & 1) c -= b[i];
	//fprintf(stderr, "c = %llu\n", c);
	exit(0);
}

u64 brute() {
	int m = n / 2;
	static std::pair<u64, int> u[M], v[M];
	init(0, b, m, u);
	for (int i = m; i < n; ++i) b[i] = -b[i];
	init(c, b + m, n - m, v);
	for (int i = 0, j = 0; i < (1 << m); ++i) {
		while (j < (1 << (n - m)) && v[j].first < u[i].first) ++j;
		if (v[j].first == u[i].first) return u[i].second | ((u64)v[j].second << m);
	}
}

u64 inv(u64 x) {
	u64 res = 0;
	for (int i = 0; i < 64; ++i) {
		u64 temp = (res | (1ULL << i)) * x;
		if (i < 63) temp &= (1ULL << (i + 1)) - 1;
		if (temp == 1) res |= 1ULL << i;
	}
	assert(res * x == 1);
	return res;
}

int main() {
	freopen("19.in","r",stdin);
	freopen("19_.out","w",stdout);
	scanf("%d", &n);
	for (int i = 0; i < n; ++i) scanf("%llu", &b[i]);
	scanf("%llu", &c);
	if (n < 45) print(brute());
	int k = __builtin_ctzll(b[0]);
	u64 x = inv(b[0] >> k);
	for (u64 i = 1; i < (1ULL << (65 - n - k)); ++i) {
		u64 a = i << k;
		u64 y = i * x;
		for (int j = 0; j < (1 << k); ++j) {
			u64 r = y + ((u64)j << (64 - k));
			static u64 cur[N];
			for (int p = 0; p < n; ++p) cur[p] = b[p] * r;
			u64 d = c * r;
			u64 ans = 0;
			for (int p = n - 1; p >= 0; --p) if (d >= cur[p]) d -= cur[p], ans |= 1ULL << p;
			if (!d) print(ans);
		}
	}
	while(1) {}
	return 0;
}
