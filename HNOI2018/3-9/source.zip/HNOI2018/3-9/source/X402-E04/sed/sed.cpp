#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll unsigned long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
}
ll b[N], w;
int c[N], n;
void init(){
	read(n);
	For(i, 1, n)read(b[i]);
	read(w);
}
void dfs(int now, ll cur){
	if(now > n){
		if(cur == w){
			For(i, 1, n)printf("%d",c[i]);
			puts("");
			exit(0);
		}
		return ;
	}
	c[now] = 1;
	dfs(now + 1, cur + b[now]);
	c[now] = 0;
	dfs(now + 1, cur);
}
void solve(){
	dfs(1, 0);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
