#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 


int main(){
	freopen("fst.in","w",stdout);
	srand(time(0));
	int n = 500, r = rand() % (n-1) + 1, k = rand()%((n-r)*(n-r+1)/2) + 1, M=1e6;
	printf("%d %d %d\n",n,r,k);
	For(i, 1, n)printf("%d ",rand()%M+1);puts("");
	For(i, 1, n)printf("%d ",rand()%M+1);puts("");
	For(i, 1, n)printf("%d ",rand()%M+1);
	return 0;
}
