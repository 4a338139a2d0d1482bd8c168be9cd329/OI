#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 30010, INF = 0x3f3f3f3f;
template<class T>void read(T &X){
	X = 0; char C = getchar();
	while(!isdigit(C))C=getchar();
	while( isdigit(C))X=X*10+C-48,C=getchar();
}
struct Splay{
	#define L(i) T[i].s[0]
	#define R(i) T[i].s[1]
	#define S(i) T[i].sz
	#define F(i) T[i].p
	#define V(i) T[i].v
	#define Mid ((l+r)>>1)
	#define Key L(R(rt))
	struct node{
		int s[2], sz, p, id;ll v;
	}T[N];
	int rt,tot,cur=0;
	inline void update(int i){if(i)S(i) = S(L(i)) + S(R(i)) + 1;}
	inline void Sets(int a,int b,int c){if(a)T[a].s[c] = b;if(b)F(b) = a;}
	inline void insert(int &i, ll val, int p, int id){
		if(!i){
			V(i=++tot) = val, F(i) = p, S(i) = 1;
			T[i].id = id;
			return ;
		}
		if(val > V(i) || (val == V(i) && id > T[i].id))insert(R(i), val, i, id);
		else insert(L(i), val, i, id);
		update(i);
	}
	inline int Loc(int x){return R(F(x)) == x;}
	inline void Rotate(int x){
		int y = F(x), z = F(y), lx = Loc(x), ly = Loc(y);
		Sets(y, T[x].s[!lx], lx);
		Sets(z, x, ly);
		Sets(x, y, !lx);
		update(y);
	}
	void splay(int x, int goal){
		while(F(x) != goal){
			int y = F(x);
			if(F(y) != goal){
				if(Loc(x) ^ Loc(y))Rotate(x);
				else Rotate(y);
			}
			Rotate(x);
		}
		update(x);
		if(!goal)rt = x;
	}
	int find(ll val,int i, int id){
		if(V(i) == val && id == T[i].id)return i;
		if(val > V(i) || (val == V(i) && id > T[i].id))return find(val, R(i), id);
		else return find(val, L(i), id);
	}
	int findsuf(){
		int u = R(rt);
		while(L(u))u = L(u);
		return u;
	}
	int findpre(){
		int u = L(rt);
		while(R(u))u = R(u);
		return u;
	}
	void Del(ll last,int id){
		int v, suf, pre;
		v = find(last, rt, id);
		splay(v, 0);
		if(R(v) == 0 && L(v) == 0){
			T[F(v)].s[Loc(v)] = 0, F(v) = 0;
			rt = 0;
		}
		else if(R(v) == 0){
			int y = F(v);
			Sets(y, L(v) ,Loc(v));
			if(y)update(y);
			if(v == rt) rt = L(v);
		}
		else if(L(v) == 0){
			int y = F(v);
			Sets(y, R(v) ,Loc(v));
			if(y)update(y);
			if(v == rt) rt = R(v);
		}
		else {
			suf = findsuf();
			pre = findpre();
			splay(pre, 0), splay(suf, rt);
			Key = 0;
			update(R(rt)), update(rt);
		}
		cur--;
	}
	inline void Ins(ll val,int id){
		cur++;
		insert(rt, val, 0, id);
		splay(tot, 0);
	}
	int Rank(ll val, int i){
		if(!i)return 0;
		if(val >= V(i))return S(L(i)) + 1 + Rank(val, R(i));
		else return Rank(val, L(i));
	}
	inline void Clear(){
		rt = 0;
		For(i, 1, tot)V(i) = T[i].id = L(i) = R(i) = S(i) = F(i) = 0;
		tot = 0;
	}
	void print(){
		//printf("%d\n",rt);
		//For(i, 1, tot)printf("%d %d %d %d %d\n",i,T[i].v,T[i].p,T[i].s[0],T[i].s[1]);
	}
}S1, S2;
int n, r;
ll a[N], b[N], c[N], k;
ll L, R;
ll sa[N], sb[N], sc[N];
inline void init(){
	read(n), read(r), read(k);
	For(i, 1, n)read(a[i]), sa[i] = sa[i-1] + a[i];
	For(i, 1, n)read(b[i]), sb[i] = sb[i-1] + b[i];
	For(i, 1, n)read(c[i]), sc[i] = sc[i-1] + c[i];
	L = R = 0;
	For(i, 1, n)
		L = L + min(a[i],min(b[i],c[i])), R = R + max(a[i],max(b[i],c[i]));
	//printf("%d %d\n", L, R);
}
inline void file(){
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
}
ll y[N];
inline ll Cal1(int i){
	return sa[n] - sa[i + r - 1] + sb[i + r - 1] + sb[i - 1] - sc[i - 1];
}
inline ll Cal2(int i){
	return sa[n] - sa[i + r - 1] + sb[i + r - 1] - sb[i - 1] + sa[i - 1];
}	
bool check(ll X){
	For(i, 2, n - r + 1){
		if(i <= r){
			y[i] = Cal1(i);
			S1.Ins(y[i], i);
		}else {
			y[i] = Cal2(i);
			S2.Ins(y[i], i);
		}
		//printf("%d %d\n", Cal1(i), Cal2(i));
	}//puts("");
	//cerr<<"ok"<<endl;
	ll cnt = 0;
	For(i, 1, n - r){
		ll nowx1 = sa[i - 1] - sb[i - 1] - sb[i + r - 1] + sc[i + r - 1];
		ll nowx2 = sa[i - 1] + sb[i + r - 1] - sb[i - 1] - sa[i + r - 1];
		//printf("%d %d\n", nowx1, nowx2);
		//cerr<<"ok"<<endl;

		//S1.print(), S2.print();
		if(S1.cur)cnt += S1.Rank(X - nowx1, S1.rt);

		//printf("->%d\n",cnt);
		if(S2.cur)cnt += S2.Rank(X - nowx2, S2.rt);

		//printf("->%d\n",cnt);
		if(S1.cur)S1.Del(y[i + 1], i + 1);
		if(i + r <= n - r + 1){
			if(S2.cur)S2.Del(y[i + r], i + r);
			if(r!=1)S1.Ins(y[i + r] = Cal1(i + r), i + r); 
		}
	}
	S1.Clear(), S2.Clear();
	//printf("%d\n",cnt);
	return cnt >= k;
}
void solve(){
	ll ans = 0;
	while(L <= R){
		ll mid = (L + R) >> 1;
		//printf("%lld %lld %lld\n",L, R, mid);
		if(check(mid))ans = mid , R = mid - 1;
		else L = mid + 1;
	}
	printf("%lld\n", ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
