#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 30010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("fst.in","r",stdin);
	freopen("BF.out","w",stdout);
}
int n, a[3][N], k, r;
ll ans[500*510];
void init(){
	read(n), read(r), read(k);
	For(i, 1, n)read(a[0][i]);
	For(i, 1, n)read(a[1][i]);
	For(i, 1, n)read(a[2][i]);
}
inline int in(int x, int l, int r){
	return x>=l && x<=r;
}
void solve(){
	For(i, 1, n - r + 1)
		For(j, i + 1, n - r + 1){
			int u = i + r - 1, v = j + r - 1;ll ret = 0;
			For(K, 1, n)ret += a[in(K, i, u) + in(K, j, v)][K];
			ans[++ans[0]] = ret;
		}
	sort(ans + 1, ans + ans[0] + 1);
	printf("%lld\n", ans[k]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
