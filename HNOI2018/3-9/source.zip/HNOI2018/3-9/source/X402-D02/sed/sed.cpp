#include<iostream>
#include<cstdio>
#include<cstring>

typedef unsigned long long ull;
const int N=20;

inline int lowbit(int x){return x&(-x);}

ull A[N],f[1<<N],sum;
int id[1<<N];

int n;

void output(int ans)
{
	if(ans<0)printf("?_?\n");
	else
	{
		for(int i=0;i<n;i++)
			printf("%d",(ans>>i)&1);
		printf("\n");
	}
}

int main()
{
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%llu",A+i),id[1<<i]=i;
	scanf("%llu",&sum);

	int m=1<<n,ans=-1;
	for(int i=1;i<m;i++)
		f[i]=f[i^lowbit(i)]+A[id[lowbit(i)]];
	for(int i=0;i<m;i++)
		if(f[i]==sum){ans=i;break;}

	output(ans);

	return 0;
}
