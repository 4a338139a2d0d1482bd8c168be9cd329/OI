#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define x first
#define y second

template<typename T>inline bool check_min(T a,T &b){return a<b?b=a,1:0;}

namespace hehehe
{
	typedef long long ll;
	typedef std::pair<ll,int> pii;
	const int N=510,M=2050;
	const ll INF=10000000000000007ll;

	struct edge
	{
		int u,v,w;
		bool operator < (const edge &A) const {return w<A.w;}
	};
	
	edge E[N];
	int begin[N],next[M],to[M],w[M],ty[M];
	int n,m,k,e;

	ll spfa(bool flag=0)
	{
		static ll f[N][N];
		static std::queue<pii> Q;

		for(int i=1;i<=n;i++)
			for(int j=1;j<=k;j++)
				f[i][j]=INF;
		f[1][0]=0;

		for(Q.push(pii(1,0));!Q.empty();)
		{
			pii A=Q.front();Q.pop();
			int p=A.x,x=A.y;

			for(int i=begin[p],q;i;i=next[i])
				if(check_min(f[p][x]+w[i],f[q=to[i]][x+ty[i]]))
					if(x+ty[i]<=k)Q.push(pii(q,x+ty[i]));
		}

		if(flag)
		{
			ll ret=INF;
			for(int i=1;i<=k;i++)
				check_min(f[n][i],ret);
			return ret;
		}
		return f[n][k];
	}

	void add(int x,int y,int z,bool kk=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		w[e]=z;
		ty[e]=1;
		if(kk)add(y,x,z,0);
	}

	void initialize()
	{
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1;i<=m;i++)
			scanf("%d%d%d",&E[i].u,&E[i].v,&E[i].w);
		std::sort(E+1,E+m+1);
		for(int i=1;i<=m;i++)
			add(E[i].u,E[i].v,E[i].w);
	}

	void solve()
	{
		initialize();
		ll ans=INF;

		check_min(spfa(1),ans);
		if(ans<INF){printf("%lld\n",ans);return;}

		for(int i=1;i<=m;i++)
		{
			ty[i*2-1]=ty[i*2]=0;
			w[i*2-1]=w[i*2]=0;
			check_min(spfa(),ans);
		}

		printf("%lld\n",ans);
	}
}

int main()
{
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);
	hehehe::solve();
	return 0;
}
