#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

const int N=2333;

int A[N],B[N],C[N];
int n,len,k;

int calc(int x,int y)
{
	static int cnt[N];
	memset(cnt,0,sizeof(cnt));
	for(int i=x;i<=x+len-1;i++)cnt[i]++;
	for(int i=y;i<=y+len-1;i++)cnt[i]++;
	int ret=0;
	for(int i=1;i<=n;i++)
		if(cnt[i]==0)ret+=A[i];
		else if(cnt[i]==1)ret+=B[i];
		else if(cnt[i]==2)ret+=C[i];
		else printf("fuck\n");
	return ret;
}

int s[N*N],tot;

int main()
{
	freopen("fst.in","r",stdin);
	freopen("fst.ans","w",stdout);

	scanf("%d%d%d",&n,&len,&k);
	for(int i=1;i<=n;i++)scanf("%d",A+i);
	for(int i=1;i<=n;i++)scanf("%d",B+i);
	for(int i=1;i<=n;i++)scanf("%d",C+i);

	tot=0;
	for(int i=1;i<=n-len+1;i++)
		for(int j=i+1;j<=n-len+1;j++)
			s[++tot]=calc(i,j);

	std::sort(s+1,s+tot+1);
	printf("%d\n",s[k]);

//	fprintf(stderr,"bf = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
