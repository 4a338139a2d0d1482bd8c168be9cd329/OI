#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace FenKuaiBuHuiXieZenMeBanA___QAQ
{
	typedef long long ll;
	const int N=30100,S=55;
	const ll INF=1000000000000000ll;

	struct blocker
	{
		ll s[N],t[N],tag[N/S];
		int L[N/S],R[N/S],bel[N];

		bool udo[N/S];

		int tot;

		void reset(ll *A,int n)
		{
			for(int i=1;i<=n;i++)
				s[i]=t[i]=A[i];
			tot=0;
			for(int i=1,j;i<=n;i=j+1)
			{
				j=std::min(n,i+S-1);
				tot++,L[tot]=i,R[tot]=j,tag[tot]=0,udo[tot]=0;
				std::sort(t+i,t+j+1);

				for(int k=i;k<=j;k++)bel[k]=tot;
			}
		}
		
		inline void upd(int p)
		{
			for(register int i=L[p];i<=R[p];i++)
				t[i]=s[i];
			std::sort(t+L[p],t+R[p]+1);
		}
		void modify(int l,int r,ll x)
		{

			if(bel[l]==bel[r])
			{
				for(register int i=l;i<=r;i++)
					s[i]+=x;
				udo[bel[l]]=1;
				return;
			}
			if(L[bel[l]]!=l)
			{
				l=L[bel[l]];
			}
			if(R[bel[r]]!=r)
			{
				for(register int i=L[bel[r]];i<=r;i++)
					s[i]+=x;
				udo[bel[r]]=1;

				r=L[bel[r]]-1;
			}

			for(register int i=bel[l];i<=bel[r];i++)
				tag[i]+=x;
		}

		inline int ask(int p,ll x)
		{
			if(udo[p])upd(p),udo[p]=0;

			if(x-tag[p]<t[L[p]])return 0;
			if(x-tag[p]>=t[R[p]])return R[p]-L[p]+1;

			return std::upper_bound(t+L[p],t+R[p]+1,x-tag[p])-t-L[p];
		}

		int query(int l,ll k)
		{
			register int ret=0;

			if(l!=L[bel[l]])
			{
				for(register int i=l;i<=R[bel[l]];i++)
					if(s[i]+tag[bel[l]]<=k)ret++;
				if(bel[l]==tot)return ret;

				l=R[bel[l]]+1;
			}

			for(register int i=bel[l];i<=tot;i++)
				ret+=ask(i,k);
			return ret;
		}
	}d;

	int A[N],B[N],C[N];
	int n,len,k;

	bool check(ll lim)
	{
		static ll f[N],g[N];
		ll sum=0;
		for(int i=1;i<=len;i++)
			f[i]=C[i]-B[i],sum+=B[i];
		for(int i=len+1;i<=n;i++)
			f[i]=B[i]-A[i],sum+=A[i];

		int m=n-len+1;
		g[m]=0;
		for(int i=m;i<=n;i++)
			g[m]+=f[i];
		for(int i=m-1;i;i--)
			g[i]=g[i+1]+f[i]-f[i+len];
		d.reset(g,m);

		register int cnt=d.query(2,lim-sum);

		for(int i=2;i<m;i++)
		{
			sum+=-B[i-1]+A[i-1]+B[i+len-1]-A[i+len-1];

			register int delta=(C[i+len-1]-B[i+len-1])-(B[i+len-1]-A[i+len-1]);
			register int tmp=std::min(i+len-1,m);
			d.modify(i,tmp,delta);

			cnt+=d.query(i+1,lim-sum);

			if(cnt>=k)return 1;
		}

//		printf("cnt = %d\n",cnt);

		return cnt>=k;
	}

	void initialize()
	{
		read(n),read(len),read(k);
		for(int i=1;i<=n;i++)read(A[i]);
		for(int i=1;i<=n;i++)read(B[i]);
		for(int i=1;i<=n;i++)read(C[i]);
	}

	void solve()
	{
		initialize();

		ll u=0,d=0,mid;
		for(int i=1;i<=n;i++)u+=C[i];

		while(u>d)
		{
//			fprintf(stderr,"%lld -- %lld\n",d,u);
			mid=(u+d)>>1;
			if(check(mid))u=mid;
			else d=mid+1;
		}
		printf("%lld\n",d);
	}

}

int main()
{
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);

	FenKuaiBuHuiXieZenMeBanA___QAQ::solve();

//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
