#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace FenKuaiBuHuiXieZenMeBanA___QAQ
{
	typedef long long ll;
	const int N=30100,S=60;
	const ll INF=1000000000000000ll;

	struct blocker
	{
		ll s[N],t[N],tag[N/S];
		int L[N/S],R[N/S],bel[N];
		int tot;

		void reset(ll *A,int n)
		{
			for(int i=1;i<=n;i++)
				s[i]=t[i]=A[i];
			tot=0;
			for(int i=1,j;i<=n;i=j+1)
			{
				j=std::min(n,i+S-1);
				tot++,L[tot]=i,R[tot]=j,tag[tot]=0;
				std::sort(t+i,t+j+1);

				for(int k=i;k<=j;k++)bel[k]=tot;
			}
		}
		
		inline void upd(int p)
		{
			for(register int i=L[p];i<=R[p];i++)
				t[i]=s[i];
			std::sort(t+L[p],t+R[p]+1);
		}
		void modify(int l,int r,ll x)
		{
			if(bel[l]==bel[r])
			{
				for(int i=l;i<=r;i++)
					s[i]+=x;
				upd(bel[l]);
				return;
			}
			if(L[bel[l]]!=l)
			{
				for(int i=l;i<=R[bel[l]];i++)
					s[i]+=x;
				upd(bel[l]);
				l=R[bel[l]]+1;
			}
			if(R[bel[r]]!=r)
			{
				for(int i=L[bel[r]];i<=r;i++)
					s[i]+=x;
				upd(bel[r]);
				r=L[bel[r]]-1;
			}

			while(l<r)tag[bel[l]]+=x,l=R[bel[l]]+1;
		}

		inline int ask(int p,ll x)
		{
			x-=tag[p];
			return std::upper_bound(t+L[p],t+R[p]+1,x)-t-L[p];
		}

		int query(ll k)
		{
			register int ret=0;
			for(int i=1;i<=tot;i++)
				ret+=ask(i,k);
			return ret;
		}
	}d;

	int A[N],B[N],C[N];
	int n,len,k;

	bool check(ll lim)
	{
		static ll f[N],g[N];
		ll sum=0;
		for(int i=1;i<=len;i++)
			f[i]=C[i]-B[i],sum+=B[i];
		for(int i=len+1;i<=n;i++)
			f[i]=B[i]-A[i],sum+=A[i];

		int m=n-len+1;
		g[m]=0;
		for(int i=m;i<=n;i++)
			g[m]+=f[i];
		for(int i=m-1;i;i--)
			g[i]=g[i+1]+f[i]-f[i+len];
		d.reset(g,m);

		d.modify(1,1,INF);
		int cnt=d.query(lim-sum);

		for(int i=2;i<=m;i++)
		{
			sum+=-B[i-1]+A[i-1]+B[i+len-1]-A[i+len-1];
			d.modify(i,i,INF);

			register int delta=(C[i+len-1]-B[i+len-1])-(B[i+len-1]-A[i+len-1]);
			register int tmp=std::min(i+len-1,m);
			d.modify(i,tmp,delta);

			cnt+=d.query(lim-sum);
		}

		return cnt>=k;
	}

	void initialize()
	{
		read(n),read(len),read(k);
		for(int i=1;i<=n;i++)read(A[i]);
		for(int i=1;i<=n;i++)read(B[i]);
		for(int i=1;i<=n;i++)read(C[i]);
	}

	void solve()
	{
		initialize();

//		printf(":%d\n",check(40));
//		return;

		ll u=0,d=0,mid;
		for(int i=1;i<=n;i++)u+=C[i];

		while(u>d)
		{
			mid=(u+d)>>1;
			if(check(mid))u=mid;
			else d=mid+1;
		}
		printf("%lld\n",d);
	}

}

int main()
{
	freopen("fst.in","r",stdin);
//	freopen("fst.out","w",stdout);

	FenKuaiBuHuiXieZenMeBanA___QAQ::solve();

	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
