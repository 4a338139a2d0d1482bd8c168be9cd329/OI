#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

const int N=233333;

int A[N],B[N],C[N];

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("fst.in","w",stdout);//look at here

	int n=100,len=rand()%(std::min(n-1,100))+1;
	int tot=(n-len)*(n-len+1)/2;
	int k=rand()%tot+1;

	printf("%d %d %d\n",n,len,k);

	int lim=10000;
	for(int i=1;i<=n;i++)
	{
		A[i]=rand()%lim+1,B[i]=rand()%lim+1,C[i]=rand()%lim+1;
		if(B[i]>C[i])std::swap(B[i],C[i]);
		if(A[i]>B[i])std::swap(A[i],B[i]);
		if(B[i]>C[i])std::swap(B[i],C[i]);
	}
	for(int i=1;i<=n;i++)printf("%d ",A[i]);printf("\n");
	for(int i=1;i<=n;i++)printf("%d ",B[i]);printf("\n");
	for(int i=1;i<=n;i++)printf("%d ",C[i]);printf("\n");

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
