#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}
int a[100000];

int main(){
	init();
	freopen("fst.in","w",stdout);
	int n=f(2,1e3),r=f(1,n-1),k=f(1,(n-r)*(n-r+1)/2);
	if(rand()&1)k=1;
	printf("%d %d %d\n",n,r,k);
	for(int i=1;i<=n;++i)
		printf("%d ",a[i]=f(1,1e6-2));
	puts("");
	for(int i=1;i<=n;++i)
		printf("%d ",a[i]=f(a[i]+1,1e6-1));
	puts("");
	for(int i=1;i<=n;++i)
		printf("%d ",a[i]=f(a[i]+1,1e6));
	return 0;
}
