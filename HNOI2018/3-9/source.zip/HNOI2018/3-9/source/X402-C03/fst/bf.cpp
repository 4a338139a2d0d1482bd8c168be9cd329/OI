#include<bits/stdc++.h>
using namespace std;

#define glt genius
#define zlt the_strongest_in_hn
#define GLT GENIUS
#define ZLT THE_STRONGEST_IN_HN

typedef long long ll;
const int maxn=1e3+10;
int n,r,k;
ll a[maxn],b[maxn],c[maxn];
priority_queue<ll,vector<ll>,greater<ll> > q;

int main(){
	freopen("fst.in","r",stdin);
	freopen("fst.txt","w",stdout);
	scanf("%d%d%d",&n,&r,&k);
	for(int i=1;i<=n;++i)
		scanf("%lld",&a[i]);
	for(int i=1;i<=n;++i)
		scanf("%lld",&b[i]);
	for(int i=1;i<=n;++i)
		scanf("%lld",&c[i]);
	for(int i=r;i<=n;++i)
		for(int j=i+1;j<=n;++j){
			static int xxx[maxn];
			memset(xxx,0,sizeof(xxx));
			for(int k=i-r+1;k<=i;++k)
				++xxx[k];
			for(int k=j-r+1;k<=j;++k)
				++xxx[k];
			ll res=0;
			for(int k=1;k<=n;++k)
				if(!xxx[k])
					res+=a[k];
				else if(xxx[k]==1)
					res+=b[k];
				else
					res+=c[k];
			q.push(res);
		}
	while(k>1)
		q.pop(),--k;
	printf("%lld\n",q.top());
	return 0;
}
