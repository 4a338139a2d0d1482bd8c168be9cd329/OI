#include<bits/stdc++.h>
using namespace std;

#define glt genius
#define zlt the_strongest_in_hn
#define GLT GENIUS
#define ZLT THE_STRONGEST_IN_HN

template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}

typedef long long ll;
const int maxn=3e4+10;
int n,r,k;
ll a[maxn],b[maxn],c[maxn];
priority_queue<ll,vector<ll>,greater<ll> > q;

namespace glt{
	ll ans=1e18;
	ll st[maxn<<2];
	inline ll push_up(int rt){
		st[rt]=min_(st[rt<<1],st[rt<<1|1]);
	}
	inline void build(int rt,int l,int r,void(*func)(int,int)){
		if(l==r){
			func(rt,l);
			return;
		}
		int mid=l+r>>1;
		build(rt<<1,l,mid,func);
		build(rt<<1|1,mid+1,r,func);
		push_up(rt);
	}
	int query(int rt,int l,int r,int x,int y){
		if(l==x&&r==y)
			return st[rt];
		int mid=l+r>>1;
		if(y<=mid)
			return query(rt<<1,l,mid,x,y);
		else if(x>mid)
			return query(rt<<1|1,mid+1,r,x,y);
		else
			return min_(query(rt<<1,l,mid,x,mid),query(rt<<1|1,mid+1,r,mid+1,y));
	}
	inline void calc1(int rt,int pos){
		st[rt]=a[pos-r]+b[pos]-b[pos-r]-a[pos];
	}
	inline void calc2(int rt,int pos){
		st[rt]=b[pos-r]-c[pos-r]+b[pos]-a[pos];
	}
	int main(){
		if(2*r<=n){
			build(1,2*r,n,calc1);
			for(int i=r;i+r<=n;++i)
				chkmin(ans,query(1,2*r,n,i+r,n)+a[i-r]+b[i]-b[i-r]-a[i]+a[n]);
		}
		build(1,r+1,n,calc2);
		for(int i=r;i<n;++i)
			chkmin(ans,query(1,r+1,n,i+1,min_(i+r,n))+a[i-r]-b[i-r]+c[i]-b[i]+a[n]);
		printf("%lld\n",ans);
		exit(0);
	}
}

int main(){
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
	scanf("%d%d%d",&n,&r,&k);
	for(int i=1;i<=n;++i){
		scanf("%lld",&a[i]);
		a[i]+=a[i-1];
	}
	for(int i=1;i<=n;++i){
		scanf("%lld",&b[i]);
		b[i]+=b[i-1];
	}
	for(int i=1;i<=n;++i){
		scanf("%lld",&c[i]);
		c[i]+=c[i-1];
	}
	if(k==1)
		genius::main();
	for(int i=r;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			if(i<j-r)
				q.push(a[i-r]+b[i]-b[i-r]+a[j-r]-a[i]+b[j]-b[j-r]+a[n]-a[j]);
			else
				q.push(a[i-r]+b[j-r]-b[i-r]+c[i]-c[j-r]+b[j]-b[i]+a[n]-a[j]);
	while(k>1)
		q.pop(),--k;
	printf("%lld\n",q.top());
	return 0;
}
