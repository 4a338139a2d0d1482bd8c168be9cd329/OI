#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("skd.in","w",stdout);
	int n=40,m=70,k,w=10;
	m=f(n-1,m);
	k=rand()%n+1;
	printf("%d %d %d\n",n,m,k);
	for(int i=2;i<=n;++i)
		printf("%d %d %d\n",rand()%(i-1)+1,i,rand()%w+1);
	for(int i=n;i<=m;++i)
		printf("%d %d %d\n",rand()%n+1,rand()%n+1,rand()%w+1);
	return 0;
}
