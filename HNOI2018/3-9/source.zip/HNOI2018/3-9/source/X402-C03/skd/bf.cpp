#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=3e3+10;
int n,m,k;
int ecnt,ebeg[maxn],eto[maxn<<1],enxt[maxn<<1],ew[maxn<<1];
ll ans=1e18;

inline void ae(int u,int v,int w){
	++ecnt;
	enxt[ecnt]=ebeg[u];
	ebeg[u]=ecnt;
	eto[ecnt]=v;
	ew[ecnt]=w;
}
bool vis[maxn];int path[maxn],tmp[maxn];
void dfs(int pos,int cnt){
	if(pos==n){
		copy(path,path+cnt,tmp);
		sort(tmp,tmp+cnt,greater<int>());
		ll res=0;
		for(int i=0;i<k&&i<cnt;++i)
			res+=tmp[i];
		if(res<ans)
			ans=res;
		return;
	}
	vis[pos]=true;
	for(int i=ebeg[pos],v;i;i=enxt[i])
		if(!vis[v=eto[i]]){
			path[cnt]=ew[i];
			dfs(v,cnt+1);
		}
	vis[pos]=false;
}

int main(){
	freopen("skd.in","r",stdin);
	freopen("skd.txt","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1,u,v,w;i<=m;++i){
		scanf("%d%d%d",&u,&v,&w);
		ae(u,v,w);
		ae(v,u,w);
	}
	dfs(1,0);
	printf("%lld\n",ans);
	return 0;
}
