#include<bits/stdc++.h>
using namespace std;

template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}

typedef long long ll;
const int maxn=3e3+10;
const ll inf=1e18;
int n,m,k;
int ecnt,ebeg[maxn],eto[maxn<<1],enxt[maxn<<1],ew[maxn<<1];
bool inq[maxn];
ll ans=inf,dis[maxn][maxn];

inline void ae(int u,int v,int w){
	++ecnt;
	enxt[ecnt]=ebeg[u];
	ebeg[u]=ecnt;
	eto[ecnt]=v;
	ew[ecnt]=w;
}

int main(){
	!freopen("skd.in","r",stdin);
	!freopen("skd.out","w",stdout);
	!scanf("%d%d%d",&n,&m,&k);
	for(int i=1,u,v,w;i<=m;++i){
		!scanf("%d%d%d",&u,&v,&w);
		ae(u,v,w);
		ae(v,u,w);
	}
	for(int i=2;i<=n;++i)
		dis[i][0]=inf;
	for(int i=0;i<k;++i){
		for(int j=1;j<=n;++j)
			dis[j][i+1]=inf;
		for(int j=1;j<=n;++j)
			if(dis[j][i]!=inf)
				for(int k=ebeg[j];k;k=enxt[k])
					chkmin(dis[eto[k]][i+1],dis[j][i]+ew[k]);
	}
	for(int i=0;i<=k;++i)
		chkmin(ans,dis[n][i]);
	for(int i=1;i<=n;++i)
		dis[i][0]=0;
	for(int i=1;i<=k;++i){
		queue<int> q;
		for(int j=1;j<=n;++j)
			if(dis[j][i]!=inf){
				q.push(j);
				inq[j]=true;
			}
		while(!q.empty()){
			int pos=q.front();q.pop();
			for(int j=ebeg[pos],v;j;j=enxt[j])
				if(dis[v=eto[j]][i]>max_(dis[pos][i],dis[pos][i-1]+ew[j])){
					dis[v][i]=max_(dis[pos][i],dis[pos][i-1]+ew[j]);
					if(!inq[v]){
						q.push(v);
						inq[v]=true;
					}
				}
			inq[pos]=false;
		}
	}
	chkmin(ans,dis[n][k]);
	printf("%lld\n",ans);
	return 0;
}
