#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}
typedef unsigned long long ull;

int main(){
	init();
	freopen("sed.in","w",stdout);
	int n=7;
	unsigned long long a[100],r,x;
	for(int i=1;i<=n;++i){
		for(int j=1;j<i;++j)
			a[i]+=a[j];
		a[i]=f(a[i]+1,a[i]*2);
	}
	r=(ull)rand()<<32|(ull)rand()<<1;
	printf("%d\n",n);
	for(int i=1;i<=n;++i)
		printf("%llu\n",a[i]*r);
	for(int i=1;i<=n;++i)
		if(rand()&1)
			x+=a[i]*r;
	printf("%llu\n",x);
	return 0;
}
