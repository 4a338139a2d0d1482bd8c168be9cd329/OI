#include<bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
const int maxn=1e2;
int n;
ull b[maxn],xxx,a[maxn],r;
__int128 sum[maxn];
char c[maxn];

int main(){
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%llu",&b[i]);
	scanf("%llu",&xxx);
	srand(time(NULL)+clock());
	while(clock()<0.95*CLOCKS_PER_SEC){
		r=(ull)rand()<<63|(ull)rand()<<32|(ull)rand()<<1|1ull;
		ull x=xxx*r;
		for(int i=1;i<=n;++i)
			a[i]=b[i]*r;
		for(int i=1;i<=n;++i)
			sum[i]=sum[i-1]+a[i];
		for(int i=2;i<=n;++i)
			if(a[i]<=sum[i-1])
				goto hell;
		for(int i=n;i;--i)
			if(x>=a[i])
				x-=a[i],c[i]='1';
			else
				c[i]='0';
		if(x)
			goto hell;
		break;
hell:
		;
	}
	printf("%s",c+1);
	return 0;
}
