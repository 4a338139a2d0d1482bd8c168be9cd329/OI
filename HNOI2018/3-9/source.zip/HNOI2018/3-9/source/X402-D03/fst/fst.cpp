#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 30010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, r, K;
int a[MAXN], b[MAXN], c[MAXN];
ll prea[MAXN], preb[MAXN], prec[MAXN];
vector<int> res;

int main() {
	freopen("fst.in", "r", stdin);
	freopen("fst.out", "w", stdout);

	int i, j;
	n = read(), r = read(), K = read();
	generate(a+1, a+n+1, read);
	generate(b+1, b+n+1, read);
	generate(c+1, c+n+1, read);
	for(i = 1; i <= n; i++) prea[i] = prea[i-1]+a[i];
	for(i = 1; i <= n; i++) preb[i] = preb[i-1]+b[i];
	for(i = 1; i <= n; i++) prec[i] = prec[i-1]+c[i];
	if(K == 1) {
		ll ans = 1LL<<60;
		for(i = 1; i < n-r+1; i++) 
			for(j = i+1; j <= n-r+1; j++) 
				ans = min(ans, prea[i-1]+preb[j-1]-preb[i-1]+prec[i+r-1]-prec[j-1]+preb[j+r-1]-preb[i+r-1]+prea[n]-prea[j+r-1]);
		printf("%lld\n", ans);
		return 0;
	}
	for(i = 1; i < n-r+1; i++) 
		for(j = i+1; j <= n-r+1; j++) 
			res.push_back(prea[i-1]+preb[j-1]-preb[i-1]+prec[i+r-1]-prec[j-1]+preb[j+r-1]-preb[i+r-1]+prea[n]-prea[j+r-1]);
	sort(res.begin(), res.end());
	printf("%d\n", res[K-1]);
	return 0;
}
