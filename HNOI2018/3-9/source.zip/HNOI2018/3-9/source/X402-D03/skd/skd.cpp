#include<bits/stdc++.h>
using namespace std;

const int MAXN = 3010, MAXM = 3010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, K;

int st[MAXN], to[MAXN<<1], e;
int nxt[MAXN<<1], w[MAXN<<1];
inline void Add(int u, int v, int W) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e, w[e] = W;
	to[++e] = u, nxt[e] = st[v];
	st[v] = e, w[e] = W;
}

int main() {
	freopen("skd.in", "r", stdin);
	freopen("skd.out", "w", stdout);

	int i;
	n = read(), m = read(), K = read();
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		Add(u, v, read());
	}
	int L = K, R = m;
