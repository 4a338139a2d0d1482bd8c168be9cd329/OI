#include<bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
const int MAXN = 25;

inline ull read() {
	ull x = 0;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) ;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x;
}

int n;
ull b[MAXN], sum;
bool c[MAXN];

void dfs(int u) {
	if(u == n+1) {
		ull res = 0;
		int i;
		for(i = 1; i <= n; i++) res += b[i]*c[i];
		if(res == sum) {
			for(i = 1; i <= n; i++) printf("%d", (int)c[i]);
			exit(0);
		}
		return;
	}
	c[u] = true;
	dfs(u+1);
	c[u] = false;
	dfs(u+1);
}

int main() {
	freopen("sed.in", "r", stdin);
	freopen("sed.out", "w", stdout);

	int i;
	n = read();
	generate(b+1, b+n+1, read);
	sum = read();
	dfs(1);
	return 0;
}
