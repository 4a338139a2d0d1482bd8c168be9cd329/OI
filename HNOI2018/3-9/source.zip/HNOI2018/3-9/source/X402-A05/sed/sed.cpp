#include <bits/stdc++.h>

using std :: cin;

typedef unsigned long long ull;

const int N = 64;

int n;
ull b[N + 5], re;

int main()
{
	freopen("sed.in", "r", stdin);
	freopen("sed.out", "w", stdout);

	scanf("%d", &n);
	for (int i = 0; i < n; ++i) cin >> b[i];
	cin >> re;

	for (int s = 0; s < (1<<n); ++s) {
		ull ret = 0;
		for (int i = 0; i < n; ++i) {
			if ((s >> i) & 1) ret += b[i];
		}
		if (ret == re) {
			for (int i = 0; i < n; ++i) 
				printf("%d", (s>>i) & 1);
			break;
		}
	}
//	assert(false);

	return 0;
}
