#include <bits/stdc++.h>

using std :: pair;
using std :: queue;
using std :: sort;

typedef long long LL;
typedef pair<int, int> pii;

inline int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}
inline bool chkmin(LL &a, LL b)
{
	return a > b? a = b, true : false;
}

const int N = 3e3;
const int M = 6e3;
const LL inf = 1LL << 60;

int n, m, k;

int e, Begin[N + 5];
struct Edge
{
	int from, to, next, w;
	bool operator < (const Edge& rhs) const
	{
		return w > rhs.w;
	}
	void Input()
	{
		from = read(); to = read(); w = read();
	}
}E[M + 5], graph[M + 5];

void AddEdge(int i)
{
	E[++e] = graph[i];
	E[e].next = Begin[E[e].from];
	Begin[E[e].from] = e;
}

queue<pii> q;
bool inq[N + 5][N + 5];

LL dp[N + 5][N + 5];
int num[M + 5];

void exec()
{
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j <= n; ++j) dp[i][j] = inf;
	}
	q.push(pii(1, 0)); dp[1][0] = 0;

	while (!q.empty()) {
		pii o = q.front(); q.pop();
		int u = o.first, ec = o.second;
		if (ec > k) continue;
		inq[u][ec] = false;
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to, _e = num[i];
			if (chkmin(dp[v][ec+_e], dp[u][ec] + _e*E[i].w)) {
				if (!inq[v][ec+_e]) {
					q.push(pii(v, ec+_e));
					inq[v][ec+_e] = true;
				}
			}
		}
	}
}

int main()
{
	freopen("skd.in", "r", stdin);
	freopen("skd.out", "w", stdout);

	n = read(), m = read(), k = read();
	for (int i = 1; i <= m; ++i) {
		graph[i].Input();
	}

	LL ans = inf;
	sort(graph + 1, graph + m + 1);
	for (int i = 1; i <= m; ++i) {
		AddEdge(i);
		std::swap(graph[i].from, graph[i].to);
		AddEdge(i);
	}

	for (int i = 1; i < std::min(k, m); ++i) 
		num[i*2] = num[i*2-1] = 1;
	for (int i = k; i < m; ++i) {
		num[i*2] = num[i*2-1] = 1;
		exec();
		chkmin(ans, dp[n][k]);
	//	std::cerr << dp[n][k] << std::endl;
	}

	num[m*2] = num[m*2-1] = 1;
	exec();
	for (int i = 0; i <= n; ++i) {
		chkmin(ans, dp[n][i]);
	}

	printf("%lld\n", ans);

	return 0;
}
