#include <bits/stdc++.h>

typedef long long LL;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int N = 3e4;

int n, r, kth;
LL A[N + 5];
LL B[N + 5];
LL C[N + 5];

namespace SubTask1
{
	const int N = 1e3;
	using std :: sort;

	LL ans[N * N];
	int tot;

	void main()
	{
		for (int l1 = 1; l1+r-1 <= n; ++l1) {
			for (int l2 = l1+1; l2 <= l1+r-1 && l2+r-1 <= n; ++l2) {
				ans[++tot] = A[l1-1] + B[l2-1]-B[l1-1] + 
					C[l1+r-1] - C[l2-1] + B[l2+r-1]-B[l1+r-1] + A[n]-A[l2+r-1];
			}
		}
		for (int l0 = 1; l0+r-1 <= n; ++l0) {
			for (int l1 = l0+r; l1+r-1 <= n; ++l1)
				ans[++tot] = B[l0+r-1]-B[l0-1] + B[l1+r-1]-B[l1-1]
					+ A[l0-1]-A[0] + A[l1-1]-A[l0+r-1] + A[n]-A[l1+r-1];
		}
	//	std::cerr << tot << std::endl;
		sort(ans + 1, ans + tot + 1);
		printf("%lld\n", ans[kth]);
	}

}

namespace SubTask2
{
	const LL inf = 1LL << 60;
	using std :: min;

	struct SEGT
	{
		#define lc (h << 1)
		#define rc (lc | 1)
		#define mid ((l + r) >> 1)

		LL Mn[(N << 2) + 5];
		SEGT() 
		{
			for (int i = 0; i <= N<<2; ++i) {
				Mn[i] = inf;
			}
		}

		void Insert(int h, int l, int r, int u, LL v)
		{
			Mn[h] = min(v, Mn[h]);
			if (l == r) return ;
			u <= mid? Insert(lc, l, mid, u, v) : Insert(rc, mid + 1, r, u, v);
		}
		
		LL query(int h, int l, int r, int ql, int qr) 
		{
			if (qr < ql) return inf;
			if (ql <= l && r <= qr) return Mn[h];
			return min(ql <= mid? query(lc, l, mid, ql, qr) : inf, 
					qr > mid? query(rc, mid + 1, r, ql, qr) : inf);
		}

		#undef lc
		#undef rc
		#undef mid
	};
	
	SEGT isInsect, notInsect;

	void main()
	{
		LL ans = inf;
		for (int i = 1; i+r-1 <= n; ++i) {
			isInsect.Insert(1, 1, n, i, B[i-1]-C[i-1] + B[i+r-1]-A[i+r-1]);
			notInsect.Insert(1, 1, n, i, B[i+r-1]-B[i-1] + A[i-1]-A[i+r-1]);
		}
		for (int l = 1; l+r <= n; ++l) {
			LL ret = A[l-1]-B[l-1] + C[l+r-1]-B[l+r-1] + A[n];
			ret = ret + isInsect.query(1, 1, n, l+1, l+r-1);
			ans = min(ans, ret);
		}
		for (int l = 1; l+2*r-1 <= n; ++l) {
			LL ret = B[l+r-1]-B[l-1] + A[l-1]-A[l+r-1]+A[n];
			ret = ret + notInsect.query(1, 1, n, l+r, n-r+1);
			ans = min(ans, ret);
		}
		printf("%lld\n", ans);
	}

}

int Init()
{
	n = read(), r = read(), kth = read();
	for (int i = 1; i <= n; ++i) A[i] = A[i-1] + read();
	for (int i = 1; i <= n; ++i) B[i] = B[i-1] + read();
	for (int i = 1; i <= n; ++i) C[i] = C[i-1] + read();
	return kth == 1;
}

int main()
{
	freopen("fst.in", "r", stdin);
	freopen("fst.out", "w", stdout);

	if (!Init()) {
		SubTask1 :: main();
	}
	else {
		SubTask2 :: main();
	}

	return 0;
}
