#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef unsigned long long ULL;
using namespace std;
const int N=100;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
}
int n;
ULL b[N],x;
int main()
{
	file();
	read(n);
	For(i,1,n)read(b[i]);
	read(x);
	For(i,0,(1<<n)-1)
	{
		ULL ret=0;
		For(j,1,n)if(i&(1ll<<(j-1)))ret+=b[j];
		if(ret==x)
		{
			For(j,1,n)printf("%lld",(i>>(j-1))&1ll);
			break;
		}
	}
	return 0;
}
