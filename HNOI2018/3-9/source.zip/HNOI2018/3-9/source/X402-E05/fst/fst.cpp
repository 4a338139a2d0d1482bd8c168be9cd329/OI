#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=30010;
const int M=8000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
}
int n,R,K,tot;
LL a[N],b[N],c[N],len;
LL sa[N],sb[N],sc[N];
int lc[M],rc[M],sum[M];
int rt1[N],rt2[N];
LL w1[N],w2[N];
inline LL Sa(int l,int r){return l>r?0:sa[r]-sa[l-1];}
inline LL Sb(int l,int r){return l>r?0:sb[r]-sb[l-1];}
inline LL Sc(int l,int r){return l>r?0:sc[r]-sc[l-1];}
inline LL Get(int l,int r)
{
	return Sa(1,l-1)+Sa(r+R,n)+
		(l+R<=r?Sb(l,l+R-1)+Sb(r,r+R-1)+Sa(l+R,r-1)
			   :Sb(l,r-1)+Sb(l+R,r+R-1)+Sc(r,l+R-1));
}
inline void insert(int&ret,LL x,int y)
{
	//printf("insert:%lld %d\n",x,y);
	LL l=-len,r=len;int pre=ret;
	ret=++tot;
	int now=ret;
	sum[now]=sum[pre]+y;
	while(l<r)
	{
		LL mid=(l+r)>>1;
		if(x<=mid)
		{
			lc[now]=++tot,rc[now]=rc[pre];
			pre=lc[pre],r=mid;
		}
		else
		{
			lc[now]=lc[pre],rc[now]=++tot;
			pre=rc[pre],l=mid+1;
		}
		sum[now=tot]=sum[pre]+y;
	}
}
inline void print(LL l,LL r,int p)
{
	if(!p)return;
	//printf("(%d %d) %d\n",l,r,sum[p]);
	if(l==r)return;
	LL mid=(l+r)>>1;
	print(ls,lc[p]),print(rs,rc[p]);
}
inline void init()
{
	For(i,2,n-R+1)
	{
		rt1[i]=rt1[i-1],w1[i]=w1[i-1];
		rt2[i]=rt2[i-1],w2[i]=w2[i-1];
		w1[i]+=-c[i-1]+b[i-1]-a[i-1+R]+b[i-1+R];
		w2[i]+=-b[i-1]+a[i-1]-a[i-1+R]+b[i-1+R];
		insert(rt1[i],Get(i-1,i)-w1[i],1);
		//printf("%d %lld %lld\n",i,Get(i-1,i),w1[i]);
		if(i-R>=1)
		{
			insert(rt1[i],Get(i-R,i)-w1[i],-1);
			insert(rt2[i],Get(i-R,i)-w2[i],1);
			//printf("%d: %d %d\n",i,Get(i-R,i)-w2[i],w2[i]);
		}
		//print(-len,len,rt1[i]);
		//print(-len,len,rt2[i]);
	}
	//For(i,1,n)printf("%d %d\n",sum[rt1[i]],sum[rt2[i]]);
}
inline int Query(LL l,LL r,int p,LL x)
{
	if(!p)return 0;
	LL mid=(l+r)>>1;
	if(x<=mid)return Query(ls,lc[p],x);
	else return Query(rs,rc[p],x)+sum[lc[p]];
}
inline int check(LL x)
{
	int ret=0;
	For(i,1,n)
	{
		ret+=x-w1[i]>=1?Query(-len,len,rt1[i],x-w1[i]):0;
		ret+=x-w2[i]>=1?Query(-len,len,rt2[i],x-w2[i]):0;
	}
	//printf("%lld %d\n",x,ret);
	return ret;
}
int main()
{
	LL Max=0;
	file();
	read(n),read(R),read(K);
	For(i,1,n)read(a[i]),sa[i]=sa[i-1]+a[i],chkmax(Max,a[i]);
	For(i,1,n)read(b[i]),sb[i]=sb[i-1]+b[i],chkmax(Max,b[i]);
	For(i,1,n)read(c[i]),sc[i]=sc[i-1]+c[i],chkmax(Max,c[i]);
	len=2ll*n*Max;
	init();
	LL l=0,r=n*Max*2,ans=0;
	while(l<=r)
	{
		LL mid=(l+r)>>1;
		if(check(mid)<K)ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%lld\n",ans);
	//cerr<<tot<<endl;
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
