#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=30010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("fst.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,R,K;
LL a[N],b[N],c[N];
LL sa[N],sb[N],sc[N];
inline LL Sa(int l,int r){return l>r?0:sa[r]-sa[l-1];}
inline LL Sb(int l,int r){return l>r?0:sb[r]-sb[l-1];}
inline LL Sc(int l,int r){return l>r?0:sc[r]-sc[l-1];}
inline LL Get(int l,int r)
{
	return Sa(1,l-1)+Sa(r+R,n)+
		(l+R<=r?Sb(l,l+R-1)+Sb(r,r+R-1)+Sa(l+R,r-1)
			   :Sb(l,r-1)+Sb(l+R,r+R-1)+Sc(r,l+R-1));
}
inline int check(LL x)
{
	int ret=0;
	For(i,1,n)
		For(j,i+1,n-R+1)
			if(Get(i,j)<x)ret++;
	return ret;
}
int main()
{
	LL Max=0;
	file();
	read(n),read(R),read(K);
	For(i,1,n)read(a[i]),sa[i]=sa[i-1]+a[i],chkmax(Max,a[i]);
	For(i,1,n)read(b[i]),sb[i]=sb[i-1]+b[i],chkmax(Max,b[i]);
	For(i,1,n)read(c[i]),sc[i]=sc[i-1]+c[i],chkmax(Max,c[i]);
	LL l=0,r=Max*n,ans=0;
	while(l<=r)
	{
		LL mid=(l+r)>>1;
		if(check(mid)<K)ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%lld\n",ans);
	return 0;
}
