#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 3e4 + 10;

typedef long long LL;

struct Persistent_Segment_Tree {

	const static int NODE = N * 32;

	int lc[NODE], rc[NODE], sum[NODE], node;
	int rt[N];

	#define M ((L + R) >> 1)

	void add(int &o, int ro, int L, int R, int x) {
		o = ++node;
		lc[o] = lc[ro], rc[o] = rc[ro];
		sum[o] = sum[ro] + 1;
		if (L < R) {
			if (x <= M) add(lc[o], lc[ro], L, M, x);
			else add(rc[o], rc[ro], M + 1, R, x);
		}
	}

	int qsum(int o, int L, int R, int l, int r) {
		if (l <= L && R <= r) return sum[o];
		else {
			int ret = 0;
			if (l <= M) ret += qsum(lc[o], L, M, l, r);
			if (r > M) ret += qsum(rc[o], M + 1, R, l, r);
			return ret;
		}
	}

	#undef M

}Ta, Tb;

int n, m, k;
LL A[N], B[N], base;
LL lva[N], rva[N], lvb[N], rvb[N];
LL numa[N], numb[N];
int ca, cb;

int count(LL x) {
	int ret = 0, r;
	LL lim;
	For(i, m, n) {
		lim = x - rva[i];
		r = upper_bound(numa + 1, numa + ca + 1, lim) - numa - 1;
		if (r && i - m * 2 >= 0) 
			ret += Ta.qsum(Ta.rt[i - m * 2 + 1], 1, n - m + 1, 1, r);
		
		lim = x - rvb[i];
		r = upper_bound(numb + 1, numb + cb + 1, lim) - numb - 1;
		if (r)
			ret += Tb.qsum(Tb.rt[i - m], 1, n - m + 1, 1, r) -
				Tb.qsum(Tb.rt[max(0, i - m * 2 + 1)], 1, n - m + 1, 1, r);
	}
	return ret;
}

int main() {

	freopen("fst.in", "r", stdin);
	freopen("fst.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	For(i, 1, n) scanf("%lld", &A[i]), base += A[i];
	For(i, 1, n) scanf("%lld", &B[i]);
	For(i, 1, n) {
		int x;
		scanf("%d", &x);
		A[i] = B[i] - A[i], B[i] = x - B[i];
		A[i] += A[i - 1], B[i] += B[i - 1];
	}
	
	For(i, 0, n - m) lva[i] = A[i + m] - A[i], numa[++ca] = lva[i];
	For(i, m, n) rva[i] = A[i] - A[i - m];
	For(i, 0, n - m) lvb[i] = B[i + m] - A[i], numb[++cb] = lvb[i];
	For(i, m, n) rvb[i] = A[i] - B[i - m];

	sort(numa + 1, numa + ca + 1), ca = unique(numa + 1, numa + ca + 1) - numa - 1;
	sort(numb + 1, numb + cb + 1), cb = unique(numb + 1, numb + cb + 1) - numb - 1;
	For(i, 0, n - m) {
		lva[i] = lower_bound(numa + 1, numa + ca + 1, lva[i]) - numa;
		Ta.add(Ta.rt[i + 1], Ta.rt[i], 1, n - m + 1, lva[i]);
		lvb[i] = lower_bound(numb + 1, numb + cb + 1, lvb[i]) - numb;
		Tb.add(Tb.rt[i + 1], Tb.rt[i], 1, n - m + 1, lvb[i]);
	}

	LL L = 0, R = A[n] + B[n];
	while (L < R) {
		LL mid = (L + R) >> 1;
		if (count(mid) >= k) R = mid;
		else L = mid + 1;
	}
	printf("%lld\n", L + base);

	return 0;
}
