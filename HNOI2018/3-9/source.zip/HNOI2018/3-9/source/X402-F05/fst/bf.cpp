#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 3e3 + 10;

typedef long long LL;

int n, m, k;
LL A[N], B[N], num[N * N], base;
int c;

int main() {

	freopen("fst.in", "r", stdin);
	freopen("fst.ans", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	For(i, 1, n) scanf("%lld", &A[i]), base += A[i];
	For(i, 1, n) scanf("%lld", &B[i]);
	For(i, 1, n) {
		int x;
		scanf("%d", &x);
		A[i] = B[i] - A[i], B[i] = x - B[i];
		A[i] += A[i - 1], B[i] += B[i - 1];
	}

	For(i, 1, n - m) For(j, i + 1, n - m + 1) {
		if (j - i >= m) num[++c] = A[j + m - 1] - A[j - 1] + A[i + m - 1] - A[i - 1];
		else num[++c] = A[j + m - 1] - A[i - 1] + B[i + m - 1] - B[j - 1];
	}
	sort(num + 1, num + c + 1);
	printf("%lld\n", num[k] + base);

	return 0;
}
