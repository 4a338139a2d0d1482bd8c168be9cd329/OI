#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 30010;

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int nxt[N];

int main() {

	freopen("fst.in", "w", stdout);
	srand(time(0));
	int n = 3000, m = randint(1, n / 2), k = randint(1, (n - m) * (n - m - 1) / 2);
	printf("%d %d %d\n", n, m, k);
	For(i, 1, n) printf("%d%c", nxt[i] = randint(nxt[i], nxt[i] + 3.3e8), i == n ? '\n' : ' ');
	For(i, 1, n) printf("%d%c", nxt[i] = randint(nxt[i], nxt[i] + 3.3e8), i == n ? '\n' : ' ');
	For(i, 1, n) printf("%d%c", nxt[i] = randint(nxt[i], nxt[i] + 3.3e8), i == n ? '\n' : ' ');

	return 0;
}
