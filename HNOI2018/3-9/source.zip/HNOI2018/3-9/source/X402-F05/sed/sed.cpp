#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef unsigned long long LL;

const int N = 64;

int n;
LL B[N], sum;

int main() {

	freopen("sed.in", "r", stdin);
	freopen("sed.out", "w", stdout);

	scanf("%d", &n);
	For(i, 0, n - 1) scanf("%llu", &B[i]);
	scanf("%llu", &sum);

	For(i, 0, (1 << n) - 1) {
		LL val = 0;
		For(j, 0, n - 1) if (i & (1 << j)) val += B[j];
		if (val == sum) {
			For(j, 0, n - 1) putchar(i & (1 << j) ? '1' : '0');
			puts("");
			return 0;
		}
	}

	return 0;
}
