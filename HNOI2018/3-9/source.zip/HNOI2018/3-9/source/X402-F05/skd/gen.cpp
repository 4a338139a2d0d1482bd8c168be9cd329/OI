#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

int main() {

	freopen("skd.in", "w", stdout);

	int n = 3000, m = 3000, k = 100;
	printf("%d %d %d\n", n, m, k);
	For(i, 1, m) printf("%d %d %d\n", rand() % n + 1, rand() % n + 1, rand() / 2);
	
	return 0;
}
