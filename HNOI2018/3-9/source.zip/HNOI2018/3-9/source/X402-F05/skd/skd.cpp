#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 3010;

typedef long long LL;

int Begin[N], Next[N << 1], to[N << 1], len[N << 1], e;

void add(int u, int v, int w) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e, len[e] = w;
}

int n, m, k;
int num[N], c;
LL dis[N], ans = 1ll << 60;
bool inq[N];

void SPFA(int lim) {
	memset(dis, 0x3f, sizeof dis);
	queue<int> q;
	q.push(1);
	dis[1] = 0, inq[1] = true;
	while (!q.empty()) {
		int o = q.front(); q.pop();
		inq[o] = false;
		for (int i = Begin[o]; i; i = Next[i]) {
			int u = to[i];
			LL w = dis[o] + max(0, len[i] - lim);
			if (w < dis[u]) {
				dis[u] = w;
				if (!inq[u]) q.push(u), inq[u] = true;
			}
		}
	}
	ans = min(ans, 1ll * k * lim + dis[n]);
}

int main() {

	freopen("skd.in", "r", stdin);
	freopen("skd.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	For(i, 1, m) {
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		add(u, v, w), add(v, u, w);
		num[++c] = w;
	}
	sort(num + 1, num + c + 1);
	c = unique(num + 1, num + c + 1) - num - 1;

	For(i, 0, c) SPFA(num[i]);
	printf("%lld\n", ans);

	return 0;
}
