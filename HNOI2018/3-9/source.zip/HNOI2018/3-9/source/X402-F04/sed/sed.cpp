//2018-3-9
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define ULL unsigned long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (64 + 5)

int n;
ULL m, b[N];
map<ULL, int> ms;

int main(){
	freopen("sed.in", "r", stdin);
	freopen("sed.out", "w", stdout);
	
	scanf("%d", &n);
	For(i, 1, n) scanf("%llu", &b[i]);
	scanf("%llu", &m);
	
	if(n <= 20){
		ULL now;
		For(i, 0, (1 << n) - 1){
			now = 0;
			For(j, 1, n) if(i & (1 << (j - 1))) now += b[j];
			if(now == m){
				For(j, 1, n) if((i & (1 << (j - 1)))) printf("1"); else printf("0");
				puts("");
				return 0;
			}
		}
	}

	ULL now, end = (1llu << n) - 1, sum;

	srand(time(NULL));
	while(true){
		now = rand() % end + 1;
		while(ms.count(now)) now = rand() % end + 1;
		ms[now] = 1;

		sum = 0;
		For(i, 1, n) if(now & (1llu << (i - 1))) sum += b[i];
		if(sum == m){
			For(i, 1, n) if(now & (1llu << (i - 1))) printf("1"); else printf("0");
			puts("");
			return 0;
		}
	}

	return 0;
}
