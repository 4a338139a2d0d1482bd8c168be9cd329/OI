//2018-3-9
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (3000 + 5)

struct node{
	int v, w;
};

LL ans;
int n, m, d, road[N], tmp[N];
bool vis[N];
vector<node> G[N];

LL Calc(int nn){
	For(i, 1, nn) tmp[i] = road[i];
	sort(tmp + 1, tmp + nn + 1, greater<int>());
	
	LL ret = 0;
	For(i, 1, min(nn, d)) ret += tmp[i];
	return ret;
}

#define v G[now][i].v
void Dfs(int now, int dep){
	if(vis[now]) return;
	if(now == n){
		ans = min(ans, Calc(dep - 1)); return;
	}

	vis[now] = true;
	For(i, 0, G[now].size() - 1){
		road[dep] = G[now][i].w;
		Dfs(v, dep + 1);
	}
	vis[now] = false;
}
#undef v

int main(){
	freopen("skd.in", "r", stdin);
	freopen("skd.out", "w", stdout);
	
	int u, v, w;
	
	scanf("%d%d%d", &n, &m, &d);
	For(i, 1, m){
		scanf("%d%d%d", &u, &v, &w);
		G[u].pb((node){v, w}); G[v].pb((node){u, w});
	}

	ans = 1ll << 60;
	Dfs(1, 1);
	printf("%lld\n", ans);

	return 0;
}
