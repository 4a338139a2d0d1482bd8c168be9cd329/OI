//2018-3-9
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (500 + 5)
#define N (30000 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

int In(int l, int r, int o){
	return o >= l && o <= r;
}

int n, d, m, a[N], b[N], c[N];
LL num[M * M];

void Bf(){
	int l1, r1, l2, r2, t1, t2, nn = 0;
	LL now;

	For(s1, 1, n - d + 1) For(s2, s1 + 1, n - d + 1){
		now = 0;
		l1 = s1, r1 = l1 + d - 1;
		l2 = s2, r2 = l2 + d - 1;	    

		For(i, 1, n){
			t1 = In(l1, r1, i); t2 = In(l2, r2, i);
			if(t1 && t2) now += c[i];
			else if(t1 ^ t2) now += b[i];
			else now += a[i];
		}
		
		num[++nn] = now;
	}
	sort(num + 1, num + nn + 1);

	printf("%lld\n", num[m]);
}

void Cheat(){
	LL ans = 1ll << 60, now;
	int l1, r1, l2, r2, t1, t2;

	For(s1, 1, n - d + 1){
		if((s1 + d - 1) + d - 1 > n) break;
		l1 = s1, r1 = l1 + d - 1;
		l2 = s1 + 1, r2 = l2 + d - 1;
		
		now = 0;
		For(i, 1, n){
			t1 = In(l1, r1, i); t2 = In(l2, r2, i);
			if(t1 && t2) now += c[i];
			else if(t1 ^ t2) now += b[i];
			else now += a[i];
		}
		ans = min(ans, now);

		For(s2, s1 + 2, n - d + 1){
			now += b[s2 + d - 1] - a[s2 + d - 1];
			if(In(l1, r1, s2 - 1)) now += b[s2 - 1] - c[s2 - 1];
			else now += a[s2 - 1] - b[s2 - 1];
			ans = min(ans, now);
		}
	}

	printf("%lld\n", ans);
}

int main(){
	freopen("fst.in", "r", stdin);
	freopen("fst.out", "w", stdout);
	
	Read(n), Read(d), Read(m);
	For(i, 1, n) Read(a[i]);
	For(i, 1, n) Read(b[i]);
	For(i, 1, n) Read(c[i]);

	if(n <= 500){Bf(); return 0;}
	if(m == 1){Cheat(); return 0;}

	return 0;
}
