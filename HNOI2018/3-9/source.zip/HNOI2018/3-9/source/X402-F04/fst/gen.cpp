//2018-3-9
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int main(){
	freopen("fst.in", "w", stdout);

	int n = 30000, r = rand() % 2000 + 1, m = rand() % 100 + 5;
	int V = 100000;

	srand(time(NULL));
	printf("%d %d %d\n", n, 1, 1);
	For(i, 1, n) printf("%d ", rand() % V + 1); puts("");
	For(i, 1, n) printf("%d ", rand() % V + 1); puts("");
	For(i, 1, n) printf("%d ", rand() % V + 1); puts("");

	return 0;
}
