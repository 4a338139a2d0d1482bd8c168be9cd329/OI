#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=30009;
const ll M=1e11;

int n,r,k,rt;
ll a[N],b[N],c[N],db[N],dc[N],f[N],ans;
priority_queue<ll,vector<ll>,greater<ll> > q;

inline void chkmin(ll &a,ll b){if(a>b)a=b;}

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

namespace segt
{
	int ls[N*60],rs[N*60],t[N*60],tot;

	inline void init()
	{
		rt=tot=0;
	}

	inline int newnode()
	{
		int ret=++tot;ls[ret]=rs[ret]=t[ret]=0;return ret;
	}

	inline void modify(int &x,ll l,ll r,ll p,int v)
	{
		if(!x)x=newnode();ll mid=l+r>>1;
		t[x]+=v;if(l==r)return;
		if(p<=mid)modify(ls[x],l,mid,p,v);
		else modify(rs[x],mid+1,r,p,v);
	}

	inline ll query(int x,ll l,ll r,ll dl,ll dr)
	{
		if(dl>dr || (!x))return 0;ll mid=l+r>>1;
		if(dl==l && r==dr)return t[x];
		if(dr<=mid)return query(ls[x],l,mid,dl,dr);
		if(mid<dl)return query(rs[x],mid+1,r,dl,dr);
		return query(ls[x],l,mid,dl,mid)+query(rs[x],mid+1,r,mid+1,dr);
	}
}

namespace guo
{
	int p[N],q[N],lb,rb;
	
	inline ll g(int x)
	{
		return a[n]+db[x+r-1]-db[x-1];
	}

	ll count(ll v)
	{
		ll ret=0;
		
		segt::init();
		segt::modify(rt,0,M,g(1)-db[r]+dc[r],1);
		for(int i=2;i<=n-r+1;i++)
		{
			if(i>r)segt::modify(rt,0,M,g(i-r)-db[i-1]+dc[i-1],-1);
			ret+=segt::query(rt,0,M,0,v+dc[i-1]-db[i+r-1]);
			segt::modify(rt,0,M,g(i)-db[i+r-1]+dc[i+r-1],1);
		}

		segt::init();
		segt::modify(rt,0,M,db[r]-db[0]+a[n],1);
		for(int i=r+1;i<=n-r+1;i++)
		{
			ret+=segt::query(rt,0,M,0,v-db[i+r-1]+db[i-1]);
			segt::modify(rt,0,M,db[i]-db[i-r]+a[n],1);
		}

		return ret;
	}
}

int main()
{
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);

	n=read();r=read();k=read();
	for(int i=1;i<=n;i++)a[i]=(ll)read()+a[i-1];
	for(int i=1;i<=n;i++)b[i]=(ll)read()+b[i-1];
	for(int i=1;i<=n;i++)c[i]=(ll)read()+c[i-1];
	for(int i=1;i<=n;i++)db[i]=b[i]-a[i];
	for(int i=1;i<=n;i++)dc[i]=c[i]-b[i];

	ll l=0,r=c[n],mid,ans=0,tmp;
	while(l<=r)
	{
		mid=l+r>>1;
		if((tmp=guo::count(mid))<k)
			l=mid+1;
		else ans=mid,r=mid-1;
	}
	
	printf("%lld\n",ans);
	return 0;
}


