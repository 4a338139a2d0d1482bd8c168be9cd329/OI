#include<bits/stdc++.h>
using namespace std;
int main(){
	unsigned long long x=1;
	cerr<<(x<<63)<<endl;
	return 0;
}
