#include<bits/stdc++.h>
using namespace std;
const int maxn=110;
#define ull unsigned long long
ull b[maxn];
ull v;
bool c[maxn];
int n;
void dfs(int p,ull sum){
	if(p>n){
		if(sum==v){
			for(int i=1;i<=n;i++)
				printf("%d",c[i]);
			printf("\n");
			exit(0);
		}
		return;
	}
	c[p]=1;
	dfs(p+1,sum+b[p]);
	c[p]=0;
	dfs(p+1,sum);
}
int main(){
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%llu",&b[i]);
	scanf("%llu",&v);
	dfs(1,0);
	return 0;
}
