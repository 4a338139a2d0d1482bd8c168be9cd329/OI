#include<bits/stdc++.h>
using namespace std;
const int maxn=110;
#define ull unsigned long long
ull b[maxn];
ull v;
int n;
namespace M{
	bool c[maxn];
	void dfs(int p,ull sum){
		if(p>n){
			if(sum==v){
				for(int i=1;i<=n;i++)
					printf("%d",c[i]);
				printf("\n");
				exit(0);
			}
			return;
		}
		c[p]=1;
		dfs(p+1,sum+b[p]);
		c[p]=0;
		dfs(p+1,sum);
	}
}
map<ull,ull> mp;
void dfs_ycl(int p,ull sum,ull x){
	if(p>n/2){
		mp[sum]=x;
		return;
	}
	dfs_ycl(p+1,sum+b[p],x|(((ull)1)<<(p-1)));
	dfs_ycl(p+1,sum,x);
}
void dfs_getans(int p,ull sum,ull x){
	if(p>n){
		if(sum==v){
			ull y=x;
			for(int i=0;i<n;i++)
				printf("%llu",(y>>i)&1);
			exit(0);
		}
		if(mp[v-sum]){
			ull y=x;
			y|=mp[v-sum];
			for(int i=0;i<n;i++)
				printf("%llu",(y>>i)&1);
			exit(0);
		}
		return;
	}
	dfs_getans(p+1,sum+b[p],x|(((ull)1)<<(p-1)));
	dfs_getans(p+1,sum,x);
}
void solve1(){
	dfs_ycl(1,0,0);
	dfs_getans(n/2+1,0,0);
}
ull powd(ull x,ull y){
	ull res=1;
	while(y){
		if(y&1) res=res*x;
		x=x*x;
		y>>=1;
	}
	return res;
}
const ull MAX=((ull)1)<<63;
void printans(ull *c){
	static bool d[maxn];
	for(int i=n;i>=1;i--){
		if(c[i]<=v){
			d[i]=1;
			v-=c[i];
		}
		else
			d[i]=0;
	}
	for(int i=1;i<=n;i++)
		printf("%d",d[i]);
}
void solve2(){
	static ull c[maxn];
	ull y=b[1],st;

	int cnt=0;
	while(y%2==0) y>>=1,cnt++;
	ull x=powd(b[1]>>cnt,MAX);
	ull sum;
	for(int i=1;i<(1<<20);i++){
		if(cnt){
			st=(i>>cnt);
			y=(x*st)^((i&(((((ull)1)<<cnt)-1)))<<(64-cnt));
		}
		else
			y=x*((ull)i);
		for(int j=1;j<=n;j++)
			c[j]=b[j]*y;
		sum=0;
		bool bo=1;
		for(int j=1;j<=n;j++){
			if(-c[j]<=sum){
				bo=0;
				break;
			}
			if(c[j]<=sum){
				bo=0;
				break;
			}
			sum+=c[j];
		}
		if(bo){
			printans(c);
			return;
		}
	}
}
int main(){
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%llu",&b[i]);
	scanf("%llu",&v);
	if(n<=20){
		M::dfs(1,0);
		return 0;
	}
	if(n<=44)
		solve1();
	else
		solve2();
	return 0;
}
