#include<bits/stdc++.h>
using namespace std;
const int maxn=30010;
const long long maxv=1e11;
#define mid ((l+r)>>1)
int a[maxn],b[maxn],c[maxn];
struct node{
	int l,r,v;
}tr[maxn*100];
int num;
int Query(int h,long long l,long long r,long long s,long long t){
	if(!h) return 0;
	if(s<=l&&r<=t) return tr[h].v;
	if(t<=mid) return Query(tr[h].l,l,mid,s,t);
	else if(s>mid) return Query(tr[h].r,mid+1,r,s,t);
	else
		return Query(tr[h].l,l,mid,s,mid)+Query(tr[h].r,mid+1,r,mid+1,t);
}
void Insert(int h1,int &h2,long long l,long long r,long long p){
	h2=++num;
	tr[h2]=tr[h1];
	tr[h2].v++;
	if(l==r) return;
	if(p<=mid) Insert(tr[h1].l,tr[h2].l,l,mid,p);
	else Insert(tr[h1].r,tr[h2].r,mid+1,r,p);
}
int rt1[maxn],rt2[maxn];
int n,r;
long long sumc[maxn],sumd[maxn],sumb[maxn];
long long solve(long long s){
	long long res=0;
	for(int i=1;i<=n-r;i++){
		if(i+r-1>=n-r+1){
			res+=Query(rt2[n-r+1],-maxv,maxv,-maxv,s-(sumc[i]-sumd[i]));
			res-=Query(rt2[i],-maxv,maxv,-maxv,s-(sumc[i]-sumd[i]));
		}
		else{
			res+=Query(rt2[i+r-1],-maxv,maxv,-maxv,s-(sumc[i]-sumd[i]));
			res-=Query(rt2[i],-maxv,maxv,-maxv,s-(sumc[i]-sumd[i]));
			res+=Query(rt1[n-r+1],1,maxv,1,s-sumb[i]);
			res-=Query(rt1[i+r-1],1,maxv,1,s-sumb[i]);
		}
	}
	return res;
}
int main(){
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
	long long ans=0,k;
	scanf("%d%d%lld",&n,&r,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		ans+=a[i];
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&b[i]);
		b[i]-=a[i];
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&c[i]);
		c[i]-=a[i];
	}

	for(int i=1;i<r;i++){
		sumc[0]+=c[i];
		sumb[0]+=b[i];
	}
	for(int i=1;i<=n-r+1;i++){
		sumc[i]=sumc[i-1]+c[i+r-1]-c[i-1];
		sumb[i]=sumb[i-1]+b[i+r-1]-b[i-1];
	}

	for(int i=1;i<=n-r+1;i++)
		Insert(rt1[i-1],rt1[i],1,maxv,sumb[i]);
	for(int i=1;i<=n-r+1;i++){
		sumd[i]=sumd[i-1]+b[i+r-1]-c[i-1]+b[i-1];
		Insert(rt2[i-1],rt2[i],-maxv,maxv,sumd[i]);
	}
	long long L=0,R=maxv;
	while(R-L>1){
		if(solve((R+L)>>1)>=k) R=(R+L)>>1;
		else L=(R+L)>>1;
	}
	printf("%lld\n",R+ans);
	return 0;
}
