#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxn=100100;
const int maxv=300000;
int a[maxn],b[maxn];
void solve(){
	int n,r,k;
	n=300,r=rand()%(n-1)+1,k=rand()%((n-r+1)*(n-r)/2)+1;
	printf("%d %d %d\n",n,r,k);
	for(int i=1;i<=n;i++){
		a[i]=rand()%maxv+1;
		printf("%d ",a[i]);
	}
	printf("\n");
	for(int i=1;i<=n;i++){
		b[i]=rand()%maxv+1+a[i];
		printf("%d ",b[i]);
	}
	printf("\n");
	for(int i=1;i<=n;i++)
		printf("%d ",b[i]+rand()%maxv+1);
	printf("\n");
}
int main(){
	srand(time(0)+getx());
	freopen("fst.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
