#include<bits/stdc++.h>
using namespace std;
const int maxn=1001000;
int a[maxn],b[maxn],c[maxn];
int cnt[maxn];
int stk[maxn],top;
int main(){
	freopen("fst.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int n,r,k;
	scanf("%d%d%d",&n,&r,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	int sum;
	for(int i=1;i<=n-r;i++){
		for(int j=i;j<i+r;j++)
			cnt[j]++;
		for(int j=i+1;j<=n-r+1;j++){
			for(int l=j;l<j+r;l++)
				cnt[l]++;

			sum=0;
			for(int l=1;l<=n;l++){
				if(cnt[l]==0) sum+=a[l];
				else if(cnt[l]==1) sum+=b[l];
				else sum+=c[l];
			}
			stk[++top]=sum;

			for(int l=j;l<j+r;l++)
				cnt[l]--;
		}
		for(int j=i;j<i+r;j++)
			cnt[j]--;
	}
	sort(stk+1,stk+top+1);
	printf("%d\n",stk[k]);
	cerr<<stk[k]<<endl;
	return 0;
}
