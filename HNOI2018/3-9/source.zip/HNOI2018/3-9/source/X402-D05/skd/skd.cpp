#include<bits/stdc++.h>
using namespace std;
const int maxn=10010;
const long long INF=1e16;
void chkmin(long long &x,long long y){
	x=x<y?x:y;
}
int n,m;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],w[maxn<<1],e;
void putin(int s,int t,int v){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=v;
}
struct Edge{
	int s,t,v;
}edge[maxn];
bool cmp(const Edge &A,const Edge &B){
	return A.v<B.v;
}
int f[maxn];
int fa(int x){
	if(f[x]==x) return x;
	return f[x]=fa(f[x]);
}
void clear_graph(){
	e=0;
	for(int i=1;i<=n;i++)
		beg[i]=0;
}
void Build_graph(){
	clear_graph();
	for(int i=1;i<=m;i++){
		putin(fa(edge[i].s),fa(edge[i].t),edge[i].v);
		putin(fa(edge[i].t),fa(edge[i].s),edge[i].v);
	}
}
struct node{
	int cnt;
	long long sum;
};
bool operator < (const node &A,const node &B){
	return A.sum>B.sum;
}
priority_queue<node> q;
node dij(){
	static bool vis[maxn];
	static int d[maxn];
	static long long dis[maxn];
	while(!q.empty()) q.pop();
	for(int i=1;i<=n;i++)
		dis[i]=INF,d[i]=0,vis[i]=0;
	dis[1]=0,d[1]=0;
	q.push((node){1,0});
	node st;
	while(!q.empty()){
		st=q.top();
		q.pop();
		if(vis[st.cnt]) continue;
		vis[st.cnt]=1;
		for(int i=beg[st.cnt];i;i=nex[i]){
			if(st.sum+w[i]<dis[tto[i]]){
				dis[tto[i]]=st.sum+w[i];
				d[tto[i]]=d[st.cnt]+1;
				q.push((node){tto[i],dis[tto[i]]});
			}
		}
	}
	return (node){d[n],dis[n]};
}
int main(){
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);
	int k;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		f[i]=i;
	for(int i=1;i<=m;i++)
		scanf("%d%d%d",&edge[i].s,&edge[i].t,&edge[i].v);
	sort(edge+1,edge+m+1,cmp);
	Build_graph();
	long long ans=dij().sum;
	for(int i=1;i<=m;i++){
		f[fa(edge[i].s)]=fa(edge[i].t);
		Build_graph();
		if(dij().cnt>=k)
			chkmin(ans,dij().sum);
	}
	printf("%lld\n",ans);
	return 0;
}
