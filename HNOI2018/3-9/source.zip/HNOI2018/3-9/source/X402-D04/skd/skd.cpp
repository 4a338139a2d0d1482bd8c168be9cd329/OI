#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
typedef long long ll;
const int maxn=3010;
const ll inf=1e18;
int n, m, k;
vector<int> g[maxn], w[maxn];
ll suf[maxn];

void chkmin(ll& x,ll y){ if(x>y) x=y; }

struct node{
	int u, v, z;
	bool operator <(const node& A)const{ return z<A.z; }
	void init(){ 
		scanf("%d%d%d", &u, &v, &z); 
	}
}e[maxn];

int fa[maxn];
int find(int x){ return x==fa[x] ? x : fa[x]=find(fa[x]); }

ll dis[maxn][maxn]; int inq[maxn][maxn];
void spfa(){
	for(int i=1;i<=n;i++) for(int j=0;j<=k+1;j++) dis[i][j]=inf, inq[i][j]=0;
	queue<pii> q;
	int st=find(1);
	q.push(make_pair(st,0)); dis[st][0]=0;
	while(!q.empty()){
		pii pi=q.front(); q.pop();
		int u=pi.fi, d=pi.se; u=find(u); inq[u][d]=0;
		// printf("u = %d %d %lld\n", u, d, dis[u][d]);
		if(d>=k) continue;
		for(int i=0;i<g[u].size();i++){
			int v=g[u][i]; v=find(v);
			if(dis[v][d+1]>dis[u][d]+w[u][i]){
				dis[v][d+1]=dis[u][d]+w[u][i];
				if(!inq[v][d+1]) inq[v][d+1]=1, q.push(make_pair(v,d+1));
			}
		}
	}
}
ll ans;
void solve(int x){
	// printf("x = %d\n", x);
	for(int i=1;i<=n;i++) fa[i]=i;
	for(int i=1;i<=x;i++){
		int u=e[i].u, v=e[i].v;
		u=find(u), v=find(v);
		fa[v]=u;
	}
	for(int i=1;i<=n;i++) g[i].clear(), w[i].clear();
	// for(int i=1;i<=n;i++) printf("%d ", fa[i]); puts("");
	for(int i=1;i<=m;i++){
		int u=e[i].u, v=e[i].v, z=e[i].z; u=find(u), v=find(v);
		if(u==v) continue;
		// printf("%d - %d\n", u, v);
		g[u].push_back(v), g[v].push_back(u);
		w[u].push_back(z), w[v].push_back(z);
	}
	spfa();
	// for(int i=1;i<=k;i++) printf("%lld ", dis[find(n)][i]); puts("");
	for(int i=0;i<=min(x,k);i++){
		// printf("%lld %lld\n", suf[x+1], dis[find(n)][k]);
		chkmin(ans, suf[x-i+1]-suf[x+1]+dis[find(n)][k-i]);
	}
	if(!x){
		for(int i=0;i<=k;i++) chkmin(ans, dis[find(n)][i]);
	}
}

bool check(int x){
	solve(x);
	for(int i=1;i<=k;i++) if(dis[find(n)][i]<inf) return true;
	return false;
}

void solve1(){
	/*
		solve(0);
		cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
		printf("%lld\n", ans); return ;
	*/
	int T=3000/k;
	int lst=0;
	for(int kase=1;kase<=T;kase++){
		if(1.0*clock()/CLOCKS_PER_SEC>=0.90){ printf("%lld\n", ans); return; }
		// int del=kase==T ? (int)(1.0*(rand()%INT_MAX)/INT_MAX/T) : m; 
		// cerr<<del<<endl;
		// cerr<<rand()/INT_MAX<<endl;
		int l=lst, r=min(m,l+m/T), ret=0;
		// cerr<<l<<' '<<r<<endl;
		lst=r;
		while(l<=r){
			if(1.0*clock()/CLOCKS_PER_SEC>=min(0.80,0.95-1.0*k/3000)){ solve(0); printf("%lld\n", ans); 
		// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
				return; }
			int mid=(l+r)>>1;
			// cerr<<mid<<endl;
			if(check(mid)) r=mid-1, ret=mid;
			else l=mid+1;
		}
		// printf("%lld\n", dis[find(n)][3]);
		// printf("ret = %d\n", ret);
	}
	// for(int i=max(0,ret-10);i<=min(m,ret+10);i++) solve(i);
	printf("%lld\n", ans);
}

int main(){
	freopen("skd.in","r",stdin),freopen("skd.out","w",stdout);

	srand(time(0));
	scanf("%d%d%d", &n, &m, &k);
	for(int i=1;i<=m;i++) e[i].init();
	sort(e+1,e+1+m);
	for(int i=m;i>=1;i--) suf[i]=suf[i+1]+e[i].z;
	// for(int i=1;i<=m;i++) printf("%lld ", suf[i]); puts("");
	/*
	ans=1e18;
	solve1(); 
	*/
	ans=1e18;
	if(n>500){ solve1(); return 0; }
	ll pre=ans;
	for(int i=0;i<=m;i++){
		pre=ans;
		solve(i);
		// if(ans!=pre) printf("%d %lld\n", i, ans);
		// printf("ans = %lld\n", ans);
	}
	printf("%lld\n", ans);
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
