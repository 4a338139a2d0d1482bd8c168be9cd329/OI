#include<bits/stdc++.h>
using namespace std;

const int maxn=3010;
const int mod=1e9;
int n, m, k;

int g[maxn][maxn];

int main(){
	freopen("skd1.in","w",stdout);

	srand(time(0));
	printf("%d %d %d\n", n=2500, m=3000, k=200);
	m-=n-1;
	for(int i=1;i<n;i++) printf("%d %d %d\n", i, i+1, rand()%mod);
	for(int i=1;i<=m;i++){
		int u=rand()%n+1, v=rand()%n+1;
		while(g[u][v] || u==v) u=rand()%n+1, v=rand()%n+1;
		g[u][v]=g[v][u]=1;
		printf("%d %d %d\n", u, v, rand()%mod);
	}
	return 0;
}
