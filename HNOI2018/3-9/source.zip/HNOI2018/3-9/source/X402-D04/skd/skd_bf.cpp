#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
typedef long long ll;
const int maxn=3010;
const ll inf=1e18;
int n, m, k;
vector<int> g[maxn], w[maxn];
ll suf[maxn];

void chkmin(ll& x,ll y){ if(x>y) x=y; }

struct node{
	int u, v, z;
	bool operator <(const node& A)const{ return z<A.z; }
	void init(){ 
		scanf("%d%d%d", &u, &v, &z); 
	}
}e[maxn];

int fa[maxn];
int find(int x){ return x==fa[x] ? x : fa[x]=find(fa[x]); }

ll dis[maxn][maxn]; int inq[maxn][maxn];
void spfa(){
	for(int i=1;i<=n;i++) for(int j=0;j<=k+1;j++) dis[i][j]=inf, inq[i][j]=0;
	queue<pii> q;
	int st=find(1);
	q.push(make_pair(st,0)); dis[st][0]=0;
	while(!q.empty()){
		pii pi=q.front(); q.pop();
		int u=pi.fi, d=pi.se; u=find(u);
		// printf("u = %d %d %lld\n", u, d, dis[u][d]);
		if(d>=k) continue;
		for(int i=0;i<g[u].size();i++){
			int v=g[u][i]; v=find(v);
			if(dis[v][d+1]>dis[u][d]+w[u][i]){
				dis[v][d+1]=dis[u][d]+w[u][i];
				if(!inq[v][d+1]) inq[v][d+1]=1, q.push(make_pair(v,d+1));
			}
		}
	}
}
ll ans;
void solve(int x){
	// printf("x = %d\n", x);
	for(int i=1;i<=n;i++) fa[i]=i;
	for(int i=1;i<=x;i++){
		int u=e[i].u, v=e[i].v;
		u=find(u), v=find(v);
		fa[v]=u;
	}
	for(int i=1;i<=n;i++) g[i].clear(), w[i].clear();
	// for(int i=1;i<=n;i++) printf("%d ", fa[i]); puts("");
	for(int i=1;i<=m;i++){
		int u=e[i].u, v=e[i].v, z=e[i].z; u=find(u), v=find(v);
		if(u==v) continue;
		// printf("%d - %d\n", u, v);
		g[u].push_back(v), g[v].push_back(u);
		w[u].push_back(z), w[v].push_back(z);
	}
	spfa();
	// for(int i=1;i<=k;i++) printf("%lld ", dis[find(n)][i]); puts("");
	for(int i=0;i<=min(x,k);i++){
		// printf("%lld %lld\n", suf[x+1], dis[find(n)][k]);
		chkmin(ans, suf[x-i+1]-suf[x+1]+dis[find(n)][k-i]);
	}
	if(!x){
		for(int i=0;i<=k;i++) chkmin(ans, dis[find(n)][i]);
	}
}

int main(){
	freopen("skd.in","r",stdin),freopen("skd.out","w",stdout);

	scanf("%d%d%d", &n, &m, &k);
	for(int i=1;i<=m;i++) e[i].init();
	sort(e+1,e+1+m);
	for(int i=m;i>=1;i--) suf[i]=suf[i+1]+e[i].z;
	// for(int i=1;i<=m;i++) printf("%lld ", suf[i]); puts("");
	ans=1e18;
	for(int i=0;i<=m;i++){
		solve(i);
		// printf("ans = %lld\n", ans);
	}
	printf("%lld\n", ans);
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
