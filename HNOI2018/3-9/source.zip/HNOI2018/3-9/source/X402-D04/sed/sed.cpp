#include<bits/stdc++.h>
using namespace std;

const int maxn=100;
typedef long long ll;
int n;
ll a[maxn], c;
int use[maxn];

int main(){
	freopen("sed.in","r",stdin),freopen("sed.out","w",stdout);

	scanf("%d", &n);
	for(int i=1;i<=n;i++) scanf("%lld\n", &a[i]);
	scanf("%lld\n", &c);
	for(int i=0;i<(1<<n);i++){
		for(int j=1;j<=n;j++) if(i & (1<<(j-1))) use[j]=1; else use[j]=0;
		ll t=0;
		for(int j=1;j<=n;j++) if(use[j]) t+=a[j];
		if(t==c){
			for(int j=1;j<=n;j++) printf("%d", use[j]);
			return 0;
		}
	}
	return 0;
}
