#include<bits/stdc++.h>
using namespace std;

const int maxn=30010;
const int mod=100000;
int n, r, k;
int a[maxn];

int main(){
	freopen("fst.in","w",stdout);

	printf("%d %d %d\n", n=30000, r=1, k=1);
	for(int i=1;i<=n;i++){
		printf("%d ", a[i]=rand()%mod);
	}
	puts("");
	for(int i=1;i<=n;i++){
		printf("%d ", a[i]+=rand()%mod);
	}
	puts("");
	for(int i=1;i<=n;i++){
		printf("%d ", a[i]+=rand()%mod);
	}
	return 0;
}
