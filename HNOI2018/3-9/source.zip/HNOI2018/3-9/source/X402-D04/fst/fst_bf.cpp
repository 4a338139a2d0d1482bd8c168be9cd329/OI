#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=30010;
int n, r, k;
int a[maxn][5];
int cnt[maxn], tot;
ll ans[maxn*100];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

void solve(){
	
}

int main(){
	freopen("fst.in","r",stdin),freopen("fst.out","w",stdout);

	read(n), read(r), read(k);
	for(int i=1;i<=n;i++) read(a[i][0]);
	for(int i=1;i<=n;i++) read(a[i][1]);
	for(int i=1;i<=n;i++) read(a[i][2]);
	if(n>500 && k==1){ solve(); return 0; }
	for(int i=1;i<n-r+1;i++) for(int j=i+1;j<=n-r+1;j++){
		for(int l=0;l<r;l++) cnt[i+l]++;
		for(int l=0;l<r;l++) cnt[j+l]++;
		ll t=0;
		for(int l=1;l<=n;l++) t+=a[l][ cnt[l] ];
		ans[++tot]=t;
		for(int l=1;l<=n;l++) cnt[l]=0;
	}
	sort(ans+1,ans+1+tot);
	printf("%lld\n", ans[k]);
	return 0;
}
