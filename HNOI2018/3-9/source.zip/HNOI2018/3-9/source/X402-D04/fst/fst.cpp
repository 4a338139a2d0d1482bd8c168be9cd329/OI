#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=30010;
int n, r, k;
int a[maxn][5];
int cnt[maxn], tot;
ll ans[maxn*100];
ll A[maxn], B[maxn], C[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(ll& x,ll y){ if(x>y) x=y; }

ll Ans;
void solve(){
	Ans=1e18;
	for(int i=1;i<=n;i++) A[i]=A[i-1]+a[i][0], B[i]=B[i-1]+a[i][1]-a[i][0], C[i]=C[i-1]+(a[i][2]-a[i][0])-2*(a[i][1]-a[i][0]);
	// for(int i=1;i<=n;i++) printf("%lld ", B[i]); puts("");
	for(int i=1;i<n-r+1;i++) for(int j=i+1;j<=n-r+1;j++){
		int l1=i, r1=i+r-1, l2=j, r2=j+r-1;
		ll tot=B[r1]-B[l1-1]+B[r2]-B[l2-1];
	 	// printf("%d %d %lld\n", i, j, tot);
		if(r1>=l2) tot+=C[r1]-C[l2-1];
		chkmin(Ans, tot);
	}
	printf("%lld\n", Ans+A[n]);
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
}

int main(){
	freopen("fst.in","r",stdin),freopen("fst.out","w",stdout);

	read(n), read(r), read(k);
	for(int i=1;i<=n;i++) read(a[i][0]);
	for(int i=1;i<=n;i++) read(a[i][1]);
	for(int i=1;i<=n;i++) read(a[i][2]);
	if(n>500 && k==1){ solve(); return 0; }
	for(int i=1;i<n-r+1;i++) for(int j=i+1;j<=n-r+1;j++){
		for(int l=0;l<r;l++) cnt[i+l]++;
		for(int l=0;l<r;l++) cnt[j+l]++;
		ll t=0;
		for(int l=1;l<=n;l++) t+=a[l][ cnt[l] ];
		ans[++tot]=t;
		for(int l=1;l<=n;l++) cnt[l]=0;
	}
	sort(ans+1,ans+1+tot);
	printf("%lld\n", ans[k]);
	return 0;
}
