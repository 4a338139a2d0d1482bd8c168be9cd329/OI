#include<bits/stdc++.h>
#define rg register
#define sz size
#define pb push_back
#define ll long long
const int N=3e4+10;
const ll inf=1e18;
using namespace std;

int n,r,k;
ll prea[N],preb[N],prec[N],sufa[N];
int a[N],b[N],c[N];
vector<ll> vec;

namespace solver{
	inline int read(){
		char ch=getchar();
		int x(0);
		while(!isdigit(ch))ch=getchar();
		while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
		return x;
	}
	void solve(){
		freopen("fst.in","r",stdin);
		freopen("fst.out","w",stdout);
		n=read();r=read();k=read();
		for(int i=1;i<=n;++i)a[i]=read(),prea[i]=prea[i-1]+a[i];
		for(int i=n;i>=1;--i)sufa[i]=sufa[i+1]+a[i];
		for(int i=1;i<=n;++i)b[i]=read(),preb[i]=preb[i-1]+b[i];
		for(int i=1;i<=n;++i)c[i]=read(),prec[i]=prec[i-1]+c[i];
		if(k==1){
			ll ans=inf;
			for(rg int i=1;i+r-1<=n;++i)
			  	for(rg int j=i+1;j+r-1<=n;++j){
					ll ret=0;
					if(j<=i+r-1){
						ret=prea[i-1]+sufa[j+r]+
						preb[j-1]-preb[i-1]+preb[j+r-1]-preb[i+r-1]+
			  			+prec[i+r-1]-prec[j-1];
					}
					else{
						ret=prea[i-1]+sufa[j+r]+
						+preb[j+r-1]-preb[j-1]+preb[i+r-1]-preb[i-1];
						+prea[j-1]-prea[i+r-1];
					}
					ans=ans<ret?ans:ret;
				}
			printf("%lld\n",ans);
		} 
		if(k!=1){
			int sz=0;
			for(rg int i=1;i+r-1<=n;++i)
			  	for(rg int j=i+1;j+r-1<=n;++j){
					ll ret=0;
					if(j<=i+r-1){
						ret=prea[i-1]+sufa[j+r]+
						preb[j-1]-preb[i-1]+preb[j+r-1]-preb[i+r-1]+
			  			+prec[i+r-1]-prec[j-1];
					}
					else{
						ret=prea[i-1]+sufa[j+r]+
						+preb[j+r-1]-preb[j-1]+preb[i+r-1]-preb[i-1];
						+prea[j-1]-prea[i+r-1];
					}
					vec.pb(ret);
				}
			sort(vec.begin(),vec.end());
			printf("%lld\n",vec[k-1]);
		}
	}			
}

int main(){
	solver::solve();
}
