#include<bits/stdc++.h>
#define pb push_back
#define sz size
#define re register
#define lim mm
using namespace std;
const int N=5e2+10;
int n,m,e,k;
int bgn[N],nxt[N<<1],to[N<<1],w[N<<1];
int f[N][N],vis[N],g[N][N][N];
queue<int> q;
vector<int> vec;

namespace solver{
	inline int read(){
		char ch=getchar();
		int x(0);
		while(!isdigit(ch))ch=getchar();
		while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
		return x;
	}
	inline void add(int x,int y,int z){
		to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e; w[e]=z;
	}
	void dfs(int x,int t,int lim){
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(w[i]<=lim){
				if(f[x][t]<f[y][t]){
					f[y][t]=f[x][t];
					dfs(y,t,lim);
				}
			}
		}
	}
	void solve(){
		n=read();m=read();k=read();
		int x=0,y=0,z=0;
		for(int i=1; i<=m; ++i){
			x=read();y=read();z=read();
			add(x,y,z);
			add(y,x,z);
			vec.pb(z);
		}
		int ans=0x3f3f3f3f;
		memset(f,0x3f3f3f3f,sizeof(f));
		f[1][0]=0;
		for(int t=1;t<=k;++t){
			for(int j=1;j<=n;++j)if(f[j][t-1]!=0x3f3f3f3f){
				q.push(j),vis[j]=1;
			}

			while(!q.empty()){
				int x=q.front();q.pop(); vis[x]=0;
				for(int i=bgn[x]; i; i=nxt[i]){
					int y=to[i];
					if(f[x][t-1]+w[i]<f[y][t]){
						f[y][t]=f[x][t-1]+w[i];
						if(!vis[y]){
							vis[y]=1;
							q.push(y);
						}
					}
				}
			}
			ans=min(ans,f[n][t]);
		}


		sort(vec.begin(),vec.end());
		int ret=0x3f3f3f3f;
		for(int i=0;i<vec.sz();++i){
			memset(g,0x3f3f3f3f,sizeof(g));
			g[1][0][0]=0;
			int mm=vec[i]-1;
			for(int t=1;t<=n;++t)
				for(int k=0;k<=n;++k){
					for(int j=1;j<=n;++j)if(g[j][t-1][k]!=0x3f3f3f3f)q.push(j),vis[j]=1;
					while(!q.empty()){
						int x=q.front(); q.pop(); vis[x]=0;
						for(int i=bgn[x]; i; i=nxt[i]){
						  	int y=to[i];
							if(w[i]>lim){
						  		if(g[x][t-1][k]+w[i]<g[y][t][k+1]){
							 		g[y][t][k+1]=g[x][t-1][k]+w[i];
									if(!vis[y]){
										vis[y]=1;
										q.push(y);
									}
								}
							}
						}
					}
					for(int j=1;j<=n;++j)if(g[j][t-1][k]!=0x3f3f3f3f)q.push(j),vis[j]=1;
					while(!q.empty()){
						int x=q.front(); q.pop(); vis[x]=0;
						for(int i=bgn[x]; i; i=nxt[i]){
							int y=to[i];
							if(w[i]<=lim){
								if(g[x][t-1][k]<g[y][t][k]){
							 		g[y][t][k]=g[x][t-1][k];
									if(!vis[y]){
										vis[y]=1;
										q.push(y);
									}
								}
							}
							if(w[i]>lim){
								if(g[x][t-1][k]+w[i]<g[y][t][k]){
							 		g[y][t][k]=g[x][t-1][k]+w[i];
									if(!vis[y]){
										vis[y]=1;
										q.push(y);
									}
								}	
							}
						}
					}
				}
			//printf("_%d\n",g[3][3][1]);
			for(int t=k;t<=n;++t) ret=min(ret,g[n][t][k]);
			//if(ret!=0x3f3f3f3f)break;
		}
		ans=min(ans,ret);
		printf("%d\n",ans);
	}
}

int main(){
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);
	solver::solve();
}
