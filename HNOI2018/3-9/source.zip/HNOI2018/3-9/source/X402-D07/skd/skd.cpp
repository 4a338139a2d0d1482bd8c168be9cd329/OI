#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int maxn=3010;
const LL INF=0x3f3f3f3f3f3f3f3fll;

int n,m,k;
LL ans;

struct edge{
    int u,v,w;
    
    bool operator < (const edge& rhs) const{
        return w<rhs.w;
    }
} E[maxn];

int f[maxn];
int getf(int v){ return f[v]=f[v]==v?v:getf(f[v]); }

queue<int> q;
bool inq[maxn];
int step[maxn];
LL dis[maxn];

int head[maxn],nxt[maxn<<1],to[maxn<<1],w[maxn<<1],e;
void ae(int x,int y,int W){
    to[++e]=y; nxt[e]=head[x]; head[x]=e; w[e]=W;
}

void SPFA(int s){
    for(int i=1;i<=n;i++) dis[i]=INF;
    memset(step,0x3f3f3f3f,sizeof step);
    q.push(s); inq[s]=1; dis[s]=0; step[s]=0;

    while(!q.empty()){
        int u=q.front(); q.pop(); inq[u]=0;
        for(int i=head[u];i;i=nxt[i]){
            int v=to[i];
            if(chkmin(dis[v],dis[u]+w[i])){
                step[v]=step[u]+1;
                if(!inq[v]) inq[v]=1,q.push(v);
            }
            else if(dis[v]==dis[u]+w[i]) chkmax(step[v],step[u]+1);
        }
    }
}

int main(){
    freopen("skd.in","r",stdin);
    freopen("skd.out","w",stdout);

    read(n); read(m); read(k);
    for(int i=1;i<=m;i++) read(E[i].u),read(E[i].v),read(E[i].w);
    sort(E+1,E+m+1);
    for(int i=1;i<=n;i++) f[i]=i;

    ans=INF;

    for(int i=0;i<=m-k;i++){
        f[getf(E[i].u)]=getf(E[i].v);
        if(getf(1)==getf(n)) break;
        memset(head,0,sizeof head); e=0;
        for(int j=i+1;j<=m;j++){
            int fu=getf(E[j].u),fv=getf(E[j].v);
            if(fu!=fv) ae(fu,fv,E[j].w),ae(fv,fu,E[j].w);
        }
        SPFA(getf(1));
        if(i==0||step[getf(n)]>=k) chkmin(ans,dis[getf(n)]);
    }

    printf("%lld\n",ans);

    return 0;
}
