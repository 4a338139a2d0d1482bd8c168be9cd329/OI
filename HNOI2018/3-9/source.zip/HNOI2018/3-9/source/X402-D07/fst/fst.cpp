#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define ALL(x) (x).begin(),(x).end()

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int maxn=30010;
const LL lim=3e10;

int n,r,k;

LL a[maxn],b[maxn],c[maxn],ans;

struct PSGT{
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r
    struct node{
        int ls,rs,sz;
        node():ls(0),rs(0),sz(0){}
    } T[maxn*36];

    int rt[maxn],cur;

    void update(int& h,LL l,LL r,LL p){
        T[++cur]=T[h]; h=cur;
        if(l==r) return void(++T[h].sz);
        if(p<=mid) update(T[h].ls,lc,p);
        else update(T[h].rs,rc,p);
        T[h].sz=T[T[h].ls].sz+T[T[h].rs].sz;
    }

    int query(int h1,int h2,LL l,LL r,LL R){
        if(r<=R) return T[h2].sz-T[h1].sz;
        int ret=0;
        ret+=query(T[h1].ls,T[h2].ls,lc,R);
        if(R>mid) ret+=query(T[h1].rs,T[h2].rs,rc,R);
        return ret;
    }
#undef mid
} T1,T2;

bool check(LL w){
    int tot=0;
    for(int i=2;i<=n-r+1;i++){
        int base;
        base=a[n]-a[i+r-1]+b[i+r-1]-c[i-1]+b[i-1]; //j in [i-r+1,i-1]
        tot+=T1.query(T1.rt[max(i-r,0)],T1.rt[i-1],-lim,lim,w-base);
        base=a[n]-a[i+r-1]+b[i+r-1]-b[i-1]+a[i-1]; //j in [1,i-r]
        tot+=T2.query(T2.rt[0],T2.rt[max(i-r,0)],-lim,lim,w-base);
    }
    return tot>=k;
}

int main(){
    freopen("fst.in","r",stdin);
    freopen("fst.out","w",stdout);

    read(n); read(r); read(k);

    for(int i=1;i<=n;i++) read(a[i])+=a[i-1];
    for(int i=1;i<=n;i++) read(b[i])+=b[i-1];
    for(int i=1;i<=n;i++) read(c[i])+=c[i-1];

    for(int j=1;j<=n-r;j++){
        T1.rt[j]=T1.rt[j-1];
        T1.update(T1.rt[j],-lim,lim,-b[j+r-1]+c[j+r-1]-b[j-1]+a[j-1]);
        T2.rt[j]=T2.rt[j-1];
        T2.update(T2.rt[j],-lim,lim,-a[j+r-1]+b[j+r-1]-b[j-1]+a[j-1]);
    }

    LL L=0,R=lim;
    while(L<R){
        LL mid=(L+R)>>1;
        if(check(mid)) R=mid;
        else L=mid+1;
    }
    
    printf("%lld\n",L);

    return 0;
}
