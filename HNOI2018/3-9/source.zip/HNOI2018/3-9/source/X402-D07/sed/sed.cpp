#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef unsigned long long ULL;

const int maxn=25;

int n;
ULL w,b[maxn];

void write(int s){
    for(int i=0;i<n;i++)
        if((s>>i)&1) printf("1");
        else printf("0");
    puts("");
}

int main(){
    freopen("sed.in","r",stdin);
    freopen("sed.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++) read(b[i]);
    read(w);
    for(int s=0;s<(1<<n);s++){
        ULL sum=0;
        for(int i=1;i<=n;i++) if((s>>(i-1))&1) sum+=b[i];
        if(sum==w){ write(s); break; }
    }

    return 0;
}
