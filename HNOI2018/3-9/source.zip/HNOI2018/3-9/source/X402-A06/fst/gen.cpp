#include<bits/stdc++.h>

#define ll long long
#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

const int maxn = 1e6;

int main() {
	
	srand(time(NULL));
	int n, r, k;
	n = rand() % 499 + 2; r = rand() % (n - 1) + 1; 
	int all = (n - r) * (n - r + 1) / 2;
	k = rand() % all + 1;
	printf("%d %d %d\n", n, r, k);

	For(i, 1, n) {
		int x = rand() % maxn + 1;
		printf("%d ", x);
	}puts("");

	For(i, 1, n) {
		int x = rand() % maxn + 1;
		printf("%d ", x);
	}puts("");

	For(i, 1, n) {
		int x = rand() % maxn + 1;
		printf("%d ", x);
	}puts("");

	return 0;
}
