#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 300010;

int n, r, K, a[maxn], b[maxn], c[maxn], sum[3][maxn], Max;

void Get() {
	n = read(), r = read(), K = read();
	For(i, 1, n) a[i] = read(), Max = max(Max, a[i]);
	For(i, 1, n) b[i] = read(), Max = max(Max, b[i]);
	For(i, 1, n) c[i] = read(), Max = max(Max, c[i]);

	For(i, 1, n) {
		sum[0][i] = sum[0][i-1] + a[i];
		sum[1][i] = sum[1][i-1] + b[i];
		sum[2][i] = sum[2][i-1] + c[i];
	}

	Max = Max * n;
}

int vis[maxn], ls[maxn], cnt;

void lower_bf() {
	For(i, 1, n-r) {
		For(j, i, i+r-1) ++ vis[j];
		For(j, i+1, n-r+1) {
			++ cnt;
			For(k, j, j+r-1) ++ vis[k];
			For(k, 1, n) {
				if(vis[k] == 0) ls[cnt] += a[k];
				else if(vis[k] == 1) ls[cnt] += b[k];
				else ls[cnt] += c[k];
			}

			For(k, j, j+r-1) -- vis[k];
		}
		For(j, i, i+r-1) -- vis[j];
	}

	sort(ls+1, ls+cnt+1);
	printf("%d\n", ls[K]);
}

void bf() {
	For(i, 1, n-r) {
		For(j, i+1, n-r+1) {
	/*		++ cnt;
			ls[cnt] += sum[0][i-1];
			ls[cnt] += sum[0][n]-sum[0][j+r-1];

			ls[cnt] += sum[1][min(j-1,i+r-1)]-sum[1][i-1];
			ls[cnt] += sum[1][j+r-1]-sum[1][max(i+r,j)-1];

			if(i+r-j > 0) ls[cnt] += sum[2][i+r-1]-sum[2][j-1];
			*/
		}
	}

	sort(ls+1, ls+cnt+1);
	printf("%d\n", ls[K]);
}

const int maxm = 3000000;

//remember to open long long

int Same;

struct Segment_tree{
	
	int Hash[maxn], cnt;
	
	int A[maxn], B[maxn], tree[maxm], root[maxn], tot, ls[maxm], rs[maxm], same[maxn];

	int lowbit(int x) {return x & -x;}
	
	void SORT(){
		For(j, 2, n-r+1) Hash[++cnt] = B[j];
		sort(Hash+1, Hash+cnt+1);
		cnt = unique(Hash+1, Hash+cnt+1) - Hash - 1;
	}

	void insert(int &h,int l,int r,int pos) {
		if(!h) h = ++ tot;
		++ tree[h];
		if(l == r) return;
		int mid = l+r >> 1;
		if(pos <= mid) insert(ls[h], l, mid, pos);
		else insert(rs[h], mid+1, r, pos);
	}

	void add() {
		For(j, 2, n-r+1) {
			int pos = lower_bound(Hash+1, Hash+cnt+1, B[j]) - Hash;

			for(int k = j;k <= n;k += lowbit(k) ){
				insert(root[k], 1, cnt, pos);
			}
		}
	}

	int query(int h,int l,int r,int s,int e) {
		if(!tree[h]) return 0;
		if(l == s && r == e) return tree[h];

		int mid = l+r >> 1;
		if(e <= mid) return query(ls[h], l, mid, s, e);
		else if(s > mid) return query(rs[h], mid+1, r, s, e);
		else return query(ls[h], l, mid, s, mid) + query(rs[h], mid+1, r, mid+1, e);
	}

	int Query(int loc,int val,int tp) {
		int Ans = 0;
		int pos = upper_bound(Hash+1, Hash+cnt+1, val) - Hash - 1;
		if(pos == 0) return 0;

		for(int i = loc;i ;i -= lowbit(i) ) {
			Ans += query(root[i], 1, cnt, 1, pos);
			if(Hash[pos] == val) Same += tp * query(root[i], 1, cnt, pos, pos);
		}

		return Ans;
	}

}ta, tb;

void pre_work() {
	For(i, 1, n-r) ta.A[i] = sum[0][i-1] - sum[0][i+r-1] + sum[1][i+r-1] - sum[1][i-1];
	For(j, 2, n-r+1) ta.B[j] = sum[0][n] - sum[0][j+r-1] + sum[1][j+r-1] + sum[0][j-1] - sum[1][j-1];

	For(i, 1, n-r) tb.A[i] = sum[0][i-1] - sum[1][i-1] - sum[1][i+r-1] + sum[2][i+r-1];
	For(j, 2, n-r+1) tb.B[j] = sum[0][n] - sum[0][j+r-1] + sum[1][j-1] + sum[1][j+r-1] - sum[2][j-1];

	ta.SORT(), tb.SORT();
	ta.add(), tb.add();
}

int check(int mid) {
	int Ans = 0;
	Same = 0;

	For(i, 1, n-r) {
		if(i+r <= n-r+1) {
			int Q = mid - ta.A[i];
			Ans += ta.Query(n-r+1, Q, 1) - ta.Query(i+r-1, Q, -1);
		}

		if(i+1 <= i+r-1) {
			int Q = mid - tb.A[i];
			Ans += tb.Query(i+r-1, Q, 1) - tb.Query(i, Q, -1);
		}
	}

	if(Ans >= K) {
		if(Same != 0 && Ans - Same < K) return 2;
		return 1;
	}
	return 0;
}

void solve() {
	pre_work();
	int l = 0, r = Max;
	while(l <= r) {
		int mid = l+r >> 1;
		int now = check(mid);
		if(now == 2) {
			printf("%d\n", mid);
			return;
		}

		if(now == 1) r = mid-1;
		else l = mid+1;
	}
}

int main() {

	//freopen("fst.in", "r", stdin);
	//freopen("fst.out", "w", stdout);
	
	Get();
	lower_bf();

	return 0;
}
