#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(ll i = (a);i <= (b); ++i)
#define rep(i, a, b) for(ll i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

ll read() {
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const ll maxn = 30010;

ll n, r, K, a[maxn], b[maxn], c[maxn], sum[3][maxn], Max;

void Get() {
	n = read(), r = read(), K = read();
	For(i, 1, n) a[i] = read(), Max = max(Max, a[i]);
	For(i, 1, n) b[i] = read(), Max = max(Max, b[i]);
	For(i, 1, n) c[i] = read(), Max = max(Max, c[i]);

	For(i, 1, n) {
		sum[0][i] = sum[0][i-1] + a[i];
		sum[1][i] = sum[1][i-1] + b[i];
		sum[2][i] = sum[2][i-1] + c[i];
	}

	Max = Max * n;
}

const ll maxm = 7000000;

//remember to open long long

ll Same;

struct Segment_tree{
	
	ll Hash[maxn], cnt;
	
	ll A[maxn], B[maxn], tree[maxm], root[maxn], tot, ls[maxm], rs[maxm];

	inline ll lowbit(ll x) {return x & -x;}
	
	inline void SORT(){
		For(j, 2, n-r+1) Hash[++cnt] = B[j];
		sort(Hash+1, Hash+cnt+1);
		cnt = unique(Hash+1, Hash+cnt+1) - Hash - 1;
	}

	inline void insert(ll &h,ll l,ll r,ll pos) {
		if(!h) h = ++ tot;
		++ tree[h];
		if(l == r) return;
		ll mid = l+r >> 1;
		if(pos <= mid) insert(ls[h], l, mid, pos);
		else insert(rs[h], mid+1, r, pos);
	}

	inline void add() {
		For(j, 2, n-r+1) {
			ll pos = lower_bound(Hash+1, Hash+cnt+1, B[j]) - Hash;

			for(ll k = j;k <= n;k += lowbit(k) ){
				insert(root[k], 1, cnt, pos);
			}
		}
	}

	inline ll query(ll h,ll l,ll r,ll s,ll e) {
		if(!tree[h]) return 0;
		if(l == s && r == e) return tree[h];

		ll mid = l+r >> 1;
		if(e <= mid) return query(ls[h], l, mid, s, e);
		else if(s > mid) return query(rs[h], mid+1, r, s, e);
		else return query(ls[h], l, mid, s, mid) + query(rs[h], mid+1, r, mid+1, e);
	}

	inline ll Query(ll loc,ll val,ll tp) {
		ll Ans = 0;
		ll pos = upper_bound(Hash+1, Hash+cnt+1, val) - Hash - 1;
		if(pos == 0) return 0;

		for(ll i = loc;i ;i -= lowbit(i) ) {
			Ans += query(root[i], 1, cnt, 1, pos);
			if(Hash[pos] == val) Same += tp * query(root[i], 1, cnt, pos, pos);
		}

		return Ans;
	}

}ta, tb;

void pre_work() {
	For(i, 1, n-r) ta.A[i] = sum[0][i-1] - sum[0][i+r-1] + sum[1][i+r-1] - sum[1][i-1];
	For(j, 2, n-r+1) ta.B[j] = sum[0][n] - sum[0][j+r-1] + sum[1][j+r-1] + sum[0][j-1] - sum[1][j-1];

	For(i, 1, n-r) tb.A[i] = sum[0][i-1] - sum[1][i-1] - sum[1][i+r-1] + sum[2][i+r-1];
	For(j, 2, n-r+1) tb.B[j] = sum[0][n] - sum[0][j+r-1] + sum[1][j-1] + sum[1][j+r-1] - sum[2][j-1];

	ta.SORT(), tb.SORT();
	ta.add(), tb.add();
}

ll check(ll mid) {
	ll Ans = 0;
	Same = 0;

	For(i, 1, n-r) {
		if(i+r <= n-r+1) {
			ll Q = mid - ta.A[i];
			Ans += ta.Query(n-r+1, Q, 1) - ta.Query(i+r-1, Q, -1);
		}

		if(i+1 <= i+r-1) {
			ll Q = mid - tb.A[i];
			Ans += tb.Query(i+r-1, Q, 1) - tb.Query(i, Q, -1);
		}

		if(Ans - Same >= K) return 1;
	}

	if(Ans >= K) {
		if(Same != 0 && Ans - Same < K) return 2;
		return 1;
	}
	return 0;
}

void solve() {
	pre_work();
	ll l = 0, r = Max;
	while(l <= r) {
		ll mid = l+r >> 1;
		ll now = check(mid);
		if(now == 2) {
			printf("%lld\n", mid);
			return;
		}

		if(now == 1) r = mid-1;
		else l = mid+1;
	}

	printf("0\n");
}

int main() {

	freopen("fst.in", "r", stdin);
	freopen("fst.out", "w", stdout);

	Get();
	solve();

	return 0;
}
