#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(ll i = (a);i <= (b); ++i)
#define rep(i, a, b) for(ll i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

ll read() {
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const ll maxn = 100010;

ll n, en;

ll b[maxn], c[maxn];

void Get() {
	n = read();
	For(i, 1, n) b[i] = read();
	en = read();
}

void bf() {
	ll tmp = (1 << n) - 1;
	For(i, 0, tmp) {
		ll ans_now = 0;
		For(j, 1, n) {
			if(i & (1 << j-1) ) ans_now += b[j];
		}
		if(ans_now == en) {
			For(j, 1, n) {
				if(i & (1 << j-1) )printf("1");
				else printf("0");
			}puts("");
			return;
		}
	}
}

int main() {
	
	freopen("sed.in", "r", stdin);
	freopen("sed.out", "w", stdout);

	Get();
	bf();

	return 0;
}
