#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=30009;

int n,r,k;
ll a[N],b[N],c[N],db[N],dc[N],f[N],ans;
priority_queue<ll,vector<ll>,greater<ll> > q;

inline void chkmin(ll &a,ll b){if(a>b)a=b;}

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

namespace guo
{
	int p[N],q[N],lb,rb;
	
	inline ll g(int x)
	{
		return a[n]+db[x+r-1]-db[x-1];
	}

	int main()
	{
		ans=1e18;
		
		lb=rb=1;
		q[1]=g(1)-db[r]+dc[r];
		p[1]=1;
		for(int i=2;i<=n-r+1;i++)
		{
			while(p[lb]+r-1<i)lb++;

			chkmin(ans,q[lb]-dc[i-1]+db[i+r-1]);

			while(lb<=rb && q[rb]>g(i)-db[i+r-1]+dc[i+r-1])rb--;
			q[++rb]=g(i)-db[i+r-1]+dc[i+r-1];
			p[rb]=i;
		}

		ll minv=db[r]-db[0]+a[n];
		for(int i=r+1;i<=n-r+1;i++)
		{
			chkmin(ans,db[i+r-1]-db[i-1]+minv);
			chkmin(minv,db[i]-db[i-r]+a[n]);
		}

		printf("%lld\n",ans);
		return 0;
	}


}

int main()
{
	freopen("fst.in","r",stdin);
	freopen("fsts.out","w",stdout);

	n=read();r=read();k=read();
	for(int i=1;i<=n;i++)a[i]=(ll)read()+a[i-1];
	for(int i=1;i<=n;i++)b[i]=(ll)read()+b[i-1];
	for(int i=1;i<=n;i++)c[i]=(ll)read()+c[i-1];
	for(int i=1;i<=n;i++)db[i]=b[i]-a[i];
	for(int i=1;i<=n;i++)dc[i]=c[i]-b[i];

	if(k==1)return guo::main();
	for(int x=1;x<=n-r+1;x++)
		for(int y=x+1;y<=n-r+1;y++)
		{
			if(y<=x+r-1)
				q.push(a[n]+db[y+r-1]-db[x-1]+dc[x+r-1]-dc[y-1]);
			else
				q.push(a[n]+db[x+r-1]-db[x-1]+db[y+r-1]-db[y-1]);
		}

	for(int i=1;i<k;i++)q.pop();
	printf("%lld\n",q.top());
	return 0;
}
