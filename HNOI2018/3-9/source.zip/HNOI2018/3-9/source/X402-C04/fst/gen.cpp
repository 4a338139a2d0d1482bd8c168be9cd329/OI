
#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pr;
typedef long long ll;
set<pr> ha;

const int N=30009;
const int M=20;

int a[N];

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("fst.in","w",stdout);

	int n=300,r=rand()%(n/2-2)+2,k=rand()%((n-r)*(n-r+1)/2)+1;
	printf("%d %d %d\n",n,r,k);
	for(int i=1;i<=n;i++)
		printf("%d ",a[i]=a[i]+rand()%M);
	puts("");
	for(int i=1;i<=n;i++)
		printf("%d ",a[i]=a[i]+rand()%M);
	puts("");
	for(int i=1;i<=n;i++)
		printf("%d ",a[i]=a[i]+rand()%M);
	puts("");

	return 0;
}
