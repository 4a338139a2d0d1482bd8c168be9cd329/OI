#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=3009;

int n,m,k;
int to[N<<1],nxt[N<<1],w[N<<1],beg[N],tot;
int stk[N],tmp[N],top;
bool vis[N];
ll ans=1e18;

inline void add(int u,int v,int c)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	w[tot]=c;
	beg[u]=tot;
}

inline void dfs(int u)
{
	if(u==n)
	{
		memcpy(tmp,stk,sizeof(stk[0])*(top+5));
		sort(tmp+1,tmp+top+1);
		ll cans=0;
		for(int i=1;i<=k;i++)
			cans+=tmp[top-i+1];
		if(ans>cans)
			ans=cans;
		return;
	}

	vis[u]=1;
	for(int i=beg[u];i;i=nxt[i])
		if(!vis[to[i]])
		{
			stk[++top]=w[i];
			dfs(to[i]);top--;
		}
	vis[u]=0;
}

int main()
{
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);

	n=read();m=read();k=read();
	for(int i=1,u,v,c;i<=m;i++)
	{
		u=read();v=read();c=read();
		add(u,v,c);add(v,u,c);
	}

	dfs(1);

	printf("%lld\n",ans);
	return 0;
}
