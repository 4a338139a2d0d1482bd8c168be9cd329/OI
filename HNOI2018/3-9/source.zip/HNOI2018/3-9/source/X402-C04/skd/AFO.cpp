#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=3009;

int n,m,k;
int to[N<<1],nxt[N<<1],w[N<<1],beg[N],tot;
int stk[N],tmp[N],rha[N],top;
ll dis[N][K];
map<int,int> ha;
bool vis[N];
ll ans=1e18;

inline void add(int u,int v,int c)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	w[tot]=c;
	beg[u]=tot;
}

int main()
{
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);

	n=read();m=read();k=read();
	for(int i=1,u,v,c;i<=m;i++)
	{
		u=read();v=read();c=read();
		add(u,v,c);add(v,u,c);ha[c];
	}

	int cnt=0;
	for(map<int,int>::iterator it=ha.begin();it!=ha.end();it++)
		rha[(*it).second=++cnt]=(*it).first;

	for(int lp=1;lp<=cnt;lp++)
	{
		int lim=rha[lp];
		for(int j=1;j<=n)
	}

	dfs(1);

	printf("%lld\n",ans);
	return 0;
}
