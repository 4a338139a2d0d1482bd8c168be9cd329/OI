#include<bits/stdc++.h>
using namespace std;

typedef unsigned long long ll;

const int N=69;

int n,c[N];
ll b[N],tar;

inline bool dfs(int p,ll v)
{
	if(p==n+1)
	{
		if(v==tar)return 1;
		return 0;
	}
	c[p]=0;
	if(dfs(p+1,v))return 1;
	c[p]=1;
	return dfs(p+1,v+b[p]);
}

inline void rands()
{
	ll ans;
	while(1)
	{
		ans=0;
		for(int i=1;i<=n;i++)
			if((c[i]=rand()%2))
				ans+=b[i];
		if(ans==tar)break;
	}
}

int main()
{
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%llu",&b[i]);
	scanf("%llu",&tar);

	if(n<=20)dfs(1,0);
	else rands();
	for(int i=1;i<=n;i++)
		printf("%d ",c[i]);
	puts("");
	return 0;
}
