#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=3010;
int n,m,K;
ll dis[maxn];
vector<pair<int,int> > G[maxn];

template<typename T>bool chkmin(T &x,T y){
	if(x>y){x=y;return 1;}
	else return 0;
}

set<int> zero;
set<int>::iterator it;
struct data{
	int u,k;
	ll dis;
	set<int> q;
	data(){
		u=dis=k=0;
		q=zero;
	}
	data(int u,ll dis,int k,set<int> q):u(u),dis(dis),k(k),q(q){};
};

bool operator < (data a,data b){
	if(a.dis!=b.dis)return a.dis>b.dis;
	if(a.k!=b.k)return a.k>b.k;
	return a.u>b.u;
}

priority_queue<data> Q;

bool chk(data u,int v,int w){
	//Q.top();
	if(u.k==K){
		it=u.q.begin();
		if(it==u.q.end()&&chkmin(dis[v],u.dis)){
			Q.push(data(v,dis[v],K,u.q));
		}
		else if(chkmin(dis[v],u.dis+w-(*it))){
			u.q.erase(u.q.begin());
			u.q.insert(w);
			Q.push(data(v,dis[v],K,u.q));
		}
	}
	else{
		if(chkmin(dis[v],u.dis+w)){
			u.q.insert(w);
			Q.push(data(v,dis[v],u.k+1,u.q));
		}
	}
}

void solve(){
	scanf("%d%d%d",&n,&m,&K);
	for(int i=1,u,v,w;i<=m;++i){
		scanf("%d%d%d",&u,&v,&w);
		G[u].push_back(make_pair(v,w));
		G[v].push_back(make_pair(u,w));
	}
	memset(dis,0x3f,sizeof dis);
	dis[1]=0;
	Q.push(data(1,dis[1],0,zero));
	for(data u;!Q.empty();){
		u=Q.top();Q.pop();
		for(int i=0,v,w;i<G[u.u].size();++i){
			//v=G[u.u][i].first;w=G[u.u][i].second;
			//if(chk(u,v,w)){
			//	Q.push((data){v,dis[v],});
			//}
			chk(u,G[u.u][i].first,G[u.u][i].second);
		}
	}
	printf("%lld\n",dis[n]);
}
int main(){
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);
	solve();

	return 0;
}
