#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ll;
int n,a[110],c[110];
ll m;
void dfs(int x,ll res){
	if(x>n){
		if(res==m){
			for(int i=1;i<=n;++i){
				printf("%d",c[i]);
			}
			exit(0);
		}
		return;
	}
	c[x]=1;
	dfs(x+1,res+a[x]);
	c[x]=0;
	dfs(x+1,res);
}
void solve(){
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",a+i);
	scanf("%llu",&m);
	dfs(1,0);
}
int main(){
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
	solve();

	return 0;
}
