#include<bits/stdc++.h>
using namespace std;

template<typename T>T read(){
	T x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
	return x*f;
}
typedef long long ll;
const int maxn=30010;

priority_queue<ll,vector<ll>,greater<ll> > q;

ll k,a[maxn],b[maxn],c[maxn];
ll del[maxn],d[maxn],tmp;
int n,r;

void work1(){
	for(int i=1;i<=n;++i)a[i]=read<int>();
	for(int i=1;i<=n;++i)b[i]=read<int>();
	for(int i=1;i<=n;++i)c[i]=read<int>();
	for(int i=1;i<=n;++i){
		del[i]=b[i]-a[i];
	}
	for(int i=1;i<=n;++i){
		tmp+=del[i];
		if(i-r+1>0){
			d[i-r+1]=tmp;
			tmp-=del[i-r+1];
		}
	}
	for(int i=1;i<=n-r+1;++i){
		
	}
	exit(0);
}

void solve(){
	n=read<int>(),r=read<int>(),k=read<ll>();
	//if(k==1)work1();

	for(int i=1;i<=n;++i)a[i]=a[i-1]+read<int>();
	for(int i=1;i<=n;++i)b[i]=b[i-1]+read<int>();
	for(int i=1;i<=n;++i)c[i]=c[i-1]+read<int>();
	
	for(int lx=1,rx,ry;lx<=n-r+1;++lx)
		for(int ly=lx+1;ly<=n-r+1;++ly){
			rx=lx+r-1;ry=ly+r-1;
			if(rx<ly){
				q.push(a[lx-1]-a[0]+b[rx]-b[lx-1]+a[ly-1]-a[rx]+b[ry]-b[ly-1]+a[n]-a[ry]);
			}
			else{
				q.push(a[lx-1]-a[0]+b[ly-1]-b[lx-1]+c[rx]-c[ly-1]+b[ry]-b[rx]+a[n]-a[ry]);
			}
		}
	for(int i=1;i<=k;++i)q.pop();
	cout<<q.top()<<endl;
}
int main(){
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
	solve();
	return 0;
}
