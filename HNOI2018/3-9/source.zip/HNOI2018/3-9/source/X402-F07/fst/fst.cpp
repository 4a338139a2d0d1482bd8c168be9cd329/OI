#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=30005;
const ll Lim=1e12;
int n,m,r;
int a[maxn],b[maxn],c[maxn];
ll val[maxn],s[maxn],t[maxn];
int tot;
struct node{int lc,rc,sum;};
struct seg_tree{
	int Root;
	ll tag;
	node tr[maxn*100];
	void init(){
		Root=0,tag=0;
	}
	int newnode(){
		++tot;
		tr[tot].lc=tr[tot].rc=tr[tot].sum=0;
		return tot;
	}
	void update(int &p,ll l,ll r,ll pos,int x){
		if(!p)p=newnode();
		tr[p].sum+=x;
		if(l==r)return;
		ll mid=(l+r)>>1;
		if(pos<=mid)update(tr[p].lc,l,mid,pos,x);
		else update(tr[p].rc,mid+1,r,pos,x);
	}
	ll query(int p,ll l,ll r,ll L,ll R){
		if((!p)||(L>R))return 0;
		if((L<=l)&&(R>=r))return tr[p].sum;
		ll mid=(l+r)>>1,res=0;
		if(L<=mid)res+=query(tr[p].lc,l,mid,L,R);
		if(R>mid)res+=query(tr[p].rc,mid+1,r,L,R);
		return res;
	}
/*
	void DFS(int p,ll l,ll r,ll tmp){
		if(!p)return;
		if(l==r){cout<<l+tmp<<'-'<<tr[p].sum<<' ';return;}
		ll mid=(l+r)>>1;
		DFS(tr[p].lc,l,mid,tmp);
		DFS(tr[p].rc,mid+1,r,tmp);
	}
*/
}T1,T2;
ll calc(ll x){
	ll res=0;
	T1.init(),T2.init();
	REP(i,2,min(r,n-r+1))T1.update(T1.Root,-Lim,Lim,s[i],1),t[i]=s[i];
	REP(i,r+1,n-r+1)T2.update(T2.Root,-Lim,Lim,s[i],1);
	REP(i,1,n-r){
		if(i>1){
			if(i+r<=n-r+1){
				T2.update(T2.Root,-Lim,Lim,s[i+r-1],-1);
				T1.update(T1.Root,-Lim,Lim,t[i+r-1]=s[i+r-1]+T2.tag-T1.tag,1);
			}
			T1.tag+=c[i-1]-b[i-1]+a[i+r-1]-b[i+r-1];
			T2.tag+=c[i-1]-b[i-1]+b[i+r-1]-c[i+r-1];
			T1.update(T1.Root,-Lim,Lim,t[i],-1);
		}
		res+=T1.query(T1.Root,-Lim,Lim,-Lim,x-T1.tag-val[i]);
		res+=T2.query(T2.Root,-Lim,Lim,-Lim,x-T2.tag-val[i]);
/*
		cout<<"i="<<i<<endl;
		T1.DFS(T1.Root,-Lim,Lim,T1.tag+val[i]),puts("");
		T2.DFS(T2.Root,-Lim,Lim,T2.tag+val[i]),puts("");
*/
	}
//	cout<<x<<' '<<res<<endl;
	return res;
}
void work(){
	REP(i,1,r)val[1]+=c[i];
	REP(i,r+1,n)val[1]+=a[i];
	REP(i,2,n-r)val[i]=val[i-1]+a[i-1]-c[i-1]+c[i+r-1]-a[i+r-1];
	REP(i,2,min(r+1,n-r+1))s[i]=b[i+r-1]-a[i+r-1]+b[i-1]-c[i-1];
	REP(i,r+2,n-r+1)s[i]=b[i+r-1]-a[i+r-1]+a[i-1]-b[i-1];
	REP(i,2,n-r+1)s[i]+=s[i-1];
//	calc(1);
///*
	ll l=1,h=3e10;
	while(l<=h){
		ll mid=(l+h)>>1;
		if(calc(mid)>=m)h=mid-1;
		else l=mid+1;
	}
	write(l,'\n');
//*/
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
#endif
	n=read(),r=read(),m=read<ll>();
	REP(i,1,n)a[i]=read();
	REP(i,1,n)b[i]=read();
	REP(i,1,n)c[i]=read();
	work();
	return 0;
}
