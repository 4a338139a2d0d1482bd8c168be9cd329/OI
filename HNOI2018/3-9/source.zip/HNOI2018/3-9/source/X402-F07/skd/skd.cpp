#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=3005;
int n,m,k;
int fa[maxn];
int find_fa(int x){
	return x==fa[x]?x:fa[x]=find_fa(fa[x]);
}
struct edge{
	int u,v,w;
	void input(){
		u=read(),v=read(),w=read();
	}
	bool operator < (const edge &A) const {
		return w>A.w;
	}
}e[maxn];
bool vis[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);
#endif
	ll ans=1e18;
	n=read(),m=read(),k=read();
	REP(i,1,m)e[i].input();
	sort(e+1,e+1+m);
	REP(i,1,m){
		ll cost=0;
		int cnt=0,tot=0;
		REP(j,1,n)fa[j]=j;
		REP(j,1,m)vis[j]=0;
		REP(j,i+1,m)
			if(find_fa(e[j].v)!=find_fa(e[j].u)){
				++tot;
				fa[find_fa(e[j].v)]=find_fa(e[j].u);
			}
		DREP(j,i,1)
			if(find_fa(e[j].v)!=find_fa(e[j].u)){
				cost+=e[j].w,++cnt,++tot,vis[j]=1;
				fa[find_fa(e[j].v)]=find_fa(e[j].u);
			}
		if((tot!=n-1)||(cnt!=k))continue;
//		cerr<<i<<' '<<cost<<' '<<e[i].w<<endl;
		chkmin(ans,cost);
	}
	write(ans,'\n');
	return 0;
}
