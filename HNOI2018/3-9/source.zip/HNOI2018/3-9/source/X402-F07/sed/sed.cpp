#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef unsigned long long llu;
typedef double lf;
const int maxn=64;
const llu mod=-1;
int n;
llu a[maxn],b;
int main(){
#ifndef ONLINE_JUDGE
	freopen("sed.in","r",stdin);
	freopen("sed.out","w",stdout);
#endif
	n=read();
	REP(i,1,n)a[i]=read();
	b=read();
	REP(i,0,(1<<n)-1){
		__int128 res=0;
		REP(j,1,n)
			if(i&(1<<(j-1)))
				(res+=a[j])&=mod;
		if(res==b){
			REP(j,0,n-1)
				printf("%d",(i>>j)&1);
			break;
		}
	}
	return 0;
}
