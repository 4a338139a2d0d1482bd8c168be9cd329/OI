#include <bits/stdc++.h>
#define LL unsigned long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 65 ;
LL n, m, b[maxn], k ;
bool solve ( LL x ) {
	LL i, val = x, rec = 0 ;
	for ( i = 1 ; x ; x >>= 1, i ++ )
		if (x&1) rec += b[i] ;
	if (rec ^ k) return 0 ;
	for ( i = 1 ; i <= n ; val >>= 1, i ++ )
		putchar((val&1)+'0') ;
	puts("") ;
	return 1 ;
}
void Force() {
	for ( LL i = 0 ; i <= m ; i ++ )
		if (solve(i)) return ;
}
void Random() {
	while (!solve((long long)rand()*rand()%m*rand()%m)) ;
}
int main() {
	freopen ( "sed.in", "r", stdin ) ;
	freopen ( "sed.out", "w", stdout ) ;
	srand(time(0)) ;
	Read(n) ;
	for ( LL i = 1 ; i <= n ; i ++ )
		Read(b[i]) ;
	Read(k) ; m = (1LL<<n)-1 ;
	if (n <= 20) Force() ;
	else Random() ;
	return 0 ;
}
