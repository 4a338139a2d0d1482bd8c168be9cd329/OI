#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const int maxn = 3e5+5 ;
int A[maxn], B[maxn], C[maxn] ;
int main() {
	srand(time(0)) ;
	freopen ( "fst.in", "w", stdout ) ;
	int k, i, v = 1e6+1, a, b, c, n, m ;
	n = 2000 ;
	m = rand()%(n-1)+1 ;
	k = rand()%((n-m)*(n-m+1)/2)+1 ;
	k = 1 ;
	printf ( "%d %d %d\n", n, m, k ) ;
	for ( i = 1 ; i <= n ; i ++ ) {
		a = rand()%v+1, b = rand()%v+1, c = rand()%v+1 ;
		if (a > b) swap(a, b) ;
		if (b > c) swap(b, c) ;
		if (a > b) swap(a, b) ;
		A[i] = a, B[i] = b, C[i] = c ;
	}
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%d ", A[i] ) ;
	puts("") ;
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%d ", B[i] ) ;
	puts("") ;
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%d ", C[i] ) ;
	puts("") ;
	return 0 ;
}
