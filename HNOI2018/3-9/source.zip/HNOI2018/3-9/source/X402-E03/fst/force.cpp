#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void chkmin ( LL &a, LL b ) { a = a<b? a:b ; }
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 3e4+5, inf = 1e13 ;
LL n, m, k, lim, a[maxn], b[maxn], c[maxn] ;
LL Min[maxn] ;
priority_queue <LL, vector<LL>, greater<LL> > Q ;
LL calc ( LL x, LL y ) {
	LL i, cnt, val = 0 ;
	for ( i = 1 ; i <= n ; i ++ ) {
		cnt = 0 ;
		if (i >= x && i <= x+m-1) ++ cnt ;
		if (i >= y && i <= y+m-1) ++ cnt ;
		if (cnt == 0) val += a[i] ;
		else if (cnt == 1) val += b[i] ;
		else val += c[i] ;
	}
	return val ;
}
int main() {
	freopen ( "fst.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;
	Read(n), Read(m), Read(k) ;
	LL i, j ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(a[i]) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(b[i]) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(c[i]) ;
	lim = n-m+1 ;
	for ( i = 1 ; i <= lim ; i ++ )
		for ( j = i+1 ; j <= lim ; j ++ )
			Q.push(calc(i, j)) ;
	while (--k) Q.pop() ;
	cout << Q.top() << endl ;
	cerr << "force " << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
