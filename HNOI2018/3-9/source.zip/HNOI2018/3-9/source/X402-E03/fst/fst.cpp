#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void chkmin ( LL &a, LL b ) { a = a<b? a:b ; }
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 3e4+5, inf = 1e13 ;
LL n, m, k, lim, a[maxn], b[maxn], c[maxn] ;
LL Min[maxn] ;
priority_queue <LL, vector<LL>, greater<LL> > Q ;
LL calc ( LL x, LL y ) {
	LL val = 0 ;
	val += a[x-1] ;
	if (y <= x+m-1) val += b[y-1]-b[x-1] + c[x+m-1]-c[y-1] + b[y+m-1]-b[x+m-1] ;
	else val += b[x+m-1]-b[x-1] + b[y+m-1]-b[y-1] + a[y-1] - a[x+m-1] ;
	val += a[n]-a[y+m-1] ;
	return val ;
}
int main() {
	freopen ( "fst.in", "r", stdin ) ;
	freopen ( "fst.out", "w", stdout ) ;
	Read(n), Read(m), Read(k) ;
	LL i, j, t ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(a[i]), a[i] += a[i - 1] ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(b[i]), b[i] += b[i - 1] ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(c[i]), c[i] += c[i - 1] ;
	lim = n-m+1 ;
	if (k ^ 1) {
		for ( i = 1 ; i <= lim ; i ++ )
			for ( j = i+1 ; j <= lim ; j ++ )
				Q.push(calc(i, j)) ;
		while (--k) Q.pop() ;
		cout << Q.top() << endl ;
	} else {
		LL lim2, ans = inf ;
		Min[lim] = b[n]-a[n]-b[lim-1]+a[lim-1] ;
		for ( i = lim-1 ; i ; i -- ) {
			Min[i] = b[i+m-1]-a[i+m-1]-b[i-1]+a[i-1] ;
			chkmin(Min[i], Min[i+1]) ;
		}
		for ( i = 1 ; i <= lim ; i ++ ) {
			for ( lim2 = min(lim, i+m-1), j = i+1 ; j <= lim2 ; j ++ ) {
				t = a[i-1] + b[j-1]-b[i-1] + c[i+m-1]-c[j-1] + b[j+m-1]-b[i+m-1] + a[n]-a[j+m-1] ;
				chkmin(ans, t) ;
			}
			if (i+m <= lim) {
				t = a[n]+Min[i+m]+b[i+m-1]-b[i-1]-a[i+m-1]+a[i-1] ;
				chkmin(ans, t) ;
			}
		}
		cout << ans << endl ;
		//cerr << "solve " << (double)clock()/CLOCKS_PER_SEC << endl ;
	}
	return 0 ;
}
