#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=3050;
int head[N],cnt=1;
struct node
{
	int to,next,w;
	node(int to=0,int next=0,int w=0):to(to),next(next),w(w) { }
}e[N<<1];
inline void add(int x,int y,int w)
{
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],w};head[y]=cnt;
}
pii E[N];
int fa[N];
inline int find(int x)
{
	if(fa[x]!=x) return fa[x]=find(fa[x]);
	return fa[x];
}
int n,m,k,stk[N],top=0;
bool vis[N<<1];


void wj()
{
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read(); k=read();
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read(),w=read();
		add(x,y,w);
		E[i]=pii(w,i);
	}
	sort(E+1,E+1+m);
	ll ans=0;
	for(int i=1;i<=k&&i<=m;++i) ans+=E[i].fi;
	printf("%lld\n",ans);
	/*
	for(int i=1;i<=n;++i) fa[i]=i;
	ll ans=0;
	for(int i=1;i<=m;++i)
	{
		int x=e[E[i].se<<1].to,y=e[E[i].se<<1|1].to;
		int r1=find(x),r2=find(y);
		if(r1!=r2) fa[r1]=r2,vis[E[i].se<<1]=1,vis[E[i].se<<1|1]=1;
	}
	for(int i=1;i<=m;++i)
	{
		if(!vis[i<<1])
		{
		}
	}*/
	return 0;
}
