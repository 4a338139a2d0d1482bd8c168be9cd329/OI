#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=30050;
int n,R,K,tot=0;
ll a[N],b[N],c[N],val[550*550];

void wj()
{
	freopen("fst.in","r",stdin);
	//freopen("fst.out","w",stdout);
}
int main()
{
	wj();
	n=read(); R=read(); K=read();
	for(int i=1;i<=n;++i) a[i]=read()+a[i-1];
	for(int i=1;i<=n;++i) b[i]=read()+b[i-1];
	for(int i=1;i<=n;++i) c[i]=read()+c[i-1];
	for(int i=1;i<=n-R+1;++i) for(int j=i+1;j<=n-R+1;++j)
	{
		if(j<=i+R-1) val[++tot]=a[i-1]+b[j-1]-b[i-1]
			+c[i+R-1]-c[j-1]+b[j+R-1]-b[i+R-1]+a[n]-a[j+R-1];
		else val[++tot]=a[i-1]+b[i+R-1]-b[i-1]+
			a[j-1]-a[i+R-1]+b[j+R-1]-b[j-1]+a[n]-a[j+R-1];
	}
	//nth_element(val+1,val+K,val+tot+1);
	sort(val+1,val+1+tot);
	//for(int i=1;i<=20;++i) printf("%lld ",val[i]); ln;
	//printf("%lld\n",val[20000]);
	printf("%lld\n",val[K]);
	return 0;
}
