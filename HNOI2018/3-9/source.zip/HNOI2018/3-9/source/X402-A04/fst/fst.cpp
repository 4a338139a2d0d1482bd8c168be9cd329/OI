#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=60050;
int n,R,K,tot=0;
ll a[N],b[N],c[N],hav[N],nhav[N];
ll po[N];

struct seg
{
	int sum[N*21],sz,ch[N*21][2],rt[N];
	seg()
	{
		memset(sum,0,sizeof(sum)); sz=0; memset(ch,0,sizeof(ch));
		memset(rt,0,sizeof(rt));
	}
	void insert(int &o,int last,int l,int r,int x)
	{
		o=++sz;
		ch[o][0]=ch[last][0]; ch[o][1]=ch[last][1];
		sum[o]=sum[last]+1;
		if(l==r) return ;
		int mid=l+r>>1;
		if(x<=mid) insert(ch[o][0],ch[last][0],l,mid,x);
		else insert(ch[o][1],ch[last][1],mid+1,r,x);
	}
	int query(int s,int t,int l,int r,int x)
	{
		if(l==r) {if(l<x) return sum[t]-sum[s]; return 0;}
		int mid=l+r>>1;
		if(x<=mid) return query(ch[s][0],ch[t][0],l,mid,x);
		else return query(ch[s][1],ch[t][1],mid+1,r,x)+sum[ch[t][0]]-sum[ch[s][0]];
	}
}t1,t2;

int check(ll x)
{
	int ans=0;
	for(int i=1;i<=n-R+1;++i)
	{
		int k;
		k=lower_bound(po+1,po+1+tot,x-(a[i-1]-b[i-1]+c[i+R-1]-b[i+R-1]+a[n]))-po;
		ans+=t1.query(t1.rt[i],t1.rt[min(i+R-1,n-R+1)],1,tot,k); //hav

		if(i+R<=n-R+1)
		{
			k=lower_bound(po+1,po+1+tot,x-(a[i-1]+b[i+R-1]-b[i-1]-a[i+R-1]+a[n]))-po;
			ans+=t2.query(t2.rt[i+R-1],t2.rt[n-R+1],1,tot,k); //nhav
		}
	}
	return ans;
}

void wj()
{
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
}
int main()
{
	wj();
	n=read(); R=read(); K=read();
	for(int i=1;i<=n;++i) a[i]=read()+a[i-1];
	for(int i=1;i<=n;++i) b[i]=read()+b[i-1];
	for(int i=1;i<=n;++i) c[i]=read()+c[i-1];

	for(int j=1;j<=n-R+1;++j)
	{
		hav[j]=b[j-1]-c[j-1]+b[j+R-1]-a[j+R-1];
		nhav[j]=a[j-1]+b[j+R-1]-b[j-1]-a[j+R-1];
		po[++tot]=hav[j]; po[++tot]=nhav[j];
	}
	sort(po+1,po+1+tot);
	tot=unique(po+1,po+1+tot)-(po+1);
	for(int j=1;j<=n-R+1;++j)
	{
		hav[j]=lower_bound(po+1,po+1+tot,hav[j])-po;
		nhav[j]=lower_bound(po+1,po+1+tot,nhav[j])-po;
	}

	for(int i=1;i<=n-R+1;++i) t1.insert(t1.rt[i],t1.rt[i-1],1,tot,hav[i]);
	for(int i=1;i<=n-R+1;++i) t2.insert(t2.rt[i],t2.rt[i-1],1,tot,nhav[i]);

	/*for(int i=1;i<=n-R+1;++i) cerr<<(a[i-1]-b[i-1]+c[i+R-1]-b[i+R-1]+a[n])<<' ';
	cerr<<endl;
	for(int i=1;i<=n-R+1;++i) cerr<<po[hav[i]]<<' ';
	cerr<<endl;
	for(int i=1;i<=n-R+1;++i) cerr<<(a[i-1]+b[i+R-1]-b[i-1]-a[i+R-1]+a[n])<<' ';
	cerr<<endl;
	for(int i=1;i<=n-R+1;++i) cerr<<po[nhav[i]]<<' ';
	cerr<<endl;

	int i=1;
	int k=lower_bound(po+1,po+1+tot,32-(a[i-1]-b[i-1]+c[i+R-1]-b[i+R-1]+a[n]))-po;
	cerr<<k<<endl;
	cerr<<t1.query(t1.rt[i],t1.rt[i+R-1],1,tot,k);*/

	ll l=0,r=3e11,g=0;
	while(l<r)
	{
		ll mid=l+r>>1;
		if(check(mid)<=K-1) g=max(g,mid),l=mid+1;
		else r=mid;
	}
	if(check(l)<=K-1) g=max(g,l);
	printf("%lld\n",g);
	//for(int i=1;i<=50;++i) cerr<<check(i)<<' '; cerr<<endl;
	//cerr<<check(252815576);
	return 0;
}
