#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <set>
#include      <map>
using namespace std;

typedef long long LL;

const int N=30005,M=1e7;
const LL oo=1ll<<45;

int n,r,k,a[N],b[N],c[N],rt,m,s[M],lc[M],rc[M];
LL sa,sb[N],sc[N],addt;

void Add(int& x,LL l,LL r,LL p,int c)
{
	if(!x)
		x=++m,s[x]=0,lc[x]=0,rc[x]=0;
	s[x]+=c;
	LL Mid=l+r>>1;
	if(l==r)
		return;
	if(p<=Mid)
		Add(lc[x],l,Mid,p,c);
	else
		Add(rc[x],Mid+1,r,p,c);
}

int Ask(int& x,LL l,LL r,LL p)
{
	if(!x)
		return 0;
	if(p<=l)
		return s[x];
	LL Mid=l+r>>1;
	if(p<=Mid)
		return Ask(lc[x],l,Mid,p)+Ask(rc[x],Mid+1,r,p);
	return Ask(rc[x],Mid+1,r,p);
}

void cleartree()
{
	rt=m=1;s[1]=rc[1]=lc[1]=0;addt=0;
}

void alladd(LL t)
{
	addt+=t;
}

void Insert(LL t)
{
	Add(rt,-oo,oo,t-addt,1);
}

void Delete(LL t)
{
	Add(rt,-oo,oo,t-addt,-1);
}

int Ask(LL t)
{
	return Ask(rt,-oo,oo,t-addt);
}

bool check(LL val)
{
	cleartree();
	int Num=0;
	for(int i=n;i>=r;i--)
	{
		if(i+r<=n)
			Insert(sb[i+r]-sb[i]);
		Num+=Ask(val-sa-sb[i]+sb[i-r]);
	}
	cleartree();
	for(int i=n-1;i>=r;i--)
	{
		alladd(b[i+1]-c[i+1]+b[i-r+1]);
		Insert(sc[i]-sc[i-r+1]+b[i-r+1]+b[i+1]);
		if(i+r<=n)
			Delete(sb[i+r]-sb[i-r]);
		Num+=Ask(val-sa);
	}
	return Num>=k;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("fst.in","r",stdin);
	freopen("fst.out","w",stdout);
#endif
	scanf("%d%d%d",&n,&r,&k);k=(n-r)*(n-r+1)/2-k+1;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]),sa+=a[i];
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]),b[i]-=a[i],sb[i]=sb[i-1]+b[i];
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]),c[i]-=a[i],sc[i]=sc[i-1]+c[i];
	LL Ans=0,l=sa,r=sa+sc[n];
	while(l<=r)
	{
		LL Mid=l+r>>1;
		if(check(Mid))
			l=Mid+1,Ans=Mid;
		else
			r=Mid-1;
	}
	cout<<Ans<<endl;
	return 0;
}

