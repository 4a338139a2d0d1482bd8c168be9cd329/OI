#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <set>
#include      <map>
using namespace std;

#define rep(i,a,n) for (int i=a;i<n;i++)
#define pb push_back
#define fi first
#define se second
#define mp make_pair
typedef long long ll;
const ll inf=1ll<<60;
const int N=3010;
int n,m,k,u,v,w,vis[N];
vector<pair<int,int> > e[N];
ll dis[N];
vector<int> vec;
ll gao(int d) {
	rep(i,1,n+1) dis[i]=inf,vis[i]=0;
	priority_queue<pair<ll,int> > hs;
	dis[1]=0;
	hs.push(mp(0,1));
	while (!hs.empty()) {
		int u=-1;
		while (!hs.empty()) {
			auto it=hs.top(); hs.pop();
			if (!vis[it.se]) {
				u=it.se;
				break;
			}
		}
//		printf("ff %d\n",u);
		if (u==-1) break;
		vis[u]=1;
		for (auto p:e[u]) {
			int v=p.fi,w=max(p.se-d,0);
			if (dis[v]>dis[u]+w) {
				dis[v]=dis[u]+w;
				hs.push(mp(-dis[v],v));
			}
		}
	}
	return dis[n];
}
int main() {
	freopen("skd.in","r",stdin);
	freopen("skd.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	rep(i,0,m) {
		scanf("%d%d%d",&u,&v,&w);
		e[u].pb(mp(v,w));
		e[v].pb(mp(u,w));
		vec.pb(w);
	}
	ll ret=gao(0);
	rep(it,0,m) {
		ret=min(ret,gao(vec[it])+(ll)vec[it]*k);
	}
	printf("%lld\n",ret);
}
