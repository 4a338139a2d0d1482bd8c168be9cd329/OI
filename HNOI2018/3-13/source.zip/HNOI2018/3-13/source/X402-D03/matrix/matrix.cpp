#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n;
struct Matrix {
	bitset<1001> m[1010];
	Matrix(int x = 0) {
		int i, j;
		if(x == 0) {
			for(i = 1; i <= n; i++) 
				for(j = 1; j <= n; j++) m[i][j] = 0;
		}
	}
};
struct Vector {
	bitset<1001> m;
}X;

inline Matrix inv(const Matrix &a) {
	Matrix res;
	int i, j;
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= n; j++) res.m[i][j] = a.m[j][i];
	return res;
}

Matrix operator * (const Matrix &a, const Matrix &b) {
	Matrix res, B;
	B = inv(b);
	int i, j;
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= n; j++) 
			res.m[i][j] = (a.m[i]&B.m[j]).count()&1;
	return res;
}

Vector operator * (const Matrix &a, const Vector &b) {
	Vector res;
	int i;
	for(i = 1; i <= n; i++) 
		res.m[i] = (a.m[i]&b.m).count()&1;
	return res;
}

int m;

int main() {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);

	int i, j;
	n = read();
	Matrix A[30];
	char s[1010];
	for(i = 1; i <= n; i++) {
		scanf("%s", s+1);
		for(j = 1; j <= n; j++)
			A[1].m[i][j] = s[j]-'0';
	}
	scanf("%s", s+1);
	for(i = 1; i <= n; i++) X.m[i] = s[i]-'0';
	for(i = 2; i <= 29; i++) A[i] = A[i-1]*A[i-1];
	m = read();
	while(m--) {
		int K = read();
		Vector res = X;
		i = 1;
		while(K) {
			if(K & 1LL) res = A[i] * res;
			K >>= 1, i++;
		}
		for(i = 1; i <= n; i++) printf("%d", (int)res.m[i]);
		printf("\n");
	}
	return 0;
}
