#include <bits/stdc++.h>

using std :: sort;
using std :: unique;
using std :: lower_bound;
using std :: upper_bound;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int N = 1e5;

struct Point
{
	int x, y, z, opt, ty, id, y2, z2;
	Point(int x = 0, int y = 0, int z = 0, int opt = 0, int ty = 0, int id = 0, int y2 = 0, int z2 = 0) : x(x), y(y), z(z), opt(opt), ty(ty), id(id), y2(y2), z2(z2) {}
	bool operator < (const Point& rhs)const
	{
		return x != rhs.x? x < rhs.x : ty < rhs.ty;
	}
}q[N + 5];

int m;

namespace JMXSYYC
{
	int xi[N + 5], xl;
	int yi[N + 5], yl;
	int zi[N + 5], zl;
	int ans[N + 5];

	#define mid ((l + r) >> 1)
	const int NLOG = N * 100;

	int tot, rt[N + 5];
	int sum[NLOG + 5], lc[NLOG + 5], rc[NLOG + 5];

	void insert(int &h, int l, int r, int u)
	{
		if (!h) {
			h = ++tot; sum[h] = lc[h] = rc[h] = 0;
		}
		sum[h] ++;
		if (l == r) return ;
		u <= mid? insert(lc[h], l, mid, u) : insert(rc[h], mid + 1, r, u);
	}

	int query(int h, int l, int r, int ql, int qr)
	{
		if (!h) return 0;
		if (ql <= l && r <= qr) return sum[h];
		return (ql <= mid? query(lc[h], l, mid, ql, qr) : 0) + 
			(qr > mid? query(rc[h], mid + 1, r, ql, qr) : 0);
	}
	#undef mid

	void add(int y, int z)
	{
		for (; y <= yl; y += (y & -y)) insert(rt[y], 1, zl, z);
	}
	int ask(int y0, int y1, int z0, int z1)
	{
		int ret = 0;
		for (; y0 > 0; y0 -= (y0 & -y0)) ret -= query(rt[y0], 1, zl, z0, z1);
		for (; y1 > 0; y1 -= (y1 & -y1)) ret += query(rt[y1], 1, zl, z0, z1);
		return ret;
	}

	void solve(int l, int r)
	{
		if (l == r) return ;
		int mid = (l + r) >> 1;
		solve(l, mid); solve(mid + 1, r);

		for (int i = l; i <= r; ++i) q[i].ty = (i > mid);
		sort(q + l, q + r + 1);
//		for (int i = l; i <= r; ++i) {
//			printf("X[%d] = %d in %d%c", q[i].id, q[i].x, i, i != r? ' ':'\n');
//		}
		for (int i = l; i <= r; ++i) {
			if (!q[i].ty) { 
				if (q[i].opt == 1) add(q[i].y, q[i].z);
			}
			else {
				if (q[i].opt == 2) {
					ans[q[i].id] -= ask(q[i].y, q[i].y2, q[i].z, q[i].z2);
				}
				else if (q[i].opt == 3) {
//					if (q[i].id == 31) {
//						fprintf(stderr, "i = %d FUCKNUM [%d, %d] = %d\n", i, l, r, ask(q[i].y, q[i].y2, q[i].z, q[i].z2));
//					}
					ans[q[i].id] += ask(q[i].y, q[i].y2, q[i].z, q[i].z2);
				}
			}
		}
		//6 18 10
		//7 4 2
		//20 10 15

		tot = 0;
		for (int i = l; i <= r; ++i) {
			if (!q[i].ty && q[i].opt == 1) 
				for (int j = q[i].y; j <= yl; j += (j & -j)) rt[j] = 0;
		}
	}

	int cnt = 0;
	int qstk[N + 5], len;

	void main()
	{
		scanf("%d", &m);
		for (int i = 1; i <= m; ++i) {
			int opt = read(), sx = read(), sy = read(), sz = read();
			if (opt == 1) {
				xi[++xl] = sx; yi[++yl] = sy; zi[++zl] = sz;
				q[++cnt] = Point(sx, sy, sz, 1, 0, i, 0, 0);
			}
			else {
				int tx = read(), ty = read(), tz = read();

				q[++cnt] = Point(sx, sy, sz, 2, 0, i, ty, tz);
				q[++cnt] = Point(tx, sy, sz, 3, 0, i, ty, tz);
				qstk[++len] = i;
			}
		}

		sort(xi + 1, xi + xl + 1); xl = unique(xi + 1, xi + xl + 1) - xi - 1;
		sort(yi + 1, yi + yl + 1); yl = unique(yi + 1, yi + yl + 1) - yi - 1;
		sort(zi + 1, zi + zl + 1); zl = unique(zi + 1, zi + zl + 1) - zi - 1;
//		fprintf(stderr, "%d %d %d\n", xl, yl, zl);

		for (int i = 1; i <= cnt; ++i) {
			if (q[i].opt == 1) {
				q[i].x = lower_bound(xi + 1, xi + xl + 1, q[i].x) - xi;
				q[i].y = lower_bound(yi + 1, yi + yl + 1, q[i].y) - yi;
				q[i].z = lower_bound(zi + 1, zi + zl + 1, q[i].z) - zi;
			}
			else {
				if (q[i].opt == 2) 
					q[i].x = lower_bound(xi + 1, xi + xl + 1, q[i].x) - xi - 1;
				else 
					q[i].x = upper_bound(xi + 1, xi + xl + 1, q[i].x) - xi - 1;
				q[i].y = lower_bound(yi + 1, yi + yl + 1, q[i].y) - yi - 1;
				q[i].z = lower_bound(zi + 1, zi + zl + 1, q[i].z) - zi;
				q[i].y2 = upper_bound(yi + 1, yi + yl + 1, q[i].y2) - yi - 1;
				q[i].z2 = upper_bound(zi + 1, zi + zl + 1, q[i].z2) - zi - 1;
//				if (q[i].id == 31)
//					fprintf(stderr, "%d %d %d %d %d\n", q[i].x, q[i].y, q[i].z, q[i].y2, q[i].z2);
			}
		}

		fprintf(stderr, "%d %d %d\n", q[25].x, q[25].y, q[25].z);
//		fprintf(stderr, "%d\n", cnt);
		solve(1, cnt);
		for (int i = 1; i <= len; ++i) printf("%d\n", ans[qstk[i]]);
	}
}

int main()
{
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	JMXSYYC :: main();

	return 0;
}
