#include <bits/stdc++.h>

using std :: vector;

const int N = 1e5;

int n;
bool inq[N + 5];
vector<int> A, B;

int main()
{
	freopen("a.in", "r", stdin);
	freopen("a.ans", "w", stdout);

	scanf("%d", &n);

	inq[0] = true;
	A.push_back(0);

	for (int i = 1; i <= n; ++i) {
		int sumA = 0, sumB = 0;
		for (int j = 0; j < i; ++j) {
			if (j < i-j) {
				sumA += inq[j] && inq[i-j];
				sumB += (!inq[j]) && (!inq[i-j]);
			}
		}
		if (sumA == sumB) {
			B.push_back(i);
		}
		else {
			assert(sumA == sumB-1);
			A.push_back(i);
			inq[i] = true;
		}
	}
	
	for (int i = 0; i < (int)A.size(); ++i)
		printf("%d%c", A[i], i == (int)A.size()-1? '\n':' ');
	for (int i = 0; i < (int)B.size(); ++i)
		printf("%d%c", B[i], i == (int)B.size()-1? '\n':' ');

	return 0;
}
