#include <bits/stdc++.h>

int main()
{
	freopen("matrix.in", "w", stdout);

	srand(time(0));

	int n = 300; printf("%d\n", n);
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j) printf("%d", rand() & 1);
		putchar('\n');
	}
	for (int i = 1; i <= n; ++i) printf("%d", rand() & 1);

	int m = 100; printf("%d\n", m);
	for (int i = 1; i <= m; ++i)
		printf("%d\n", rand() % 1000000000 + 1);

	return 0;
}
