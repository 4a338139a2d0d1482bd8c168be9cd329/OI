#include <bits/stdc++.h>

using std :: bitset;
using std :: pair;

typedef pair<int, int> pii;

const int N = 3e2;

int n, m;

struct Matrix
{
	bitset<N + 5> e[N + 5];
}ret, res, E;
struct Vector
{
	bitset<N + 5> e;
}unit, RET, RES;
bitset<N + 5> tmp[N + 5];

Matrix operator * (const Matrix& A, const Matrix& B)
{
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j)
			tmp[j][i] = B.e[i][j];
	}
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j)
			ret.e[i][j] = (A.e[i] & tmp[j]).count() & 1;
	}
	return ret;
}
Vector operator * (const Matrix& A, const Vector& B)
{
	for (int i = 1; i <= n; ++i)
		RET.e[i] = (A.e[i] & B.e).count() & 1;
	return RET;
}

Matrix multy(Matrix A, int d)
{
	res = E;
	for (; d; d >>= 1) {
		if (d & 1) res = res * A;
		A = A * A;
	}
	return res;
}

int cnt = 0;
void calc(Matrix A, Vector& o, int d)
{
	for (; d; d >>= 1) {
		if (d & 1) o = A * o;
		A = A * A; cnt ++;
	}
}

bitset<N + 5> b, ans[100 + 5];
Matrix A; Vector cur;

pair<int, int> q[N + 5];

int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);

	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) E.e[i][i] = 1;

	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j) {
			int f; scanf("%1d", &f);
			A.e[i][j] = f;
		}
	}
	for (int i = 1; i <= n; ++i) {
		int f; scanf("%1d", &f);
		b[i] = f; unit.e[i] = f;
	}

	scanf("%d", &m);
	for (int c = 1; c <= m; ++c) {
		int x; scanf("%d", &x);
		q[c] = pii(x, c);
	}

	sort(q + 1, q + m + 1);

//	cur = E;
//	cur = A ^ q[m].first;
//	fprintf(stderr, "cnt= %d,  %.4lf\n", cnt, 1.0*clock()/CLOCKS_PER_SEC);
//	return 0;

	int lst = 0;
	cur = unit;
	for (int i = 1; i <= m; ++i) {
		if (q[i].first != lst)
			calc(A, cur, q[i].first - lst);

		for (int j = 1; j <= n; ++j)
			ans[q[i].second][j] = cur.e[j];

		lst = q[i].first;
	}

	for (int i = 1; i <= m; ++i) {
		for (int j = 1; j <= n; ++j) putchar(48 + ans[i][j]);
		putchar('\n');
	}
//	fprintf(stderr, "cnt = %d, %lf\n", cnt, 1.0*clock()/CLOCKS_PER_SEC);

	return 0;
}
