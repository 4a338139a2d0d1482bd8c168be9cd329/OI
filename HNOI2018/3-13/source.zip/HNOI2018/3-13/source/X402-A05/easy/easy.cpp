#include <bits/stdc++.h>

typedef long long LL;

const int N = 5e3;

void chkmin(LL &a, LL b)
{
	if (a > b) a = b;
}

int n, m;
int A[N + 5], B[N + 5];
LL dp[N + 5][N + 5];

int main()
{
	freopen("easy.in", "r", stdin);
	freopen("easy.out", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i = 0; i <= n; ++i) scanf("%d", &A[i]);
	for (int i = 0; i <= m; ++i) scanf("%d", &B[i]);

	for (int i = 0; i <= n; ++i) {
		for (int j = 0; j <= m; ++j)
			dp[i][j] = 1ll << 60;
	}

	dp[0][0] = 0;
	for (int i = 0; i <= n; ++i) {
		for (int j = 0; j <= m; ++j) {
			chkmin(dp[i+1][j], dp[i][j] + B[j]);
			chkmin(dp[i][j+1], dp[i][j] + A[i]);
		}
	}

	printf("%lld\n", dp[n][m]);

	return 0;
}
