#include <bits/stdc++.h>

const int N = 50;

bool ban[N + 5][N + 5];
int Left[N + 5][N + 5];
int Down[N + 5][N + 5];
int dp[N + 5][N + 5][2];

bool dfsBF(int x, int y, bool cur = 0)
{
//	printf("people : %d %d %d\n", cur, x, y);
	int &o = dp[x][y][cur];
	if (o != -1) return o;
	for (int i = 1; i <= x-Left[x][y]-1; ++i)
		if (!dfsBF(x - i, y, cur ^ 1)) {
			o = 1; return true;
		}
	for (int i = 1; i <= y-Down[x][y]-1; ++i)
		if (!dfsBF(x, y - i, cur ^ 1)) {
			o = 1; return true;
		}
	o = 0; return false;
}

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);

	int T; scanf("%d", &T);
	while (T --) {
		int n; scanf("%d", &n);
		if (n) {
			memset(ban, 0, sizeof ban);
			memset(Left, -1, sizeof Left);
			memset(Down, -1, sizeof Down);
			memset(dp, -1, sizeof dp);
		}
		for (int i = 1; i <= n; ++i) {
			int x, y;
			scanf("%d%d", &x, &y);
			ban[x][y] = 1;
		}

		if (n) {
			for (int i = 0; i <= 30; ++i) {
				for (int j = 0; j <= 30; ++j) {
					for (int k = j; k >= 0; --k)
						if (ban[i][k]) {
							Down[i][j] = k;
							break;
						}
					for (int k = i; k >= 0; --k)
						if (ban[k][j]) {
							Left[i][j] = k;
							break;
						}
				}
			}
		}

		int q; scanf("%d", &q);
		for (int i = 1; i <= q; ++i) {
			int x, y;
			scanf("%d%d", &x, &y);
			if (!n) puts(x == y? "Bob" : "Alice");
			else puts(dfsBF(x, y)? "Alice" : "Bob");
		}
	}

	return 0;
}
