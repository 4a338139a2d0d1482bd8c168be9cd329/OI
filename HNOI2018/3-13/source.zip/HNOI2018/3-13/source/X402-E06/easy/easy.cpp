#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 5000;

int n, m;
ll dp[N + 5][N + 5];
int a[N + 5], b[N + 5];

int main() {
    freopen("easy.in", "r", stdin);
    freopen("easy.out", "w", stdout);

    read(n), read(m);
    for(int i = 0; i <= n; ++i) read(a[i]);
    for(int i = 0; i <= m; ++i) read(b[i]);

    memset(dp, oo, sizeof dp);
    dp[0][0] = 0;
    for(int i = 0; i <= n; ++i) {
        for(int j = 0; j <= m; ++j) {
            if(i) chkmin(dp[i][j], dp[i-1][j] + b[j]);
            if(j) chkmin(dp[i][j], dp[i][j-1] + a[i]);
        }
    }
    printf("%lld\n", dp[n][m]);

    // std::cout << procStatus() << std::endl;

    return 0;
}
