#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 1000;

int n, m;
struct Matrix {
    bool res[N + 5][N + 5];

    Matrix () {
        memset(res, 0, sizeof res);
    }
};

Matrix operator * (const Matrix& a, const Matrix& b) {
    Matrix c;
    for(int i = 0; i < n; ++i) for(int j = 0; j < n; ++j) 
        for(int k = 0; k < n; ++k) c.res[i][j] ^= (a.res[i][k] & b.res[k][j]);
    return c;
}

Matrix fpm(const Matrix& x, int b) {
    Matrix c, a = x;
    for(int i = 0; i < n; ++i) c.res[i][i] = 1;

    for(; b > 0; b >>= 1) {
        if(b & 1)
            c = c * a;
        a = a * a;
    }
    return c;
}

Matrix a, x;
char st[N + 5];

int main() {
    freopen("matrix.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n);
    for(int i = 0; i < n; ++i) {
        scanf("%s", st);
        for(int j = 0; j < n; ++j) {
            a.res[i][j] = (st[j] - '0');
        }
    }

    scanf("%s", st);
    for(int i = 0; i < n; ++i) x.res[i][0] = (st[i] - '0');

    read(m);
    while(m--) {
        static int k;
        read(k);

        Matrix RES = fpm(a, k) * x;

        for(register int i = 0; i < n; ++i) 
            putchar(RES.res[i][0] + '0');
        puts("");
    }
    // std::cout << procStatus() << std::endl;

    return 0;
}
