#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 1000;

typedef std::bitset<N + 5> bset;

int n, m;
struct Matrix {
    bset lne[N + 5];

    inline void clear() {
        for(register int i = 0; i < n; ++i) lne[i].reset();
    }
};

inline void mg(const Matrix& a, const bset& b, bset& c) {
    for(register int i = 0; i < n; ++i) {
        c[i] = (a.lne[i] & b).count() & 1;
    }
}

inline void mul(const Matrix& a, const Matrix& b, Matrix& c) {
    c.clear();
    for(register int i = 0; i < n; ++i) {
        for(register int j = 0; j < n; ++j) {
            if(a.lne[i][j]) c.lne[i] ^= b.lne[j];
        }
    }
}

bset x;
char st[N + 5];
Matrix pw[30 + 5];

int main() {
    freopen("matrix.in", "r", stdin);
    freopen("matrix.out", "w", stdout);

    read(n);
    for(int i = 0; i < n; ++i) {
        scanf("%s", st);
        for(int j = 0; j < n; ++j) {
            pw[0].lne[i][j] = (st[j] - '0');
        }
    }

    scanf("%s", st);
    for(int i = 0; i < n; ++i) x[i] = (st[i] - '0');
    for(int i = 0; i < 29; ++i) mul(pw[i], pw[i], pw[i+1]);

    read(m);
    while(m--) {
        static int k;
        read(k);

        bset ans = x, tmp;
        for(register int i = 0; i <= 29; ++i) 
            if(k >> i & 1) mg(pw[i], tmp = ans, ans);

        for(register int i = 0; i < n; ++i) putchar(ans[i] + '0');
        puts("");
    }
    // std::cout << procStatus() << std::endl;

    return 0;
}
