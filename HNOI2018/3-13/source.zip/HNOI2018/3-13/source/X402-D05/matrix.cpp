#include<bits/stdc++.h>
using namespace std;
const int maxn=1010;
int n,m;
struct Matrix{
	bitset<maxn> a[maxn];
}Base[30];
bitset<maxn> lA[maxn],lB[maxn];
Matrix operator * (const Matrix &A,const Matrix &B){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(A.a[i].test(j))
				lA[i].set(j);
			else
				lA[i].reset(j);
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(B.a[i].test(j))
				lB[j].set(i);
			else
				lB[j].reset(i);
		}
	}
	Matrix res;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
			if((lA[i]&lB[j]).count()&1)
				res.a[i].set(j);
			else
				res.a[i].reset(j);
		}
	return res;
}
void Deal(const Matrix &x){
	Base[0]=x;
	for(int i=1;i<30;i++)
		Base[i]=Base[i-1]*Base[i-1];
}
bitset<maxn> v,vec,Vec;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	static Matrix x;
	static char str[maxn];
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%s",str);
		for(int j=0;j<n;j++){
			if(str[j]=='1')
				x.a[i].set(j);
			else
				x.a[i].reset(j);
		}
	}
	Deal(x);
	scanf("%s",str);
	for(int i=0;i<n;i++){
		if(str[i]=='1')
			v.set(i);
		else
			v.reset(i);
	}
	int M,k;
	scanf("%d",&M);
	for(m=1;m<=M;m++){
		scanf("%d",&k);
		vec=v;
		for(int p=0;p<30;p++){
			if(!(k&(1<<p))) continue;
			for(int i=0;i<n;i++){
				if((vec&Base[p].a[i]).count()&1)
					Vec.set(i);
				else
					Vec.reset(i);
			}
			vec=Vec;
		}
		for(int i=0;i<n;i++)
			printf("%d",vec.test(i));
		printf("\n");
	}
	return 0;
}
