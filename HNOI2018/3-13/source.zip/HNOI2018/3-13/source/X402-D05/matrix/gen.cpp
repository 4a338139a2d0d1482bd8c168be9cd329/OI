#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=300;
	printf("%d\n",n);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++)
			printf("%d",rand()%2);
		printf("\n");
	}
	for(int j=0;j<n;j++)
		printf("%d",rand()%2);
	printf("\n");
	int m=100;
	printf("%d\n",m);
	for(int i=1;i<=m;i++)
		printf("%d\n",rand()%1000000000);
}
int main(){
	srand(time(0)+getx());
	freopen("matrix.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
