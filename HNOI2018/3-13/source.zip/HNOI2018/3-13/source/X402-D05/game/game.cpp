#include<bits/stdc++.h>
using namespace std;
int ti;
const int maxn=100100;
const int INF=1e9+7;
int Min(int x,int y){
	return x<y?x:y;
}
long long Max(long long x,long long y){
	return x>y?x:y;
}
int n,m;
struct node{
	int x,y;
}a[maxn];
struct Asks{
	int x,y,id;
}b[maxn];
int ans[maxn];
bool cmpa(const node &A,const node &B){
	return A.x==B.x?A.y<B.y:A.x<B.x;
}
bool cmpb(const Asks &A,const Asks &B){
	return A.x==B.x?A.y<B.y:A.x<B.x;
}
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
void readin(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		readl(a[i].x),readl(a[i].y);
	sort(a+1,a+n+1,cmpa);
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		readl(b[i].x),readl(b[i].y);
		b[i].id=i;
	}
	sort(b+1,b+m+1,cmpb);
}
map<int,bool> mp,gmp;
set<int> sak;
int stk[maxn],top;
int val[maxn],cnt;
long long bound;
void Add_bound(){
	mp[bound]=1;
	bound++;
	while(gmp[bound]){
		gmp[bound]=0;
		bound++;
	}
}
void Addstk(int l,int r){
	top=1;
	stk[1]=-1;
	for(int i=l;i<=r;i++)
		stk[++top]=a[i].y;
	stk[top+1]=INF;
}
void delete_set(){
	mp.clear();
	set<int>::iterator it;
	for(int i=1;i<=top;i++){
		mp[stk[i]]=1;
		if(stk[i]==bound)
			Add_bound();
		if(stk[i]<bound){
			it=sak.lower_bound(stk[i]+1);
			if(it!=sak.end()&&(*it)<stk[i+1]){
				mp[*it]=1;
				sak.erase(it);
			}
			else if(stk[i+1]>bound){
				Add_bound();
			}
			if(stk[i]>=0)
				sak.insert(stk[i]);
		}
		else{
			int r=stk[i]+1;
			while(gmp[r]) r++;
			gmp[r]=1;
			mp[r]=1;
			gmp[stk[i]]=0;
		}
	}
}
void get_ans(int l,int r){
	for(int i=l;i<=r;i++)
		if(b[i].y<=bound)
			ans[b[i].id]=!mp[b[i].y];
}
void solve(){
	bound=-1;
	mp.clear();
	int l1=1,l2=1,r;
	for(int i=0;i<=1000000003;i++){
		ti=i;
		if(l1>n&&l2>m) break;
		if(sak.empty()&&i<Min(a[l1].x,b[l2].x)){
			bound+=Min(a[l1].x,b[l2].x)-1-i;
			Add_bound();
			i=Min(a[l1].x,b[l2].x)-1;
		}

		r=l1;
		while(r<=n&&a[r].x==i) r++;
		Addstk(l1,r-1);
		delete_set();
		l1=r;

		r=l2;
		while(r<=m&&b[r].x==i) r++;
		get_ans(l2,r-1);
		l2=r;
	}
}
int main(){
	freopen("game.in","r",stdin);
	int T;
	scanf("%d",&T);
	while(T--){
		readin();
		solve();
		for(int i=1;i<=m;i++){
			if(ans[i])
				printf("Alice\n");
			else
				printf("Bob\n");
		}
	}
	return 0;
}
