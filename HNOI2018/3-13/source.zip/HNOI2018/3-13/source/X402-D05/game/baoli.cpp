#include<bits/stdc++.h>
using namespace std;
int a[310][310],b[310][310];
int n,q;
int main(){
	freopen("game.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int T;
	scanf("%d",&T);
	int x,y;
	while(T--){
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d%d",&x,&y);
			b[x][y]=1;
		}
		for(int i=0;i<=300;i++){
			for(int j=0;j<=300;j++){
				for(int k=1;k<=300;k++){
					if(i-k<0) break;
					if(b[i-k][j]) break;
					if(!a[i-k][j]){
						a[i][j]=1;
						break;
					}
				}
				for(int k=1;k<=300;k++){
					if(j-k<0) break;
					if(b[i][j-k]) break;
					if(!a[i][j-k]){
						a[i][j]=1;
						break;
					}
				}
			}
		}
		scanf("%d",&q);
		for(int i=1;i<=q;i++){
			scanf("%d%d",&x,&y);
			if(n==0){
				if(x==y) printf("Bob\n");
				else printf("Alice\n");
				continue;
			}
			if(a[x][y])
				printf("Alice\n");
			else
				printf("Bob\n");
		}
	}
	return 0;
}
