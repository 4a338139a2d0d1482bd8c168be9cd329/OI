#include<bits/stdc++.h>
using namespace std;
const long long INF=1e17;
const int maxn=500100;
string procstatus(){
	ifstream t("/proc/self/status");
	return (string){istreambuf_iterator<char>(t),istreambuf_iterator<char>()};
}
void chkmin(long long &x,long long y){
	x=x<y?x:y;
}
int a[maxn],b[maxn];
long long dp[5010][5010];
int main(){
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=0;i<=m;i++)
		scanf("%d",&b[i]);
	if(n<=5000&&m<=5000){
		for(int i=0;i<=n;i++)
			for(int j=0;j<=m;j++)
				dp[i][j]=INF;
		dp[0][0]=0;
		for(int i=0;i<=n;i++){
			for(int j=0;j<=m;j++){
				if(i>0) chkmin(dp[i][j],dp[i-1][j]+b[j]);
				if(j>0) chkmin(dp[i][j],dp[i][j-1]+a[i]);
			}
		}
		printf("%lld\n",dp[n][m]);
		return 0;
	}
	else{
		long long ans=INF;
		for(int i=0;i<=n;i++)
			chkmin(ans,b[0]*(long long)i+b[m]*(long long)(n-i)+a[i]*(long long)m);
		printf("%lld\n",ans);
	}
	return 0;
}
