#include<bits/stdc++.h>
using namespace std;
const long long INF=1e17;
const int maxn=500100;
void chkmin(long long &x,long long y){
	x=x<y?x:y;
}
int a[maxn],b[maxn];
int main(){
	freopen("easy.in","r",stdin);
	freopen("test.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=0;i<=m;i++)
		scanf("%d",&b[i]);
	long long ans=INF;
	for(int i=0;i<=n;i++)
		chkmin(ans,b[0]*(long long)i+b[m]*(long long)(n-i)+a[i]*(long long)m);
	printf("%lld\n",ans);
	cerr<<ans<<endl;
	return 0;
}
