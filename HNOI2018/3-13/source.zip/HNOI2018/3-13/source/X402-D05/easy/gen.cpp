#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=rand()%5000+1,m=rand()%5000+1;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%1000000000+1);
	printf("\n");
	for(int i=1;i<=m;i++)
		printf("%d ",i);
	printf("\n");
}
int main(){
	srand(time(0)+getx());
	freopen("easy.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
