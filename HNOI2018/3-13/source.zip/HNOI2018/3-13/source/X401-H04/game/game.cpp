#include <cstring>
#include <cstdio>
#include <algorithm>
const int MAXN = 30;
using namespace std;

int T, N, Q;
bool map[MAXN + 5][MAXN + 5], win[MAXN + 5][MAXN + 5];

int main() {
	freopen("game.in", "rt", stdin);
    freopen("game.out", "wt", stdout);
	
    int i, x, y;
    scanf("%d", &T);
    while(T--) {
        scanf("%d", &N);
        
        memset(map, 0, sizeof(map));
        for(i = 1; i <= N; i++) {
            scanf("%d%d", &x, &y);
            map[x][y] = 1;
        }

		scanf("%d", &Q);
        if(N == 0) {
            while(Q--) {
                scanf("%d%d", &x, &y);
                printf( ( (x ^ y) != 0 ) ? "Alice\n" : "Bob\n" );
            }
        }
        else
        {
            for(y = 0; y <= MAXN; y++) for(x = 0; x <= MAXN; x++) {
                bool haveLose = 0;

                //Move Left
                for(i = x - 1; i >= 0; i--) {
                    if(map[i][y]) break;
                    haveLose |= !win[i][y];
                }
                //Move Down
                for(i = y - 1; i >= 0; i--) {
                    if(map[x][i]) break;
                    haveLose |= !win[x][i];
                }

                win[x][y] = haveLose;
            }

            while(Q--) {
                scanf("%d%d", &x, &y);
                printf(win[x][y] ? "Alice\n" : "Bob\n");
            }
        }
    }
}
