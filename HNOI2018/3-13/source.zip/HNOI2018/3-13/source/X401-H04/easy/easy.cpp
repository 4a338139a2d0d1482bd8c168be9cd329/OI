#include <cstring>
#include <cstdio>
#include <algorithm>
#define ll long long
const ll INFLL = 0x3f3f3f3f3f3f3f3fLL;
using namespace std;

const int MAXN = 5010;
ll dp[MAXN][MAXN];
int N, M, A[MAXN], B[MAXN];

inline void update(ll &x, ll y) { x = x < y ? x : y; }

int main() {
    freopen("easy.in", "rt", stdin);
    freopen("easy.out", "wt", stdout);

    int x, y;
    scanf("%d%d", &N, &M);
    for(x = 0; x <= N; x++) scanf("%d", &A[x]);
    for(y = 0; y <= M; y++) scanf("%d", &B[y]);

    memset(dp, 0x3f, sizeof(dp));
    dp[0][0] = 0;
    for(x = 0; x <= N; x++) for(y = 0; y <= M; y++) {
        update(dp[x][y + 1], dp[x][y] + A[x]);
        update(dp[x + 1][y], dp[x][y] + B[y]);
    }

    printf("%lld", dp[N][M]);
}
