#include <cstring>
#include <cstdio>
#include <algorithm>
#include <bitset>
const int MAXLOG = 29;
using namespace std;

struct matrix {
    bitset<1000> d[1000];
    int r, c;
    inline matrix transpose() const {
        matrix ret;
        ret.r = c, ret.c = r;
        for(int i = 0; i < ret.r; i++) for(int j = 0; j < ret.c; j++)
            ret.d[i][j] = d[j][i];
        return ret;
    }
    inline matrix operator*(const matrix &rhs) const {
        matrix ret, rhsT = rhs.transpose();
        ret.r = r, ret.c = rhs.c;
        for(int i = 0; i < ret.r; i++) for(int j = 0; j < ret.c; j++)
            ret.d[i][j] = ((d[i] & rhsT.d[j]).count()) & 1;
        return ret;
    }
};

int N, Q, K;
matrix A[MAXLOG + 5], B, Ans;

char str[1024];
int main() {
    freopen("matrix.in", "rt", stdin);
    freopen("matrix.out", "wt", stdout);

    int i, j;

    scanf("%d", &N);
    //Read A
    A[0].r = A[0].c = N;
    for(i = 0; i < N; i++) {
        scanf("%s", str);
        for(j = 0; j < N; j++) A[0].d[i][j] = (str[j] - '0');
    }
    //QPow
    for(i = 1; i <= MAXLOG; i++) A[i] = A[i - 1] * A[i - 1];

    //Read B
    B.r = N, B.c = 1;
    scanf("%s", str);
    for(i = 0; i < N; i++) B.d[i][0] = (str[i] - '0');

    scanf("%d", &Q);
    while(Q--) {
        scanf("%d", &K);
        Ans = B;
        for(i = 0; i <= MAXLOG; i++) if((K >> i) & 1) {
            Ans = A[i] * Ans;
        }

        for(i = 0; i < N; i++) putchar(Ans.d[i][0] + '0');
        putchar('\n');
    }
}
