#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
}
int T,n,m,q;
int p[N][N],vis[N],G[N][N];
inline int Solve(int x,int y)
{
	if(!n)return x^y;
	return G[x][y];
}
inline void init()
{
	For(i,0,m)For(j,0,m)
	{
		For(k,1,j){if(p[i][j-k])break;vis[G[i][j-k]]=1;}
		For(k,1,i){if(p[i-k][j])break;vis[G[i-k][j]]=1;}
		for(int x=0;;x++)if(!vis[x]){G[i][j]=x;break;}
		//printf("(%d %d) %d\n",i,j,G[i][j]);
		For(k,1,j){if(p[i][j-k])break;vis[G[i][j-k]]=0;}
		For(k,1,i){if(p[i-k][j])break;vis[G[i-k][j]]=0;}
	}
}
int main()
{
	int x,y;
	file();
	m=100;
	read(T);
	while(T--)
	{
		read(n);
		For(i,1,n)
		{
			read(x),read(y);
			p[x][y]=1;
		}
		if(n)init();
		read(q);
		while(q--)
		{
			read(x),read(y);
			printf("%s\n",Solve(x,y)?"Alice":"Bob");
		}
	}
	return 0;
}
