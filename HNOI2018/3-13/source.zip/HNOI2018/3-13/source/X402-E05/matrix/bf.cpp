#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("matrix.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,m,k;
char s[N];
struct Matrix{bitset<N>x[N];}a[31];
struct Line{bitset<N>x;}b,ans;
inline Matrix mult(const Matrix&A,const Matrix&B)
{
	Matrix C;
	For(i,1,n)C.x[i].reset();
	For(i,1,n)
		For(j,1,n)
			For(k,1,n)
				C.x[i][j]=C.x[i][j]^(A.x[i][k]&B.x[k][j]);
	return C;
}
inline Line mult(const Matrix&A,const Line&B)
{
	Line C;C.x.reset();
	For(i,1,n)
		For(j,1,n)
			C.x[i]=C.x[i]^(A.x[i][j]&B.x[j]);
	return C;
}
inline Line qpow(Line A,int x)
{
	int now=0;
	for(;x;x>>=1,now++)
		if(x&1)A=mult(a[now],A);
	return A;
}
int main()
{
	file();
	read(n);
	For(i,1,n)
	{
		scanf("%s",s+1);
		For(j,1,n)a[0].x[i][j]=s[j]-'0';
	}
	For(i,1,30)a[i]=mult(a[i-1],a[i-1]);
	scanf("%s",s+1);
	For(i,1,n)b.x[i]=s[i]-'0';
	read(m);
	while(m--)
	{
		read(k);
		ans=qpow(b,k);
		For(i,1,n)printf("%d",(int)ans.x[i]);
		puts("");
	}
	return 0;
}
