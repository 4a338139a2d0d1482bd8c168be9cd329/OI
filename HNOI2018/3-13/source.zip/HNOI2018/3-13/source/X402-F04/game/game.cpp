//2018-3-13
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (30 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

int n, q;
bool win[N][N], ban[N][N], vis[N][N];

bool Solve(int x, int y){
	if(vis[x][y]) return win[x][y];

	vis[x][y] = true;
	if(x == 0 && y == 0) return win[x][y] = false;

	For(a, 1, x){
		if(ban[x - a][y]) break;
		if(!Solve(x - a, y)) return win[x][y] = true;
	}
	For(b, 1, y){
		if(ban[x][y - b]) break;
		if(!Solve(x, y - b)) return win[x][y] = true;
	}
	return false;
}

void Bf(int x, int y){
	if(Solve(x, y)) puts("Alice");
	else puts("Bob");
}

int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);

	int T, x, y;

	Read(T);
	while(T --){
		Set(win, 0); Set(ban, 0); Set(vis, 0);

		Read(n);
		For(i, 1, n){
			Read(x), Read(y);
			if(x <= 30 && y <= 30) ban[x][y] = true;
		}

		scanf("%d", &q);
		For(i, 1, q){
			Read(x), Read(y);
			if(x <= 30 && y <= 30) Bf(x, y);
			else{
				if(x == y) puts("Bob");
				else puts("Alice");
			}
		}
	}
	
	return 0;
}
