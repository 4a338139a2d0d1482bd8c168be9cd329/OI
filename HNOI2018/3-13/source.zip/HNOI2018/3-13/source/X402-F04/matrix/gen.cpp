//2018-3-13
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int main(){
	freopen("matrix.in", "w", stdout);

	srand(time(NULL));
	int n = 300, Q = 100;
	printf("%d\n", n);

	For(i, 1, n + 1){
		For(j, 1, n) printf("%c", rand()%3? '1': '0');
		puts("");
	}
	printf("%d\n", Q);
	For(i, 1, Q) printf("%d\n", rand() % 1000000001);

	return 0;
}
