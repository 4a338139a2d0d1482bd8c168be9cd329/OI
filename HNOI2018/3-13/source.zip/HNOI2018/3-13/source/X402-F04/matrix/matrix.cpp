//2018-3-13
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define LOG 31
#define N (300 + 5)

struct Qus{
	int id, v;
	bool operator <(const Qus &rhs)const{
		return v < rhs.v;
	}
}qus[N];

int n;
bitset<N> x, ans[N], tmp[N];

struct Matrix{
	bitset<N> mt[N];
	
	Matrix(){For(i, 1, n) mt[i].reset();}
	Matrix operator *(const Matrix &rhs)const{
		Matrix ret;
		For(i, 1, n) tmp[i].reset();
		For(i, 1, n) For(j, 1, n) if(rhs.mt[i][j]) tmp[j].set(i);

		For(i, 1, n) if(mt[i].count()) For(j, 1, n)
			if((mt[i] & tmp[j]).count() & 1) ret.mt[i].set(j);
		
		return ret;
	}
}ra, h[LOG], a;

char s[N];
bool flag;

void Init(){
	For(i, 1, n) h[0].mt[i] = ra.mt[i];
	For(i, 1, 29) h[i] = h[i - 1] * h[i - 1];
}

void Pow(int anum){
	Forr(i, 29, 0) if(anum >= (1 << i)){
		anum -= 1 << i;
		if(flag){
			flag = false;
			For(j, 1, n) a.mt[j] = h[i].mt[j];
		}else a = h[i] * a;
	}
}

int main(){
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	
	scanf("%d", &n);
	For(i, 1, n){
		scanf("%s", s + 1);
		For(j, 1, n) if(s[j] == '1') ra.mt[i].set(j);
	}
	scanf("%s", s + 1);
	For(i, 1, n) if(s[i] == '1') x.set(i);
	
	int Q, rt, o;

	scanf("%d", &Q);
	For(i, 1, Q){
		scanf("%d", &rt); qus[i] = (Qus){i, rt};
		ans[i].reset();
	}
	sort(qus + 1, qus + Q + 1);

	Init(); flag = true;
	For(i, 1, Q){
		o = qus[i].id;

		Pow(qus[i].v - qus[i - 1].v);
		if(qus[i].v){
			For(j, 1, n)
				if((a.mt[j] & x).count() & 1) ans[o].set(j);
		}else{
			For(j, 1, n) if(x[j]) ans[o].set(j);
		}
	}
	
	For(i, 1, Q){
		For(j, 1, n) printf("%c", ans[i][j]? '1': '0');
		puts("");
	}

	return 0;
}
