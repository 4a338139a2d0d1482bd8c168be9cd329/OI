//2018-3-13
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (5000 + 5)
#define N (500000 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

inline void Get(LL &a, LL b){
	if(a > b) a = b;
}

LL f[M][M];
int n, m, a[N], b[N];

void Bf(){
	For(i, 0, n) For(j, 0, m) f[i][j] = 1ll << 60;
	f[0][0] = 0;

	For(i, 0, n) For(j, 0, m) if(f[i][j] < 1ll << 60){
		Get(f[i + 1][j], f[i][j] + b[j]);
		Get(f[i][j + 1], f[i][j] + a[i]);
	}

	printf("%lld\n", f[n][m]);
}

void Cheat(){
	LL ans = 1ll << 60, tans;

	For(i, 0, m){
		tans = (LL)b[i] * n;
		tans += (LL)a[0] * i + (LL)a[n] * (m - i);
		ans = min(ans, tans);
	}
	For(i, 0, n){
		tans = (LL)a[i] * m;
		tans += (LL)b[0] * i + (LL)b[m] * (n - i);
		ans = min(ans, tans);
	}

	printf("%lld\n", ans);
}

int main(){
	freopen("easy.in", "r", stdin);
	freopen("easy.out", "w", stdout);

	Read(n), Read(m);
	For(i, 0, n) Read(a[i]); For(i, 0, m) Read(b[i]);

	if(n <= 5000 && m <= 5000){
		Bf(); return 0;
	}
	Cheat();

	return 0;
}
