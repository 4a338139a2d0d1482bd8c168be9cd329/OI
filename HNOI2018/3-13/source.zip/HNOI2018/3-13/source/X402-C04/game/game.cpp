#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=1e5+9;
const int M=2000;

int n,q,tim;
int g[M][M],f[M][M],vis[N];

inline void pre()
{
	memset(f,0,sizeof(f));tim=0;
	memset(vis,0,sizeof(vis));
	for(int i=0;i<=n;i++)
		for(int j=0;j<=n;j++)
		{
			tim++;
			for(int p=i-1;p>=0 && !g[p][j];p--)
				vis[f[p][j]]=tim;
			for(int p=j-1;p>=0 && !g[i][p];p--)
				vis[f[i][p]]=tim;
			for(int p=0;;p++)
				if(vis[p]!=tim)
				{
					f[i][j]=p;
					break;
				}
		}
}

inline int minaa()
{
	q=read();
	while(q--)
	{
		int x=read(),y=read();
		puts(x==y?"Bob":"Alice");
	}
}

inline int mina()
{
	n=read();if(!n)return minaa();

	memset(g,0,sizeof(g));
	int mv=0;
	for(int i=1,x,y;i<=n;i++)
	{
		x=read();y=read();
		g[x][y]=1;
		mv=max(mv,x);
		mv=max(mv,y);
	}

	if(mv>300)
	{
		q=read();
		while(q--)
		{
			int x=read(),y=read();
			puts("Alice");
		}
		return 0;
	}

	n=300;pre();
	q=read();
	for(int _=1,x,y;_<=q;_++)
	{
		x=read();y=read();
		puts(f[x][y]?"Alice":"Bob");
	}
	
	return 0;
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);

	int T=read();
	while(T--)
		mina();

	return 0;
}
