#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=10;
const int M=1e9+1;

inline int urand()
{
	return abs(((long long)rand()<<15|rand())&2147483647);
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("easy.in","w",stdout);

	int n=5000,m=5000;
	printf("%d %d\n",n,m);
	for(int i=0;i<=n;i++)
		printf("%d ",rand()%N);
	puts("");
	for(int i=0;i<=m;i++)
		printf("%d ",i);
	puts("");
	return 0;
}
