#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=500009;
const int M=5009;

int n,m;
ll a[N],b[N];
ll f[M][M],ans=1e18;

inline void chkmin(ll &a,ll b){if(a>b)a=b;}

namespace mina30
{
	inline ll calc(int p)
	{
		return a[p]*(ll)m+(ll)m*((ll)n-p);
	}

	int main()
	{
		for(int i=1;i<=n;i++)
			chkmin(ans,calc(i));
		printf("%lld\n",ans);
		return 0;
	}
}

int main()
{
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);

	n=read();m=read();bool fl=0;
	for(int i=0;i<=n;i++)
		a[i]=read();
	for(int j=0;j<=m;j++)
		if((b[j]=read())!=j)
			fl=1;
	if(!fl && (n>5000 || m>5000))
		return mina30::main();

	memset(f,127,sizeof(f));
	f[0][0]=0;
	for(int i=0;i<=n;i++)
		for(int j=0;j<=m;j++)
		{
			if(i>0)chkmin(f[i][j],f[i-1][j]+b[j]);
			if(j>0)chkmin(f[i][j],f[i][j-1]+a[i]);
		}
	
	printf("%lld\n",f[n][m]);
	return 0;
}
