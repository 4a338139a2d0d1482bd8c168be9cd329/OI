#include<bits/stdc++.h>
using namespace std;

const int N=1009;
const int K=31;

typedef unsigned long long ull;
const int B=63;
const int E=64;

int n,m,k;
char s[N]; 

inline ull minn(ull a,ull b){return a<b?a:b;}

struct bit
{
	ull a[N/E+1],len;
	inline int test(int p){return (a[p/E]>>(p&B))&1;}
	inline void init(){for(int i=0;i<=len;i++)a[i]=0;}
	inline void set(int p,int v)
	{
		if(v)
			a[p/E]|=1<<(p&B);
		else if(test(p))
			a[p/E]^=1<<(p&B);
	}
};

inline int and_count(bit a,bit b)
{
	int ret=0;
	for(int i=0,e=minn(a.len,b.len);i<=e;i++)
		ret+=__builtin_popcount(a.a[i]&b.a[i]);
	return ret;
}

struct matrix
{
	int lena,lenb;
	bit a[N],b[N];

	inline void init()
	{
		for(int i=0;i<=lena;i++)
			a[i].len=lenb/E,a[i].init();
		for(int i=0;i<=lenb;i++)
			b[i].len=lena/E,b[i].init();
	}

	matrix(){init();}
	matrix(int aa,int bb){lena=aa;lenb=bb;init();}
	inline void set(int x,int y,int v){a[x].set(y,v);b[y].set(x,v);}

	inline matrix operator * (matrix o)const
	{
		matrix ret(lena,o.lenb);
		for(int i=0;i<lena;i++)
			for(int j=0;j<o.lenb;j++)
				ret.set(i,j,and_count(a[i],o.b[j])&1);
		return ret;
	}

	inline void e()
	{
		for(int i=0;i<lena;i++)
			a[i].set(i,1),b[i].set(i,1);
	}
}base[K],x;

inline matrix qpow(int b)
{
	matrix ret(base[0].lena,base[0].lenb);ret.e();
	for(int i=K-1;i>=0;i--)
		if(b>>i&1)
			ret=ret*base[i];
	return ret;
}

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);

	scanf("%d",&n);
	base[0].lena=base[0].lenb=n;
	for(int i=0;i<n;i++)
	{
		scanf("%s",s);
		for(int j=0;j<n;j++)
			base[0].set(i,j,s[j]-'0');
	}

	scanf("%s",s);
	x.lena=n;x.lenb=1;
	for(int i=0;i<n;i++)
		x.set(i,0,s[i]-'0');
	
	for(int i=1;i<K;i++)
		base[i]=base[i-1]*base[i-1];

	scanf("%d",&m);
	while(m--)
	{
		scanf("%d",&k);
		matrix ret=qpow(k)*x;
 		for(int i=0;i<n;i++)
			printf("%d ",ret.a[i].test(0));
		puts("");
	}

	return 0;
}
