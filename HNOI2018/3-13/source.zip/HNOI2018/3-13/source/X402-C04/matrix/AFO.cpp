#include<bits/stdc++.h>
using namespace std;

const int N=1009;
const int K=31;
typedef bitset<N> bit;

int n,m,k;
char s[N]; 

struct matrix
{
	int lena,lenb;
	bit a[N],b[N];

	inline void init()
	{
		for(int i=0;i<lena;i++)
			a[i].reset();
		for(int i=0;i<lenb;i++)
			b[i].reset();
	}

	inline void set(int x,int y,int v=1){a[x][y]=v;b[y][x]=v;}

	matrix(){init();}
	matrix(int a,int b){lena=a;lenb=b;init();}

	inline matrix operator * (matrix o)const
	{
		static bit tmp;
		matrix ret(lena,o.lenb);

		for(int i=0;i<lena;i++)
			for(int j=0;j<o.lenb;j++)
				ret.set(i,j,((a[i]&o.b[j]).count()&1));
		return ret;
	}

	inline void e()
	{
		for(int i=0;i<lena;i++)
			a[i][i]=1,b[i][i]=1;
	}

	inline void output()
	{
		for(int i=0;i<lena;i++,puts(""))
			for(int j=0;j<lenb;j++)
				printf("%d ",a[i].test(j));
	}
}base[K],x;

inline matrix qpow(int b)
{
	matrix ret(base[0].lena,base[0].lenb);ret.e();
	for(int i=K-1;i>=0;i--)
		if(b>>i&1)
			ret=ret*base[i];
	return ret;
}

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrixs.out","w",stdout);

	scanf("%d",&n);
	base[0].lena=base[0].lenb=n;
	for(int i=0;i<n;i++)
	{
		scanf("%s",s);
		for(int j=0;j<n;j++)
			base[0].set(i,j,s[j]-'0');
	}

	scanf("%s",s);
	x.lena=n;x.lenb=1;
	for(int i=0;i<n;i++)
		x.set(i,0,s[i]-'0');
	
	for(int i=1;i<K;i++)
		base[i]=base[i-1]*base[i-1];

	scanf("%d",&m);
	while(m--)
	{
		scanf("%d",&k);
		matrix ret=qpow(k)*x;
 		for(int i=0;i<n;i++)
			printf("%d ",ret.a[i].test(0));
		puts("");
	}

	return 0;
}
