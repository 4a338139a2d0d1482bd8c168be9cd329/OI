#include<bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int N=100;
const int M=1e9+1;

inline int urand()
{
	return abs(((long long)rand()<<15|rand())&2147483647);
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("matrix.in","w",stdout);

	int n=150,m=80;
	printf("%d\n",n);
	for(int i=1;i<=n;i++,puts(""))
		for(int j=1;j<=n;j++)
			putchar('0'+rand()%2);
	for(int j=1;j<=n;j++)
		putchar('0'+rand()%2);
	printf("\n%d\n",m);
	for(int i=1;i<=m;i++)
		printf("%d\n",urand()%M);
	return 0;
}
