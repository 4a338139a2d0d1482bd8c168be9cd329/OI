#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for (int i = j; i <= k; i++)

int Read() {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	int x = c - '0'; c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

using namespace std;

const int N = 5e5 + 10;

int n, m;
int A[N], B[N];

namespace BF {

	long long dp[5010][5010];

	void main() {
		For(i, 0, n) For(j, 0, m) {
			if (i || j) dp[i][j] = 1ll << 60;
			if (i) dp[i][j] = min(dp[i][j], dp[i - 1][j] + B[j]);
			if (j) dp[i][j] = min(dp[i][j], dp[i][j - 1] + A[i]);
		}
		printf("%lld\n", dp[n][m]);
	}

};

namespace Cheat {

	void main() {
		long long ans = 1ll << 60;
		For(i, 0, n) ans = min(ans, 1ll * m * (n - i + A[i]));
		printf("%lld\n", ans);
	}

};

int main() {

	freopen("easy.in", "r", stdin);
	freopen("easy.out", "w", stdout);

	n = Read(), m = Read();
	For(i, 0, n) A[i] = Read();
	For(i, 0, m) B[i] = Read();

	if (n <= 5000 && m <= 5000) BF::main();
	else Cheat::main();

	return 0;
}
