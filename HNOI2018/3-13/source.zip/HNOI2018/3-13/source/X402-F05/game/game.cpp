#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1050, M = 1e5 + 10;

int X[M], Y[M], qx[M], qy[M];
int n, m, q;

bool dp[N][N], Map[N][N];

namespace BF {	

	int fx[N], fy[N];

	void DP() {
		memset(fx, false, sizeof fx);
		memset(fy, false, sizeof fy);
		For(i, 0, m) {
			For(j, 0, m) {
				if (Map[i][j]) {
					fx[i] = fy[j] = 0;
				//	putchar('x'); 
					continue;
				}
				dp[i][j] = fx[i] | fy[j];
				if (!dp[i][j]) fx[i] = fy[j] = true;
				//printf("%d", int(dp[i][j]));
			}
			//puts("");
		}

	}

	void main() {

		memset(Map, 0, sizeof Map);
		For(i, 1, n) Map[X[i]][Y[i]] = 1;
		DP();
		For(i, 1, q) puts(dp[qx[i]][qy[i]] ? "Alice" : "Bob");

	}
}

namespace Cheat {

	int p[N], c = 0;

	void main() {
		p[c = 1] = 0;
		For(i, 1, n) {
			For(j, 0, 23) p[++c] = X[i] + j;
			For(j, 0, 23) p[++c] = Y[i] + j;
		}
		sort(p + 1, p + c + 1), c = unique(p + 1, p + c + 1) - p - 1;

		memset(Map, 0, sizeof Map);
		For(i, 1, n) {
			int u = lower_bound(p + 1, p + c + 1, X[i]) - p,
				v = lower_bound(p + 1, p + c + 1, Y[i]) - p;
			Map[u][v] = true;
		}
		m = c;
		BF::DP();

		For(i, 1, q) {
			int nx = upper_bound(p + 1, p + c + 1, qx[i]) - p - 1;
			int d = qx[i] - p[nx];
			qx[i] -= d, qy[i] -= d;
			int ny = upper_bound(p + 1, p + c + 1, qy[i]) - p - 1;

			d = qy[i] - p[ny];
			qx[i] -= d, qy[i] -= d;
			nx = upper_bound(p + 1, p + c + 1, qx[i]) - p - 1;

			if (!ny || !nx || p[nx] != qx[i]) puts("Alice");
			else puts(dp[nx][ny] ? "Alice" : "Bob");
		}
	}

};

int main() {

	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);

	int Case;
	scanf("%d", &Case);

	while (Case--) {
		scanf("%d", &n);

		m = 0;
		For(i, 1, n) {
			int x, y;
			scanf("%d%d", &x, &y);
			m = max(m, max(x, y));
			X[i] = x, Y[i] = y;
		}
		scanf("%d", &q);
		For(i, 1, q) {
			int x, y;
			scanf("%d%d", &x, &y);
			m = max(m, max(x, y));
			qx[i] = x, qy[i] = y;
		}

		if (m <= 1000) {
			BF::main();
		} else if (!n) {
			For(i, 1, q) puts(qx[i] == qy[i] ? "Bob" : "Alice");
		} else {
			Cheat::main();
		}

	}


	return 0;
}
