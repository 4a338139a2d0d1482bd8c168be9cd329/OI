#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int main() {

	freopen("matrix.in", "w", stdout);

	srand(time(0));
	int n = 1000, m = 100;
	
	printf("%d\n", n);
	For(i, 1, n + 1) {
		For(j, 1, n) putchar(rand() % 2 + '0');
		puts("");
	}
	printf("%d\n", m);
	while (m--) printf("%d\n", rand() % (1 << 30));

	return 0;
}
