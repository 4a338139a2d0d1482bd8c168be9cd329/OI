#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1010;

typedef bitset<N> Vector;

struct Matrix {
	Vector A[N];
}M[32];

int n, m;

void mul(Matrix &ret, const Matrix &A, const Matrix &B) {
	static Vector b[N];
	For(i, 1, n) For(j, 1, n) b[i][j] = B.A[j][i];
	For(i, 1, n) For(j, 1, n) ret.A[i][j] = (A.A[i] & b[j]).count() & 1;
}

Vector operator * (const Matrix &A, const Vector& B) {
	static Vector ret;
	For(i, 1, n) ret[i] = (A.A[i] & B).count() & 1;
	return ret;
}

char S[N];
Vector B;

int main() {

	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	
	scanf("%d", &n);
	For(i, 1, n) {
		scanf("%s", S + 1);
		For(j, 1, n) M[0].A[i][j] = S[j] - '0';
	}
	
	scanf("%s", S + 1);
	For(i, 1, n) B[i] = bool(S[i] - '0');
	For(i, 1, 29) mul(M[i], M[i - 1], M[i - 1]);
	
//	cerr << 1.0 * clock() / CLOCKS_PER_SEC << endl;

	scanf("%d", &m);
	while (m--) {
		
		Vector ans = B;
		int st;
		scanf("%d", &st);
		For(i, 0, 29) if (st & (1 << i)) ans = M[i] * ans;
		For(i, 1, n) putchar(ans[i] ? '1' : '0');
		puts("");

	}

	return 0;
}
