#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 5010;
int INF;
template<class T>void read(T &x){
	x=0;char c = getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
}
int n, A[N], B[N], m;
ll f[N][N];
void init(){
	read(n), read(m);
	For(i, 0, n)read(A[i]);
	For(i, 0, m)read(B[i]);
}
void solve(){
	memset(f, 0x3f, sizeof(f));
	INF = f[0][0];
	f[0][0] = 0;
	For(i, 0, n){
		For(j, 0, m)if(f[i][j] < INF){
			f[i + 1][j] = min(f[i + 1][j], f[i][j] + B[j]);
			f[i][j + 1] = min(f[i][j + 1], f[i][j] + A[i]);
		}
	}
	printf("%lld\n", f[n][m]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
