#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 20, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int n, m;
struct Mat{
	int a[N][N];
	void clear(){memset(a, 0, sizeof(a));}
	Mat operator *(const Mat &B)const {
		Mat C;C.clear();
		For(k, 1, n)
			For(i, 1, n)if(a[i][k])
				For(j, 1, n)
					C.a[i][j] ^= B.a[k][j];	
		return C;
	}	
	Mat operator ^(int b)const {
		Mat ret, A = *this;ret.clear();
		For(i, 1, n)ret.a[i][i] = 1;
		for(;b;b>>=1, A=A*A)if(b&1)ret = ret * A;
		return ret;
	}
}F, X, ans;
inline void file(){
	freopen("matrix.in","r",stdin);
	freopen("BF.out","w",stdout);
}

char s[N];
void init(){
	read(n);
	For(i, 1, n){
		scanf("%s", s + 1);
		For(j, 1, n)F.a[i][j] = s[j] == '1';
	}
	scanf("%s", s + 1);
	For(i, 1, n)X.a[i][1] = s[i] == '1';
}
void solve(){
	read(m);
	while(m--){
		int k;
		read(k);
		ans = (F ^ k) * X;
		For(i, 1, n)printf("%d",ans.a[i][1]);
		puts("");
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}

