#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 1005, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int n, m;
struct Mat{
	bitset<N>a[N];
	void clear(){For(i, 1, n)a[i].reset();}
	Mat operator *(const Mat &B)const {
		Mat C;C.clear();
		For(k, 1, n)For(i, 1, n)if(a[i][k])C.a[i]^=B.a[k];
		return C;
	}	
	bitset<N> operator *(const bitset<N> B)const {
		bitset<N> C;C.reset();
		For(i, 1, n)
			C[i] = (B&a[i]).count() & 1;
		return C;
	}
}F[31];
inline void file(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
}

bitset<N>ans, X;
char s[N];
void init(){
	read(n);
	For(i, 1, n){
		scanf("%s", s + 1);
		For(j, 1, n)F[0].a[i][j] = s[j] == '1';
	}
	For(i, 1, 30)F[i] = F[i - 1] * F[i - 1];
	scanf("%s", s + 1);
	For(i, 1, n)X[i] = s[i] == '1';
}
void solve(){
	read(m);
	while(m--){
		int k;
		read(k);
		ans = X;
		For(i, 0, 30)if(k & (1<<i))ans = F[i] * ans;
		For(i, 1, n)printf("%d", (int)ans[i]);
		puts("");
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
