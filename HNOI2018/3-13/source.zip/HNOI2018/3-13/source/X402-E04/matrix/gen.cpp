#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;


int main(){
	freopen("matrix.in","w",stdout);
	srand(time(0));
	int n = rand()%100+1;
	printf("%d\n",n);
	For(i, 1, n){
		For(j, 1, n){
			printf("%d",1);
		}
		puts("");
	}
	For(i, 1, n)printf("%d",1);
	puts("");
	int m = rand()%20+1;
	printf("%d\n",m);
	For(i, 1, m)
		printf("%d\n", rand()%((int)1e9));
	return 0;
}
