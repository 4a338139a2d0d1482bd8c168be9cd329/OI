#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
}
int n, T, q;
void init(){
	read(n);
}
int dp[40][40];
void solve(){
	if(n == 0){
		read(q);
		while(q--){
			int x, y;
			read(x), read(y);
			if(x ^ y)puts("Alice");
			else puts("Bob");
		}
	}else {
		For(i, 1, n){
			int x, y;
			read(x), read(y);
			dp[x][y] = -1;
		}
		read(q);
		For(i, 0, 30)
			For(j, 0, 30)
				if((i||j)&&dp[i][j]!=-1){
					dp[i][j] = 0;
					Forr(k, j-1, 0)if(dp[i][k]!=-1){
						if(dp[i][k] == 0)dp[i][j] = 1;
					}else break;
					Forr(k, i-1, 0)if(dp[k][j]!=-1){
						if(dp[k][j] == 0)dp[i][j] = 1;
					}else break;
				}
		while(q--){
			int x, y;
			read(x), read(y);
			if(dp[x][y])puts("Alice");
			else puts("Bob");
		}
	}
}
int main(){
	file();
	read(T);
	while(T--)init(), solve();
	return 0;
}
