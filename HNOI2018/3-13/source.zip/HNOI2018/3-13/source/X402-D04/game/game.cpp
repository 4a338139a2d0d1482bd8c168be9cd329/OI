#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
int n, q;
int ban[maxn][maxn], vis[maxn][maxn];

void read(int& x){
	x=0; char c=getchar(); int f=1;
	while(c<'0' || c>'9'){ if(c=='-') f=-1; c=getchar(); }
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	x*=f;
}

void solve(){
	int x, y;
	read(q);
	while(q--){
		read(x), read(y);
		printf("%s\n", x==y ? "Bob" : "Alice");
	}
}

bool dfs(int x,int y){
	// cerr<<x<<' '<<y<<endl;
	if(~vis[x][y]) return vis[x][y];
	if(!x && !y) return 0;
	for(int i=x-1;i>=1;i--){
		if(ban[i][y]) break;
		if(!dfs(i,y)) return vis[x][y]=1;
	}
	for(int i=y-1;i>=1;i--){
		if(ban[x][i]) break;
		if(!dfs(x,i)) return vis[x][y]=1;
	}
	return vis[x][y]=0;
}

int main(){
	freopen("game.in","r",stdin),freopen("game.out","w",stdout);

	int T;
	read(T);
	while(T--){
		read(n);
		if(!n){ solve(); continue; }
		memset(ban,0,sizeof(ban));
		memset(vis,-1,sizeof(vis));
		int x, y;
		for(int i=1;i<=n;i++){
			read(x), read(y);
			ban[x][y]=1;
		}
		read(q);
		while(q--){
			read(x), read(y);
			printf("%s\n", dfs(x, y) ? "Alice" : "Bob");
		}
	}
	return 0;
}
