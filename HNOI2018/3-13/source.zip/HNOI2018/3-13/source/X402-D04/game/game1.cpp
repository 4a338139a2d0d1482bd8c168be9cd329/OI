#include<bits/stdc++.h>
using namespace std;

const int maxn=40;
int n, q;
int ban[maxn][maxn], vis[maxn][maxn], sg[maxn][maxn];

void read(int& x){
	x=0; char c=getchar(); int f=1;
	while(c<'0' || c>'9'){ if(c=='-') f=-1; c=getchar(); }
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	x*=f;
}

void solve(){
	int x, y;
	read(q);
	while(q--){
		read(x), read(y);
		printf("%s\n", x==y ? "Bob" : "Alice");
	}
}

/*
bool dfs(int x,int y){
	// cerr<<x<<' '<<y<<endl;
	if(~vis[x][y]) return vis[x][y];
	if(!x && !y) return 0;
	for(int i=x-1;i>=0;i--){
		if(ban[i][y]) break;
		if(!dfs(i,y)) return vis[x][y]=1;
	}
	for(int i=y-1;i>=0;i--){
		if(ban[x][i]) break;
		if(!dfs(x,i)) return vis[x][y]=1;
	}
	return vis[x][y]=0;
}
*/

int dfs(int x,int y){
	if(~sg[x][y]) return sg[x][y];
	if(!x && !y) return sg[x][y]=0;
	int can[maxn]={0};
	for(int i=x-1;i>=0;i--){
		if(ban[i][y]) break;
		can[ dfs(i,y) ]=1;
	}
	for(int i=y-1;i>=0;i--){
		if(ban[x][i]) break;
		can[ dfs(x,i) ]=1;
	}
	int now=0;
	while(can[now]) now++;
	return sg[x][y]=now;
}

int main(){
	freopen("game.in","r",stdin),freopen("game.out","w",stdout);

	int T;
	read(T);
	while(T--){
		read(n);
		if(!n){ solve(); continue; }
		memset(ban,0,sizeof(ban));
		memset(vis,-1,sizeof(vis));
		memset(sg,-1,sizeof(sg));
		int x, y;
		for(int i=1;i<=n;i++){
			read(x), read(y);
			//ban[x][y]=1;
		}
		// ban[1][4]=1;
		dfs(30,30);
		for(int i=0;i<=10;i++,puts("")) for(int j=0;j<=10;j++) printf("%d ", sg[i][j]);
		return 0;
		read(q);
		while(q--){
			read(x), read(y);
			printf("%s\n", dfs(x, y) ? "Alice" : "Bob");
		}
	}
	return 0;
}
