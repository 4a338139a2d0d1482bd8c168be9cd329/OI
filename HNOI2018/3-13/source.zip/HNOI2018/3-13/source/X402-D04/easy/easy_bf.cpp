#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=5010;
int n, m;
int a[maxn], b[maxn];
ll dp[maxn][maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(ll& x,ll y){ if(x>y) x=y; }

int main(){
	freopen("easy.in","r",stdin),freopen("easy.ans","w",stdout);

	read(n), read(m);
	for(int i=0;i<=n;i++) read(a[i]);
	for(int i=0;i<=m;i++) read(b[i]);
	memset(dp,0x3f3f3f3f3f,sizeof(dp));
	dp[0][0]=0;
	for(int i=0;i<=n;i++) for(int j=0;j<=m;j++){
		chkmin(dp[i+1][j],dp[i][j]+b[j]);
		chkmin(dp[i][j+1],dp[i][j]+a[i]);
	}
	printf("%lld\n", dp[n][m]);
	return 0;
}
