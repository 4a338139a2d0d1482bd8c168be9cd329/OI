#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=500010;
const ll inf=1e18;
int n, m;
int a[maxn], b[maxn];
ll dp[5010][5010];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(ll& x,ll y){ if(x>y) x=y; }

void solve(){
	ll ans=inf;
	for(int i=0;i<=n;i++){
		chkmin(ans, 1ll*a[i]*m+1ll*(n-i)*m);
	}
	printf("%lld\n", ans);
}

int main(){
	freopen("easy.in","r",stdin),freopen("easy.out","w",stdout);

	read(n), read(m);
	for(int i=0;i<=n;i++) read(a[i]);
	int f=1;
	for(int i=0;i<=m;i++) read(b[i]), f&=b[i]==i;
	if(f){ solve(); return 0; }
	memset(dp,0x3f3f3f3f3f,sizeof(dp));
	dp[0][0]=0;
	for(int i=0;i<=n;i++) for(int j=0;j<=m;j++){
		chkmin(dp[i+1][j],dp[i][j]+b[j]);
		chkmin(dp[i][j+1],dp[i][j]+a[i]);
	}
	printf("%lld\n", dp[n][m]);
	return 0;
}
