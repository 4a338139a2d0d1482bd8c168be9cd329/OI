#include<bits/stdc++.h>
using namespace std;

const int maxn=5010;
const int mod=1e9;
int n, m;

int main(){
	freopen("easy.in","w",stdout);

	srand(time(0));
	printf("%d %d\n", n=5000, m=5000);
	for(int i=0;i<=n;i++) printf("%d ", rand()%mod); puts("");
	for(int i=0;i<=m;i++) printf("%d ", i); puts("");
	return 0;
}
