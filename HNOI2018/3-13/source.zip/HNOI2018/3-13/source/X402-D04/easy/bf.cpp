#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=500010;
const LL inf=0x3f3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("easy.in","r",stdin);
	//freopen("easy.out","w",stdout);
}
int n,m;
LL a[N],b[N],f[2][N];
int main()
{
	file();
	read(n),read(m);
	For(i,0,n)read(a[i]);
	For(i,0,m)read(b[i]);
	mem(f,inf);
	f[0][0]=0;
	For(i,0,n-1)
	{
		int now=i&1,nxt=!(i&1);
		For(j,0,m)
		{
			chkmin(f[nxt][j],f[now][j]+b[j]);
			chkmin(f[now][j+1],f[now][j]+a[i]);
			f[now][j]=inf;
		}
	}
	printf("%lld\n",f[n&1][m]);
	return 0;
}
