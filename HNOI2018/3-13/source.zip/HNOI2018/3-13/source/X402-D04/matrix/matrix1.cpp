#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=310;
int n, m;
char s[maxn];

struct Matrix{
	bool a[maxn][maxn];
	Matrix(int v=0){
		memset(a,0,sizeof(a));
		if(v){
			for(int i=1;i<=n;i++) a[i][i]=1;
		}
	}
	Matrix operator *(const Matrix& A)const{
		Matrix ret;
		bitset<maxn> r[maxn], c[maxn];
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) r[i][j]=a[i][j];
		for(int j=1;j<=n;j++) for(int i=1;i<=n;i++) c[j][i]=A.a[i][j];
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++){
			ret.a[i][j]=(r[i]&c[j]).count()&1;
		}
		// puts("ret");
		// ret.print();
		return ret;
	}
	Matrix operator ^(ll y)const{
		Matrix ret(1), x=*this; 
		while(y){ if(y&1) ret=ret*x; x=x*x; y>>=1; }
		return ret;
	}
	void print(){
		for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=n;j++) printf("%d ", a[i][j]);
	}
}A, b, ans;

int k;

int main(){
	freopen("matrix.in","r",stdin),freopen("matrix.out","w",stdout);

	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		scanf("%s", s+1);
		for(int j=1;j<=n;j++) A.a[i][j]=s[j]-'0';
	}
	scanf("%s", s+1);
	for(int i=1;i<=n;i++) b.a[i][1]=s[i]-'0';
	scanf("%d", &m);
	/*
	 A.print();
	 ans=A^2;
	 ans.print();
	return 0;
	*/
	while(m--){
		scanf("%d", &k);
		ans=(A^k)*b;
		for(int i=1;i<=n;i++) printf("%d", ans.a[i][1]); puts("");
	}
	return 0;
}
