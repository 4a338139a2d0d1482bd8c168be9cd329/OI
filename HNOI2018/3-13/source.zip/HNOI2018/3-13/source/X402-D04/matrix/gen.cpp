#include<bits/stdc++.h>
using namespace std;

const int mod=1e9;
int n, m;

int main(){
	freopen("1.in","w",stdout);

	srand(time(0));
	printf("%d\n", n=1000);
	for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=n;j++) printf("%d", rand()&1);
	for(int i=1;i<=n;i++) printf("%d", rand()&1); puts("");
	printf("%d\n", m=100);
	for(int i=1;i<=m;i++) printf("%d\n", rand()%mod);
	return 0;
}
