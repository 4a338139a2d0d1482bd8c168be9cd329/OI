#include<bits/stdc++.h>
using namespace std; 
typedef long long ll;
const int maxn=1010;
int n, m;
char s[maxn];

struct Matrix{
	bool a[maxn][maxn];
	Matrix(int v=0){
		memset(a,0,sizeof(a));
		if(v){
			for(int i=1;i<=n;i++) a[i][i]=1;
		}
	}
	Matrix operator *(const Matrix& A)const{
		Matrix ret;
		bitset<maxn> r[maxn], c[maxn];
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) r[i][j]=a[i][j];
		for(int j=1;j<=n;j++) for(int i=1;i<=n;i++) c[j][i]=A.a[i][j];
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++){
			ret.a[i][j]=(r[i]&c[j]).count()&1;
		}
		// puts("ret");
		// ret.print();
		return ret;
	}
	Matrix operator ^(ll y)const{
		Matrix ret(1), x=*this; 
		while(y){ if(y&1) ret=ret*x; x=x*x; y>>=1; }
		return ret;
	}
	void print(){
		for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=n;j++) printf("%d ", a[i][j]);
	}
}A[32];

int k, b[maxn], t[maxn];

/*
void mul(int* b,Matrix A){
	int ret[maxn]={0};
	bitset<maxn> r[maxn], c;
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) r[i][j]=A.a[i][j];
	for(int i=1;i<=n;i++) c[i]=b[i];
	for(int i=1;i<=n;i++) ret[i]=(r[i]&c).count()&1;
	for(int i=1;i<=n;i++) b[i]=ret[i];
}
*/
void mul(int* b,Matrix A){
	int ret[maxn]={0};
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) ret[i]^=A.a[i][j]&b[j];
	for(int i=1;i<=n;i++) b[i]=ret[i];
}

int main(){
	freopen("matrix.in","r",stdin),freopen("matrix.out","w",stdout);
	//freopen("1.in","r",stdin),freopen("matrix.out","w",stdout);

	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		scanf("%s", s+1);
		for(int j=1;j<=n;j++) A[0].a[i][j]=s[j]-'0';
	}
	for(int i=1;i<=30;i++) A[i]=A[i-1]*A[i-1];
	scanf("%s", s+1);
	for(int i=1;i<=n;i++) b[i]=s[i]-'0';
	scanf("%d", &m);
	// A[25].print();
	/*
	 A.print();
	 ans=A^2;
	 ans.print();
	return 0;
	*/
	while(m--){
		scanf("%d", &k);
		for(int i=1;i<=n;i++) t[i]=b[i];
		for(int i=0;i<=30;i++) if(k & (1<<i)) mul(t,A[i]);
		for(int i=1;i<=n;i++) printf("%d", t[i]); puts("");
	}
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
