#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}

const int maxn=1e5+10;
int t,n,q;

namespace seg{
	const int size=maxn*300;
	int cnt,sum[size],ls[size],rs[size];
	bool tag[size];

	inline int newnode(int l,int r){
		++cnt;
		sum[cnt]=r-l+1;
		ls[cnt]=rs[cnt]=tag[cnt]=0;
		return cnt;
	}
	inline void build(){
		cnt=0;
		newnode(0,1e9);
	}
	inline void push_up(int rt){
		sum[rt]=sum[ls[rt]]+sum[rs[rt]];
	}
	inline void push_down(int rt){
		if(tag[rt]){
			tag[ls[rt]]=tag[rs[rt]]=true;
			sum[ls[rt]]=sum[rs[rt]]=0;
			tag[rt]=false;
		}
	}
	void build(int rt,int l,int r){
		sum[rt]=r-l+1;tag[rt]=false;
		if(l==r)
			return;
		int mid=l+r>>1;
		build(ls[rt],l,mid);
		build(rs[rt],mid+1,r);
	}
	void modify(int rt,int l,int r,int&k){
		if(!k)
			return;
		if(k>=sum[rt]){
			k-=sum[rt];
			tag[rt]=true;
			sum[rt]=0;
			return;
		}
		int mid=l+r>>1;
		if(!ls[rt])
			ls[rt]=newnode(l,mid);
		if(!rs[rt])
			rs[rt]=newnode(mid+1,r);
		push_down(rt);
		modify(ls[rt],l,mid,k);
		modify(rs[rt],mid+1,r,k);
		push_up(rt);
	}
	int findfirst(int rt,int l,int r,int x,int y){
		if(!sum[rt])
			return -1;
		if(l==r){
			sum[rt]=0;
			return l;
		}
		int mid=l+r>>1,res;
		if(!ls[rt])
			ls[rt]=newnode(l,mid);
		if(!rs[rt])
			rs[rt]=newnode(mid+1,r);
		push_down(rt);
		if(y<=mid)
			res=findfirst(ls[rt],l,mid,x,y);
		else if(x>mid)
			res=findfirst(rs[rt],mid+1,r,x,y);
		else{
			res=findfirst(ls[rt],l,mid,x,y);
			if(res==-1)res=findfirst(rs[rt],mid+1,r,mid+1,y);
		}
		push_up(rt);
		return res;
	}
	void erase(int rt,int l,int r,int pos){
		if(l==r){
			sum[rt]=1;
			return;
		}
		int mid=l+r>>1;
		if(!ls[rt])
			ls[rt]=newnode(l,mid);
		if(!rs[rt])
			rs[rt]=newnode(mid+1,r);
		push_down(rt);
		if(pos<=mid)
			erase(ls[rt],l,mid,pos);
		else
			erase(rs[rt],mid+1,r,pos);
		push_up(rt);
	}
	int query(int rt,int l,int r,int p){
		if(l==r)
			return sum[rt];
		push_down(rt);
		int mid=l+r>>1;
		if(p<=mid)return query(ls[rt],l,mid,p);
		else return query(rs[rt],mid+1,r,p);
	}
}
int ans[maxn];
struct node{
	int id;
	int x,y;
	bool operator< (node o)const{
		return x<o.x||x==o.x&&y<o.y;
	}
	inline void get(int i){
		id=i;
		x=read();y=read();
	}
}a[maxn<<1];

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	t=read();
	while(t--){
		n=read();
		for(int i=1;i<=n;++i)
			a[i].get(0);
		q=read();
		for(int i=1;i<=q;++i)
			a[i+n].get(i);
		sort(a+1,a+n+q+1);
		seg::build();
		for(int i=1,j,last=-1;i<=q+n;){
			j=i;
			while(j<q+n&&a[j+1].x==a[j].x)++j;
			if(last+1<a[i].x){
				int cnt=a[i].x-last-1;
				seg::modify(1,0,1e9,cnt);
			}
			vector<int> vec,fail;
			vec.push_back(-1);
			for(int k=i;k<=j;++k)
				if(!a[k].id)
					vec.push_back(a[k].y);
			vec.push_back(1e9+1);
			for(int k=1;k<vec.size();++k){
				int l=vec[k-1]+1,r=vec[k]-1;
				if(l>r)continue;
				int tmp=seg::findfirst(1,0,1e9,l,r);
				if(~tmp)fail.push_back(tmp);
			}
			for(int k=i,p=0;k<=j;++k){
				if(a[k].id==0){
					seg::erase(1,0,1e9,a[k].y);
					continue;
				}
				while(p<fail.size()&&fail[p]<a[k].y)++p;
				if(p<fail.size()&&fail[p]==a[k].y)
					ans[a[k].id]=false;
				else
					ans[a[k].id]=true;
			}
			last=a[i].x;
			i=j+1;
		}
		for(int i=1;i<=q;++i)
			puts(ans[i]?"Alice":"Bob");
	}
	return 0;
}
