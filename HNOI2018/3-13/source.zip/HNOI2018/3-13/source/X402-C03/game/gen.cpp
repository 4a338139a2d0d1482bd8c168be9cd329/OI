#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("game.in","w",stdout);
	int t=5;
	int nn=40,qq=40,w=70;
	nn=qq=1e4;w=3e2;
	printf("%d\n",t);
	while(t--){
		set<pair<int,int> > st;
		int n=f(0,nn),q=f(1,qq);
		if(rand()%3==0)
			n=f(0,sqrt(nn)),q=f(1,sqrt(qq));
	//	n=q=1e5;w=1e4;
		printf("%d\n",n);
		for(int i=1;i<=n;++i){
			int x=f(0,w),y=f(0,w);
			if(st.count(make_pair(x,y))){--i;continue;}
			printf("%d %d\n",x,y);
			st.insert(make_pair(x,y));
		}
		printf("%d\n",q);
		for(int i=1;i<=q;++i){
			int x=f(0,w),y=f(0,w);
			if(st.count(make_pair(x,y))){--i;continue;}
			printf("%d %d\n",x,y);
			st.insert(make_pair(x,y));
		}
	}
	return 0;
}
