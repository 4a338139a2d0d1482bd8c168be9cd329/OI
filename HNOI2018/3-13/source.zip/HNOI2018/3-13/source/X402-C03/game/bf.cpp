#include<bits/stdc++.h>
using namespace std;

const int maxx=3e2+10;
int t,n,q,sg[maxx][maxx];
bool mex[maxx<<1];

int main(){
	freopen("game.in","r",stdin);
	freopen("game.txt","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		memset(sg,0,sizeof(sg));
		for(int i=1,x,y;i<=n;++i){
			scanf("%d%d",&x,&y);
			sg[x][y]=-1;
		}
		for(int i=0;i<maxx;++i)
			for(int j=0;j<maxx;++j){
				if(sg[i][j]==-1)
					continue;
				for(int k=i-1;~k&&~sg[k][j];--k)
					mex[sg[k][j]]=true;
				for(int k=j-1;~k&&~sg[i][k];--k)
					mex[sg[i][k]]=true;
				for(int k=0;;++k)
					if(!mex[k]){
						sg[i][j]=k;
						break;
					}
				for(int k=i-1;~k&&~sg[k][j];--k)
					mex[sg[k][j]]=false;
				for(int k=j-1;~k&&~sg[i][k];--k)
					mex[sg[i][k]]=false;
			}
		scanf("%d",&q);
		while(q--){
			int x,y;
			scanf("%d%d",&x,&y);
			puts(sg[x][y]?"Alice":"Bob");
		}
	}
	return 0;
}
