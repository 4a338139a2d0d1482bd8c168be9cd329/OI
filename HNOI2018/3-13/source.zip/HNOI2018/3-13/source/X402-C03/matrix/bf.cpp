#include<bits/stdc++.h>
using namespace std;

const int maxn=100;
int n,m,k;

struct matrix{
	int x,y;
	int a[maxn][maxn];
	inline matrix(int xx,int yy):x(xx),y(yy){
		memset(a,0,sizeof(a));
	}
	inline matrix operator* (matrix o){
		matrix res(x,o.y);
		for(int i=0;i<x;++i)
			for(int j=0;j<o.y;++j)
				for(int k=0;k<y;++k)
					res.a[i][j]^=a[i][k]&o.a[k][j];
		return res;
	}
};
inline matrix fpow(matrix a,int n){
	matrix res(a.x,a.y);
	for(int i=0;i<res.x;++i)
		res.a[i][i]=1;
	for(;n;n>>=1,a=a*a)
		if(n&1)
			res=res*a;
	return res;
}

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.txt","w",stdout);
	scanf("%d",&n);
	matrix base1(n,n);
	for(int i=0;i<n;++i){
		static char s[maxn];
		scanf("%s",s);
		for(int j=0;j<n;++j)
			base1.a[i][j]=s[j]-'0';
	}
	matrix base2(n,1);
	{
		static char s[maxn];
		scanf("%s",s);
		for(int i=0;i<n;++i)
			base2.a[i][0]=s[i]-'0';
	}
	scanf("%d",&m);
	while(m--){
		scanf("%d",&k);
		matrix ans=fpow(base1,k)*base2;
		for(int i=0;i<n;++i)
			putchar(ans.a[i][0]+'0');
		putchar('\n');
	}
	return 0;
}
