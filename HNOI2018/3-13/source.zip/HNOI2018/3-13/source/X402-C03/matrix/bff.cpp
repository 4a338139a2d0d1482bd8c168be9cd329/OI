#include<bits/stdc++.h>
using namespace std;

const int maxn=1e3+10,maxlog=31;
int n,m,k;
char s[maxn];

struct matrix{
	int x,y;
	bitset<maxn> a[maxn],b[maxn];
	inline matrix(){}
	inline matrix(int xx,int yy):x(xx),y(yy){}
	inline void mark(int xx,int yy){
		a[xx][yy]=1;b[yy][xx]=1;
	}
	inline matrix operator* (matrix o){
		matrix res(x,o.y);
		for(int i=0;i<x;++i)
			for(int j=0;j<o.y;++j)
				res.a[i][j]=res.b[j][i]=(a[i]&o.b[j]).count()&1;
		return res;
	}
}prepow[maxlog];

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.txt","w",stdout);
	scanf("%d",&n);
	matrix base1(n,n),base2(n,1);
	for(int i=0;i<n;++i){
		scanf("%s",s);
		for(int j=0;j<n;++j)
			if(s[j]=='1')
				base1.mark(i,j);
	}
	scanf("%s",s);
	for(int i=0;i<n;++i)
		if(s[i]=='1')
			base2.mark(i,0);
	prepow[0]=base1;
	for(int i=1;i<maxlog;++i)
		prepow[i]=prepow[i-1]*prepow[i-1];
	scanf("%d",&m);
	while(m--){
		scanf("%d",&k);
		matrix ans=base2;
		for(int i=0;i<maxlog;++i)
			if(k>>i&1)
				ans=prepow[i]*ans;
		for(int i=0;i<n;++i)
			putchar(ans.a[i][0]+'0');
		putchar('\n');
	}
	return 0;
}
