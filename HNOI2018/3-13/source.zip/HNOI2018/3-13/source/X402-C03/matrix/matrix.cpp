#include<bits/stdc++.h>
using namespace std;

const int maxn=1e3+10,/*maxlen=maxn/64+1,*/maxlog=31;
//const long long one=1;
int n,m,k;
char s[maxn];

/*
struct bit_set{
	long long x[maxlen];
	inline bit_set(){
		memset(x,0,sizeof(x));
	}
	inline int andcount(const bit_set&a)const{
		int res=0;
		for(int i=0;i<maxlen;++i)
			res+=__builtin_popcount(x[i]&a.x[i]);
		return res;
	}
};
*/
struct matrix{
	int x,y;
//	bit_set aa[maxn],bb[maxn];
	bitset<maxn> a[maxn],b[maxn];
	inline matrix(){}
	inline matrix(int xx,int yy):x(xx),y(yy){}
	inline void mark(int xx,int yy){
		a[xx][yy]=b[yy][xx]=1;
	//	aa[xx].x[yy>>6]|=one<<(yy&63);
	//	bb[yy].x[xx>>6]|=one<<(xx&63);
	}
}prepow[maxlog];
inline void mul(matrix&res,const matrix&a){
	res.x=a.x;res.y=a.y;
	for(int i=0;i<a.x;++i)
		for(int j=0;j<a.y;++j){
		//	if(a.aa[i].andcount(a.bb[j]))
		//		res.mark(i,j);
			if((a.a[i]&a.b[j]).count()&1)
				res.mark(i,j);
		}
}
inline matrix operator* (const matrix&a,const matrix&b){
	matrix res(a.x,b.y);
	for(int i=0;i<a.x;++i)
		for(int j=0;j<b.y;++j){
		//	if(a.aa[i].andcount(b.bb[j]))
		//		res.mark(i,j);
			if((a.a[i]&b.b[j]).count()&1)
				res.mark(i,j);
		}
	return res;
}

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	matrix base1(n,n),base2(1,n);
	for(int i=0;i<n;++i){
		scanf("%s",s);
		for(int j=0;j<n;++j)
			if(s[j]=='1')
				base1.mark(j,i);
	}
	scanf("%s",s);
	for(int i=0;i<n;++i)
		if(s[i]=='1')
			base2.mark(0,i);
	prepow[0]=base1;
	for(int i=1;i<=26;++i)
		mul(prepow[i],prepow[i-1]);
	scanf("%d",&m);
	while(m--){
		scanf("%d",&k);
		matrix ans=base2;
		while(k>>26){
			ans=ans*prepow[26];
			k-=1<<26;
		}
		for(int i=0;i<26;++i)
			if(k>>i&1)
				ans=ans*prepow[i];
		for(int i=0;i<n;++i)
		//	putchar((ans.aa[0].x[i>>6]>>(i&63)&1)+'0');
			putchar(ans.a[0][i]+'0');
		putchar('\n');
	}
	return 0;
}
