#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("matrix.in","w",stdout);
	int n=f(1,300),m=100,k=1e9;
//	n=1e3;
	printf("%d\n",n);
	for(int i=0;i<=n;++i,puts(""))
		for(int j=1;j<=n;++j)
			putchar(f('0','1'));
	printf("%d\n",m);
	for(int i=1;i<=m;++i)
		printf("%d\n",rand()&31?f(0,k):f(0,pow(k,0.2)));
	return 0;
}
