#include<bits/stdc++.h>
using namespace std;

template<typename t>inline t min_(t a,t b){return a<=b?a:b;}

typedef long long ll;
const int maxn=5e5+10;
int n,m,a[maxn],b[maxn];
ll dp[2][maxn];

int main(){
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=0;i<=m;++i)
		scanf("%d",&b[i]);
	for(int i=1;i<=m;++i)
		dp[0][i]=dp[0][i-1]+a[0];
	for(int i=1;i<=n;++i){
		dp[i&1][0]=dp[i&1^1][0]+b[0];
		for(int j=1;j<=m;++j)
			dp[i&1][j]=min_(dp[i&1^1][j]+b[j],dp[i&1][j-1]+a[i]);
	}
	printf("%lld\n",dp[n&1][m]);
	return 0;
}
