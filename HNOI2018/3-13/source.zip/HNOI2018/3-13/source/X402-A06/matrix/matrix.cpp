#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m;

char ss[maxn];

struct matrix{ 
	int a[302][302];
	void init() {
		For(i, 0, n-1) {
			For(j, 0, n-1){
				a[i][j] = 0;
			}
		}
	}
}st, en;

void Get() {
	n = read();
	st.init();
	For(i, 0, n-1) {
		scanf("%s", ss);
		For(j, 0, n-1) {
			st.a[i][j] = ss[j]-'0';
		}
	}

	scanf("%s", ss);
	en.init();
	For(i, 0, n-1) {
		en.a[i][0] = ss[i]-'0';
	}
	m = read();
}

matrix res; 

bitset<302> A[302], B[302];

matrix operator * (matrix c, matrix d) {
	For(i, 0, n-1) For(j, 0, n-1) A[i][j] = c.a[i][j], B[i][j] = d.a[j][i];
	For(i, 0, n-1) {
		For(j, 0, n-1) {
			res.a[i][j] = ( (A[i] & B[j]).count() & 1);
		}
	}
	return res;
}

void solve(int k) {
	matrix s;
	bool flag = 0;
	s.init();
	matrix x = st;

	if(k == 0) {
		printf("%s\n", ss);
		return;
	}

	while(k) {
		if(k&1) {
			if(!flag) s = x, flag = 1;
			else s = s * x;
		}
		x = x * x;
		k >>= 1;
	}

	s = s * en;
	For(i, 0, n-1) printf("%d", s.a[i][0]); puts("");
}

int main() {

	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);

	Get();
	while(m --){
		int k = read();
		solve(k);
	}

	return 0;
}
