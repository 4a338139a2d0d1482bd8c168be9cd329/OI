#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(ll i = (a);i <= (b); ++i)
#define rep(i, a, b) for(ll i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

ll read() {
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const ll maxn = 100010;

ll n, m, A[maxn], B[maxn];

void Get() {
	n = read(), m = read();
	For(i, 0, n) A[i] = read();
	For(i, 0, m) B[i] = read();
}

ll dp[5010][5010];

void solve_bf() {
	For(i, 0, n) For(j, 0, m) dp[i][j] = inf;
	dp[0][0] = 0;

	For(i, 0, n) {
		For(j, 0, m) {
			if(dp[i][j] == inf) continue;
			dp[i+1][j] = min(dp[i+1][j], dp[i][j] + B[j]);
			dp[i][j+1] = min(dp[i][j+1], dp[i][j] + A[i]);
		}
	}

	printf("%lld\n", dp[n][m]);
}

int main() {

	freopen("easy.in", "r", stdin);
	freopen("easy.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
