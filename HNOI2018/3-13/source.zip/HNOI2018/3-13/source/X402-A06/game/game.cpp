#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

bool vis[100][100];

int n, q, X[maxn], Y[maxn], stx, sty, Max;

void Get() {
	n = read();
	Max = 0;
	For(i, 1, n) {
		X[i] = read(), Y[i] = read();
		if(X[i] < 100 && Y[i] < 100) vis[X[i]][Y[i]] = 1;
		Max = max(Max, X[i]);
		Max = max(Max, Y[i]);
	}

	q = read();
}

int dp[100][100];

int dfs(int x,int y,int tp) {
	if(dp[x][y] != -1) {
		if(dp[x][y] == 0) return (tp^1);
		else return tp;
	}

	rep(i, x-1, 0){
		if(vis[i][y]) break;
		if(dfs(i, y, tp^1) == tp) {
			dp[x][y] = 1;
			return tp;
		}
	}

	rep(i, y-1, 0){
		if(vis[x][i]) break;
		if(dfs(x, i, tp^1) == tp){
			dp[x][y] = 1;
			return tp;
		}
	}

	dp[x][y] = 0;
	return (tp^1);
}

int main() {

	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);

	int _ = read();
	while(_ --) {
		Get();
		For(i, 0, 30) For(j, 0, 30) dp[i][j] = -1;
		For(i, 1, q) {
			stx = read(), sty = read();
			if(Max > 30 || stx > 30 || sty > 30) {
				if(n == 0){
					if(stx == sty) printf("Bob\n");
					else printf("Alice\n");
					continue;
				}
			}
			int tmp = dfs(stx, sty, 1);

			if(tmp == 1) printf("Alice\n");
			else printf("Bob\n");
		}
		For(i, 1, n) vis[X[i]][Y[i]] = 0;
	}

	return 0;
}
