#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=5050;
const ll infl=1e18;
int A[N],B[N],n,m;
ll dis[N][N];
bool vis[N][N];
pii pre[N][N];

void wj()
{
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=0;i<=n;++i) A[i]=read();
	for(int j=0;j<=m;++j) B[j]=read();
	for(int i=0;i<=n;++i) for(int j=0;j<=m;++j) dis[i][j]=infl;
	dis[0][0]=0;
	for(int i=0;i<=n;++i) for(int j=0;j<=m;++j)
	{
		//dis[i+1][j]=min(dis[i+1][j],dis[i][j]+B[j]);
		//dis[i][j+1]=min(dis[i][j+1],dis[i][j]+A[i]);
		if(dis[i][j]+B[j]<dis[i+1][j]) 
			dis[i+1][j]=dis[i][j]+B[j],pre[i+1][j]=pii(i,j);
		if(dis[i][j]+A[i]<dis[i][j+1])
			dis[i][j+1]=dis[i][j]+A[i],pre[i][j+1]=pii(i,j);
	}
	int x=n,y=m;
	while(x!=0||y!=0)
	{
		//printf("%d %d\n",x,y);
		vis[x][y]=1;
		pii o=pre[x][y];
		x=o.fi; y=o.se;
	}
	vis[0][0]=1;
	for(int i=0;i<=n;++i) printf("%d ",A[i]); ln;
	for(int j=m;j>=0;--j) 
	{
		for(int i=0;i<=n;++i) 
			printf("%c ",vis[i][j]==1?'Y':' ');
		printf("%d\n",B[j]);
	}
	printf("%lld\n",dis[n][m]);
	return 0;
}
