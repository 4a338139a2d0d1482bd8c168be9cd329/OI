#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=5050;
const ll infl=1e18;
int A[500050],B[500050],n,m;
ll dis[N][N];

void wj()
{
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=0;i<=n;++i) A[i]=read();
	for(int j=0;j<=m;++j) B[j]=read();
	if(n>5005||m>5005)
	{
		ll ans=infl;
		for(int i=0;i<=n;++i) 
			ans=min(ans,1ll*i*B[0]+1ll*m*A[i]+1ll*(n-i)*B[m]);
		for(int i=0;i<=m;++i)
			ans=min(ans,1ll*i*A[0]+1ll*n*B[i]+1ll*(m-i)*A[n]);
		printf("%lld\n",ans);
		return 0;
	}
	for(int i=0;i<=n;++i) for(int j=0;j<=m;++j) dis[i][j]=infl;
	dis[0][0]=0;
	for(int i=0;i<=n;++i) for(int j=0;j<=m;++j)
	{
		dis[i+1][j]=min(dis[i+1][j],dis[i][j]+B[j]);
		dis[i][j+1]=min(dis[i][j+1],dis[i][j]+A[i]);
	}
	printf("%lld\n",dis[n][m]);
	return 0;
}
