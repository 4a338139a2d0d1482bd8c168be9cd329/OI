#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<bitset>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1011;

bitset<N>bb[N];
int n,ls[N][N];
void mul(bitset<N> *a,const bitset<N> *b)
{
	//for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) bb[i][j]=b[j][i];
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) bb[j][i]=b[i][j];
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j)
		ls[i][j]=(a[i]&bb[j]).count() &1;
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) a[i][j]=ls[i][j];
}
bitset<N> A[N],pw[33][N];
bitset<N>X,now,we;

char in[N];
void wj()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	n=read();
	for(int i=1;i<=n;++i)
	{
		scanf("%s",in+1);
		for(int j=1;j<=n;++j) A[i][j]=in[j]-48;
	}
	for(int i=1;i<=n;++i) pw[0][i]=A[i];
	for(int i=1;i<=29;++i)
	{
		for(int j=1;j<=n;++j) pw[i][j]=pw[i-1][j];
		mul(pw[i],pw[i-1]);
	}

	scanf("%s",in+1);
	for(int i=1;i<=n;++i) X[i]=in[i]-48;
	int m=read();
	for(int cas=1;cas<=m;++cas)
	{
		int k=read();
		for(int i=1;i<=n;++i) now[i]=X[i];
		for(int o=0;o<=29;++o) if(k&1<<o)
		{
			for(int i=1;i<=n;++i)
			{
				int ans=0;
				we[i]=(pw[o][i]&now).count() &1;
			}
			for(int i=1;i<=n;++i) now[i]=we[i];
		}
		for(int i=1;i<=n;++i) putchar(now[i]+48);
		ln;
	}
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
