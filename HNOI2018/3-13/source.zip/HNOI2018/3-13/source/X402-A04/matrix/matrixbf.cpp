#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=105;
struct matrix
{
	int s[N][N];
	matrix() {clean();}
	void clean() { memset(s,0,sizeof(s)); }
};
int ls[N][N],n;
void mul(matrix &a,const matrix &b)
{
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) ls[i][j]=0;
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) for(int k=1;k<=n;++k)
		ls[i][j]^=a.s[i][k]&b.s[k][j];
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) a.s[i][j]=ls[i][j];
}
matrix A,B,C;
int X[N];

char in[N];
void wj()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i)
	{
		scanf("%s",in+1);
		for(int j=1;j<=n;++j) A.s[i][j]=in[j]-48;
	}
	scanf("%s",in+1);
	for(int i=1;i<=n;++i) X[i]=in[i]-48;
	int m=read();
	for(int cas=1;cas<=m;++cas)
	{
		int k=read();
		B=A;
		C.clean();
		for(int i=1;i<=n;++i) C.s[i][i]=1;
		for(;k;k>>=1,mul(B,B)) if(k&1) mul(C,B);
		for(int i=1;i<=n;++i) 
		{
			int ans=0;
			for(int j=1;j<=n;++j) ans^=C.s[i][j]&X[j];
			putchar(ans+48);
		}
		ln;
	}
	return 0;
}
