#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=105;
struct matrix
{
	int s[N][N];
	matrix() {clean();}
	void clean() { memset(s,0,sizeof(s)); }
};
int ls[N][N],n;
void mul(matrix &a,const matrix &b)
{
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) ls[i][j]=0;
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) for(int k=1;k<=n;++k)
		ls[i][j]^=a.s[i][k]&b.s[k][j];
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j) a.s[i][j]=ls[i][j];
}
matrix A,B,C,pw[37];
int X[N],now[N],we[N];

char in[N];
void wj()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i)
	{
		scanf("%s",in+1);
		for(int j=1;j<=n;++j) A.s[i][j]=in[j]-48;
	}
	pw[0]=A;
	for(int i=1;i<=30;++i) pw[i]=pw[i-1],mul(pw[i],pw[i-1]);

	scanf("%s",in+1);
	for(int i=1;i<=n;++i) X[i]=in[i]-48;
	int m=read();
	for(int cas=1;cas<=m;++cas)
	{
		int k=read();
		for(int i=1;i<=n;++i) now[i]=X[i];
		for(int o=0;o<=30;++o) if(k&1<<o)
		{
			for(int i=1;i<=n;++i)
			{
				int ans=0;
				for(int j=1;j<=n;++j) ans^=pw[o].s[i][j]&now[j];
				we[i]=ans;
			}
			for(int i=1;i<=n;++i) now[i]=we[i];
		}
		for(int i=1;i<=n;++i) putchar(now[i]+48);
		ln;
	}
	return 0;
}
