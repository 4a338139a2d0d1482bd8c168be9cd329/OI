#include<bits/stdc++.h>
using namespace std;
int n,m;

struct matrix{
	int a[1010][1010];
	matrix(int v=0){
		for(int i=0;i<n;++i)
			for(int j=0;j<n;++j){
				if(i!=j)a[i][j]=0;
				else a[i][j]=v;
			}
	}	
}A,B,X;
matrix operator * (matrix aa,matrix bb){
	matrix ret;
	for(int i=0;i<n;++i)
		for(int j=0;j<n;++j)
			for(int k=0;k<n;++k)
				(ret.a[i][j]+=(aa.a[i][k]*bb.a[k][j])%2)%=2;
	return ret;
}
void output(matrix A){
	for(int i=0;i<n;++i)
		printf("%d",A.a[i][0]);
	puts("");
}
void de(matrix A){
	for(int i=0;i<n;++i,puts(""))
		for(int j=0;j<n;++j)
			printf("%d",A.a[i][j]);
	puts("");
}
matrix fpm(matrix a,int b){
	matrix ret(1);
	for(;b;b>>=1,a=a*a)
		if(b&1)ret=ret*a;
	return ret;
}

char s[1010];
void solve(){
	scanf("%d",&n);
	for(int i=0;i<n;++i){
		scanf("%s",s);
		for(int j=0;j<n;++j)
			A.a[i][j]=s[j]-'0';
	}
	scanf("%s",s);
	for(int i=0;i<n;++i)X.a[i][0]=s[i]-'0';
	scanf("%d",&m);
	for(int k;m--;){
		scanf("%d",&k);
		B=fpm(A,k);B=B*X;
		output(B);
	}
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	solve();
	return 0;
}
