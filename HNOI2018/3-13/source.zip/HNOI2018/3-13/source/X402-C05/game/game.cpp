#include<bits/stdc++.h>
using namespace std;
template<typename T>T read(){
	T x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
	return x*f;
}
int n,q;
void work1(){
	q=read<int>()+1;
	for(int x,y;--q;){
		x=read<int>(),y=read<int>();
		if(x!=y)puts("Alice");
		else puts("Bob");
	}
}
struct data{
	int x,y;
}b[50],c[50];
int a[50][50],pre[50];
void work2(){
	memset(a,0,sizeof a);
	for(int i=1;i<=n;++i)a[b[i].x][b[i].y]=2;
	memset(pre,0,sizeof pre);
	for(int i=0;i<=30;++i)
		for(int j=0,x=0;j<=30;++j){
			if(a[i][j]==2){pre[j]=0,x=0;continue;}
			else{a[i][j]=!(pre[j]|x);}
			pre[j]|=a[i][j];
			x|=a[i][j];
		}
	for(int i=1;i<=q;++i){
		if(a[c[i].x][c[i].y]==1)puts("Bob");
		else puts("Alice");
	}
}
void solve(){
	for(int T=read<int>()+1,flag;--T;){
		n=read<int>();
		if(!n){work1();continue;}
		flag=0;
		for(int i=1;i<=n;++i){
			b[i].x=read<int>();
			b[i].y=read<int>();
			if(b[i].x>30||b[i].y>30)flag=1;
		}
		q=read<int>();
		for(int i=1;i<=q;++i){
			c[i].x=read<int>();
			c[i].y=read<int>();
			if(c[i].x>30||c[i].y>30)flag=1;
		}
		if(!flag){work2();continue;}
	}
	
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	solve();
	
	return 0;
}
