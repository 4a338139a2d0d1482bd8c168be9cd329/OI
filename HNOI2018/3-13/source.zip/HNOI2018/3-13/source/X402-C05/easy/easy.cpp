#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=5010;
ll f[maxn][maxn];
int n,m,a[maxn],b[maxn];
void solve(){
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;++i)scanf("%d",a+i);
	for(int i=0;i<=m;++i)scanf("%d",b+i);
	for(int i=0;i<=n;++i)
		for(int j=0;j<=m;++j)
			f[i][j]=1e18;
	f[0][0]=0;
	for(int i=0;i<=n;++i)
		for(int j=0;j<=m;++j){
			f[i][j+1]=min(f[i][j+1],f[i][j]+a[i]);
			f[i+1][j]=min(f[i+1][j],f[i][j]+b[j]);
		}
	printf("%lld\n",f[n][m]);
}
int main(){
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
	solve();
	
	return 0;
}
