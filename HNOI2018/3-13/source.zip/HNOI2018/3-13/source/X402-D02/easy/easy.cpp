#include<iostream>
#include<cstdio>
#include<cstring>

template<typename T>inline void check_min(T a,T &b){if(a<b)b=a;}

typedef long long ll;
const int N=5010;
const ll INF=9223372036854775807ll;

int A[N],B[N];
int n,m;

ll f[N][N];

int main()
{
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;i++)
		scanf("%d",A+i);
	for(int i=0;i<=m;i++)
		scanf("%d",B+i);
	for(int i=0;i<=n;i++)
		for(int j=0;j<=m;j++)
			f[i][j]=INF;
	f[0][0]=0;
	for(int i=0;i<=n;i++)
		for(int j=0;j<=m;j++)
		{
			check_min(f[i][j]+A[i],f[i][j+1]);
			check_min(f[i][j]+B[j],f[i+1][j]);
		}
	printf("%lld\n",f[n][m]);
	return 0;
}
