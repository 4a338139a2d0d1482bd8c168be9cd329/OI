#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<set>

FILE* seed,in;

const int N=510;

bool G[N][N];

void work()
{
	int n=2333,m=2333,lim=500;
	printf("%d\n",n);
	while(n--)
	{
		int x=rand()%lim,y=rand()%lim;
		while(G[x][y])x=rand()%lim,y=rand()%lim;
		printf("%d %d\n",x,y);
		G[x][y]=1;
	}
	printf("%d\n",m);
	while(m--)
	{
		int x=rand()%lim,y=rand()%lim;
		while(G[x][y])x=rand()%lim,y=rand()%lim;
		printf("%d %d\n",x,y);
	}
}


int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("game.in","w",stdout);//look at here

	int T=1;
	printf("%d\n",T);
	while(T--)work();

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
