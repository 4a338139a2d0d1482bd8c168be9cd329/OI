#include<iostream>
#include<cstdio>
#include<cstring>

const int N=550;

bool f[N][N];
bool G[N][N];
int n,m;

void initialize()
{
	memset(f,0,sizeof(f));
	memset(G,0,sizeof(G));
	scanf("%d",&n);
	for(int i=1,x,y;i<=n;i++)
		scanf("%d%d",&x,&y),G[x+1][y+1]=1;

	for(int i=1;i<N;i++)
		for(int j=1;j<N;j++)
		{
			if(G[i][j]){f[i][j]=0;continue;}

			for(int k=i-1;k && !f[i][j] && !G[k][j];k--)
				if(!f[k][j])f[i][j]=1;
			for(int k=j-1;k && !f[i][j] && !G[i][k];k--)
				if(!f[i][k])f[i][j]=1;
		}

}
void solve()
{
	initialize();
	scanf("%d",&m);
	int x,y;
	while(m--)
	{
		scanf("%d%d",&x,&y);
		if(f[x+1][y+1])printf("Alice\n");
		else printf("Bob\n");
	}
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.ans","w",stdout);
	int T;
	for(scanf("%d",&T);T--;solve());
	return 0;
}
