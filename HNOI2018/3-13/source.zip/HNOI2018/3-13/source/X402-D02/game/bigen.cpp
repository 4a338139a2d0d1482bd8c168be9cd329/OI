#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<set>

FILE* seed,in;

typedef std::pair<int,int> pii;

std::set<pii> S;

void work()
{
	S.clear();
	int n=100000,m=100000,lim=1000000000;
	printf("%d\n",n);
	while(n--)
	{
		int x=rand()%lim,y=rand()%lim;
		while(S.count(pii(x,y)))x=rand()%lim,y=rand()%lim;
		printf("%d %d\n",x,y);
		S.insert(pii(x,y));
	}
	printf("%d\n",m);
	while(m--)
	{
		int x=rand()%lim,y=rand()%lim;
		while(S.count(pii(x,y)))x=rand()%lim,y=rand()%lim;
		printf("%d %d\n",x,y);
	}
}


int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("game.in","w",stdout);//look at here

	int T=1;
	printf("%d\n",T);
	while(T--)work();

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
