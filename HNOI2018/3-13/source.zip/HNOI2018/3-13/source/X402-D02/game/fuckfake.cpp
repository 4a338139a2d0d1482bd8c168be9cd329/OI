#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<set>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace fatesky
{
	typedef std::set<int>::iterator sit;

	const int N=501000,M=10000000,INF=1000000007;

	struct fuckment_tree
	{
#define lt(p) (st[p][0])
#define rt(p) (st[p][1])
#define mid ((L+R)>>1)

		int st[M][2],w[M];

		int e;
		inline int newnode(){e++;lt(e)=rt(e)=0,w[e]=0;return e;}
		inline int check(int &p){return p?p:p=newnode();}

		void reset(){e=0,newnode();}

		void modify(int x,int y,int p=1,int L=1,int R=INF)
		{
			w[p]+=y;
			if(L==R)return;
			if(x<=mid)modify(x,y,check(lt(p)),L,mid);
			else modify(x,y,check(rt(p)),mid+1,R);
		}
		int count(int x,int p=1,int L=1,int R=INF)
		{
			if(!p)return 0;
			if(L==R)return w[p];

			if(x<=mid)return count(x,lt(p),L,mid);
			else return count(x,rt(p),mid+1,R);
		}

		void find(int &x,int p=1,int L=1,int R=INF)
		{
			if(!p)return;
			if(L==x)
			{
				if(w[p]==R-L+1)
				{
					x=R+1;
					return;
				}
				if(L==R)return;
				find(x,lt(p),L,mid);

				if(x>mid)find(x,rt(p),mid+1,R);

				return;
			}

			if(x<=mid)find(x,lt(p),L,mid);
			if(x>mid)find(x,rt(p),mid+1,R);
		}
		void dnif(int &x,int p=1,int L=1,int R=INF)
		{
			if(x==370)
			{
				fprintf(stderr,"%d _ %d -- %d : %d\n",p,L,R,w[p]);
			}
			if(x==478)
			{
				fprintf(stderr,"%d -- %d : %d\n",L,R,w[p]);
			}
			if(!p || w[p]==0)
			{
				x=R+1;
				return;
			}
			if(L==x)
			{
				if(w[p]==0)
				{
					x=R+1;
					return;
				}

				if(L==R)return;
				dnif(x,lt(p),L,mid);

				if(x>mid)dnif(x,rt(p),mid+1,R);

				return;
			}

			if(x<=mid)dnif(x,lt(p),L,mid);
			if(x>mid)dnif(x,rt(p),mid+1,R);
		}

		inline bool empty(){return w[1]==0;}
		inline int size(){return w[1];}
		int min(int p=1,int L=1,int R=INF)
		{
			if(L==R)return L;
			if(w[lt(p)])return min(lt(p),L,mid);
			else return min(rt(p),mid+1,R);
		}

#undef lt
#undef rt
#undef mid
	}S,T;

	struct node
	{
		int ty,x,y,id;
		node(int ty0=0,int x0=0,int y0=0,int id0=0):ty(ty0),x(x0),y(y0),id(id0){}
		bool operator < (const node &A)const {return y==A.y?ty==A.ty?x<A.x:ty<A.ty:y<A.y;}
	};

	node s[N];

	int n,m,tot,mid;

	void initialize()
	{
		S.reset(),T.reset();
		read(n);
		for(int i=1;i<=n;i++)
		{
			read(s[i].x),read(s[i].y);
			s[i].x++,s[i].y++;

			s[i].ty=0;
		}
		read(m),tot=n+m;
		for(int i=1;i<=m;i++)
		{
			read(s[n+i].x),read(s[n+i].y);
			s[n+i].x++,s[n+i].y++;

			s[n+i].ty=1,s[n+i].id=i;
		}
		std::sort(s+1,s+tot+1);
	}
	bool ans[N];
	int pos;

	void set0(int x)
	{
		if(x<=mid)
		{
			if(S.count(x))S.modify(x,-1);
		}
		else
		{
			if(!T.count(x))T.modify(x,1);
		}
	}

	std::set<int> Q;

	void jump(int k)
	{
		Q.clear();
		int lst=-1;

		pos+=k;

		int step=std::min(k,S.size());
		k-=step;
		while(step--)
		{
			lst=S.min();
			S.modify(lst,-1);
		}

		while(k>0)
		{
			lst=mid+k;

			mid+=k,k=0;

			int it;
			while(!T.empty() && (it=T.min())<=mid)
				T.modify(it,-1),k++;
		}

		if(lst!=-1)Q.insert(lst);
	}

	int td[N],cnt;
	bool ned[N];

	void upd()
	{
		Q.clear();
		for(int i=1;i<=cnt;i++)ned[i]=0,Q.insert(td[i]);

		for(int i=1;i<=cnt;i++)
		{
			int x=td[i],y=x+1;

			if(y<=mid)
			{
				int it=y,tmp=y;

				S.dnif(tmp);

				while(!S.count(it) && it<=mid)it++;
				if(tmp!=it)fprintf(stderr,"%d , %d , %d , %d\n",y,tmp,mid,it);

				if(it<=mid)y=it;
				else y=mid+1;
			}
			if(y>mid)T.find(y);

			if(i==cnt || y<td[i+1])set0(y),Q.insert(y);
		}

		for(int i=1;i<=cnt;i++)
		{
			int x=td[i];
			
			if(x<=mid)
			{
				if(!S.count(x))S.modify(x,1);
			}
			else
			{
				if(T.count(x))T.modify(x,-1);
			}
		}

		if(!S.empty())
		{
			int h=S.min();
			if(h<td[1])set0(h),Q.insert(h);
		}
		else
		{
			int k=mid+1;
			T.find(k);
//			while(k<td[1] && T.count(k))k++;
			if(k<td[1])set0(k),Q.insert(k);
		}

		pos++;
	}
	inline bool query(int x)
	{
		return Q.count(x)==0;
	}

	void solve()
	{
		initialize();
		pos=mid=0;

		for(int i=1,j;i<=tot;i=j+1)
		{
			for(j=i;s[j+1].y==s[j].y;j++);

			jump(s[i].y-pos-1);

			cnt=0;
			for(int k=i;k<=j;k++)
				if(s[k].ty==0)td[++cnt]=s[k].x;

			if(cnt)upd();
			else jump(1);

			for(int k=i;k<=j;k++)
				if(s[k].ty==1)
					ans[s[k].id]=query(s[k].x);
		}
		
		for(int i=1;i<=m;i++)
			if(ans[i])printf("Alice\n");
			else printf("Bob\n");
	}
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;fatesky::solve());
	fprintf(stderr,"faster time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
