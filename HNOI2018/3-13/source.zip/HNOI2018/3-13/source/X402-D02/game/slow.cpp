#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<set>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace fatesky
{
	typedef std::set<int>::iterator sit;

	const int N=510000;

	struct node
	{
		int ty,x,y,id;
		node(int ty0=0,int x0=0,int y0=0,int id0=0):ty(ty0),x(x0),y(y0),id(id0){}
		bool operator < (const node &A)const {return y==A.y?ty==A.ty?x<A.x:ty<A.ty:y<A.y;}
	};

	std::set<int> S,T;
	node s[N];

	int n,m,tot,mid;

	void initialize()
	{
		S.clear(),T.clear();
		read(n);
		for(int i=1;i<=n;i++)
		{
			read(s[i].x),read(s[i].y);
			s[i].x++,s[i].y++;

			s[i].ty=0;
		}
		read(m),tot=n+m;
		for(int i=1;i<=m;i++)
		{
			read(s[n+i].x),read(s[n+i].y);
			s[n+i].x++,s[n+i].y++;

			s[n+i].ty=1,s[n+i].id=i;
		}
		std::sort(s+1,s+tot+1);
	}
	bool ans[N];
	int pos;

	void set0(int x)
	{
		if(x<=mid)
		{
			if(S.count(x))S.erase(x);
		}
		else
		{
			if(!T.count(x))T.insert(x);
		}
	}

	std::set<int> Q;

	void jump(int k)
	{
//		printf("jump : %d\n",k);
//		printf("----------------------------------------\n");
		Q.clear();
		int lst=-1;

		pos+=k;

		int step=std::min(k,(int)S.size());
		k-=step;
		while(step--)
		{
//			Q.clear();
//			Q.insert(*S.begin());
			lst=*S.begin();

			S.erase(S.begin());
		}

		while(k>0)
		{
			lst=mid+k;

			mid+=k,k=0;
			sit it;
			while(!T.empty() && *(it=T.begin())<=mid)
				T.erase(it),k++;
		}

		if(lst!=-1)Q.insert(lst);
	}

	int td[N],cnt;
	bool ned[N];

	void upd()
	{
		Q.clear();
		for(int i=1;i<=cnt;i++)ned[i]=0,Q.insert(td[i]);

		for(int i=1;i<=cnt;i++)
		{
			int x=td[i],y=x+1,flag;

			if(y<=mid)flag=(S.count(y)!=0);
			else flag=(T.count(y)==0);

			while(!flag && (i==cnt || y<td[i+1]))
			{
				y++;
				if(y<=mid)flag=(S.count(y)!=0);
				else flag=(T.count(y)==0);
			}
			if(flag)set0(y),Q.insert(y);
		}

		for(int i=1;i<=cnt;i++)
		{
			int x=td[i];
			
			if(x<=mid)
			{
				if(!S.count(x))S.insert(x);
			}
			else
			{
				if(T.count(x))T.erase(x);
			}
		}

		if(!S.empty())
		{
			int h=*S.begin();
			if(h<td[1])set0(h),Q.insert(h);
		}
		else
		{
			int k=mid+1;
			while(k<td[1] && T.count(k))k++;
			if(k<td[1])set0(k),Q.insert(k);
		}

		pos++;
	}
	bool query(int x)
	{
		return Q.count(x)==0;
	}

	void solve()
	{
		initialize();
		pos=mid=0;

		for(int i=1,j;i<=tot;i=j+1)
		{
			for(j=i;s[j+1].y==s[j].y;j++);

			jump(s[i].y-pos-1);

			//printf("pos = %d , mid = %d\n",pos,mid);
			//printf("S : ");for(auto x:S)printf("%d ",x);printf("\n");
			//printf("T : ");for(auto x:T)printf("%d ",x);printf("\n");
			//printf("Q : ");for(auto x:Q)printf("%d ",x);printf("\n");
			//printf("----------------------------------------\n");

			cnt=0;
			for(int k=i;k<=j;k++)
				if(s[k].ty==0)td[++cnt]=s[k].x;

			if(cnt)upd();
			else jump(1);

			//printf("pos = %d , mid = %d\n",pos,mid);
			//printf("S : ");for(auto x:S)printf("%d ",x);printf("\n");
			//printf("T : ");for(auto x:T)printf("%d ",x);printf("\n");
			//printf("Q : ");for(auto x:Q)printf("%d ",x);printf("\n");
			//printf("----------------------------------------\n");

			for(int k=i;k<=j;k++)
				if(s[k].ty==1)
				{
//					printf("query : %d , %d : %d\n",s[k].x,s[k].y,s[k].id);
					ans[s[k].id]=query(s[k].x);
				}
//			printf("----------------------------------------\n");
		}
		
		for(int i=1;i<=m;i++)
			if(ans[i])printf("Alice\n");
			else printf("Bob\n");
	}
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.ans","w",stdout);
	int T;
	for(scanf("%d",&T);T--;fatesky::solve());
	fprintf(stderr,"slow time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
