#include<iostream>
#include<cstdio>
#include<cstring>
#include<bitset>

namespace Luoti
{
	const int N=1045;

	inline bool got(){for(char c=getchar();;c=getchar())if(c=='0')return 0;else if(c=='1')return 1;return 0;}

	int n;

	struct matrix 
	{
		bool s[N][N];
		matrix(int ty=0)
		{
			memset(s,0,sizeof(s));
			if(ty)for(int i=1;i<=n;i++)s[i][i]=1;
		}
	};
	struct vector
	{
		bool s[N];
		vector()
		{
			memset(s,0,sizeof(s));
		}
	};

	matrix operator * (matrix &A,matrix &B)
	{
		static std::bitset<N> u[N],v[N];
		static matrix C;

		for(int i=1;i<=n;i++)u[i].reset(),v[i].reset();
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				u[i][j]=A.s[i][j],v[i][j]=B.s[j][i];

		C=matrix(0);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				C.s[i][j]=(u[i]&v[j]).count()&1;

//				for(int k=1;k<=n;k++)
//					C.s[i][j]^=A.s[i][k]&B.s[k][j];
		return C;
	}
	vector operator * (matrix &A,vector &B)
	{
		static std::bitset<N> u[N],v;
		static vector C;

		for(int i=1;i<=n;i++)u[i].reset();v.reset();
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				u[i][j]=A.s[i][j];
		for(int i=1;i<=n;i++)v[i]=B.s[i];

		C=vector();
		for(int i=1;i<=n;i++)
			C.s[i]=(u[i]&v).count()&1;
//			for(int j=1;j<=n;j++)
//				C.s[i]^=A.s[i][j]&B.s[j];
		return C;
	}

	const int M=30;

	matrix pow[M];
	vector v;

	void initialize()
	{
		pow[0]=matrix(0);
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				pow[0].s[i][j]=got();
		for(int i=1;i<=n;i++)
			v.s[i]=got();

		for(int i=1;i<M;i++)
			pow[i]=pow[i-1]*pow[i-1];
	}

	void solve()
	{
		initialize();

		int T,k;
		for(scanf("%d",&T);T--;)
		{
			scanf("%d",&k);

			vector B=v;

			for(int i=0;i<M;i++)
				if(k&(1<<i))B=pow[i]*B;

			for(int i=1;i<=n;i++)
				printf("%d",B.s[i]);
			printf("\n");
		}
	}
}

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	Luoti::solve();
	return 0;
}
