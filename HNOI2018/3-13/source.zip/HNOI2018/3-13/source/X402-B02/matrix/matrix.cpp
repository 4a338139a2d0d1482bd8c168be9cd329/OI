#include<bits/stdc++.h>
#define pb push_back
const int N=3e2+10;
using namespace std;

int n;
bitset<N> a[N],c[N];
char str[N];

struct mat{
	int m[N][N];
	void init(){
		for(int i=1; i<=n; ++i) for(int j=1; j<=n; ++j)m[i][j]=(bool)(i==j);
	}
	void clr(){
		for(int i=1; i<=n; ++i) for(int j=1; j<=n; ++j)m[i][j]=0;
	}
	void operator *= (struct mat b){
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=n; ++j)
				a[i][j]=m[i][j];
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=n; ++j)
				c[i][j]=b.m[j][i];
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=n; ++j){
				m[i][j]=((a[i]&c[j]).count()&1);
			}
	}
} ans,ret,now;

mat pow(struct mat a,int k){
	mat g=a,s; s.init();
	while(k){
		if(k&1) s*=g;
		k>>=1; g*=g;
	}
	return s;
}

int main(){
	int T;
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	clock_t a=clock();
	for(int i=1; i<=n; ++i){
		scanf("%s",str+1);
		for(int j=1; j<=n; ++j) ans.m[i][j]=str[j]-'0';
	}
	scanf("%s",str+1);
	for(int j=1; j<=n; ++j) ret.m[j][1]=str[j]-'0';
	scanf("%d",&T);
	int kk=0;
	while(T--){
		scanf("%d",&kk);
		now=pow(ans,kk);
		now*=ret;
		for(int j=1;j<=n;++j) putchar((48+now.m[j][1]));
		putchar('\n');
	}
	clock_t b=clock();
	cerr<<1.000*(b-a)/CLOCKS_PER_SEC<<endl;
}

