#include<bits/stdc++.h>
#define getchar getchar_unlocked
const int N=110;
const int M=500010;
using namespace std;
int a[N][N];
int b[N][N];
int n,m;
struct node{
	int x,y;
};
struct node p[M],Q[M];

inline int read(){
	char ch=getchar();
	int x=0;
	while(ch>'9'||ch<'0')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int T,x,y,q;
	T=read();
	while(T--){	
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		n=read();
		for(int i=1; i<=n; ++i){
			p[i].x=read(); p[i].y=read();
		}
		q=read();
		for(int i=1; i<=q; ++i){
			Q[i].x=read(); Q[i].y=read();
		}
		if(!n){
			for(int i=1; i<=q; ++i){
				puts((Q[i].x==Q[i].y)?"Bob":"Alice");
			}
			continue;
		}
		else{
			for(int i=1; i<=n; ++i){
				a[p[i].x][p[i].y]=1;
			}
		}
		n=30;
		b[1][1]=0;
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=n; ++j){
				if(i==1&&j==1) continue;
				int v=1,l1=0x3f3f,l2=0x3f3f;
				for(int k=i-1; k; --k) if(a[k][j]){
					l1=k+1;
					break;
				}
				if(l1==0x3f3f) l1=1;
				for(int k=j-1; k; --k) if(a[i][k]){
					l2=k+1;
					break;
				}
				if(l2==0x3f3f) l2=1;
				
				int cntt=0;
				for(int k=l1; k<=i-1; ++k) cntt++, v&=b[k][j];
				for(int k=l2; k<=j-1; ++k) cntt++, v&=b[i][k];
				if(!cntt) b[i][j]=0; else 
				if(!v) b[i][j]=1; else b[i][j]=0;
			}
		for(int i=1; i<=q; ++i){
			puts(b[Q[i].x][Q[i].y]?"Alice":"Bob");
		}
	}
}
