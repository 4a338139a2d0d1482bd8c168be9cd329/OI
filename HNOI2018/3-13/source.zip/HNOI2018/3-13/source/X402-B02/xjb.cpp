#include<bits/stdc++.h>
using namespace std;

int main(){
	int n;
	n=200;
	freopen("matrix.in","w",stdout);
	printf("%d\n",n);
	for(int i=0;i<n;++i){
		for(int j=0;j<n;++j){
			int c=rand()%2;
			printf("%d",c);
		}
		puts("");
	}

	puts("");
	for(int i=1;i<=n;++i) printf("%d",rand()%2);
	puts("");

	int k=100;
	printf("%d\n",k);
	for(int i=1;i<=k;++i)
	printf("%d\n",rand()
			%1000000);
}
