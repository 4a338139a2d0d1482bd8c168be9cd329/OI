#include<bits/stdc++.h>
#define ll long long
const int N=5e3+10;
using namespace std;

int n,m;
ll f[N][N];
int a[N],b[N];

namespace buf{

	bool ck(){
		for(int j=0;j<=m;++j)if(b[j]!=j) return 0;
		return 1;
	}

	void solve(){
		scanf("%d%d",&n,&m);
		for(int i=0; i<=n; ++i)	scanf("%d",&a[i]);
		for(int j=0; j<=m; ++j) scanf("%d",&b[j]);
		
		for(int i=0; i<N; ++i)
			for(int j=0; j<N; ++j)
				f[i][j]=1e18;

		f[0][0]=0;
		for(int i=0; i<=n; ++i)
			for(int j=0; j<=m; ++j){
				if(i)f[i][j]=min(f[i][j],f[i-1][j]+b[j]);
				if(j)f[i][j]=min(f[i][j],f[i][j-1]+a[i]);
			}
		printf("%lld\n",f[n][m]);
	}
}

int main(){
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
	buf::solve();
}
