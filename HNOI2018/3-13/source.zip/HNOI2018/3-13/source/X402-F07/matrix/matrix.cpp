#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1005,all=(1<<16)-1,sz=1000/64;
int n,q_cnt,cnt[all+1];
char s[maxn];
struct bitset__{
	unsigned long long s[sz+1];
	void set(const int &pos,const bool t){
		if(((s[pos/64]>>pos&63)&1)^t)s[pos/64]^=(1ull<<(pos&63));
	}
	bool operator [] (const int &pos) const {
		return (s[pos/64]>>(pos&63))&1;
	}
};
bool bitcount(const unsigned long long x){
	return cnt[x&all]^cnt[(x>>16)&all]^cnt[(x>>32)&all]^cnt[(x>>48)&all];
}
bool And(const bitset__ &A,const bitset__ &B){
	bool res=0;
	REP(i,0,sz)
		res^=bitcount(A.s[i]&B.s[i]);
	return res;
}
struct Matrix{
	bitset__ x[maxn],y[maxn];
}A[30],B,C;
bool Ans[maxn];
void Mul(Matrix &A,const Matrix &B){
	REP(i,0,n-1)
		Ans[i]=And(B.x[i],A.y[0]);
	REP(i,0,n-1)
		A.y[0].set(i,Ans[i]);
}
void Mul2(Matrix &A,const Matrix &B){
	REP(i,0,n-1)
		REP(j,0,n-1){
			bool k=And(B.x[i],B.y[j]);
			A.x[i].set(j,k),A.y[j].set(i,k);
		}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
#endif
	REP(i,0,all)
		cnt[i]=cnt[i>>1]^(i&1);
	n=read();
	REP(i,0,n-1){
		scanf("%s",s);
		REP(j,0,n-1){
			A[0].x[i].set(j,s[j]-'0');
			A[0].y[j].set(i,s[j]-'0');
		}
	}
	scanf("%s",s);
	REP(i,0,n-1)
		B.y[0].set(i,s[i]-'0');
	REP(i,1,29)
		Mul2(A[i],A[i-1]);
	q_cnt=read();
	REP(i,1,q_cnt){
		int t=read();
		C=B;
		REP(i,0,29)
			if((t>>i)&1)
				Mul(C,A[i]);
		REP(i,0,n-1)
			putchar(C.y[0][i]^48);
		puts("");
	}
	return 0;
}
