#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=35;
int n,m;
bool mark[maxn][maxn],sg[maxn][maxn];
void work(){
	n=read();
	if(n==0){
		m=read();
		REP(i,1,m){
			int x=read(),y=read();
			puts(x==y?"Bob":"Alice");
		}
	}else{
		memset(mark,0,sizeof(mark));
		memset(sg,0,sizeof(sg));
		REP(i,1,n){
			int x=read(),y=read();
			mark[x][y]=1;
		}
		REP(i,0,30)
			REP(j,0,30){
				DREP(k,i-1,0){
					if(mark[k][j])break;
					if(sg[k][j]==0){sg[i][j]=1;break;}
				}
				if(sg[i][j])continue;
				DREP(k,j-1,0){
					if(mark[i][k])break;
					if(sg[i][k]==0){sg[i][j]=1;break;}
				}
			}
/*
		REP(i,0,10){
			REP(j,0,10){
				if(mark[i][j])putchar('X');
				else putchar(sg[i][j]^48);
			}
			puts("");
		}
		REP(i,0,10){
			REP(j,0,10){
				if(mark[i][j])putchar('X');
				else putchar(sg[i][j]^(i!=j)^48);
			}
			puts("");
		}
*/
		m=read();
		REP(i,1,m){
			int x=read(),y=read();
			puts(sg[x][y]?"Alice":"Bob");
		}
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
#endif
	int q_cnt=read();
	while(q_cnt--)work();
	return 0;
}
