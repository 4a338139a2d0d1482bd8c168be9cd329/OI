#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=500005;
int n,m,A[maxn],B[maxn];
ll dp[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("easy.in","r",stdin);
	freopen("easy.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,0,n)A[i]=read();
	REP(i,0,m)B[i]=read();
	if(n<=5000){
		memset(dp,0x3f,sizeof(dp));
		dp[0]=0;
		REP(i,1,n+m)
			DREP(j,min(m,i),0){
				dp[j]+=B[j];
				if(j>0)chkmin(dp[j],dp[j-1]+A[i-j]);
			}
		write(dp[m],'\n');
	}
	else{
		int Min=2e9;
		REP(i,0,n){
			A[i]+=n-i;
			chkmin(Min,A[i]);
		}
		write(1ll*Min*m,'\n');
	}
	return 0;
}
