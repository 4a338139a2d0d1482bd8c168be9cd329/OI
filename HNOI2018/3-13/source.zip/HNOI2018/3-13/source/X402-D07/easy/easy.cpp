#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=5010,INF=0x3f3f3f3f;

int n,m;
int a[maxn],b[maxn];
int f[maxn][maxn];

int main(){
    freopen("easy.in","r",stdin);
    freopen("easy.out","w",stdout);

    read(n); read(m);

    for(int i=0;i<=n;i++) read(a[i]);
    for(int i=0;i<=m;i++) read(b[i]);

    memset(f,INF,sizeof f);
    f[0][0]=0;

    for(int i=0;i<=n;i++)
        for(int j=0;j<=m;j++) if(i||j){
            if(j) chkmin(f[i][j],f[i][j-1]+a[i]);
            if(i) chkmin(f[i][j],f[i-1][j]+b[j]);
        }

    printf("%d\n",f[n][m]);

    return 0;
}
