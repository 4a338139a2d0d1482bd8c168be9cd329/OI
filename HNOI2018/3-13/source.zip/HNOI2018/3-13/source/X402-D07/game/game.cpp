#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int lim=30;

int n,q;
bool book[lim+5][lim+5];
int SG[lim+5][lim+5];
bool t[lim*lim+5];

namespace SP{
    void solve(){
        read(q);

        while(q--){
            int x,y;
            read(x); read(y);
            puts((x^y)?"Alice":"Bob");
        }
    }
}

int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);

    int _; read(_);
    while(_--){
        read(n);

        if(!n){ SP::solve(); continue; }

        for(int i=1;i<=n;i++){
            int x,y;
            read(x); read(y);
            book[x][y]=1;
        }

        for(int i=0;i<=lim;i++)
            for(int j=0;j<=lim;j++){
                memset(t,0,sizeof t);
                for(int k=0;i-k>=0&&!book[i-k][j];k++) if(k) t[SG[i-k][j]]=1;
                for(int k=0;j-k>=0&&!book[i][j-k];k++) if(k) t[SG[i][j-k]]=1;
                for(int k=0;k<=lim*lim;k++) if(!t[k]){ SG[i][j]=k; break; }
            }

        read(q);

        while(q--){
            int x,y;
            read(x); read(y);
            puts(SG[x][y]?"Alice":"Bob");
        }
    }

    return 0;
}
