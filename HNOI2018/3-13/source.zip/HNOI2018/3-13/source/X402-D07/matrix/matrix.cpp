#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=1e3+10,maxm=1e2+10;

int n,m;

char s[maxn];

struct Matrix{
    bitset<maxn> M[maxn];
} A[32];

bitset<maxn> x;

Matrix mul(Matrix a,Matrix b){
    Matrix c;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++) if(a.M[i][j]) c.M[i]^=b.M[j];
    return c;
}

bitset<maxn> mul(Matrix a,bitset<maxn> b){
    bitset<maxn> ret;
    for(int i=1;i<=n;i++) ret[i]=((a.M[i]&b).count()&1);
    return ret;
}

int main(){
    freopen("matrix.in","r",stdin);
    freopen("matrix.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++){
        scanf("%s",s+1);
        for(int j=1;j<=n;j++) A[0].M[i][j]=(s[j]=='1');
    }

    scanf("%s",s+1);
    for(int i=1;i<=n;i++) x[i]=(s[i]=='1');

    for(int i=1;i<31;i++) A[i]=mul(A[i-1],A[i-1]);

    read(m);

    while(m--){
        int k; read(k);
        bitset<maxn> res=x;
        for(int i=0;i<31;i++) if((k>>i)&1) res=mul(A[i],res);
        for(int i=1;i<=n;i++) printf("%d",(res[i]==1));
        puts("");
    }

    return 0;
}
