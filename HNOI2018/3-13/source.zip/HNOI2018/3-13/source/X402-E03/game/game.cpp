#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 35 ;
int g[maxn][maxn], n ;
bool a[maxn][maxn] ;
bool Query ( int x, int y ) {
	int &rec = g[x][y], i ;
	if (rec != -1) return rec ;
	rec = 0 ;
	for ( i = x-1 ; i >= 0 ; i -- ) {
		if (a[i][y]) break ;
		if (!Query(i, y)) return rec = 1 ;
	}
	for ( i = y-1 ; i >= 0 ; i -- ) {
		if (a[x][i]) break ;
		if (!Query(x, i)) return rec = 1 ;
	}
	return rec ;
}
void solve() {
	int i, _, x, y ;
	memset (g, -1, sizeof g) ;
	memset (a, 0, sizeof a) ;
	Read(n) ;
	for ( i = 1 ; i <= n ; i ++ ) {
		Read(x), Read(y) ;
		a[x][y] = 1 ;
	}
	Read(_) ;
	while (_--) {
		Read(x), Read(y) ;
		if (n == 0) {
			if (x^y) puts("Alice") ;
			else puts("Bob") ;
		} else {
			if (Query(x, y)) puts("Alice") ;
			else puts("Bob") ;
		}
	}
}
int main() {
	freopen ( "game.in", "r", stdin ) ;
	freopen ( "game.out", "w", stdout ) ;
	int _ ;
	for ( Read(_) ; _-- ; solve() ) ;
	return 0 ;
}
