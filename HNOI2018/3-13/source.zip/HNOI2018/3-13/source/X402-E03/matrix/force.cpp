#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 501 ;
int n, m ;
struct Matrix {
	bool s[maxn][maxn] ;
	int N, M ;
	friend Matrix operator * ( Matrix A, Matrix B ) {
		Matrix C ;
		C.N = A.N, C.M = B.M ;
		for ( int i = 1 ; i <= C.N ; i ++ )
			for ( int j = 1 ; j <= C.M ; j ++ ) {
				C.s[i][j] = 0 ;
				for ( int k = 1 ; k <= A.M ; k ++ )
					C.s[i][j] ^= A.s[i][k]&B.s[k][j] ;
			}
		return C ;
	}
	void check() {
		for ( int i = 1 ; i <= N ; i ++, puts("") )
			for ( int j = 1 ; j <= M ; j ++ )
				printf ( "%d", s[i][j] ) ;
	}
} V, a[31] ;
Matrix Qpow ( Matrix A, int b, Matrix rec = a[0] ) {
	for ( ; b ; b >>= 1, A = A*A )
		if (b&1) rec = rec*A ;
	return rec ;
}
char chr[maxn] ;
int main() {
	freopen ( "matrix.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;
	Read(n) ;
	int i, j, x, _ ;
	for ( i = 1 ; i <= n ; i ++ ) {
		scanf ( "%s", chr+1 ) ;
		for ( j = 1 ; j <= n ; j ++ ) {
			a[0].s[i][j] = (i==j) ;
			a[1].s[i][j] = chr[j]-'0' ;
		}
	}
	a[0].N = a[0].M = a[1].N = a[1].M = n ;
	scanf ( "%s", chr+1 ) ;
	for ( i = 1 ; i <= n ; i ++ )
		V.s[i][1] = chr[i]-'0' ;
	V.N = n, V.M = 1 ;
	for ( i = 2 ; i <= 30 ; i ++ ) {
		a[i] = a[i-1]*a[i-1] ;
		//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	}
	Matrix rec ;
	Read(_) ;
	while (_--) {
		rec = a[0] ;
		Read(x) ;
		for ( i = 1 ; x ; x >>= 1, i ++ )
			if (x&1) rec = rec*a[i] ;
		//rec.check() ;
		rec = rec*V ;
		for ( i = 1 ; i <= n ; i ++ )
			putchar(rec.s[i][1]+'0') ;
		puts("") ;
	}
	cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
