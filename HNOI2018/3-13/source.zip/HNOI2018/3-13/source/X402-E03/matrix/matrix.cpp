#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 1005 ;
int n, m ;
struct Matrix {
	bitset <maxn> s[maxn] ;
	int N, M ;
} V, a[31], C ;
Matrix operator * ( Matrix A, Matrix B ) {
	int i, j ;
	/*for ( i = 1 ; i <= B.N ; i ++ )
		for ( j = 1 ; j <= B.M ; j ++ )
			C.s[j][i] = B.s[i][j] ;
	swap(B.M, B.N) ;
	for ( i = 1 ; i <= B.N ; i ++ )
		for ( j = 1 ; j <= B.M ; j ++ )
			B.s[i][j] = C.s[i][j] ;*/
	C.N = A.N, C.M = B.M ;
	for ( i = 1 ; i <= C.N ; i ++ )
		C.s[i] = 0 ;
	for ( i = 1 ; i <= A.M ; i ++ ) for ( j = 1 ; j <= A.N ; j ++ )
		if (A.s[j][i]) C.s[j] ^= B.s[i] ;
	return C ;
}
Matrix Mul ( Matrix A, Matrix B ) {
	int i, j ;
	for ( i = 1 ; i <= B.N ; i ++ )
		for ( j = 1 ; j <= B.M ; j ++ )
			C.s[j][i] = B.s[i][j] ;
	swap(B.M, B.N) ;
	for ( i = 1 ; i <= B.N ; i ++ )
		for ( j = 1 ; j <= B.M ; j ++ )
			B.s[i][j] = C.s[i][j] ;
	C.N = A.N, C.M = B.N ;
	for ( i = 1 ; i <= C.N ; i ++ ) {
		C.s[i][j] = 0 ;
		for ( j = 1 ; j <= C.M ; j ++ )
			C.s[i][j] = (A.s[i]&B.s[j]).count()&1 ;
	}
	return C ;
}
Matrix Qpow ( Matrix A, int b ) {
	C = a[0] ;
	for ( ; b ; b >>= 1, A = A*A )
		if (b&1) C = C*A ;
	return C ;
}
char chr[maxn] ;
int main() {
	freopen ( "matrix.in", "r", stdin ) ;
	freopen ( "matrix.out", "w", stdout ) ;
	Read(n) ;
	int i, j, x, _ ;
	for ( i = 1 ; i <= n ; i ++ ) {
		scanf ( "%s", chr+1 ) ;
		for ( j = 1 ; j <= n ; j ++ ) {
			a[0].s[i][j] = (i==j) ;
			a[1].s[i][j] = chr[j]-'0' ;
		}
	}
	a[0].N = a[0].M = a[1].N = a[1].M = n ;
	scanf ( "%s", chr+1 ) ;
	for ( i = 1 ; i <= n ; i ++ )
		V.s[i][1] = chr[i]-'0' ;
	V.N = n, V.M = 1 ;
	for ( i = 2 ; i <= 30 ; i ++ )
		a[i] = a[i-1]*a[i-1] ;
	Matrix rec ;
	Read(_) ;
	while (_--) {
		rec = V ;
		Read(x) ;
		//cerr << x << endl ;
		for ( i = 1 ; x ; x >>= 1, i ++ )
			if (x&1) rec = Mul(a[i],rec) ;
		//rec.check() ;
		for ( i = 1 ; i <= n ; i ++ )
			putchar(rec.s[i][1]+'0') ;
		puts("") ;
	}
	cerr << "solve " <<  (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
