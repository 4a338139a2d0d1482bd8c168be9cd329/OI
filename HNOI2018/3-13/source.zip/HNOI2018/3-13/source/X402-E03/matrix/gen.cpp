#include <bits/stdc++.h>
using namespace std ;
int main() {
	srand(time(0)) ;
	freopen ( "matrix.in", "w", stdout ) ;
	int i, j, n, _, maxv = 1e9+1 ;
	n = 1000, _ = 100 ;
	printf ( "%d\n", n ) ;
	for ( i = 0 ; i <= n ; i ++, puts("") )
		for ( j = 1 ; j <= n ; j ++ )
			putchar(rand()%2+'0') ;
	printf ( "%d\n", _ ) ;
	while (_--)
		printf ( "%d\n", rand()%maxv ) ;
		//cout << (1<<30)-1 << endl ;
	return 0 ;
}
