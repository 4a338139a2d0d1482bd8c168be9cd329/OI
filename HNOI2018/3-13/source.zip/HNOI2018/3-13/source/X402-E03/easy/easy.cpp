#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 5005, maxN = 5e5+5 ;
LL n, m, a[maxN], b[maxN], g[maxn][maxn] ;
void chkmin ( LL &a, LL b ) { a = a<b? a:b ; }
int main() {
	freopen ( "easy.in", "r", stdin ) ;
	freopen ( "easy.out", "w", stdout ) ;
	int i, j ;
	Read(n), Read(m) ;
	for ( i = 0 ; i <= n ; i ++ )
		Read(a[i]) ;
	for ( i = 0 ; i <= m ; i ++ )
		Read(b[i]) ;
	for ( i = 0 ; i <= n ; i ++ )
		for ( j = 0 ; j <= m ; j ++ )
			g[i][j] = 1e16 ;
	g[0][0] = 0 ;
	for ( i = 0 ; i <= n ; i ++ )
		for ( j = 0 ; j <= m ; j ++ ) {
			chkmin(g[i][j+1], g[i][j]+a[i]) ;
			chkmin(g[i+1][j], g[i][j]+b[j]) ;
			//printf ( "g[%d][%d]=%lld\n", i, j, g[i][j] ) ;
		}
	printf ( "%lld\n", g[n][m] ) ;
	return 0 ;
}
