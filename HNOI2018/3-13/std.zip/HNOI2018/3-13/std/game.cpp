#include <cstdio>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

#define MAX 100000
#define END 1100000000

int T, N, Q;
typedef pair<int, int> point;
point blocked[MAX+1];
pair<point, int> start[MAX+1];
bool answer[MAX];

int main(){	
	scanf("%d", &T);
	while(T--){
		// Read the input
		scanf("%d", &N);
		for(int i=0; i<N; i++)
			scanf("%d%d", &blocked[i].first, &blocked[i].second);
		blocked[N++]=make_pair(END, END);
		sort(blocked, blocked+N);
		scanf("%d", &Q);
		for(int i=0; i<Q; i++){
			scanf("%d%d", &start[i].first.first, &start[i].first.second);
			start[i].second=i;
		}
		// Add a dummy cell at the end
		start[Q]=make_pair(make_pair(END, END), Q);
		Q++;
		sort(start, start+Q);
		
		// Current x-value of our line sweep
		int sweepx=0;
		int n=0, q=0;
		int lastx=0, lasty=0;

		// Rows with losing positions in them.  segments[A]=B if
		// every row in the segment [A,B] has losing position
		// (unless the row is in "holes")
		map<int, int> segments;
		set<int> holes;
		segments[0]=0;
		segments[END]=END;
		holes.insert(END);
		for(;;){
			// The next x-value of the line-sweep
			int nextx = min(blocked[n].first, start[q].first.first);
			if(nextx == END)
				break;
			// Move the line
			while(sweepx < nextx){
				// If the first segment has a hole, remove the hole.
				// Otherwise, extend the first segment.
				if(*holes.begin() <= segments[0]){
					lastx = sweepx+1;
					lasty = *holes.begin();
					holes.erase(holes.begin());
					sweepx++;
				}else{
					map<int, int>::iterator second = segments.begin();
					second++;
					int diff = second->first - segments[0] - 1;
					int goal = nextx - sweepx;
					// If there is a large enough gap between this segment
					// and the next, extend this segment.  Otherwise, merge
					// this segment and the next.
					if(diff < goal){
						sweepx += diff;
						segments[0] = second->second;
						segments.erase(second);
					}else{
						sweepx += goal;
						segments[0] += goal;
						lastx = sweepx;
						lasty = segments[0];
					}
				}
			}
			if(blocked[n] < start[q].first){
				// Adding an impassable cell.  We need to mark the current
				// row as not having a losing cell, and find the next cell
				// in this column that is losing.
				int y = blocked[n].second;
				map<int, int>::iterator next = segments.upper_bound(y);
				map<int, int>::iterator prev = next;
				prev--;
				if(prev->second >= y){
					holes.insert(y);
				}
				if(y >= lasty){
					if(next->first == y+1){
						prev = next;
						next++;
					}
					// Merge adjacent segments
					while(prev->second == next->first-1){
						prev->second = next->second;
						segments.erase(next);
						next = prev;
						next++;
					}
					// 3 cases follow: either we remove a hole, extend
					// a segment, or add a new segment
					set<int>::iterator hole = holes.upper_bound(y);
					if(*hole <= prev->second){
						lasty = *hole;
						holes.erase(hole);
					}else if(prev->second >= y){
						prev->second++;
						lasty = prev->second;
					}else{
						segments[y+1] = y+1;
						lasty = y+1;
					}
				}
				n++;
			}else{
				answer[start[q].second] = sweepx == lastx && lasty == start[q].first.second;
				q++;
			}
		}
		for(int i=0; i<Q-1; i++)
			puts(answer[i] ? "Bob" : "Alice");
	}
}