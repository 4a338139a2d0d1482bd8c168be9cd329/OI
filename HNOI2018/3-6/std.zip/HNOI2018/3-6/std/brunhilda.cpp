#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#include<map>
using namespace std;

typedef long long ll;
const int maxn=10000010;
const int N=10000000;
int m, q, n;
int a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int dp[maxn], ans[maxn], Max;

int check(int x){
	int ret=x;
	for(int i=1;i<=m;i++) ret=min(ret, x-(x%a[i]));
	return ret;
}
void solve(){
	for(int i=1;i<maxn;i++){
		int l=dp[i-1], r=dp[i-1]+Max, ret=l;
		while(l<=r){
			int mid=(l+r)>>1;
			if(check(mid)<=dp[i-1]) l=mid+1, ret=mid; else r=mid-1;
		}
		dp[i]=ret;
		dp[i]=min(dp[i], N);
		if(dp[i]>=N) break;
	}
}

int main(){
	freopen("brunhilda10.in","r",stdin),freopen("brunhilda.out","w",stdout);

	read(m); read(q);
	ll mul=1;
	for(int i=1;i<=m;i++) read(a[i]), Max=max(Max, a[i]), mul=min((ll)1e7, mul*a[i]);
	solve();
	for(int i=1;i<maxn;i++) for(int j=dp[i-1]+1;j<=dp[i];j++) ans[j]=i;
	while(q--){
		read(n);
		if(n>=mul){ puts("oo"); continue; }
		printf("%d\n", ans[n]);
	}
	return 0;
}
