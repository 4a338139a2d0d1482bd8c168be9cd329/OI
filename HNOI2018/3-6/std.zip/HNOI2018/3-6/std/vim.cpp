#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#include<map>
using namespace std;

const int maxn=70010;
const int size=11;
int n, len;
char s[maxn];
bool must[maxn];
int a[maxn], f[maxn][size], g[maxn][size][size];
int cnt, ans;

void chkmin(int& x,int y){ if(x>y) x=y; }

int main(){
	freopen("vim25.in","r",stdin),freopen("vim.out","w",stdout);

	scanf("%d%s", &len, s+1);
	int fi=0;
	for(int i=1;i<=len;i++){
		if(s[i]=='e') cnt+=2, fi=1;
		else{ a[++n]=s[i]-'a'; if(fi) must[n]=1, fi=0; }
	}
	memset(f, 0x3f, sizeof(f)); memset(g, 0x3f, sizeof(g));
	f[1][ a[1] ]=0;
	for(int i=1;i<=n;i++){
		for(int j=0;j<size;j++){
			if(j!=a[i] && !must[i]) chkmin(f[i+1][j], f[i][j]);
			chkmin(f[i+1][j], f[i][ a[i] ]+2);
			if(j!=a[i]) chkmin(f[i+1][j], g[i][ a[i] ][j]);
			chkmin(f[i+1][j], g[i][ a[i] ][ a[i] ]+2);
		}
		for(int j=0;j<size;j++) for(int k=0;k<size;k++){
			if(j!=a[i] && k!=a[i]) chkmin(g[i+1][j][k], g[i][j][k]+1);
			if(j!=a[i]) chkmin(g[i+1][j][k], g[i][j][ a[i] ]+3);
			if(k!=a[i]) chkmin(g[i+1][j][k], g[i][ a[i] ][k]+3);
			chkmin(g[i+1][j][k], g[i][ a[i] ][ a[i] ]+5);
			if(j!=a[i]) chkmin(g[i+1][j][k], f[i][j]+3);
			chkmin(g[i+1][j][k], f[i][ a[i] ]+5);
		}
	}
	printf("%d\n", f[n+1][size-1]+cnt-2);
	return 0;
}
