#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
using namespace std;

const int maxn=30;
const int maxm=maxn*maxn*30+100;
const int inf=1e9;
int n, m;
char c[maxn];
int s[maxn][maxn], t[maxn][maxn];
int val[maxn][maxn];
int dx[8]={-1,-1,0,1,1,1,0,-1},dy[8]={0,-1,-1,-1,0,1,1,1};

int to[maxm*2],Next[maxm*2],Begin[maxm],e=1,cost[maxm*2],w[maxm*2];
void add(int x,int y,int z,int c){
	to[++e]=y, Next[e]=Begin[x], Begin[x]=e, cost[e]=c; w[e]=z;
}
void addedge(int x,int y,int z,int c){
	add(x,y,z,c); add(y,x,0,-c);
}

int dis[maxm], vis[maxm], S, T, inq[maxm];
bool spfa(){
	for(int i=1;i<=T;i++) dis[i]=inf, inq[i]=0;
	queue<int> q;
	q.push(S); dis[S]=0;
	while(!q.empty()){
		int x=q.front(); q.pop(); inq[x]=0;
		for(int i=Begin[x];i;i=Next[i]) if(w[i]>0){
			int v=to[i];
			if(dis[v]>dis[x]+cost[i]){
				dis[v]=dis[x]+cost[i];
				if(!inq[v]) inq[v]=1, q.push(v);
			}
		}
	}
	return dis[T]<inf;
}

int dfs(int x,int flow){
	vis[x]=1;
	if(x==T) return flow;
	int res=flow, v;
	for(int i=Begin[x];i;i=Next[i])if(!vis[v=to[i]] && w[i]>0 && dis[v]==dis[x]+cost[i]){
		int Min=dfs(v,min(res,w[i]));
		w[i]-=Min; w[i^1]+=Min;
		res-=Min;
		if(!res) return flow;
	}
	return flow-res;
}

int ans;
void solve(){
	while(spfa()){
		vis[T]=1;
		int flow=0;
		while(vis[T]){
			memset(vis,0,sizeof(vis));
			flow+=dfs(S,inf);
		}
		ans+=flow*dis[T];
	}
}

int id[maxn][maxn];
int main(){
	freopen("txt.in","r",stdin),freopen("txt.out","w",stdout);

	scanf("%d%d", &n, &m);
	S=n*m*3+1, T=S+1;
	for(int i=1;i<=n;i++){
		scanf("%s", c+1);
		for(int j=1;j<=m;j++) s[i][j]=c[j]-'0';
	}
	for(int i=1;i<=n;i++){
		scanf("%s", c+1);
		for(int j=1;j<=m;j++) t[i][j]=c[j]-'0';
	}
	for(int i=1;i<=n;i++){
		scanf("%s", c+1);
		for(int j=1;j<=m;j++) val[i][j]=c[j]-'0';
	}
	int cnt=0, cnt1=0, cnt2=0;
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) id[i][j]=++cnt;
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++){
		if(s[i][j]) addedge(S,id[i][j]+n*m,1,0), cnt1++;
		if(t[i][j]) addedge(id[i][j]+n*m,T,1,0), cnt2++;
	}
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++){
		int now=id[i][j];
		if(s[i][j] && t[i][j]) addedge(now,now+n*m,val[i][j]/2,1), addedge(now+n*m,now+n*m*2,val[i][j]/2,0);
		else if(s[i][j]) addedge(now,now+n*m,val[i][j]/2,1), addedge(now+n*m,now+2*n*m,(val[i][j]+1)/2,0);
		else if(t[i][j]) addedge(now,now+n*m,(val[i][j]+1)/2,1), addedge(now+n*m,now+n*m*2,val[i][j]/2,0);
		else addedge(now,now+n*m,val[i][j]/2,1), addedge(now+n*m,now+n*m*2,val[i][j]/2,0);
		for(int k=0;k<8;k++){
			int xx=i+dx[k], yy=j+dy[k];
			if(xx<1 || xx>n || yy<1 || yy>m) continue;
			addedge(now+2*n*m,id[xx][yy],inf,0);
		}
	}
	solve();
	printf("%d\n", cnt1==cnt2?ans:-1);
	return 0;
}
