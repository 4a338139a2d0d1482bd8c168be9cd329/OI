#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N = 1010, INF = 0x3f3f3f3f, M = 200010;
const int dx[]={0,1,0,-1,1,1,-1,-1},dy[]={1,0,-1,0,1,-1,1,-1};
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);
}
struct Flow{
	int d[N],cur[N],vis[N],Begin[N],f[M],w[M],S,T,e,to[M],Next[M];
	queue<int>q;
	inline void add(int x,int y,int z,int v){
		to[++e]=y,Next[e]=Begin[x],Begin[x]=e;f[e]=z,w[e]=v;
		to[++e]=x,Next[e]=Begin[y],Begin[y]=e,f[e]=0,w[e]=-v;
	}
	inline void init(int s,int t){
		e=1;S=s,T=t;
		memset(Begin,0,sizeof(Begin));
		memset(vis,0,sizeof(vis));
	}
	bool SPFA(){
		For(i,1,T)d[i]=INF,vis[i]=0;d[S]=0;
		q.push(S);
		while(!q.empty()){
			int r=q.front();q.pop();vis[r]=0;
			Rep(i,r)
				if(f[i]&&d[v]>d[r]+w[i]){
					d[v]=d[r]+w[i];
					if(!vis[v])q.push(v),vis[v]=1;
				}
		}
		return d[T]!=INF;
	}
	int DFS(int u,int flow){
		if(u==T)return flow;
		int res=flow;vis[u]=1;
		for(int &i=cur[u],v=to[i];i;i=Next[i],v=to[i]){
			if(!f[i]||vis[v]||d[v]!=d[u]+w[i])continue;
			int a=DFS(v,min(res,f[i]));
			f[i]-=a,f[i^1]+=a;
			if(!(res-=a))return flow;
		}vis[u]=0;
		return flow-res;
	}
	pair<int,int> Maxflow(){
		int ans1=0,ans2=0;
		while(SPFA()){
			For(i,1,T)cur[i]=Begin[i],vis[i]=0;
			int a=DFS(S,INF);
			ans1+=a,ans2+=a*d[T];
		}
		return make_pair(ans1,ans2);
	}
}F;
int n, m, A[21][21], B[21][21], C[21][21]; 
inline int id(int x, int y,int c){
	return 2 *((x - 1) * m + y) + c;
}
int cnt = 0;
char ch[N];
void init(){
	read(n), read(m);
	int s = 2 * (n * m) + 3, t = s + 1;
	F.init(s, t);
	For(i, 1, n){
		scanf("%s", ch + 1);
		For(j, 1, m)A[i][j] = ch[j] - '0';
	}		
	For(i, 1, n){
		scanf("%s", ch + 1);
		For(j, 1, m)B[i][j] = ch[j] - '0';
	}
	For(i, 1, n){
		scanf("%s", ch + 1);
		For(j, 1, m){
			C[i][j] = ch[j] - '0';
			if(ch[j] == 'z')C[i][j] = 74;
			if(A[i][j] && !B[i][j]){
				F.add(s, id(i, j, 0), 1, 0);
				F.add(id(i, j, 0), id(i, j, 1), (C[i][j] + 1) / 2, 0);
				cnt++;
			}
			else if(!A[i][j] && B[i][j]){
				F.add(id(i, j, 1), t, 1, 0);
				F.add(id(i, j, 0), id(i, j, 1), (C[i][j] + 1) / 2, 0);
			}
			else if(!A[i][j] && !B[i][j])
				F.add(id(i, j, 0), id(i, j, 1), C[i][j] / 2, 0);
		}
	}
	For(i, 1, n)
		For(j, 1, m)
			For(k, 0, 7){
				int x = dx[k] + i, y = dy[k] + j;
				if(x>0&&y>0&&x<=n&&y<=m)
					F.add(id(i, j, 1), id(x, y, 0), INF, 1);
			}
}
void solve(){
	pair<int, int>ans;
	ans = F.Maxflow();
	if(ans.first != cnt)puts("-1");
	else printf("%d\n", ans.second);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
