#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("brunhilda.in","r",stdin);
	freopen("BF.out","w",stdout);
}
int m, Q, p[N], q[N], n;
void init(){
	read(m), read(Q);
	For(i, 1, m)read(p[i]);
	For(i, 1, Q)read(q[i]), n = max(n, q[i]);
}
int dp[N*100];
void solve(){
	For(i, 1, p[m] - 1)dp[i] = 1;
	For(i, p[m], n){
		dp[i] = INF;
		For(j, 1, m)
			dp[i] = min(dp[i], dp[p[j] * (i / p[j])] + 1);
	}
	For(i, 1, Q)
		if(dp[q[i]] != INF)printf("%d\n", dp[q[i]]); 
		else puts("oo");		
}
int main(){
	file();
	init();
	solve();
	return 0;
}
