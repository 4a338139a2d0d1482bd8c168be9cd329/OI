#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f, M = 1e7 +10;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
}
int m, Q, p[N], q[N], n, B[M];
int pri[M], tot, mx[M];
bool vis[M];
void get_pri(){
	mx[1] = 0;
	For(i, 2, n){
		if(!vis[i])pri[++tot] = i, mx[i] = B[i] ? i : 0;
		for(ll j = 1, v;(v = pri[j] * i) <= n && j <= tot; ++j){
			vis[v] = 1;
			mx[v] = max(mx[pri[j]], mx[i]);
			if(i % pri[j] == 0)break;
		}
	}
}
void init(){
	read(m), read(Q);
	For(i, 1, m)read(p[i]), B[p[i]] = 1;
	sort(p + 1, p + m + 1);
	For(i, 1, Q)read(q[i]), n = max(n, q[i]);
	get_pri();

}
int dp[M];
int f[M],ok;
int find(int x){
    int k, j, r;
    r = x;
    while(r != f[r])r = f[r];      
    k = x;        
    while(k != r)j = f[k], f[k] = r, k = j;                       
    return r;                   
}
inline void link(int x, int y){
	x = find(x), y = find(y);
	f[x] = y; find(x);
}
void solve(){
	dp[0] = 0;
	For(i, 1, n + 1)f[i] = i, dp[i] = INF;

	For(i, 0, n){
		int l = i + 1, r = min(i + mx[i] - 1, n);
		if(i < p[m])r = max(r, min(p[m] - 1, n));
		l = find(l);
		if(l == n + 1)break;
		For(j, l, r){
			dp[j] = min(dp[j], dp[i] + 1);
			link(j, j + 1);
		}
	}
	For(i, 1, Q)
		if(dp[q[i]] != INF)printf("%d\n", dp[q[i]]); 
		else puts("oo");		
}
int main(){
	file();
	init();
	solve();
	return 0;
}
