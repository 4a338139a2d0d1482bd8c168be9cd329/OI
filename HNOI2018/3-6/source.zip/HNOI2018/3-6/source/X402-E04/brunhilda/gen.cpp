#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int M = 1e7 + 10;
int pri[M], tot;
bool vis[M];
void get_pri(int n = 1e4){
	For(i, 2, n){
		if(!vis[i])pri[++tot] = i;
		for(ll j = 1, v;(v = pri[j] * i) <= n && j <= tot; ++j){
			vis[v] = 1;
			if(i % pri[j] == 0)break;
		}
	}
}
int main(){
	freopen("brunhilda.in","w",stdout);
	int n = 10000, Q = 10000;
	printf("%d %d \n", n, Q);
	srand(time(0));
	get_pri(n/100);
	For(i, 1, n)printf("%d ",pri[rand()%tot + 1]);puts("");
	For(i, 1, Q)printf("%d\n",rand()%(n) + 1);puts("");
	return 0;
}
