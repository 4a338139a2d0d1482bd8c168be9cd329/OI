#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+10,maxa=1e7+10;
int n,a[maxn],m,endd;
int dis[maxa],pop[maxa],maxfac[maxa];
queue<int> q;

int main(){
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	sort(a+1,a+n+1);
	n=unique(a+1,a+n+1)-a-1;
	for(int i=1;i<=n;++i)
		for(int j=1;a[i]*j<maxa;++j)
			if(maxfac[a[i]*j]<a[i])
				maxfac[a[i]*j]=a[i];
	q.push(0);
	++pop[a[n]];
	endd=a[n];
	for(int i=1;i<maxa;++i){
		for(int j=0;j<pop[i];++j)
			q.pop();
		if(!q.empty())
			dis[i]=q.front()+1;
		else{
			while(i<maxa)
				dis[i++]=-1;
			break;
		}
		if(maxfac[i]&&i+maxfac[i]>endd){
			if(i+maxfac[i]<maxa)
				++pop[i+maxfac[i]];
			q.push(dis[i]);
			endd=i+maxfac[i];
		}
	}
	while(m--){
		int pos;
		scanf("%d",&pos);
		if(~dis[pos])
			printf("%d\n",dis[pos]);
		else
			puts("oo");
	}
	return 0;
}
