#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+10,maxa=1e7+10,inf=1e9;
int n,a[maxn],m;
int dis[maxa];

int main(){
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1;i<maxa;++i)
		dis[i]=inf;
	for(int i=0;i<maxa;++i){
		if(dis[i]==inf)continue;
		for(int j=1;j<=n;++j)
			if(i%a[j]==0)
				for(int k=1;k<a[j]&&i+k<maxa;++k)
				if(dis[i+k]>dis[i]+1)
					dis[i+k]=dis[i]+1;
	}
	while(m--){
		int pos;
		scanf("%d",&pos);
		if(dis[pos]!=inf)
			printf("%d\n",dis[pos]);
		else
			puts("oo");
	}
	return 0;
}
