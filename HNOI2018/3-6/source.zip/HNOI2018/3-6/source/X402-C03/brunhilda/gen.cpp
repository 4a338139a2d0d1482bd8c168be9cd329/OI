#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE* f=fopen("seed","r");
	int seed;
	if(f==NULL)
		seed=time(NULL)+(clock()*clock()*clock()^123456789);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
const int xxx=1e7;
int pcnt,p[xxx+10];
bool prm[xxx+10];

int main(){
	init();
	freopen("brunhilda.in","w",stdout);
	for(int i=2;i<=xxx;++i){
		if(!prm[i])
			p[++pcnt]=i;
		for(int j=1;j<=pcnt&&i*p[j]<=xxx;++j)
			if(i%p[j])
				prm[i*p[j]]=true;
			else{
				prm[i*p[j]]=true;
				break;
			}
	}
	int n=10,m=1e5;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;++i){
		int x;
		x=rand()%(int)pow(pcnt,1.0/(rand()%20+1))+1;
		if(!p[x]){--i;continue;}
		printf("%d ",p[x]);
		p[x]=0;
	}
	puts("");
	for(int i=1;i<=m;++i)
		printf("%d\n",rand()%xxx+1);
	return 0;
}
