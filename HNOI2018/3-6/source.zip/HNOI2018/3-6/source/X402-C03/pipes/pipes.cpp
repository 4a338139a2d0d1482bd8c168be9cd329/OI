#include<bits/stdc++.h>
using namespace std;

const int maxn=20+5,maxnn=20*20*2+10,maxm=maxnn*10,dx[]={1,1,1,0,-1,-1,-1,0},dy[]={-1,0,1,1,1,0,-1,-1},inf=1e9;
int n,m,cnta,cntb,s,t,res,ans;
char a[maxn][maxn],b[maxn][maxn],c[maxn][maxn];
int ecnt=1,ebeg[maxnn],enxt[maxm],eto[maxm],ecap[maxm],ew[maxm];
int dis[maxnn],pre[maxnn];bool inq[maxnn];

inline void adde(int u,int v,int c,int w){
	++ecnt;
	enxt[ecnt]=ebeg[u];
	ebeg[u]=ecnt;
	eto[ecnt]=v;
	ecap[ecnt]=c;
	ew[ecnt]=w;
}
inline void ae(int u,int v,int c,int w){
	adde(u,v,c,w);
	adde(v,u,0,-w);
}
inline int id(int x,int y,int type){
	return (x-1)*m+y+type*n*m;
}
inline int spfa(){
	for(int i=1;i<=t;++i)
		dis[i]=inf;
	dis[s]=0;
	queue<int> q;
	inq[s]=true;
	q.push(s);
	while(!q.empty()){
		int pos=q.front();q.pop();
		inq[pos]=false;
		if(pos==t)
			continue;
		for(int i=ebeg[pos],v;i;i=enxt[i])
			if(ecap[i]&&dis[v=eto[i]]>dis[pos]+ew[i]){
				dis[v]=dis[pos]+ew[i];
				pre[v]=i;
				if(!inq[v]){
					inq[v]=true;
					q.push(v);
				}
			}
	}
	if(dis[t]==inf)
		return 0;
	int flow=inf;
	for(int p=t;p!=s;p=eto[pre[p]^1])
		if(flow>ecap[pre[p]])
			flow=ecap[pre[p]];
	for(int p=t;p!=s;p=eto[pre[p]^1]){
		ans+=ew[pre[p]]*flow;
		ecap[pre[p]]-=flow;
		ecap[pre[p]^1]+=flow;
	}
	return flow;
}

int main(){
	!freopen("pipes.in","r",stdin);
	!freopen("pipes.out","w",stdout);
	!scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		!scanf("%s",a[i]+1);
	for(int i=1;i<=n;++i)
		!scanf("%s",b[i]+1);
	for(int i=1;i<=n;++i){
		!scanf("%s",c[i]+1);
		for(int j=1;j<=m;++j)
			if(c[i][j]=='z')
				c[i][j]=74;
			else
				c[i][j]=c[i][j]-'0';
	}
	s=id(n,m,1)+1;t=s+1;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j){
			if(a[i][j]=='1'&&b[i][j]=='1')
				a[i][j]=b[i][j]='0';
			if(a[i][j]=='1'){
				++cnta;
				if(c[i][j])
					ae(s,id(i,j,1),1,0),--c[i][j];
				else{
					puts("-1");
					return 0;
				}
			}
			if(b[i][j]=='1'){
				++cntb;
				if(c[i][j])
					ae(id(i,j,0),t,1,0),--c[i][j];
				else{
					puts("-1");
					return 0;
				}
			}
		}
	if(cnta!=cntb){
		puts("-1");
		return 0;
	}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j){
			for(int d=0,x,y;d<8;++d)
				if(x=i+dx[d],y=j+dy[d],x>0&&x<=n&&y>0&&y<=m)
					ae(id(i,j,1),id(x,y,0),inf,1);
			ae(id(i,j,0),id(i,j,1),c[i][j]/2,0);
		}
	while(true){
		int tmp=spfa();
		if(tmp)
			res+=tmp;
		else
			break;
	}
	if(res!=cnta)
		puts("-1");
	else
		printf("%d\n",ans);
	return 0;
}
