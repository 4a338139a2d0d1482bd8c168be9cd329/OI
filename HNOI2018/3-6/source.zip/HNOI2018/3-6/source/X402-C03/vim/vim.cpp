#include<bits/stdc++.h>
using namespace std;

const int maxn=7e4+10;
const int maxm=5e3+10;
int n,res,fp[maxn][9],ans=1e9,nxt[maxn];
char s[maxn];
vector<int> vec;
int dp[maxm][maxm];

inline int chkmin(int&a,int b){if(a>b)a=b;}

int main(){
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);
	scanf("%*d%s",s);
	for(int i=0;s[i];++i){
		if(s[i]=='e'){
			while(s[i]=='e')
				res+=2,++i;
			vec.push_back(n);
		}
		s[n++]=s[i];
	}
	if(!res){
		printf("%d\n",res);
		return 0;
	}
	for(int i=0;i<n;++i)
		if(s[i]<'e')
			s[i]-='a';
		else
			s[i]-='a'+1;
	for(int i=0;i<9;++i)
		for(int last=-1,j=n-1;~j;--j){
			fp[j][i]=last;
			if(s[j]==i)
				last=j;
		}
	for(int i=0;i<n;++i)
		nxt[i]=upper_bound(vec.begin(),vec.end(),i)-vec.begin();
	for(int i=0;i<n;++i)
		dp[vec.size()][i]=res;
	for(int i=vec.size()-1;~i;--i)
		for(int j=n-1;~j;--j){
			dp[i][j]=1e9;
			for(int k=0;k<9;++k)
				if(~fp[j][k])
					chkmin(dp[i][j],dp[i][fp[j][k]]+2);
			if(nxt[j]>i)
				chkmin(dp[i][j],dp[nxt[j]][vec[i]]+j-vec[i]);
		}
	printf("%d\n",dp[0][0]);
	return 0;
}
