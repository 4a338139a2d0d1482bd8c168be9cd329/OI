#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

int S, T;
namespace cost_flow {
    const int N = 400 << 2;
    const int M = 400 << 6;

    struct edge { 
        int to, nxt, cap, cost; 
    };

    edge e[M + 5];
    int st[N + 5], ecnt = 1;

    inline void addedge(int u, int v, int c, int w) {
        e[++ ecnt] = (edge) { v, st[u], c, w }; st[u] = ecnt;
        e[++ ecnt] = (edge) { u, st[v], 0,-w }; st[v] = ecnt;
    }

    bool inq[N + 5];
    int dis[N + 5], pre[N + 5], cap[N + 5];

    bool spfa() {
        std::queue<int> q; 
        memset(dis, oo, sizeof dis);

        q.push(S);
        dis[S] = 0;
        cap[S] = oo;

        while(!q.empty()) {
            int x = q.front(); q.pop();

            inq[x] = false;
            for(int i = st[x]; i; i = e[i].nxt) {
                int y = e[i].to;
                if(e[i].cap && chkmin(dis[y], dis[x] + e[i].cost)) {

                    cap[y] = std::min(cap[x], e[i].cap);
                    pre[y] = i;

                    if(!inq[y]) {
                        inq[y] = true;
                        q.push(y);
                    }
                }
            }
        }

        return dis[T] < oo;
    }

    pii mcmf() {
        int ans = 0, flow = 0;
        while(spfa()) {
            flow += cap[T];
            ans += cap[T] * dis[T];
            for(int i = T; i != S; i = e[pre[i]^1].to) {
                e[pre[i]].cap -= cap[T];
                e[pre[i]^1].cap += cap[T];
            }
        }
        return mp(flow, ans);
    }
}

const int N = 20;

const int dx[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
const int dy[] = { -1, 0, 1, -1, 1, -1, 0, 1 };

int n, m;
char grid[N + 5];
int val[N + 5][N + 5];

inline int idx(int x, int y, bool d) {
    return x * m + y + (n * m * d);
}

int main() {
    freopen("pipes.in", "r", stdin);
    freopen("pipes.out", "w", stdout);

    read(n), read(m);
    S = 2 * n * m, T = S + 1;

    int tot = 0;
    for(int i = 0; i < n; ++i) {
        scanf("%s", grid);
        for(int j = 0; j < m; ++j) if(grid[j] == '1') {
            ++ tot;
            ++ val[i][j]; cost_flow::addedge(S, idx(i, j, 0), 1, 0);
        }
    }

    int tot1 = 0;
    for(int i = 0; i < n; ++i) {
        scanf("%s", grid);
        for(int j = 0; j < m; ++j) if(grid[j] == '1') {
            ++ tot1;
            ++ val[i][j]; cost_flow::addedge(idx(i, j, 1), T, 1, 0);
        }
    }

    if(tot1 != tot) {
        puts("-1");
        return 0;
    }

    for(int i = 0; i < n; ++i) {
        scanf("%s", grid);
        for(int j = 0; j < m; ++j) {
            int c = grid[j] == 'z' ? 74 : grid[j] - '0';
            cost_flow::addedge(idx(i, j, 0), idx(i, j, 1), (val[i][j]+c) >> 1, 0);

            for(int d = 0; d < 8; ++ d) {
                int ni = i + dx[d], nj = j + dy[d];
                
                if(ni >= 0 && ni < n && nj >= 0 && nj < m) {
                    cost_flow::addedge(idx(i, j, 1), idx(ni, nj, 0), oo, 1);
                }
            }
        }
    }
    
    pii ans = cost_flow::mcmf();
    printf("%d\n", ans.fst == tot ? ans.snd : -1);

    return 0;
}
