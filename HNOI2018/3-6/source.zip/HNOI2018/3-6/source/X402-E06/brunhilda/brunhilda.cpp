#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 10000000;

bool usable[N + 5];
bool notprime[N + 5];

int prime[N / 10 + 5], pcnt;
int mxpri[N + 5], res[N + 5];

void sieve() {
    for(int i = 2; i <= N; ++i) {
        if(!notprime[i]) {
            prime[pcnt ++] = i;
            mxpri[i] = usable[i] ? i : 0;
        }

        static ll x;
        for(int j = 0; j < pcnt && (x = 1ll * i * prime[j]) <= N; ++j) {
            notprime[x] = true;
            mxpri[x] = std::max(mxpri[i], mxpri[prime[j]]);

            if(i % prime[j] == 0) break;
        }
    }
}

int m, p, q, mxp;

int main() {
    freopen("brunhilda.in", "r", stdin);
    freopen("brunhilda.out", "w", stdout);

    read(m), read(q);
    for(int i = 1; i <= m; ++i) usable[read(p)] = true, chkmax(mxp, p);

    sieve();

    int l = 1, r = mxp - 1, nxt;
    for(int cur = 1; ; ++ cur) {

        nxt = 0;
        for(int i = l; i <= r && i <= N; ++i) {
            res[i] = cur;
            chkmax(nxt, i + mxpri[i] - 1);
        }

        if(nxt <= r || r >= N) break;
        l = r + 1, r = nxt;
    }

    for(int i = r+1; i <= N; ++i) res[i] = oo;

    for(int i = 1; i <= q; ++i) {
        read(p);

        if(res[p] == oo) 
            printf("oo\n");
        else 
            printf("%d\n", res[p]);
    }

    // std::cout << procStatus() << std::endl;
    return 0;
}
