#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 70000;
const int S = 1 << 10;

int n;
char st[N + 5];
int dp[N + 5][S + 5];

int main() {
    freopen("vim.in", "r", stdin);
    freopen("vim.out", "w", stdout);

    read(n);
    scanf("%s", st + 1);

    bool flag = false;
    for(int i = 1; i <= n; ++i) if(st[i] == 'e') {
        flag = true; break;
    }
    if(!flag) { puts("0"); return 0; }

    memset(dp, oo, sizeof dp);
    dp[1][0] = 0;

    int all = S - 1;
    for(int i = 1; i <= n; ++i) {

        flag = false;
        int vis = 0, cost = 2, lst = 0, temp = 0;

        for(int j = 0; j < 10; ++j) 
            for(int k = 0; k < S; ++k) if(k >> j & 1) {
                chkmin(dp[i][k], dp[i][k ^ (1 << j)]);
            }

        for(int j = i+1; j <= n; ++j) {
            if(st[j] == 'e') {
                cost += 1; 
                if(lst) cost += j - lst;
                lst = j; 
            } else {

                if(lst) {
                    if(flag) {
                        temp |= 1 << (st[j]-'a');
                    } else {
                        flag = true;
                    }
                }

                if(!(vis >> (st[j]-'a') & 1)) 
                    chkmin(dp[j][temp], dp[i][all^(1<<(st[j]-'a'))] + cost + (lst ? (j - lst) : 0));
                vis |= 1 << (st[j]-'a');
            }
        }
    }

    int ans = oo;
    for(int i = n; i >= 1; --i) {
        if(st[i] == 'e') break;
        chkmin(ans, dp[i][all]);
    }
    printf("%d\n", ans);

    // std::cout << procStatus() << std::endl;

    return 0;
}
