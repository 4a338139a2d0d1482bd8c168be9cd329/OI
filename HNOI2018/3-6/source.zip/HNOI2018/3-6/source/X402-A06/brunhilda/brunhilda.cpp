#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read (){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();
	
	return sum * fg;
}

const int maxn = 100010;

int m, q, a[maxn], ans[maxn], Max, b[maxn], Maxx;

void Get() {
	m = read(), q = read();
	For(i, 1, m){
		a[i] = read();
		Max = max(Max, a[i]);
	}
	For(i, 1, q){
		b[i] = read();
		Maxx = max(Maxx, b[i]);
	}
}

void pre_work() {
	For(i, 1, Maxx) ans[i] = inf;
	For(i, 1, Max - 1) ans[i] = 1;
	For(i, Max, Maxx) {
		For(j, 1, m) {
			ans[i] = min(ans[i], ans[i-(i%a[j])] + 1);
		}
	}
}

void solve_bf() {
	pre_work();
	For(i, 1, q) {
		if(ans[b[i]] == inf) printf("oo\n");
		else printf("%d\n", ans[b[i]]);
	}
}

int main (){
	
	freopen("brunhilda.in", "r", stdin);
	freopen("brunhilda.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
