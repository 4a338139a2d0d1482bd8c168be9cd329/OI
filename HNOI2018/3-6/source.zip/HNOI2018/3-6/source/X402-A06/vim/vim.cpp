#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read (){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int maxm = 10;

int Last[maxn], sum[maxn][maxm + 10], cnt, Next[maxn][maxm + 10], n, a[maxn], sume[maxn];

char s[maxn];

int pos[maxn], dp[5010][5010];

void Get() {
	n = read();
	scanf("%s", s+1);
	For(i, 1, n) a[i] = s[i] - 'a' + 1;
}

void pre_work() {
	For(i, 1, maxm) Last[i] = inf;
	rep(i, n, 1) {
		For(j, 1, maxm) Next[i][j] = Last[j];
		Last[a[i]] = i;
	}

	For(i, 1, n) {
		sume[i] = sume[i-1];
		if(s[i] == 'e') pos[++ sume[i]] = i;

		For(j, 1, maxm) sum[i][j] = sum[i-1][j];
		++ sum[i][a[i]];
	}
}

void solve_bf() {
	pre_work();
	if(sume[n] == 0) {
		puts("0");
		return ;
	}

	For(i, 0, sume[n]) {
		For(j, 0, sume[n]) {
			dp[i][j] = inf;
		}
	}

	int Max = n * 2 + n;

	dp[0][0] = 0;
	pos[0] = 1;

	For(i, 0, sume[n]) {
		For(j, 0, i) {
			if(dp[i][j] >= Max) continue;

			For(k, 1, maxm) {
				if(k == 5) continue;
				for(int o = Next[pos[i]][k], ls; o != inf; o = Next[o][k]) {
					if( (ls = (sume[o] - sume[pos[i]]) ) == 0) continue;

					int ans = (sum[o][k] - sum[pos[j]][k]) * 2;
					ans += ls + o - pos[i+1];
					
					dp[sume[o]][i+1] = min(dp[sume[o]][i+1], dp[i][j] + ans);
				}
			}
		}
	}

	int Ans = inf;
	For(i, 0, sume[n]) Ans = min(Ans, dp[sume[n]][i]);
	printf("%d\n", Ans);
}

int f[maxn][maxm + 10];

void solve_try() {
	pre_work();
	if(sume[n] == 0) {
		puts("0");
		return ;
	}

	For(i, 0, sume[n]) {
		For(j, 0, maxm) {
			f[i][j] = inf;
		}
	}

	pos[0] = 1;
	For(i, 1, maxm) {
		if(i == 5) continue;
		f[0][i] = -2 * sum[pos[0]][i];
	}

	For(i, 2, n) {
		if(s[i] != 'e') {
			int j = a[i];
			For(k, 0, sume[i] - 1) {
				int ans = 0;
				ans += sume[i] - sume[pos[k]];
				ans += i - pos[k+1]; ans += sum[i][j] * 2;
				For(o, 1, maxm) {
					if(o == 5) continue;
					if(sume[i] != sume[n]) f[sume[i]][o] = min(f[sume[i]][o], f[k][j] + ans - 2 * sum[pos[k+1]][o]);
					else f[sume[i]][o] = min(f[sume[i]][o], f[k][j] + ans);
				}
			}
		}
	}
	
	int Ans = inf;
	For(i, 1, maxm) {
		if(i == 5) continue;
		Ans = min(Ans, f[sume[n]][i]);
	}

	printf("%d\n", Ans);
}

int main() {

	freopen("vim.in", "r", stdin);
	freopen("vim.out", "w", stdout);

	Get();
	solve_try();

	return 0;
}
