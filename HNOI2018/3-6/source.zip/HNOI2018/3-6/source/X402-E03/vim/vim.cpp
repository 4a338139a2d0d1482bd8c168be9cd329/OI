#include <bits/stdc++.h>
using namespace std ;
const int maxn = 5005, inf = 0x3f3f3f3f ;
int n, m, dis[maxn][maxn], f[maxn][maxn] ;
int Last[maxn][10] ;
int pos[maxn], sz ;
void chkmin ( int &a, int b ) { a = a<b? a:b ; }
char s[maxn] ;
int main() {
	freopen ( "vim.in", "r", stdin ) ;
	freopen ( "vim.out", "w", stdout ) ;

	cin >> n ;
	int i, j, k ;
	scanf ( "%s", s+1 ) ;
	for ( i = 1 ; i <= n ; i ++ )
		if (s[i] == 'e') pos[++sz] = i ;
	if (!sz) {
		puts("0") ;
		return 0 ;
	}
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= n ; j ++ )
			if (i ^ j) dis[i][j] = inf ;
			else dis[i][j] = 0 ;
	for ( i = 1 ; i ^ n ; i ++ )
		chkmin(dis[i + 1][i], 1) ;
	for ( i = n ; i ; i -- ) {
		for ( j = 0 ; j < 10 ; j ++ ) {
			Last[i][j] = Last[i + 1][j] ;
			if (Last[i][j] && j != 4) chkmin(dis[i][Last[i][j]], 2) ;
		}
		Last[i][s[i] - 'a'] = i ;
	}
	for ( k = 1 ; k <= n ; k ++ )
		for ( i = 1 ; i <= n ; i ++ )
			for ( j = 1 ; j <= n ; j ++ )
				chkmin(dis[i][j], dis[i][k] + dis[k][j]) ;
	/*for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= n ; j ++ )
			if (dis[i][j] ^ inf)
			printf ( "dis[%d][%d]=%d\n", i, j, dis[i][j] ) ;*/
	for ( i = 0 ; i <= sz ; i ++ )
		for ( j = 0 ; j <= n ; j ++ )
			f[i][j] = inf ;
	f[0][1] = 0 ;
	for ( i = 1 ; i <= sz ; i ++ )
		for ( j = 0 ; j < i ; j ++ )
			for ( k = 1 ; k <= n ; k ++ )
				if (f[j][k] != inf) {
					chkmin(f[i][pos[j+1]+1], f[j][k] + dis[k][pos[i]] + min(pos[i]-pos[j+1], dis[pos[i]+1][pos[j+1]]) + i - j) ;
					//printf ( "[%d][%d]->[%d][%d]=%d\n", j, k, i, pos[j+1]+1, f[i][pos[j+1]+1] ) ;
				}
	/*for ( i = 0 ; i <= sz ; i ++ )
		for ( k = 1 ; k <= n ; k ++ )
			if (f[i][k] != inf)
				printf ( "f[%d][%d]=%d\n", i, k, f[i][k] ) ;*/
	int ans = inf ;
	for ( i = 1 ; i <= n ; i ++ )
		chkmin(ans, f[sz][i]) ;
	cout << ans << endl ;
	//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
