#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 25 ;
int n, m ;
const int go[8][2] = {{1, 0}, {0, 1}, {0, -1}, {-1, 0}, {1, 1}, {-1, -1}, {1, -1}, {1, -1}} ;
struct node {
	int x, y ;
	friend bool operator < ( node A, node B ) {
		if (A.x ^ B.x) return A.x < B.x ;
		return A.y < B.y ;
	}
} ;
struct Graph {
	int g[4][4], sz ;
	bool vis[4][4] ;
	node ND[10] ;
	void print() {
		for ( int i = 0 ; i < sz ; i ++ )
			printf ( "(%d,%d)\n", ND[i].x, ND[i].y ) ;
		for ( int i = 0 ; i < n ; i ++, puts("") )
			for ( int j = 0 ; j ^ m ; j ++ )
				printf ( "%d", vis[i][j] ) ;
	}
	friend bool operator == ( Graph A, Graph B ) {
		for ( int i = 0 ; i ^ n ; i ++ )
			for ( int j = 0 ; j ^ m ; j ++ )
				if (A.g[i][j]!=B.g[i][j] || A.vis[i][j] != B.vis[i][j])
					return 0 ;
		return 1 ;
	}
	friend bool operator < ( Graph A, Graph B ) {
		for ( int i = 0 ; i ^ n ; i ++ )
			for ( int j = 0 ; j ^ m ; j ++ ) {
				if (A.g[i][j]^B.g[i][j]) return A.g[i][j] < B.g[i][j] ;
				if (A.vis[i][j]^B.vis[i][j]) return A.vis[i][j] < B.vis[i][j] ;
			}
		return 0 ;
	}
} S, T ;
bool same ( Graph A, Graph B ) {
	for ( int i = 0 ; i ^ n ; i ++ )
		for ( int j = 0 ; j ^ m ; j ++ )
			if (A.vis[i][j]^B.vis[i][j]) return 0 ;
	return 1 ;
}
bool judge ( int u, int v ) {
	if (u < 0 || v < 0 || u >= n || v >= m) return 0 ;
	return 1 ;
}
vector <int> A ;
char s[maxn] ;
queue <Graph> Q ;
map <Graph, int> dis ;
void BFS() {
	Q.push(S) ;
	Graph X, U ;
	dis[S] = 0 ;
	int i, u, v, j, x, y, t ;
	while (!Q.empty()) {
		X = Q.front() ;
		sort(X.ND, X.ND+X.sz) ;
		Q.pop() ;
		t = dis[X] ;
		if (same(X, T)) {
			printf ( "%d\n", dis[X] ) ;
			return ;
		}
		for ( i = 0 ; i ^ X.sz ; i ++ ) {
			x = X.ND[i].x, y = X.ND[i].y ;
			if (X.g[x][y] > 0)
			for ( j = 0 ; j ^ 8 ; j ++ ) {
				u = x+go[j][0] ;
				v = y+go[j][1] ;
				if (judge(u, v) && !X.vis[u][v] && X.g[u][v] > 0) {
					U = X ;
					U.vis[x][y] = 0, U.vis[u][v] = 1 ;
					U.ND[i] = (node){u, v} ;
					--U.g[x][y], --U.g[u][v] ;
					sort(U.ND, U.ND+U.sz) ;
					if (!dis.count(U)) {
						dis[U] = t+1 ;
						Q.push(U) ;
					}
				}
			}
		}
	}
	puts("-1") ;
}
int g[maxn][maxn] ;
void solve1() {
	int i, j, x, y, u, v ;
	node S, T, X, U ;
	map <node, int> dis ;
	dis.clear() ;
	queue <node> Q ;
	for ( i = 0 ; i ^ n ; i ++ ) {
		scanf ( "%s", s ) ;
		for ( j = 0 ; j ^ m ; j ++ )
			if (s[j] == '1') S = (node){i, j} ;
	}
	for ( i = 0 ; i ^ n ; i ++ ) {
		scanf ( "%s", s ) ;
		for ( j = 0 ; j ^ m ; j ++ )
			if (s[j] == '1') T = (node){i, j} ;
	}
	for ( i = 0 ; i ^ n ; i ++ ) {
		scanf ( "%s", s ) ;
		for ( j = 0 ; j ^ m ; j ++ )
			if (s[j] == 'z') g[i][j] = 72 ;
			else g[i][j] = s[j]-'0' ;
	}
	Q.push(S) ;
	dis[S] = 0 ;
	while (!Q.empty()) {
		X = Q.front() ;
		Q.pop() ;
		x = X.x, y = X.y ;
		if (x == T.x && y == T.y) {
			printf ( "%d\n", dis[X] ) ;
			return ;
		}
		for ( i = 0 ; i < 8 ; i ++ ) {
			u = x+go[i][0], v = y+go[i][1] ;
			U = (node){u, v} ;
			if (judge(u, v) && g[u][v] && !dis.count(U)) {
				if (g[u][v] < 2 && (u != T.x && v != T.y) ) continue ;
				dis[U] = dis[X]+1 ;
				Q.push(U) ;
			}
		}
	}
	puts("-1") ;
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "pipes.in", "r", stdin ) ;
	freopen ( "pipes.out", "w", stdout ) ;
#endif
	int i, j ;
	Read(n), Read(m) ;
	if (n <= 3 && m <= 3) {
		for ( i = 0 ; i ^ n ; i ++ ) {
			scanf ( "%s", s ) ;
			for ( j = 0 ; j ^ m ; j ++ )
				if (s[j] == '1') {
					S.ND[S.sz++] = (node){i, j} ;
					S.vis[i][j] = 1 ;
				}
		}
		for ( i = 0 ; i ^ n ; i ++ ) {
			scanf ( "%s", s ) ;
			for ( j = 0 ; j ^ m ; j ++ )
				if (s[j] == '1') {
					T.ND[T.sz++] = (node){i, j} ;
					T.vis[i][j] = 1 ;
				}
		}
		for ( i = 0 ; i ^ n ; i ++ ) {
			scanf ( "%s", s ) ;
			for ( j = 0 ; j ^ m ; j ++ )
				if (s[j] == 'z') S.g[i][j] = 74 ;
				else S.g[i][j] = s[j]-'0' ;
		}
		BFS() ;
	} else solve1() ;
	return 0 ;
}
