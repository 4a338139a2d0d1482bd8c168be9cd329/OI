#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1e4+5, inf = 0x3f3f3f3f ;
int n, m, p[maxn], f[maxn] ;
void chkmin ( int &a, int b ) { a = a<b? a:b ; }
int main() {
	freopen ( "brunhilda.in", "r", stdin ) ;
	freopen ( "brunhilda.out", "w", stdout ) ;
	int i, j, _ ;
	memset (f, inf, sizeof f) ;
	Read(m), Read(_) ;
	for ( i = 1 ; i <= m ; i ++ ) Read(p[i]), n = max(n, p[i]) ;
	n = min(n, 10001) ;
	for ( i = 1 ; i ^ n ; i ++ )
		f[i] = 1 ;
	for ( i = n ; i <= 1e4 ; i ++ )
		for ( j = 1 ; j <= m && f[i] > 1 ; j ++ )
			if (i%p[j]) chkmin(f[i], f[i-i%p[j]]+1) ;
	while (_--) {
		Read(n) ;
		if (f[n] ^ inf) printf ( "%d\n", f[n] ) ;
		else puts("oo") ;
	}
	return 0 ;
}
