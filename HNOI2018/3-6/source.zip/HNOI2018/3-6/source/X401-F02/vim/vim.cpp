#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);
	scanf("%s",str+1);
	int len=strlen(str+1);
	puts("0");
	return 0;
}
