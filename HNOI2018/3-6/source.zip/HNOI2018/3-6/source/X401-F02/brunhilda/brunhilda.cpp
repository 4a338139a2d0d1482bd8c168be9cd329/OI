#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
const int inf=1<<30;
#define maxn 10000010
#define maxm 100010

int m,Q,maxx;

int q[maxn],num[maxn],f[maxn],s[maxm],pri[maxm];

int main()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
	read(m),read(Q);
	for(int i=1;i<=m;i++)
		read(pri[i]);
	for(int i=1;i<=Q;i++)
		read(s[i]),maxx=max(maxx,s[i]);
	for(int i=1;i<=maxx;i++) f[i]=num[i]=inf;
	for(int i=1;i<=m;i++)
		for(int j=pri[i];j<=maxx;j+=pri[i]) 
			num[j]=pri[i];
	int l=1,r=2,st=1;q[1]=0;f[0]=0;num[0]=pri[m];
	while(l<r&&st<=maxx){
		int x=q[l];l++;
		if(num[x]==inf) continue;
		int tmp=min(maxx,num[x]+x-1);
		for(;st<=tmp;st++) f[st]=f[x]+1,q[r++]=st;
	}
	for(int i=1;i<=Q;i++)
		f[s[i]]==inf?puts("oo"):printf("%d\n",f[s[i]]);
	return 0;
}
