#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005,inf=0x3f3f3f3f;
int nxt[maxn][10],nxtpos[maxn];
int pos[maxn],id[maxn],tot;
int n,dp[5005][5005],ans=inf;
char s[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);
#endif
	n=read(),scanf("%s",s+1);
	REP(i,1,n)if(s[i]=='e')pos[++tot]=i,id[i]=tot;
	if(!tot)return puts("0"),0;
	DREP(i,n-1,1){
		memcpy(nxt[i],nxt[i+1],sizeof(nxt[i]));
		nxt[i][s[i+1]-'a']=i+1;
	}
	memset(dp,inf,sizeof(dp));
	dp[1][0]=0;
	REP(i,1,tot){
		int j=i;
		while(pos[j+1]-pos[j]==1)++j;
		REP(k,i,j)nxtpos[pos[k]]=pos[j]+1;
		i=j;
	}
	REP(j,0,tot-1)
		REP(i,1,n)
			if(dp[i][j]<inf){
				int p=pos[j+1];
				if(i>=p){
					int t=upper_bound(pos+1,pos+1+tot,i)-pos-1;
					chkmin(dp[nxtpos[p]][t],dp[i][j]+i-p+t-j);
				}
				REP(k,0,9){
					if((k==4)||(!nxt[i][k]))continue;
					chkmin(dp[nxt[i][k]][j],dp[i][j]+2);
				}
			}
	REP(i,1,n)chkmin(ans,dp[i][tot]);
	write(ans,'\n');
	return 0;
}
