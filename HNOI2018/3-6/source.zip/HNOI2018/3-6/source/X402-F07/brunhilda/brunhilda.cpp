#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=10000005,inf=0x3f3f3f3f;
int n,m,q_cnt;
int Maxp[maxn],prime[maxn/10],tot;
bool isprime[maxn],vis[maxn];
int ans[maxn];
void init(){
	memset(isprime,1,sizeof(isprime));
	REP(i,2,n){
		if(isprime[i]){
			prime[++tot]=i;
			if(vis[i])Maxp[i]=i,Maxp[0]=i;
		}
		REP(j,1,tot){
			if(i*prime[j]>n)break;
			isprime[i*prime[j]]=0;
			Maxp[i*prime[j]]=max(Maxp[i],Maxp[prime[j]]);
			if(i%prime[j]==0)break;
		}
	}
}
int c[maxn];
void update(int x,int val){
	if(x<=0)x=1;
	while(x<=n)chkmin(c[x],val),x+=x&-x;
}
int query(int x){
	int res=inf;
	while(x)chkmin(res,c[x]),x-=x&-x;
	return res;
}
void solve(){
	memset(c,inf,sizeof(c));
	memset(ans,inf,sizeof(ans));
	ans[0]=0,update(n-Maxp[0]+2,0);
	REP(i,1,n){
		ans[i]=query(n-i+1)+1;
		if(!Maxp[i])continue;
		update(n-i-Maxp[i]+2,ans[i]);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
#endif
	n=10000000;
	m=read(),q_cnt=read();
	REP(i,1,m)vis[read()]=1;
	init();
	solve();
	REP(i,1,q_cnt){
		int x=read();
		if(ans[x]<inf)write(ans[x],'\n');
		else puts("oo");
	}
	return 0;
}
