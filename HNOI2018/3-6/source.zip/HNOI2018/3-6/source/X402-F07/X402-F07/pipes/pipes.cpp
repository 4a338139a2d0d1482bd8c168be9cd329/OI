#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=805,maxm=maxn*100,inf=0x3f3f3f3f,dir[8][2]={{0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,-1},{1,-1},{-1,1}};
int n,m,S,T;
int Begin[maxn],Next[maxm],to[maxm],flow[maxm],cost[maxm],e=1;
char A[25][25],B[25][25],C[25][25];
void add_edge(int u,int v,int w,int f){
	to[++e]=v,Next[e]=Begin[u],Begin[u]=e,flow[e]=f,cost[e]=w;
	to[++e]=u,Next[e]=Begin[v],Begin[v]=e,flow[e]=0,cost[e]=-w;
}
int id(int x,int y,int t){
	return t*n*m+(x-1)*m+y;
}
int spfa(){
	static queue<int>Q;
	static bool vis[maxn];
	static int dis[maxn],pre[maxn];
	memset(dis,inf,sizeof(dis));
	memset(vis,0,sizeof(vis));
	dis[S]=0,Q.push(S);
	while(!Q.empty()){
		int u=Q.front();
		Q.pop(),vis[u]=0;
		for(int i=Begin[u];i;i=Next[i]){
			if(!flow[i])continue;
			int v=to[i];
			if(chkmin(dis[v],dis[u]+cost[i])){
				pre[v]=i;
				if(!vis[v])Q.push(v),vis[v]=1;
			}
		}
	}
	if(dis[T]==inf)return inf;
	int v=T,u;
	while(u=to[pre[v]^1]){
		flow[pre[v]]--;
		flow[pre[v]^1]++;
		v=u;
	}
	return dis[T];
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);
#endif
	n=read(),m=read();
	S=2*n*m+1,T=S+1;
	REP(i,1,n)scanf("%s",A[i]+1);
	REP(i,1,n)scanf("%s",B[i]+1);
	REP(i,1,n)scanf("%s",C[i]+1);
	REP(i,1,n)
		REP(j,1,m)
			REP(k,0,7){
				int x=i+dir[k][0],y=j+dir[k][1];
				if((x<1)||(y<1)||(x>n)||(y>m))continue;
				add_edge(id(i,j,1),id(x,y,0),1,inf);
			}
	REP(i,1,n)REP(j,1,m)if((A[i][j]=='1')&&(B[i][j]=='1'))A[i][j]=B[i][j]='0';
	REP(i,1,n)REP(j,1,m)if(A[i][j]=='1')add_edge(S,id(i,j,0),0,1);
	REP(i,1,n)REP(j,1,m)if(B[i][j]=='1')add_edge(id(i,j,1),T,0,1);
	REP(i,1,n)REP(j,1,m)add_edge(id(i,j,0),id(i,j,1),0,C[i][j]-'0');
	int res,ans=0;
	while((res=spfa())!=inf)ans+=res;
	for(int i=Begin[S];i;i=Next[i])if(flow[i])return puts("-1"),0;
	for(int i=Begin[T];i;i=Next[i])if(!flow[i])return puts("-1"),0;
	write(ans,'\n');
	return 0;
}
