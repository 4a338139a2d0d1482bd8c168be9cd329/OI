#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=5050;
const int inf=0x3f3f3f3f;
char in[N];
int nex[N][11],n,s[N],f[N][N],dis[N][N];
int head[N],cnt=0;
struct node
{
	int to,next,w;
}e[N*10+N];
inline void add_edge(int x,int y,int w)
{
	e[++cnt]=(node){y,head[x],w};head[x]=cnt;
}
queue<int>q[N*2];
bool vis[N];
void dijkstra(int s)
{
	for(int i=1;i<=n;++i) vis[i]=0;
	q[0].push(s); dis[s][s]=0;
	for(int j=0;j<=n*2;++j)
	{
		while(!q[j].empty())
		{
			int u=q[j].front(); q[j].pop();
			if(vis[u]) continue;
			vis[u]=1;
			for(int i=head[u];i;i=e[i].next)
			{
				int v=e[i].to;
				if(dis[s][v]>dis[s][u]+e[i].w)
				{
					dis[s][v]=dis[s][u]+e[i].w;
					q[dis[s][v]].push(v);
				}
			}
		}
	}
}

int ve[N],tote=0;
void wj()
{
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);
}
int main()
{
	wj();
	int ans=0,nn=0;
	n=read();
	if(n>5000) {puts("0");return 0;}
	scanf("%s",in+1);
	for(int i=1;i<=n;++i)
	{
		int num=1;
		while(in[i]==in[i+1]&&in[i]=='e') i++,num++;
		s[++nn]=in[i]-'a'; ans+=2*(num-1);
	}
	n=nn;
	for(int i=1;i<=n;++i) if(s[i]==4) ve[++tote]=i;

	for(int i=n;i;--i)
	{
		for(int j=0;j<10;++j) nex[i][j]=nex[i+1][j];
		if(i!=n) nex[i][s[i+1]]=i+1;
	}

	//the dis(x,y) means y to x.
	for(int i=1;i<=n;++i) for(int j=0;j<10;++j) if(nex[i][j]&&j!=4)
		add_edge(nex[i][j],i,2);
	for(int i=2;i<=n;++i) add_edge(i-1,i,1);
	memset(dis,inf,sizeof(dis));
	for(int i=1;i<=n;++i) if(s[i-1]==4) dijkstra(i);

	memset(f,inf,sizeof(f));
	f[0][1]=0;
	for(int i=0;i<tote;++i) for(int j=1;j<=n;++j) if(f[i][j]!=inf)
	{
		for(int k=i+1;k<=tote;++k) 
			f[k][ve[i+1]+1]=min(f[k][ve[i+1]+1]
			,f[i][j]+dis[ve[k]+1][j]+ve[k]+1-ve[i+1]+k-i);
	}
	int minn=inf;
	for(int i=1;i<=n;++i) minn=min(minn,f[tote][i]);
	printf("%d\n",minn+ans);
	return 0;
}
