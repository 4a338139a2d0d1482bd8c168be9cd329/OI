#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=25;
const int inf=0x3f3f3f3f;
int move1[8]={1,0,-1,0,1,1,-1,-1},move2[8]={0,1,0,-1,1,-1,1,-1};
int id[N][N],n,m,S,T,tot=0;
int head[N*N*2],cnt=1;
struct node
{
	int to,next,flow,w;
}e[N*N*11*2];
inline void add(int x,int y,int flow,int w)
{
	e[++cnt]=(node){y,head[x],flow,w};head[x]=cnt;
	e[++cnt]=(node){x,head[y],0,-w};head[y]=cnt;
}
int maxflow=0,mincost=0;

queue<int>q;
int dis[N*N*2],pre[N*N*2],pree[N*N*2];
bool vis[N*N*2];
bool spfa()
{
	while(!q.empty()) q.pop();
	for(int i=1;i<=T;++i) dis[i]=inf,pree[i]=pre[i]=0;
	q.push(S); dis[S]=0;
	while(!q.empty())
	{
		int u=q.front(); q.pop();
		vis[u]=0;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(dis[v]>dis[u]+e[i].w&&e[i].flow>0)
			{
				dis[v]=dis[u]+e[i].w;
				pre[v]=u; pree[v]=i;
				if(!vis[v]) vis[v]=1,q.push(v);
			}
		}
	}
	if(dis[T]==inf) return 0;
	mincost+=dis[T];
	int minn=inf,u=T;
	while(u!=S)
	{
		minn=min(minn,e[pree[u]].flow);
		u=pre[u];
	}
	maxflow+=minn;
	u=T;
	while(u!=S)
	{
		e[pree[u]].flow-=minn;
		e[pree[u]^1].flow+=minn;
		u=pre[u];
	}
	return 1;
}

char s1[N][N],s2[N][N],lim[N][N];
void wj()
{
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=1;i<=n;++i) scanf("%s",s1[i]+1);
	for(int i=1;i<=n;++i) scanf("%s",s2[i]+1);
	for(int i=1;i<=n;++i) scanf("%s",lim[i]+1);
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) id[i][j]=++tot;

	S=tot*2+1; T=tot*2+2;
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) 
	{
		int f;
		if(lim[i][j]=='z') f=74;
		else f=lim[i][j]-'0';
		add(id[i][j]*2-1,id[i][j]*2,f,0);
	}

	int num1=0,num2=0;
	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j)
	{
		if(s1[i][j]=='1') add(S,id[i][j]*2-1,1,0),num1++;
		if(s2[i][j]=='1') add(id[i][j]*2,T,1,0),num2++;
	}
	if(num1!=num2) {puts("-1");return 0;}

	for(int i=1;i<=n;++i) for(int j=1;j<=m;++j)
	{
		for(int k=0;k<8;++k)
		{
			int x=i+move1[k],y=j+move2[k];
			if(x<1||y<1||x>n||y>m) continue;
			add(id[i][j]*2,id[x][y]*2-1,inf,1);
		}
	}

	while(spfa()) ;
	if(maxflow!=num1) {puts("-1");return 0;}
	printf("%d\n",mincost);
	return 0;
}
