#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int M=10000050;
const int inf=0x3f3f3f3f;
int n,p[N];
int dis[M],ask[N];

void wj()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	n=read(); int Q=read();
	for(int i=1;i<=n;++i) p[i]=read();
	sort(p+1,p+1+n,greater<int>());
	ll mul=1;
	for(int i=1;i<=n;++i) 
	{
		mul*=p[i];
		if(mul>10000000) {n=i;break;}
	}
	int maxn=0;
	for(int i=1;i<=Q;++i) ask[i]=read(),maxn=max(maxn,ask[i]);

	dis[0]=0;
	for(int i=1;i<=maxn;++i) 
	{
		dis[i]=inf;
		for(int j=1;j<=n;++j) 
		{
			int x=dis[i-i%p[j]]+1;
			dis[i]=x<dis[i]?x:dis[i];
		}
	}
	for(int i=1;i<=Q;++i)
	{
		if(dis[ask[i]]==inf) {puts("oo");continue;} //ask[i]>=mul||
		printf("%d\n",dis[ask[i]]);
	}
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
