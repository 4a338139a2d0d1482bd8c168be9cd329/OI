#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int inf=0x3f3f3f3f;
int n,p[N],minn;
int stk[N];
void dfs(int x,int r)
{
	if(!x) 
	{
		minn=min(minn,r);
		//if(r==9) {for(int i=0;i<r;++i) cerr<<stk[i]<<' '; cerr<<endl;}
		return ;
	}
	if(r>=minn) return ;
	for(int i=1;i<=n;++i) if(x%p[i])
		stk[r]=p[i],dfs(x-x%p[i],r+1);
}

void wj()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
}
int main()
{
	wj();
	n=read(); int Q=read();
	for(int i=1;i<=n;++i) p[i]=read();
	sort(p+1,p+1+n,greater<int>());
	ll mul=1;
	for(int i=1;i<=n;++i) 
	{
		mul*=p[i];
		if(mul>10000000) break;
	}
	for(int cas=1;cas<=Q;++cas)
	{
		int x=read();
		if(x>=mul) {puts("oo");continue;}
		minn=inf;
		dfs(x,0);
		printf("%d\n",minn);
	}
	return 0;
}
