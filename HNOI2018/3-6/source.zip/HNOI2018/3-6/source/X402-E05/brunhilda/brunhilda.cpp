#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const int M=10000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
}
int m,Q,n,a[N],q[N];
int f[M];
int main()
{
	file();
	read(m),read(Q);
	For(i,1,m)read(a[i]);
	For(i,1,Q)read(q[i]),chkmax(n,q[i]);
	For(i,1,n)
	{
		f[i]=inf;
		For(j,1,m)chkmin(f[i],f[i-i%a[j]]+1);
	}
	For(i,1,Q)f[q[i]]==inf?puts("oo"):printf("%d\n",f[q[i]]);
	return 0;
}
