#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define id(x,y,f) ((x-1)*m+y+f*(n*m))
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int L=30;
const int N=1010;
const int M=1000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);
}
int n,m,cnta,cntb,ans;
char s[L][L];
int a[L][L],b[L][L],G[L][L];
int bgn[N],nxt[M],to[M],c[M],w[M],E=1;
int S,T,cnt;
int dir[8][2]={{1,0},{0,1},{-1,0},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
inline void ADD(int u,int v,int C,int W){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v,c[E]=C,w[E]=W;}
inline void add_edge(int u,int v,int c,int w){ADD(u,v,c,w),ADD(v,u,0,-w);}
struct Netflow
{
	int cur[N],dis[N],vis[N],S,T,n;
	inline void init(int s,int t,int cnt){S=s,T=t,n=cnt;}
	inline bool bfs()
	{
		memset(vis,0,n*sizeof(int));
		memset(dis,inf,n*sizeof(int));
		queue<int>q;
		q.push(S);vis[S]=1;dis[S]=0;
		while(!q.empty())
		{
			int u=q.front();q.pop();vis[u]=0;
			for(int v,i=bgn[u];i;i=nxt[i])
				if(c[i]&&chkmin(dis[v=to[i]],dis[u]+w[i]))
					if(!vis[v])q.push(v);
		}
		return dis[T]!=inf;
	}
	inline int dfs(int u,int flow)
	{
		if(u==T)return flow;
		int ret=flow;vis[u]=1;
		for(int v,i=bgn[u];i;i=nxt[i])
		if(c[i]&&!vis[v=to[i]]&&dis[v]==dis[u]+w[i])
		{
			int f=dfs(v,min(c[i],ret));
			c[i]-=f,c[i^1]+=f,ret-=f;
			if(!ret)return flow;
		}vis[u]=0;
		return flow-ret;
	}
	inline void Solve()
	{
		int ret1=0,ret2=0;
		while(bfs())
		{
			memcpy(cur,bgn,n*sizeof(int));
			int x=dfs(S,inf);
			ret1+=x,ret2+=x*dis[T];
		}
		if(ret1!=cnta)puts("-1");
		else printf("%d\n",ret2);
	}
}ZKW;
int main()
{
	int flag=0;
	file();
	read(n),read(m);
	For(i,1,n)scanf("%s",s[i]+1);
	For(i,1,n)For(j,1,m)a[i][j]=s[i][j]=='1';
	For(i,1,n)scanf("%s",s[i]+1);
	For(i,1,n)For(j,1,m)b[i][j]=s[i][j]=='1';
	For(i,1,n)scanf("%s",s[i]+1);
	For(i,1,n)For(j,1,m)G[i][j]=s[i][j]=='z'?74:s[i][j]-'0';
	cnt=n*m*2;
	S=++cnt,T=++cnt;
	ZKW.init(S,T,++cnt);
	For(i,1,n)For(j,1,m)
	{
		int cnt=abs(a[i][j]-b[i][j]);
		if(G[i][j]-cnt<0)flag=1;
		add_edge(id(i,j,1),id(i,j,0),(G[i][j]-cnt)/2,0);
		if(cnt)
		{
			if(a[i][j])add_edge(S,id(i,j,0),1,0),cnta++;
			if(b[i][j])add_edge(id(i,j,1),T,1,0),cntb++;
		}
		For(k,0,7)
		{
			int x=i+dir[k][0],y=j+dir[k][1];
			if(x<1||x>n||y<1||y>m)continue;
			add_edge(id(i,j,0),id(x,y,1),inf,1);
		}
	}
	if(flag||cnta!=cntb)puts("-1");
	else ZKW.Solve();
	return 0;
}
