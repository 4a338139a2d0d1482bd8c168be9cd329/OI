#include<bits/stdc++.h>
const int N=500+10;
using namespace std;

struct node{
	string a;
	int p,v;
};
queue<node> q;
char str[N];
int n,m;

int main(){
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n>1000) {puts("0"); return 0;}
	scanf("%s",str);	
	q.push((node){str,0,0});
	while(!q.empty()){
		struct node b=q.front(); q.pop();

		int flag=0;
		for(int i=0; i<6; ++i) if(b.a[i]=='e') flag=1;
		if(flag==0) {printf("%d\n",b.v); break;}
		
		struct node c=b; c.v=b.v+1;
		for(int i=c.p; i<6; ++i) c.a[i]=c.a[i+1];
		q.push(c);

		struct node e=b; e.v=e.v+1; 
		if(e.p){e.p--;q.push(e);}
		
		for(char j='a'; j<='j'; ++j){
			struct node d=b; d.v=b.v+1;
			for(int k=d.p+1; k<6; ++k){
				if(d.a[k]==j) {d.p=k; break;}
			}
			q.push(d);
		}
	}
}
