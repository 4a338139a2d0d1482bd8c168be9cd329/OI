#include<bits/stdc++.h>
const int N=500+10;
using namespace std;

char str[N];
int n,m;

int main(){
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n>1000) {puts("0"); return 0;}
	scanf("%s",str);	
}
