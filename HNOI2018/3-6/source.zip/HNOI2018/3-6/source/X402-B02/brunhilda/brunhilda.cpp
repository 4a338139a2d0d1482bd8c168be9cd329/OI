#include<bits/stdc++.h>
#define pb push_back
#define sz size
#define ll long long
using namespace std;
const int N=1e5+10;
const int E=1e7+10;
int pnt,n,m;
bool a[N+5];
int p[N+5];
int mx[E+5];
int r[E+5];
int dis[E+5];
int v=0;

namespace solver{
	inline bool cmp(int x,int y){
		return x>y?x:y;
	}
	inline int read(){
		char ch=getchar();
		int x=0;
		while(ch>'9'||ch<'0')ch=getchar();
		while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
		return x;
	}
	void solve(){
		n=read(); m=read();
		for(int i=1; i<=n; ++i) p[i]=read();
		int x=0;
		sort(p+1,p+n+1);
		for(int i=1; i<=n; ++i){
			if(p[i]==p[i-1]) continue;
			for(int j=p[i]; j<=10000000; j+=p[i]){
				if(j+p[i]<=10000000){
					mx[j]=p[i];
				}
			}
		}
		int nwmx=p[n];
		for(int i=1; i<=10000000; ++i){
			--nwmx;
			r[i]=i+nwmx;
			if(mx[i]+i<=10000000)
				nwmx=max(nwmx,mx[i]);
		}
		int p=1,ret=0;
		while(p!=r[p]){
			++ret;
			for(int i=p; i<r[p]; ++i) dis[i]=ret;
			p=r[p];
		}
		for(int i=1; i<=m; ++i){
			scanf("%d",&x);
			if(!dis[x]) puts("oo"); else printf("%d\n",dis[x]);
		}
	}
}

int main(){
		freopen("brunhilda.in","r",stdin);
		freopen("brunhilda.out","w",stdout);
		solver::solve();	
}
