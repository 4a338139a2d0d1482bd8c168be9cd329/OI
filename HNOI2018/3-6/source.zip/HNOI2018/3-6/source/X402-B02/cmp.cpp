#include<bits/stdc++.h>
int main(){
 	int n;
	char a[10000][100],b[10000][100];
	freopen("un.out","r",stdin);
	for(int i=1; i<=1000; ++i)
			scanf("%s",a[i]);
	
	freopen("brunhilda.out","r",stdin);
	for(int i=1; i<=1000; ++i)
			scanf("%s",b[i]);


	for(int i=1; i<=1000; ++i)
		if(strcmp(a[i],b[i])!=0) puts("wa");
	puts("ac");
	//freopen("brunhilda.out","r",stdin);
}
