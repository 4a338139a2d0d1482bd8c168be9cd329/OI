#include<bits/stdc++.h>
#define sz size
#define pb push_back
const int N=100;
using namespace std;

struct node{
	int x,y;
};

int n,m;

int a[N][N];
int b[N][N];
int e[N][N];
int f[N][N]; 

char str[N];
vector<node> c,d;
int all=0;

int fbs(int x) {return x>0?x:-x;}
int dist(node e,node f){
	int le=abs(e.x-f.x)+abs(e.y-f.y);
}

int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};

void dfs(int x,int y){
	for(int i=0; i<=3; ++i){
		int tx=x+dx[i];
		int ty=y+dy[i];
		if(tx<1||tx>n)continue;
		if(ty<1||ty>m)continue;	
		if(!e[tx][ty])continue;
		if(f[x][y]+1<f[tx][ty]){
			f[tx][ty]=f[x][y]+1;
			dfs(tx,ty);
		}
	}
}

int rdist(struct node a,struct node b){	
	for(int i=1; i<=n; ++i)
		for(int j=1; j<=m; ++j)
			f[i][j]=0x3f3f3f3f;
	f[a.x][a.y]=0;
	dfs(a.x,a.y);
	return f[b.x][b.y];
}

void check1(){
	for(int i=1; i<=n; ++i)
		for(int j=1; j<=m; ++j)
			f[i][j]=0x3f3f3f3f;
	f[c[0].x][c[0].y]=0;
	dfs(c[0].x,c[0].y);
	printf("%d\n",f[d[0].x][d[0].y]);
}

struct _{
	int x,y,d;
	bool operator < (const struct _ &p){
		 return d<p.d;
	}
};
int fa[100000];
struct _ edge[500*500];

int find(int x){
	return fa[x]==x?x:fa[x]=find(fa[x]);
}

int now;

int main(){
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);
	scanf("%d%d",&n,&m);
	int bll=0;
	for(int i=1; i<=n; ++i){		
			scanf("%s",str);
			for(int j=1; j<=m; ++j) a[i][j]=(bool)(str[j-1]=='1');
			for(int j=1; j<=m; ++j) all+=a[i][j];
			for(int j=1; j<=m; ++j) if(a[i][j]) c.pb((node){i,j});
	}
	for(int i=1; i<=n; ++i){
			scanf("%s",str);
			for(int j=1; j<=m; ++j) b[i][j]=(bool)(str[j-1]=='1');
			for(int j=1; j<=m; ++j) if(b[i][j]) d.pb((node){i,j});
	}
	for(int i=1; i<=n; ++i){
			scanf("%s",str);
			for(int j=1; j<=m; ++j){
				if(str[j-1]=='z') e[i][j]=74,++bll; else e[i][j]=str[j-1]-'0';
			}
	}
	
	if(all==1)check1();
	else if(bll==n*m){
		for(int i=0; i<all; ++i)
			for(int j=0; j<all; ++j){
				edge[++now]=(_){i+1,j+1,rdist(c[i],d[j])};
			}
		sort(edge+1,edge+now+1);
		int ret=0;
		for(int i=1; i<=all; ++i) fa[i]=i;
		for(int i=1; i<=now; ++i){
			int x=edge[i].x,y=edge[i].y;
			if(find(x)==find(y))continue;
			fa[x]=y;ret+=edge[i].d;
		}
		printf("%d\n",ret);
	}
}
