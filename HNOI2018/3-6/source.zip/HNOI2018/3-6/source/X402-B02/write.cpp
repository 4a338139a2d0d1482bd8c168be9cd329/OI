#include<bits/stdc++.h>
#define pb push_back
#define sz size
#define ll long long
using namespace std;
const int N=1e5+10;
const int E=1e7+10;
int pnt,n,m;
bool a[N+5];
int p[N+5];
vector<int> mx[E+5];
int r[E+5];

namespace solver{
	bool cmp(int x,int y){
		return x>y?x:y;
	}
	void solve(){
		scanf("%d%d",&n,&m);
		for(int i=1; i<=n; ++i) scanf("%d",&p[i]);
		int x=0;

		sort(p+1,p+n+1);
		for(int i=1; i<=n; ++i){
			if(p[i]==p[i-1]) continue;
			for(int j=p[i]; j<=10000000; j+=p[i]){
				mx[j].push_back(p[i]);
			}
		}
		
		/*int nwmx=p[n];
		for(int i=1; i<=n; ++i){
			scanf("%d",&m);
			r[x]=nwmx;
			--nwmx;
			for(int j=0; j<mx[i].sz(); ++j){
				if(mx[i][j]+i<=10000000)
					nwmx=max(nwmx,mx[i][j]+i);
			}
		}*/
		
		/*for(int i=1; i<=m; ++i){
			scanf("%d",&x);
			int p=1,ret=0;
			while(r[p]<=x){
				p=r[p];
				++ret;
			}
			printf("%d\n",ret);
		}*/
	}
}

int main(){
		freopen("brunhilda.in","r",stdin);
		freopen("brunhilda.out","w",stdout);
		solver::solve();	
}
