#include<bits/stdc++.h>
using namespace std;
const int maxn=10000010;
int ans[maxn];
int qus[100100];
struct node{
	int p,v;
};
bool operator < (const node &A,const node &B){
	return A.p>B.p;
}
priority_queue<node> q;
int main(){
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
	int n,m,Max=0;
	node st;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d",&st.v);
		st.p=0;
		q.push(st);
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&qus[i]);
		if(qus[i]>Max) Max=qus[i];
	}
	ans[0]=0;
	for(int i=1;i<=Max;i++){
		while(q.top().p+q.top().v<=i){
			st.v=q.top().v;
			st.p=i-i%st.v;
			q.pop();
			q.push(st);
		}
		if(q.top().p==i){
			for(int j=i;j<=Max;j++)
				ans[j]=-1;
			break;
		}
		ans[i]=ans[q.top().p]+1;
	}
	for(int i=1;i<=m;i++){
		if(ans[qus[i]]>=0)
			printf("%d\n",ans[qus[i]]);
		else
			printf("oo\n");
	}
	return 0;
}
