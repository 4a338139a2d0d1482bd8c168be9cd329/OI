#include<bits/stdc++.h>
using namespace std;
const int INF=1e9;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
int pri[100100],qus[100100];
int dp[100100];
int main(){
	freopen("brunhilda.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int n,m,maxval=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&pri[i]);
	for(int i=1;i<=m;i++){
		scanf("%d",&qus[i]);
		if(qus[i]>maxval) maxval=qus[i];
	}
	dp[0]=0;
	for(int i=1;i<=maxval;i++){
		dp[i]=INF;
		for(int j=1;j<=n;j++)
			chkmin(dp[i],dp[i-i%pri[j]]+1);
	}
	for(int i=1;i<=m;i++){
		if(dp[qus[i]]==INF)
			printf("oo\n");
		else
			printf("%d\n",dp[qus[i]]);
	}
	return 0;
}
