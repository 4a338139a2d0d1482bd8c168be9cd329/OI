#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
bool isprim(int x){
	for(int i=2;i*i<=x;i++)
		if(x%i==0)
			return 0;
	return 1;
}
void solve(){
	int n=rand()%1000+1,m=100000;
	printf("%d %d\n",n,m);
	int x,v=rand()%n+1;
	for(int i=1;i<=n;i++){
		x=rand()%v+2;
		while(!isprim(x)) x=rand()%v+2;
		printf("%d ",x);
	}
	printf("\n");
	for(int i=1;i<=m;i++)
		printf("%d ",rand()%(m+1));
	printf("\n");
}
int main(){
	srand(time(0)+getx());
	freopen("brunhilda.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
