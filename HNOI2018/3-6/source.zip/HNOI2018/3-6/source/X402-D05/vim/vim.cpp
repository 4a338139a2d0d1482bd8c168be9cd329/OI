#include<bits/stdc++.h>
using namespace std;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
const int INF=1e9;
char str[100100];
bool pd[100100];
int dp[5010][5010];
int nex[100100][12];
int mp[1000100],p[100100];
int main(){
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n>5010){
		puts("0");
		return 0;
	}
	scanf("%s",str+1);
	int ans=0,num=0;
	for(int i=1;i<=n;i++){
		if(str[i]=='e')
			ans+=2;
		else{
			num++;
			if(str[i-1]=='e')
				pd[num]=1;
			str[num]=str[i];
		}
	}
	n=num;
	num=0;
	for(int i=1;i<=n;i++){
		if(pd[i])
			p[++num]=i;
		mp[i]=num;
	}
	for(int i=0;i<10;i++)
		nex[n][i]=n+1;
	for(int i=n-1;i>=1;i--){
		for(int j=0;j<10;j++)
			nex[i][j]=nex[i+1][j];
		nex[i][str[i+1]-'a']=i+1;
	}
	for(int i=0;i<=num;i++)
		for(int j=0;j<=n;j++)
			dp[i][j]=INF;
	dp[0][1]=0;
	for(int i=0;i<num;i++){
		for(int j=1;j<=n;j++){
			if(dp[i][j]==INF) continue;
			for(int k=0;k<10;k++){
				if(nex[j][k]<=n)
					chkmin(dp[i][nex[j][k]],dp[i][j]+2);
				if(mp[j]>i)
					chkmin(dp[mp[j]][p[i+1]],dp[i][j]+j-p[i+1]);
			}
		}
	}
	int sum=INF;
	for(int i=1;i<=n;i++)
		chkmin(sum,dp[num][i]);
	ans=ans+sum;
	printf("%d\n",ans);
	return 0;
}
