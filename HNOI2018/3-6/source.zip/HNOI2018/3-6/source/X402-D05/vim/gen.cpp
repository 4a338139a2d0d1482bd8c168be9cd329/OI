#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=5000;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		printf("%c",rand()%10+'a');
	printf("\n");
}
int main(){
	srand(time(0)+getx());
	freopen("vim.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
