#include<bits/stdc++.h>

using namespace std;

#define mp make_pair

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef pair<int,int> PII;

const int maxn=25,INF=0x3f3f3f3f;

char s[maxn];

int n,m,cnt1,cnt2;
bool A[maxn][maxn],B[maxn][maxn];
int G[maxn][maxn];

namespace BF{
    int ans=INF;

    bool check(){
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++) if(A[i][j]!=B[i][j]) return 0;
        return 1;
    }

    void dfs(int u){
        if(u>ans) return;
        if(check()) return void(ans=u);
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++) if(A[i][j]&&G[i][j])
                for(int dx=-1;dx<=1;dx++)
                    for(int dy=-1;dy<=1;dy++)
                        if(!A[i+dx][j+dy]&&G[i+dx][j+dy]){
                            A[i][j]=0; A[i+dx][j+dy]=1;
                            G[i][j]--; G[i+dx][j+dy]--;
                            dfs(u+1);
                            A[i][j]=1; A[i+dx][j+dy]=0;
                            G[i][j]++; G[i+dx][j+dy]++;
                        }
    }

    void solve(){
        dfs(0); printf("%d\n",ans==INF?-1:ans);
    }
}

namespace SP{
    int dis[maxn][maxn];

    void solve(){
        queue<PII> q;
        memset(dis,INF,sizeof dis);

        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++) if(A[i][j]){
                if(!G[i][j]){ puts("-1"); return; }
                q.push(mp(i,j)),dis[i][j]=0;
            }

        while(!q.empty()){
            PII u=q.front(); q.pop();
            int x=u.first,y=u.second;
            if(B[x][y]){
                printf("%d\n",dis[x][y]);
                return;
            }
            for(int dx=-1;dx<=1;dx++)
                for(int dy=-1;dy<=1;dy++){
                    int nx=x+dx,ny=y+dy;
                    if(dis[nx][ny]!=INF) continue;
                    if(B[nx][ny]+G[nx][ny]<2) continue;
                    dis[nx][ny]=dis[x][y]+1;
                    q.push(mp(nx,ny));
                }
        }
    }
}

int main(){
    freopen("pipes.in","r",stdin);
    freopen("pipes.out","w",stdout);

    read(n); read(m);

    for(int i=1;i<=n;i++){
        scanf("%s",s+1);
        for(int j=1;j<=m;j++) cnt1+=(A[i][j]=(s[j]-'0'));
    }

    for(int i=1;i<=n;i++){
        scanf("%s",s+1);
        for(int j=1;j<=m;j++) cnt2+=(B[i][j]=(s[j]-'0'));
    }

    for(int i=1;i<=n;i++){
        scanf("%s",s+1);
        for(int j=1;j<=m;j++) G[i][j]=(s[j]=='z'?74:s[j]-'0');
    }

    if(cnt1!=cnt2) puts("-1"),exit(0);

    if(n<=3&&m<=3) BF::solve();
    else if(cnt1==1) SP::solve();

    return 0;
}
