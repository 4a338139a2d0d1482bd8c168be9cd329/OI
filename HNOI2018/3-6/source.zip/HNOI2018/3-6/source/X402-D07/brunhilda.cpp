#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=1e7,maxm=1e5,INF=0x3f3f3f3f;

int m,q;
int f[maxn+5],g[maxn+5];

int main(){
    freopen("brunhilda.in","r",stdin);
    freopen("brunhilda.out","w",stdout);

    read(m); read(q);

    for(int i=1;i<=maxn;i++) g[i]=INF;

    while(m--){
        int p; read(p);
        for(int i=0;i*p<=maxn;i++){
            int L=i*p,R=min(L+p-1,maxn);
            chkmin(g[R],L);
        }
    }

    for(int i=maxn-1;i;i--) chkmin(g[i],g[i+1]);

    memset(f,INF,sizeof f); f[0]=0;
    for(int i=1;i<=maxn;i++) chkmin(f[i],f[g[i]]+1);

    while(q--){
        int x; read(x);
        if(f[x]==INF) puts("oo");
        else printf("%d\n",f[x]);
    }

    return 0;
}
