#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=510,INF=0x3f3f3f3f;

int n,ans;
char s[maxn];
int G[maxn][maxn],f[maxn][maxn];
int p[maxn],cnt;

int main(){
    freopen("vim.in","r",stdin);
    freopen("vim.out","w",stdout);
    
    read(n);
    scanf("%s",s+1);

    memset(G,INF,sizeof G);
    for(int i=1;i<=n;i++) G[i][i]=0;

    p[0]=1;

    for(int i=1;i<=n;i++){
        if(s[i]=='e') p[++cnt]=i;
        G[i][i-1]=1;
        for(int k=0;k<10;k++) if(k!=4)
            for(int j=i+1;j<=n;j++) if(s[j]=='a'+k){ G[i][j]=2; break; }
    }

    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++) chkmin(G[i][j],G[i][k]+G[k][j]);

    memset(f,INF,sizeof f);
    f[0][0]=0;
    for(int i=1;i<=cnt;i++)
        for(int j=1;j<=i;j++)
            for(int k=0;k<j;k++)
                chkmin(f[i][j],f[j-1][k]+G[p[k]][p[i]]+(p[i]-p[j]));
    
    ans=INF;
    for(int i=1;i<=cnt;i++) chkmin(ans,f[cnt][i]);
    printf("%d\n",ans+cnt);

    return 0;
}
