#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
const int INF=1e9;
const int drx[8]={1,-1,1,-1,0,0,-1,1};
const int dry[8]={1,-1,-1,1,-1,1,0,0};
int a[100][100],b[100][100],cst[100][100];
char str[maxn];
int n,m;
int S,T;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],c[maxn<<1],w[maxn<<1],e=1;
void putin(int s,int t,int W,int C){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
	w[e]=W,c[e]=C;
}
void Addedge(int s,int t,int W,int C){
	putin(s,t,W,C);
	putin(t,s,0,-C);
}
int id(int x,int y,int dr){
	return ((x-1)*m+y-1)<<1|dr;
}
bool out(int x,int y){
	if(x<1||x>n) return 1;
	if(y<1||y>m) return 1;
	return 0;
}
int ans,sum;
int f[maxn],dis[maxn];
bool inq[maxn];
queue<int> q;
bool SPFA(){
	while(!q.empty()) q.pop();
	for(int i=0;i<=T;i++)
		dis[i]=INF,f[i]=0,inq[i]=0;
	dis[S]=0;
	q.push(S);
	int u;
	while(!q.empty()){
		u=q.front();
		q.pop();
		inq[u]=0;
		for(int i=beg[u];i;i=nex[i]){
			if(w[i]&&dis[tto[i]]>dis[u]+c[i]){
				dis[tto[i]]=dis[u]+c[i];
				f[tto[i]]=i;
				if(!inq[tto[i]]){
					inq[tto[i]]=1;
					q.push(tto[i]);
				}
			}
		}
	}
	return dis[T]<INF;
}
void Addflow(){
	int u=T;
	int mn=INF;
	while(u!=S){
		if(w[f[u]]<mn) mn=w[f[u]];
		u=tto[f[u]^1];
	}
	u=T;
	while(u!=S){
		w[f[u]]-=mn,w[f[u]^1]+=mn;
		ans+=mn*c[f[u]];
		u=tto[f[u]^1];
	}
	sum+=mn;
}
int main(){
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);
	int cnt1=0,cnt2=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",str+1);
		for(int j=1;j<=m;j++){
			a[i][j]=str[j]-'0';
			cnt1+=a[i][j];
		}
	}
	for(int i=1;i<=n;i++){
		scanf("%s",str+1);
		for(int j=1;j<=m;j++){
			b[i][j]=str[j]-'0';
			cnt2+=b[i][j];
		}
	}
	for(int i=1;i<=n;i++){
		scanf("%s",str+1);
		for(int j=1;j<=m;j++){
			if(str[j]=='z')
				cst[i][j]=74;
			else
				cst[i][j]=str[j]-'0';
		}
	}
	if(cnt1!=cnt2){
		printf("-1\n");
		return 0;
	}
	S=n*m*2,T=n*m*2+1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(a[i][j])
				Addedge(S,id(i,j,0),1,0);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(b[i][j])
				Addedge(id(i,j,1),T,1,0);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			Addedge(id(i,j,0),id(i,j,1),(a[i][j]+b[i][j]+cst[i][j])/2,0);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			for(int k=0;k<8;k++){
				int x=i+drx[k],y=j+dry[k];
				if(out(x,y)) continue;
				Addedge(id(i,j,1),id(x,y,0),INF,1);
			}
	while(SPFA()) Addflow();
	if(sum!=cnt1)
		printf("-1\n");
	else
		printf("%d\n",ans);
	return 0;
}
