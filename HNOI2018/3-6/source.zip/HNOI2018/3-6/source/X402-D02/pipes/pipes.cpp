#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>

inline bool check_min(int a,int &b){return a<b?b=a,1:0;}

typedef std::pair<int,int> pii;
const int L=22,N=L*L*3+233,M=N*100,INF=23333;

namespace network
{
	int begin[N],next[M],to[M],w[M],c[M];
	int S,T,e;

	inline void reset(int ds,int dt){S=ds,T=dt,e=1;}
	void add(int x,int y,int z,int h,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		w[e]=z;
		c[e]=h;
		if(k)add(y,x,0,-h,0);
	}
	int dis[N],pre[N];
	bool spfa()
	{
		static std::queue<int> Q;
		while(!Q.empty())Q.pop();

		for(int i=1;i<=T;i++)dis[i]=INF;
		dis[S]=0,Q.push(S);

		for(int p,q;!Q.empty();)
		{
			p=Q.front();Q.pop();
			for(int i=begin[p];i;i=next[i])
				if(w[i] && check_min(dis[p]+c[i],dis[q=to[i]]))
					pre[q]=i,Q.push(q);
		}

		return dis[T]<INF;
	}
	pii MCMF()
	{
		pii ret=pii(0,0);
		while(spfa())
		{
			for(int p=T;p!=S;p=to[pre[p]^1])
				w[pre[p]]--,w[pre[p]^1]++;
			ret.first+=dis[T];
			ret.second++;
		}
		return ret;
	}
}

namespace hei
{
	const int mv[8][2]=
	{
		-1,-1,-1,0,-1,1,
		0,-1      ,0,1,
		1,-1,1,0,1,1
	};
	char G0[L][L],G1[L][L],s[L][L];

	int n,m;
	inline bool out(int x,int y){return x<1 || x>n || y<1 || y>m;}

#define id(i,j,k) ((i-1)*m+j+(k)*(n*m))
	void build()
	{
		int S=n*m*3+1,T=S+1;
		network::reset(S,T);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
			{
				int less=s[i][j]/2,more=s[i][j]-less;
				if(G0[i][j]==G1[i][j])
				{
					network::add(id(i,j,0),id(i,j,1),less,0);
					network::add(id(i,j,1),id(i,j,2),less,0);
				}
				else if(G0[i][j]=='1')
				{
					network::add(id(i,j,0),id(i,j,1),less,0);
					network::add(id(i,j,1),id(i,j,2),more,0);
				}
				else
				{
					network::add(id(i,j,0),id(i,j,1),more,0);
					network::add(id(i,j,1),id(i,j,2),less,0);
				}

				for(int k=0;k<8;k++)
				{
					int x=i+mv[k][0],y=j+mv[k][1];
					if(out(x,y))continue;
					network::add(id(i,j,2),id(x,y,0),INF,1);
				}

				if(G0[i][j]=='1')network::add(S,id(i,j,1),1,0);
				if(G1[i][j]=='1')network::add(id(i,j,1),T,1,0);
			}
	}

	inline void got(char &x){for(x=getchar();!isdigit(x) && x!='z';x=getchar());}
	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				got(G0[i][j]);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				got(G1[i][j]);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				got(s[i][j]),s[i][j]=s[i][j]=='z'?74:s[i][j]-48;
	}
	int precheck()
	{
		int x=0,y=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				x+=G0[i][j]^48;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				y+=G1[i][j]^48;
		return x==y?x:-1;
	}
	void solve()
	{
		initialize();
		int amount=precheck();
		if(amount<0){printf("-1\n");return;}
		build();
		pii ans=network::MCMF();
		if(ans.second<amount)printf("-1\n");
		else printf("%d\n",ans.first);
	}
}

int main()
{
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);
	hei::solve();
	return 0;
}
