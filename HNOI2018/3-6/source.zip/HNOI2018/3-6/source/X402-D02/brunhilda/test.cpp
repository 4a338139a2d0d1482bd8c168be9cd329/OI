#include<iostream>
#include<cstdio>
#include<cstring>

const int N=2333,M=233333;

int p[N],f[M];

int n,m;

int main()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",p+i);
	for(int i=1;i<=50000;i++)
		f[i]=M;
	for(int i=1;i<=50000;i++)
		for(int j=1;j<=n;j++)
			f[i]=std::min(f[i],f[(i/p[j])*p[j]]+1);

	for(int i=1;i<=50000;i++)
		if(f[i]-f[i-1]>0)printf("%d : %d\n",i,f[i]);

	return 0;
}
