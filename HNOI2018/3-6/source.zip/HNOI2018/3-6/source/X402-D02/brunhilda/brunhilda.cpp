#include<iostream>
#include<cstdio>
#include<cstring>

inline void check_min(int a,int &b){if(a<b)b=a;}

namespace Zhe_Jue_Bu_Ke_Neng_Pao_De_Chu_Lai
{
	const int N=10001000,M=100010,INF=998244353; 

	int g[N];

	int n,m;
	
	inline void work(int x)
	{
		for(int i=0;i*x<N;i++)
		{
			int L=i*x,R=std::min(L+x-1,N-1);
			check_min(L,g[R]);
		}
	}
	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=0;i<N;i++)g[i]=INF;
		for(int i=1,x;i<=n;i++)
			scanf("%d",&x),work(x);
		for(int i=N-1;i;i--)check_min(g[i],g[i-1]);
	}

	int f[N];
	void dp()
	{
		for(int i=1;i<N;i++)
		{
			f[i]=INF;
			f[i]=f[g[i]]+1;
		}
	}
	void solve()
	{
		initialize();
		dp();
		for(int x;m--;)
		{
			scanf("%d",&x);
			if(f[x]<INF)printf("%d\n",f[x]);
			else printf("oo\n");
		}
	}
}

int main()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
	Zhe_Jue_Bu_Ke_Neng_Pao_De_Chu_Lai::solve();

//	fprintf(stderr,"fast time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
