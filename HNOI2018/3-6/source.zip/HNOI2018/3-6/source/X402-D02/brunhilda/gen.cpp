#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

const int N=1000100;

bool isit[N];
int pri[N/8],tot;

void getpri()
{
	for(int i=2;i<N;i++)
	{
		if(!isit[i])pri[++tot]=i;
		for(int j=1,x;(x=i*pri[j])<N;j++)
		{
			isit[x]=1;
			if(i%pri[j]==0)break;
		}
	}
}
bool vis[N/8];

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("brunhilda.in","w",stdout);//look at here

	getpri();

	int n=23,m=23333;
	tot=100;
	printf("%d %d\n",n,m);
	while(n--)
	{
		int x=rand()%tot+1;
		while(vis[x])x=rand()%tot+1;
		printf("%d ",pri[x]);
		vis[x]=1;
	}
	printf("\n");
	while(m--)printf("%d\n",rand()%1000000);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
