#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>

namespace Zhe_Jue_Bu_Ke_Neng_Pao_De_Chu_Lai
{
	const int N=1000010,M=100010,INF=998244353; 

#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
	int w[M*4];
	void reset(int p=1,int L=1,int R=M-1){w[p]=INF;if(L!=R)reset(lcq),reset(rcq);}
	void modify(int x,int y,int p=1,int L=1,int R=M-1)
	{
		if(L==R)w[p]=y;
		else (x<=mid?modify(x,y,lcq):modify(x,y,rcq)),w[p]=std::min(w[lt],w[rt]);
	}
	inline int query(){return w[1];}

	std::vector<int> V[N];

	int n,m;
	
	inline void work(int x,int pos)
	{
		for(int i=0;i*x<N;i++)
			V[i*x].push_back(pos);
	}
	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=1,x;i<=n;i++)
			scanf("%d",&x),work(x,i);
	}

	int f[N];
	void dp()
	{
		reset();
		for(int j=0;j<(int)V[0].size();j++)modify(V[0][j],0);

		for(int i=1;i<N;i++)
		{
			f[i]=INF;
			for(int j=0;j<(int)V[i].size();j++)
				modify(V[i][j],i);
			f[i]=f[query()]+1;
		}
	}
	void solve()
	{
		initialize();
		dp();
		for(int x;m--;)
		{
			scanf("%d",&x);
			if(f[x]<INF)printf("%d\n",f[x]);
			else printf("oo\n");
		}
	}
}

int main()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.ans","w",stdout);
	Zhe_Jue_Bu_Ke_Neng_Pao_De_Chu_Lai::solve();

	fprintf(stderr,"not fast time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
