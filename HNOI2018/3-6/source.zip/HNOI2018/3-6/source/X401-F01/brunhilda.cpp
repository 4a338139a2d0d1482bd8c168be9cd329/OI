#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e5+10,MAXV=1e7+10;
int n,Q,pri[MAXN],_max[MAXV],f[MAXV];
queue<int>q;
int main()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);
	n=read();Q=read();
	for(int i=1;i<=n;++i)pri[i]=read();
	memset(f,INF,sizeof(f));
	for(int i=1;i<=n;++i)
		for(int j=pri[i];j<=int(1e7);j+=pri[i])
			_max[j]=pri[i];
	q.push(0);
	f[0]=0;
	_max[0]=pri[n];
	int v=1;
	while(!q.empty()&&v<=int(1e7))
	{
		int u=q.front();q.pop();
		if(!_max[u])continue;
		while(v<=u+_max[u]-1&&v<=int(1e7))
		{
			f[v]=f[u]+1;
			q.push(v++);
		}
	}
	for(int i=1;i<=Q;++i)
	{
		int x=read();
		f[x]==INF?puts("oo"):printf("%d\n",f[x]);
	}
	return 0;
}
