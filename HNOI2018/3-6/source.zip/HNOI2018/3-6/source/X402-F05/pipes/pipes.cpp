#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int oo = 1e9;

struct MCMF {

	const static int N = 900, M = N * 30;

	MCMF() { e = 1; }

	int Begin[N], flow[M], to[M], Next[M], cost[M], e;

	void add(int u, int v, int f, int c) {
		to[++e] = v, Next[e] = Begin[u], Begin[u] = e, cost[e] = c, flow[e] = f;
		to[++e] = u, Next[e] = Begin[v], Begin[v] = e, cost[e] = -c, flow[e] = 0;
	}

	int S, T;
	int dis[N], pre[N];
	bool inq[N];

	bool SPFA(int &sum) {
		queue<int> q;
		memset(dis, 0x3f, sizeof dis);
		q.push(S);
		dis[S] = 0, inq[S] = true;
		while (!q.empty()) {
			int o = q.front(); q.pop();
			inq[o] = false;
			for (int i = Begin[o]; i; i = Next[i]) {
				int u = to[i], w = dis[o] + cost[i];
				if (flow[i] && w < dis[u]) {
					dis[u] = w, pre[u] = i;
					if (!inq[u]) inq[u] = true, q.push(u);
				}
			}
		}
		if (dis[T] > oo) return false;
		sum += dis[T];
		for (int o = T; o != S; o = to[pre[o] ^ 1]) flow[pre[o]]--, flow[pre[o] ^ 1]++;
		return true;
	}

	void work(int s, int t, int &f, int &c) {
		S = s, T = t;
		while (SPFA(c)) ++f;
	}
	
}F;

const int N = 21;

int n, m;
int A[N][N], B[N][N], lim[N][N];

int id(int x, int y, int z) {
	return ((x - 1) * m + y - 1) * 2 + z + 1;
}

int main() {

	freopen("pipes.in", "r", stdin);
	freopen("pipes.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) For(j, 1, m) scanf("%1d", &A[i][j]);
	
	int sumf = 0, cnt = 0;
	For(i, 1, n) For(j, 1, m) {
		scanf("%1d", &B[i][j]);
		if (A[i][j] && B[i][j]) A[i][j] = B[i][j] = 0;
		sumf += B[i][j];
		cnt += A[i][j];
	}

	if (sumf ^ cnt) {
		puts("-1");
		return 0;
	}

	For(i, 1, n) {
		char S[n + 5];
		scanf("%s", S + 1);
		For(j, 1, m) {
			lim[i][j] = S[j] == 'z' ? 74 : S[j] - '0';
			lim[i][j] = (lim[i][j] + A[i][j] + B[i][j]) / 2;
		}
	}
	int S = n * m * 2 + 1, T = S + 1;
	For(i, 1, n) For(j, 1, m) 
		For(x, max(1, i - 1), min(n, i + 1)) For(y, max(1, j - 1), min(m, j + 1))
			if (x != i || y != j) F.add(id(i, j, 1), id(x, y, 0), oo, 1);
	For(i, 1, n) For(j, 1, m) {
		if (A[i][j]) F.add(S, id(i, j, 0), 1, 0);
		if (B[i][j]) F.add(id(i, j, 1), T, 1, 0);
		F.add(id(i, j, 0), id(i, j, 1), lim[i][j], 0);
	}

	int f = 0, c = 0;
	F.work(S, T, f, c);
	printf("%d\n", f == sumf ? c : -1);

	return 0;
}
