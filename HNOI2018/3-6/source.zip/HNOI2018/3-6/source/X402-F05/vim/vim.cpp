#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 7e4 + 10;
const int ban = 'e' - 'a';

int n;
int nxt[N][12], cnt[N];
int dp[5010][5010], suf[N];
char S[N];

int main() {

	freopen("vim.in", "r", stdin);
	freopen("vim.out", "w", stdout);

	scanf("%d%s", &n, S + 1);
	Forr(i, n, 1) {
		For(j, 0, 9) nxt[i][j] = nxt[i + 1][j];
		if (i < n) nxt[i][S[i + 1] - 'a'] = i + 1;
		suf[i] = S[i + 1] == 'e' ? suf[i + 1] : i + 1;
	}
	For(i, 1, n) cnt[i] = cnt[i - 1] + (S[i] == 'e');

	if (cnt[n] == 0) {
		puts("0");
		return 0;
	}

	memset(dp, 0x3f, sizeof dp);
	dp[1][1] = 0;
	For(i, 1, n) For(p, i, n) {
		int val = dp[i][p];
		if (val > 1e9 || val >= dp[i][p + 1]) continue;
		For(j, 0, 9) if (j ^ ban) {
			int k = nxt[i][j];
			if (cnt[k] - cnt[p] > 0) {
				int len = 2 + k - nxt[p][ban];
				int u = suf[nxt[p][ban]];
				dp[u][k] = min(dp[u][k], val + len);
			} else {
				dp[k][p] = min(dp[k][p], val + 2);
			}
		}
	}

	int ans = 1e9;
	For(i, 1, n) if (cnt[i] == cnt[n]) For(j, 1, n) ans = min(ans, dp[j][i]);
	printf("%d\n", ans + cnt[n]);
	
	return 0;
}
