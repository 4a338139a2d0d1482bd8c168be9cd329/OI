#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e7 + 10;

bool vis[N];

int main() {

	freopen("brunhilda.in", "w", stdout);

	srand(time(0));
	int lim = N - 5, n = 0;
	puts("100000 100000");
	For(i, 2, lim) if (!vis[i]) {
		printf("%d%c", i, ++n == 100000 ? '\n' : ' ');
		if (n == 100000) break;
		for (int j = i * 2; j <= lim; j += i) vis[j] = true;
	}
	For(i, 1, 100000) printf("%d\n", rand() % (N - 10) + 1);

	return 0;
}
