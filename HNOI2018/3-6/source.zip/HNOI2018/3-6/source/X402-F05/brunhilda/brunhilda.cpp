#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10, M = 1e7 + 10;

int n, m, lim = M - 5;
int P[N];
int dp[M], mx[M];
int cnt[M];

int Begin[M], Next[M], to[M], e;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int main() {

	freopen("brunhilda.in", "r", stdin);
	freopen("brunhilda.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%d", &P[i]);
	sort(P + 1, P + n + 1), n = unique(P + 1, P + n + 1) - P - 1;

	For(i, 1, n) for (int j = 0; j <= lim; j += P[i]) mx[j] = max(mx[j], P[i]);
	For(i, 0, lim) if (mx[i] && i + mx[i] <= lim) add(i + mx[i], i);
	
	dp[0] = 0, cnt[0] = 1;
	int p = 0;
	For(i, 1, lim) {
		dp[i] = 1e9;
		if (mx[i]) cnt[i]++;	
		for (int j = Begin[i]; j; j = Next[j]) cnt[to[j]]--;
		while (!cnt[p] && p < i) ++p;
		dp[i] = dp[p] + 1;
	}

	while (m--) {
		int x;
		scanf("%d", &x);
		if (dp[x] > x) puts("oo");
		else printf("%d\n", dp[x]);
	}

	return 0;
}
