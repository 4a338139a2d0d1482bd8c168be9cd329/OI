#include<bits/stdc++.h>
using namespace std;

const int N=1000;
const int M=1e6+9;

int pri[M>>1],ptop;
bool npri[M];

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

inline void init()
{
	for(int i=2;i<M;i++)
	{
		if(!npri[i])
			pri[++ptop]=i;
		for(int j=1;j<=ptop && i*pri[j]<M;j++)
		{
			npri[i*pri[j]]=1;
			if(!(i%pri[j]))break;
		}
	}
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("brunhilda.in","w",stdout);
	init();

	int n=10,m=100000;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",pri[i]);
	puts("");
	for(int i=1;i<=m;i++)
		printf("%d\n",urand()%10000);
	return 0;
}
