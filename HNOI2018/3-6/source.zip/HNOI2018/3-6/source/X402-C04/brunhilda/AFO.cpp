#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void chkmin(int &a,int b){if(a>b)a=b;}
inline void chkmax(int &a,int b){if(a<b)a=b;}

const int N=10000009;
const int M=100009;

int n,m,q,Inf,mv;
int p[M],dis[N],qu[M];
bool vis[N];
vector<int> son[N];

int main()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);

	m=read();q=read();
	memset(dis,127,sizeof(dis));
	Inf=dis[0];dis[0]=0;

	for(int i=1;i<=m;i++)
	{
		p[i]=read();
		for(int j=1;p[i]*j<M;j++)
		{
			vis[p[i]*j]=1;
			son[p[i]*j].push_back(p[i]);
		}
		for(int j=1;j<p[i];j++)
			dis[j]=1;
	}

	for(int i=1;i<=q;i++)
		chkmax(mv,qu[i]=read());

	for(int i=1;i<mv;i++)
	{
		if(!vis[i] || dis[i]==Inf)continue;
		for(int j=0;j<son[i].size();j++)
		{
			int pri=son[i][j];
			for(int k=1;k<pri;k++)
				chkmin(dis[i+k],dis[i]+1);
		}
	}

	for(int i=1;i<=q;i++)
	{
		if(dis[qu[i]]==Inf)
			puts("oo");
		else
			printf("%d\n",dis[qu[i]]);
	}

	return 0;
}
