#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=10000009;

int n,m,q,ans;
int p[N];
bool f[2][N];

int main()
{
	freopen("brunhilda.in","r",stdin);
	freopen("brunhilda.out","w",stdout);

	m=read();q=read();
	for(int i=1;i<=m;i++)
		p[i]=read();
	while(q--)
	{
		n=read();
		memset(f,0,sizeof(f));
		f[0][n]=1;
		for(ans=1;ans;ans++)
		{
			bool fl=0;
			for(int j=1;j<=n;j++)
			{
				if(f[ans&1][j]!=f[ans&1^1][j])
					fl=1;
				f[ans&1][j]=0;
			}
			if(!fl)break;
			for(int j=1;j<=n;j++)
				if(f[ans&1^1][j])
					for(int k=1;k<=m;k++)
					{
						f[ans&1][j-j%p[k]]=1;
						if(f[ans&1][0])
							goto out;
					}
		}
		puts("oo");continue;
		out:;
		printf("%d\n",ans);
	}

	return 0;
}
