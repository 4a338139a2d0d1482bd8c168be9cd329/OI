#include<bits/stdc++.h>
using namespace std;

const int N=29;

int n,m,s,t,pcnt,Inf=1e9+7;
char gs[N][N],gt[N][N],gw[N][N];
int dx[]={0,1,0,-1,1,-1,-1,1};
int dy[]={1,0,-1,0,1,-1,1,-1};

inline bool chkmin(int &a,int b){if(a>b){a=b;return 1;}return 0;}
inline bool chkmax(int &a,int b){if(a<b){a=b;return 1;}return 0;}

inline int pt(int x,int y,int ty)
{
	return (((x-1)*m+y)<<1)+ty;
}

inline bool in(int a,int b)
{
	return 1<=a && a<=n && 1<=b && b<=m;
}

namespace mcmf
{
    const int P=1009;
    const int E=P*19;

    int to[E],nxt[E],w[E],beg[P],fae[P],tf,tot=1;
    int cost[E],dis[P];
    queue<int> q;
    bool inq[P];

    inline void adde(int u,int v,int flow,int c)
    {
		assert(tot<E-1);
        to[++tot]=v;nxt[tot]=beg[u];beg[u]=tot;
        cost[tot]=c;w[tot]=flow;
    }

    inline void add(int u,int v,int flow,int c)
    {
        adde(u,v,flow,c);adde(v,u,0,-c);
    }

    inline bool spfa()
    {
        memset(dis,127,sizeof(dis[0])*(t+5));
        Inf=dis[s];dis[s]=0;q.push(s);
		while(!q.empty())
		{
			int u=q.front();q.pop();inq[u]=0;
            for(int i=beg[u];i;i=nxt[i])
                if(w[i]>0 && chkmin(dis[to[i]],dis[u]+cost[i]))
                {
                    fae[to[i]]=i;
                    if(!inq[to[i]])
                        inq[to[i]]=1,q.push(to[i]);
                }
		}
        return dis[t]!=Inf;
    }

    inline int augment()
    {
        int mf=1e9;
        for(int i=t;i!=s;i=to[fae[i]^1])
			chkmin(mf,w[fae[i]]);
        for(int i=t;i!=s;i=to[fae[i]^1])
            w[fae[i]]-=mf,w[fae[i]^1]+=mf;
		tf+=mf;
        return mf*dis[t];
    }

    inline int run()
    {
        int ret=0;
        while(spfa())
			ret+=augment();
        return ret;
    }
}

int main()
{
	freopen("pipes.in","r",stdin);
	freopen("pipes.out","w",stdout);

	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%s",gs[i]+1);
	for(int i=1;i<=n;i++)
		scanf("%s",gt[i]+1);
	for(int i=1;i<=n;i++)
		scanf("%s",gw[i]+1);
	s=pt(n,m,1)+1,t=s+1;

	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(gs[i][j]=='1')
			{
				pcnt++;
				mcmf::add(s,pt(i,j,0),1,0);
			}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(gt[i][j]=='1')
				mcmf::add(pt(i,j,1),t,1,0);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			for(int k=0;k<=7;k++)
			{
				int fi=i+dx[k],fj=j+dy[k];
				if(in(fi,fj))
					mcmf::add(pt(fi,fj,1),pt(i,j,0),Inf,1);
			}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			if('0'<=gw[i][j] && gw[i][j]<='9')
				mcmf::add(pt(i,j,0),pt(i,j,1),gw[i][j]-'0',0);
			else
				mcmf::add(pt(i,j,0),pt(i,j,1),74,0);
		}
	int ans=mcmf::run();
	if(mcmf::tf!=pcnt)
		puts("-1");
	else
		printf("%d\n",ans);
	return 0;
}
