
#include<bits/stdc++.h>
using namespace std;

const int N=29;

int gs[N][N],gt[N][N];

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("pipes.in","w",stdout);

	int n=20,m=20,cnt=22;
	printf("%d %d\n",n,m);

	for(int i=1;i<=cnt;i++)
	{
		int u,v;re0:;
		u=rand()%n+1,v=rand()%n+1;
		if(gs[u][v])goto re0;
		gs[u][v]=1;
	}
	for(int i=1;i<cnt;i++)
	{
		int u,v;re1:;
		u=rand()%n+1,v=rand()%n+1;
		if(gt[u][v])goto re1;
		gt[u][v]=1;
	}

	for(int i=1;i<=n;i++,puts(""))
		for(int j=1;j<=m;j++)
			printf("%d",gs[i][j]);
	for(int i=1;i<=n;i++,puts(""))
		for(int j=1;j<=m;j++)
			printf("%d",gt[i][j]);
	for(int i=1;i<=n;i++,puts(""))
		for(int j=1;j<=m;j++)
		{
			int v=rand()%11;
			if(v<=10)printf("z");
			else printf("%d",v);
		}
	return 0;
}
