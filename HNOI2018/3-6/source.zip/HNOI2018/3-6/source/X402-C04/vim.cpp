#include<bits/stdc++.h>
using namespace std;

const int N=70009;
const int C=10;

int n,ans;
char s[N];
int nxt[N][C+5];
vector<int> vec;
bool mark[N],vis[N];

inline bool chkmin(int &a,int b){if(a>b){a=b;return 1;}return 0;}

namespace xjbf
{
	const int M=5009;
	int Inf=1e9+7,cnt;
	int f[M][M],con[N];

	inline void finde()
	{
		for(int i=0;s[i];++i)
		{
			if(s[i]=='e')
			{
				while(s[i]=='e')
					cnt+=2,++i;
				vec.push_back(n);
			}
			s[n++]=s[i];
		}
	}


	inline int works()
	{
		finde();
		if(!cnt)return printf("%d\n",cnt),0;

		for(int i=0;i<n;++i)
			if(s[i]<'e')s[i]-='a';
			else s[i]-='a'+1;
		
		for(int i=0;i<9;++i)
			for(int last=-1,j=n-1;~j;--j)
			{
				nxt[j][i]=last;
				if(s[j]==i)
					last=j;
			}

		for(int i=0;i<n;++i)
			con[i]=upper_bound(vec.begin(),vec.end(),i)-vec.begin();
		for(int i=0;i<n;++i)
			f[vec.size()][i]=cnt;
		for(int i=vec.size()-1;~i;--i)
			for(int j=n-1;~j;--j)
			{
				f[i][j]=1e9;
				for(int k=0;k<9;++k)
					if(~nxt[j][k])
						chkmin(f[i][j],f[i][nxt[j][k]]+2);
				if(con[j]>i)
					chkmin(f[i][j],f[con[j]][vec[i]]+j-vec[i]);
			}

		printf("%d\n",f[0][0]);

	}
}

int main()
{
	freopen("vim.in","r",stdin);
	freopen("vim.out","w",stdout);

	scanf("%*d%s",s);
/*	for(int i=0;i<C;i++)
		con[n][i]=n+1;
	for(int i=n-1;i>=0;i--)
	{
		for(int j=0;j<C;j++)
			con[i][j]=con[i+1][j];
		con[i][s[i+1]-'a']=i+1;
	}

	for(int i=1;i<=n;i++)
		if(s[i]=='e')
		{
			vec.push_back(i);
			ind[i]=vec.size();
		}
	for(int i=1;i<vec.size();i++)
		if(vec[i]-vec[i-1]<=2)
		{
			back[vec[i]]=vec[i-1];
			mark[vec[i-1]]=1;
		}

	if(!vec.size())
		return puts("0"),0;

	int u=1,tar=findtar(1);
	while(del!=vec.size())
	{
		int mindis=1e9+7;

		for(int i=0;i<C && i!='e'-'a';i++)
		{
			int step=0,pos=u;
			while(pos<tar)
				pos=con[pos][i],step+=2;
			chkmin(mindis,step+pos-tar);
		}
		ans+=mindis+1;del++;
		
		int pos=tar;
		while(back[pos])
			ans+=pos-back[pos]+1,del++,pos=back[pos];
		u=pos+1;tar=findtar(tar);
	}

	del=0;
	printf("%d\n",ans);*/
	xjbf::works();
	return 0;
}
