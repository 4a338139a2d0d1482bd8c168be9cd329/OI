#include <bits/stdc++.h>

using std :: sort;
using std :: pair;

typedef pair<int, int> Pii;

const int inf = 0x3f3f3f3f;

namespace SubTaskAll
{
	const int M = 1e7;
	const int N = 1e5;

	int m, Q, p[N + 5];
	int MaxDiv[M + 5];
	int Ans[M + 5];

	int q[M + 5], Lim = 1;
	void BFS_trans(int r = 0)
	{
		q[++r] = 0;
		for (int l = 1; l <= r; ++l){
			int v = q[l];
			for (int i = Lim-v; i < MaxDiv[v]; ++i){
				if (v + i > M) break;
				if (Ans[v + i] == 0){
					Ans[v + i] = Ans[v] + 1;
					q[++r] = v + i;
				}
				else assert(false);
				if (v + MaxDiv[v] > Lim)
					Lim = v + MaxDiv[v];
			}
		}
	}

	void main()
	{
		scanf("%d%d", &m, &Q);
		for (int i = 1; i <= m; ++i) scanf("%d", p + i);

		sort(p + 1, p + m + 1);
		for (int i = 1; i <= m; ++i) 
			if (p[i] != p[i-1]){
				for (int j = 0; j <= M; j += p[i]){
					MaxDiv[j] = p[i];
				}
			}

		BFS_trans();

		while (Q--){
			int n; scanf("%d", &n);
			if (Ans[n])
				printf("%d\n", Ans[n]);
			else
				puts("oo");
		}
	}
}

int main()
{
	freopen("brunhilda.in", "r", stdin);
	freopen("brunhilda.out", "w", stdout);

	SubTaskAll :: main();
	std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;

	return 0;
}
