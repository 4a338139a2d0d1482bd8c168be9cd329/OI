#include <bits/stdc++.h>

int RandInt(int l, int r)
{
	return 1ll * rand() * rand() % (r - l + 1) + l;
}

const int N = 1e7;

bool NotPrime[N + 5];
int prime[N + 5], tot;

void PrimeInit()
{
	for (int i = 2; i <= 10000; ++i){
		if (!NotPrime[i]){
			prime[tot ++] = i;
		}
		for (int j = 0; j < tot && prime[j] * i <= 10000; ++j){
			NotPrime[prime[j] * i] = true;
			if (i % prime[j] == 0) break;
		}
	}
}

bool vis[N + 5];

int main()
{
	freopen("brunhilda.in", "w", stdout);

	srand(time(NULL));

	PrimeInit(); vis[tot] = true;

	int m = 20, q = 50;
	printf("%d %d\n", m, q);
	for (int i = 1; i <= m; ++i){
		int j = tot;
		while (vis[j]) j = RandInt(0, tot - 1);
		vis[j] = true;
		printf("%d%c", prime[j], i != m? ' ':'\n');
	}
	for (int i = 1; i <= q; ++i)
		printf("%d\n", RandInt(1, 10000000));
	return 0;
}
