#include <bits/stdc++.h>

using std :: sort;
using std :: min;

const int inf = 0x3f3f3f3f;

namespace SubTask0
{
	const int N = 1e7;

	int m, q;
	int dp[N + 5];
	int p[N + 5];

	void main()
	{
		scanf("%d%d", &m, &q);
		for (int i = 1; i <= m; ++i) scanf("%d", &p[i]);
		while (q--){
			int n; scanf("%d", &n);
			memset(dp, -1, sizeof dp);
			dp[n] = 0;
			for (int i = n; i >= 1; --i){
				if (dp[i] >= 0){
					for (int j = 1; j <= m; ++j){
						if (i % p[j]){
							if (dp[i - i%p[j]] < 0)
								dp[i - i%p[j]] = inf;
							dp[i - i%p[j]] = min(dp[i - i%p[j]], dp[i] + 1);
						}
					}
				}
			}
			if (dp[0] < 0) 
				puts("oo");
			else
				printf("%d\n", dp[0]);
		}
	}
}

int main()
{
	freopen("brunhilda.in", "r", stdin);
	freopen("brunhilda.ans", "w", stdout);

	SubTask0 :: main();

	return 0;
}
