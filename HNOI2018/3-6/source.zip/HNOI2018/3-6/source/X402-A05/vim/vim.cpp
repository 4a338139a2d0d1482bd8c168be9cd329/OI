#include <bits/stdc++.h>

bool chkmin(int &a, int b) { return a > b? a = b, 1 : 0; }

const int N = 5e2;
const int inf = 0x3f3f3f3f;

int n;
char s[N + 5];

int dp[N + 5][N + 5];
int pos[N + 5], eNum;
int nxt[N + 5][11];
int NotE[N + 5];
int skip[N + 5][N + 5];
int sum[N + 5];

int main()
{
	freopen("vim.in", "r", stdin);
	freopen("vim.out", "w", stdout);

	scanf("%d%s", &n, s + 1);
	for (int i = 1; i <= n; ++i){
		sum[i] = sum[i-1];
		if (s[i] == 'e'){
			pos[++eNum] = i;
			for (int j = i + 1; j <= n; ++j)
				if (s[j] != 'e'){
					NotE[eNum] = j;
					break;
				}
		}
		else sum[i] ++;
		for (char c = 'a'; c <= 'j'; ++c){
			if (c == 'e') continue;
			for (int j = i + 1; j <= n; ++j)
				if (s[j] == c){
					nxt[i][c-'a'] = j;
					break;
				}
		}
	}

	for (int i = 1; i <= n; ++i){
		if (s[i] == 'e') continue;
		for (int j = 1; j <= eNum; ++j){
			if (pos[j] < i) continue;
			skip[i][j] = inf;
			for (int c = 0; c < 10; ++c){
				if (c + 'a' == 'e') continue;

				int ret = 0, u = i;
				for (; u && u < pos[j]; u = nxt[u][c]) ret += 2;
				if (u > pos[j])
					chkmin(skip[i][j], ret + u - pos[j]);
			}
		}
	}

	memset(dp, inf, sizeof dp);
	dp[0][1] = 0;
	for (int i = 0; i < eNum; ++i){
		for (int j = 1; j <= n; ++j){
			if (dp[i][j] >= inf) continue;
			for (int k = i+1; k <= eNum; ++k){
				chkmin(dp[k][NotE[i+1]], dp[i][j] + skip[j][k]
						+ (k-i)*2-1 + sum[pos[k]]-sum[pos[i+1]]);
			}
		}
	}

	int ans = inf;
	for (int i = 1; i <= n; ++i)
		if (dp[eNum][i] >= 0) chkmin(ans, dp[eNum][i]);

	printf("%d\n", ans);
	return 0;
}
