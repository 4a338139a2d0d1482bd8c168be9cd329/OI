#include <bits/stdc++.h>

using std :: pair;

typedef pair<int, int> Pii;

const int N = 20;
const int inf = 0x3f3f3f3f;
const int dx[3] = {-1, 0, 1}, dy[3] = {-1, 0, 1};

bool chkmin(int &a, int b)
{
	return a > b? a = b, true : false;
}

int n, m, c0, c1;
int A0[N + 5][N + 5];
int A1[N + 5][N + 5];
int B[N + 5][N + 5];

struct Node
{
	int x, y, step;
	int mat[N + 5][N + 5];
};
Node q[N*N + 5];

int aim;
Pii X, Y;
int vis[N + 5][N + 5];

namespace SubTask1
{
	const int N = 3;

	int flag = 0;
	bool vis[1000000];

	void DFS_calc(int step, int Limit)
	{
		if (step > Limit) return ;

		int val = 0;
		for (int i = 1; i <= n; ++i){
			for (int j = 1; j <= m; ++j){
				val = (val << 1) | A0[i][j];
			}
		}
		if (val == aim){
			flag = 1;
			return ;
		}
		if (vis[val]) return ;
		vis[val] = true;

		for (int x = 1; x <= n; ++x){
			for (int y = 1; y <= m; ++y){
				for (int i = 0; i < 3; ++i)
					for (int j = 0; j < 3; ++j){
						if ((!dx[i] && !dy[j])) continue;
						int _x = x + dx[i];
						int _y = y + dy[j];
						if (!A0[x][y] && !A0[_x][_y]) continue;
						if (A0[x][y] && A0[_x][_y]) continue;
						if (!B[_x][_y]) continue;
						B[_x][_y] --;
						std::swap(A0[x][y], A0[_x][_y]);
						DFS_calc(step + 1, Limit);
						std::swap(A0[x][y], A0[_x][_y]);
						B[_x][_y] ++;
					}
			}
		}

		vis[val] = false;
	}

	void Exec()
	{
		if (c0 != c1){
			printf("%d\n", -1);
			return ;
		}
		for (int Limit = 0; Limit <= 7; ++Limit){
			DFS_calc(0, Limit);
			if (flag){
				printf("%d\n", Limit);
				return ;
			}
		}
		printf("%d\n", -1);
	}
}

namespace SubTask2
{
	int ans = inf, flag = 0;
	int vis[N + 5][N + 5];
	void DFS_calc(int x, int y, int step)
	{
		if (step >= ans) return ;

		if (x == Y.first && y == Y.second){
			flag = 1;
			chkmin(ans, step);
			return ;
		}
		if (vis[x][y]) return ;
		vis[x][y] = true;

		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j){
				if ((!dx[i] && !dy[j])) continue;
				int _x = x + dx[i];
				int _y = y + dy[j];
				if (!B[_x][_y]) continue;
				B[_x][_y] --;
				DFS_calc(_x, _y, step + 1);
				B[_x][_y] ++;
			}

		vis[x][y] = false;
	}

	void Exec()
	{
		if (c0 != c1){
			printf("%d\n", -1);
			return ;
		}
		DFS_calc(X.first, X.second, 0);
		printf("%d\n", flag? ans : -1);
	}
}

bool Init()
{
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i){
		for (int j = 1; j <= m; ++j){
			scanf("%1d", &A0[i][j]);
			c0 += A0[i][j];
		}
	}
	for (int i = 1; i <= n; ++i){
		for (int j = 1; j <= m; ++j){
			scanf("%1d", &A1[i][j]);
			aim = (aim << 1) | A1[i][j];
			c1 += A1[i][j];
		}
	}
	for (int i = 1; i <= n; ++i){
		for (int j = 1; j <= m; ++j){
			scanf("%1d", &B[i][j]);
		}
	}
	for (int i = 1; i <= n; ++i){
		for (int j = 1; j <= m; ++j){
			if (A0[i][j]) X = Pii(i, j);
			if (A1[i][j]) Y = Pii(i, j);
		}
	}
	return n <= 3 && m <= 3;
}

int main()
{
	freopen("pipes.in", "r", stdin);
	freopen("pipes.out", "w", stdout);

	if (!Init()){
		SubTask1 :: Exec();
	}
	else 
		SubTask2 :: Exec();

	return 0;
}
