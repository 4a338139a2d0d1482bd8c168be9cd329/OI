#include<bits/stdc++.h>
using namespace std;

const int INF =	1000000000;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int m, Q;
int p[100010], n;
vector<int> l;

int main() {
	freopen("brunhilda.in", "r", stdin);
	freopen("brunhilda.out", "w", stdout);
	
	int i, M = 1;
	l.push_back(M);
	m = read(), Q = read();
	generate(p+1, p+m+1, read);
	while(M <= 10000000) {
		int nxt = -1;
		for(i = 1; i <= m; i++) {
			if(M % p[i] == 0) continue;
			nxt = max(nxt, (M/p[i]+1)*p[i]);
		}
		if(nxt == -1) break;
		l.push_back(M = nxt);
	}
	while(Q--) {
		n = read();
		n = upper_bound(l.begin(), l.end(), n)-l.begin();
		if(n == (int)l.size()) {
			if(l.back() <= 10000000) printf("oo\n");
			else printf("%d\n", n);
		}
		else printf("%d\n", n);
	}
	return 0;
}
