#include<bits/stdc++.h>
using namespace std;

bool np[10000010];
int p[10000010], cnt;

inline void getprime() {
	int i, j;
	for(i = 2; i <= 100000; i++) {
		if(!np[i]) p[++cnt] = i;
		for(j = 1; j <= cnt && p[j]*i <= 100000; j++) {
			np[p[j]*i] = true;
			if(i % p[j] == 0) break;
		}
	}
}

int main() {
	getprime();
	for(int i = 1; i<= cnt; i++)
		printf("%d, ", p[i]);
	/*long long ans = 0;
	for(int i = 1; i <= cnt; i++)
		ans += (10000000/p[i]);
	printf("%lld\n", ans);*/
	return 0;
}
