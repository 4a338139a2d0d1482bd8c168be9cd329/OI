#include<bits/stdc++.h>
using namespace std;

const int INF =	1000000000;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int m, Q, ans[10001];
int p[10001], n;

int main() {
	freopen("brunhilda.in", "r", stdin);
	freopen("bf.out", "w", stdout);
	
	int i, j;
	m = read(), Q = read();
	generate(p+1, p+m+1, read);
	for(i = 1; i <= 10000; i++) {
		ans[i] = INF;
		for(j = 1; j <= m; j++) 
			ans[i] = min(ans[i], ans[i-i%p[j]]+1);
	}
	/*for(i = 1; i <= 10000; i++) printf("%d\n", ans[i]);
	printf("\n");*/
	while(Q--) {
		n = read();
		if(ans[n] == INF) printf("oo\n");
		else printf("%d\n", ans[n]);
	}
	return 0;
}
