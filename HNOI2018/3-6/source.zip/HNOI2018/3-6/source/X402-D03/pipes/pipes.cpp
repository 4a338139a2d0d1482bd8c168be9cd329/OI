#include<bits/stdc++.h>
using namespace std;

const int INF = 1000000000;
const int MAXN = 1010;

int dr[8][2] = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};

int st[MAXN], to[16*MAXN], w[16*MAXN];
int nxt[16*MAXN], e = 1, c[16*MAXN];
inline void Add(int u, int v, int C, int W) {
	//printf("%d %d %d %d\n", u, v, C, W);
	to[++e] = v, nxt[e] = st[u];
	c[e] = C, w[e] = W, st[u] = e;
	to[++e] = u, nxt[e] = st[v];
	c[e] = 0, w[e] = -W, st[v] = e;
}

int n, S, T, ans, flow;
int dis[MAXN], pre[MAXN];
bool inq[MAXN];
queue<int> q;

inline bool SPFA() {
	int i;
	for(i = 1; i <= n; i++) dis[i] = INF, pre[i] = 0, inq[i] = false;
	dis[S] = 0, inq[S] = true;
	q.push(S);
	while(!q.empty()) {
		int u = q.front();
		//printf(">> %d\n", u);
		q.pop(),  inq[u] = false;
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(inq[v]) continue;
			if(c[i] > 0 && dis[v] > dis[u]+w[i]) {
				dis[v] = dis[u]+w[i];
				pre[v] = i;
				if(!inq[v]) q.push(v), inq[v] = true;
			}
		}
	}
	return dis[T] != INF;
}

inline void Aug() {
	int x = T, minc = INF;
	while(x != S) {
		minc = min(minc, c[pre[x]]);
		x = to[pre[x]^1];
	}
	//printf("::: %d\n", minc);
	flow -= minc;
	x = T;
	while(x != S) {
		ans += minc*w[pre[x]];
		c[pre[x]] -= minc;
		c[pre[x]^1] += minc;
		x = to[pre[x]^1];
	}
}

int N, M;
char a[25][25], b[25][25], s[25];
int C[25][25];

int main() {
	freopen("pipes.in", "r", stdin);
	freopen("pipes.out", "w", stdout);

	int i, j, k;
	cin >> N >> M;
	//cout << N << ' ' << M << endl;
	S = N*M*2+1, n = T = S+1;
	for(i = 1; i <= N; i++)
		scanf("%s", a[i]+1);
	for(i = 1; i <= N; i++)
		scanf("%s", b[i]+1);
	for(i = 1; i <= N; i++) {
		scanf("%s", s+1);
		for(j = 1; j <= M; j++) {
			if(s[j] == 'z') C[i][j] = 74;
			else C[i][j] = s[j]-'0';
		}
	}
	for(i = 1; i <= N; i++)
		for(j = 1; j <= M; j++)
			if(a[i][j] == '1' && b[i][j] == '1') a[i][j] = '0', b[i][j] = '0';
	for(i = 1; i <= N; i++)
		for(j = 1; j <= M; j++) {
			if(a[i][j] == '1') {
				flow++;
				C[i][j]--;
				Add(S, (i-1)*M+j+N*M, 1, 0);
			}
			if(b[i][j] == '1') {
				C[i][j]--;
				Add((i-1)*M+j, T, 1, 0);
			}
		}
	/*for(i = 1; i <= N; i++) printf("%s\n", b[i]+1);
	return 0;*/
	for(i = 1; i <= N; i++)
		for(j = 1; j <= M; j++) {
			if(C[i][j] < 0) {
				printf("-1\n");
				return 0;
			}
			Add((i-1)*M+j, (i-1)*M+j+N*M, C[i][j]>>1, 0);
		}
	for(i = 1; i <= N; i++) 
		for(j = 1; j <= M; j++) 
			for(k = 0; k < 8; k++) {
				int nx = i+dr[k][0], ny = j+dr[k][1];
				if(nx < 1 || nx > N || ny < 1 || ny > M) continue;
				Add((i-1)*M+j+N*M, (nx-1)*M+ny, INF, 1);
			}
	while(SPFA()) {
		//printf("!!\n");
		Aug();
	}
	//printf("%d %d\n", flow, ans);
	if(flow != 0) printf("-1\n");
	else printf("%d\n", ans);
	return 0;
}
