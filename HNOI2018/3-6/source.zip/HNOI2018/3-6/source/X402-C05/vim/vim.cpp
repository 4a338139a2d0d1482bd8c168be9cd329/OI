#include<bits/stdc++.h>
using namespace std;
const int maxn=7e4+10;
int n;
char s[maxn];
struct data{
	int id,step,cnt;
	friend bool operator < (data a,data b){
		return a.step>b.step;
	}
};
priority_queue<data> Q;

vector<int> zero;

int pre[maxn],nxt[maxn];
int nx[10][maxn];
int rid[maxn],cnt;

vector<int> id;

void solve(){
	scanf("%d%s",&n,s+1);
	for(int i=1;i<=n;++i){
		pre[i]=i-1;
		nxt[i]=i+1;
		if(s[i]=='e'){
			id.push_back(i);
			rid[i]=id.size()-1;
			++cnt;
		}
	}
	
	for(int j=n;j;--j){
		for(int i=0;i<10;++i){
			nx[i][j]=nx[i][j+1];
			if(s[j+1]=='a'+i)nx[i][j]=j+1;
		}
	}
	
	Q.push((data){1,0,0});
	
	for(data u;!Q.empty();){
		u=Q.top();Q.pop();
		//if(mp.count(u))continue;
		//mp[u]=1;
		if(u.cnt==cnt){
			cout<<u.step+1<<endl;
			exit(0);
		}
		if(s[u.id]=='e'){
			if(nxt[u.id]<=n)Q.push((data){nxt[u.id],u.step+1,u.cnt+1});
			pre[nxt[u.id]]=pre[u.id];
			nxt[pre[u.id]]=nxt[u.id];
		}
		if(pre[u.id]>0)Q.push((data){pre[u.id],u.step+1,u.cnt});
		for(int i=0;i<10;++i){
			if(nx[i][u.id]<=n)Q.push((data){nx[i][u.id],u.step+2,u.cnt});
		}
	}
}
int main(){
	freopen("vim.in","r",stdin);freopen("vim.out","w",stdout);
	solve();
	
	return 0;
}
