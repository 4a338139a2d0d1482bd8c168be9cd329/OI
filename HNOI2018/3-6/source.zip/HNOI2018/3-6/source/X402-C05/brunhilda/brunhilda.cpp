#include<bits/stdc++.h>
#define For(i,a,b) for(int i=(a),i_end=(b);i<=i_end;++i)
using namespace std;
typedef long long ll;

template<typename T>T read(){
	T x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
	return x*f;
}

template<typename T>void wrote(T x){
	if(x<=0)return;
	wrote(x/10);
	putchar(x%10+48);
}

template<typename T>void write(T x){
	if(!x)putchar('0');
	else if(x<0)putchar('-'),wrote(-x);
	else wrote(x);
}

const int maxn=1e5+10,maxm=1e7;
int n,m,q,p[maxn];
ll lim,tmp;

namespace solver{
int ans[maxm+10];
struct data{
	int id,step;
	friend bool operator < (data a,data b){
		if(a.step!=b.step)return a.step>b.step;
		return a.id>b.id;
	}
};
priority_queue<data> Q;
vector<int> v[maxm+10];
bool vis[maxm+10];
void solve(){
	//scanf("%d%d",&m,&q);
	m=read<int>();
	q=read<int>();
	lim=1;
	for(int i=1;i<=m;++i){
		p[i]=read<int>();
		//scanf("%d",p+i);
		if(1ll*lim*p[i]<1e7){lim=lim*p[i];}
		else lim=lim*p[i];
	}
	lim=min(lim-1,1ll*maxm);
	
	for(int i=1;i<=m;++i){
		for(int j=0;j<=lim;j+=p[i]){
			v[j].push_back(p[i]);
		}
	}
	Q.push((data){0,0});
	for(data u;!Q.empty();){
		u=Q.top();Q.pop();
		for(int i=0,vv;i<v[u.id].size();++i){
			vv=v[u.id][i];
			for(int j=1;j<vv;++j){
				if(!vis[u.id+j]){
					vis[u.id+j]=1;
					Q.push((data){u.id+j,u.step+1});
					ans[u.id+j]=u.step+1;
				}
			}
		}
	}
	for(;q--;){
		n=read<int>();
		//scanf("%d",&n);
		if(lim<n)puts("oo");
		else write(ans[n]),puts("");//printf("%d\n",ans[n]);
	}
}
}
void work(){
	scanf("%d%d",&m,&q);
	lim=1;
	for(int i=1;i<=m;++i){
		scanf("%d",p+i);
		if(1ll*lim*p[i]<1e7){lim=lim*p[i];}
		else lim=lim*p[i];
	}
	lim=min(lim,1ll*maxm);
	sort(p+1,p+m+1,greater<int>());
	for(;q--;){
		scanf("%d",&n);
		if(lim<=n)puts("oo");
		else printf("%d\n",(n/p[1])*2+((n%p[1])?1:0));
		//else printf("%d\n",ans[n]);
	}
}
int main(){
	freopen("brunhilda.in","r",stdin);freopen("brunhilda.out","w",stdout);
	
	solver::solve();
	//work();
	
	return 0;
}
/*
2 2
2 3
5
6

3 456
2 3 5
25
31

2 456
11 13
120
*/
