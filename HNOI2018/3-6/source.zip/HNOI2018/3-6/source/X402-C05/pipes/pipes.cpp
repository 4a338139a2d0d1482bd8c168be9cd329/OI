#include<bits/stdc++.h>
using namespace std;
const int N=30;
int n,m,flag;
char st[N][N],ed[N][N],g[N][N];

namespace work1{
	int sx,sy,ex,ey;
	struct data{
		int x,y,step;
		friend bool operator < (data a,data b){
			return a.step>b.step;
		}
	};
	const int dx[]={0,0,1,-1,1,1,-1,-1};
	const int dy[]={1,-1,0,0,-1,1,1,-1};
	bool vis[N][N];
	priority_queue<data> Q;
	void solve(){
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(st[i][j]=='1'){
					sx=i;sy=j;
				}
			}
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(ed[i][j]=='1'){
					ex=i;ey=j;
				}
			}
		}
		
		Q.push((data){sx,sy,0});
		vis[sx][sy]=0;
		for(data u;!Q.empty();){
			u=Q.top();Q.pop();
			if(u.x==ex&&u.y==ey){
				cout<<u.step<<endl;
				exit(0);
			}
			for(int i=0,tx,ty;i<8;++i){
				tx=u.x+dx[i];ty=u.y+dy[i];
				if(tx<=0||tx>n||ty>m||ty<=0||vis[tx][ty])continue;
				if(g[tx][ty]=='0')continue;
				vis[tx][ty]=1;
				Q.push((data){tx,ty,u.step+1});
			}
		}
	}
}
namespace work4{
	int a[N],b[N];
	struct data{
		int x,y;
	};
	int G[N][N],vis[N];
	vector<data> A,B;
	int dfs(int u){
		return 0;//tmd,i forgot it!!!
	}
	void solve(){
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(st[i][j]=='1')A.push_back((data){i,j});
				if(ed[i][j]=='1')B.push_back((data){i,j});
			}
		}
		for(int i=0;i<A.size();++i){
			for(int j=0;j<B.size();++j){
				G[i][j]=max(abs(A[i].x-B[j].x),abs(A[i].y-B[j].y));
			}
		}
		int ans=0;
		for(int i=0;i<A.size();++i){
			memset(vis,0,sizeof vis);
			ans+=dfs(1);
		}
		cout<<ans<<endl;
	}
}
void solve(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i){
		scanf("%s",st[i]+1);
	}
	for(int i=1;i<=n;++i){
		scanf("%s",ed[i]+1);
	}
	for(int i=1;i<=n;++i){
		scanf("%s",g[i]+1);
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			if(st[i][j]=='1')++flag;
		}
	}
	if(flag==1)work1::solve();
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			if(g[i][j]=='z'){
				flag=4;break;
			}
		}
	}
	if(flag==4)work4::solve();
	
}
int main(){
	freopen("pipes.in","r",stdin);freopen("pipes.out","w",stdout);
	solve();
	
	return 0;
}
