#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	int tlen;
	t[tlen=1]=c;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
typedef long long ll;
typedef double lf;
#define pb push_back
const int maxn=305,maxm=1005,mod=1004535809;
int n,m,w[maxn],tot;
int dp[2][maxn][maxm];
int S[maxn][maxn];
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
	if(x<0)x+=mod;
}
void init(){
	S[0][0]=1;
	REP(i,1,n)
		REP(j,1,i)
			S[i][j]=(S[i-1][j-1]+1ll*S[i-1][j]*j%mod)%mod;
	REP(i,1,n)add(tot,S[n][i]);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("division.in","r",stdin);
	freopen("division.out","w",stdout);
#endif
	scanf("%d%d",&n,&m);
	init();
	REP(i,1,n)scanf("%d",&w[i]);
	sort(w+1,w+1+n);
	dp[0][0][0]=1;
	REP(i,1,n){
		bool t=i&1;
		memset(dp[t],0,sizeof(dp[t]));
		REP(j,0,i-1){
			int tmp=(w[i]-w[i-1])*j;
			REP(k,0,m){
				int l=k+tmp;
				if((!dp[t^1][j][k])||(l>=m))continue;
				add(dp[t][j][l],1ll*j*dp[t^1][j][k]%mod);
				if(j)add(dp[t][j-1][l],1ll*j*dp[t^1][j][k]%mod);
				add(dp[t][j+1][l],dp[t^1][j][k]);
				add(dp[t][j][l],dp[t^1][j][k]);
			}
		}
	}
	int ans=tot;
	REP(i,0,m)add(ans,-dp[n&1][0][i]);
	printf("%d\n",ans);
	return 0;
}
