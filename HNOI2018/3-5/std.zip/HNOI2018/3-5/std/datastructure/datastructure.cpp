#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
typedef long long ll;
typedef double lf;
#define pb push_back
const int maxn=500005,mod=1004535809;
int n,m,cur;
template<typename T>void add(T &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
	if(x<0)x+=mod;
}
struct data{
	ll Max,Max2;
	int cnt,sum,sum2;
	ll tag,tag2,tag3;
	void update_up(const data &t){
		cnt+=t.cnt,add(sum,t.sum),add(sum2,t.sum2);
		chkmax(Max,t.Max),chkmax(Max2,t.Max2);
	}
	void update_down(const data &t){
		if(!cnt)return;
		chkmax(Max2,Max+t.tag3);
		chkmax(tag3,tag+t.tag3);
		Max+=t.tag,add(sum,cnt*t.tag%mod),tag+=t.tag;
		add(sum2,t.tag2*cnt%mod),add(tag2,t.tag2);
	}
	void cleardata(){
		Max=Max2=cnt=sum=sum2=0;
	}
	void cleartag(){
		tag=tag2=tag3=0;
	}
};
struct seg_tree{
	data Max[maxn<<2],Oth[maxn<<2];
	void cleardata(int p){
		Max[p].cleardata();
		Oth[p].cleardata();
	}
	void cleartag(int p){
		Max[p].cleartag();
		Oth[p].cleartag();
	}
	void push_up(int p,int u,int v){
		ll Maxval=max(Max[u].Max,Max[v].Max);
		cleardata(p);
		if(Maxval==Max[u].Max)Max[p].update_up(Max[u]);
		else Oth[p].update_up(Max[u]);
		if(Maxval==Max[v].Max)Max[p].update_up(Max[v]);
		else Oth[p].update_up(Max[v]);
		Oth[p].update_up(Oth[u]);
		Oth[p].update_up(Oth[v]);
	}
	void push_down(int p,int u,int v){
		ll Maxval=max(Max[u].Max,Max[v].Max);
		if(Max[u].Max==Maxval)Max[u].update_down(Max[p]);
		else Max[u].update_down(Oth[p]);
		if(Max[v].Max==Maxval)Max[v].update_down(Max[p]);
		else Max[v].update_down(Oth[p]);
		Oth[u].update_down(Oth[p]);
		Oth[v].update_down(Oth[p]);
		cleartag(p);
	}
	void create_tree(int p,int l,int r){
		if(l==r){
			cleardata(p);
			Max[p].Max=Max[p].Max2=Max[p].sum=read(),Max[p].cnt=1;
			return;
		}
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		create_tree(u,l,mid);
		create_tree(v,mid+1,r);
		push_up(p,u,v);
	}
	void update(int p,int l,int r,int L,int R,ll x){
		if((L<=l)&&(R>=r)){
			data t=(data){0,0,0,0,0,x,x*cur%mod,x};
			Max[p].update_down(t);
			Oth[p].update_down(t);
			return;
		}
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		push_down(p,u,v);
		if(L<=mid)update(u,l,mid,L,R,x);
		if(R>mid)update(v,mid+1,r,L,R,x);
		push_up(p,u,v);
	}
	void update_min(int p,int l,int r,int L,int R,ll x){
		if((L<=l)&&(R>=r)){
			if(Max[p].Max<=x)return;
			else if(Oth[p].Max<=x){
				x-=Max[p].Max;
				data t=(data){0,0,0,0,0,x,x%mod*cur%mod,x};
				Max[p].update_down(t);
				return;
			}
		}
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		push_down(p,u,v);
		if(L<=mid)update_min(u,l,mid,L,R,x);
		if(R>mid)update_min(v,mid+1,r,L,R,x);
		push_up(p,u,v);
	}
	int query(int p,int l,int r,int L,int R){
		if((L<=l)&&(R>=r))return (Max[p].sum+Oth[p].sum)%mod;
		int mid=(l+r)>>1,u=p<<1,v=u+1,res=0;
		push_down(p,u,v);
		if(L<=mid)add(res,query(u,l,mid,L,R));
		if(R>mid)add(res,query(v,mid+1,r,L,R));
		push_up(p,u,v);
		return res;
	}
	int query2(int p,int l,int r,int L,int R){
		if((L<=l)&&(R>=r))return (Max[p].sum2+Oth[p].sum2)%mod;
		int mid=(l+r)>>1,u=p<<1,v=u+1,res=0;
		push_down(p,u,v);
		if(L<=mid)add(res,query2(u,l,mid,L,R));
		if(R>mid)add(res,query2(v,mid+1,r,L,R));
		push_up(p,u,v);
		return res;
	}
	ll query3(int p,int l,int r,int L,int R){
		if((L<=l)&&(R>=r))return max(Max[p].Max2,Oth[p].Max2);
		ll res=0;
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		push_down(p,u,v);
		if(L<=mid)chkmax(res,query3(u,l,mid,L,R));
		if(R>mid)chkmax(res,query3(v,mid+1,r,L,R));
		push_up(p,u,v);
		return res;
	}
}T;
int main(){
#ifndef ONLINE_JUDGE
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
#endif
	n=read(),m=read();
	T.create_tree(1,1,n);
	for(cur=1;cur<=m;cur++){
		int type,l,r,x;
		type=read(),l=read(),r=read();
		if(type==1){
			x=read();
			T.update(1,1,n,l,r,x);
		}else if(type==2){
			x=read();
			T.update_min(1,1,n,l,r,x);
		}else if(type==3){
			int ans=T.query(1,1,n,l,r);
			write(ans,'\n');
		}else if(type==4){
			int ans=1ll*cur*T.query(1,1,n,l,r)%mod;
			add(ans,-T.query2(1,1,n,l,r));
			write(ans,'\n');
		}else{
			ll ans=T.query3(1,1,n,l,r);
			write(ans%mod,'\n');
		}
	}
	return 0;
}
