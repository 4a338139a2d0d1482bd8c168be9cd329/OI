#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	int tlen;
	t[tlen=1]=c;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
typedef long long ll;
typedef double lf;
#define pb push_back
const int maxn=500005,block_sz=200,sz=2500;
int n;
ll ans[maxn];
int pre[maxn];
int Begin[maxn],Next[maxn<<1],to[maxn<<1],e;
struct data{int x,y;}q[maxn];
int px[maxn],py[maxn];
namespace bitree{
	int c[sz+5][sz+5];
	void update(int x,int y,int val){
		for(int i=x;i<=sz;i+=i&-i)
			for(int j=y;j<=sz;j+=j&-j)
				c[i][j]+=val;
	}
	int query(int x,int y){
		int res=0;
		for(int i=x;i;i-=i&-i)
			for(int j=y;j;j-=j&-j)
				res+=c[i][j];
		return res;
	}
};
using namespace bitree;
void add_edge(int u,int v){
	to[++e]=v,Next[e]=Begin[u],Begin[u]=e;
}
void dfs(int u,int dep){
	if(u){
		int tx=(q[u].x-1)/block_sz+1,ty=(q[u].y-1)/block_sz+1;
		ans[u]+=dep-1+query(tx-1,ty-1)+query(tx,ty)-query(tx,sz)-query(sz,ty);
		update(tx,ty,1);
		int l=(tx-1)*block_sz+1,r=min(n,tx*block_sz);
		REP(i,l,r){
			int p=px[i];
			if(!p)continue;
			if((q[u].x>i)==(q[u].y>p))++ans[u];
		}
		REP(i,(ty-1)*block_sz+1,min(n,ty*block_sz)){
			int p=py[i];
			if(!p)continue;
			if((p>=l)&&(p<=r))continue;
			if((q[u].x>p)==(q[u].y>i))++ans[u];
		}
		px[q[u].x]=q[u].y,py[q[u].y]=q[u].x;
	}
	for(int i=Begin[u];i;i=Next[i])dfs(to[i],dep+1);
	if(u){
		int tx=(q[u].x-1)/block_sz+1,ty=(q[u].y-1)/block_sz+1;
		update(tx,ty,-1);
		px[q[u].x]=0,py[q[u].y]=0;
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
#endif
	n=read();
	REP(i,1,n)
		pre[i]=read(),q[i].x=read(),q[i].y=read(),add_edge(pre[i],i);
	dfs(0,0);
	REP(i,1,n)ans[i]+=ans[pre[i]],write(ans[i],'\n');
	return 0;
}
