#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	int tlen;
	t[tlen=1]=c;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
typedef long long ll;
typedef double lf;
#define pb push_back
const int maxn=500005;
int n;
struct data{
	int x,y,id;
	bool type;
	bool operator < (const data &A) const {
		return x<A.x;
	}
}q[maxn];
ll ans[maxn];
int pre[maxn];
int sz[maxn];
bool vis[maxn];
int Begin[maxn],Next[maxn<<1],to[maxn<<1],e;
void add_edge(int u,int v){
	to[++e]=v,Next[e]=Begin[u],Begin[u]=e;
}
void getsz(int u,int fa){
	sz[u]=1;
	for(int i=Begin[u],v;i;i=Next[i]){
		v=to[i];
		if((vis[v])||(v==fa))continue;
		getsz(v,u),sz[u]+=sz[v];
	}
}
int getroot(int u,int fa,int tot){
	int maxsz=tot-sz[u],res;
	for(int i=Begin[u],v;i;i=Next[i]){
		v=to[i];
		if((vis[v])||(v==fa))continue;
		if(res=getroot(v,u,tot))return res;
		chkmax(maxsz,sz[v]);
	}return (maxsz<=tot/2)?u:0;
}
data a[maxn];
int m;
void dfs(int u,int fa){
	a[++m]=q[u],a[m].type=1,a[m].id=u;
	for(int i=Begin[u],v;i;i=Next[i]){
		v=to[i];
		if((vis[v])||(v==fa))continue;
		dfs(v,u);
	}
}
bool cmp(const int &x,const int &y){
	return a[x].x<a[y].x;
}
struct bitree{
	int c[maxn];
	void add(int x,int val){
		while(x<=n)
			c[x]+=val,x+=x&-x;
	}
	int query(int x){
		int res=0;
		while(x)
			res+=c[x],x-=x&-x;
		return res;
	}
}T;
void solve(int u){
	getsz(u,0);
	u=getroot(u,0,sz[u]);
	m=0;
	for(int p=u;(p)&&(!vis[p]);p=pre[p])
		a[++m]=q[p],a[m].type=0,a[m].id=p;
	vis[u]=1;
	dfs(u,pre[u]);
	sort(a+1,a+1+m);
	REP(i,1,m){
		if(a[i].type==0)T.add(a[i].y,1);
		else ans[a[i].id]+=T.query(a[i].y-1);
	}
	REP(i,1,m)if(a[i].type==0)T.add(a[i].y,-1);
	int cnt=0;
	DREP(i,m,1){
		if(a[i].type==0)T.add(a[i].y,1),++cnt;
		else ans[a[i].id]+=cnt-T.query(a[i].y);
	}
	REP(i,1,m)if(a[i].type==0)T.add(a[i].y,-1);
	for(int i=Begin[u],v;i;i=Next[i]){
		v=to[i];
		if(!vis[v])solve(v);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
#endif
	n=read();
	REP(i,1,n){
		pre[i]=read(),q[i].x=read(),q[i].y=read();
		add_edge(pre[i],i);
		if(pre[i])add_edge(i,pre[i]);
	}
	for(int i=Begin[0];i;i=Next[i])solve(to[i]);
	REP(i,1,n)ans[i]+=ans[pre[i]],write(ans[i],'\n');
	return 0;
}
