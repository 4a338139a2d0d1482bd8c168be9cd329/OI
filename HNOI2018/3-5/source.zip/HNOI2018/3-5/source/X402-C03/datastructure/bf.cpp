#include<bits/stdc++.h>

typedef long long ll;
template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}
inline int rui(){int x;char c;while(!isdigit(c=getchar()));x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return x;}
inline int rsi(){int x;bool f=false;char c;while(!isdigit(c=getchar()))if(c=='-')f=true;x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return f?-x:x;}
inline ll rul(){ll x;char c;while(!isdigit(c=getchar()));x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return x;}
inline ll rsl(){ll x;bool f=false;char c;while(!isdigit(c=getchar()))if(c=='-')f=true;x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return f?-x:x;}
template<typename t>void write_(t x){if(x>9)write_(x/10);putchar(x%10+48);}
template<typename t>inline void wu(t x){write_(x);}	   
template<typename t>inline void ws(t x){if(x<0)putchar('-'),write_(-x);else write_(x);}
template<typename t>inline void wu(t x,char c){write_(x);putchar(c);}
template<typename t>inline void ws(t x,char c){if(x<0)putchar('-'),write_(-x);else write_(x);putchar(c);}
inline void wstr(const char*s){while(*s)putchar(*s++);}
inline void wstr(const char*s,char c){while(*s)putchar(*s++);putchar(c);}
//inline void chkt(){fprintf(stderr,"Time:\t%f s\n",(double)clock()/CLOCKS_PER_SEC);}
//inline void chkm(){FILE*f=fopen("/proc/self/status","r");char c;for(int t=12;t;)if(fgetc(f)==' ')--t;fprintf(stderr,"VmPeak:\t");while((c=fgetc(f))!=' ')fputc(c,stderr);fprintf(stderr," kB\n");fclose(f);}
//#define err(...) fprintf(stderr,__VA_ARGS__)

const int maxn=2e5+10,mod=1004535809;
int n,m;
ll a[maxn];

int main(){
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%lld",&a[i]);
	while(m--){
		int type,l,r;
		scanf("%d%d%d",&type,&l,&r);
		if(type==1){
			int v;scanf("%d",&v);
			for(int i=l;i<=r;++i)
				a[i]=a[i]+v;
		}
		else if(type==3){
			ll sum=0;
			for(int i=l;i<=r;++i)
				sum=(sum+a[i])%mod;
			printf("%lld\n",sum);
		}
		else if(type==5){
			ll max=0;
			for(int i=l;i<=r;++i)
				max=max_(max,a[i]);
			printf("%lld\n",max%mod);
		}
	}
	return 0;
}

