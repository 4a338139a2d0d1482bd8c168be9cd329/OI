#include<bits/stdc++.h>

typedef long long ll;
template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}
inline int rui(){int x;char c;while(!isdigit(c=getchar()));x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return x;}
inline int rsi(){int x;bool f=false;char c;while(!isdigit(c=getchar()))if(c=='-')f=true;x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return f?-x:x;}
inline ll rul(){ll x;char c;while(!isdigit(c=getchar()));x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return x;}
inline ll rsl(){ll x;bool f=false;char c;while(!isdigit(c=getchar()))if(c=='-')f=true;x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return f?-x:x;}
template<typename t>void write_(t x){if(x>9)write_(x/10);putchar(x%10+48);}
template<typename t>inline void wu(t x){write_(x);}	   
template<typename t>inline void ws(t x){if(x<0)putchar('-'),write_(-x);else write_(x);}
template<typename t>inline void wu(t x,char c){write_(x);putchar(c);}
template<typename t>inline void ws(t x,char c){if(x<0)putchar('-'),write_(-x);else write_(x);putchar(c);}
inline void wstr(const char*s){while(*s)putchar(*s++);}
inline void wstr(const char*s,char c){while(*s)putchar(*s++);putchar(c);}
//inline void chkt(){fprintf(stderr,"Time:\t%f s\n",(double)clock()/CLOCKS_PER_SEC);}
//inline void chkm(){FILE*f=fopen("/proc/self/status","r");char c;for(int t=12;t;)if(fgetc(f)==' ')--t;fprintf(stderr,"VmPeak:\t");while((c=fgetc(f))!=' ')fputc(c,stderr);fprintf(stderr," kB\n");fclose(f);}
//#define err(...) fprintf(stderr,__VA_ARGS__)

const int maxn=2e5+10,mod=1004535809;
int n,m;
int sum[maxn<<2];ll tag[maxn<<2],max[maxn<<2];

inline void push_up(int rt){
	sum[rt]=(sum[rt<<1]+sum[rt<<1|1])%mod;
	max[rt]=max_(max[rt<<1],max[rt<<1|1]);
}
inline void push_down(int rt,int l,int mid,int r){
	if(tag[rt]){
		tag[rt<<1]=tag[rt<<1]+tag[rt];
		sum[rt<<1]=(sum[rt<<1]+tag[rt]%mod*(mid-l+1))%mod;
		max[rt<<1]=max[rt<<1]+tag[rt];
		tag[rt<<1|1]=tag[rt<<1|1]+tag[rt];
		sum[rt<<1|1]=(sum[rt<<1|1]+tag[rt]%mod*(r-mid))%mod;
		max[rt<<1|1]=max[rt<<1|1]+tag[rt];
		tag[rt]=0;
	}
}
void build(int rt,int l,int r){
	if(l==r){
		sum[rt]=max[rt]=rui();
		return;
	}
	int mid=l+r>>1;
	build(rt<<1,l,mid);
	build(rt<<1|1,mid+1,r);
	push_up(rt);
}
void modify(int rt,int l,int r,int x,int y,int v){
	if(l==x&&r==y){
		tag[rt]=tag[rt]+v;
		sum[rt]=(sum[rt]+(ll)v*(r-l+1))%mod;
		max[rt]=max[rt]+v;
		return;
	}
	int mid=l+r>>1;
	push_down(rt,l,mid,r);
	if(y<=mid)
		modify(rt<<1,l,mid,x,y,v);
	else if(x>mid)
		modify(rt<<1|1,mid+1,r,x,y,v);
	else{
		modify(rt<<1,l,mid,x,mid,v);
		modify(rt<<1|1,mid+1,r,mid+1,y,v);
	}
	push_up(rt);
}
int querysum(int rt,int l,int r,int x,int y){
	if(l==x&&r==y)
		return sum[rt];
	int mid=l+r>>1;
	push_down(rt,l,mid,r);
	if(y<=mid)
		return querysum(rt<<1,l,mid,x,y);
	else if(x>mid)
		return querysum(rt<<1|1,mid+1,r,x,y);
	else
		return (querysum(rt<<1,l,mid,x,mid)+querysum(rt<<1|1,mid+1,r,mid+1,y))%mod;
}
ll querymax(int rt,int l,int r,int x,int y){
	if(l==x&&r==y)
		return max[rt];
	int mid=l+r>>1;
	push_down(rt,l,mid,r);
	if(y<=mid)
		return querymax(rt<<1,l,mid,x,y);
	else if(x>mid)
		return querymax(rt<<1|1,mid+1,r,x,y);
	else
		return max_(querymax(rt<<1,l,mid,x,mid),querymax(rt<<1|1,mid+1,r,mid+1,y));
}

int main(){
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
	n=rui();m=rui();
	build(1,1,n);
	while(m--){
		int type=rui(),l=rui(),r=rui();
		if(type==1)
			modify(1,1,n,l,r,rui());
		else if(type==3)
			wu(querysum(1,1,n,l,r),'\n');
		else if(type==5)
			wu(querymax(1,1,n,l,r)%mod,'\n');
	}
	return 0;
}
