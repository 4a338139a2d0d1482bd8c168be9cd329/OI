#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE* f=fopen("seed","r");
	int seed;
	if(f==NULL)
		seed=time(NULL)+(clock()*clock()*clock()^123456789);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}

int main(){
	init();
	freopen("datastructure.in","w",stdout);
	int n,m;
	m=n=1e3;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;++i)
		printf("%d ",rand()%1000000000+1);
	puts("");
	while(m--){
		int type=rand()%3*2+1,l=rand()%n+1,r=rand()%n+1;
		if(l>r)swap(l,r);
		if(type==1)
			printf("1 %d %d %d\n",l,r,rand()%1000000000+1);
		else if(type==3)
			printf("3 %d %d\n",l,r);
		else
			printf("5 %d %d\n",l,r);
	}
	return 0;
}
