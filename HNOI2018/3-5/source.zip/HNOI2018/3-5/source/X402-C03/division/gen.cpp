#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE* f=fopen("seed","r");
	int seed;
	if(f==NULL)
		seed=time(NULL)+(clock()*clock()*clock()^123456789);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}

int main(){
	init();
	freopen("division.in","w",stdout);
	int n=10,m=8,w=10;
//	n=18;m=20;
	n-=rand()%n;m-=rand()%m;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;++i)
		printf("%d ",rand()%w+1);
	return 0;
}
