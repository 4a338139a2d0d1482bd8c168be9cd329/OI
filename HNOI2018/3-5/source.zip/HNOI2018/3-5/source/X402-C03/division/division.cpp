#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=300+10,mod=1004535809;
int n,m,w[maxn],tmp[maxn];
int dp[maxn][maxn];

inline int min_(int a,int b){return a<=b?a:b;}
/*
int f(int pos,int cnt){
	static int t[maxn];
	int res=0;
	if((n+1-pos)<=cnt){
		for(int i=1;i<=cnt;++i)
			t[i]=tmp[i];
		sort(t+1,t+cnt+1);
		for(int i=pos,j=1;i<=n;++i,++j)
			res+=w[i]-t[j];
		return res;
	}
	else{
		for(int i=1;i<=cnt;++i)
			t[i]=tmp[i];
		for(int i=pos;i<=n;++i)
			t[++cnt]=w[i];
		sort(t+1,t+cnt+1);
		for(int i=1,j=cnt;i<j;++i,--j)
			res+=t[j]-t[i];
		return res;
	}
}*/
int f[21][1<<18];
int dfs(int pos,int now,int cnt){
//	if(now>=m&&~dp[pos][cnt])
//		return dp[pos][cnt];
	if(~f[now][cnt])
		return f[now][cnt];
//	if(pos>n||now+f(pos,cnt)<m)
//		return 0;
	if(pos>n)
		if(now>=m)
			return 1;
		else
			return 0;
	int res=0;
	for(int i=1;i<pos;++i)
		if(cnt&1<<(i-1))
			(res+=dfs(pos+1,min_(now+w[pos]-w[i],m),cnt^(1<<i-1)^(1<<pos-1)))%=mod;
	(res+=dfs(pos+1,now,cnt^(1<<pos-1)))%=mod;
	return f[now][cnt]=res;
/*	for(int i=1;i<=cnt;++i){
		int pre=tmp[i];
		tmp[i]=w[pos];
		(res+=dfs(pos+1,now+w[pos]-pre,cnt))%=mod;
		tmp[i]=pre;
	}
	tmp[cnt+1]=w[pos];
	(res+=dfs(pos+1,now,cnt+1))%=mod;
	if(now>=m)
		dp[pos][cnt]=res;
	return res;*/
}
namespace m_1{
	ll c[maxn][maxn],s[maxn],ans;
	int main(){
		c[0][0]=1;
		for(int i=0;i<maxn;++i)
			for(int j=1;j<=i;++j)
				c[i][j]=(c[i-1][j-1]+j*c[i-1][j])%mod;
		for(int i=0;i<maxn;++i)
			for(int j=0;j<=i;++j)
				(s[i]+=c[i][j])%=mod;
		ans=1;
		for(int i=1,j;i<=n;){
			j=i;
			while(j<n&&w[j+1]==w[i])++j;
			ans=ans*s[j-i+1]%mod;
			i=j+1;
		}
		printf("%lld\n",(s[n]+mod-ans)%mod);
		exit(0);
	}
}

int main(){
	freopen("division.in","r",stdin);
	freopen("division.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&w[i]);
	sort(w+1,w+n+1);
	if(m==1)
		m_1::main();
	memset(dp,-1,sizeof(dp));
	for(int i=1;i<=n;++i)
		dp[n+1][i]=1;
	memset(f,-1,sizeof(f));
	printf("%d\n",dfs(1,0,0));
	return 0;
}
