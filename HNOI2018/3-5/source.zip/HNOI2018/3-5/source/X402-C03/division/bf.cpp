#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=300+10,mod=1004535809;
int n,m,w[maxn],tmp[maxn],ans;

void dfs(int pos,int now,int cnt){
	if(pos>n){
		if(now>=m)
			++ans;
		return;
	}
	for(int i=1;i<=cnt;++i){
		int pre=tmp[i];
		tmp[i]=w[pos];
		dfs(pos+1,now+w[pos]-pre,cnt);
		tmp[i]=pre;
	}
	tmp[cnt+1]=w[pos];
	dfs(pos+1,now,cnt+1);
}

int main(){
	freopen("division.in","r",stdin);
	freopen("division.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&w[i]);
	sort(w+1,w+n+1);
	dfs(1,0,0);
	printf("%d\n",ans);
	return 0;
}
