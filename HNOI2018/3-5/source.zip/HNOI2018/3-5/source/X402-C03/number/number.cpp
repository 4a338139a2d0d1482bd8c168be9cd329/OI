#include<bits/stdc++.h>

typedef long long ll;
template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}
inline int rui(){int x;char c;while(!isdigit(c=getchar()));x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return x;}
template<typename t>void write_(t x){if(x>9)write_(x/10);putchar(x%10+48);}
template<typename t>inline void wu(t x,char c){write_(x);putchar(c);}
template<typename t>inline void ws(t x,char c){if(x<0)putchar('-'),write_(-x);else write_(x);putchar(c);}
inline void chkt(){fprintf(stderr,"Time:\t%f s\n",(double)clock()/CLOCKS_PER_SEC);}
inline void chkm(){FILE*f=fopen("/proc/self/status","r");char c;while((c=fgetc(f))!='B')fputc(c,stderr);fclose(f);}
using namespace std;

const int maxn=5e5+10;
int t,p[maxn],x[maxn];
ll ans[maxn];
vector<int> g[maxn];

namespace yycjm{
	const int size=5e6;
	int key[size],sum[size],fa[size],ch[size][2];
	inline int newnode(){
		static int mempoint;
		return ++mempoint;
	}
	struct splay_tree{
		int root;
		inline void push_up(int pos){
			sum[pos]=1+sum[ch[pos][0]]+sum[ch[pos][1]];
		}
		inline void rotate(int pos){
			int f=fa[pos],ff=fa[f];
			if(ff)
				ch[ff][ch[ff][1]==f]=pos;
			bool tmp=ch[f][1]==pos;
			ch[f][tmp]=ch[pos][tmp^1];
			fa[ch[f][tmp]]=f;
			ch[pos][tmp^1]=f;
			fa[f]=pos;
			fa[pos]=ff;
			push_up(f);push_up(pos);
		}
		inline void splay(int pos){
			while(fa[pos]){
				int f=fa[pos],ff=fa[f];
				if(ff)
					if((ch[f][1]==pos)==(ch[ff][1]==f))
						rotate(f);
					else
						rotate(pos);
				rotate(pos);
			}
			root=pos;
		}
		inline int find(int val){
			int pos=root;
			while(true)
				if(key[pos]==val)
					return pos;
				else if(key[pos]>val)
					pos=ch[pos][0];
				else
					pos=ch[pos][1];
		}
		inline void insert(int val){
			int pos=newnode(),p=root;
			key[pos]=val;
			if(root==0){
				root=pos;
				return;
			}
			while(true)
				if(val<key[p])
					if(ch[p][0])
						p=ch[p][0];
					else{
						ch[p][0]=pos;
						fa[pos]=p;
						break;
					}
				else
					if(ch[p][1])
						p=ch[p][1];
					else{
						ch[p][1]=pos;
						fa[pos]=p;
						break;
					}
			splay(pos);
		}
		inline void erase(int val){
			int pos=find(val);
			splay(pos);
			if(ch[pos][0])
				if(ch[pos][1]){
					int l=ch[pos][0],r=ch[pos][1];
					fa[l]=fa[r]=0;
					while(ch[r][0])r=ch[r][0];
					ch[r][0]=l;fa[l]=r;
					splay(l);
				}
				else{
					root=ch[pos][0];
					fa[root]=0;
				}
			else
				if(ch[pos][1]){
					root=ch[pos][1];
					fa[root]=0;
				}
				else
					root=0;
		}
		inline int querypre(int y){
			int pos=root,p=0;
			while(pos)
				if(key[pos]<=y)
					p=pos,pos=ch[pos][1];
				else
					pos=ch[pos][0];
			if(p){
				splay(p);
				return sum[ch[p][0]]+1;
			}
			else
				return 0;
		}
		inline int querysuf(int y){
			int pos=root,p=0;
			while(pos)
				if(key[pos]>=y)
					p=pos,pos=ch[pos][0];
				else
					pos=ch[pos][1];
			if(p){
				splay(p);
				return sum[ch[p][1]]+1;
			}
			else
				return 0;
		}
	}bit[maxn];
	inline int sumpre(int pos,int val){
		int res=0;
		while(pos){
			res+=bit[pos].querypre(val);
			pos-=pos&-pos;
		}
		return res;
	}
	inline int sumsuf(int pos,int val){
		int res=0;
		while(pos){
			res+=bit[pos].querysuf(val);
			pos-=pos&-pos;
		}
		return res;
	}
	inline int add(int pos,int val){
		int res=0;
		res+=sumpre(pos-1,val-1)+sumsuf(t,val+1)-sumsuf(pos,val+1);
		while(pos<=t){
			bit[pos].insert(val);
			pos+=pos&-pos;
		}
		return res;
	}
	inline int del(int pos,int val){
		while(pos<=t){
			bit[pos].erase(val);
			pos+=pos&-pos;
		}
	}
}

void dfs(int pos,ll res){
	res+=yycjm::add(p[pos],x[pos]);
	ans[pos]=res;
	for(int i=0;i<g[pos].size();++i)
		dfs(g[pos][i],res);
	yycjm::del(p[pos],x[pos]);
}

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	t=rui();
	for(int i=1;i<=t;++i){
		g[rui()].push_back(i);
		p[i]=rui();x[i]=rui();
	}
	for(int i=0;i<g[0].size();++i)
		dfs(g[0][i],0);
	for(int i=1;i<=t;++i)
		wu(ans[i],'\n');
	return 0;
}
