#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE* f=fopen("seed","r");
	int seed;
	if(f==NULL)
		seed=time(NULL)+(clock()*clock()*clock()^123456789);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}

int a[500100],b[500100];

int main(){
	init();
	freopen("number.in","w",stdout);
	int n=5e3;
//	n=1e5;
	printf("%d\n",n);
	for(int i=1;i<=n;++i)
		a[i]=i;
	random_shuffle(a+1,a+n+1);
	for(int i=1;i<=n;++i)
		b[i]=i;
	random_shuffle(b+1,b+n+1);
	for(int i=1;i<=n;++i)
	printf("%d %d %d\n",rand()%i,a[i],b[i]);
//	printf("%d %d %d\n",i-1,a[i],b[i]);
	return 0;
}
