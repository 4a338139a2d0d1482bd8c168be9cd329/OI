#include <bits/stdc++.h>

int RandInt(int l, int r)
{
	return rand() % (r - l + 1) + l;
}

const int N = 5e5 + 5;
int x[N], p[N];

int main()
{
	freopen("number.in", "w", stdout);
	srand(time(NULL));
	int n = 5e5; printf("%d\n", n);
	for (int i = 1; i <= n; ++i){
		x[i] = i; p[i] = i;
	}
	std::random_shuffle(x + 1, x + n + 1);
	std::random_shuffle(p + 1, p + n + 1);
	for (int i = 1; i <= n; ++i)
		printf("%d %d %d\n", RandInt(0, i - 1), p[i], x[i]);
	return 0;
}
