#include <bits/stdc++.h>

using std :: set;
using std :: pair;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

typedef pair<int, int> pii;

const int N = 5e5;

int n;
long long ans[N + 5];
int t[N + 5];
int p[N + 5];
int x[N + 5];
set<pii> seq[N + 5];

namespace Bfer
{
	void main()
	{
		for (int i = 1; i <= n; ++i){
			for (auto j : seq[t[i]]){
				if (j.first < p[i] && j.second < x[i]){
					ans[i] ++;
				}
				else if (j.first > p[i] && j.second > x[i]){
					ans[i] ++;
				}
			}
			ans[i] += ans[t[i]];
			seq[i] = seq[t[i]];
			seq[i].insert(pii(p[i], x[i]));

			printf("%lld\n", ans[i]);
		}
	}
}

/*namespace BitTree
{
	//ct
	#define mid ((l + r) >> 1)
	int tot;
	int lc[(N << 2) + 5], rc[(N << 2) + 5];
	int sum[(N << 2) + 5];

	int Insert(int u, int l, int r, int x)
	{
		int h = ++tot;
		sum[h] ++;
		if (l == r) return h;
		x <= mid? lc[h] = Insert(lc[u], l, mid, x) : rc[h] = Insert(rc[u], mid + 1, r, x);
		return h;
	}

	int query(int v, int u, int l, int r, int ql, int qr)
	{
		if (ql <= l && r <= qr) return sum[h];
		return (ql <= mid? query(lc[v], lc[u], l, mid, ql, qr) : 0) + 
			(qr > mid? query(rc[v], rc[u], mid + 1, r, ql, qr) : 0);
	}
	#undef

	#define lowbit(x) (x & -x)
	int c[N];
	inline void add(int now, int v)
	{
		for (int i = now; i <= n; i += lowbit(i))
			c[i] = Insert(c[i], 1, n, v);
	}

	//i - [1, p], val - [ql, qr]
	inline int ask(int p, int ql, int qr)
	{
		int ret = 0;
		for (int i = p; i > 0; i -= lowbit(i)){
			ret += query(c[i], 1, n, ql, qr);
		}
		return ret;
	}

	void main()
	{
	}
}*/

bool Init(bool flag = true)
{
	n = read();
	for (int i = 1; i <= n; ++i){
		t[i] = read();
		p[i] = read();
		x[i] = read();
		flag &= (t[i] == i-1);
	}
	return flag;
}

int main()
{
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);

	if (!Init())
		Bfer :: main();
	else {
	//	BitTree :: main();
	// 	yycjm
	}
//	std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;

	return 0;
}
//yycjm
