#include <bits/stdc++.h>
using namespace std;

int read(int x = 0, int _f = 0)
{
	char c = getchar(); x = 0;
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

const int mod = 1004535809;

void Inc(int &a, int b)
{
	a += b;
	if (a >= mod) a -= mod;
}

const int N = 300;

int n, m, A[N + 5];
int S[N + 5][N + 5];

void StirlingInit()
{
	S[0][0] = 1;
	for (int i = 1; i <= N; ++i){
		for (int j = 1; j <= i; ++j)
			S[i][j] = (S[i-1][j-1] + 1ll * j * S[i-1][j] % mod) % mod;
	}
}

namespace SubTask1
{
	const int STAUS = 1 << 18;

	int con[STAUS + 5];
	map<int, int> dp[STAUS + 5];

	void main()
	{
		for (int s = 0; s < (1<<n); ++s){
			int Max = 0, Min = mod;
			for (int i = 1; i <= n; ++i){
				if ((s >> (i-1)) & 1){
					Max = max(Max, A[i]);
					Min = min(Min, A[i]);
				}
			}
			con[s] = Max - Min;
		}

//		int cnt = 0;
		dp[0][0] = 1;
		for (int s = 0; s < (1<<n); ++s){
//			cnt += dp[s].size();
			for (auto i : dp[s]){
				for (int sta = s; sta < (1<<n); sta = (sta+1)|s){
					if ((sta ^ s) < s) continue;
					if (i.first + con[sta^s] < m)
						Inc(dp[sta][i.first + con[sta^s]], i.second);
				}
			}
		}

		int tot = 0, del = 0;
		for (int i = 1; i <= n; ++i)
			Inc(tot, S[n][i]);
		for (auto i : dp[(1<<n)-1])
			Inc(del, i.second);
		printf("%d\n", (tot - del + mod) % mod);
	}
}

namespace SubTask2
{
	int num[1000 + 5];

	void main()
	{
		int tot = 0, del = 1;
		for (int i = 1; i <= n; ++i) Inc(tot, S[n][i]);
		for (int i = 1; i <= n; ++i) num[A[i]] ++;
		for (int v = 1; v <= 1000; ++v){
			if (!num[v]) continue;

			int ret = 0;
			for (int i = 1; i <= num[v]; ++i){
				Inc(ret, S[num[v]][i]);
			}
			del = 1ll * del * ret % mod;
		}
		printf("%d\n", (tot - del + mod) % mod);
	}
}

int main()
{
	freopen("division.in", "r", stdin);
	freopen("division.out", "w", stdout);

	StirlingInit();

	n = read(); m = read();
	for (int i = 1; i <= n; ++i){
		A[i] = read();
	}

	if (n <= 18)
		SubTask1 :: main();
	else 
		SubTask2 :: main();

//	std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;
	return 0;
}
//jmxsyyc c kb t
