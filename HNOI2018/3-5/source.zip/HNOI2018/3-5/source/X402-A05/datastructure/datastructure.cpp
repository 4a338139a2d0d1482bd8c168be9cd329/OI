#include <bits/stdc++.h>
using namespace std;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

typedef long long LL;

const int N = 2e5;
const int mod = 1004535809;
const int inf = mod + 1;

void Inc(int &a, int b)
{
	a += b;
	if (a >= mod) a -= mod;
}

int n, m;
int A[N + 5];

struct query
{
	int ty, l, r, x;
	void Input()
	{
		ty = read(); l = read(), r = read(); 
		if (ty <= 2) x = read();
	}
}q[N + 5];

struct SegmentTree
{
#define mid ((l + r) >> 1)
#define lc (h << 1)
#define rc (lc | 1)

	static const int M = N << 2;

	int sum[M + 5];
	LL addv[M + 5];
	LL Max[M + 5];

	inline void push_up(int h)
	{
		sum[h] = (sum[lc] + sum[rc]) % mod;
		Max[h] = max(Max[lc], Max[rc]);
	}
	inline void push_down(int h, int l, int r)
	{
		if (addv[h]){
			Inc(sum[lc], 1ll * (mid - l + 1) * (addv[h]%mod) % mod);
			Inc(sum[rc], 1ll * (r - mid) * (addv[h]%mod) % mod);
			addv[lc] += addv[h];
			addv[rc] += addv[h];
			Max[lc] += addv[h], Max[rc] += addv[h];
			addv[h] = 0;
		}
	}

	void modify(int h, int l, int r, int ql, int qr, int v)
	{
		if (ql <= l && r <= qr){
			Max[h] += v;
			addv[h] += v;
			Inc(sum[h], 1ll * v * (r - l + 1) % mod);
		}
		else {
			push_down(h, l, r);
			if (ql <= mid) modify(lc, l, mid, ql, qr, v);
			if (qr > mid) modify(rc, mid + 1, r, ql, qr, v);
			push_up(h);
		}
	}

	int query(int h, int l, int r, int ql, int qr)
	{
		if (ql <= l && r <= qr) return sum[h];
		push_down(h, l, r);
		return ((ql <= mid? query(lc, l, mid, ql, qr) : 0) + 
				(qr > mid? query(rc, mid + 1, r, ql, qr) : 0)) % mod;
	}
	LL AskMax(int h, int l, int r, int ql, int qr)
	{
		if (ql <= l && r <= qr) return Max[h];
		push_down(h, l, r);
		return max((ql <= mid? AskMax(lc, l, mid, ql, qr) : 0),
				(qr > mid? AskMax(rc, mid + 1, r, ql, qr) : 0));
	}

#undef mid
#undef lc
#undef rc
}Tree;

namespace SubTask1
{
	void main()
	{
		for (int i = 1; i <= n; ++i) Tree.modify(1, 1, n, i, i, A[i]);
		for (int i = 1; i <= m; ++i){
			if (q[i].ty == 1){
				Tree.modify(1, 1, n, q[i].l, q[i].r, q[i].x);
			}
			else if (q[i].ty == 2){
				//yycjm
			}
			else {
				printf("%d\n", Tree.query(1, 1, n, q[i].l, q[i].r));
			}
		}
	}
}

namespace SubTask2
{
	void main()
	{
		for (int i = 1; i <= n; ++i) Tree.modify(1, 1, n, i, i, A[i]);
		for (int i = 1; i <= m; ++i){
			if (q[i].ty == 1){
				Tree.modify(1, 1, n, q[i].l, q[i].r, q[i].x);
			}
			else if (q[i].ty == 3){
				printf("%d\n", Tree.query(1, 1, n, q[i].l, q[i].r));
			}
			else if (q[i].ty == 5){
				printf("%lld\n", Tree.AskMax(1, 1, n, q[i].l, q[i].r) % mod);
			}
		}
	}
}

bool Init(bool flag = true)
{
	n = read(), m = read();
	for (int i = 1; i <= n; ++i) A[i] = read();
	for (int i = 1; i <= m; ++i){
		q[i].Input();
		flag &= (q[i].ty <= 3);
	}
	return flag;
}

int main()
{
	freopen("datastructure.in", "r", stdin);
	freopen("datastructure.out", "w", stdout);

	if (Init()){
		SubTask1 :: main();
	}
	else {
		SubTask2 :: main();
	}

	return 0;
}
//		yycjm
//		void cover(int h, int l, int r, int ql, int qr, int v)
//		{
//			if (ql <= l && r <= qr){
//				tagv[h] = v;
//				sum[h] = 1ll * v * (r - l + 1) % mod;
//			}
//			else {
//				push_down(h, l, r);
//				if (ql <= mid) cover(lc, l, mid, ql, qr, v);
//				if (qr > mid) cover(rc, mid + 1, r, ql, qr, v);
//				push_up(h);
//			}
//		}
