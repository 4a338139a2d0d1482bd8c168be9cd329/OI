#include <bits/stdc++.h>

const int L = 1e9;

int RandInt(int l, int r)
{
	return rand() % (r - l + 1) + l;
}

int main()
{
	freopen("datastructure.in", "w", stdout);

	srand(time(NULL));
	int n = 5000, m = 6000;
	printf("%d %d\n", n, m);
	for (int i = 1; i <= n; ++i){
		printf("%d%c", RandInt(1, L), i != n? ' ':'\n');
	}
	for (int i = 1; i <= m; ++i){
		int ty = 2;
		while (ty % 2 == 0) ty = RandInt(1, 5);
		int r = RandInt(1, n);
		int l = RandInt(1, r);
		if (ty <= 2){
			int x = RandInt(1, L);
			printf("%d %d %d %d\n", ty, l, r, x);
		}
		else {
			printf("%d %d %d\n", ty, l, r);
		}
//		for (int j = 1; j <= n; ++j){
//			B[j] = (B[j] + A[j]) % mod;
//		}
	}
	return 0;
}
