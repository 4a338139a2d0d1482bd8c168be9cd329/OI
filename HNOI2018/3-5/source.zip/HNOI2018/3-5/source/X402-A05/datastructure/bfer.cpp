#include <bits/stdc++.h>
using namespace std;

const int N = 5e3;
const int mod = 1004535809;

int n, m;
int A[N + 5];
int B[N + 5];
long long C[N + 5];
long long Ai[N + 5];

int main()
{
	freopen("datastructure.in", "r", stdin);
	freopen("datastructure.ans", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i){
		scanf("%d", &A[i]);
		B[i] = A[i];
		Ai[i] = C[i] = A[i];
	}
	for (int i = 1; i <= m; ++i){
		int ty, l, r, x = 0;
		scanf("%d%d%d", &ty, &l, &r);
		if (ty <= 2){
			scanf("%d", &x);
			if (ty == 1)
				for (int j = l; j <= r; ++j){
					A[j] = (A[j] + x) % mod;
					Ai[j] += x;
				}
		}
		else if (ty == 3){
			int ans = 0;
			for (int j = l; j <= r; ++j)
				ans = (ans + A[j]) % mod;
			printf("%d\n", ans);
		}else if (ty == 5){
			long long ans = 0;
			for (int j = l; j <= r; ++j)
				ans = max(ans, C[j]);
			printf("%lld\n", ans % mod);
		}
		for (int j = 1; j <= n; ++j){
			B[j] = (B[j] + A[j]) % mod;
			C[j] = max(C[j], Ai[j]);
		}
	}
	return 0;
}
