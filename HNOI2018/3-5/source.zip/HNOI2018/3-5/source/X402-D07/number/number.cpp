#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define debug(...) fprintf(stderr,__VA_ARGS__)

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int maxn=500010,INF=0x3f3f3f3f;

int n,p[maxn],w[maxn];
vector<int> G[maxn];

int F[maxn],sz[maxn],rt,sum;
LL ans[maxn];
bool vis[maxn];

void getrt(int u,int fa){
    sz[u]=1; F[u]=0;

    for(auto v:G[u]) if(v!=fa&&!vis[v]){
        getrt(v,u); sz[u]+=sz[v];
        chkmax(F[u],sz[v]);
    }

    chkmax(F[u],sum-sz[u]);
    if(F[u]<F[rt]) rt=u;
}

namespace BIT{
    int T[maxn];

    void add(int p,int x){ for(;p<=n;p+=p&-p) T[p]+=x; }
    int sum(int p){ int ret=0; for(;p;p-=p&-p) ret+=T[p]; return ret; }
}

struct point{
    int x,y,op,id;

    point(){}
    point(int _x,int _y,int _op,int _id):x(_x),y(_y),op(_op),id(_id){}

    bool operator < (const point& rhs) const{
        return x<rhs.x||(x==rhs.x&&y==rhs.y&&op>rhs.op);
    }
} stk[maxn];

bool cmp(point a,point b){
    return a.x>b.x||(a.x==b.x&&a.y==b.y&&a.op>b.op);
}

int top;

bool find(int u,int fa,int h){
    if(u==h){
        stk[++top]=point(p[u],w[u],0,0);
        return 1;
    }

    for(auto v:G[u]) if(v!=fa&&!vis[v]&&find(v,u,h)){
        stk[++top]=point(p[u],w[u],0,0);
        return 1;
    }

    return 0;
}

void dfs(int u,int fa){
    stk[++top]=point(p[u],w[u],1,u);
    for(auto v:G[u]) if(v!=fa&&!vis[v]) dfs(v,u);
}

void solve(int u,int h){
    top=0;
    stk[++top]=point(p[u],w[u],1,u);
    stk[++top]=point(p[u],w[u],0,0);

    vis[u]=1; int special=-1;

    for(auto v:G[u]) if(!vis[v]){
        if(!find(v,-1,h)) dfs(v,-1);
        else special=v;
    }

    sort(stk+1,stk+top+1);

    for(int i=1;i<=top;i++) if(stk[i].x){
        if(stk[i].op==0) BIT::add(stk[i].y,1);
        else ans[stk[i].id]+=BIT::sum(stk[i].y-1);
    }

    for(int i=1;i<=top;i++)
        if(stk[i].op==0&&stk[i].x) BIT::add(stk[i].y,-1);

    sort(stk+1,stk+top+1,cmp);

    for(int i=1;i<=top;i++) if(stk[i].x){
        if(stk[i].op==0) BIT::add(n-stk[i].y+1,1);
        else ans[stk[i].id]+=BIT::sum(n-stk[i].y);
    }

    for(int i=1;i<=top;i++)
        if(stk[i].op==0&&stk[i].x) BIT::add(n-stk[i].y+1,-1);

    for(auto v:G[u]) if(!vis[v]){
        sum=sz[v]; rt=n+1;
        getrt(v,-1); solve(rt,v==special?h:v);
    }
}

void getans(int u,int fa){
    ans[u]+=ans[fa];
    for(auto v:G[u]) if(v!=fa) getans(v,u);
}

int main(){
    freopen("number.in","r",stdin);
    freopen("number.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++){
        int u; read(u);
        G[i].pb(u); G[u].pb(i);
        read(p[i]); read(w[i]);
    }

    F[n+1]=INF;
    sum=n; rt=n+1;
    getrt(0,-1); solve(rt,0);

    getans(0,-1);

    for(int i=1;i<=n;i++) printf("%lld\n",ans[i]);

    return 0;
}
