#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int mo=1004535809,maxn=200010,INF=0x3f3f3f3f;

int n,m;

namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    LL T[maxn<<2],add[maxn<<2],Max[maxn<<2];

    void pushup(int h){
        T[h]=T[ls]+T[rs];
        Max[h]=max(Max[ls],Max[rs]);
    }

    void pushdown(int h,int l,int r){
        if(add[h]){
            T[ls]+=1ll*add[h]*(mid-l+1);
            T[rs]+=1ll*add[h]*(r-mid);
            add[ls]+=add[h]; add[rs]+=add[h];
            Max[ls]+=add[h]; Max[rs]+=add[h];
            add[h]=0;
        }
    }

    void creat(int h,int l,int r){
        if(l==r) return void(Max[h]=read(T[h]));

        creat(ls,lc); creat(rs,rc);

        pushup(h);
    }

    void modify(int h,int l,int r,int L,int R,int w){
        if(L<=l&&r<=R){
            T[h]+=1ll*w*(r-l+1);
            add[h]+=w; Max[h]+=w;
            return;
        }

        pushdown(h,l,r);

        if(L<=mid) modify(ls,lc,L,R,w);
        if(R>mid) modify(rs,rc,L,R,w);

        pushup(h);
    }

    LL query(int h,int l,int r,int L,int R){
        if(L<=l&&r<=R) return T[h];

        pushdown(h,l,r);

        LL ret=0;
        if(L<=mid) ret+=query(ls,lc,L,R);
        if(R>mid) ret+=query(rs,rc,L,R);

        return ret;
    }

    LL qrymax(int h,int l,int r,int L,int R){
        if(L<=l&&r<=R) return Max[h];

        pushdown(h,l,r);

        LL ret=0;
        if(L<=mid) chkmax(ret,qrymax(ls,lc,L,R));
        if(R>mid) chkmax(ret,qrymax(rs,rc,L,R));

        return ret;
    }
}

using namespace SGT;

int main(){
    freopen("datastructure.in","r",stdin);
    freopen("datastructure.out","w",stdout);

    read(n); read(m);
    creat(1,1,n);

    for(int i=1;i<=m;i++){
        int op,l,r,x;
        read(op); read(l); read(r);
        if(op==1) modify(1,1,n,l,r,read(x));
        if(op==3) printf("%lld\n",query(1,1,n,l,r)%mo);
        if(op==5) printf("%lld\n",qrymax(1,1,n,l,r)%mo);
    }

    return 0;
}
