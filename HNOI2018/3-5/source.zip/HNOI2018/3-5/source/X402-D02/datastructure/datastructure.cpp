#include<iostream>
#include<cstdio>
#include<cstring>

inline void read(int &x)
{
	char c=x=0;
	int flag=1;
	for(c=getchar();!isdigit(c) && c!='-';c=getchar());
	if(c=='-')flag=-1,c=getchar();
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=flag;
}

namespace BuKeZuoTi
{
	typedef long long ll;
	const int N=201000,M=N*4,MOD=1004535809;
	const ll INF=9123372036854775807ll;

#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
	ll max[M],cntmax[M],dmax[M],sum[M],sumtag[M],maxtag[M];

	void put_chkmin(int p,ll x)
	{
		if(x>=max[p])return;
		sum[p]-=(max[p]-x)*cntmax[p];
		max[p]=x,maxtag[p]=x;
	}
	void put_sum(int p,ll x,int n)
	{
		max[p]+=x,dmax[p]+=x;
		sum[p]+=(ll)n*x;
		sumtag[p]+=x;
		if(maxtag[p])maxtag[p]+=x;
	}
	void upd(int p)
	{
		if(max[lt]==max[rt])
		{
			max[p]=max[lt];
			dmax[p]=std::max(dmax[lt],dmax[rt]);
			cntmax[p]=cntmax[lt]+cntmax[rt];
		}
		else if(max[lt]>max[rt])
		{
			max[p]=max[lt];
			dmax[p]=std::max(dmax[lt],max[rt]);
			cntmax[p]=cntmax[lt];
		}
		else 
		{
			max[p]=max[rt];
			dmax[p]=std::max(dmax[rt],max[lt]);
			cntmax[p]=cntmax[rt];
		}

		sum[p]=sum[lt]+sum[rt];
	}
	void down(int p,int L,int R)
	{
		if(sumtag[p])
		{
			put_sum(lt,sumtag[p],mid-L+1);
			put_sum(rt,sumtag[p],R-mid);
			sumtag[p]=0;
		}
		if(maxtag[p])
		{
			put_chkmin(lt,maxtag[p]);
			put_chkmin(rt,maxtag[p]);
			maxtag[p]=0;
		}
	}

	void build(int *A,int p=1,int L=1,int R=N-1)
	{
		if(L==R)
		{
			max[p]=A[L],cntmax[p]=1;
			dmax[p]=-INF;
			sum[p]=A[L];
			return;
		}
		build(A,lcq),build(A,rcq);
		upd(p);
	}

	void add(int s,int t,int x,int p=1,int L=1,int R=N-1)
	{
		if(L>=s && R<=t)
		{
			put_sum(p,x,R-L+1);
			return;
		}
		down(p,L,R);
		if(s<=mid)add(s,t,x,lcq);
		if(t>mid)add(s,t,x,rcq);
		upd(p);
	}
	void chkmin(int s,int t,int x,int p=1,int L=1,int R=N-1)
	{
//		printf("%d %d , %lld , %lld\n",L,R,max[p],dmax[p]);
		if(L>=s && R<=t && dmax[p]<x)
		{
			put_chkmin(p,x);
			return;
		}
		down(p,L,R);
		if(s<=mid)chkmin(s,t,x,lcq);
		if(t>mid)chkmin(s,t,x,rcq);
		upd(p);
	}
	ll query(int s,int t,int p=1,int L=1,int R=N-1)
	{
		if(L>=s && R<=t)return sum[p];
		down(p,L,R);
		ll ret=0;
		if(s<=mid)ret+=query(s,t,lcq);
		if(t>mid)ret+=query(s,t,rcq);
		return ret;
	}

	int n,m;
	void initialize()
	{
		static int tmp[N];
		read(n),read(m);
		for(int i=1;i<=n;i++)
			read(tmp[i]);
		build(tmp);
	}

	void solve()
	{
		initialize();
		for(int ty,l,r,x;m--;)
		{
			read(ty),read(l),read(r);
			if(ty==1)read(x),add(l,r,x);
			else if(ty==2)read(x),chkmin(l,r,x);
			else if(ty==3)printf("%lld\n",query(l,r)%MOD);
			else printf("fuck\n");
		}
	}
}

int main()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
	BuKeZuoTi::solve();
	return 0;
}
