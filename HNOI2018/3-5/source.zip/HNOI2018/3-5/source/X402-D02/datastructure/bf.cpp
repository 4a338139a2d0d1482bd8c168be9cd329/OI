#include<iostream>
#include<cstdio>
#include<cstring>

const int N=5010,MOD=1004535809;

typedef long long ll;

ll A[N],B[N],C[N];

int n,m;

void work()
{
	for(int i=1;i<=n;i++)
		B[i]=(B[i]+A[i])%MOD,C[i]=std::max(C[i],A[i]);
}
void add(int s,int t,int x)
{
	for(int i=s;i<=t;i++)
		A[i]+=x;
}
void chkmin(int s,int t,ll x)
{
	for(int i=s;i<=t;i++)
		A[i]=std::min(A[i],x);
}
int query(int s,int t)
{
	ll ret=0;
	for(int i=s;i<=t;i++)
		ret=(ret+A[i])%MOD;
	return ret%MOD;
}

int main()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.ans","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%lld",A+i);
	for(int ty,l,r,x;m--;)
	{
		scanf("%d%d%d",&ty,&l,&r);
		if(ty==1)scanf("%d",&x),add(l,r,x);
		else if(ty==2)scanf("%d",&x),chkmin(l,r,x);
		else if(ty==3)printf("%d\n",query(l,r));
		else printf("fuck\n");

		work();
	}
	return 0;
}
