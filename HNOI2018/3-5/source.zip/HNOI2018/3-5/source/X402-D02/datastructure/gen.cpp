#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int lim=10000;
int rd(){return rand()%lim+1;}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("datastructure.in","w",stdout);//look at here

	int n=5000,m=5000;
	printf("%d %d\n",n,m);

	for(int i=1;i<=n;i++)
		printf("%d ",rd());
	printf("\n");
	for(int ty,l,r;m--;)
	{
		ty=rand()%3+1;
		l=rand()%n+1,r=rand()%n+1;
		if(l>r)std::swap(l,r);
		printf("%d %d %d ",ty,l,r);
		if(ty==1 || ty==2)printf("%d ",rd());
		printf("\n");
	}

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
