#include<iostream>
#include<cstdio>
#include<cstring>
//#include<ctime>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

namespace YYC_chu_nan_ti
{
	typedef long long ll;
	const int N=500010,M=55000000;

	struct segment_tree
	{
#define lt(p) (st[p][0])
#define rt(p) (st[p][1])
		int st[M][2],w[M];
		int root[N];
		int e;
		
		inline void check(int &p){if(!p)p=++e;}
		int query(int s,int t,int p,int L=1,int R=N-1)
		{
			if(!p || w[p]==0)return 0;
			if(L>=s && R<=t)return w[p];
			register int ret=0,mid=(L+R)>>1;
			if(s<=mid)ret+=query(s,t,lt(p),L,mid);
			if(t>mid)ret+=query(s,t,rt(p),mid+1,R);
			return ret;
		}

#define lowbit(x) ((x)&(-x))
		inline void Modify(int x,int y,int z)
		{
			static int fuck[233];
			register int tot;
			tot=0;
			for(;x<N;x+=lowbit(x))
			{
				check(root[x]);
				fuck[++tot]=root[x];
			}

			register int L=1,R=N-1,mid;
			while(L!=R)
			{
				for(int i=1;i<=tot;i++)w[fuck[i]]+=z;
				mid=(L+R)>>1;

				for(int i=1;i<=tot;i++)
				{
					check(st[fuck[i]][y>mid]),
					fuck[i]=st[fuck[i]][y>mid];
				}
				if(y<=mid)R=mid;else L=mid+1;
			}
			for(int i=1;i<=tot;i++)
				w[fuck[i]]+=z;
		}
		inline int ask(int x,int s,int t)
		{
			int ret=0;
			for(;x;x-=lowbit(x))
				ret+=query(s,t,root[x]);
			return ret;
		}
		inline int Query(int x0,int x1,int y0,int y1)
		{
			static int A[233],B[233];
			static int ca,cb;

			ca=cb=0;
			for(;x1;x1-=lowbit(x1))A[++ca]=x1;
			for(x0--;x0;x0-=lowbit(x0))B[++cb]=x0;

			int ret=0;
			while(ca>0 && cb>0)
			{
				if(A[ca]<B[cb])
					ret+=query(y0,y1,root[A[ca]]),ca--;
				else if(A[ca]>B[cb])
					ret-=query(y0,y1,root[B[cb]]),cb--;
				else ca--,cb--;
			}
			while(ca>0)ret+=query(y0,y1,root[A[ca]]),ca--;
			while(cb>0)ret-=query(y0,y1,root[B[cb]]),cb--;

			return ret;
		}
	}T;

	int begin[N],next[N],to[N];
	int P[N][2];
	int n,e;
	
	void add(int x,int y)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}
	void initialize()
	{
		read(n);
		for(int i=1,x;i<=n;i++)
		{
			read(x),read(P[i][0]),read(P[i][1]);
			add(x,i);
		}
		P[0][0]=1,P[0][1]=N-1;
	}

	ll ans[N];

	int dfn=0;

	void dfs(int p,ll cnt)
	{
		T.Modify(P[p][0],P[p][1],1);
		cnt+=T.Query(P[p][0]+1,N-1,P[p][1]+1,N-1);
		cnt+=T.Query(1,P[p][0]-1,1,P[p][1]-1);
		ans[p]=cnt;

		for(register int i=begin[p];i;i=next[i])
			dfs(to[i],cnt);

		T.Modify(P[p][0],P[p][1],-1);
	}

	void solve()
	{
		initialize();
		dfs(0,0);
		for(int i=1;i<=n;i++)
			printf("%lld\n",ans[i]);
	}
}

int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	YYC_chu_nan_ti::solve();
//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
