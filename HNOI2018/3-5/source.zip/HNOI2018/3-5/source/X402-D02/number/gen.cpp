#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("number.in","w",stdout);//look at here

	int n=500000;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		printf("%d %d %d\n",rand()%i,rand()%n+1,rand()%n+1);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
