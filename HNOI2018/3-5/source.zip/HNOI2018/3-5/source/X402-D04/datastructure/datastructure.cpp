#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=200010; 
const int mod=1004535809;
const int inf=1e9;
int n, m;
int a[maxn];

void read(int& x){
	x=0; char c=getchar(); int f=1;
	while(c<'0' || c>'9'){ if(c=='-') f=-1; c=getchar(); } 
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	x*=f;
}

ll Max[maxn<<2], t[maxn<<2], se[maxn<<2], sum[maxn<<2], add[maxn<<2];
void pushup(int o){
	if(Max[o<<1]<Max[o<<1|1]){
		Max[o]=Max[o<<1|1], t[o]=t[o<<1|1];
		se[o]=max(Max[o<<1],se[o<<1|1]);
	}else if(Max[o<<1]>Max[o<<1|1]){
		Max[o]=Max[o<<1], t[o]=t[o<<1];
		se[o]=max(Max[o<<1|1],se[o<<1]);
	}else{
		Max[o]=Max[o<<1], t[o]=t[o<<1]+t[o<<1|1];
		se[o]=max(se[o<<1],se[o<<1|1]);
	}
	sum[o]=(sum[o<<1]+sum[o<<1|1])%mod;
}
void build(int o,int l,int r){
	add[o]=0;
	if(l==r){
		int x;
		read(x);
		sum[o]=Max[o]=x; t[o]=1; se[o]=-inf;
		return;
	}
	int mid=(l+r)>>1;
	build(o<<1,l,mid), build(o<<1|1,mid+1,r);
	pushup(o);
}
void get(int o,int x,int len){
	add[o]+=x; (sum[o]+=1ll*x*len%mod)%=mod; Max[o]+=x; se[o]+=x;
}
void getmin(int o,int l,int r,int x){
	sum[o]=(sum[o]-t[o]*(Max[o]-x)%mod+mod)%mod;
	Max[o]=x;
}
void pushdown(int o,int l,int r){
	int mid=(l+r)>>1;
	if(add[o]){
		//printf("add %d %d %lld\n", l, r, add[o]);
		get(o<<1,add[o],mid-l+1); get(o<<1|1, add[o],r-mid);
		add[o]=0;
	}
	if(Max[o<<1]>Max[o] && se[o<<1]<Max[o]) getmin(o<<1,l,mid,Max[o]); //
	if(Max[o<<1|1]>Max[o] && se[o<<1|1]<Max[o]) getmin(o<<1|1,mid+1,r,Max[o]); // 
}
int query(int o,int l,int r,int ql,int qr){
	if(ql<=l && qr>=r) return sum[o];
	pushdown(o,l,r);
	int mid=(l+r)>>1, ret=0;
	if(ql<=mid) ret=query(o<<1,l,mid,ql,qr); if(qr>mid) ret=(ret+query(o<<1|1,mid+1,r,ql,qr))%mod;
	return ret;
}
void modify(int o,int l,int r,int ql,int qr,int x){
	//printf("l = %d r = %d sum = %lld\n", l, r, sum[o]);
	if(ql<=l && qr>=r){
		//printf("x = %d\n", x);
		get(o,x,r-l+1);
		//printf("sum = %lld\n", sum[o]);
		//add[o]+=x; sum[o]+=x*(r-l+1);
		//printf("wu = %d\n", x*(r-l+1));
		return;
	}
	pushdown(o,l,r);
	int mid=(l+r)>>1;
	if(ql<=mid) modify(o<<1,l,mid,ql,qr,x); if(qr>mid) modify(o<<1|1,mid+1,r,ql,qr,x);
	pushup(o);
}
void chkmin(int o,int l,int r,int ql,int qr,int x){
	if(Max[o]<=x) return;
	if(ql<=l && qr>=r && x>se[o]){ getmin(o,l,r,x); return; }
	pushdown(o,l,r);
	int mid=(l+r)>>1;
	if(ql<=mid) chkmin(o<<1,l,mid,ql,qr,x); if(qr>mid) chkmin(o<<1|1,mid+1,r,ql,qr,x);
	pushup(o);
}

int main(){
	freopen("datastructure.in","r",stdin),freopen("datastructure.out","w",stdout);

	read(n), read(m);
	build(1,1,n);
	int x, l, r, op;
	while(m--){
		read(op);
		if(op==1){
			//puts("modify");
			read(l), read(r), read(x);
			modify(1,1,n,l,r,x);
		}else if(op==2){
			//puts("chkmin");
			read(l), read(r), read(x);
			chkmin(1,1,n,l,r,x);
		}else if(op==3){
			//puts("query");
			read(l), read(r);
			printf("%d\n", query(1,1,n,l,r));
		}else{
			read(l), read(r);
			printf("%d\n", query(1,1,n,l,r));
		}
		//printf("sum1 = %lld\n", sum[1]);
	}
	return 0;
}
