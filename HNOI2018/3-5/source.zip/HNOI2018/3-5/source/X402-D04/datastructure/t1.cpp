#include<bits/stdc++.h>
#define N 600005
#define lson (o<<1)
#define rson (o<<1|1)
#define inf 1<<30
using namespace std;
typedef long long ll;
int n;
inline int read(){
    int f=1,x=0;char ch;
    do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');
    do{x=x*10+ch-'0';ch=getchar();}while(ch>='0'&&ch<='9');
    return f*x;
}

int maxv[N<<2],snd_max[N<<2],cnt_max[N<<2],minv[N<<2],snd_min[N<<2],cnt_min[N<<2],tagv[N<<2];
ll sumv[N<<2];
inline void pushup(int o){ int l=o<<1,r=o<<1|1;sumv[o]=sumv[l]+sumv[r];
  if(maxv[l]==maxv[r])maxv[o]=maxv[l],cnt_max[o]=cnt_max[l]+cnt_max[r],snd_max[o]=max(snd_max[l],snd_max[r]);
  else{
    if(maxv[l]>maxv[r]) swap(l,r);maxv[o]=maxv[r]; cnt_max[o]=cnt_max[r];snd_max[o]=max(snd_max[r],maxv[l]);
  }
}
inline void puttag(int o,int l,int r,int v){
    tagv[o]+=v;sumv[o]+=(ll)(r-l+1)*v;
    minv[o]+=v;maxv[o]+=v;snd_max[o]+=v;snd_min[o]+=v;
}
inline void tmin(int o,int l,int r,int v){
    sumv[o]-=(ll)(cnt_max[o])*(maxv[o]-v);
    maxv[o]=v;minv[o]=min(v,minv[o]);
}
inline void pushdown(int o,int l,int r){
    int mid=(l+r)>>1;
    if(tagv[o]){
        puttag(lson,l,mid,tagv[o]);puttag(rson,mid+1,r,tagv[o]);
        tagv[o]=0;
    }
    if(maxv[lson]>maxv[o]&&snd_max[lson]<maxv[o])tmin(lson,l,mid,maxv[o]);
    if(maxv[rson]>maxv[o]&&snd_max[rson]<maxv[o])tmin(rson,mid+1,r,maxv[o]);
}
void build(int o,int l,int r){
    tagv[o]=0;
    if(l==r){
        int x=read();
        sumv[o]=maxv[o]=minv[o]=x;cnt_max[o]=cnt_min[o]=1;snd_max[o]=-inf;snd_min[o]=inf;tagv[o]=0;return;
    }
    int mid=(l+r)>>1;
    build(lson,l,mid);build(rson,mid+1,r);
    pushup(o);
}
void changemin(int o,int l,int r,int ql,int qr,int v){
    if(maxv[o]<=v)return;
    if(ql<=l&&r<=qr&&v>snd_max[o]){tmin(o,l,r,v);return;}
    pushdown(o,l,r);int mid=(l+r)>>1;
    if(ql<=mid)changemin(lson,l,mid,ql,qr,v);
    if(qr>mid)changemin(rson,mid+1,r,ql,qr,v);
    pushup(o);
}
void add(int o,int l,int r,int ql,int qr,int v){
    if(ql<=l&&r<=qr){puttag(o,l,r,v);return;}
    pushdown(o,l,r);int mid=(l+r)>>1;
    if(ql<=mid)add(lson,l,mid,ql,qr,v);
    if(qr>mid)add(rson,mid+1,r,ql,qr,v);
    pushup(o);
}
ll querysum(int o,int l,int r,int ql,int qr){
    if(ql<=l&&r<=qr)return sumv[o];
    pushdown(o,l,r);int mid=(l+r)>>1;ll ans=0;
    if(ql<=mid)ans+=querysum(lson,l,mid,ql,qr);
    if(qr>mid)ans+=querysum(rson,mid+1,r,ql,qr);
    return ans;
}

int main(){
    freopen("datastructure2.in", "r", stdin);
    freopen("t.out", "w", stdout);
    n=read();
    int T=read();
	build(1,1,n);
    while(T--){
        int opt=read(),l=read(),r=read(),v;
        if(opt==1)v=read(),add(1,1,n,l,r,v);
        //if(opt==2)v=read(),changemax(1,1,n,l,r,v);
        if(opt==2)v=read(),changemin(1,1,n,l,r,v);
        if(opt==3)printf("%lld\n",querysum(1,1,n,l,r));
        //if(opt==5)printf("%d\n",querymax(1,1,n,l,r));
        //if(opt==6)printf("%d\n",querymin(1,1,n,l,r));
    }
}
