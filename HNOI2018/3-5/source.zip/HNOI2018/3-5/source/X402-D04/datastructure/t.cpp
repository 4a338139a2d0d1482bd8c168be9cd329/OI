#include<bits/stdc++.h>
using namespace std;
#define lson (o<<1)
#define rson (o<<1|1)
#define inf 1<<30

typedef long long ll;
const int mod=1004535809;
const int maxn=200010;
int n;
int read(){
	int x=0; char c=getchar(); int f=1;
	while(c<'0' || c>'9'){ if(c=='-') f=-1; c=getchar(); } 
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x*f;
}

int maxv[maxn<<2],se[maxn<<2],cnt[maxn<<2],tagv[maxn<<2];
ll sumv[maxn<<2];
void pushup(int o){ 
	int l=o<<1,r=o<<1|1;sumv[o]=sumv[l]+sumv[r];
	if(maxv[l]==maxv[r])maxv[o]=maxv[l],cnt[o]=cnt[l]+cnt[r],se[o]=max(se[l],se[r]);
	else{
		if(maxv[l]>maxv[r]) swap(l,r);
		maxv[o]=maxv[r]; cnt[o]=cnt[r];se[o]=max(se[r],maxv[l]);
	}
}
void puttag(int o,int l,int r,int v){
	tagv[o]+=v;sumv[o]+=(ll)(r-l+1)*v;
	maxv[o]+=v;se[o]+=v;
}
void tmin(int o,int l,int r,int v){
	sumv[o]-=(ll)(cnt[o])*(maxv[o]-v);
	maxv[o]=v;
}
void pushdown(int o,int l,int r){
	int mid=(l+r)>>1;
	if(tagv[o]){
		puttag(lson,l,mid,tagv[o]);puttag(rson,mid+1,r,tagv[o]);
		tagv[o]=0;
	}
	if(maxv[lson]>maxv[o]&&se[lson]<maxv[o])tmin(lson,l,mid,maxv[o]);
	if(maxv[rson]>maxv[o]&&se[rson]<maxv[o])tmin(rson,mid+1,r,maxv[o]);
}
void build(int o,int l,int r){
	tagv[o]=0;
	if(l==r){
		int x=read();
		sumv[o]=maxv[o]=x;cnt[o]==1;se[o]=-inf;tagv[o]=0;return;
	}
	int mid=(l+r)>>1;
	build(lson,l,mid);build(rson,mid+1,r);
	pushup(o);
}
void changemin(int o,int l,int r,int ql,int qr,int v){
	if(maxv[o]<=v)return;
	if(ql<=l&&r<=qr&&v>se[o]){tmin(o,l,r,v);return;}
	pushdown(o,l,r);int mid=(l+r)>>1;
	if(ql<=mid)changemin(lson,l,mid,ql,qr,v); if(qr>mid)changemin(rson,mid+1,r,ql,qr,v);
	pushup(o);
}
void add(int o,int l,int r,int ql,int qr,int v){
	if(ql<=l&&r<=qr){puttag(o,l,r,v);return;}
	pushdown(o,l,r);int mid=(l+r)>>1;
	if(ql<=mid)add(lson,l,mid,ql,qr,v); if(qr>mid)add(rson,mid+1,r,ql,qr,v);
	pushup(o);
}
ll querysum(int o,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr)return sumv[o];
	pushdown(o,l,r);int mid=(l+r)>>1;ll ans=0;
	if(ql<=mid)ans+=querysum(lson,l,mid,ql,qr); if(qr>mid)ans+=querysum(rson,mid+1,r,ql,qr);
	return ans;
}

int main(){
	//freopen("datastructure.in","r",stdin),freopen("datastructure.out","w",stdout);
	freopen("datastructure2.in","r",stdin),freopen("t.out","w",stdout);
    n=read();
    int T=read();
	build(1,1,n);
    while(T--){
        int opt=read(),l=read(),r=read(),v;
        if(opt==1)v=read(),add(1,1,n,l,r,v);
        if(opt==2)v=read(),changemin(1,1,n,l,r,v);
        if(opt==3){
			//printf("l = %d r = %d\n", l, r);
			printf("%lld\n",querysum(1,1,n,l,r)%mod);
		}
    }
}
