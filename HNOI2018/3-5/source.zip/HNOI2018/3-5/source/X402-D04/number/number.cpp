#include<bits/stdc++.h>
using namespace std;

const int maxn=500010;
int n;
int t[maxn], p[maxn], x[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
struct node{
	int x,y;
	bool operator <(const node& A)const{ return x<A.x; }
}a[maxn];

int c[maxn];
int lowbit(int x){ return x&(-x); }
void add(int x,int val){
	while(x<maxn){ c[x]+=val; x+=lowbit(x); }
}
int sum(int x){
	int ret=0;
	while(x){ ret+=c[x]; x-=lowbit(x); }
	return ret;
}

void Add(int x,int val){
	
}
void solve(){
	for(int i=1;i<=n;i++){
		Add(x[i],p[i]);
	}
}

int main(){
	freopen("number.in","r",stdin),freopen("number.out","w",stdout);

	read(n);
	int f=1;
	for(int i=1;i<=n;i++){
		read(t[i]), read(p[i]), read(x[i]);
		f &= (t[i]==i-1);
	}
	for(int i=1;i<=n;i++){
		int now=i, m=0;
		while(now){
			a[++m]=(node){p[now], x[now]};
			now=t[now];
		}
		sort(a+1,a+1+m);
		int ans=0;
		for(int j=1;j<=m;j++){
			ans+=sum(a[j].y);
			add(a[j].y,1);
		}
		for(int j=1;j<=m;j++) add(a[j].y,-1);
		printf("%d\n", ans);
	}
	return 0;
}
