#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
const int mod=1004535809;
int n, m;
int w[maxn], a[(1<<10)+10];
int dp[maxn][maxn];

void init(){
	for(int i=1;i<(1<<n);i++){
		int Min=1000, Max=0;
		for(int j=1;j<=n;j++) if(i & (1<<(j-1))){
			Min=min(Min,w[j]); Max=max(Max,w[j]);
		}
		a[i]=Max-Min;
	}
}
int get(int x){
	for(int i=1;i<=n;i++) if(!(x & (1<<(i-1)))) return i;
	return 10;
}

void solve(){
	dp[0][0]=1;
	for(int i=0;i<(1<<n);i++) for(int j=0;j<=m;j++) if(dp[i][j]){
		int s=((1<<n)-1) ^ i, p=get(i);
		for(int k=s;k;k=(k-1)&s) if(k & (1<<(p-1))){
			int mm=min(m,j+a[k]);
			(dp[i | k][mm]+=dp[i][j])%=mod;
		}
	}
	printf("%lld\n", dp[(1<<n)-1][m]);
}

int main(){
	freopen("division.in","r",stdin),freopen("division.out","w",stdout);

	scanf("%d%d", &n, &m);
	for(int i=1;i<=n;i++) scanf("%d", &w[i]);
	init();
	solve();
	return 0;
}
