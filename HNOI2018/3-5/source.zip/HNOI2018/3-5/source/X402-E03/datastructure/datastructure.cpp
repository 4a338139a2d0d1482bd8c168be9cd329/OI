#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 2e5+5, Mod = 1004535809 ;
LL n, t1[maxn*3], t2[maxn*3], tg1[maxn*3], tg2[maxn*3] ;
void push_up ( LL h ) {
	t1[h] = (t1[h<<1] + t1[h<<1|1])%Mod ;
}
void push_down ( LL h, LL len ) {
	if (tg1[h]) {
		(tg1[h<<1] += tg1[h]) %= Mod ;
		(tg1[h<<1|1] += tg1[h]) %= Mod ;
		(t1[h<<1] += (len-(len>>1))*tg1[h]%Mod) %= Mod ;
		(t1[h<<1|1] += (len>>1)*tg1[h]%Mod) %= Mod ;
		tg1[h] = 0 ;
	}
}
void create ( LL h, LL l, LL r ) {
	if (l == r) {
		Read(t1[h]) ;
		t2[h] = t1[h] ;
		return ;
	}
	LL mid = (l+r)>>1 ;
	create(h<<1, l, mid) ;
	create(h<<1|1, mid+1, r) ;
	push_up(h) ;
}
void Update1 ( LL h, LL l, LL r, LL x, LL y, LL v ) {
	if (x <= l && r <= y) {
		(t1[h] += v*(r-l+1)%Mod) %= Mod ;
		(tg1[h] += v) %= Mod ;
		return ;
	}
	LL mid = (l+r)>>1 ;
	push_down(h, r-l+1) ;
	if (y <= mid) Update1(h<<1, l, mid, x, y, v) ;
	else if (x > mid) Update1(h<<1|1, mid+1, r, x, y, v) ;
	else {
		Update1(h<<1, l, mid, x, mid, v) ;
		Update1(h<<1|1, mid+1, r, mid+1, y, v) ;
	}
	push_up(h) ;
}
LL Query ( LL h, LL l, LL r, LL x, LL y ) {
	if (x <= l && r <= y) return t1[h] ;
	LL mid = (l+r)>>1 ;
	push_down(h, r-l+1) ;
	if (y <= mid) return Query(h<<1, l, mid, x, y) ;
	else if (x > mid) return Query(h<<1|1, mid+1, r, x, y) ;
	return (Query(h<<1, l, mid, x, mid)+Query(h<<1|1, mid+1, r, mid+1, y))%Mod ;
}
int main() {
	freopen ( "datastructure.in", "r", stdin ) ;
	freopen ( "datastructure.out", "w", stdout ) ;
	LL _, l, r, x ;
	Read(n), Read(_) ;
	create(1, 1, n) ;
	while (_--) {
		Read(x) ;
		if (x == 1) {
			Read(l), Read(r), Read(x) ;
			Update1(1, 1, n, l, r, x) ;
		} else if (x == 2) {
			Read(l), Read(r), Read(x) ;
			//Update2(1, 1, n, l, r, x) ;
		} else if (x == 3) {
			Read(l), Read(r) ;
			printf ( "%lld\n", Query(1, 1, n, l, r) ) ;
		} else puts("YYCKJM") ;
	}
	return 0 ;
}
