#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 5e5+5 ;
int n, m, c[maxn] ;
void Update ( int x, int v ) {
	for ( ; x <= n ; x += (x&-x) )
		c[x] += v ;
}
int Query ( int x, int rec = 0 ) {
	for ( ; x ; x -= (x&-x) )
		rec += c[x] ;
	return rec ;
}
struct node {
	int t, p, v ;
	friend bool operator < ( node A, node B ) {
		return A.t < B.t ;
	}
} s[maxn], b[maxn] ;
LL Ans[maxn] ;
void solve ( int l, int r ) {
	if (l == r) return ;
	register int i, mid = (l+r)>>1, t1, t2 ;
	solve(l, mid), solve(mid+1, r) ;
	for ( i = l, t1 = l, t2 = mid+1 ; i <= r ; i ++ ) {
		if (t2 > r || (t1 <= mid && s[t1].p < s[t2].p)) {
			b[i] = s[t1 ++] ;
			Update(b[i].v, 1) ;
		}
		else {
			b[i] = s[t2 ++] ;
			Ans[b[i].t] += Query(b[i].v-1) ;
		}
	}
	for ( i = l ; i <= r ; i ++ ) if (b[i].t < mid) Update(b[i].v, -1) ;
	for ( i = r ; i >= l ; i -- )
		if (b[i].t < mid)
			Update(b[i].v, 1) ;
		else Ans[b[i].t] += Query(n)-Query(b[i].v) ;
	for ( i = l ; i <= r ; i ++ ) if (b[i].t < mid) Update(b[i].v, -1) ;
	for ( i = l ; i <= r ; i ++ ) s[i] = b[i] ;
}
void CDQ() {
	solve(1, n) ;
	for ( int i = 0 ; i ^ n ; i ++ ) {
		if (i) Ans[i] += Ans[i-1] ;
		printf ( "%lld\n", Ans[i] ) ;
	}
}
bool check_cdq() {
	for ( int i = 1 ; i <= n ; i ++ )
		if (s[i].t != i-1) return 0 ;
	return 1 ;
}
void Force() {
	int i, j ;
	for ( i = 1 ; i <= n ; i ++ ) {
		for ( j = s[i].t ; j ; j = s[j].t )
			if (s[j].p < s[i].p && s[j].v < s[i].v)
				++ Ans[i] ;
			else if (s[j].p > s[i].p && s[j].v > s[i].v)
				++ Ans[i] ;
		Ans[i] += Ans[s[i].t] ;
		printf ( "%lld\n", Ans[i] ) ;
	}
}
int main() {
	freopen ( "number.in", "r", stdin ) ;
	freopen ( "number.out", "w", stdout ) ;
	Read(n) ;
	int i ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(s[i].t), Read(s[i].p), Read(s[i].v) ;
	if (check_cdq()) CDQ() ;
	else Force() ;
	return 0 ;
}
