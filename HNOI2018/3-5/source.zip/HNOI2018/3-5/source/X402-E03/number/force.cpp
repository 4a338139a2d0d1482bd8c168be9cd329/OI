#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 5e5+5 ;
struct node {
	int t, p, v ;
} s[maxn] ;
int n ;
LL Ans[maxn] ;
int main() {
	freopen ( "number.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;

	Read(n) ;
	int i, j ;
	for ( i = 1 ; i <= n ; i ++ ) {
		Read(s[i].t), Read(s[i].p), Read(s[i].v) ;
		for ( j = s[i].t ; j ; j = s[j].t )
			if (s[j].p < s[i].p && s[j].v < s[i].v)
				++ Ans[i] ;
			else if (s[j].p > s[i].p && s[j].v > s[i].v)
				++ Ans[i] ;
		Ans[i] += Ans[s[i].t] ;
		printf ( "%lld\n", Ans[i] ) ;
	}
	cerr << "Force : " << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
