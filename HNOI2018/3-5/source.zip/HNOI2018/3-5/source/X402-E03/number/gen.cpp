#include <bits/stdc++.h>
using namespace std ;
const int maxn = 5e5+5 ;
struct node {
	int v, id ;
	friend bool operator < ( node A, node B ) {
		return A.v < B.v ;
	}
} s[maxn] ;
int main() {
	srand(time(0)) ;
	freopen ( "number.in", "w", stdout ) ;
	int n, i, t, p, x ;
	n = 10000 ;
	printf ( "%d\n", n ) ;
	for ( i = 1 ; i <= n ; i ++ )
		s[i].v = rand(), s[i].id = i ;
	sort(s+1, s+n+1) ;
	for ( i = 1 ; i <= n ; i ++ ) {
		printf ( "%d %d %d\n", i-1, s[i].id, s[s[i].id].id ) ;
	}
	return 0 ;
}
