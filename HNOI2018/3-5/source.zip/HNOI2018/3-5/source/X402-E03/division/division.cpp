#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 18, maxm = 20, maxw = 1001, Mod = 1004535809 ;
LL n, m, sz[maxn+5], w[maxn+5], st[maxn+5][(1<<18)+5], bt[(1<<18)+5], Min[(1<<18)+5], Max[(1<<18)+5] ;
LL f[(1<<18)+5][maxm+5][maxn+5] ;
LL Qpow ( LL a, LL b, LL rec = 1 ) {
	for ( ; b ; b >>= 1, (a *= a) %= Mod )
		if (b&1) (rec *= a) %= Mod ;
	return rec ;
}
int main() {
#ifndef ONLINE_JUDGE
	freopen ( "division.in", "r", stdin ) ;
	freopen ( "division.out", "w", stdout ) ;
#endif
	Read(n), Read(m) ;
	LL i, j, k, l, S, x, u ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(w[i]), Min[1<<(i-1)] = Max[1<<(i-1)] = w[i] ;
	S = (1<<n)-1 ;
	for ( i = 0 ; i <= S ; i ++ ) {
		bt[i] = bt[i>>1] + (i&1) ;
		st[bt[i]][++sz[bt[i]]] = i ;
	}
	for ( i = 1 ; i <= n ; i ++ ) {
		for ( j = 1 ; j <= sz[i] ; j ++ ) {
			x = st[i][j] ;
			for ( l = 1 ; l <= n ; l ++ ) {
				u = x^(1<<(l-1)) ;
				if (u&(1<<(l-1))) {
					Max[u] = max(Max[x], w[l]) ;
					Min[u] = min(Min[x], w[l]) ;
				}
			}
		}
	}
	f[0][0][0] = 1 ;
	for ( i = 1 ; i <= n ; i ++ ) {
		for ( j = 1 ; j <= sz[i] ; j ++ ) {
			x = st[i][j] ;
			for ( u = x ; u ; u = x&(u-1) )
				for ( l = 0 ; l <= m ; l ++ )
					for ( k = 0 ; k <= n ; k ++ ) {
					(f[x][min(m, l+Max[u]-Min[u])][k+1] += f[x^u][l][k]) %= Mod ;
				}
		}
	}
	LL ans = 0, fac = 1 ;
	for ( i = 1 ; i <= n ; i ++ )
		(fac *= i) %= Mod ;
	fac = Qpow(fac, Mod-2) ;
	for ( i = n ; i ; i -- ) {
		(ans += f[S][m][i]*fac%Mod) %= Mod ;
		(fac *= i) %= Mod ;
	}
	cout << ans << endl ;
	return 0 ;
}
