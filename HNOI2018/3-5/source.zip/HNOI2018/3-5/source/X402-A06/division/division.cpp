#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m, w[maxn], val[(1 << 18) + 10];

void Get() {
	n = read(), m = read();
	For(i, 1, n) w[i] = read();
}

const int mod = 1004535809;

int dp[(1 << 18) + 10][22];

int link[2010][2010];

void solve_bf() {
	int tmp = (1 << n) - 1;
	For(i, 1, tmp) {
		int Min = inf, Max = 0;
		For(j, 1, n) {
			if(i & (1 << j-1) ) {
				Min = min(Min, w[j]);
				Max = max(Max, w[j]);
			}
		}
		val[i] = Max - Min;
	}

	dp[0][0] = 1;
	For(i, 1, tmp) {
		for(int j = i;j ;j = ( (j-1)&i) ) {
			if(!link[j][i^j] && !link[i^j][j]){
				link[j][i^j] = link[i^j][j] = 1;
			}
			else{
				link[j][i^j] = link[i^j][j] = 0;
				continue;
			}

			For(k, 0, m) {
				(dp[i][min(k+val[j], m)] += dp[i^j][k]) %= mod;
			}
		}
	}

	printf("%d\n", dp[tmp][m]);
}

int main () {

	freopen("division.in", "r", stdin);
	freopen("division.out", "w", stdout);
	
	Get();
	solve_bf();

	return 0;
}
