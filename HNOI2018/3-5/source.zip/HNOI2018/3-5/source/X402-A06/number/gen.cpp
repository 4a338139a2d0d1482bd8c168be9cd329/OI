#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

const int maxn = 100010;

const int maxm = 100000;

int a[maxn], b[maxn];

int main() {
	
	freopen("number.in", "w", stdout);

	srand(time(NULL));

	For(i, 1, maxm) {
		a[i] = i;
		b[i] = i;
	}

	random_shuffle(a+1, a+maxm+1);
	random_shuffle(b+1, b+maxm+1);

	printf("%d\n", maxm);
	For(i, 1, maxm) {
		int x = rand() % i;
		printf("%d %d %d\n", x, a[i], b[i]);
	}

	return 0;
}
