#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 500010;

int Begin[maxn], to[maxn], E, Next[maxn];

void add(int x,int y) {
	to[++E] = y;
	Next[E] = Begin[x];
	Begin[x] = E;
}

struct node{
	int p, x;
}t[maxn];

int n;

void Get() {
	n = read();
	For(i, 1, n) {
		int Return = read();
		t[i].p = read(), t[i].x = read();
		add(Return, i);
	}
}

int lowbit(int x){ return x & -x ; }

const int maxm = 10000010;

int tot, tree[maxm], ls[maxm], rs[maxm], root[maxn];

ll Ans, ans[maxn];
//remember to change type of Ans to long long
void insert(int &h,int l,int r,int pos,int tp) {
	if(!h) h = ++ tot;
	if(l == r) {
		tree[h] += tp;
		return;
	}

	int mid = l+r >> 1;
	if(pos <= mid) insert(ls[h], l, mid, pos, tp);
	else insert(rs[h], mid+1, r, pos, tp);

	tree[h] = tree[ls[h]] + tree[rs[h]];
}

void Add(int p,int x,int tp) {
	for(int i = p;i <= n; i += lowbit(i) ){
		insert(root[i], 1, n, x, tp);
	}
}

int query(int h,int l,int r,int s,int e) {
	if(tree[h] == 0) return 0;
	if(l == s && r == e) return tree[h];
	
	int mid = l+r >> 1;
	if(e <= mid) return query(ls[h], l, mid, s, e);
	else if(s > mid) return query(rs[h], mid+1, r, s, e);
	else return query(ls[h], l, mid, s, mid) + query(rs[h], mid+1, r, mid+1, e);
}

int Query(int p,int x) {
	int Ans_now = 0;
	for(int i = p;i ;i -= lowbit(i) ){
		Ans_now += query(root[i], 1, n, 1, x);
		Ans_now -= query(root[i], 1, n, x, n);
	}

	for(int i = n;i ;i -= lowbit(i) ){
		Ans_now += query(root[i], 1, n, x, n);
	}

	return Ans_now;
}

void dfs(int h) {
	ans[h] = Ans;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];

		int Ans_now = Query(t[v].p, t[v].x);
		Ans += Ans_now;
		Add(t[v].p, t[v].x, 1);

		dfs(v);
		
		Add(t[v].p, t[v].x, -1);
		Ans -= Ans_now;
	}
}

void solve_bf() {
	dfs(0);
	For(i, 1, n) printf("%lld\n", ans[i]);
}

int main() {

	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
