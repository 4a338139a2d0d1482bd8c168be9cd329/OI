#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 1000010;

const int mod = 1004535809;

int a[maxn], n, m;

void Get() {
	n = read(), m = read();
	For(i, 1, n) a[i] = read();
}

int tree[maxn], tag[maxn];

void build(int h,int l,int r) {
	if(l == r) {
		tree[h] = a[l];
		return;
	}

	int mid = l+r >> 1;
	build(h<<1, l, mid);
	build(h<<1|1, mid+1, r);

	tree[h] = (tree[h<<1] + tree[h<<1|1]) % mod;
}

void pushdown(int h,int l,int r) {
	if(tag[h] == 0) return;
	(tree[h] += 1ll * tag[h] * (r - l + 1) % mod) %= mod;
	if(l == r) {
		tag[h] = 0;
		return;
	}

	tag[h<<1] += tag[h];
	tag[h<<1|1] += tag[h];
	tag[h] = 0;
}

void pushup(int h,int l,int r){
	int mid = l+r >> 1;
	if(tag[h << 1] != 0) pushdown(h<<1, l, mid);
	if(tag[h << 1|1] != 0) pushdown(h<<1|1, mid+1, r);
	tree[h] = (tree[h<<1] + tree[h<<1|1]) % mod;
}

void updada(int h,int l,int r,int s,int e,int val) {
	pushdown(h, l, r);
	if(l == s && r == e) {
		tag[h] += val;
		pushdown(h, l, r);
		return;
	}

	int mid = l+r >> 1;
	if(e <= mid) updada(h<<1, l, mid, s, e, val);
	else if(s > mid) updada(h<<1|1, mid+1, r, s, e, val);
	else updada(h<<1, l, mid, s, mid, val), updada(h<<1|1, mid+1, r, mid+1, e, val);

	pushup(h, l, r);
}

int query(int h,int l,int r,int s,int e) {
	pushdown(h, l, r);
	if(l == s && r == e) {
		return tree[h];
	}

	int mid = l+r >> 1, ans = 0;
	if(e <= mid) ans = query(h<<1, l, mid, s, e);
	else if(s > mid) ans = query(h<<1|1, mid+1, r, s, e);
	else ans = (query(h<<1, l, mid, s, mid) + query(h<<1|1, mid+1, r, mid+1, e) ) % mod;

	return ans;
}

void solve_bf() {
	build(1, 1, n);
	while(m --) {
		int tp = read();
		if(tp == 1) {
			int l = read(), r = read(), x = read();
			updada(1, 1, n, l, r, x);
		}
		else if( tp == 3) {
			int l = read(), r = read();
			printf("%d\n", query(1, 1, n, l, r) );
		}
	}
}

int main () {

	freopen("datastructure.in", "r", stdin);
	freopen("datastructure.out", "w", stdout);
	
	Get();
	solve_bf();

	return 0;
}
