#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int MAXN=50010;
int n,m,stack[MAXN],top;
struct tree
{
	int lsum,rsum,mx;
}a[MAXN*4];
void buildtree(int o,int l,int r)
{
	if(l==r)
	{
		a[o]=(tree){1,1,1};
		return;
	}
	int L=o<<1,R=o<<1|1,M=(l+r)>>1;
	a[o]=(tree){r-l+1,r-l+1,r-l+1};
	buildtree(L,l,M);
	buildtree(R,M+1,r);
	return;
}
void update(int o,int l,int r,int k,int v)
{
	if(l==r)
	{
		a[o]=(tree){k,k,k};
		return;
	}
	int L=o<<1,R=o<<1|1,M=(l+r)>>1;
	if(v<=M)update(L,l,M,k,v);
	else update(R,M+1,r,k,v);
	a[o].lsum=a[L].lsum;
	a[o].rsum=a[R].rsum;
	a[o].mx=max(max(a[L].mx,a[R].mx),a[L].rsum+a[R].lsum);
	if(a[L].lsum==M-l+1)a[o].lsum+=a[R].lsum;
	if(a[R].rsum==r-M)a[o].rsum+=a[L].rsum;
	return;
}
int query(int o,int l,int r,int v)
{
	if(l==r||a[o].mx==0||a[o].mx==r-l+1)return a[o].mx;
	int L=o<<1,R=o<<1|1,M=(l+r)>>1;
	if(v<=M)
	{
		if(v>=M-a[L].rsum+1)return a[L].rsum+a[R].lsum;
		else return query(L,l,M,v);
	}
	else
	{
		if(v<=M+a[R].lsum)return a[L].rsum+a[R].lsum;
		else return query(R,M+1,r,v);
	}
}
int main()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
	scanf("%d%d",&n,&m);
	char t1;
	int v;
	buildtree(1,1,n);
	while(m--)
	{
		scanf("\n");
		scanf("%c",&t1);
		if(t1=='1')
		{
			scanf("%d",&v);
			update(1,1,n,0,v);
			stack[++top]=v;
		}
		else if(t1=='2')
		{
			scanf("%d",&v);
			printf("%d\n",query(1,1,n,v));
		}
		else
		{
			v=stack[top--];
			update(1,1,n,1,v);
		}
	}
	return 0;
}
