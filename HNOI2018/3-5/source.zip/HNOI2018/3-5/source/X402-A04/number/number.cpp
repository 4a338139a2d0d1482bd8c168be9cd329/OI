#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
char writec[25];
inline void write(long long x)
{
	if(!x) putchar('0');
	else
	{
		int len=0;
		for(;x;x/=10) writec[len++]=x%10+48;
		for(int i=len-1;i>=0;--i) putchar(writec[i]);
	}
	putchar('\n');
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=500050;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
}
pii p[N];

int T;
namespace bit
{
	int rt[N],ch[50050*340][2],sum[50050*340],sz=0;
	int query(int o,int l,int r,int x,int y)
	{
		if(!o) return 0;
		if(x<=l&&r<=y) return sum[o];
		int mid=l+r>>1,ans=0;
		if(x<=mid) ans+=query(ch[o][0],l,mid,x,y);
		if(y>mid) ans+=query(ch[o][1],mid+1,r,x,y);
		return ans;
	}
	void update(int &o,int l,int r,int x,int k)
	{
		if(!o) o=++sz;
		if(l==r) {sum[o]+=k;return ;}
		int mid=l+r>>1;
		if(x<=mid) update(ch[o][0],l,mid,x,k);
		else update(ch[o][1],mid+1,r,x,k);
		sum[o]=sum[ch[o][0]]+sum[ch[o][1]];
	}
	inline int ask(int l,int r,int x,int y)
	{
		int ans=0;
		for(int i=r;i;i-=(i&-i)) ans+=query(rt[i],1,T,x,y);
		for(int i=l-1;i;i-=(i&-i)) ans-=query(rt[i],1,T,x,y);
		return ans;
	}
	inline void add(int x,int y,int k)
	{
		for(int i=x;i<=T;i+=(i&-i)) update(rt[i],1,T,y,k);
	}
}

ll sum[N];
void dfs(int u,ll s)
{
	if(u)
	{
		s+=bit::ask(p[u].fi,T,p[u].se,T)+bit::ask(1,p[u].fi,1,p[u].se);
		sum[u]=s;
		bit::add(p[u].fi,p[u].se,1);
	}
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		dfs(v,s);
	}
	if(u) bit::add(p[u].fi,p[u].se,-1);
}

int fa[N];
void dfs2(int u,ll s)
{
	for(int i=u;i;i=fa[i]) if((p[u].fi<p[i].fi&&p[u].se<p[i].se)||(p[u].fi>p[i].fi&&p[u].se>p[i].se)) s++;
	sum[u]=s;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		dfs2(v,s);
	}
}

void wj()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
}
int main()
{
	wj();
	T=read();
	for(int i=1;i<=T;++i)
	{
		int t=read(),x=read(),y=read();
		add(t,i); fa[i]=t; p[i]=pii(x,y);
	}
	if(T>60000) 
	{
		dfs2(0,0);
		for(int i=1;i<=T;++i) write(sum[i]);
		return 0;
	}
	dfs(0,0);
	for(int i=1;i<=T;++i) write(sum[i]);
	return 0;
}
