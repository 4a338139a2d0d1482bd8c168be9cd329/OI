#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
const int mod=1004535809;
const int inf=0x3f3f3f3f;

int pw[N],n,m;
int A[N],B[N],C[N];
namespace sega
{
	int maxnum[N<<2],sum[N<<2],tag[N<<2];
	ll maxv[N<<2],secv[N<<2],add[N<<2];
	inline void maintain(int o)
	{
		sum[o]=(sum[o<<1]+sum[o<<1|1])%mod;
		if(maxv[o<<1]<maxv[o<<1|1]) 
		{
			maxnum[o]=maxnum[o<<1|1]; maxv[o]=maxv[o<<1|1];
			secv[o]=max(maxv[o<<1],secv[o<<1|1]);
		}
		else if(maxv[o<<1]>maxv[o<<1|1])
		{
			maxnum[o]=maxnum[o<<1]; maxv[o]=maxv[o<<1];
			secv[o]=max(secv[o<<1],maxv[o<<1|1]);
		}
		else
		{
			maxnum[o]=maxnum[o<<1]+maxnum[o<<1|1]; maxv[o]=maxv[o<<1];
			secv[o]=max(secv[o<<1],secv[o<<1|1]);
		}
	}
	void build(int o,int l,int r)
	{
		if(l==r) {maxv[o]=sum[o]=A[l]; maxnum[o]=1; return ;}
		int mid=l+r>>1;
		build(o<<1,l,mid); build(o<<1|1,mid+1,r);
		maintain(o);
	}
	inline void pushdown(int o,int l,int r)
	{
		if(tag[o]!=inf)
		{
			if(tag[o]<maxv[o<<1])
			{
				tag[o<<1]=min(tag[o<<1],tag[o]);	
				sum[o<<1]=(sum[o<<1]-maxnum[o<<1]*maxv[o<<1]%mod+1ll*maxnum[o<<1]*tag[o]%mod+mod)%mod;
				maxv[o<<1]=tag[o];
			}

			if(tag[o]<maxv[o<<1|1])
			{
				tag[o<<1|1]=min(tag[o<<1|1],tag[o]);
				sum[o<<1|1]=(sum[o<<1|1]-maxnum[o<<1|1]*maxv[o<<1|1]%mod+1ll*maxnum[o<<1|1]*tag[o]%mod+mod)%mod;
				maxv[o<<1|1]=tag[o];
			}

			tag[o]=inf;
		}
		if(add[o])
		{
			add[o<<1]+=add[o]; add[o<<1|1]+=add[o];
			int mid=l+r>>1;
			sum[o<<1]=(sum[o<<1]+(mid-l+1)*add[o])%mod;
			sum[o<<1|1]=(sum[o<<1|1]+(r-mid)*add[o])%mod;
			maxv[o<<1]+=add[o]; maxv[o<<1|1]+=add[o];
			if(secv[o<<1]) secv[o<<1]+=add[o];
			if(secv[o<<1|1]) secv[o<<1|1]+=add[o];
			//if(tag[o<<1]!=inf) tag[o<<1]+=add[o];
			//if(tag[o<<1|1]!=inf) tag[o<<1|1]+=add[o];
			add[o]=0;
		}
	}
	void update_add(int o,int l,int r,int x,int y,int k)
	{
		if(x<=l&&r<=y)
		{
			add[o]+=k;
			sum[o]=(sum[o]+1ll*(r-l+1)*k)%mod;
			maxv[o]+=k;
			if(secv[o]) secv[o]+=k;
			if(tag[o]!=inf) tag[o]+=k;
			return ;
		}
		pushdown(o,l,r);
		int mid=l+r>>1;
		if(x<=mid) update_add(o<<1,l,mid,x,y,k);
		if(y>mid) update_add(o<<1|1,mid+1,r,x,y,k);
		maintain(o);
	}
	void chkmin(int o,int l,int r,int x,int y,int k)
	{
		if(x<=l&&r<=y&&secv[o]<k)
		{
			if(maxv[o]<=k) return ;
			tag[o]=min(tag[o],k);
			sum[o]=(sum[o]-maxnum[o]*maxv[o]%mod+1ll*maxnum[o]*k%mod+mod)%mod;
			maxv[o]=k;
			return ;
		}
		pushdown(o,l,r);
		int mid=l+r>>1;
		if(x<=mid) chkmin(o<<1,l,mid,x,y,k);
		if(y>mid) chkmin(o<<1|1,mid+1,r,x,y,k);
		maintain(o);
	}
	int query(int o,int l,int r,int x,int y)
	{
		if(x<=l&&r<=y) return sum[o];
		pushdown(o,l,r);
		int mid=l+r>>1,ans=0;
		if(x<=mid) ans=query(o<<1,l,mid,x,y);
		if(y>mid) ans=(ans+query(o<<1|1,mid+1,r,x,y))%mod;
		return ans;
	}
}

void wj()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	pw[0]=1;
	for(int i=1;i<=n;++i) pw[i]=(pw[i-1]+pw[i-1])%mod;
	for(int i=1;i<=n;++i) A[i]=B[i]=C[i]=read();
	memset(sega::tag,inf,sizeof(sega::tag));
	sega::build(1,1,n);
	for(int cas=1;cas<=m;++cas)
	{
		int opt=read(),l=read(),r=read();
		if(opt==1) {int x=read(); sega::update_add(1,1,n,l,r,x);}
		else if(opt==2) {int x=read(); sega::chkmin(1,1,n,l,r,x);}
		else if(opt==3) printf("%d\n",sega::query(1,1,n,l,r));
	}
	return 0;
}
