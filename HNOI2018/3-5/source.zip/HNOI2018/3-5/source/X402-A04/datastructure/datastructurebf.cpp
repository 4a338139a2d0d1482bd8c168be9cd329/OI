#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
const int mod=1004535809;
const int inf=0x3f3f3f3f;

int pw[N],n,m;
ll A[N],B[N],C[N];

void wj()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.ans","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=1;i<=n;++i) A[i]=B[i]=C[i]=read();
	for(int cas=1;cas<=m;++cas)
	{
		int opt=read(),l=read(),r=read();
		if(opt==1)
		{
			int x=read();
			for(int i=l;i<=r;++i) A[i]=A[i]+x;
		}
		else if(opt==2)
		{
			ll x=read();
			for(int i=l;i<=r;++i) A[i]=min(A[i],x);
		}
		else if(opt==3)
		{
			int ans=0;
			for(int i=l;i<=r;++i) ans=(ans+A[i])%mod;
			printf("%d\n",ans);
		}
		else if(opt==4)
		{
			int ans=0;
			for(int i=l;i<=r;++i) ans=(ans+B[i])%mod;
			printf("%d\n",ans);
		}
		else if(opt==5)
		{
			ll ans=0;
			for(int i=l;i<=r;++i) ans=max(ans,C[i]);
			printf("%lld\n",ans%mod);
		}
		for(int i=1;i<=n;++i) B[i]=A[i]+B[i],C[i]=max(C[i],A[i]);
	}
	return 0;
}
