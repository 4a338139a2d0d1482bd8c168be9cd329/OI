#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
const int mod=1004535809;
const int inf=0x3f3f3f3f;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int pw[N],n,m,pwinv[N];
int A[N],B[N],C[N];
namespace sega
{
	int sum[N<<2],add[N<<2];
	void build(int o,int l,int r)
	{
		if(l==r) {sum[o]=A[l];return ;}
		int mid=l+r>>1;
		build(o<<1,l,mid); build(o<<1|1,mid+1,r);
		sum[o]=(sum[o<<1]+sum[o<<1|1])%mod;
	}
	inline void pushdown(int o,int l,int r)
	{
		if(add[o])
		{
			add[o<<1]=(add[o<<1]+add[o])%mod; add[o<<1|1]=(add[o<<1|1]+add[o])%mod;
			int mid=l+r>>1;
			sum[o<<1]=(sum[o<<1]+1ll*(mid-l+1)*add[o])%mod;
			sum[o<<1|1]=(sum[o<<1|1]+1ll*(r-mid)*add[o])%mod;
			add[o]=0;
		}
	}
	void update_add(int o,int l,int r,int x,int y,int k)
	{
		if(x<=l&&r<=y)
		{
			add[o]=(add[o]+k)%mod;
			sum[o]=(sum[o]+1ll*(r-l+1)*k)%mod;
			return ;
		}
		pushdown(o,l,r);
		int mid=l+r>>1;
		if(x<=mid) update_add(o<<1,l,mid,x,y,k);
		if(y>mid) update_add(o<<1|1,mid+1,r,x,y,k);
		sum[o]=(sum[o<<1]+sum[o<<1|1])%mod;
	}
	int query(int o,int l,int r,int x,int y)
	{
		if(x<=l&&r<=y) return sum[o];
		pushdown(o,l,r);
		int mid=l+r>>1,ans=0;
		if(x<=mid) ans=query(o<<1,l,mid,x,y);
		if(y>mid) ans=(ans+query(o<<1|1,mid+1,r,x,y))%mod;
		return ans;
	}
}

namespace segb
{
	int sum[N<<2],add[N<<2],sumc[N<<2],addc[N<<2];
	void build(int o,int l,int r)
	{
		if(l==r) {sum[o]=B[l];return ;}
		int mid=l+r>>1;
		build(o<<1,l,mid); build(o<<1|1,mid+1,r);
		sum[o]=(sum[o<<1]+sum[o<<1|1])%mod;
	}
	inline void pushdown(int o,int l,int r)
	{
		if(add[o])
		{
			add[o<<1]=(add[o<<1]+add[o])%mod; add[o<<1|1]=(add[o<<1|1]+add[o])%mod;
			int mid=l+r>>1;
			sum[o<<1]=(sum[o<<1]+1ll*(mid-l+1)*add[o])%mod;
			sum[o<<1|1]=(sum[o<<1|1]+1ll*(r-mid)*add[o])%mod;
			add[o]=0;
		}
		if(addc[o])
		{
			addc[o<<1]=(addc[o<<1]+addc[o])%mod; 
			addc[o<<1|1]=(addc[o<<1|1]+addc[o])%mod;
			int mid=l+r>>1;
			sumc[o<<1]=(sumc[o<<1]+1ll*(mid-l+1)*addc[o])%mod;
			sumc[o<<1|1]=(sumc[o<<1|1]+1ll*(r-mid)*addc[o])%mod;
			addc[o]=0;
		}
	}
	void updatec(int o,int l,int r,int x,int y,int k)
	{
		if(x<=l&&r<=y)
		{
			addc[o]=(addc[o]+k)%mod;
			sumc[o]=(sumc[o]+1ll*(r-l+1)*k)%mod;
			return ;
		}
		pushdown(o,l,r);
		int mid=l+r>>1;
		if(x<=mid) updatec(o<<1,l,mid,x,y,k);
		if(y>mid) updatec(o<<1|1,mid+1,r,x,y,k);
		sumc[o]=(sumc[o<<1]+sumc[o<<1|1])%mod;
	}
	void update(int o,int l,int r,int x,int y,int k)
	{
		if(x<=l&&r<=y) 
		{
			add[o]=(add[o]+k)%mod;
			sum[o]=(sum[o]+1ll*(r-l+1)*k)%mod;
			return ;
		}
		pushdown(o,l,r);
		int mid=l+r>>1;
		if(x<=mid) update(o<<1,l,mid,x,y,k);
		if(y>mid) update(o<<1|1,mid+1,r,x,y,k);
		sum[o]=(sum[o<<1]+sum[o<<1|1])%mod;
	}
	int query(int o,int l,int r,int x,int y)
	{
		if(x<=l&&r<=y) return sum[o];
		pushdown(o,l,r);
		int mid=l+r>>1,ans=0;
		if(x<=mid) ans=query(o<<1,l,mid,x,y);
		if(y>mid) ans=(ans+query(o<<1|1,mid+1,r,x,y))%mod;
		return ans;
	}
	int queryc(int o,int l,int r,int x,int y)
	{
		if(x<=l&&r<=y) return sumc[o];
		pushdown(o,l,r);
		int mid=l+r>>1,ans=0;
		if(x<=mid) ans=queryc(o<<1,l,mid,x,y);
		if(y>mid) ans=(ans+queryc(o<<1|1,mid+1,r,x,y))%mod;
		return ans;
	}
}

void wj()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	pw[0]=1;
	for(int i=1;i<=n;++i) pw[i]=(pw[i-1]+pw[i-1])%mod;
	pwinv[n]=qpow(pw[n],mod-2);
	for(int i=n-1;i>=0;--i) pwinv[i]=pwinv[i+1]*2%mod;

	for(int i=1;i<=n;++i) A[i]=B[i]=C[i]=read();
	sega::build(1,1,n);
	for(int i=1;i<=n;++i) B[i]=(B[i]+B[i-1])%mod;
	//for(int i=1;i<=n;++i) A[i]=(A[i]+A[i-1])%mod;
	for(int cas=1;cas<=m;++cas)
	{
		int opt=read(),l=read(),r=read();
		if(opt==1) 
		{
			int x=read();
			sega::update_add(1,1,n,l,r,x);
			segb::update(1,1,n,l,r,1ll*x*(mod-cas)%mod);
			segb::updatec(1,1,n,l,r,x);
		}
		else if(opt==2) {int x=read();}
		else if(opt==3) printf("%d\n",sega::query(1,1,n,l,r));
		else if(opt==4) 
		{
			int ans=1ll*segb::queryc(1,1,n,l,r)*cas%mod;
			ans=(ans+1ll*(B[r]-B[l-1]+mod)*cas%mod+mod)%mod;
			ans=(ans+segb::query(1,1,n,l,r))%mod;
			printf("%d\n",ans);
		}
	}
	return 0;
}
