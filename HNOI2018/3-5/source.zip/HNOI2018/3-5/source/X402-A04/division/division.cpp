#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=998244353;
const int N=18;
const int inf=0x3f3f3f3f;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int f[23][1<<N|1],w[N+5],n,m,val[1<<N|1];

void wj()
{
	freopen("division.in","r",stdin);
	freopen("division.out","w",stdout);
}
int main()
{
	wj();
	n=read(); m=read();
	for(int i=1;i<=n;++i) w[i]=read();
	int tot=1<<n;
	for(int s=0;s<tot;++s)
	{
		int minn=inf,maxn=0;
		for(int i=1;i<=n;++i) if(s&(1<<i-1)) maxn=max(maxn,w[i]),minn=min(minn,w[i]);
		val[s]=maxn-minn;
	}
	f[0][0]=1;
	/*for(int i=0;i<=m;++i)
	{
		for(int s=1;s<tot;++s)
		{
			int low=__builtin_ctz(s);
			for(int s0=s;s0;s0=(s0-1)&s) if(s0&1<<low)
				f[i][s]=(f[i][s]+f[max(i-val[s0],0)][s^s0])%mod;
		}
	}*/
	for(int i=0;i<=m;++i) for(int s=0;s<tot;++s) if(f[i][s])
	{
		int ss=tot-1^s,low=__builtin_ctz(ss);
		for(int s0=ss;s0;s0=(s0-1)&ss) if(s0&1<<low)
		{
			int &x=f[min(i+val[s0],m)][s|s0];
			x=(x+f[i][s])%mod;
		}
	}
	printf("%d\n",f[m][tot-1]);
	return 0;
}
