#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ft first
#define sd second
#define ls l,mid
#define rs mid+1,r
#define lowbit(x) (x&-x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
}
int n,len,fa[N];
int bgn[N],nxt[N],to[N],E;
LL ans[N];
pii a[N];
int dfq[N],cnt,ln[N],rn[N];
int t[2][N];
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
struct node
{
	int pos,x,y,id,flag;
	node(){}
	node(int pos,int x,int y,int id,int flag):pos(pos),x(x),y(y),id(id),flag(flag){}
}X[N],p[N];
inline bool operator<(const node&A,const node&B){return A.pos==B.pos?A.flag>B.flag:A.pos<B.pos;}
inline void dfs(int u)
{
	dfq[ln[u]=++cnt]=u;
	for(int i=bgn[u];i;i=nxt[i])
		dfs(to[i]);
	rn[u]=cnt;
}
inline int Sum(int x,int p)
{
	int ret=0;
	if(p==0)for(;x;x-=lowbit(x))ret+=t[p^1][x];
	else
	{
		for(;x;x-=lowbit(x))ret-=t[p^1][x];
		for(x=n;x;x-=lowbit(x))ret+=t[p^1][x];
	}
	return ret;
}
inline void Add(int x,int y,int p){for(;x<=n;x+=lowbit(x))t[p][x]+=y;}
inline void Solve(int l,int r,int L,int R)
{
	if(L>R||l>=r)return;
	int mid=(l+r)>>1;
	For(i,L,R)
	{
		if(X[i].flag==1)ans[X[i].id]+=Sum(X[i].y,X[i].x<=mid);
		Add(X[i].y,X[i].flag,X[i].x<=mid);
	}
	int lp=L,rp=R;
	For(i,L,R)X[i].x<=mid?p[lp++]=X[i]:p[rp--]=X[i];
	reverse(p+rp+1,p+R+1);
	For(i,L,R)X[i]=p[i];
	Solve(l,mid,L,lp-1);
	Solve(mid+1,r,lp,R);
}
int main()
{
	int x,y,z;
	file();
	read(n);
	For(i,1,n)
	{
		read(x),read(y),read(z);
		add_edge(x,i),a[i]=pii(y,z);
		fa[i]=x;
	}
	dfs(0);
	For(i,1,n)
	{
		X[++len]=node(ln[i],a[i].ft,a[i].sd,i,1);
		X[++len]=node(rn[i],a[i].ft,a[i].sd,i,-1);
	}
	sort(X+1,X+len+1);
	Solve(1,n,1,len);
	For(i,1,n)ans[i]+=ans[fa[i]];
	For(i,1,n)printf("%lld\n",ans[i]);
	return 0;
}
