#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ft first
#define sd second
#define ls l,mid
#define rs mid+1,r
#define lowbit(x) (x&-x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=500010;
const int M=15000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("number.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n,tot;
int bgn[N],nxt[N],to[N],E;
LL ans[N],nans;
pii a[N];
int rt[N],lc[M],rc[M],sum[M];
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void Add_tree(int l,int r,int&p,int x,int y)
{
	if(!p)p=++tot;
	sum[p]+=y;
	if(l==r){return;}
	int mid=(l+r)>>1;
	if(x<=mid)Add_tree(ls,lc[p],x,y);
	else Add_tree(rs,rc[p],x,y);
}
inline int Query_tree(int l,int r,int p,int x,int y)
{
	if(!p)return 0;
	if(x<=l&&r<=y)return sum[p];
	int mid=(l+r)>>1,ret=0;
	if(x<=mid)ret+=Query_tree(ls,lc[p],x,y);
	if(y> mid)ret+=Query_tree(rs,rc[p],x,y);
	return ret;
}
inline int Query(int x,int l,int r)
{
	if(!x)return 0;
	if(l>r)return 0;
	int ret=0;
	for(;x;x-=lowbit(x))ret+=Query_tree(1,n,rt[x],l,r);
	return ret;
}
inline void Add(pii A)
{
	int x=A.ft,y=A.sd;
	nans+=Query(x-1,1,y-1)+Query(n,y+1,n)-Query(x-1,y+1,n);
	for(;x<=n;x+=lowbit(x))Add_tree(1,n,rt[x],y,1);
}
inline void Del(pii A)
{
	int x=A.ft,y=A.sd;
	for(;x<=n;x+=lowbit(x))Add_tree(1,n,rt[x],y,-1);
	nans-=Query(x-1,1,y-1)+Query(n,y+1,n)-Query(x-1,y+1,n);
}
vector<pii>G,A;
inline LL Get_ans()
{
	A=G;
	sort(A.begin(),A.end());
	LL ans=0;
	For(i,0,SZ(A)-1)
		For(j,0,i-1)
			if(A[j].sd<A[i].sd)
				ans++;
	return ans;
}
inline void dfs(int u)
{
	if(u)G.pb(a[u]);
	ans[u]=Get_ans();
	for(int i=bgn[u];i;i=nxt[i])
		dfs(to[i]);
	if(u)G.pop_back();
}
int main()
{
	int x,y,z;
	file();
	read(n);
	For(i,1,n)
	{
		read(x),read(y),read(z);
		add_edge(x,i),a[i]=pii(y,z);
	}
	dfs(0);
	For(i,1,n)printf("%lld\n",ans[i]);
	return 0;
}
