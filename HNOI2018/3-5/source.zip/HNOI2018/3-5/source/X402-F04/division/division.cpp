//2018-3-5
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (300 + 5)

int n, m, gn, ans, w[N], gr[N];
int mx[N], mn[N];

bool Check(){
	For(i, 1, n) mn[gr[i]] = mx[gr[i]] = w[i];
	For(i, 1, n){
		mn[gr[i]] = min(mn[gr[i]], w[i]);
		mx[gr[i]] = max(mx[gr[i]], w[i]);
	}

	int tot = 0;
	For(i, 1, gn) tot += mx[i] - mn[i];
	return tot >= m;
}

void Dfs(int now){
	if(now > n){
		ans += Check(); return;
	}
	
	gr[now] = ++gn;
	Dfs(now + 1); --gn;

	For(i, 1, gn){
		gr[now] = i; Dfs(now + 1);
	}
}

int main(){
	freopen("division.in", "r", stdin);
	freopen("division.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%d", &w[i]);

	gr[1] = gn = 1;
	Dfs(2);
	printf("%d\n", ans);

	return 0;
}
