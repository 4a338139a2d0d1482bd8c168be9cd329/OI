//2018-3-5
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (200000 + 5)
const int P = 1004535809;

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

inline int Mod(LL a){
	if(a < 0) return a + P;
	return a >= P? a - P: a;
}
inline int Mul(LL a, LL b){
	a %= P; b %= P;
	return (LL)a * b % P;
}

int a[N], b[N], c[N];

namespace SegTree{
	int ql, qr;
	LL add[N << 2], sum[N << 2], Max[N << 2];
	
#define lc (o << 1)
#define rc (o << 1 | 1)
#define mid ((L + R) >> 1)

	void Pushup(int o){
		sum[o] = Mod(sum[lc] + sum[rc]); Max[o] = max(Max[lc], Max[rc]);
	}

	void Build(int o, int L, int R){
		if(L == R){
			sum[o] = Max[o] = a[L]; return;
		}

		Build(lc, L, mid); Build(rc, mid + 1, R);
		Pushup(o);
	}

	void Put(int o, int L, int R, int av){
		add[o] = add[o] + av; Max[o] += av;
		sum[o] = Mod(sum[o] + Mul(R - L + 1, av));
	}
	
	void Pushdown(int o, int L, int R){
		if(!add[o]) return;
		Put(lc, L, mid, add[o]); Put(rc, mid + 1, R, add[o]);
		add[o] = 0;
	}

	void Modify(int o, int L, int R, int av){
		if(ql <= L && qr >= R){
			Put(o, L, R, av); return;
		}

		Pushdown(o, L, R);
		if(ql <= mid) Modify(lc, L, mid, av);
		if(qr > mid) Modify(rc, mid + 1, R, av);
		Pushup(o);
	}
	
	LL QueryMax(int o, int L, int R){
		if(ql <= L && qr >= R) return Max[o];
		
		LL ret = -(1ll << 60);
		Pushdown(o, L, R);
		if(ql <= mid) ret = max(ret, QueryMax(lc, L, mid));
		if(qr > mid) ret = max(ret, QueryMax(rc, mid + 1, R));
		Pushup(o);
		return ret;
	}

	LL QuerySum(int o, int L, int R){
		if(ql <= L && qr >= R) return sum[o];

		LL ret = 0;
		Pushdown(o, L, R);
		if(ql <= mid) ret += QuerySum(lc, L, mid);
		if(qr > mid) ret += QuerySum(rc, mid + 1, R);
		Pushup(o);
		return Mod(ret);
	}

#undef lc
#undef rc
#undef mid
}

using namespace SegTree;

int main(){
	freopen("datastructure.in", "r", stdin);
	freopen("datastructure.out", "w", stdout);

	int n, m, op, x;

	Read(n); Read(m);
	For(i, 1, n) Read(a[i]);

	Build(1, 1, n);
	while(m --){
		Read(op); Read(ql); Read(qr);

		if(op <= 2){
			scanf("%d", &x);
			Modify(1, 1, n, x);
		}else if(op == 3){
			printf("%lld\n", QuerySum(1, 1, n) % P);
		}else if(op == 5){
			printf("%lld\n", QueryMax(1, 1, n) % P);
		}
	}

	return 0;
}
