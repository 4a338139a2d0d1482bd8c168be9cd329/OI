//2018-3-5
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (500000 + 5)

int p[N], x[N];

int main(){
	freopen("number.in", "w", stdout);
	
	srand(time(NULL));
	int n = 500000;
	
	printf("%d\n", n);
	For(i, 1, n) p[i] = i, x[i] = i;
	For(i, 1, n) swap(p[rand() % n + 1], p[rand() % n + 1]);
	For(i, 1, n) swap(x[rand() % n + 1], x[rand() % n + 1]);

	For(i, 1, n){
		printf("%d %d %d\n", i - 1, p[i], x[i]);
	}

	return 0;
}
