//2018-3-5
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (500000 + 5)
#define M (17000000 + 5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

struct node{
	int v, p, x;
};

struct snode{
	int ls, rs, tot;
};

namespace SegTree{
	int hn, ql, qr;
	snode h[M];

#define lc h[o].ls
#define rc h[o].rs
#define mid ((L + R) >> 1)

	void Modify(int &o, int L, int R, int av, int op){
		if(!o) o = ++hn;
		if(L == R){h[o].tot += op; return;}
		
		if(av <= mid) Modify(lc, L, mid, av, op);
		else Modify(rc, mid + 1, R, av, op);
		
		h[o].tot = h[lc].tot + h[rc].tot;
	}
	
	LL Query(int o, int L, int R){
		if(!o) return 0;
		if(ql <= L && qr >= R) return h[o].tot;
	
		LL ret = 0;
		if(ql <= mid) ret += Query(lc, L, mid);
		if(qr > mid) ret += Query(rc, mid + 1, R);
		return ret;
	}

#undef lc
#undef rc
#undef mid
};

int n, root[N];
LL ans[N], Ans;
vector<node> G[N];

LL Sum(int x, int l, int r){
	LL ret = 0;

	SegTree::ql = l; SegTree::qr = r;
	while(x > 0){
		ret += SegTree::Query(root[x], 1, n);
		x -= x & (-x);
	}
	return ret;
}

void Add(int x, int y, int op){
	Ans += op * (Sum(n, y + 1, n) - Sum(x, y + 1, n));
	Ans += op * Sum(x - 1, 1, y - 1);

//	printf("Add(%d %d)\n", x, y);
	while(x <= n){
		SegTree::Modify(root[x], 1, n, y, op);
		x += x & (-x);
	}
}

void Dfs(int now){
//	printf("now = %d Ans = %lld\n", now, Ans);
	ans[now] = Ans;
	
	For(i, 0, G[now].size() - 1){
		Add(G[now][i].p, G[now][i].x, 1);
		Dfs(G[now][i].v);
		Add(G[now][i].p, G[now][i].x, -1);
	}
}

int main(){
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);
	
	int t, p, x;

	Read(n);
	For(i, 1, n){
		Read(t); Read(p); Read(x);
		G[t].pb((node){i, p, x});
	}

	Dfs(0);

//	cerr<<SegTree::hn<<endl;
	For(i, 1, n) printf("%lld\n", ans[i]);
	
	return 0;
}
