#include<bits/stdc++.h>
using namespace std;
const int maxn=500100;
#define mid ((l+r)>>1)
int n;
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
struct node{
	int t,p,x;
}a[maxn];
struct Tree{
	int l,r,v;
}tr[maxn*30];
int b[maxn],num;
void Add(int &h,int l,int r,int p,int v){
	if(!h) h=++num;
	tr[h].v+=v;
	if(l==r) return;
	if(p<=mid) Add(tr[h].l,l,mid,p,v);
	else Add(tr[h].r,mid+1,r,p,v);
}
void Add(int p,int x,int v){
	while(p<=n){
		Add(b[p],1,n,x,v);
		p+=p&(-p);
	}
}
int Query(int h,int l,int r,int s,int t){
	if(!tr[h].v) return 0;
	if(s<=l&&r<=t) return tr[h].v;
	if(t<=mid) return Query(tr[h].l,l,mid,s,t);
	else if(s>mid)
		return Query(tr[h].r,mid+1,r,s,t);
	else
		return Query(tr[h].l,l,mid,s,mid)+Query(tr[h].r,mid+1,r,mid+1,t);
}
int Query(int p,int l,int r){
	int res=0;
	while(p){
		res+=Query(b[p],1,n,l,r);
		p-=p&(-p);
	}
	return res;
}
long long Ans[maxn];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void dfs(int u,int fa){
	if(u){
		Ans[u]=Ans[fa]+Query(a[u].p-1,1,a[u].x)+Query(n,a[u].x,n)-Query(a[u].p,a[u].x,n);
		Add(a[u].p,a[u].x,1);
	}
	for(int i=beg[u];i;i=nex[i])
		dfs(tto[i],u);
	if(u)
		Add(a[u].p,a[u].x,-1);
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	readl(n);
	for(int i=1;i<=n;i++){
		readl(a[i].t),readl(a[i].p),readl(a[i].x);
		putin(a[i].t,i);
	}
	dfs(0,-1);
	for(int i=1;i<=n;i++)
		printf("%lld\n",Ans[i]);
	return 0;
}
