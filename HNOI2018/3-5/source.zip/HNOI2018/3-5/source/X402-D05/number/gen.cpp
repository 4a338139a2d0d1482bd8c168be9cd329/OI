#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=500000;
	printf("%d\n",n);
	for(int i=1;i<=n;i++){
		printf("%d %d %d\n",i-1,rand()%n+1,rand()%n+1);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("number.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
