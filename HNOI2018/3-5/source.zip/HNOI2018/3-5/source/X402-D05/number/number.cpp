#include<bits/stdc++.h>
using namespace std;
const int maxn=500100;
int n;
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
struct node{
	int t,p,x;
}a[maxn];
struct Tree{
	int ch[4];
	int v;
}tr[maxn*30];
int num,rt;
struct Range{
	int lx,rx;
	int ly,ry;
	int midx(){
		return (lx+rx)>>1;
	}
	int midy(){
		return (ly+ry)>>1;
	}
};
struct point{
	int x,y;
};
int tt;
void Add(int &h,Range A,const point &B,int v){
	if(!h) h=++num;
	tr[h].v+=v;
	if(A.lx==A.rx&&A.ly==A.ry) return;
	int nx=0;
	if(B.x<=A.midx())
		A.rx=A.midx();
	else{
		nx|=1;
		A.lx=A.midx()+1;
	}
	if(B.y<=A.midy())
		A.ry=A.midy();
	else{
		nx|=2;
		A.ly=A.midy()+1;
	}
	Add(tr[h].ch[nx],A,B,v);
}
int Query(int h,const Range &A,const Range &B){
	if(!tr[h].v) return 0;
	if(B.lx>A.rx||B.rx<A.lx) return 0;
	if(B.ly>A.ry||B.ry<A.ly) return 0;
	if(B.lx<=A.lx&&A.rx<=B.rx&&B.ly<=A.ly&&A.ry<=B.ry)
		return tr[h].v;
	Range New;
	int res=0;
	for(int i=0;i<4;i++){
		New=A;
		if(i&1) New.lx=New.midx()+1;
		else New.rx=New.midx();
		if(i&2) New.ly=New.midy()+1;
		else New.ry=New.midy();
		res+=Query(tr[h].ch[i],New,B);
	}
	return res;
}
long long Ans[maxn];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void dfs(int u,int fa){
	if(u){
		Ans[u]=Ans[fa];
		Ans[u]+=Query(rt,(Range){1,n,1,n},(Range){1,a[u].p,1,a[u].x});
		Ans[u]+=Query(rt,(Range){1,n,1,n},(Range){a[u].p,n,a[u].x,n});
		Add(rt,(Range){1,n,1,n},(point){a[u].p,a[u].x},1);
	}
	for(int i=beg[u];i;i=nex[i])
		dfs(tto[i],u);
	if(u)
		Add(rt,(Range){1,n,1,n},(point){a[u].p,a[u].x},-1);
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	readl(n);
	for(int i=1;i<=n;i++){
		readl(a[i].t),readl(a[i].p),readl(a[i].x);
		putin(a[i].t,i);
	}
	dfs(0,-1);
	for(int i=1;i<=n;i++)
		printf("%lld\n",Ans[i]);
	return 0;
}
