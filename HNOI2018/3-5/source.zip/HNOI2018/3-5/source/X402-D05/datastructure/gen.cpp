#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxv=1e9;
void solve(){
	int n=2000,m=2000;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%maxv+1);
	printf("\n");
	for(int i=1;i<=n;i++){
		int op=rand()%3+1;
		if(op==2) op=5;
		printf("%d ",op);
		int l=rand()%n+1,r=rand()%n+1;
		if(l>r) swap(l,r);
		if(op<=2){
			printf("%d %d %d\n",l,r,rand()%maxv+1);
		}
		else{
			printf("%d %d\n",l,r);
		}
	}
}
int main(){
	srand(time(0)+getx());
	freopen("datastructure.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
