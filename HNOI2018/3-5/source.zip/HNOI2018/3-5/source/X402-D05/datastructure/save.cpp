#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
const int md=1004535809;
const long long INF=1e16;
#define mid ((l+r)>>1)
void chkmax(long long &x,long long y){
	x=x>y?x:y;
}
int n,m;
int a[maxn];
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
struct node{
	long long sum,tgs;
	long long mx1,mx2,chm;
	int cnt;
}tr[maxn<<2];
void push_down(int h,int l,int r);
void push_up(int h);
void Change(int h,long long v,int cnt){
	if(v>tr[h].mx1){
		tr[h].mx2=tr[h].mx1;
		tr[h].mx1=v,tr[h].cnt=cnt;
	}
	else if(v==tr[h].mx1){
		tr[h].cnt+=cnt;
		return;
	}
	else
		chkmax(tr[h].mx2,v);
}
void Add(int h,int l,int r,long long v){
	(tr[h].sum+=v*(r-l+1))%=md;
	tr[h].tgs+=v;
	tr[h].mx1+=v,tr[h].mx2+=v;
}
void ChkMin(int h,int l,int r,long long v){
	if(v>=tr[h].mx1) return;
	else if(v>tr[h].mx2){
//		if(m==1) cerr<<l<<" "<<r<<" "<<tr[h].mx2<<endl;
		tr[h].sum=(tr[h].sum-(tr[h].mx1-v)*tr[h].cnt%md+md)%md;
		tr[h].mx1=v;
		tr[h].chm=v-tr[h].tgs;
	}
	else{
		tr[h].chm=v-tr[h].tgs;
		push_down(h,l,r);
		push_up(h);
	}
}
void Add(int h,int l,int r,int s,int t,int v){
	if(s<=l&&r<=t){
		Add(h,l,r,v);
		return;
	}
	push_down(h,l,r);
	if(t<=mid) Add(h<<1,l,mid,s,t,v);
	else if(s>mid) Add(h<<1|1,mid+1,r,s,t,v);
	else{
		Add(h<<1,l,mid,s,mid,v);
		Add(h<<1|1,mid+1,r,mid+1,t,v);
	}
	push_up(h);
}
void push_up(int h){
	tr[h].sum=(tr[h<<1].sum+tr[h<<1|1].sum)%md;
	tr[h].mx1=tr[h<<1].mx1,tr[h].mx2=tr[h<<1].mx2;
	tr[h].cnt=tr[h<<1].cnt;
	Change(h,tr[h<<1|1].mx1,tr[h<<1|1].cnt);
	Change(h,tr[h<<1|1].mx2,0);
}
void push_down(int h,int l,int r){
	if(tr[h].chm<INF){
		ChkMin(h<<1,l,mid,tr[h].chm);
		ChkMin(h<<1|1,mid+1,r,tr[h].chm);
		tr[h].chm=INF;
	}
	if(tr[h].tgs){
		Add(h<<1,l,mid,tr[h].tgs);
		Add(h<<1|1,mid+1,r,tr[h].tgs);
		tr[h].tgs=0;
	}
}
void ChkMin(int h,int l,int r,int s,int t,int v){
	if(s<=l&&r<=t){
		ChkMin(h,l,r,v);
		return;
	}
	push_down(h,l,r);
	if(t<=mid) ChkMin(h<<1,l,mid,s,t,v);
	else if(s>mid) ChkMin(h<<1|1,mid+1,r,s,t,v);
	else{
		ChkMin(h<<1,l,mid,s,mid,v);
		ChkMin(h<<1|1,mid+1,r,mid+1,t,v);
	}
	push_up(h);
}
long long Query(int h,int l,int r,int s,int t){
	if(s<=l&&r<=t)
		return tr[h].sum;
	push_down(h,l,r);
	if(t<=mid) return Query(h<<1,l,mid,s,t);
	else if(s>mid) return Query(h<<1|1,mid+1,r,s,t);
	else
		return (Query(h<<1,l,mid,s,mid)+Query(h<<1|1,mid+1,r,mid+1,t))%md;
}
void Build_tree(int h,int l,int r){
	tr[h].tgs=0,tr[h].chm=INF;
	if(l==r){
		tr[h].sum=a[l],tr[h].cnt=1;
		tr[h].mx1=a[l],tr[h].mx2=-INF;
		return;
	}
	Build_tree(h<<1,l,mid);
	Build_tree(h<<1|1,mid+1,r);
//	cerr<<"------------"<<l<<" "<<r<<"----------------\n";
	push_up(h);
//	cerr<<"------------"<<l<<" "<<r<<"----------------\n";
}
int main(){
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	for(int i=1;i<=n;i++)
		readl(a[i]);
	Build_tree(1,1,n);
	int op,l,r,x;
	for(m=1;m<=M;m++){
		readl(op);
		if(op==1){
			readl(l),readl(r),readl(x);
			Add(1,1,n,l,r,x);
		}
		else if(op==2){
			readl(l),readl(r),readl(x);
			ChkMin(1,1,n,l,r,x);
		}
		else{
			readl(l),readl(r);
			printf("%lld\n",Query(1,1,n,l,r));
		}
	}
	return 0;
}
