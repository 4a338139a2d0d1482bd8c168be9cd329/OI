#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
const long long md=1004535809;
long long a[maxn],b[maxn],c[maxn];
int n,m;
int main(){
	freopen("datastructure.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int M;
	scanf("%d%d",&n,&M);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		b[i]=c[i]=a[i];
	}
	int op,l,r;
	long long x;
	long long ans;
	for(m=1;m<=M;m++){
		scanf("%d",&op);
		if(op==1){
			scanf("%d%d%lld",&l,&r,&x);
			for(int i=l;i<=r;i++)
				a[i]+=x;
		}
		else if(op==2){
			scanf("%d%d%lld",&l,&r,&x);
			for(int i=l;i<=r;i++)
				a[i]=min(a[i],x);
		}
		else if(op==3){
			scanf("%d%d",&l,&r);
			ans=0;
			for(int i=l;i<=r;i++)
				(ans+=a[i])%=md;
			if(m>M-3) cerr<<ans<<endl;
			printf("%lld\n",ans);
		}
		else if(op==4){
			scanf("%d%d",&l,&r);
			ans=0;
			for(int i=l;i<=r;i++)
				ans=(ans+b[i])%md;
			printf("%lld\n",ans);
		}
		else{
			scanf("%d%d",&l,&r);
			ans=0;
			for(int i=l;i<=r;i++)
				ans=max(ans,c[i]);
			printf("%lld\n",ans%md);
		}
		for(int i=1;i<=n;i++)
			b[i]=(b[i]+a[i])%md;
		for(int i=1;i<=n;i++)
			c[i]=max(c[i],a[i]);
	}
	return 0;
}
