#include<bits/stdc++.h>
using namespace std;
const int md=1004535809;
const int maxn=310;
int f[20][20][20000];
int a[maxn];
int getg(int n){
	static int g[310][310];
	g[0][0]=1;
	for(int i=0;i<n;i++)
		for(int j=0;j<=i;j++){
			if(j>0)
				(g[i+1][j-1]+=g[i][j]*(long long)j%md)%=md;
			(g[i+1][j]+=g[i][j]*(long long)(j+1)%md)%=md;
			(g[i+1][j+1]+=g[i][j])%=md;
		}
	return g[n][0];
}
int main(){
	freopen("division.in","r",stdin);
	freopen("division.out","w",stdout);
	int n,m,sum=0;
	scanf("%d%d",&n,&m);
	int ans=getg(n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	sort(a+1,a+n+1);
	reverse(a+1,a+n+1);
	f[0][0][0]=1;
	for(int i=0;i<n;i++){
		for(int j=0;j<=i;j++){
			for(int k=0;k<=sum;k++){
				if(!f[i][j][k]) continue;
				(f[i+1][j][k]+=f[i][j][k]*(long long)(j+1)%md)%=md;
				if(k+a[i]<=sum){
					(f[i+1][j+1][k+a[i+1]]+=f[i][j][k])%=md;
				}
				if(k-a[i]>=0&&j>0)
					(f[i+1][j-1][k-a[i+1]]+=f[i][j][k]*(long long)j%md)%=md;
			}
		}
	}
	for(int i=0;i<m;i++)
		ans=(ans-f[n][0][i]+md)%md;
	printf("%d\n",ans);
	return 0;
}
