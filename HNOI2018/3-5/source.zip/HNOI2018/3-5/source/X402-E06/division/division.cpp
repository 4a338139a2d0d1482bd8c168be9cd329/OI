#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int M = 20;
const int S = 1 << 18;
const int mo = 1004535809;

int n, m;
int dp[S + 5][M + 5];
int mx[S + 5], mn[S + 5], w[M + 5];

int main() {
    freopen("division.in", "r", stdin);
    freopen("division.out", "w", stdout);

    read(n), read(m);
    for(int i = 0; i < n; ++i) {
        mx[1 << i] = mn[1 << i] = read(w[i]);
    }

    mx[0] = -oo, mn[0] = oo;
    for(int i = 1; i < (1 << n); ++i) {
        mx[i] = std::max(mx[i ^ (i & -i)], mx[i & -i]);
        mn[i] = std::min(mn[i ^ (i & -i)], mn[i & -i]);
    }

    dp[0][0] = 1;
    for(int i = 0; i < (1 << n); ++i) {
        for(int j = 0; j <= m; ++j) if(dp[i][j]) {

            int rest = ((1 << n) - 1) ^ i;
            if(!rest) continue;

            int u = rest & -rest;

            rest ^= u;
            for(int sub = rest; ; sub = (sub - 1) & rest) {
                int s = sub | u;
                (dp[i | s][std::min(m, j + (mx[s] - mn[s]))] += dp[i][j]) %= mo;

                if(sub == 0) break;
            }
        }
    }
    printf("%d\n", dp[(1 << n) - 1][m]);

    return 0;
}
