#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 500000;

int n;
namespace BIT {
#define lowbit(x) (x & -x)

    ll c[N + 5];
    inline void add(int x, int y) {
        while(x <= N) {
            c[x] += y;
            x += lowbit(x);
        }
    }
    inline int query(int x) {
        int res = 0;
        while(x > 0) {
            res += c[x];
            x -= lowbit(x);
        }
        return res;
    }
}

vector<int> G[N + 5];
struct option { 
    int p, x, sgn, id; 

    bool operator < (const option& rhs) const {
        return p < rhs.p;
    }
} op[N + 5];

ll res[(N << 1) + 5];
option dseq[(N << 1) + 5], temp[(N << 1) + 5];

void solve(int l, int r) {
    if(l == r) return;
    int mid = (l + r) >> 1;

    for(int i = l; i <= r; ++i) {
        if(dseq[i].id <= mid)
            BIT::add(dseq[i].x, dseq[i].sgn);
        else if(dseq[i].sgn == 1)
            res[dseq[i].id] += BIT::query(dseq[i].x - 1);
    } 
    for(int i = l; i <= r; ++i) if(dseq[i].id <= mid) BIT::add(dseq[i].x, -dseq[i].sgn);

    for(int i = r; i >= l; --i) {
        if(dseq[i].id <= mid) 
            BIT::add(n - dseq[i].x + 1, dseq[i].sgn);
        else if(dseq[i].sgn == 1)
            res[dseq[i].id] += BIT::query(n - dseq[i].x);
    } 
    for(int i = r; i >= l; --i) if(dseq[i].id <= mid) BIT::add(n - dseq[i].x + 1, -dseq[i].sgn);

    int px = l, py = mid+1;
    for(int i = l; i <= r; ++i) {
        if(dseq[i].id <= mid) 
            temp[px++] = dseq[i]; 
        else temp[py++] = dseq[i];
    }
    for(int i = l; i <= r; ++i) dseq[i] = temp[i];

    solve(l, mid);
    solve(mid+1, r);
}

int dfnL[N + 5], dfnR[N + 5], dfs_clock;
void dfs(int t) {
    if(t) {
        ++ dfs_clock;
        dseq[dfnL[t] = dfs_clock] = (option) { op[t].p, op[t].x, +1, dfs_clock };
    }

    for(int i = 0; i < (int) G[t].size(); ++i) dfs(G[t][i]);

    if(t) {
        ++ dfs_clock;
        dseq[dfnR[t] = dfs_clock] = (option) { op[t].p, op[t].x, -1, dfs_clock };
    }
}

void dfs_calc(int u, int f = -1) {
    if(u) {
        res[dfnL[u]] += res[dfnL[f]];
    }
    for(int i = 0; i < (int) G[u].size(); ++i) dfs_calc(G[u][i], u);
}

int main() {
    freopen("number.in", "r", stdin);
    freopen("number.out", "w", stdout);

    read(n);
    for(int i = 1; i <= n; ++i) {
        static int t;
        read(t), G[t].pb(i);
        read(op[i].p), read(op[i].x);
    }

    dfs(0);
    std::sort(dseq + 1, dseq + dfs_clock + 1);

    solve(1, dfs_clock);
    dfs_calc(0);

    for(int i = 1; i <= n; ++i) printf("%lld\n", res[dfnL[i]]);

    // std::cout << procStatus() << std::endl;
    return 0;
}
