#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 500000;

int n;
vector<int> G[N + 5];
struct option { int p, x; } op[N + 5];

int rt[N + 5];
namespace SEG {
    const int SZ = 6000000;
#define mid ((l + r) >> 1)

    int cnt;
    int sum[SZ + 5], lc[SZ + 5], rc[SZ + 5];

    void modify(int &u, int l, int r, int p, int v) {
        if(!u) u = ++ cnt;
        sum[u] += v;
        if(l == r) return;

        if(p <= mid) 
            modify(lc[u], l, mid, p, v);
        else 
            modify(rc[u], mid+1, r, p, v);
    }

    int query(int u, int l, int r, int x, int y) {
        if(!u) return 0; 
        if(x <= l && r <= y) return sum[u];

        int ans = 0;
        if(x <= mid) 
            ans += query(lc[u], l, mid, x, y);
        if(mid < y)
            ans += query(rc[u], mid+1, r, x, y);
        return ans;
    }
}

namespace BIT {
#define lowbit(x) (x & -x)

    int c[N + 5];
    void add(int x, int v, int y) {
        while(x <= n) {
            SEG::modify(rt[x], 1, n, v, y);
            x += lowbit(x);
        }
    }
    int query(int x, int l, int r) {
        int res = 0;
        while(x > 0) {
            res += SEG::query(rt[x], 1, n, l, r);
            x -= lowbit(x);
        }
        return res;
    }
}

ll res[N + 5];
void dfs(int t, ll ans = 0) {

    int delta = BIT::query(op[t].p, 1, op[t].x - 1) + (BIT::query(n, op[t].x + 1, n) - BIT::query(op[t].p, op[t].x + 1, n));
    BIT::add(op[t].p, op[t].x, +1);

    res[t] = ans + delta;
    for(int i = 0; i < (int) G[t].size(); ++i) {
        dfs(G[t][i], ans + delta);
    }

    BIT::add(op[t].p, op[t].x, -1);
}

int main() {
    freopen("number.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n);
    for(int i = 1; i <= n; ++i) {
        static int t;
        read(t), G[t].pb(i);
        read(op[i].p), read(op[i].x);
    }

    for(int i = 0; i < int(G[0].size()); ++i) dfs(G[0][i]);
    for(int i = 1; i <= n; ++i) printf("%lld\n", res[i]);
    return 0;
}
