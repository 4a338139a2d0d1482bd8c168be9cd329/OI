#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;
const int mo = 1004535809;

int n, m;
ll a[N + 5], b[N + 5], c[N + 5];

int main() {
    freopen("datastructure.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n), read(m);
    for(int i = 1; i <= n; ++i) b[i] = c[i] = read(a[i]);

    while(m--) {
        static int op, x, y, z;

        read(op);
        read(x), read(y);

        if(op == 1) { 
            read(z); 
            for(int i = x; i <= y; ++i) a[i] += z;
        }
        if(op == 3) {
            ll res = 0;
            for(int i = x; i <= y; ++i) res = (res + a[i]) % mo;
            printf("%lld\n", res);
        }
        if(op == 4) {
            ll res = 0;
            for(int i = x; i <= y; ++i) res = (res + b[i]) % mo;
            printf("%lld\n", res);
        }
        if(op == 5) {
            ll res = 0;
            for(int i = x; i <= y; ++i) chkmax(res, c[i]);
            printf("%lld\n", res % mo);
        }

        for(int i = 1; i <= n; ++i) (b[i] += a[i]) %= mo, chkmax(c[i], a[i]);
    }

    return 0;
}
