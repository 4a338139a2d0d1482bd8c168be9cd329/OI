#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;
const int mo = 1004535809;

int a[N + 5], cur;
namespace SEG {

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    const int SZ = N << 2;

    ll mx[SZ + 5];
    ll sum[SZ + 5], tga[SZ + 5];

    struct node { 
        ll h, d; 
        node (ll h_ = 0, ll d_ = 0): h(h_), d(d_) { } 
    } hsum[SZ + 5], hadd[SZ + 5];

    inline node merge(const node& a, const node& b) {
        return node((a.h + b.h) % mo, (a.d + b.d) % mo);
    }

    inline void push_down(int u, int l, int r) {
        if(tga[u]) {
            tga[lc] += tga[u], mx[lc] += tga[u], (sum[lc] += tga[u] * (mid - l + 1)) %= mo;
            tga[rc] += tga[u], mx[rc] += tga[u], (sum[rc] += tga[u] * (r - mid)) %= mo;
            tga[u] = 0;
        }

        hadd[lc].d += hadd[u].d; hadd[lc].h += hadd[u].h;
        hadd[rc].d += hadd[u].d; hadd[rc].h += hadd[u].h;

        (hsum[lc].h += hadd[u].h * (mid - l + 1)) %= mo; 
        (hsum[lc].d += hadd[u].d * (mid - l + 1)) %= mo;

        (hsum[rc].h += hadd[u].h * (r - mid)) %= mo;
        (hsum[rc].d += hadd[u].d * (r - mid)) %= mo;

        hadd[u].h = hadd[u].d = 0;
    }

    void build(int u, int l, int r) {
        if(l == r) {
            sum[u] = mx[u] = a[l]; 
            hsum[u] = node(a[l], 0);
            return;
        }

        build(lc, l, mid);
        build(rc, mid+1, r);

        hsum[u] = merge(hsum[lc], hsum[rc]);
        mx[u] = std::max(mx[lc], mx[rc]);
        sum[u] = (sum[lc] + sum[rc]) % mo;
    }

    void add(int u, int l, int r, int x, int y, int v) {
        if(x <= l && r <= y) {
            mx[u] += v;
            tga[u] += v;
            sum[u] = (sum[u] + 1ll * v * (r - l + 1)) % mo;
            hsum[u].h = (hsum[u].h + 1ll * v * (r - l + 1)) % mo;
            hsum[u].d = (hsum[u].d + 1ll * v * (r - l + 1) % mo * cur) % mo;

            hadd[u].h = (hadd[u].h + v) % mo;
            hadd[u].d = (hadd[u].d + 1ll * v * cur) % mo;

            return;
        }
        push_down(u, l, r);

        if(x <= mid) 
            add(lc, l, mid, x, y, v);
        if(mid < y)
            add(rc, mid+1, r, x, y, v);

        hsum[u] = merge(hsum[lc], hsum[rc]);
        mx[u] = std::max(mx[lc], mx[rc]);
        sum[u] = (sum[lc] + sum[rc]) % mo;
    }

    inline ll query_hsm(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return 0;
        if(x <= l && r <= y) return (1ll * cur * hsum[u].h % mo - hsum[u].d + mo) % mo;
        push_down(u, l, r);
        return (query_hsm(lc, l, mid, x, y) + query_hsm(rc, mid+1, r, x, y)) % mo;
    }

    inline ll query_sum(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return 0;
        if(x <= l && r <= y) return sum[u];
        push_down(u, l, r);
        return (query_sum(lc, l, mid, x, y) + query_sum(rc, mid+1, r, x, y)) % mo;
    }

    inline ll query_max(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return -oo;
        if(x <= l && r <= y) return mx[u];
        push_down(u, l, r);
        return std::max(query_max(lc, l, mid, x, y), query_max(rc, mid+1, r, x, y));
    }
}

int n, m;
int main() {
    freopen("datastructure.in", "r", stdin);
    freopen("datastructure.out", "w", stdout);

    read(n), read(m);
    for(int i = 1; i <= n; ++i) read(a[i]);

    SEG::build(1, 1, n);

    for(cur = 1; cur <= m; ++cur) {
        static int op, x, y, z;

        read(op);
        read(x), read(y);

        if(op == 1) SEG::add(1, 1, n, x, y, read(z));
        if(op == 3) printf("%lld\n", SEG::query_sum(1, 1, n, x, y) % mo);
        if(op == 4) printf("%lld\n", SEG::query_hsm(1, 1, n, x, y) % mo);
        if(op == 5) printf("%lld\n", SEG::query_max(1, 1, n, x, y) % mo);
    }

    return 0;
}
