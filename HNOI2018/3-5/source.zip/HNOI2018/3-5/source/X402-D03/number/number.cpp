#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 500010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

bool flag;

namespace Seg_T {
#define mid ((l+r)>>1)
	struct node {
		int val, sz;
		node *ch[2], *fa;
		node(int x, node* f, node* c) {
			val = x, sz = 1;
			ch[0] = ch[1] = c;
			fa = f;
		}
	};
	node n(0, NULL, NULL);
	node *null;
	namespace Splay {
#define ls(x) ((x)->ch[0])
#define rs(x) ((x)->ch[1])
#define rel(x) (rs((x)->fa) == (x))
		inline void update(node* x) {
			x->sz = 1+ls(x)->sz + rs(x)->sz;
		}
		inline void rotate(node* x) {
			int f = rel(x);
			node *y = x->fa, *z = x->ch[f^1];
			//printf("%d %d %d %d\n", x->val, y->val, f, y->sz);
			x->fa = y->fa;
			if(y->fa != null) y->fa->ch[rel(y)] = x;
			(y->fa = x)->ch[f^1] = y;
			(z->fa = y)->ch[f] = z;
			update(y);
		}
		inline void splay(node* x) {
			for(node* y = x->fa; y != null; rotate(x), y = x->fa) 
				if(y->fa != null) rotate(rel(x) ^ rel(y) ? x : y);
			update(x);
		}
		inline void insert(node* &rt, int x) {
			if(rt == null) {
				rt = new node(x, null, null);
				return;
			}
			node* p = rt;
			while(true) {
				bool c = x > p->val;
				p->sz++;
				if(p->ch[c] == null) {
					rt = p->ch[c] = new node(x, p, null);
					splay(p->ch[c]);
					return;
				}
				p = p->ch[c];
			}
		}
		inline node* find(node *p) {
			while(rs(p) != null) p = rs(p);
			splay(p);
			return p;
		}
		inline node* find(node *p, int x) {
			while(true) {
				if(x == p->val) break;
				if(x > p->val) p = rs(p);
				else p = ls(p);
			}
			splay(p);
			return p;
		}
		inline int query(node* &rt, int x) {
			int res = 0;
			node *p = rt;
			while(p != null) {
				if(x > p->val) {
					res += ls(p)->sz+1;
					//if(rs(p) == null) rt = p;
					p = rs(p);
				}
				else {
					//if(ls(p) == null) rt = p;
					p = ls(p);
				}
			}
			//if(rt != null) splay(rt);
			return res;
		}
		inline void remove(node* &rt, int x) {
			node *p = find(rt, x);
			if(ls(p) != null && rs(p) != null) {
				ls(p)->fa = null;
				rt = find(ls(p));
				p = rs(p);
				free(p->fa);
				p->fa = rt; 
				rs(rt) = p;
				update(rt);
			}
			else if(ls(p) == null && rs(p) != null) {
				rt = rs(p), free(p);
				rt->fa = null;
			}
			else if(ls(p) != null && rs(p) == null) {
				rt = ls(p), free(p);
				rt->fa = null;
			}
			else free(p), rt = null;
		}
		inline void output(node *p) {
			if(p == null) return;
			printf("%d %d\n", p->val, p->sz);
			output(ls(p)), output(rs(p));
		}
#undef ls
#undef rs
	}
#define ls (p<<1)
#define rs (p<<1|1)
	node* rt[MAXN<<2];
	inline void init() {
		null = &n;
		null->sz = 0;
		for(int i = 0; i < MAXN<<2; i++) rt[i] = null;
	}
	inline int query(int p, int l, int r, int x, int y, int a, int b) {
		//printf("%d %d %d %d %d %d %d\n", p, l, r, x, y, a, b);
		if(l == x && r == y) {
			return Splay::query(rt[p], b+1)-Splay::query(rt[p], a);
		}
		if(y <= mid) return query(ls, l, mid, x, y, a, b);
		if(x > mid) return query(rs, mid+1, r, x, y, a, b);
		return query(ls, l, mid, x, mid, a, b)+query(rs, mid+1, r, mid+1, y, a, b);
	}
	inline void insert(int p, int l, int r, int x, int a) {
		Splay::insert(rt[p], a);
		if(l == r) return;
		if(x <= mid) insert(ls, l, mid, x, a);
		else insert(rs, mid+1, r, x, a);
	}
	inline void remove(int p, int l, int r, int x, int a) {
		Splay::remove(rt[p], a);
		if(l == r) return;
		if(x <= mid) remove(ls, l, mid, x, a);
		else remove(rs, mid+1, r, x, a);
	}

	inline void output(int p) {
		Splay::output(rt[p]);
	}
}

int n, p[MAXN], x[MAXN];
int st[MAXN], to[MAXN];
int nxt[MAXN], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

ll ans, res[MAXN];

void dfs(int u) {
	int i;
	ll cur = 0;
	if(u != 1) {
		//if(u == 3) flag = true;
		if(p[u] > 1 && x[u] > 1) cur = Seg_T::query(1, 1, n, 1, p[u]-1, 1, x[u]-1);
		if(p[u] < n && x[u] < n) cur += Seg_T::query(1, 1, n, p[u]+1, n, x[u]+1, n);
		ans += cur;
		Seg_T::insert(1, 1, n, p[u], x[u]);
	}
	res[u] = ans;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		dfs(v);
	}
	ans -= cur;
	if(u != 1) Seg_T::remove(1, 1, n, p[u], x[u]);
}

int main() {
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);

	int i;

	n = read();
	for(i = 2; i <= n+1; i++) {
		int fa = read()+1;
		p[i] = read(), x[i] = read();
		Add(fa, i);
	}
	Seg_T::init();
	dfs(1);
	for(i = 2; i <= n+1; i++) printf("%lld\n", res[i]);
	cerr << clock() << endl;
	return 0;
}
