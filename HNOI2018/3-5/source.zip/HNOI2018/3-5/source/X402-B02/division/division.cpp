#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=a; i<=b; ++i)
const int N=1e3+10;
const int E=1<<10;
using namespace std;

int n,m,a[N];
namespace buf{
	void solve(){
		freopen("division.in","r",stdin);
		freopen("division.out","w",stdout);
		scanf("%d%d",&n,&m);
		for(int i=1; i<=n; ++i) scanf("%d",&a[i]);
	}
}

int main(){
	buf::solve();
}
