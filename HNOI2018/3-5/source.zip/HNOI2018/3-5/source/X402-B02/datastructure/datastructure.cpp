#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
}
