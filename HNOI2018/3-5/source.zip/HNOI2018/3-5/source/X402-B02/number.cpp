#include<bits/stdc++.h>
const int N=5e5+10;
using namespace std;

int c[N],n,m,ans[N],bgn[N],to[N],e,nxt[N];
int in[N],ot[N],tim;

struct node{
	int t,p,x,id;
};

struct node p[N],q[N],R[N],g[N];

bool cmp(struct node a,struct node b){
//f(a.t==b.t && a.p==b.p) return a.x<b.x;
//f(a.t==b.t) return a.p<b.p;
	return a.t<b.t;
}

bool cmp2(struct node a,struct node b){
	return a.p<b.p;
}


namespace bit{
	int lowbit(int x) {return (x&-x);}
	void add(int x,int y){
		while(x<=n){
			c[x]+=y;
			x+=lowbit(x);
		}
	}
	int sum(int x){
		int y=0;
		if(x<0) return 0;
		while(x){
			y+=c[x];
			x-=lowbit(x);
		}
		return y;
	}
}
using namespace bit;

namespace hehe{
	void solve(int l,int r,int ql,int qr){
		int qu=l-1,mi=0,mm=(ql+qr)>>1;
		
		sort(R+ql+1,R+qr+1,cmp2);		
		for(int i=l; i<=r; ++i){
			if(R[i].p<=mm) q[++qu]=R[i];
		} 
		mi=qu;
		for(int i=l; i<=r; ++i){
			if(R[i].p>mm) q[++qu]=R[i];
		}
		int l1=l,l2=mm+1;

		while(l2<=qr){
			while(q[l1].t<=p[l2].t&&l1<=mi)add(q[l1].x,q[l1].id),++l1;
			ans[p[l2].id]+=sum(p[l2].x-1);++l2;
		}
		l1=l,l2=mm+1;
		while(l2<=qr){
			while(q[l1].t<=p[l2].t&&l1<=mi)add(q[l1].x,-q[l1].id),++l1;
			++l2;
		}
		if(ql==qr) return;
		sort(R+ql+1,R+qr+1,cmp);
		solve(l,((l+r)>>1),ql,mm);
		solve(((l+r)>>1)+1,r,mm+1,qr);
	}
	void add(int x,int y){
		to[e]=y; nxt[e]=bgn[x]; bgn[x]=e++;
	}
	void dfs(int x,int f=0){
		in[x]=++tim;
		for(int i=bgn[x]; i!=-1; i=nxt[i]){
			int y=to[i];
			if(y==f) continue;
			dfs(y,x);
		}
		ot[x]=++tim;
	}
	void calc(int x,int f=0){
		for(int i=bgn[x]; i!=-1; i=nxt[i]){
			int y=to[i];
			if(y==f) continue;
			ans[y]+=ans[x];
			calc(y,x);
		}
	}
	void Solve(){
		tim=-1;
		memset(bgn,-1,sizeof(bgn));
		scanf("%d",&n);
		for(int i=1; i<=n; ++i){
			scanf("%d%d%d",&g[i].t,&g[i].p,&g[i].x);
			g[i].id=i;
			add(g[i].t,i);
		}
		dfs(0);
		for(int i=1; i<=n; ++i){
			R[++m]=(node){in[i],g[i].p,g[i].x,1};
			R[++m]=(node){ot[i],g[i].p,g[i].x,-1};
			p[i]=(node){in[i],g[i].p,g[i].x,i};
		}
		sort(R+1,R+m+1,cmp);
		sort(p+1,p+n+1,cmp);
		solve(1,m,1,n);
		calc(0);
		for(int i=1; i<=n; ++i) printf("%d\n",ans[i]);
	}
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	hehe::Solve();
}
