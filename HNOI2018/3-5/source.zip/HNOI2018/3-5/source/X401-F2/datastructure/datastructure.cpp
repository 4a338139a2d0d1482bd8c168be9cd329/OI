#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
#define maxn 100010
#define LL long long

struct node{
	LL val;
	bool f;
}tr[maxn<<2];

inline void pushup(int o){
	tr[o].val=tr[o<<1].val+tr[o<<1|1].val;
	tr[o].f=tr[o<<1].f&tr[o<<1|1].f;
}

void build(int o,int l,int r){
	if(l==r){read(tr[o].val);return ;}
	int M=l+r>>1;
	build(o<<1,l,M);build(o<<1|1,M+1,r);
	pushup(o);
}

void update(int o,int l,int r,int ql,int qr){
	if(tr[o].f) return ;
	if(l==r){tr[o].val=sqrt(tr[o].val);if(tr[o].val==1||!tr[o].val) tr[o].f=1;return ;}
	pushup(o);int M=l+r>>1;
	if(ql<=M)update(o<<1,l,M,ql,qr);
	if(qr>M) update(o<<1|1,M+1,r,ql,qr);
	pushup(o);
	return ;
}

LL query(int o,int l,int r,int ql,int qr,LL ans=0){
	if(ql<=l&&qr>=r) return tr[o].val;
	int M=l+r>>1;
	if(ql<=M) ans+=query(o<<1,l,M,ql,qr);
	if(qr>M) ans+=query(o<<1|1,M+1,r,ql,qr);
	tr[o].val=tr[o<<1].val+tr[o<<1|1].val;
	return ans;
}

int main()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
	int q,l,r,op,n;
	read(n);build(1,1,n);read(q);
	for(int i=1;i<=q;i++){
		read(op),read(l),read(r);
		if(--op==0) printf("%lld\n",query(1,1,n,l,r));
		else update(1,1,n,l,r);
	}
	return 0;
}
