#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 200100, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}

int n, m;
int A[N];
struct Segment_tree{
    #define Mid ((l+r)>>1)
    #define Lc h<<1,l,Mid
    #define Rc h<<1|1,Mid+1,r
    ll Sum[N<<2], Add[N<<2];
    inline void Pushup(int h){Sum[h]=Sum[h<<1]+Sum[h<<1|1];}
    inline void Pushdown(int h,int l,int r){
        int lc=h<<1,rc=h<<1|1;
        if(Add[h]){
            Sum[lc]+=Add[h]*(Mid-l+1);
            Sum[rc]+=Add[h]*(r-Mid);
            Add[lc]+=Add[h],Add[rc]+=Add[h];
            Add[h]=0;
        }
    }
    void Build(int h,int l,int r){
        if(l==r)return void(Sum[h]=A[l]);
        Build(Lc),Build(Rc);
        Pushup(h);
    }
    void add(int h,int l,int r,int L,int R,ll val){
        if(l>=L&&r<=R){
            Sum[h]+=(r-l+1)*val,Add[h]+=val;
            return ;
        }
        Pushdown(h,l,r);
        if(L<=Mid)add(Lc,L,R,val);
        if(R>Mid)add(Rc,L,R,val);
        Pushup(h);
    }
    ll Query(int h,int l,int r,int L,int R){
        if(l>=L&&r<=R)return Sum[h];
        Pushdown(h,l,r);
        ll ans=0;
        if(L<=Mid)ans+=Query(Lc,L,R);
        if(R>Mid)ans+=Query(Rc,L,R);
        return ans;
    }
}t;
inline void file(){
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);
}
void init(){
	read(n), read(m);
	For(i, 1, n)read(A[i]);
	t.Build(1, 1, n);
	
}
void solve(){
	For(i, 1, m){
		int tp, l, r, x;
		read(tp), read(l), read(r);
		if(tp == 1){
			read(x);
			t.add(1, 1, n, l, r, x);
		}else if(tp == 3){
			printf("%lld\n" ,t.Query(1, 1, n , l, r));
		}
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
