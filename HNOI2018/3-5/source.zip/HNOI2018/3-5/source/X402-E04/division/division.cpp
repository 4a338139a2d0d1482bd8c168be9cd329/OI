#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 18, INF = 0x3f3f3f3f, Mod = 1004535809;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int dp[N+1][1<<18][21], n, m;
inline void file(){
	freopen("division.in","r",stdin);
	freopen("division.out","w",stdout);
}
int w[N], all, v[1<<N] ,st[1<<N];
#define bitc __builtin_popcount
void init(){
	read(n), read(m);
	For(i, 1, n)
		read(w[i]);
	sort(w + 1, w + n + 1);
	all = (1<<n) - 1;
	For(i, 1, all){
		if(bitc(i) == 1){
			v[i] = 0;
			st[i] = i;
		}
		else {
			For(j, 0, n-1)
				if(i&(1<<j)){
					v[i] -= w[j + 1];
					st[i] |= (1<<j);
					break;
				}
			Forr(j, n-1, 0)
				if(i&(1<<j)){
					v[i] += w[j + 1];
					st[i] |= (1<<j);
					break;
				}
		}
	}
}
inline void add(int &a, int b){
	a=(a+b) % Mod;
}
ll qpow(ll a, ll b){
	ll ret = 1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}

void solve(){
	dp[0][0][0] = 1;
	For(s, 0, all){
		For(j, 0, m)
			For(k, 0, bitc(s))
				if(dp[k][s][j]){
					for(int t = s^all;t;t = (t - 1) & (s^all))
						add(dp[k+1][s^t][min(j+v[t],m)], dp[k][s][j]);
				}
	}
	int ans = 0, fac = 1;
	For(i, 1, n){
		fac = 1ll * fac * i % Mod;
		ans = (ans + dp[i][all][m] * qpow(fac, Mod - 2) % Mod) % Mod;
	}
	printf("%d\n", ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
