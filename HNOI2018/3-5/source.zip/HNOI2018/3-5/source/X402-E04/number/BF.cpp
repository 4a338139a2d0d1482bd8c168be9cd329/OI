#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 5100, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("number.in","r",stdin);
	freopen("BF.out","w",stdout);
#endif 
}
int n, m, a[N][N], ans[N];
inline void init(){
	read(m);
}
void solve(){
	For(i, 1, m){
		int t, p, x;
		read(t), read(p), read(x);ans[i] = ans[t];
		For(j, 1, p)if(a[t][j] < x && a[t][j])ans[i] ++;
		For(j, p, m)if(a[t][j] > x && a[t][j])ans[i] ++;
		For(j, 1, m)a[i][j] = a[t][j];
		a[i][p] = x;
		printf("%d\n", ans[i]);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
