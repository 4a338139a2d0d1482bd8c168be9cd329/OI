#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 500010;
inline void file(){
	freopen("number.in","w",stdout);
}
int a[N], b[N];
int main(){
	file();
	int n = 5000;
	srand(time(0));
	printf("%d\n", n);
	a[1] = b[1] =1;
	For(i, 2, n)a[i] = b[i] = i, swap(a[i], a[rand()%(i-1)+1]), swap(b[i], b[rand()%(i-1)+1]);
	For(i, 1, n){
		printf("%d %d %d\n", rand()%i, a[i], b[i]);
	}
	return 0;
}
