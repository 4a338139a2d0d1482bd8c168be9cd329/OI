#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 500010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
}
int n;
namespace st{
	const int N=500100;
	#define L(i) (T[i].s[0])
	#define R(i) (T[i].s[1])
	#define S(i) (T[i].S)
	#define mid ((l+r)>>1)
	#define Lc L(h),l,mid
	#define Rc R(h),mid+1,r
	struct node{
		int s[2],S;
		node(){s[1]=s[0]=S=0;}
	}T[N*30];
	int cnt,rt[N],root[N],q;
	int A[N];
	inline int lowbit(int x){return x&-x;}
	void insert(int &h,int l,int r,int p,int val){
		T[++cnt]=T[h],h=cnt,S(h)+=val;
		if(l==r)return ;
		if(p<=mid)insert(Lc,p,val);
		else insert(Rc,p,val);
	}
	void add(int x,int val){
		int p=A[x];
		for(;x<=n;x+=lowbit(x))insert(rt[x],1,n,p,val);
	}
	int Query(int h, int l, int r, int p, int tp){
		if(!h)return 0;
		if(l == r)return 0;
		int ret;
		if(p <= mid)ret=(tp?S(R(h)):0) + Query(Lc, p, tp);
		else ret=(tp?0:S(L(h))) + Query(Rc, p, tp);
		return ret;
	}
	int Query(int l,int r,int k, int tp){
		l--;
		ll ans = 0;
		for(int x=r;x;x-=lowbit(x))ans+=Query(rt[x], 1, n, k, tp);
		for(int x=l;x;x-=lowbit(x))ans-=Query(rt[x], 1, n, k, tp);
		return ans;
	}
}
int Begin[N], Next[N], to[N], e, p[N], X[N];
inline void adde(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
void init(){
	read(n);
	For(i, 1, n){
		int t;
		read(t), read(p[i]), read(X[i]);
		adde(t, i);
	}
}
ll ans[N];
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
ll Add(int x, int y){
	using namespace st;
	int ret = 0;
	ret += x>1?Query(1, x-1, y, 0):0;
	ret += x<n?Query(x+1, n, y, 1):0;
	A[x] = y, add(x, 1);
	return ret;
}
void Del(int x){
	using namespace st;
	add(x, -1);A[x] = 0;
}
int fa[N], dep[N];
void dfs(int u, int f){
	fa[u] = f;
	Rep(i,u)
		dep[v] = dep[u] + 1, dfs(v, u);
}
inline bool check(){
	ll sum = 0;
	For(i, 1, n)sum += dep[i];
	return sum <= 3e8;
}
void dfs1(int u){
	if(u){
		int v = u;
		while(fa[v]){
			if(p[fa[v]] > p[u] && X[fa[v]] > X[u])ans[u] ++;
			if(p[fa[v]] < p[u] && X[fa[v]] < X[u])ans[u] ++;
			v = fa[v];
		}
		ans[u] += ans[fa[u]];
	}
	Rep(i, u)dfs1(v);
}
void dfs2(int u){
	Rep(i, u)
		ans[v] = ans[u] + Add(p[v], X[v]), dfs2(v), Del(p[v]);
}
void solve(){
	dfs(0, 0);
	if(check())dfs1(0);
	else dfs2(0);
	For(i, 1, n)printf("%lld\n", ans[i]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
