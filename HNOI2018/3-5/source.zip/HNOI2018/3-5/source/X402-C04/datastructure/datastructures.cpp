
#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=200009;
const int md=1004535809;

inline ll maxx(ll a,ll b){return a>b?a:b;}

inline void write(ll x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

int n,m;
ll a[N];

int main()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructures.out","w",stdout);

	n=read();m=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1,ty,l,r;i<=m;i++)
	{
		ty=read();l=read();r=read();
		if(ty==1)
		{
			int x=read();
			for(int i=l;i<=r;i++)
				a[i]+=x;
		}
		else if(ty==3)
		{
			ll ans=0;
			for(int i=l;i<=r;i++)
				(ans+=a[i])%=md;
			printf("%lld\n",ans);
		}
		else if(ty==5)
		{
			ll ans=0;
			for(int i=l;i<=r;i++)
				ans=maxx(ans,a[i]);
			printf("%lld\n",ans%md);
		}
	}

	return 0;
}
