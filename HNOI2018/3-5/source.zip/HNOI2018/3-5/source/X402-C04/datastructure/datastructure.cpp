#include<bits/stdc++.h>
using namespace std;


typedef long long ll;
const int N=200009;
const int md=1004535809;

inline ll maxx(ll a,ll b){return a>b?a:b;}

inline ll read()
{
	ll x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void write(ll x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

int n,m;

namespace segt
{
	ll tsum[N<<2],tmax[N<<2],tag[N<<2];

	inline void mark(int x,int l,int r,ll v)
	{
		tmax[x]+=v;tag[x]+=v;v%=md;
		(tsum[x]+=(r-l+1)*v%md)%=md;
	}

	inline void push(int x,int l,int r)
	{
		if(tag[x])
		{
			int mid=l+r>>1;
			mark(x<<1,l,mid,tag[x]);
			mark(x<<1|1,mid+1,r,tag[x]);
			tag[x]=0;
		}
	}

	inline void update(int x)
	{
		tsum[x]=(tsum[x<<1]+tsum[x<<1|1])%md;
		tmax[x]=maxx(tmax[x<<1],tmax[x<<1|1]);
	}

	inline void build(int x,int l,int r)
	{
		if(l==r)
		{
			tsum[x]=(tmax[x]=read())%md;
			return;
		}
		int mid=l+r>>1;
		build(x<<1,l,mid);
		build(x<<1|1,mid+1,r);
		update(x);
	}

	inline void modify(int x,int l,int r,int dl,int dr,ll v)
	{
		if(dl==l && r==dr){mark(x,l,r,v);return;}
		push(x,l,r);int mid=l+r>>1;
		if(dr<=mid)modify(x<<1,l,mid,dl,dr,v);
		else if(mid<dl)modify(x<<1|1,mid+1,r,dl,dr,v);
		else modify(x<<1,l,mid,dl,mid,v),modify(x<<1|1,mid+1,r,mid+1,dr,v);
		update(x);
	}

	inline ll query3(int x,int l,int r,int dl,int dr)
	{
		if(dl==l && r==dr)return tsum[x];
		push(x,l,r);int mid=l+r>>1;
		if(dr<=mid)return query3(x<<1,l,mid,dl,dr);
		if(mid<dl)return query3(x<<1|1,mid+1,r,dl,dr);
		return (query3(x<<1,l,mid,dl,mid)+query3(x<<1|1,mid+1,r,mid+1,dr))%md;
	}

	inline ll query5(int x,int l,int r,int dl,int dr)
	{
		if(dl==l && r==dr)return tmax[x];
		push(x,l,r);int mid=l+r>>1;
		if(dr<=mid)return query5(x<<1,l,mid,dl,dr);
		if(mid<dl)return query5(x<<1|1,mid+1,r,dl,dr);
		return maxx(query5(x<<1,l,mid,dl,mid),query5(x<<1|1,mid+1,r,mid+1,dr));
	}
}

int main()
{
	freopen("datastructure.in","r",stdin);
	freopen("datastructure.out","w",stdout);

	n=read();m=read();
	segt::build(1,1,n);
	for(int i=1,ty,l,r;i<=m;i++)
	{
		ty=read();l=read();r=read();
		cerr<<l<<" "<<r<<endl;
		if(ty==1)
			segt::modify(1,1,n,l,r,read());
		else if(ty==3)
			write(segt::query3(1,1,n,l,r)%md),putchar('\n');
		else if(ty==5)
			write(segt::query5(1,1,n,l,r)%md),putchar('\n');
	}

	return 0;
}
