#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=1000;
const int M=1000;

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("datastructure.in","w",stdout);

	int n=1000,m=1000;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
		printf("%lld ",urand());
	puts("");
	for(int i=1;i<=m;i++)
	{
		int ty=rand()%3*2+1,l,r;
		l=urand()%n+1,r=urand()%n+1;
		if(l>r)swap(l,r);
		printf("%d %d %d",ty,l,r);
		if(ty==1)printf(" %d\n",urand()%((int)1e9+1));
		else printf("\n");
	}

	return 0;
}
