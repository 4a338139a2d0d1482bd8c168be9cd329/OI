#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=309;
const int M=1009;
const int md=1004535809;

int n,m,w[N],ans;
vector<int> vec[N];
bool vis[N];

inline int calc(int id)
{
	int minv=1e9,maxv=-1e9;
	for(int i=0;i<vec[id].size();i++)
	{
		minv=min(minv,vec[id][i]);
		maxv=max(maxv,vec[id][i]);
	}
	return maxv-minv;
}

inline void dfs(int id,int cur)
{
	if(id>n)
	{
		int sum=0;
		for(int i=1;i<=cur;i++)
			sum+=calc(i);
		if(sum>=m)
		{
			ans++;
			/*for(int i=1;i<=cur;i++,puts(""))
				for(int j=0;j<vec[i].size();j++)
					printf("%d ",vec[i][j]);
			puts("");*/

			if(ans>=md)ans-=md;
		}
		return;
	}

	for(int i=1;i<=cur;i++)
	{
		vec[i].push_back(w[id]);
		dfs(id+1,cur);
		vec[i].pop_back();
	}
	vec[cur+1].push_back(w[id]);
	dfs(id+1,cur+1);
	vec[cur+1].pop_back();
}

namespace m1
{
	int ww[M],ccnt;
	ll s[M][M],b[M],c[M][M];

	inline void init()
	{
		s[0][0]=1;
		for(int i=1;i<M;i++)
		{
			s[i][0]=0;
			for(ll j=1;j<=i;j++)
				s[i][j]=(s[i-1][j-1]+j*s[i-1][j]%md)%md;
		}
		for(int i=0;i<M;i++)
			for(int j=0;j<=i;j++)
				(b[i]+=s[i][j])%=md;

		c[0][0]=1;
		for(int i=1;i<M;i++)
		{
			c[i][0]=c[i][i]=1;
			for(int j=1;j<i;j++)
				c[i][j]=(c[i-1][j-1]+c[i-1][j])%md;
		}
	}

	int main()
	{
		init();
		int mx=0;
		for(int i=1;i<=n;i++)
		{
			if((++ww[w[i]])==1)
				ccnt++;
			mx=max(mx,w[i]);
		}
		ll ans=0,base=0;
		
		for(int i=1;i<=mx;i++)
			if(ww[i])
				for(int j=i+1;j<=mx;j++)
					if(ww[j])
					{
						printf("%d %d\n",c[ww[i]+ww[j]][2],b[n-1]-1);
						(ans+=c[ww[i]+ww[j]][2]*(b[n-1]-1)%md)%=md;
					}
		ans++;
		printf("%lld\n",(ans%md+md)%md);
		return 0;
	}
}

namespace dp
{
	const int K=(1<<18)+9;
	int f[K][23],g[K][23];

	inline void dfs(int las,int vis,int maxv,int minv)
	{
		if(las==n+1)
		{
			if(vis)
				f[vis][min(maxv-minv,m)]++;
			return;
		}

		for(int i=las+1;i<=n;i++)
			dfs(i,vis|(1<<i-1),max(maxv,w[i]),min(minv,w[i]));
		dfs(n+1,vis,maxv,minv);
	}

	int main()
	{
		dfs(0,0,-1e9,1e9);

		int k=1<<n;
		for(int i=1;i<k;i++)
			for(int v=0;v<=m;v++)
			{
				g[i][v]+=f[i][v];
				for(int rev=(k-1)^i,j=rev;j;j=(j-1)&rev)
					if(j<i)
						for(int vv=0;vv<=m;vv++)
							g[i|j][min(v+vv,m)]+=g[i][v]*g[j][vv]%md;
			}
		
		printf("%d\n",g[k-1][m]);
		return 0;
	}
}

int main()
{
	freopen("division.in","r",stdin);
	freopen("division.out","w",stdout);

	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&w[i]);
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}
