#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=500009;

int n,flag;
int to[N],nxt[N],p[N],x[N],beg[N],tot;
ll ans[N];

inline void write(ll x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

namespace sbt
{
	int ch[N][2],sum[N],exi[N],rt;

	inline void update(int x)
	{
		sum[x]=sum[ch[x][0]]+sum[ch[x][1]]+exi[x];
	}

	inline void rotate(int x)
	{
		int y=fa[x],z=fa[y];
		int l=(ch[y][1]==x);
		if(z)ch[z][ch[z][1]==y]=x;
		fa[x]=z;fa[y]=x;fa[ch[x][l^1]]=y;
		ch[y][l]=ch[x][l^1];ch[x][l^1]=y;
		update(y);update(x);
		if(!z)rt=x;
	}

	inline void insert(int x)
	{
		int now=rt,fat=0,son;
		while(now)
		{
			fat=now;
			if(p[x]<p[now])
				now=ch[now][son=0];
			else
				now=ch[now][son=1];
		}
		fa[x]=fat;exi[x]=1;
		if(fat)ch[fat][son]=x;
		else rt=x;
		while(x<fa[x])rotate(x);
		for(int i=x;i;i=fa[i])
			update(i);
	}

	inline void del(int x)
	{
		exi[x]=0;
		for(int i=x;i;i=fa[i])
			update(i);
	}

	inline int lower(int now,int x)
	{
		if(!now || now>=x)return 0;
		int ret=lower(ch[now][0],x);
		if(p[x]<=p[now])return ret;
		else return ret+lower(ch[now][1],x)+exi[now];
	}

	inline int upper(int now,int x)
	{
		if(!now)return 0;
		int ret=upper(ch[now][1],x);
		if(p[now]<=p[x])return ret;
		else return ret+upper(ch[now][0],x)+(exi[now] && now>x)
	}
}


inline void add(int u,int v,int a,int b)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	p[tot]=a;
	x[tot]=b;
	beg[u]=tot;
}

inline void dfs(int u,ll cans)
{
	ans[u]=cans;
	for(int i=beg[u];i;i=nxt[i])
	{
		cans=ans[u];
		cans+=bit.query(p[i],1,x[i]-1);
		cans+=bit.query(n,x[i]+1,n)-bit.query(p[i],x[i]+1,n);
		bit.modify(p[i],x[i],1);
		dfs(to[i],cans);
		if(flag)bit.modify(p[i],x[i],-1);
	}
}

int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);

	pst::init();
	n=read();
	for(int i=1,a,b,c;i<=n;i++)
	{
		a=read();
		b=read();
		c=read();
		add(a,i,b,c);
		if(a!=i-1)flag=1;
	}

	dfs(0,0);
	for(int i=1;i<=n;i++)
		write(ans[i]),putchar('\n');
	cerr<<clock()<<" "<<4*sizeof(pst::t)/1024/1024<<endl;
	return 0;
}
