#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=500009;

int n,flag;
int to[N],nxt[N],p[N],x[N],beg[N],tot;
ll ans[N];

inline void write(ll x)
{
	if(x>=10)write(x/10);
	putchar('0'+x%10);
}

namespace pst
{
	const int M=N*20;

	int ls[M],rs[M],t[M],stk[M],top;

	inline void init()
	{
		for(int i=1;i<M;i++)
			stk[++top]=i;
	}

	inline int newnode()
	{
		assert(top>=1);
		int ret=stk[top--];
		t[ret]=ls[ret]=rs[ret]=0;
		return ret;
	}

	inline void free(int &x)
	{
		if(!x)return;
		stk[++top]=x;
		if(ls[x])free(ls[x]);
		if(rs[x])free(rs[x]);
		x=0;t[x]=0;
	}

	inline void modify(int &now,int l,int r,int p,int v)
	{
		if(!now)now=newnode();t[now]+=v;
		int mid=l+r>>1;if(l==r)goto ed;
		if(p<=mid)modify(ls[now],l,mid,p,v);
		else modify(rs[now],mid+1,r,p,v);
		ed:;if(!t[now])free(now);
	}

	inline int query(int x,int l,int r,int dl,int dr)
	{
		if(!x || (dl==l && r==dr))return t[x];
		int mid=l+r>>1;
		if(dr<=mid)return query(ls[x],l,mid,dl,dr);
		if(mid<dl)return query(rs[x],mid+1,r,dl,dr);
		return query(ls[x],l,mid,dl,mid)+query(rs[x],mid+1,r,mid+1,dr);
	}
}

struct bits
{
	int rt[N];

	inline void modify(int x,int v,int dlt)
	{
		for(int i=x;i<=n;i+=i&-i)
			pst::modify(rt[i],1,n,v,dlt);
	}

	inline int query(int x,int l,int r)
	{
		int ret=0;
		for(int i=x;i;i-=i&-i)
			ret+=pst::query(rt[i],1,n,l,r);
		return ret;
	}
}bit;

inline void add(int u,int v,int a,int b)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	p[tot]=a;
	x[tot]=b;
	beg[u]=tot;
}

inline void dfs(int u,ll cans)
{
	ans[u]=cans;
	for(int i=beg[u];i;i=nxt[i])
	{
		cans=ans[u];
		cans+=bit.query(p[i],1,x[i]-1);
		cans+=bit.query(n,x[i]+1,n)-bit.query(p[i],x[i]+1,n);
		bit.modify(p[i],x[i],1);
		dfs(to[i],cans);
		if(flag)bit.modify(p[i],x[i],-1);
	}
}

int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);

	pst::init();
	n=read();
	for(int i=1,a,b,c;i<=n;i++)
	{
		a=read();
		b=read();
		c=read();
		add(a,i,b,c);
		if(a!=i-1)flag=1;
	}

	dfs(0,0);
	for(int i=1;i<=n;i++)
		write(ans[i]),putchar('\n');
	return 0;
}
