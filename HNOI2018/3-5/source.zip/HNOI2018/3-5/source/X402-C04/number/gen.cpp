#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=500009;

inline int urand()
{
	return (long long)rand()<<15|rand()&2147483647;
}

int p[N],x[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("number.in","w",stdout);

	int n=50000;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		p[i]=i;
	for(int i=1;i<=n;i++)
		x[i]=i;
	random_shuffle(p+1,p+n+1);
	random_shuffle(x+1,x+n+1);
	for(int i=1;i<=n;i++)
		printf("%d %d %d\n",i-1,p[i],x[i]);

	return 0;
}
