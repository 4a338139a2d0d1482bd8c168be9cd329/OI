#include <bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define pb push_back
#define mp make_pair

using namespace std;


vector<pair<ll,ll> > pnt[2];


void addPoint(ll pos,ll cnt){
#ifdef DEBUG
	printf("[addPoint] %lld %lld\n",pos,cnt);
#endif
	pnt[pos&1].pb(mp(pos,cnt));
	pnt[pos&1].pb(mp(pos+2,-cnt));
}

void addSeg(ll l,ll r){
#ifdef DEBUG
	printf("[addSeg] %lld %lld\n",l,r);
	assert((l&1)==(r&1));
#endif
	if (l>r) swap(l,r);
	pnt[l&1].pb(mp(l,1));
	pnt[l&1].pb(mp(r+2,-1));
}


ll doit(int k){
	ll ret=0,sum=0;
	sort(pnt[k].begin(),pnt[k].end());
	int n(pnt[k].size());
	for (int i=0;i<n;++i)
		ret=max(ret,sum+=pnt[k][i].se);
	return ret;
}


typedef pair<ll,int> Pair;

vector<Pair> a[2];
void work(){
	for (int k=0,tmp;k<2;++k){
		a[k].clear();
//		vector<Pair>(a[k]).swap(a[k]);
		for (scanf("%d",&tmp);tmp;--tmp){
			Pair p;
			scanf("%d%lld",&p.se,&p.fi);
			a[k].pb(p);
		}
		pnt[k].clear();
//		vector<pair<ll,ll> >(pnt[k]).swap(pnt[k]);
	}
	int p[2]={int(a[0].size())-1,int(a[1].size())-1};
	addPoint(0,1);
	for (ll pos=0;p[0]>=0&&p[1]>=0;){
		#define now(x) (a[x][p[x]])
		int k=now(0).fi>now(1).fi;
		ll t=now(k).fi;
		now(k^1).fi-=now(k).fi;
		int v=now(1).se-now(0).se;
		
		if (v==0) addPoint(pos,t);
		else if (abs(v)==1){
			addSeg(pos+v,pos+v*(t-(t&1^1)));
			if (t>1) addSeg(pos+v*2,pos+v*(t-(t&1)));
		}
		else addSeg(pos+v,pos+v*t);
		
		pos+=v*t;
		--p[k];
		if (now(k^1).fi==0) --p[k^1];
	}
	assert(p[0]<0&&p[1]<0);
	printf("%lld\n",max(doit(0),doit(1)));
}

int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--) work();
	return 0;
}
