#include <bits/stdc++.h>
#define M 233
#define ll long long
#define P 998244353

using namespace std;

struct matrix{
	int x,y;
	int a[M][M];
	matrix(){}
	matrix(int _x,int _y):x(_x),y(_y){memset(a,0,sizeof(a));}
	matrix(int _x){
		x=y=_x;
		memset(a,0,sizeof(a));
		for (int i=1;i<=_x;++i) a[i][i]=1;
	}
	matrix(const matrix &_m):x(_m.x),y(_m.y){
		for (int i=1;i<=x;++i)
			for (int j=1;j<=y;++j)
				a[i][j]=_m.a[i][j];
	}
	void print(){
		for (int i=1;i<=x;++i,puts(""))
			for (int j=1;j<=y;++j)
				printf("%d",a[i][j]);
	}
};
 
inline void mul(const matrix &a,const matrix &b,matrix &ret){
	assert(a.y==b.x);
	ret=matrix(a.x,b.y);
	int z=a.y;
	for (int i=1;i<=ret.x;++i)
		for (int j=1;j<=ret.y;++j){
			ret.a[i][j]=0;
			for (int k=1;k<=z;++k)
				ret.a[i][j]=(1LL*a.a[i][k]*b.a[k][j]+ret.a[i][j])%P;
		}
}
 

const int maxstamp=25;

matrix A,B;
int cost[maxstamp];
int id[1][2][3][4],stamp;
int f[maxstamp];
int msk[maxstamp][4];
bool eq[4][4];
int m;


void init(int C,int K){
	int stamp=0;
	for (int i[4]={0,0,0,0};i[0]<1;++i[0])
		for (i[1]=0;i[1]<2;++i[1])for (i[2]=0;i[2]<3;++i[2])for (i[3]=0;i[3]<4;++i[3]){
			bool valid=1;
			for (int k=0;valid&&k<4;++k) if(i[i[k]]!=i[k]) valid=0;
			if (!valid) continue;
			id[i[0]][i[1]][i[2]][i[3]]=++stamp;
			cost[stamp]=(i[0]==i[1])+(i[0]==i[2])+(i[1]==i[3])+(i[2]==i[3]);
			f[stamp]=0;
			for (int k=0;k<4;++k) msk[stamp][k]=i[k],f[stamp]+=(i[k]==k);
		}
	m=stamp*(K+1)+1;
	A=matrix(m,m);
	B=matrix(m,1);
	for (int i=1;i<=stamp;++i)if (cost[i]<=K){
		int _left=C,_count=1;
		for (int k=f[i];k;--k)
			_count=1LL*_count*(_left--)%P;
		B.a[stamp*cost[i]+i][1]=_count;
		for (int j=1;j<=stamp;++j)
			for (int b=(1<<(f[i]*f[j]))-1;b>=0;--b){
				int tmp=b;
				int count_1=0;
				for (int k0=0;k0<4;++k0)if (msk[i][k0]==k0)
					for (int k1=0;k1<4;++k1)if (msk[j][k1]==k1){
						eq[k0][k1]=tmp&1;
						count_1+=(tmp&1);
						tmp>>=1;
					}
				for (int k0=0;k0<4;++k0)for (int k1=0;k1<4;++k1)
					if (msk[i][k0]!=k0||msk[j][k1]!=k1)
						eq[k0][k1]=eq[msk[i][k0]][msk[j][k1]];
				bool valid=1;
				for (int k0=0;k0<4;++k0)for (int k1=0;k1<4;++k1)for (int k2=0;k2<4;++k2){
					if (msk[i][k0]!=msk[i][k1]&&eq[k0][k2]&&eq[k1][k2]){valid=0;break;}
					if (msk[j][k1]!=msk[j][k2]&&eq[k0][k1]&&eq[k0][k2]){valid=0;break;}
				}
				if (!valid) continue;
				_count=1;_left=C-f[i];
				if (_left<0) continue;
				for (int k=f[j]-count_1;k>0;--k)
					_count=1LL*_count*(_left--)%P;
				int _fee=cost[j];
				for (int k=0;k<4;++k) _fee+=eq[k][k];
				for (int k=0;k+_fee<=K;++k){
					A.a[stamp*(k+_fee)+j][stamp*k+i]=((ll)A.a[stamp*(k+_fee)+j][stamp*k+i]+_count)%P;
				}
			}
	}
	for (int i=1;i<=m;++i) A.a[m][i]=1;
}



const int b=60;
matrix binA[b+1];

int main(){
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	int c,k,Q;
	scanf("%d%d%d",&c,&k,&Q);
	init(c,k);
	
	binA[0]=A;
	for (int i=1;i<b;++i)
		mul(binA[i-1],binA[i-1],binA[i]);
	
	while (Q--){
		ll h;
		scanf("%lld",&h);
		matrix C=B;
		for (int i=0;i<b;++i,h>>=1)if (h&1){
			matrix tmp(C);
			mul(binA[i],tmp,C);
		}
		assert(h==0);
		
		printf("%d\n",C.a[m][1]);
	}
	return 0;
}
