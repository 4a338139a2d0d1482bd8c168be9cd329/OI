#include <bits/stdc++.h>
#define N 200005
#define M 400005

using namespace std;
bool _debug;
inline int read(){
	int ret=0;char ch=getchar();
	while (ch<'0'||ch>'9') assert((ch=getchar())!='-');
	while ('0'<=ch&&ch<='9'){
		ret=ret*10-48+ch;
		ch=getchar();
	}
	if (_debug) printf("%d\n",ret);
	return ret;
}

void Max(int &x,int y){if (y>x)x=y;}
void Min(int &x,int y){if (y<x)x=y;}

struct edge{
	int adj,next;
	edge(){}
	edge(int _adj,int _next):adj(_adj),next(_next){}
} e[M];
int n,g[N],m;
void AddEdge(int u,int v){
	e[++m]=edge(v,g[u]);g[u]=m;
	e[++m]=edge(u,g[v]);g[v]=m;
}

int lmtA[N],lmtB[N];
int size[N],fa[N];

int dfn[N],stamp;

bool dfs(int u){
	dfn[++stamp]=u;
	size[u]=1;
	for (int i=g[u];i;i=e[i].next){
		int v=e[i].adj;
		if (v==fa[u]) continue;
		fa[v]=u;
		if (!dfs(v)) return 0;
		size[u]+=size[v];
	}
	if (size[u]<lmtA[u]||n-size[u]<lmtB[u]) return 0;
	return 1;
}

int mn[N],mx[N];

bool judge(int key){
	memset(mn,0,sizeof(mn));
	memset(mx,0,sizeof(mx));
	for (int i=n;i;--i){
		int u=dfn[i];
		++mx[u];
		Max(mn[u],lmtA[u]);
		Min(mx[u],key-lmtB[u]);
		if (mn[u]>mx[u]) return 0;
		mn[fa[u]]+=mn[u];
		mx[fa[u]]+=mx[u];
	}
	return mx[1]==key;
}

int sumN;
bool exist[2][N];

int work(bool debug=0){
	_debug=debug;
	n=read();
	sumN+=n;
	assert(1<=n&&n<=int(1e5));
	memset(g,0,sizeof(g));m=1;
	for (int i=1;i<n;++i) AddEdge(read(),read());
	memset(lmtA,0,sizeof(lmtA));
	memset(lmtB,0,sizeof(lmtB));
	memset(exist,0,sizeof(exist));
	for (int k=0;k<2;++k)
		for (int i=read();i;--i){
			int r=read(),s=read();
			assert(0<=s&&s<=n);
			assert(1<=r&&r<=n);
			assert(!exist[k][r]);
			exist[k][r]=1;
			Max((k==0?lmtA:lmtB)[r],s);
		}
	stamp=0;
	memset(fa,0,sizeof(fa));
	if (!dfs(1)) return -1;
	assert(stamp==n);
	
	int l=-1,r=n,mid;
	while (l+1<r){
		mid=(l+r)>>1;
		if (judge(mid)) r=mid;
		else l=mid;
	}
	return r;
}

int main(){
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	sumN=0;
	for (int T=read();T;T--) printf("%d\n",work());
	assert(sumN<=int(1e6));
	return 0;
}
