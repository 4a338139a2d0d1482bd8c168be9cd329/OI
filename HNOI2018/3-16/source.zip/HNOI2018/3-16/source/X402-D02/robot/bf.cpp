#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

const int N=2010000;

int pos[N];

int n,m;

void solve()
{
	memset(pos,0,sizeof(pos));
	scanf("%d",&n);
	int x,y,z=0,t=0;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x,&y);
		for(int j=t+1;j<=t+y;j++)
		{
			z+=x;
			pos[j]+=z;
		}
		t+=y;
	}

	scanf("%d",&m);
	z=0,t=0;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		for(int j=t+1;j<=t+y;j++)
		{
			z+=x;
			pos[j]-=z;
		}
		t+=y;
	}

	std::sort(pos,pos+t+1);
	int ans=0;
	for(int i=0,j;i<=t;i=j+1)
	{
		for(j=i;j<t && pos[j+1]==pos[j];j++);
		ans=std::max(ans,j-i+1);
	}
	printf("%d\n",ans);
}

int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.ans","w",stdout);

	int T;
	for(scanf("%d",&T);T--;solve());
	return 0;
}
