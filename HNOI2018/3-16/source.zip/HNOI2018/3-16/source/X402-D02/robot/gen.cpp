#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

typedef long long ll;
const int N=233333;

ll A[N],B[N];

void work()
{
	ll L=233333-2333;
	int n=0,m=0;

	ll x=0,lim=233ll;
	while(x<L)A[++n]=rand()%std::min(lim,(L-x))+1,x+=A[n];
	x=0;
	while(x<L)B[++m]=rand()%std::min(lim,(L-x))+1,x+=B[m];

	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		printf("%d %lld\n",rand()%3-1,A[i]);
	printf("%d\n",m);
	for(int i=1;i<=m;i++)
		printf("%d %lld\n",rand()%3-1,B[i]);
}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("robot.in","w",stdout);//look at here

	int T=5;
	for(printf("%d\n",T);T--;work());

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
