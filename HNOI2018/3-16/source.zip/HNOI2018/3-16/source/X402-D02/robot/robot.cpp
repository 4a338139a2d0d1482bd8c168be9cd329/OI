#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define x first
#define y second

template<typename T>inline void read(T &x)
{
	char c=x=0,f=1;
	for(c=getchar();!isdigit(c) && c!='-';c=getchar());
	if(c=='-')c=getchar(),f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	if(f<0)x=-x;
}
template<typename T>inline void check_max(T a,T &b){if(a>b)b=a;}

namespace yyt
{
	typedef long long ll;
	typedef std::pair<ll,ll> pii;

	const int N=101000;

	struct segment_counter
	{
		pii s[N*4];
		int tot;

		void reset(){tot=0;}
		void insert(ll L,ll R,ll x){s[++tot]=pii(L,x),s[++tot]=pii(R+1,-x);}
		ll getans()
		{
			std::sort(s+1,s+tot+1);
			ll ret=0,sum=0;
			for(int i=1;i<=tot;i++)
				check_max(sum+=s[i].y,ret);
			return ret;
		}
	}odd,even;

	pii s[N*2];
	int n,m,tot;

	void process(ll L,ll R,int ty)
	{
#define map(x) ((x)<0?((x)-1)/2:((x)+1)/2)
#define tns(x) ((x)/2)
		if(ty>0 && L>R)std::swap(L,R);
//		printf("%lld --- %lld : type = %d\n",L,R,ty);

		if(ty==0)
		{
			if(L&1)odd.insert(map(L),map(L),R);
			else even.insert(tns(L),tns(L),R);
		}
		else if(ty==1)
		{
			ll l,r;

			l=(L&1)?L:L+1,r=R&1?R:R-1;
			if(l<=r)odd.insert(map(l),map(r),1);

			l=(L&1)?L+1:L,r=R&1?R-1:R;
			if(l<=r)even.insert(tns(l),tns(r),1);
		}
		else
		{
			if(L&1)odd.insert(map(L),map(R),1);
			else even.insert(tns(L),tns(R),1);
		}
	}
	void initialize()
	{
		tot=0;
		odd.reset(),even.reset();

		read(n);
		ll x,y,lst=0,time=0;
		for(int i=1;i<=n;i++)
		{
			read(x),read(y);
			s[++tot]=pii(time+1,x-lst),lst=x;
			time+=y;
		}
		read(m);
		time=0,lst=0;
		for(int i=1;i<=m;i++)
		{
			read(x),read(y);
			s[++tot]=pii(time+1,lst-x),lst=x;
			time+=y;
		}

		ll L=time;

		std::sort(s+1,s+tot+1);
		ll pos=time=0,tp,v=0;

		for(int i=1;i<=tot;i++)
		{
			if(time==s[i].x){v+=s[i].y;continue;}
			tp=pos+(s[i].x-time)*v;

			if(v==0)process(pos,s[i].x-time,0);
			else if(v==1 || v==-1)process(pos+v,tp,1);
			else process(pos+v,tp,2);

			pos=tp,time=s[i].x;
			v+=s[i].y;
		}

		if(time<=L)
		{
			tp=pos+(L-time+1)*v;
			if(v==0)process(pos,L-time+1,0);
			else if(v==1 || v==-1)process(pos+v,tp,1);
			else process(pos+v,tp,2);
		}
	}

	void solve()
	{
		initialize();
		printf("%lld\n",std::max(odd.getans(),even.getans()));
	}
}

int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;yyt::solve());
	return 0;
}
