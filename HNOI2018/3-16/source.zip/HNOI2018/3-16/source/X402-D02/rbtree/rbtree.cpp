#include<iostream>
#include<cstdio>
#include<cstring>
#define x first
#define y second

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
}

inline void check_min(int a,int &b){if(a<b)b=a;}
inline void check_max(int a,int &b){if(a>b)b=a;}

namespace noirnoir
{
	typedef std::pair<int,int> pii;
	const int N=101000;

	pii calc(pii A,pii B)
	{
		if(A.x>B.y || B.x>A.y)return pii(-1,-1);
		return pii(std::max(A.x,B.x),std::min(A.y,B.y));
	}

	int begin[N],next[N*2],to[N*2];

	int n,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}

	pii lim[N];

	pii dfs(int p,int h=0)
	{
		pii ret(0,1),A;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h)
			{
				A=dfs(q,p);
				if(A.x<0)return A;
				ret.x+=A.x,ret.y+=A.y;
			}
		return calc(ret,lim[p]);
	}

	int A[N],B[N];

	bool check(int K)
	{
		for(int i=1;i<=n;i++)
			lim[i]=pii(A[i],K-B[i]);
		pii A=dfs(1);
		return A.x<=K && A.y>=K;
	}

	void initialize()
	{
		read(n),e=0;
		for(int i=1;i<=n;i++)A[i]=B[i]=begin[i]=0;
		for(int i=1,u,v;i<n;i++)read(u),read(v),add(u,v);
		int tmp,x,y;
		for(read(tmp);tmp-->0;)
			read(x),read(y),A[x]=y;
		for(read(tmp);tmp-->0;)
			read(x),read(y),B[x]=y;
	}

	void solve()
	{
		initialize();
		int u=n+1,d=0,mid;
		for(int i=1;i<=n;i++)
			check_max(A[i]+B[i],d);
		while(u>d)
		{
			mid=(u+d)>>1;
			if(check(mid))u=mid;
			else d=mid+1;
		}
		printf("%d\n",d<=n?d:-1);
	}
}

int main()
{
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	int T;
	for(read(T);T--;noirnoir::solve());
	return 0;
}
