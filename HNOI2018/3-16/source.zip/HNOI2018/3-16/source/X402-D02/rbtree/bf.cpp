#include<iostream>
#include<cstdio>
#include<cstring>

namespace bf
{
	const int N=23;

	int begin[N],next[N*2],to[N*2];
	
	int n,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}

	int A[N],B[N];

	void initialize()
	{
		memset(begin,0,sizeof(begin));
		memset(A,0,sizeof(A));
		memset(B,0,sizeof(B));
		e=0;

		scanf("%d",&n);
		for(int i=1,u,v;i<n;i++)
			scanf("%d%d",&u,&v),add(u,v);
		int tmp,x,y;
		for(scanf("%d",&tmp);tmp-->0;)
			scanf("%d%d",&x,&y),A[x]=y;
		for(scanf("%d",&tmp);tmp-->0;)
			scanf("%d%d",&x,&y),B[x]=y;
	}

	bool sel[N];

	int dfs(int p,int h,int K)
	{
		int sum=sel[p],fq;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h)
			{
				fq=dfs(q,p,K);
				if(fq<0)return fq;
				sum+=fq;
			}
		if(sum<A[p])return -1;
		if(K-sum<B[p])return -1;

		return sum;
	}

	int ans;

	void dfs(int p,int cnt)
	{
		if(cnt>=ans)return ;
		if(p>n)
		{
			if(dfs(1,0,cnt)>=0)ans=cnt;
			return;
		}
		sel[p]=1;
		dfs(p+1,cnt+1);
		sel[p]=0;
		dfs(p+1,cnt);
	}

	void solve()
	{
		initialize();
		ans=n+1,dfs(1,0);
		printf("%d\n",ans<=n?ans:-1);
		if(ans<=n)fprintf(stderr,"%d\n",ans);
	}
}

int main()
{
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.ans","w",stdout);
	int T;
	for(scanf("%d",&T);T--;bf::solve());
	return 0;
}
