#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

const int N=233333;

int begin[N],next[N*2],to[N*2];
int siz[N];

int e;

void add(int x,int y,bool k=1)
{
	to[++e]=y;
	next[e]=begin[x];
	begin[x]=e;
	if(k)add(y,x,0);
}
void dfs(int p=1,int h=0)
{
	siz[p]=1;
	for(int i=begin[p],q;i;i=next[i])
		if((q=to[i])!=h)dfs(q,p),siz[p]+=siz[q];
}


int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("rbtree.in","w",stdout);//look at here

	printf("10\n");

	for(int T=10;T--;)
	{

		memset(begin,0,sizeof(begin));e=0;
		int n=rand()%10+10;

		printf("%d\n",n);
		for(int i=2;i<=n;i++)
		{
			int x=rand()%(i-1)+1;
			printf("%d %d\n",x,i);
			add(x,i);
		}
		dfs();

		int lim=23333;
		printf("%d\n",n);
		for(int i=1;i<=n;i++)
			printf("%d %d\n",i,rand()%std::min(lim,siz[i]));

		printf("%d\n",n-1);
		for(int i=2;i<=n;i++)
			printf("%d %d\n",i,rand()%std::min(lim,n-siz[i]));
		printf("\n");

	}

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
