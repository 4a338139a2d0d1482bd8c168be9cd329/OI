#include<iostream>
#include<cstdio>
#include<cstring>

int n,m,ans;

int col[8];

bool check()
{
	int tmp=0;
	tmp+=col[0]==col[1];
	tmp+=col[0]==col[2];
	tmp+=col[1]==col[3];
	tmp+=col[2]==col[3];

	tmp+=col[0]==col[4];
	tmp+=col[1]==col[5];
	tmp+=col[2]==col[6];
	tmp+=col[3]==col[7];

	tmp+=col[4]==col[5];
	tmp+=col[4]==col[6];
	tmp+=col[5]==col[7];
	tmp+=col[6]==col[7];
	return tmp<=m;
}
void dfs(int p=0)
{
	if(p==8)ans+=check();
	else 
	{
		for(int i=1;i<=n;i++)
			col[p]=i,dfs(p+1);
	}
}


bool ck()
{
	int tmp=0;
	tmp+=col[0]==col[1];
	tmp+=col[0]==col[2];
	tmp+=col[1]==col[3];
	tmp+=col[2]==col[3];
	return tmp<=m;
}
void ds(int p=0)
{
	if(p==4)ans+=ck();
	else 
	{
		for(int i=1;i<=n;i++)
			col[p]=i,ds(p+1);
	}
}

int main()
{
	scanf("%d%d",&n,&m);
	ans=0;
	ds();
	printf("%d\n",ans);
	dfs();
	printf("%d\n",ans);
	return 0;
}
