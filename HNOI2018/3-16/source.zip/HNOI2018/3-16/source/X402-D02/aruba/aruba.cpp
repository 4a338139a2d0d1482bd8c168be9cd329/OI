#include<iostream>
#include<cstdio>
#include<cstring>

namespace FeiChangNanXie
{
	typedef long long ll;
	const int MOD=998244353,N=125;
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

	int str[10][10];

	struct node
	{
		int s[4],k;
		int key()
		{
			if(s[0]<0)return 9999;

			int ret=0;
			for(int i=0;i<4;i++)
				ret=ret*4+s[i];
			ret=ret*8+k;
			return ret;
		}
		node(){}
		node(int ty)
		{
			if(ty==-1)s[0]=s[1]=s[2]=s[3]=-1;
			k=0;
		}
	};

	int m,lim;

	node operator + (node &A,node &B)
	{
		static node C;

		C.k=A.k;
		for(int i=0;i<4;i++)
			C.k+=(A.s[i]==B.s[i]),C.s[i]=-1;
		C.k+=B.s[0]==B.s[1];
		C.k+=B.s[0]==B.s[2];
		C.k+=B.s[1]==B.s[3];
		C.k+=B.s[2]==B.s[3];

		int tot=0;
		for(int i=0;i<4;i++)
			if(C.s[i]<0)
			{
				for(int j=i;j<4;j++)
					if(B.s[j]==B.s[i])C.s[j]=tot;
				tot++;
			}

		return C;
	}
	int bit(int k)
	{
		int ret=0;
		for(int i=0;i<4;i++)
			ret+=(k>>i)&1;
		return ret;
	}

	int fk(int a)
	{
		int ret=1;
		for(int i=1;i<=a;i++)
			ret=(ll)ret*i%MOD;
		return ret;
	}
	int calc(node &A,node &B)
	{
		int S=0,ret=1;

//		if(A.s[0]<0)S=(1<<(std::min(4,m)))-1;
//		else
		{
			for(int i=0;i<4;i++)
				if(A.s[i]>=0)S|=1<<A.s[i];
		}
		int tmp=S,cao=bit(S);

		int cnt=0,dnt=0;
		for(int i=0;i<4;i++)
		{
			if(!(S&(1<<B.s[i])))
			{
				ret=(ll)ret*(m-bit(S))%MOD;
				S|=1<<B.s[i];
				cnt++;
			}
			if(!(tmp&(1<<B.s[i])))dnt++;
		}

		int x=str[dnt][cnt]*fk(4-cao)%MOD;
		ret=(ret*inv(x)%MOD+MOD)%MOD;

//		if(ret!=1)
//		{
//			printf("ret = %d\n",ret);
//			printf("%d , %d , %d , %d , %d\n",A.s[0],A.s[1],A.s[2],A.s[3],A.k);
//			printf("%d , %d , %d , %d , %d\n",B.s[0],B.s[1],B.s[2],B.s[3],B.k);
//			printf("------\n");
//		}

		if(bit(S)>m)return 0;
		return ret;
	}

	int len;
	struct matrix
	{
		int s[N][N];
		matrix(int ty=0)
		{
			memset(s,0,sizeof(s));
			if(ty==1)for(int i=1;i<=len;i++)s[i][i]=1;
		}
	};
	struct vector
	{
		int s[N];
	};
	matrix operator * (matrix &A,matrix &B)
	{
		static matrix C;
		for(int i=1;i<=len;i++)
			for(int j=1;j<=len;j++)
			{
				ll x=0;
				for(int k=1;k<=len;k++)
					x+=(ll)A.s[i][k]*B.s[k][j];
				C.s[i][j]=x%MOD;
			}
		return C;
	}
	vector operator * (matrix &A,vector &B)
	{
		static vector C;
		for(int i=1;i<=len;i++)
		{
			ll x=0;
			for(int j=1;j<=len;j++)
				x+=(ll)A.s[i][j]*B.s[j];
			C.s[i]=x%MOD;
		}
		return C;
	}

	matrix g;

	int id[10000];
	node go[300];
	int tot;

	int dfs(node A)
	{
		int h=A.key();
		if(id[h])return id[h];

		int p=id[h]=++len,q;

//		printf("%d , %d , %d , %d , %d : %d\n",A.s[0],A.s[1],A.s[2],A.s[3],A.k,p);

		for(int i=1,x;i<=tot;i++)
		{
			node B=A+go[i];
			x=(calc(A,go[i])+MOD)%MOD;
			if(B.k>lim || !x)continue;

			q=dfs(B);

			{
//				printf("(%d,%d,%d,%d,%d) ---- ",
//						A.s[0],A.s[1],A.s[2],A.s[3],A.k);
//
//				printf("(%d,%d,%d,%d,%d) --> (%d,%d,%d,%d,%d) : %d\n",
//						go[i].s[0],go[i].s[1],go[i].s[2],go[i].s[3],go[i].k,B.s[0],B.s[1],B.s[2],B.s[3],B.k,x);
			}

//			g.s[q][p]=x;
			g.s[q][p]=(g.s[q][p]+x)%MOD;
		}

		return p;
	}

	matrix pow[70];

	void initialize()
	{
		scanf("%d%d",&m,&lim);
		str[0][0]=1;
		for(int i=1;i<=4;i++)
			for(int j=1;j<=4;j++)
				str[i][j]=str[i-1][j-1]+j*str[i-1][j];

		node A;
		tot=0;
		int hh=std::min(4,m);
		for(A.s[0]=0;A.s[0]<hh;A.s[0]++)
			for(A.s[1]=0;A.s[1]<hh;A.s[1]++)
				for(A.s[2]=0;A.s[2]<hh;A.s[2]++)
					for(A.s[3]=0;A.s[3]<hh;A.s[3]++)
						go[++tot]=A;

		A=node(-1);
		dfs(A);

//		for(int i=1;i<=len;i++,printf("\n"))
//			for(int j=1;j<=len;j++)printf("%d ",g.s[i][j]);

		pow[0]=g;
		for(int i=1;i<=65;i++)
			pow[i]=pow[i-1]*pow[i-1];
	}

	void solve()
	{
		initialize();
		int T;
		ll x;
		matrix tmp;
		for(scanf("%d",&T);T--;)
		{
			scanf("%lld",&x);
			ll ans=0;
			tmp=g;
			for(int i=1;i<=x;i++)
			{
				for(int j=1;j<=len;j++)
					ans=(ans+tmp.s[j][1])%MOD;
				tmp=tmp*g;
			}
			printf("%lld\n",ans);
		}
	}
}

int main()
{
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);

//	FeiChangNanXie::solve();
	puts("出题人睿智!!!!!\n");
	return 0;
}
