#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 200010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
int n, m;
int A[N], B[N], V[N], W[N];
int Pa[N][2], Pb[N][2];
inline void file(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
}
int da[N<<1], cnt;
void init(){
	read(n);
	For(i, 1, n)
		read(V[i]), read(A[i]), A[i] += A[i - 1], da[++cnt] = A[i];
	read(m);
	For(i, 1, m)
		read(W[i]), read(B[i]), B[i] += B[i - 1], da[++cnt] = B[i];
	sort(da + 1, da + cnt + 1);
	cnt = unique(da + 1, da + cnt + 1) - da - 1;
	For(i, 1, n)A[i] = lower_bound(da + 1, da + n + 1, A[i]) - da;
	For(i, 1, m)B[i] = lower_bound(da + 1, da + m + 1, B[i]) - da;
	int now = 0;
	For(i, 0, n - 1){
		For(j, A[i], A[i + 1] - 1)
			Pa[j][0] = now + (da[j] - da[A[i]]) * V[i + 1], Pa[j][1] = V[i + 1];
		now += (da[A[i + 1]] - da[A[i]]) * V[i + 1];
	}
	Pa[A[n]][0] = now; 
	now = 0;
	For(i, 0, m - 1){
		For(j, B[i], B[i + 1] - 1)
			Pb[j][0] = now + (da[j] - da[B[i]]) * W[i + 1], Pb[j][1] = W[i + 1];
		now += (da[B[i + 1]] - da[B[i]]) * W[i + 1];
	}
	Pb[B[m]][0] = now;
	For(i, 0, cnt){
		printf("%d\n", da[i]);
		printf("(%d, %d)\n",Pa[i][0],Pa[i][1]);
	}
	puts("");
	For(i, 0, cnt){
		printf("%d\n",da[i]);
		printf("(%d, %d) \n",Pb[i][0],Pb[i][1]);
	}

}
ll Calc(){
	ll ret = 0;
	For(j, 0, cnt - 1){
		if(Pa[j][1] == Pb[j][1] && Pa[j][1] != 0){
			if(Pa[j][0] == Pb[j][0])
				ret += da[j + 1] - da[j];
		}else if(Pa[j][1] == 0 && Pb[j][1] == 0){
				ret ++;
		}else{
			int x = Pa[j][0], y = Pb[j][0], tx = Pa[j][1], ty = Pb[j][1];
			if(tx < ty)swap(tx, ty), swap(x, y);
			if(x <= y){
				if(tx == 0 || ty == 0){
					if(da[y] - da[x] <= da[j + 1] - da[j])ret++;
				}else{
					if(da[y] - da[x] <= 2 * (da[j + 1] - da[j])) ret ++;
				}
			}
		}
	}
	if(Pa[cnt][0] == Pb[cnt][0])ret++;
	return ret;
}
void solve(){
	ll ans = 0;
	ans = Calc();
	printf("%d\n",ans);
	For(i, 0, cnt){
		int delta = Pb[i][0] - Pa[i][0];
		For(j, 0, cnt)Pb[j][0] -= delta;
		printf("aaa%d %d\n",delta,Calc());
		ans = max(Calc(), ans);
		For(j, 0, cnt)Pb[j][0] += delta;
	}
	printf("%lld\n", ans);
}
int main(){
	file();
	int T = 0;
	read(T);
	while(T--)init(), solve();
	return 0;
}
