#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f, Mod = 998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
}
int C, K, q;
ll h[N];
void init(){
	read(C), read(K);
	read(q);
}
void solve(){
	For(i, 1, q){
		read(h[i]);
		printf("%lld\n", 2ll * h[i] % Mod);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
