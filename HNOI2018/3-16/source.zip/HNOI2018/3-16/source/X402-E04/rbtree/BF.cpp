#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i, u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N =30, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar(); 
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("rbtree.in","r",stdin);
	freopen("BF.out","w",stdout);
}
int n, Begin[N], Next[N<<1], to[N<<1], e, a, b;
typedef pair<int, int> pii;
vector<pii>Q[N];
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
void init(){
	read(n);
	e = 0;
	memset(Begin, 0, sizeof(Begin));
	For(i, 1, n - 1){
		int u, v;
		read(u), read(v);
		add(u, v), add(v, u);
	}
	For(i, 1, n)Q[i].clear();
	read(a);
	For(i, 1, a){
		int x, s;
		read(x), read(s);
		Q[x].push_back(pii(s, 0));
	}
	read(b);
	For(i, 1, b){
		int x, s;
		read(x), read(s);
		Q[x].push_back(pii(s, 1));
	}
}
int ok = 0;
int p[N];
int sz[N];
#define fi first
#define se second
bool dfs(int u, int f, int tot){
	sz[u] = p[u];
	Rep(i, u)
		if(v^f){
			if(!dfs(v, u, tot))return 0;
			sz[u] += sz[v];
		}
	int S = Q[u].size();
	For(i, 0, S - 1)
		if(Q[u][i].se == 0){
			if(sz[u] < Q[u][i].fi)return 0;
		}else {
			if(tot - sz[u] < Q[u][i].fi)return 0;
		}
	return 1;
}
int ans = INF;
void Dfs(int now, int cnt){
	if(now > n){
		if(dfs(1, 0, cnt)){
			ok = 1;
			ans = min(ans, cnt);
		}
		return ;
	}
	p[now] = 1;
	Dfs(now + 1, cnt + 1);
	p[now] = 0;
	Dfs(now + 1, cnt);
}
void solve(){
	ok = 0;ans = INF;
	For(i, 1, n)p[i] = 0;
	Dfs(1, 0);
	if(!ok)puts("-1");
	else printf("%d\n", ans);
}
int main(){
	file();
	int T;
	read(T);
	while(T--)init(), solve();
	return 0;
}
