#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 100010;
int vis[N];
int main(){
	freopen("rbtree.in","w",stdout);
	srand(time(0));
	int T = 20;
	printf("%d\n" ,T);
	while(T--){
		int n = rand()%20 +1;//rand()% 100000 + 1;
		printf("%d\n", n);
		For(i, 2, n){
			printf("%d %d\n", i, rand() % (i - 1) + 1);
		}
		int a = rand() % (n + 1), b = rand()%(n + 1 - a);
		printf("%d\n" ,a);
		For(i, 1, n)vis[i] = 0;
		For(i, 1, a){
			int r = rand()% n + 1, s = rand() % 1 + 1;
			while(vis[r])r = rand() % n + 1;
			vis[r] = 1;
			printf("%d %d\n", r, s);
		}
		printf("%d\n",b);
		For(i, 1, b){
			int r = rand()% n + 1, s = rand() % (1) + 1;
			while(vis[r])r = rand() % n + 1;
			vis[r] = 1;
			printf("%d %d\n", r, s);
		}
	}
	return 0;
}

