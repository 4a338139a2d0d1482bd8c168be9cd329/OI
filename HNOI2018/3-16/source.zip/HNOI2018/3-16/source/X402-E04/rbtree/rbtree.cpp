#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i, u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N = 100010, INF = 0x3f3f3f3f, M = 500100;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar(); 
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
}
int n, Begin[N], Next[M], to[M], e, a, b, In[N], dfs_cnt, Out[N], sz[N];
typedef pair<int, int> pii;
vector<pii>Q[N];
vector<pii>G[N];
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
int lmax = 0, OK;
void init(){
	read(n);
	e = 0;lmax = 0;OK =0;
	memset(Begin, 0, sizeof(Begin));
	For(i, 1, n - 1){
		int u, v;
		read(u), read(v);
		add(u, v), add(v, u);
	}
	For(i, 1, n)Q[i].clear();
	read(a);
	For(i, 1, a){
		int x, s;
		read(x), read(s);
		lmax = max(lmax, s);
		Q[x].push_back(pii(s, 0));
	}
	read(b);
	For(i, 1, b){
		int x, s;
		read(x), read(s);
		lmax = max(lmax, s);
		Q[x].push_back(pii(s, 1));
	}
}
int p[N];
#define fi first
#define se second
#define pb push_back
void dfs(int u, int f, int tot){
	In[u] = ++dfs_cnt;sz[u] = 1;
	Rep(i, u)
		if(v^f)
			dfs(v, u, tot), sz[u] += sz[v];
	Out[u] = dfs_cnt;
	if(!OK)return ;
	int S = Q[u].size();
	int x = In[u] - 1, y = Out[u];
	For(i, 0, S - 1)
		if(Q[u][i].se == 0)
			G[x].pb(pii(y, Q[u][i].fi));
		else {
			G[y].pb(pii(x, Q[u][i].fi - tot));
			if(n - sz[u] < Q[u][i].fi){OK = 0;return;}
		}
}
void Build(){
	For(i, 0, n - 1)G[i].pb(pii(i + 1, 0));
	For(i, 1, n)G[i].pb(pii(i - 1, -1));
}
int vis[N], flag;
ll dis[N];
bool spfa(int u){
	vis[u] = 1;
	for(auto r : G[u]){
		int v = r.fi;
		if(dis[v] > dis[u] - r.se){
			if(vis[v] || flag){flag = 1;break;}
			dis[v] = dis[u] - r.se;
			spfa(v);
		}
	}
	vis[u] = 0;
	return 0;
}
bool Check(){
	For(i, 0, n)dis[i] = vis[i] = 0;
	flag = 0;
	For(i, 0, n){spfa(i);if(flag)break;}
	return flag;
}

bool check(int x){
	For(i, 0, n)G[i].clear();
	dfs_cnt = 0;
	OK = 1;
	dfs(1, 0, x);
	if(!OK)return 0;
	G[n].pb(pii(0, -x));
	G[0].pb(pii(n, x));
	Build();
	if(Check())return 0;
	return 1;
}
void solve(){
	int L = lmax, R = n + 1, ans = -1;
	while(L < R){
		int mid = (L + R) >> 1;
		if(check(mid))ans = mid, R = mid;
		else L = mid + 1;
	}
	printf("%d\n", ans);
}
int main(){
	file();
	int T;
	read(T);
	while(T--)init(), solve();
	return 0;
}
