#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=200010;
int to[N<<1],Begin[N],Next[N<<1],e,w[N*2];
int dis[N],n,m;
bool vis[N],flag;
inline void add(int x,int y,int z){to[++e]=y;Next[e]=Begin[x];Begin[x]=e;w[e]=z;}
inline bool spfa(int u){
    vis[u]=1;
    for (int i=Begin[u];i;i=Next[i]){
        int v=to[i];
        if (dis[v]>dis[u]+w[i]){
            if (vis[v]||flag){flag=1;break;}
            dis[v]=dis[u]+w[i];spfa(v);
        }
    }
    vis[u]=0;
    return 0;
}
int main(){
    int T;
    scanf("%d",&T);
    while(T--){ 
        e=0;memset(dis,0,sizeof(dis));
        memset(Begin,0,sizeof(Begin));
        memset(vis,0,sizeof(vis));
        scanf("%d%d",&n,&m);
        for (int i=1,u,v,w;i<=m;i++){
            scanf("%d%d%d",&u,&v,&w);
            add(u,v,w);if (w>=0)add(v,u,w);
        }flag=0;
        for (int i=1;i<=n;i++){spfa(i);if(flag)break;}
        if (flag==1)puts("YE5");
        else puts("N0");
    }
    return 0;
}
