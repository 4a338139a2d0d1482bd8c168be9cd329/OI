#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
template <typename T>T read(){
	T x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
typedef long long ll;
const int N=100005;
struct node{
	int x; ll y;
}a[N],b[N];
int f[N<<1];
int main(){
	freopen("robot.in","r",stdin); freopen("robot.out","w",stdout);
	int _=read<int>(),n,m,cnt,s,ans; ll l;
	while(_--){ 
		n=read<int>(); l=0;
		For(i,1,n) a[i]=(node){read<int>(),read<ll>()},l+=a[i].y;
		m=read<int>();
		For(i,1,m) b[i]=(node){read<int>(),read<ll>()};
		if (l<=200000){
			++l; memset(f,0,(l+1)<<2); cnt=0;
			For(i,1,n)
				For(j,1,a[i].y) ++cnt,f[cnt]=f[cnt-1]+a[i].x;
			cnt=s=0;
			For(i,1,m)
				For(j,1,b[i].y) ++cnt,s+=b[i].x,f[cnt]-=s;
			sort(f+1,f+l+1); s=ans=1; cnt=f[1];
			For(i,2,l){
				if (cnt==f[i]) ++s,ans=max(s,ans);
				else s=1,cnt=f[i];
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
