#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
typedef long long ll;
template<typename T>T read(){
	T x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=998244353;
ll h[205]; int dp[203][257][9],an[205],k[5],a[257][5],s[257],ss[257][257];
int main(){
	freopen("aruba.in","r",stdin); freopen("aruba.out","w",stdout);
	int c=read<int>(),m=read<int>(),q=read<int>(),x; ll ma=0,y;
	For(i,1,q) h[i]=read<ll>(),ma=max(ma,h[i]);
	if (c==2){
		if (m<=1) For(i,1,q) printf("%lld\n",h[i]*2%mo);
		else if (m==2) For(i,1,q) printf("%lld\n",(h[i]*2+12)%mo);
		else if (m==3) For(i,1,q) printf("%lld\n",((h[i]%mo*18%mo)-4+mo)%mo);
		else if (m==4) For(i,1,q){
			if (h[i]==1) printf("16\n"); else if (h[i]==2) printf("64\n");
			else y=23+5*(h[i]%mo-3)+23,printf("%lld\n",((h[i]-2)%mo*y%mo+64)%mo);
		}
		else if (m==5) For(i,1,q){
			if (h[i]==1) printf("16\n"); else if (h[i]==2) printf("112\n");
			else y=39+5*(h[i]%mo-3)+39,printf("%lld\n",((h[i]-2)%mo*y%mo+112)%mo);
		}
		else if (m==6) For(i,1,q){
			if (h[i]==1) printf("16\n"); else if (h[i]==2) printf("176\n"); else if (h[i]==3) printf("386\n");
			else y=124+25*(h[i]%mo-4)+124,printf("%lld\n",((h[i]-3)%mo*y%mo+386)%mo);
		}
		else if (m==7) For(i,1,q){
			if (h[i]==1) printf("16\n"); else if (h[i]==2) printf("224\n"); else if (h[i]==3) printf("754\n");
			else y=300+65*(h[i]%mo-4)+300,printf("%lld\n",((h[i]-3)%mo*y%mo+754)%mo);
		}
		exit(0);
	}
	if (c==1){
		if (m>=4) For(i,1,q) printf("1\n");
		else For(i,1,q) printf("0\n");
		exit(0);
	}
	if (ma<=200&&c<=4){
		k[0]=1; For(i,1,4) k[i]=k[i-1]*c; --k[4];
		For(i,0,k[4]){
			x=i;
			For(j,0,3) a[i][j]=x/k[3-j],x-=a[i][j]*k[3-j];
			if (a[i][0]==a[i][1]) ++s[i]; if (a[i][0]==a[i][2]) ++s[i];
			if (a[i][1]==a[i][3]) ++s[i]; if (a[i][2]==a[i][3]) ++s[i];
			if (s[i]<=m) dp[1][i][s[i]]=1,++an[1];
		}
		For(i,0,k[4])
			For(j,i,k[4]){
				For(ii,0,3) if (a[i][ii]==a[j][ii]) ++ss[i][j];
				ss[j][i]=ss[i][j];
			}
		For(i,2,ma){
			an[i]=an[i-1];
			For(j,0,k[4]){
				if (s[j]>m) continue;
				For(ii,0,k[4]){
					x=s[j]+ss[j][ii];
					For(jj,0,m-x){
						int &e=dp[i][j][jj+x]; e+=dp[i-1][ii][jj];
						if (e>=mo) e-=mo;
					}
				}
				For(ii,0,m){
					an[i]+=dp[i][j][ii];
					if (an[i]>=mo) an[i]-=mo;
				}
			}
		}
		For(i,1,q) printf("%d\n",an[h[i]]);
	}
	return 0;
}
