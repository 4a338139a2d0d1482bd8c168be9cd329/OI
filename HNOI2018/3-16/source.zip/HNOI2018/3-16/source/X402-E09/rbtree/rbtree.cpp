#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=100005;
int q[19],l,head[N],to[N<<1],nex[N],e,a[19][19],b[37],c[37],d[37];
void add(int x,int y){
	to[++e]=y; nex[e]=head[x]; head[x]=e;
}
void dfs(int x,int fa){
	q[++l]=x; For(i,1,l) a[q[i]][x]=1;
	for(int i=head[x];i;i=nex[i])
		if (to[i]!=fa) dfs(to[i],x);
	--l;
}
int main(){
	freopen("rbtree,in","r",stdin); freopen("rbtree.out","w",stdout);
	int _=read(),n,x,y,m,ans,lg[19],s,ss,fl;
	while(_--){
		 n=read(); memset(head,0,(n+1)<<2); e=0;
		 For(i,1,n-1) x=read(),y=read(),add(x,y),add(y,x);
		 if (n<=17){
			dfs(1,0),m=read(),ans=20,memset(a,0,sizeof(a)); memset(d,0,sizeof(d));
			For(i,1,m){
				b[i]=read(),c[i]=read();
				For(j,1,n) if (a[b[i]][j]) d[i]|=(1<<(j-1));
			}
			x=read(); lg[1]=1; For(i,2,n) lg[i]=lg[i-1]<<1;
			For(i,m+1,m+x){
				b[i]=read(),c[i]=read();
				For(j,1,n) if (!a[b[i]][j]) d[i]|=lg[j];
			}
			m+=x; x=(1<<n)-1;
			For(i,0,x){
				fl=0;
				For(j,1,m){
					ss=0;
					For(k,1,n) if ((d[i]&lg[k])&&(i&lg[k])) ++ss;
					if (ss<c[j]) {fl=1; break;}
				}
				if (!fl) {s=0; For(k,1,n) if (i&lg[k]) ++s; ans=min(ans,s);}
			}
			if (ans==20) printf("-1\n"); else printf("%d\n",ans);
		 }
	}
	return 0;
}
