#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline ll read()
{
	char s;
	ll k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
ll c,k,T,h;
int main()
{
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	c=read();k=read();
	T=read();
	while (T--)
	{
		h=read();
		if (c==2&&k==0)
		{
			h=h*2;
			printf("%lld\n",h);
		}
	}
	return 0;
}
