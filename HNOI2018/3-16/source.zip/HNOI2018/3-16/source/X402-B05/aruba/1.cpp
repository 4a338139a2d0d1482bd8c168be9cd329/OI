#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
int a[5],ans;
int main()
{
#ifdef ylx
	freopen("1.in","r",stdin);
	freopen("1.out","w",stdout);
#endif
	for (a[1]=1;a[1]<=3;a[1]++)
	for (a[2]=1;a[2]<=3;a[2]++)
	for (a[3]=1;a[3]<=3;a[3]++)
	for (a[4]=1;a[4]<=3;a[4]++)
	{
		if (a[1]!=a[2]&&a[1]!=a[3]&&a[2]!=a[4]&&a[3]!=a[4])
		
		{
			cout<<a[1]<<" "<<a[2]<<" "<<a[3]<<" "<<a[4]<<endl;
			ans++;
		}
	}
	cout<<ans;
	return 0;
}
