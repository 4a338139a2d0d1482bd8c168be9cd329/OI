#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(ll &x,ll y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline ll read()
{
    char s;
    ll k=0,base=1;
    while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
    if(s==EOF)exit(0);
    if(s=='-')base=-1,s=getchar();
    while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
    return k*base;
}
inline void write(int x)
{
    static char cnt,num[15];cnt=0;
    if (!x)
    {
        putchar('0');
        return;
    }
    for (;x;x/=10) num[++cnt]=x%10;
    for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e5+100;
const int maxm=2e5+100;
int T;
int n;
ll V[maxn],A[maxn];
int m;
ll W[maxn],B[maxn];
ll sum,L,ans;
ll x[maxm],y[maxm];
int Map[maxm*2+100];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	T=read();
	while (T--)
	{
		ans=1;L=0;sum=0;n=0;
		memset(x,0,sizeof(x));
		memset(y,0,sizeof(y));
		n=read();
		for (int i=1;i<=n;i++)
		{
			V[i]=read();A[i]=read();
			L+=A[i];
		}
		m=read();
		for (int i=1;i<=m;i++)
		{
			W[i]=read();B[i]=read();
		}
		if (L<=(ll)(2e5))
		{
			int p=0,t=0;
			x[0]=0;
			for (int i=1;i<=n;i++)
			{
				for (int j=1;j<=A[i];j++)
				{
					p+=V[i];
					x[++t]=p;
				}
			}
			y[0]=0;
			p=0;t=0;
			for (int i=1;i<=m;i++)
			{
				for (int j=1;j<=B[i];j++)
				{
					p+=W[i];
					y[++t]=p;
				}
			}
//			for (int i=1;i<=t;i++) printf("%d ",x[i]);printf("\n");
//			for (int i=1;i<=t;i++) printf("%d ",y[i]);printf("\n");
			memset(Map,0,sizeof(Map));
			Map[maxm]++;
			for (int i=1;i<=t;i++)
			{
				Map[x[i]-y[i]+maxm]++;
			}
			for (int i=1;i<=t;i++)
			{
				qmax(ans,Map[x[i]-y[i]+maxm]);
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
