#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
    char s;
    int k=0,base=1;
    while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
    if(s==EOF)exit(0);
    if(s=='-')base=-1,s=getchar();
    while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
    return k*base;
}
inline void write(int x)
{
    static char cnt,num[15];cnt=0;
    if (!x)
    {
        putchar('0');
        return;
    }
    for (;x;x/=10) num[++cnt]=x%10;
    for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e5+1000;
const int maxm=4e5+100;
int id1,T,X,Y,A,B,id2;
int n;
int po[maxn],ne[maxm],to[maxm],w[maxm];
int dfs_time,id[maxn],sz[maxn];
int fr[maxm];
struct node
{
	int x,y,z;
} a[maxn],b[maxn];
void add1(int x,int y)
{
	id1++;
	to[id1]=y;ne[id1]=po[x];po[x]=id1;
}
void add(int x,int y,int z)
{
	id1++;
	to[id1]=y;w[id1]=z;
	ne[id1]=po[x];po[x]=id1;
	fr[id1]=x;
}
void dfs(int x)
{
	id[x]=++dfs_time;
	sz[x]=1;
	for (int i=po[x];i;i=ne[i])
	{
		if (!id[to[i]])
		{
			dfs(to[i]);
			sz[x]+=sz[to[i]];
		}
	}
}
bool flag;
int vis[maxn],v1[maxn],dis[maxn];
void spfa(int x)
{
//	printf("%d ",x);
	vis[x]=1;
	for (int i=po[x];i;i=ne[i])
	{
		if (dis[to[i]]>dis[x]+w[i])
		{
			dis[to[i]]=dis[x]+w[i];
			if (vis[to[i]])
			{
				flag=true;return;
			}
			spfa(to[i]);
			if (flag) return;
		}
	}
	vis[x]=0;
}
bool check(int x)
{
	id1=0;
	memset(vis,0,sizeof(vis));
//	memset(v1,0,sizeof(v1));
	memset(po,0,sizeof(po));
	for (int i=1;i<=A;i++) add(a[i].x,a[i].y,a[i].z);
	for (int i=1;i<=B;i++) add(b[i].x,b[i].y,x-b[i].z);
	for (int i=1;i<=n;i++) add(i-1,i,1);
	flag=false;
//	printf("%d\n",x);
//	for (int i=1;i<=id1;i++)
//	{
//		printf("%d %d %d\n",fr[i],to[i],w[i]);
//	}
	memset(dis,0x3f3f3f3f,sizeof(dis));
	dis[0]=0;
//	cout<<dis[0]<<" "<<dis[1]<<" "<<po[0];
	spfa(0);
//	printf("--------\n");
	if (flag) return false;
	return true;
}
int main()
{
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	T=read();
	while (T--)
	{
		id1=0;dfs_time=0;
		memset(po,0,sizeof(po));
		memset(id,0,sizeof(id));
		n=read();
		for (int i=1;i<n;i++)
		{ 
			X=read();Y=read();
			add1(X,Y);add1(Y,X);
		}
		dfs(1);
//		for (int i=1;i<=n;i++)cerr<<sz[i]<<" ";cerr<<endl;
		id1=0;
		memset(po,0,sizeof(po));
		A=read();
		for (int i=1;i<=A;i++)
		{
			X=read();Y=read();
			a[i].x=id[X]+sz[X]-1;
			a[i].y=id[X]-1;
			a[i].z=-Y;
//			add(a[i].x,a[i].y,a[i].z);
		}//x->y z
		B=read();
		for (int i=1;i<=B;i++)
		{
			X=read();Y=read();
			b[i].x=id[X]-1;
			b[i].y=id[X]+sz[X]-1;
			b[i].z=Y;
		}//x->y z-ans
		int l=1,r=n,ans=n+5,mid=0;
		id2=id1;
		while (l<=r)
		{
			mid=(l+r)/2;
			if (check(mid))
			{
				qmin(ans,mid);
				r=mid-1;
			} else
			{
				l=mid+1;
			}
		}
		if (ans==n+5) ans=-1;
		printf("%d\n",ans);
	}
	return 0;
}
