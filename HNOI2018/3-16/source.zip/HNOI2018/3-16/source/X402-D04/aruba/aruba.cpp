#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1010;
const int mod=998244353;
int c, k, q;

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

int main(){
	freopen("aruba.in","r",stdin),freopen("aruba.out","w",stdout);

	scanf("%d%d", &c, &k);
	scanf("%d", &q);
	ll x;
	while(q--){
		scanf("%lld", &x);
		if(k==0 && c==2) printf("%lld\n", 2*x%mod);
		else if(c==1){
			if(k<4) puts("0");
			else puts("1");
		}
	}
	return 0;
}
