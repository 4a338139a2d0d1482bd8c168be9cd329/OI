#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
inline ll readl()
{
    char ch=getchar();int g=1;ll re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef pair<int,int> pii;
typedef pair<ll,int> pli;

const int N=100050;
int add[N*150][2],ch[N*150][2],sz,rt;
ll maxv[N*150][2],L;
inline void update(int &o,ll l,ll r,ll x,ll y,int k)
{
	if(!o) {o=++sz;add[o][0]=add[o][1]=ch[o][0]=ch[o][1]=0; maxv[o][0]=maxv[o][1]=0;}
	if(x<=l&&r<=y)
	{
		if(l<r) maxv[o][k]++,add[o][k]++;
		else if(k==(l&1)) maxv[o][k]++,add[o][k]++;
		return ;
	}
	ll mid=l+r>>1;
	if(x<=mid) update(ch[o][0],l,mid,x,y,k);
	if(y>mid) update(ch[o][1],mid+1,r,x,y,k);
	maxv[o][0]=max(maxv[ch[o][0]][0],maxv[ch[o][1]][0])+add[o][0];
	maxv[o][1]=max(maxv[ch[o][0]][1],maxv[ch[o][1]][1])+add[o][1];
}
inline void modify(int &o,ll l,ll r,ll x,ll k)
{
	if(!o) {o=++sz;add[o][0]=add[o][1]=ch[o][0]=ch[o][1]=0; maxv[o][0]=maxv[o][1]=0;}
	if(l==r) {maxv[o][l&1]+=k; return ;}
	ll mid=l+r>>1;
	if(x<=mid) modify(ch[o][0],l,mid,x,k);
	else modify(ch[o][1],mid+1,r,x,k);
	maxv[o][0]=max(maxv[ch[o][0]][0],maxv[ch[o][1]][0])+add[o][0];
	maxv[o][1]=max(maxv[ch[o][0]][1],maxv[ch[o][1]][1])+add[o][1];
}

int n,m;
pli A[N],B[N];

void wj()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
}
int main()
{
	wj();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		sz=0; rt=0;
		n=read();
		for(int i=1;i<=n;++i) 
		{
			A[i].se=read(),A[i].fi=readl();
			L+=A[i].fi; A[i].fi+=A[i-1].fi;
		}
		m=read();
		for(int i=1;i<=m;++i) B[i].se=read(),B[i].fi=readl()+B[i-1].fi;
		int p1=1,p2=1; ll now=0,sum=0;
		for(;p1<=n&&p2<=m;)
		{
			int d=A[p1].se-B[p2].se;
			//(ago,sum, A[p1].se-B[p2].se)
			if(A[p1].fi<B[p2].fi) 
			{
				ll ago=sum+A[p1].se-B[p2].se;
				sum+=(A[p1].se-B[p2].se)*(A[p1].fi-now);
				//if(ago==sum) cerr<<ago-A[p1].se+B[p2].se<<' '<<ago<<' '<<sum<<endl;

				if(d==2) update(rt,-L,L,ago,sum,ago&1);
				else if(d==1) update(rt,-L,L,ago,sum,0),update(rt,-L,L,ago,sum,1);
				else if(!d) modify(rt,-L,L,ago,A[p1].fi-now);
				else if(d==-1) update(rt,-L,L,sum,ago,0),update(rt,-L,L,sum,ago,1);
				else update(rt,-L,L,sum,ago,ago&1);
				now=A[p1].fi;
				p1++;
			}
			else if(B[p2].fi<A[p1].fi)
			{
				ll ago=sum+A[p1].se-B[p2].se;
				sum+=(A[p1].se-B[p2].se)*(B[p2].fi-now);

				if(d==2) update(rt,-L,L,ago,sum,ago&1);
				else if(d==1) update(rt,-L,L,ago,sum,0),update(rt,-L,L,ago,sum,1);
				else if(!d) modify(rt,-L,L,ago,B[p2].fi-now);
				else if(d==-1) update(rt,-L,L,sum,ago,0),update(rt,-L,L,sum,ago,1);
				else update(rt,-L,L,sum,ago,ago&1);
				now=B[p2].fi;
				p2++;
			}
			else
			{
				ll ago=sum+A[p1].se-B[p2].se;
				sum+=(A[p1].se-B[p2].se)*(B[p2].fi-now);

				if(d==2) update(rt,-L,L,ago,sum,ago&1);
				else if(d==1) update(rt,-L,L,ago,sum,0),update(rt,-L,L,ago,sum,1);
				else if(!d) modify(rt,-L,L,ago,B[p2].fi-now);
				else if(d==-1) update(rt,-L,L,sum,ago,0),update(rt,-L,L,sum,ago,1);
				else update(rt,-L,L,sum,ago,ago&1);
				now=B[p2].fi;
				p2++; p1++;
			}
		}
		modify(rt,-L,L,0,1);
		printf("%lld\n",max(maxv[1][0],maxv[1][1]));
		//cerr<<sz<<endl;
	}
	return 0;
}
