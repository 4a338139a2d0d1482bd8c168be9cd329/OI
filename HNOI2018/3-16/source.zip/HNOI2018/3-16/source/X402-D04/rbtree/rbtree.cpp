#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
int n, qa, qb;
vector<int> g[maxn];
int a[maxn], b[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(int& x,int y){ if(x>y) x=y; }
void chkmax(int& x,int y){ if(x<y) x=y; }

int ans, tot;
int use[maxn], size[maxn];
int Min[maxn], res[maxn], Max[maxn];
int flag;
void dfs(int x,int fa=0){
	res[x]=1;
	int now=0;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa) continue;
		dfs(v, x); res[x]+=res[v]; Min[x]+=Min[v]; now+=Min[v];
	}
	chkmax(Min[x], a[x]); 
	if(Max[x]<Min[x]) flag=0;
	int d=a[x]-now;
	if(d>0){
		res[x]-=d; if(res[x]<0){
			// printf("x = %d\n", x);
			flag=0;
		}
	}
	chkmin(res[x], Max[x]-Min[x]);
}
bool check(int x){
	tot=x;
	for(int i=1;i<=n;i++) res[i]=Min[i]=Max[i]=0;
	for(int i=1;i<=n;i++) Max[i]=tot-b[i];
	flag=1;
	dfs(1);
	// puts("*");
	if(!flag) return false;
	return tot<=Min[1]+res[1];
}
void solve(){
	int l=0, r=n, ret=n+1;
	while(l<=r){
		int mid=(l+r)>>1;
		// printf("%d %d %d %d\n", l, r, mid, check(mid));
		if(check(mid)) ret=mid, r=mid-1;
		else l=mid+1;
	}
	// printf("ret = %d\n", ret);
	printf("%d\n", ret==n+1 ? -1 : ret);
}

int main(){
	freopen("rbtree.in","r",stdin),freopen("rbtree.out","w",stdout);

	int T;
	read(T);
	int u, v;
	while(T--){
		read(n);
		for(int i=1;i<=n;i++) g[i].clear();
		for(int i=1;i<n;i++){
			read(u), read(v); g[u].push_back(v), g[v].push_back(u);
		}
		for(int i=1;i<=n;i++) a[i]=b[i]=0;
		read(qa);
		for(int i=1;i<=qa;i++){
			read(u), read(v);
			a[u]=v;
		}
		read(qb);
		for(int i=1;i<=qb;i++){
			read(u), read(v);
			b[u]=v;
		}
		solve();
	}
	return 0;
}
