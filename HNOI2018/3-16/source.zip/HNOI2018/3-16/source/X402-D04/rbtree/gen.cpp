#include<bits/stdc++.h>
using namespace std;

const int maxn=20;
int n, a, b;
int size[maxn];
vector<int> g[maxn];

void dfs(int x){
	size[x]=1;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i];
		dfs(v); size[x]+=size[v];
	}
}

int main(){
	freopen("rbtree.in","w",stdout);

	srand(time(0));
	int T=5;
	printf("%d\n", T);
	while(T--){
		printf("%d\n", n=15);
		for(int i=1;i<=n;i++) g[i].clear();
		for(int i=2;i<=n;i++){
			int f=rand()%(i-1)+1;
			printf("%d %d\n", f, i);
			g[f].push_back(i);
		}
		dfs(1);
		printf("%d\n", a=3);
		for(int i=1;i<=a;i++){
			int x=rand()%n+1;
			printf("%d %d\n", x, rand()%size[x]);
		}
		printf("%d\n", b=3);
		for(int i=1;i<=b;i++){
			int x=rand()%n+1;
			printf("%d %d\n", x, rand()%(n-size[x]+1));
		}
	}
	return 0;
}
