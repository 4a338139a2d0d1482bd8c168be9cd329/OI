#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
int n, qa, qb;
vector<int> g[maxn];
int a[maxn], b[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmin(int& x,int y){ if(x>y) x=y; }

int ans, tot;
int use[maxn], size[maxn];
void dfs(int x,int fa=0){
	size[x]=use[x];
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa) continue;
		dfs(v, x); size[x]+=size[v];
	}
}
bool check(){
	dfs(1);
	for(int i=1;i<=n;i++){
		if(size[i]<a[i] || tot-size[i]<b[i]) return false;
	}
	return true;
}
void solve(){
	ans=n+1;
	for(int i=0;i<(1<<n);i++){
		tot=0;
		for(int j=1;j<=n;j++) if(i & (1<<(j-1))) use[j]=1, tot++; else use[j]=0;
		if(check()) chkmin(ans, tot);
	}
	printf("%d\n", ans==n+1 ? -1 : ans);
}

int main(){
	freopen("rbtree.in","r",stdin),freopen("rbtree.ans","w",stdout);

	int T;
	read(T);
	int u, v;
	while(T--){
		read(n);
		for(int i=1;i<=n;i++) g[i].clear();
		for(int i=1;i<n;i++){
			read(u), read(v); g[u].push_back(v), g[v].push_back(u);
		}
		for(int i=1;i<=n;i++) a[i]=b[i]=-1;
		read(qa);
		for(int i=1;i<=qa;i++){
			read(u), read(v);
			a[u]=v;
		}
		read(qb);
		for(int i=1;i<=qb;i++){
			read(u), read(v);
			b[u]=v;
		}
		solve();
	}
	return 0;
}
