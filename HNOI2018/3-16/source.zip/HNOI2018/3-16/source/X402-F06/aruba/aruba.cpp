#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxk=300+10,mod=998244353;
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
/*
struct Matrix{
	int a[maxk][maxk],n;
	void clear(){
		REP(i,1,n) a[i][i]=0;
	}
	Matrix operator *(const Matrix &rhs) const{
		Matrix A;
		A.clear();
		REP(i,1,n)
			REP(j,1,n)
				REP(k,1,n)
					add(A.a[i][j],1ll*a[i][k]*rhs.a[k][j]%mod);
		return A;
	}
};
int id[5][5][5][5],cnt;
int knum[maxk][4][5];
int Begin[maxk],Next[maxk*maxk],to[maxk*maxk],w[maxk*maxk],e;
int find_num(int A,int B,int C,int D){
	return (A==B)+(B==C)+(C==D)+(A==D);
}
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return res;
}
void add_edge(int x,int y,int z){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
}
void init(int c,int n){
	REP(i,1,c)
		REP(j,1,c)
			REP(k,1,c)
				REP(l,1,c){
					int num=find_num(i,j,k,l);
					if(num>n) continue;
					id[i][j][k][l]=++cnt;
					knum[cnt][0]=i,knum[cnt][1]=j,knum[cnt][2]=k,knum[cnt][3]=l;
					knum[cnt][4]=num;
				}
	REP(i,1,cnt) REP(j,1,cnt){
		int num=0;
		REP(u,0,3) num+=(knum[i][u]==knum[j][u]);
		if(num+knum[i][4]+knum[j][4]>n) continue;
		add_edge(i,j,num);
	}
}
*/
int main(){
#ifndef ONLINE_JUDGE
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
#endif
	int c=read(),n=read();
	int q=read();
//	int inv_4=ksm(4,mod-2);
//	init(c,n);
	while(q--){
		ll h=readll();
		if(c==1) printf("1\n");
		else if(c==2 && n==0) printf("%lld\n",2*h);
		else{
		}
	}
	return 0;
}
