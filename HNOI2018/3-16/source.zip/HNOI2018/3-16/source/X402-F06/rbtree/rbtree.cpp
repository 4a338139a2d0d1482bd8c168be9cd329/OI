#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10;
int Begin[maxn],Next[maxn<<1],to[maxn<<1],e;
int a[maxn],b[maxn],f[maxn],sz[maxn],n;
void add_edge(int x,int y){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
}
void dfs_init(int x,int ff){
	sz[x]=1;
	for(int i=Begin[x];i;i=Next[i]){
		if(to[i]==ff) continue;
		dfs_init(to[i],x);
		sz[x]+=sz[to[i]];
	}
}
bool dfs(int x,int ff){
	f[x]=0;
	for(int i=Begin[x];i;i=Next[i]){
		if(to[i]==ff) continue;
		if(!dfs(to[i],x)) return 0;
		f[x]+=f[to[i]];
	}
	if(f[x]<a[x]){
		if(sz[x]<a[x]) return 0;
		f[x]=a[x];
	}
	return 1;
}
bool check(int x){
	REP(i,1,n) if(a[i]+b[i]>x || a[i]>sz[i] || b[i]>n-sz[i]) return 0;
	if(!dfs(1,0)) return 0;
	REP(i,1,n) if(b[i]+f[i]>x) return 0;
	return 1;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
#endif
	int T=read();
	while(T--){
		n=read();
		REP(i,1,n) Begin[i]=a[i]=b[i]=0;
		e=0;
		REP(i,1,n-1){
			int x=read(),y=read();
			add_edge(x,y),add_edge(y,x);
		}
		dfs_init(1,0);
		int m=read();
		REP(i,1,m){
			int x=read(),y=read();
			a[x]=y;
		}
		m=read();
		REP(i,1,m){
			int x=read(),y=read();
			b[x]=y;
		}
		int L=0,R=n;
		while(L<=R){
			int Mid=(L+R)>>1;
			if(check(Mid)) R=Mid-1;
			else L=Mid+1;
		}
		if(R+1>n) printf("-1\n");
		else printf("%d\n",R+1);
	}
	return 0;
}
