#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=2e5+10;
ll inf=1e18;
struct point{
	ll x,t;
	int v;
}a[maxn],b[maxn];
ll t[maxn];
struct Segment_tree{
	int cnt;
	struct Tree{
		ll Max,addv;
		int l,r;
		void clear(){
			l=r=Max=addv=0;
		}
	}T[maxn*50];
	void build_tree(){
		REP(i,1,cnt) T[i].clear();
		cnt=0;
	}
	ll query(int x){
		return T[x].Max;
	}
	void push_up(int x){
		T[x].Max=max(T[T[x].l].Max,T[T[x].r].Max);
	}
	void push_down(int x,ll L,ll R){
		if(!T[x].l) T[x].l=++cnt;
		if(!T[x].r) T[x].r=++cnt;
		ll Mid=L+(R-L)/2;
		int u=T[x].l,v=T[x].r;
		T[u].Max+=T[x].addv,T[u].addv+=T[x].addv;
		T[v].Max+=T[x].addv,T[v].addv+=T[x].addv;
		T[x].addv=0;
	}
	void add(int &x,ll L,ll R,ll ql,ll qr,ll v){
		if(!x) x=++cnt;
		if(ql<=L && R<=qr){
			T[x].Max+=v,T[x].addv+=v;
			return;
		}
		ll Mid=L+(R-L)/2;
		push_down(x,L,R);
		if(ql<=Mid) add(T[x].l,L,Mid,ql,qr,v);
		if(qr>Mid) add(T[x].r,Mid+1,R,ql,qr,v);
		push_up(x);
	}
}Seg[2];
int rt[2];
ll id(ll x,bool y){
	if(!y) return x/2;
	return (x+1)/2;
}
ll idl(ll x,bool y){
	if(y==(x&1ll)) return id(x,y);
	return id(x+1,y);
}
ll idr(ll x,bool y){
	if(y==(x&1ll)) return id(x,y);
	return id(x-1,y);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
#endif
	int T=read();
	while(T--){
		int n=read(),tmp=0;
		ll sum=0;
		REP(i,1,n){
			a[i].v=read(),a[i].x=readll();
			sum+=a[i].x;a[i].t=sum;
			t[++tmp]=sum;
		}
		sum=0;
		int m=read();
		REP(i,1,m){
			b[i].v=read(),b[i].x=readll();
			sum+=b[i].x;b[i].t=sum;
			t[++tmp]=sum;
		}
		sort(t+1,t+tmp+1);
		tmp=unique(t+1,t+tmp+1)-t-1;
		int A=1,B=1;
		ll lst=0;
		REP(i,0,1){
			Seg[i].build_tree();
			rt[i]=0;
		}
		Seg[0].add(rt[0],-inf,inf,0,0,1);
		REP(i,1,tmp){
			ll L=t[i-1]+1,R=t[i];
			while(a[A].t<L) ++A;
			while(b[B].t<L) ++B;
			int v=a[A].v-b[B].v;
			int u=lst&1,I=id(lst,u);
			if(v==0) Seg[u].add(rt[u],-inf,inf,I,I,R-L+1);
			else if(abs(v)==1){
				ll del=(R-L+1)*v;
				ll x=min(lst+del,lst),y=max(lst+del,lst);
				Seg[0].add(rt[0],-inf,inf,idl(x,0),idr(y,0),1);
				Seg[1].add(rt[1],-inf,inf,idl(x,1),idr(y,1),1);
				Seg[u].add(rt[u],-inf,inf,I,I,-1);
				lst+=del;
			}
			else{
				ll del=(R-L+1)*v;
				ll x=min(lst+del,lst),y=max(lst+del,lst);
				Seg[u].add(rt[u],-inf,inf,idl(x,u),idr(y,u),1);
				Seg[u].add(rt[u],-inf,inf,I,I,-1);
				lst+=del;
			}
		}
		printf("%lld\n",max(Seg[0].query(rt[0]),Seg[1].query(rt[1])));
	}
	return 0;
}
