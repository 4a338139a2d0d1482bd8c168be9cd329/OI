#include<bits/stdc++.h>
const int N=1e5+10;
using namespace std;

int n,bgn[N],e,to[N<<1],flag,nxt[N<<1],a[N],b[N],sz[N];
int g[N];

namespace rbt{
	inline int read(){
		int x=0;char ch=getchar();
		while(!isdigit(ch))ch=getchar();
		while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
		return x;
	}
	inline void add(int x,int y){
		to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e;
	}
	inline int ckmx(int a,int b){return a>b?a:b;}
	void dfs(int x,int f=0){
		sz[x]=1;
		for(int i=bgn[x]; i; i=nxt[i]){
			if(to[i]!=f){
				dfs(to[i],x); 
				sz[x]+=sz[to[i]];
			}
		}
	}
	void gfs(int x,int f=0){
		for(int i=bgn[x]; i; i=nxt[i]){
			if(to[i]!=f){
				gfs(to[i],x);
				g[x]+=g[to[i]];
			}
		}
		int dt=0;
		dt=ckmx(dt,a[x]-g[x]);
		g[x]+=dt;
	}
	void solve(){
		int x,y,A,B;
		int T;
		T=read();
		while(T--){	
			n=read();
			e=0; flag=1;
			memset(bgn,0,sizeof(bgn)); memset(g,0,sizeof(g));
			memset(a,0,sizeof(a)); memset(b,0,sizeof(b));
			for(int i=1;i<n;++i){
				x=read(); y=read();
				add(x,y); add(y,x);
			}
			A=read();
			for(int i=1;i<=A;++i){
				x=read(); y=read(); a[x]=ckmx(a[x],y);
			}
			B=read();
			for(int i=1;i<=B;++i){
				x=read(); y=read(); b[x]=ckmx(b[x],y);
			}
			dfs(1); 
			
			for(int i=1;i<=n;++i){
				if(sz[i]<a[i]) flag=-1;
				if(n-sz[i]<b[i]) flag=-1;
				if(flag==-1) break; 
			}

			if(flag==-1) puts("-1"); else{
				int ret=0;
				gfs(1);
				for(int i=1;i<=n;++i) ret=ckmx(ret,g[i]+b[i]);
				printf("%d\n",ret);
			}
		}
	}
}

int main(){
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	rbt::solve();
}
