#include<bits/stdc++.h>
#define ll long long 
const int N=2e5+10;
using namespace std;

int n,m;
map<ll,int> mp,mp1;

namespace robot{
	struct node{
		int vi; ll ai;
	};

	struct node p[N],q[N];
	ll tim[N<<1], re[N<<1], g[N<<1], dta[N<<1], rd1[N<<1], dtb[N<<1], rd[N<<1];
	int timsz;
	int tt=0,rr=0;
	ll ckmx(ll a,ll b){return a>b?a:b;}
	void solve(){
		int T;
		scanf("%d",&T);
		while(T--){
			tt=0;rr=0;scanf("%d",&n);
			for(int i=0; i<N<<1; ++i) rd[i]=rd1[i]=re[i]=tim[i]=dta[i]=dtb[i]=g[i]=0;
			
			tim[timsz=1]=0;
			
			
			mp.clear();mp1.clear();

			ll st=0;
			for(int i=1; i<=n; ++i){
				scanf("%d%lld",&p[i].vi,&p[i].ai);
				st+=p[i].ai;tim[++timsz]=st;
			}

			st=0;
			scanf("%d",&m);
			for(int i=1; i<=m; ++i){
				scanf("%d%lld",&q[i].vi,&q[i].ai);
				q[i].vi=-q[i].vi;st+=q[i].ai;
				tim[++timsz]=st;
			}
			
			sort(tim+1,tim+timsz+1);
			mp[tim[1]]=++tt;
			for(int i=2;i<=timsz;++i){
				if(tim[i]!=tim[i-1]){
					mp[tim[i]]=++tt;
					re[tt]=tim[i];
				}
			}

			st=0;
			for(int i=1; i<=n; ++i){
				dta[mp[st]]+=p[i].vi;
				st+=p[i].ai;
				dta[mp[st]]-=p[i].vi;
			}

			st=0;
			for(int i=1; i<=m; ++i){
				dta[mp[st]]+=q[i].vi;
				st+=q[i].ai;
				dta[mp[st]]-=q[i].vi;
			}

			for(int i=1; i<=tt; ++i){
				dta[i]+=dta[i-1];
				rd1[i]=rd1[i-1]+dta[i]*(re[i]-re[i-1]);
			}

			for(int i=1; i<=tt; ++i) rd[i]=rd1[i];
			sort(rd+1,rd+tt+1);
			
			mp1[rd[1]]=++rr;
			for(int i=2; i<=tt; ++i){
				if(rd[i]!=rd[i-1]) mp1[rd[i]]=++rr;
			}

			for(int i=1; i<=tt; ++i){
				if(rd1[i]==rd1[i-1]){
					g[mp1[rd1[i-1]]]+=(re[i+1]-re[i]);
				}
			}
				
			for(int i=2; i<=tt; ++i){
				ll xx=mp1[rd1[i-1]],yy=mp1[rd1[i]];
				if(xx==yy) continue;
				if(xx>yy) swap(xx,yy);
				dtb[xx]+=1;
				dtb[yy]-=1;
			}
			ll ans=0;
			for(int i=1; i<=rr; ++i){
				dtb[i]+=dtb[i-1];
				ans=ckmx(ans,dtb[i]+g[i]);
			}
			printf("%lld\n",ans);
		}
	}
}

int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	robot::solve();
}
