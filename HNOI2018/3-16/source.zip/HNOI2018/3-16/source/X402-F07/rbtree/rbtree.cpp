#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
int n,m;
int lim[maxn][2];
int r[maxn],s[maxn];
vector<int>E[maxn];
bool dfs(int u,int fa){
	r[u]=1,s[u]=0;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(v==fa)continue;
		if(!dfs(v,u))return 0;
		s[u]+=s[v];
		r[u]+=r[v];
	}
	if(s[u]<lim[u][0]){
		if(r[u]<lim[u][0]-s[u])return 0;
		else r[u]-=lim[u][0]-s[u],s[u]=lim[u][0];
	}else if(s[u]>lim[u][1])return 0;
	chkmin(r[u],lim[u][1]-s[u]);
	return 1;
}
bool check(int x){
	if(lim[1][0]>x)return 0;
	int t=lim[1][0];
	lim[1][0]=x;
	REP(i,1,n)if(lim[i][0]+lim[i][1]>x)return 0;
	REP(i,1,n)lim[i][1]=x-lim[i][1];
	bool res=dfs(1,0);
	lim[1][0]=t;
	REP(i,1,n)lim[i][1]=x-lim[i][1];
	return res;
}
void work(){
	n=read();
	REP(i,1,n){
		E[i].clear();
		lim[i][0]=lim[i][1]=0;
	}
	REP(i,2,n){
		int u=read(),v=read();
		E[u].pb(v),E[v].pb(u);
	}
	m=read();
	REP(i,1,m){
		int u=read(),v=read();
		chkmax(lim[u][0],v);
	}
	m=read();
	REP(i,1,m){
		int u=read(),v=read();
		chkmax(lim[u][1],v);
	}
	int l=1,h=n;
	while(l<=h){
		int mid=(l+h)>>1;
		if(check(mid))h=mid-1;
		else l=mid+1;
	}
	write(l==n+1?-1:l,'\n');
	cerr<<(l==n+1?-1:l)<<endl;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
#endif
	int q_cnt=read();
	while(q_cnt--)work();
	return 0;
}
