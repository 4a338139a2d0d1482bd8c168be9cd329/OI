#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=205,all=255,mod=998244353;
int dp[maxn][1<<8][8],val[1<<8],cost[1<<8][1<<8],ans[maxn];
int n=200,m,c_cnt,q_cnt;
void DP(){
	REP(i,0,all){
		int a=i&3,b=(i>>2)&3,c=(i>>4)&3,d=(i>>6)&3;
		if((a>=c_cnt)||(b>=c_cnt)||(c>=c_cnt)||(d>=c_cnt))val[i]=-1;
		else{
			val[i]=(a==b)+(a==c)+(b==d)+(c==d);
			if(val[i]>m)val[i]=-1;
		}
		if(val[i]!=-1){
			dp[1][i][val[i]]=1;
			REP(j,0,all)
				cost[i][j]=(a==(j&3))+(b==((j>>2)&3))+(c==((j>>4)&3))+(d==((j>>6)&3));
		}
	}
	REP(i,1,n-1)
		REP(j,0,all)
			REP(k,0,m){
				if(!dp[i][j][k])continue;
				REP(l,0,all){
					if(val[l]==-1)continue;
					if(k+val[l]+cost[j][l]>m)continue;
					(dp[i+1][l][k+val[l]+cost[j][l]]+=dp[i][j][k])%=mod;
				}
			}
	REP(i,1,n){
		ans[i]=ans[i-1];
		REP(j,0,all)
			REP(k,0,m)
				(ans[i]+=dp[i][j][k])%=mod;
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
#endif
	c_cnt=read(),m=read(),DP();
	q_cnt=read();
	while(q_cnt--){
		int k=read();
		if(k>200)cout<<2*k%mod<<endl;
		write(ans[k],'\n');
	}
	return 0;
}
