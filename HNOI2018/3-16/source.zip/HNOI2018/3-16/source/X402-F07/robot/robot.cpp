#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
const ll lim=2e18;
int n,m;
ll A[maxn],B[maxn];
int c[maxn],d[maxn];
ll pos;
int Root[2],tot=0;
struct node{
	int lc,rc;
	ll tag;
};
struct seg_tree{
	node tr[maxn*200];
	int newnode(){
		++tot;
		tr[tot].lc=tr[tot].rc=tr[tot].tag=0;
		return tot;
	}
	void update(int &p,ll l,ll r,ll L,ll R,ll x){
		if(!p)p=newnode();
		if((L<=l)&&(R>=r)){
			tr[p].tag+=x;
			return;
		}
		ll mid=(l+r)>>1;
		if(L<=mid)update(tr[p].lc,l,mid,L,R,x);
		if(R>mid)update(tr[p].rc,mid+1,r,L,R,x);
	}
	ll query(int &p){
		if(!p)return 0;
		return tr[p].tag+max(query(tr[p].lc),query(tr[p].rc));
	}
}T[2];
void Update(int d,ll k){
	if(!k)return;
	bool t;
	if(d==0){
		t=pos&1;
		T[t].update(Root[t],0,lim,pos/2,pos/2,k);
	}else if(d==1){
		t=pos&1;
		ll l1=(pos+2)/2,r1=(pos+k)/2;
		ll l2=(pos+1)/2,r2=(pos+k)/2;
		if(!((pos+k)&1)){
			if(t&1)--r1;
			else --r2;
		}
		T[t].update(Root[t],0,lim,l1,r1,1);
		T[t^1].update(Root[t^1],0,lim,l2,r2,1);
	}else if(d==2){
		t=pos&1;
		T[t].update(Root[t],0,lim,(pos+2)/2,(pos+2*k)/2,1);
	}else if(d==-1){
		t=(pos-k)&1;
		ll l1=(pos-k)/2,r1=(pos-1)/2;
		ll l2=(pos-k+1)/2,r2=(pos-1)/2;
		if(pos&1){
			if(t&1)--r1;
			else --r2;
		}
		T[t].update(Root[t],0,lim,l1,r1,1);
		T[t^1].update(Root[t^1],0,lim,l2,r2,1);
	}else if(d==-2){
		t=(pos-2*k)&1;
		T[t].update(Root[t],0,lim,(pos-2*k)/2,(pos-2)/2,1);
	}pos+=d*k;
}
namespace solver_3{
	struct node{
		ll pos,cnt;
		bool operator < (const node &A) const {
			return pos<A.pos;
		}
	};
	vector<node>s;
	void work(){
		ll pos=0;
		s.clear();
		s.pb((node){0,1});
		s.pb((node){1,-1});
		REP(i,1,m){
			ll l=pos+d[i],r;
			pos+=(B[i]-B[i-1])*d[i];
			r=pos;
			if(l>r)swap(l,r);
			if(l==r){
				s.pb((node){l,B[i]-B[i-1]});
				s.pb((node){r+1,-(B[i]-B[i-1])});
			}else{
				s.pb((node){l,1});
				s.pb((node){r+1,-1});
			}
		}
		sort(s.begin(),s.end());
		ll ans=0,sum=0;
		REP(i,0,s.size()-1){
			int j=i;
			while((j+1<s.size())&&(s[j+1].pos==s[i].pos))++j;
			REP(k,i,j)sum+=s[k].cnt;
			chkmax(ans,sum),i=j;
		}
		write(ans,'\n');
	}
}
namespace solver_4{
	void work(){
		ll cnt1=1,cnt2=1,Max1=1,Max2=1;
		REP(i,1,n){
			if(c[i]==0)chkmax(Max1,cnt1+=A[i]-A[i-1]);
			else cnt1=1;
		}
		REP(i,1,m){
			if(d[i]==0)chkmax(Max2,cnt2+=B[i]-B[i-1]);
			else cnt2=1;
		}
		write(min(Max1,Max2),'\n');
	}
}
void work(){
	bool flag=1,flag2=1;
	flag2=0;
	tot=0;
	Root[0]=Root[1]=0;
	n=read();
	REP(i,1,n)c[i]=read(),A[i]=A[i-1]+read<ll>(),flag&=c[i]==0;
	m=read();
	REP(i,1,m)d[i]=read(),B[i]=B[i-1]+read<ll>();
	if(flag)return solver_3::work();
	else if(flag2)return solver_4::work();
	int curx=1,cury=1,dx=c[1],dy=d[1];
	ll lst=0;
	pos=lim;
	T[pos&1].update(Root[pos&1],0,lim,pos/2,pos/2,1);
	while((curx<=n)&&(cury<=m)){
		if(A[curx]<=B[cury]){
			Update(dx-dy,A[curx]-lst);
			lst=A[curx],dx=c[++curx];
		}else{
			Update(dx-dy,B[cury]-lst);
			lst=B[cury],dy=d[++cury];
		}
//		cout<<lst<<' '<<pos-lim<<endl;
	}
//	cerr<<A[n]<<endl;
	write(max(T[0].query(Root[0]),T[1].query(Root[1])),'\n');
	cerr<<"tot="<<tot<<endl;
}

int main(){
#ifndef ONLINE_JUDGE
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
#endif
	int q_cnt=read();
	while(q_cnt--)work();
	return 0;
}
