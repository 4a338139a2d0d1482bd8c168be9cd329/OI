/*
Author: CNYALI_LK
LANG: C++
PROG: bf.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
int a[192608],v[192608],b[192608],w[192608],cnt[292608];
int main(){
	freopen("robot.in","r",stdin);
	freopen("bf.out","w",stdout);
	int n,m;
	read();
	n=read();
	for(int i=1;i<=n;++i){
		v[i]=read();a[i]=read()+a[i-1];
	}
	m=read();
	for(int i=1;i<=m;++i){
		w[i]=read();b[i]=read()+b[i-1];
	}
	int tl=100000;
	for(int l=1,r=1,t=1;l<=n;++t){
		++cnt[tl];
		tl+=v[l]-w[r];
		if(a[l]==t)++l;
		if(b[r]==t)++r;
	}
	++cnt[tl];
	int s=0,t=0;
	for(int i=0;i<=200000;++i)if(chkmax(t,cnt[i]))s=i-100000;
	printf("%d %d\n",t,s);
	return 0;
}

