/*
Author: CNYALI_LK
LANG: C++
PROG: robot.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll od[592608],ev[592608],odd[592608],even[592608];
ll a[592608],as[592608],b[592608],bs[592608],poi[592608],tlen[592608];
ll speed[592608],now[592608];
ll have_odd(ll l,ll r){
	if(l+1>=r)return 0;
	if(l&1)return(l+2<r);
	else return 1;
}

ll have_even(ll l,ll r){
	if(l+1>=r)return 0;
	if((l^1)&1)return(l+2<r);
	else return 1;
}
int main(){
	/*
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);*/
	ll t,n,m;
	t=read();
	while(t){
		--t;
		n=read();
		for(ll i=1;i<=n;++i){
			as[i]=read();
			a[i]=read()+a[i-1];
		}
		m=read();
		for(ll i=1;i<=m;++i){
			bs[i]=read();
			b[i]=read()+b[i-1];
		}
		ll q=0,fr=0,to,u=1,v=1,h;
		poi[1]=0;
		now[0]=0;
		while(u<=n){
			to=min(a[u],b[v]);
			tlen[++q]=to-fr;
			speed[q]=as[u]-bs[v];
			poi[q+1]=now[q]=(now[q-1]+tlen[q]*speed[q]);
//			printf("[%lld,%lld)%lld-%lld-%lld\n",fr,to,tlen[q],speed[q],poi[q+1]); fr=to;
			if(to==a[u])++u;
			if(to==b[v])++v;
			fr=to;
		}
		sort(poi+1,poi+q+2);
		h=unique(poi+1,poi+q+2)-poi-1;
		now[0]=lower_bound(poi+1,poi+h+1,0)-poi;
		++even[now[0]];
		--even[now[0]+1];
		++odd[now[0]];
		--odd[now[0]+1];

		for(ll i=0;i<=h;++i)od[i]=ev[i]=odd[i]=even[i]=0;
//		for(ll i=1;i<=h;++i)printf("%lld%c",poi[i],i==h?'\n':' ');
		for(ll i=1;i<=q;++i){
			now[i]=lower_bound(poi+1,poi+h+1,now[i])-poi;
			if(speed[i]==0){
//				printf("%lldexcited\n",tlen[i]);
				odd[now[i]]+=tlen[i];
				even[now[i]]+=tlen[i];
				odd[now[i]+1]-=tlen[i];
				even[now[i]+1]-=tlen[i];
			}
			else {
				u=now[i-1];v=now[i];
				if(speed[i]>0){
					if(speed[i]==1){
						++od[u];
						--od[v];
						++ev[u];
						--ev[v];
						++odd[u];
						--odd[v];
						++even[u];
						--even[v];
					}
					else{
						ll h=poi[u]&1;
						if(h){
							++od[u];
							--od[v];
							++odd[u];
							--odd[v];
						}
						else{	
							++ev[u];
							--ev[v];
							++even[u];
							--even[v];
						}
					}
				}
				else{
					swap(u,v);
					if(speed[i]==-1){
						++od[u]; --od[v]; ++ev[u]; --ev[v];
						++odd[u+1];
						--odd[v+1];
						++even[u+1];
						--even[v+1];
					}
					else{
						ll h=poi[u]&1;
						if(h){
							++od[u];
							--od[v];
							++odd[u+1];
							--odd[v+1];
						}
						else{	
							++ev[u];
							--ev[v];
							++even[u+1];
							--even[v+1];
						}
					}
				}
			}
		}
//		for(ll i=1;i<=h;++i)printf("%lld%c",poi[i],i^h&&i%10?' ':'\n');
		++odd[now[q]];
		--odd[now[q]+1];
		++even[now[q]];
		--even[now[q]+1];
		ll ans=0;
		for(ll i=1;i<=h;++i){
			if(i<h){
				od[i]+=od[i-1];
				ev[i]+=ev[i-1];
				if(have_odd(poi[i],poi[i+1]))chkmax(ans,od[i]);
				if(have_even(poi[i],poi[i+1]))if(((poi[i]+1)>>1)<((poi[i+1]+1)>>1))chkmax(ans,ev[i]);
				
			}
			odd[i]+=odd[i-1];
			even[i]+=even[i-1];
			if(poi[i]&1)chkmax(ans,odd[i]);
			else chkmax(ans,even[i]);
//			printf("%lld,%lld,%lld,%lld\n",od[i],ev[i],odd[i],even[i]);
		}
		printf("%lld\n",ans);

	}

	return 0;
}

