#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int Max(int x,int y){
	return x>y?x:y;
}
int Min(int x,int y){
	return x<y?x:y;
}
int n,T;
int beg[maxn],nex[maxn<<1],tto[maxn<<1],e;
int a[maxn],b[maxn],c[maxn];
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void clear_graph(){
	for(int i=0;i<=n;i++)
		beg[i]=0;
	e=0;
}
struct node{
	int l,r;
};
node dfs(int u,int fa){
	node st,res=(node){0,1};
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		st=dfs(tto[i],u);
		if(st.l==-1) return (node){-1,-1};
		res.l+=st.l,res.r+=st.r;
	}
	res.l=Max(res.l,a[u]);
	res.r=Min(res.r,b[u]);
	if(res.l>res.r) return (node){-1,-1};
	return res;
}
bool pd(int x){
	for(int i=1;i<=n;i++)
		b[i]=x-c[i];
	node st=dfs(1,-1);
	if(st.l==-1) return 0;
	if(st.l<=x&&x<=st.r)
		return 1;
	return 0;
}
int main(){
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	scanf("%d",&T);
	int s,t,m;
	while(T--){
		readl(n);
		clear_graph();
		for(int i=1;i<=n;i++)
			a[i]=b[i]=c[i]=0;
		for(int i=1;i<n;i++){
			readl(s),readl(t);
			putin(s,t);
			putin(t,s);
		}
		readl(m);
		for(int i=1;i<=m;i++){
			readl(s),readl(t);
			a[s]=t;
		}
		readl(m);
		for(int i=1;i<=m;i++){
			readl(s),readl(t);
			c[s]=t;
		}
		int l=0,r=n,mid;
		if(!pd(r)){
			printf("-1\n");
			continue;
		}
		while(r-l>1){
			mid=(l+r)>>1;
			if(pd(mid)) r=mid;
			else l=mid;
		}
		if(pd(l))
			printf("%d\n",l);
		else
			printf("%d\n",r);
	}
	return 0;
}
