#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
int Max(int x,int y){
	return x>y?x:y;
}
int Len;
struct Matrix{
	long long a[130][130];
	void csh(int v){
		for(int i=1;i<=Len;i++)
			for(int j=1;j<=Len;j++)
				a[i][j]=0;
		for(int i=1;i<=Len;i++)
			a[i][i]=v;
	}
}Base,Val[61];
Matrix operator * (const Matrix &A,const Matrix &B){
	Matrix res;
	for(int i=1;i<=Len;i++)
		for(int j=1;j<=Len;j++){
			res.a[i][j]=0;
			for(int k=1;k<=Len;k++)
				res.a[i][j]+=A.a[i][k]*B.a[k][j]%md;
			res.a[i][j]%=md;
		}
	return res;
}
void Deal(){
	Val[0]=Base;
	for(int i=1;i<=60;i++)
		Val[i]=Val[i-1]*Val[i-1];
}
int n,m;
int a[4],c[4];
int b[130][4];
long long d[130],f[130],g[130];
int num;
void dfs_getval(int p,int mx){
	if(p>=4){
		num++;
		for(int i=0;i<4;i++)
			b[num][i]=a[i];
		return;
	}
	for(int i=0;i<=mx;i++){
		a[p]=i;
		if(i==mx)
			dfs_getval(p+1,mx+1);
		else
			dfs_getval(p+1,mx);
	}
}
int id(int x,int y){
	return x*num+y;
}
void dfs_Insert(int las,int p,int mx,long long v){
	if(p>=4){
		int cnt=0;
		for(int i=0;i<4;i++)
			if(a[i]==b[las][i])
				cnt++;
		if(a[0]==a[1]) cnt++;
		if(a[1]==a[2]) cnt++;
		if(a[2]==a[3]) cnt++;
		if(a[3]==a[0]) cnt++;
		int ls=-1;
		bool bo;
		for(int i=0;i<4;i++){
			bo=1;
			for(int j=0;j<i;j++){
				if(a[i]==a[j]){
					c[i]=c[j];
					bo=0;
					break;
				}
			}
			if(bo) c[i]=++ls;
		}
		for(ls=1;ls<=num;ls++){
			bo=1;
			for(int i=0;i<4;i++)
				if(b[ls][i]!=c[i])
					bo=0;
			if(bo) break;
		}
		for(int i=0;i<=m-cnt;i++)
			(Base.a[id(i,las)][id(i+cnt,ls)]+=v)%=md;
		return;
	}
	for(int i=0;i<=mx;i++){
		a[p]=i;
		if(i==mx)
			dfs_Insert(las,p+1,mx+1,v*Max((n-mx),0)%md);
		else
			dfs_Insert(las,p+1,mx,v);
	}
}
int num_of_d;
void getd(int p,int mx,long long v){
	if(p>=4){
		num_of_d++;
		int cnt=0;
		if(a[0]==a[1]) cnt++;
		if(a[1]==a[2]) cnt++;
		if(a[2]==a[3]) cnt++;
		if(a[3]==a[0]) cnt++;
		if(cnt<=m) d[id(cnt,num_of_d)]=v;
		return;
	}
	for(int i=0;i<=mx;i++){
		a[p]=i;
		if(i==mx)
			getd(p+1,mx+1,v*Max((n-mx),0)%md);
		else
			getd(p+1,mx,v);
	}
}
void csh(){
	dfs_getval(0,0);
	int mx;
	for(int i=1;i<=num;i++){
		mx=0;
		for(int j=0;j<4;j++)
			chkmax(mx,b[i][j]);
		dfs_Insert(i,0,mx+1,1);
	}
	Len=num*(m+1);
	Len++;
	for(int i=1;i<=Len;i++)
		Base.a[i][Len]=1;
	Deal();
	getd(0,0,1);
}
int main(){
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	scanf("%d%d",&n,&m);
	csh();
	int Q;
	scanf("%d",&Q);
	long long sum;
	while(Q--){
		scanf("%lld",&sum);
		if(sum==0){
			printf("1\n");
			continue;
		}
		for(int i=1;i<=Len;i++)
			f[i]=d[i];
		for(int i=0;i<=60;i++){
			if(!(sum&(1LL<<i))) continue;
			for(int j=1;j<=Len;j++)
				g[j]=0;
			for(int j=1;j<=Len;j++)
				for(int k=1;k<=Len;k++)
					(g[k]+=f[j]*Val[i].a[j][k])%=md;
			for(int j=1;j<=Len;j++)
				f[j]=g[j];
		}
		printf("%lld\n",f[Len]);
	}
	return 0;
}
