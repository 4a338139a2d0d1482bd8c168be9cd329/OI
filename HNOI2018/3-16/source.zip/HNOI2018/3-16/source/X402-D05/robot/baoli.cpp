#include<bits/stdc++.h>
using namespace std;
int main(){
	int T;
	int n,m;
	scanf("%d",&T);
	return 0;
}
