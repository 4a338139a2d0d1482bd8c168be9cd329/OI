#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const long long maxv=1e17;
long long getrand(){
	return ((long long)rand()<<30)+rand();
}
void solve(){
//	int n=100000,m=100000,T=10;
	int n=10,m=10,T=100000;
	long long sum=1e18,v,S;
	printf("%d\n",T);
	while(T--){
		printf("%d\n",n);
		S=sum;
		for(int i=1;i<n;i++){
			v=getrand()%maxv+1;
			S-=v;
			printf("%d %lld\n",1-rand()%3,v);
		}
		printf("%d %lld\n",1-rand()%3,S);
		printf("%d\n",m);
		S=sum;
		for(int i=1;i<m;i++){
			v=getrand()%maxv+1;
			S-=v;
			printf("%d %lld\n",1-rand()%3,v);
		}
		printf("%d %lld\n",1-rand()%3,S);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("robot.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
