#include<bits/stdc++.h>
using namespace std;
const int md=998244353;
int dp[210][8][300];
int n,m;
int val(int p,int v){
	for(int i=0;i<v;i++)
		p/=n;
	return p%n;
}
int main(){
	freopen("aruba.in","r",stdin);
	scanf("%d%d",&n,&m);
	int cnt,lim=n*n*n*n;
	for(int i=0;i<lim;i++){
		cnt=0;
		for(int j=0;j<4;j++){
			if(val(i,j)==val(i,(j+1)%4))
				cnt++;
		}
		dp[1][cnt][i]=1;
	}
	for(int i=1;i<=10;i++){
		for(int j=0;j<=m;j++){
			for(int k=0;k<lim;k++){
				for(int l=0;l<lim;l++){
					cnt=0;
					for(int p=0;p<4;p++)
						if(val(k,p)==val(l,p))
							cnt++;
					for(int p=0;p<4;p++)
						if(val(l,p)==val(l,(p+1)%4))
							cnt++;
					if(j+cnt<=m)
						(dp[i+1][j+cnt][l]+=dp[i][j][k])%=md;
				}
			}
		}
	}
	int Q;
	scanf("%d",&Q);
	while(Q--){
		scanf("%d",&n);
		int ans=0;
		for(int k=1;k<=n;k++){
			for(int i=0;i<=m;i++)
				for(int j=0;j<lim;j++)
					(ans+=dp[k][i][j])%=md;
		}
		printf("%d\n",ans);
	}
	return 0;
}
