#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=1000000000,m=7;
	printf("%d %d\n",n,m);
	int Q=200;
	long long v=(1LL<<60)-1;
	printf("%d\n",Q);
	while(Q--){
		printf("%lld\n",v);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("aruba.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
