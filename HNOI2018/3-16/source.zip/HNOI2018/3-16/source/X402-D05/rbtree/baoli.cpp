#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
void chkmin(int &x,int y){
	x=x<y?x:y;
}
int T,n;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void clear_graph(){
	for(int i=0;i<=n;i++)
		beg[i]=0;
	e=0;
}
int a[maxn],f[maxn];
int op[maxn],b[maxn],c[maxn],siz[maxn],val[maxn];
int ans;
bool dfs_check(int u,int fa){
	siz[u]=a[u],val[u]=0;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		if(!dfs_check(tto[i],u)) return 0;
		siz[u]+=siz[tto[i]];
	}
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		chkmax(val[u],val[tto[i]]-(siz[u]-siz[tto[i]]));
	}
	if((op[u]&1)&&siz[u]<b[u]){
		return 0;
	}
	if((op[u]&2))
		chkmax(val[u],c[u]);
	return 1;
}
void check(int sum){
	if(dfs_check(1,-1)){
		if(val[1]!=0) return;
		chkmin(ans,sum);
	}
}
void dfs(int p,int sum){
	if(p>n){
		check(sum);
		return;
	}
	a[p]=0;
	dfs(p+1,sum);
	a[p]=1;
	dfs(p+1,sum+1);
}
int main(){
	freopen("rbtree.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int s,t;
	int n1,n2;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		clear_graph();
		for(int i=0;i<=n;i++)
			op[i]=0;
		for(int i=1;i<n;i++){
			scanf("%d%d",&s,&t);
			putin(s,t);
			putin(t,s);
		}
		scanf("%d",&n1);
		for(int i=1;i<=n1;i++){
			scanf("%d%d",&s,&t);
			op[s]|=1,b[s]=t;
		}
		scanf("%d",&n2);
		for(int i=1;i<=n2;i++){
			scanf("%d%d",&s,&t);
			op[s]|=2,c[s]=t;
		}
		ans=n+1;
		dfs(1,0);
		if(ans==n+1)
			printf("-1\n");
		else{
			printf("%d\n",ans);
			cerr<<ans<<endl;
		}
	}
	return 0;
}
