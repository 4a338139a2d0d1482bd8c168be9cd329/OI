#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxn=100100;
int a[maxn];
void solve(){
	int T=5e4,n,num,gl=10,vgl=10,sum;
	printf("%d\n",T);
	while(T--){
		n=20;
		printf("%d\n",n);
		gl=rand()%n+1,vgl=rand()%n+1,sum=rand()%n+1;
		for(int i=2;i<=n;i++)
			printf("%d %d\n",rand()%(i-1)+1,i);

		num=0;
		for(int i=1;i<=n;i++)
			a[i]=0;
		for(int i=1;i<=n;i++){
			if(rand()%gl==0){
				if(rand()%vgl==0) a[i]=rand()%n+1;
				else a[i]=rand()%sum+1;
				num++;
			}
		}
		printf("%d\n",num);
		for(int i=1;i<=n;i++)
			if(a[i])
				printf("%d %d\n",i,a[i]);

		num=0;
		for(int i=1;i<=n;i++)
			a[i]=0;
		for(int i=1;i<=n;i++){
			if(rand()%gl==0){
				if(rand()%vgl==0) a[i]=rand()%n+1;
				else a[i]=rand()%sum+1;
				num++;
			}
		}
		printf("%d\n",num);
		for(int i=1;i<=n;i++)
			if(a[i])
				printf("%d %d\n",i,a[i]);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("rbtree.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
