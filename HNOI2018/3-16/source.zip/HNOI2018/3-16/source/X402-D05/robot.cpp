#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
void chkmax(long long &x,long long y){
	x=x>y?x:y;
}
long long Min(long long x,long long y){
	return x<y?x:y;
}
int n,m;
struct node{
	int v;
	long long t;
}a[maxn],b[maxn];
long long ta[maxn],tb[maxn];
long long readl(){
	long long x=0;
	char ch=getchar();
	bool zx=0;
	while(!isdigit(ch)){
		if(ch=='-') zx^=1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
	if(zx) x=-x;
	return x;
}
namespace Seg{
	struct point{
		long long p,v;
		int op;
	}stk[maxn<<3];
	bool cmp(const point &A,const point &B){
		return A.p==B.p?A.v<B.v:A.p<B.p;
	}
	int top;
	void clear(){
		top=0;
	}
	void Insert(long long l,long long r,long long cnt,int v){
		stk[++top]=(point){l,cnt,v};
		stk[++top]=(point){r+1,-cnt,v};
	}
	long long Query(){
		sort(stk+1,stk+top+1,cmp);
		long long c1=0,c2=0,res=0;
		for(int i=1;i<=top;i++){
			if(stk[i].op|1) c1+=stk[i].v;
			if(stk[i].op|2) c2+=stk[i].v;
			chkmax(res,c1);
			chkmax(res,c2);
		}
		return res;
	}
}
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int T;
	scanf("%d",&T);
	long long t,vr;
	int l1,l2;
	long long p1,p2;
	while(T--){
		Seg::clear();
		n=readl();
		for(int i=1;i<=n;i++)
			a[i].v=readl(),a[i].t=readl();
		a[n].t++;
		for(int i=1;i<=n;i++)
			ta[i]=ta[i-1]+a[i].t;
		m=readl();
		for(int i=1;i<=m;i++)
			b[i].v=readl(),b[i].t=readl();
		b[m].t++;
		for(int i=1;i<=m;i++)
			tb[i]=tb[i-1]+b[i].t;
		t=0,l1=1,l2=1;
		p1=0,p2=0;
		while(t<ta[n]){
			vr=Min(ta[l1],tb[l2]);

			if(a[l1].v==1&&b[l2].v==-1)
				Seg::Insert(p2-(vr-t-1)*2-p1,p2-p1,1,(p1&1)==(p2&1)?2:1);
			else if(a[l1].v==-1&&b[l2].v==1)
				Seg::Insert(p2-p1,p2+(vr-t-1)*2-p1,1,(p1&1)==(p2&1)?2:1);
			else if(a[l1].v==b[l2].v)
				Seg::Insert(p2-p1,p2-p1,vr-t,(p1&1)==(p2&1)?2:1);
			else if(a[l1].v==1&&b[l2].v==0)
				Seg::Insert(p2-(vr-t-1)-p1,p2-p1,1,3);
			else if(a[l1].v==-1&&b[l2].v==0)
				Seg::Insert(p2-p1,p2+(vr-t-1)-p1,1,3);
			else if(a[l1].v==0&&b[l2].v==1)
				Seg::Insert(p2-p1,p2+(vr-t-1)-p1,1,3);
			else if(a[l1].v==0&&b[l2].v==-1)
				Seg::Insert(p2-(vr-t-1)-p1,p2-p1,1,3);

			p1+=a[l1].v*(vr-t);
			p2+=b[l2].v*(vr-t);
			t=vr;
			if(ta[l1]<=t) l1++;
			if(tb[l2]<=t) l2++;
		}
		printf("%lld\n",Seg::Query());
	}
	return 0;
}
