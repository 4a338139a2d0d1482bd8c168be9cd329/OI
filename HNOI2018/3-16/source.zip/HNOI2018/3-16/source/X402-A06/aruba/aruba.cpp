#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(ll i = (a);i <= (b); ++i)
#define rep(i, a, b) for(ll i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

ll read() {
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const ll maxn = 100010;

ll C, K, Q;

void Get() {
	C = read(), K = read();
	Q = read();
}

const ll mod = 998244353;

void solve_2() {
	For(i, 1, Q) {
		ll x = read();
		printf("%lld\n", x % mod * 2 % mod);
	}
}

int main() {
	
	freopen("aruba.in", "r", stdin);
	freopen("aruba.out", "w", stdout);

	Get();
	solve_2();

	return 0;
}
