#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, V[maxn], A[maxn], cnt, m, W[maxn], B[maxn], tot, all = 0;

struct node{
	int pos, t;
}a[maxn], b[maxn];

void Get() {
	all = 0;
	n = read();
	For(i, 1, n) V[i] = read(), A[i] = read(), all += A[i];

	m = read();
	For(i, 1, m) W[i] = read(), B[i] = read();
}

bool cmp(node c, node d) {
	return c.pos == d.pos ? c.t < d.t : c.pos < d.pos;
}

int ls[maxn], vis[3010][3010];

void pre_work() {
	int pos = 0; 
	cnt = 0, tot = 0;
	a[++cnt].pos = 0, a[cnt].t = cnt-1;
	For(i, 1, n) {
		For(j, 1, A[i]) {
			a[++cnt].pos = pos + V[i];
			a[cnt].t = cnt-1;
			pos += V[i];
		}
	}

	pos = 0; 
	b[++tot].pos = 0, b[tot].t = tot-1;
	For(i, 1, m) {
		For(j, 1, B[i]) {
			b[++tot].pos = pos + W[i];
			b[tot].t = tot-1;
			pos += W[i];
		}
	}

	sort(a+1, a+cnt+1, cmp);
	sort(b+1, b+tot+1, cmp);

	for(int i = 1;i <= cnt; ++i) {
		ls[i] = a[i].pos;
		int j = i;

		vis[i][a[j].t] = 1;
		while(j > 1 && a[j].pos == a[j-1].pos) --j, vis[i][a[j].t] = 1;
	}

	int down = a[1].pos - b[tot].pos - 1;
	int up = a[cnt].pos - b[1].pos + 1;

	int Ans = 0;
	For(i, down, up) {
		int nowans = 0;
		For(j, 1, tot) {
			pos = upper_bound(ls+1, ls+cnt+1, b[j].pos+i) - ls - 1;
			if(pos == 0) continue;
			if(b[j].pos+i == ls[pos]) nowans += vis[pos][b[j].t];
		}

		Ans = max(Ans, nowans);
	}

	for(int i = 1;i <= cnt; ++i){
		ls[i] = a[i].pos;
		int j = i;

		vis[i][a[j].t] = 0;
		while(j > 1 && a[j].pos == a[j-1].pos) --j, vis[i][a[j].t] = 0;
	}

	printf("%d\n", Ans);
}

void solve() {
	pre_work();
}

int main() {
	
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);

	int _ = read();
	while(_ --){
		Get();
		solve();
	}

	return 0;
}
