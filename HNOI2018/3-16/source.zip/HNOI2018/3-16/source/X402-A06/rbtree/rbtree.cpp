#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, Begin[maxn], to[maxn], e, Next[maxn], other[maxn], Min[maxn];

void add(int x,int y) {
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get() {
	n = read();
	e = 0;
	For(i, 1, n) Begin[i] = 0;

	For(i, 1, n) Min[i] = 0, other[i] = 0;
	For(i, 2, n) {
		int x = read(), y = read();
		add(x, y), add(y, x);
	}
	int A = read();
	For(i, 1, A) {
		int r = read(), s = read();
		Min[r] = max(Min[r], s);
	}

	int B = read();
	For(i, 1, B) {
		int r = read(), s = read();
		other[r] = max(other[r], s);
	}
}

int lim, dp[2010][2010], Size[maxn], OK, ls[maxn], down[maxn], up[maxn];

void get_size(int h,int father) {
	Size[h] = 1;
	for(int i = Begin[h]; i ;i = Next[i]) {
		int v = to[i];
		if(v == father) continue;

		get_size(v, h);
		Size[h] += Size[v];
	}

	if(Size[h] < Min[h]) OK = 1;
	if(n - Size[h] < other[h]) OK = 1;
}

void dfs(int h,int father,int tot) {
	if(OK) return;
	down[h] = Min[h], up[h] = tot - other[h];
	int nowcnt = 0;

	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father) continue;

		++ nowcnt;
		dfs(v, h, tot);
	}

	int lim = min(Size[h], tot);
	dp[h][0] = 1; dp[h][1] = 1;
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father) continue;

		For(j, 0, lim) ls[j] = dp[h][j], dp[h][j] = 0;
		rep(j, lim, 0) {
			For(k, down[v], min(Size[v], up[v]) ) {
				dp[h][j] |= (ls[j-k] & dp[v][k]);
				if(dp[h][j]) break;
			}
		}
	}

	if(nowcnt == 0 && 0 >= down[h] && 0 <= up[h]) dp[h][0] = 1;
	if(nowcnt == 0 && 1 >= down[h] && 1 <= up[h]) dp[h][1] = 1;

	bool flag_now = 0;
	For(i, down[h], up[h]) {
		if(dp[h][i]) {
			flag_now = 1;
			break;
		}
	}

	For(i, 0, down[h]-1) dp[h][i] = 0;
	For(i, up[h]+1, Size[h]) dp[h][i] = 0;

	if(!flag_now) OK = 1;
}

int check(int h) {
	OK = 0;
	For(i, 1, n) For(j, 0, h) dp[i][j] = 0;
	dfs(1, -1, h);

	if(OK) return 0;
	return 1;
}

void solve_bf() {
	OK = 0;
	get_size(1, -1);
	if(OK) {puts("-1"); return;}

	int l = 0, r = n, ans = n;
	while(l <= r) {
		int mid = l+r >> 1;

		if(check(mid) ) ans = mid, r = mid-1;
		else l = mid+1;
	}

	printf("%d\n", ans);
}

int color[maxn], ok;

void dfs_check(int h,int father,int all) {
	Size[h] = color[h];
	for(int i = Begin[h];i ;i = Next[i]) {
		int v = to[i];
		if(v == father) continue;

		dfs_check(v, h, all);
		Size[h] += Size[v];
	}

	if(Size[h] < Min[h]) ok = 1;
	if(all - Size[h] < other[h]) ok = 1;
}

void bf_bf() {
	int tmp = (1 << n) - 1, Ans = inf;
	for(int i = 0;i <= tmp; ++i) {
		int tot = 0; ok = 0;
		for(int j = 1;j <= n; ++j) {
			if(i & (1 << j-1) ) color[j] = 1, ++ tot;
			else color[j] = 0;
		}

		dfs_check(1, -1, tot);
		if(!ok) Ans = min(Ans, __builtin_popcount(i) );
	}

	if(Ans == inf) Ans = -1;
	printf("%d\n", Ans);
}

int main() {

	freopen("rbtree.in", "r", stdin);
	freopen("rbtree.out", "w", stdout);

	int _ = read();
	while(_ --){
		Get();
		solve_bf();
	}

	return 0;
}
