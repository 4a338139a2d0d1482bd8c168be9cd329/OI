#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline LL read()
{
	LL x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
int main()
{
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	LL c=read(),k=read();
	LL q=read();
	while(q--)
	{
		LL x=read();
		if(c==2)
			printf("%lld\n",x*2LL);
		else puts("0");
	}
	return 0;
}
