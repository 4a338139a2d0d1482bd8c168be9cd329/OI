#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=1e5+5;
int head[maxn],tot,col[maxn],bnum[maxn],deep[maxn],sz[maxn],ra[maxn],sa[maxn],rb[maxn],sb[maxn],t,n,a,b,ans,id[maxn],cnt;
struct edge{
    int to,next;
}e[maxn<<1];
struct task{
    int r,s,pri;
}A[maxn];
inline bool cmp1(task a,task b){
    return a.pri>b.pri;
}
inline int _min(int _,int __){
    return _<__?_:__;
}
inline void add(int u,int v){
    e[++tot].to=v;
    e[tot].next=head[u];
    head[u]=tot;
}
inline void dfs2(int rt,int fa){
    bnum[rt]=col[rt];
    for(register int i=head[rt];i;i=e[i].next){
        if(e[i].to==fa)continue;
        dfs2(e[i].to,rt);
        bnum[rt]+=bnum[e[i].to];
    }
    return ;
}
inline void dfs3(int rt,int fa){
    id[rt]=++cnt;
    sz[rt]=1;
    deep[rt]=deep[fa]+1;
    for(register int i=head[rt];i;i=e[i].next){
        if(e[i].to==fa)continue;
        dfs3(e[i].to,rt);
        sz[rt]+=sz[e[i].to];
    }
    return ;
}
inline bool check(){
    for(register int i=1;i<=a;++i){
        if(bnum[ra[i]]<sa[i])return 0;
    }
    for(register int i=1;i<=b;++i){
        if((bnum[1]-bnum[rb[i]])<sb[i])return 0;
    }
    return 1;
}
inline void dfs1(int pos){
    if(pos>n){
        dfs2(1,0);
        if(check())ans=_min(ans,bnum[1]);
        return ;
    }
    col[pos]=1;
    dfs1(pos+1);
    col[pos]=0;
    dfs1(pos+1);
    return ;
}
int sum[maxn<<2];
inline int lowbit(int x){
    return x&-x;
}
inline void update(int pos,int num){
    while(pos<=n){
        sum[pos]+=num;
        pos+=lowbit(pos);
    }
}
inline int query(int pos){
    int ans=0;
    while(pos){
        ans+=sum[pos];
        pos-=lowbit(pos);
    }
    return ans;
}
int main(){
    freopen("rbtree.in","r",stdin);
    freopen("rbtree.out","w",stdout);
    read(t);
    while(t--){
        read(n);
        if(n<=17){
            ans=2147483645;
            memset(bnum,0,sizeof(bnum));
            memset(head,0,sizeof(head));
            tot=0;
            for(register int i=1;i<=n-1;++i){
                int u,v;
                read(u);read(v);
                add(u,v);
                add(v,u);
            }
            read(a);
            for(register int i=1;i<=a;++i){
                read(ra[i]);read(sa[i]);
            }
            read(b);
            for(register int i=1;i<=b;++i){
                read(rb[i]);read(sb[i]);
            }
            dfs1(1);
            if(ans==2147483645)puts("-1");
            else printf("%d\n",ans);
        }
        else{
            bool flag=1;
            memset(head,0,sizeof(head));
            tot=0;
            for(register int i=1;i<=n-1;++i){
                int u,v;
                read(u);read(v);
                add(u,v);
                add(v,u);
            }
            dfs3(1,0);
            read(a);
            for(register int i=1;i<=a;++i){
                int r,s;
                read(r);read(s);
                A[i].r=r;A[i].s=s;
                A[i].pri=deep[r];
            }
            sort(A+1,A+1+a,cmp1);
            for(register int i=1;i<=a;++i){
                if(sz[A[i].r]<A[i].s){
                    flag=0;
                    cout<<A[i].r<<' '<<sz[A[i].r]<<' '<<A[i].s<<endl;
                    break;
                }
                update(id[A[i].r],A[i].s-(query(id[A[i].r]+sz[A[i].r]-1)-query(id[A[i].r]-1)));
            }
            int SUM=query(sz[1]);
            read(b);
            if(flag!=0){
                for(register int i=1;i<=b;++i){
                    int r,s;
                    read(r);read(s);
                    int num=query(id[r]+sz[r]-1)-query(id[r]-1);
                    if((sz[1]-num)<s){
                        flag=0;
                        break;
                    }
                    if((num+s)>SUM){
                        update(1,(num+s)-SUM);
                        SUM=num+s;
                    }
                }
            }
            if(flag==0)puts("-1");
            else printf("%d\n",SUM);
        }
    }
    return 0;
}
