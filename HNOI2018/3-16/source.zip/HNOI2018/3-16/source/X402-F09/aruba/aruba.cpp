#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
int main(){
    freopen("aruba.in","r",stdin);
    freopen("aruba.out","w",stdout);
    int c,k,Q,h;
    read(c);read(k);
    read(Q);
    while(Q--){
        read(h);
        printf("%d\n",2*h);
    }
    return 0;
}
