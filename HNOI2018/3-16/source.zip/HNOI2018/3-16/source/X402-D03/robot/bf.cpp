#include<bits/stdc++.h>
using namespace std;

const int MAXN = 3010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m;
int A[MAXN], B[MAXN];

int main() {
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);

	int T = read(), i, j;
	while(T--) {
		n = read();
		int cnt = 0, ans = 0;
		A[0] = 0;
		for(i = 1; i <= n; i++) {
			int v = read(), a = read();
			for(j = cnt+1; j <= cnt+a; j++)
				A[j] = A[j-1]+v;
			cnt += a;
		}
		cnt = 0;
		B[0] = 0;
		m = read();
		for(i = 1; i <= m; i++) {
			int v = read(), b = read();
			for(j = cnt+1; j <= cnt+b; j++)
				B[j] = B[j-1]+v;
			cnt += b;
		}
		//for(i = 0; i <= cnt; i++)
		//	printf("%d ", A[i]);
		//printf("\n");
		//for(i = 0; i <= cnt; i++)
		//	printf("%d ", B[i]);
		//printf("\n");
		for(i = 0; i <= cnt; i++) {
			int t = B[i]-A[i];
			int res = 0;
			for(j = 0; j <= cnt; j++)
				if(A[j]+t == B[j]) res++;
			ans = max(ans, res);
		}
		printf("%d\n", ans);
	}
	return 0;
}
