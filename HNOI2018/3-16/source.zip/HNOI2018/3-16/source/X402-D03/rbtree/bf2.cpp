#include<bits/stdc++.h>
using namespace std;

const int MAXN = 1010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmax(int &cur, int val) {
	if(val > cur) cur = val;
}

int n, size[MAXN], dw[MAXN];
int up[MAXN], b[MAXN], an, bn;
int st[MAXN], to[MAXN<<1];
int nxt[MAXN<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

void dfs(int u, int fa) {
	int i;
	size[u] = 1;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		dfs(v, u), size[u] += size[v];
	}
}

namespace Plan1 {
	int f[MAXN];
	inline void DP(int u, int fa) {
		int i;
		f[u] = 0;
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			if(v == fa) continue;
			DP(v, u);
			f[u] += f[v];
		}
		chkmax(f[u], dw[u]);
	}
	inline void solve() {
		for(int i = 1; i <= n; i++)
			if(dw[i] > size[i]) {
				printf("-1\n");
				return;
			}
		DP(1, 0);
		printf("%d\n", f[1]);
	}
}

bool dp[MAXN][MAXN], f[MAXN];
inline void DP(int u, int fa) {
	//cerr << u << ' ' << endl;
	int i, j, k, cnt = 1;
	memset(dp[u], 0, sizeof(dp[u]));
	dp[u][0] = dp[u][1] = true;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		DP(v, u);
		for(j = 0; j <= size[v]; j++) {
			if(!dp[v][j]) continue;
			for(k = 0; k <= cnt; k++) {
				if(!dp[u][k]) continue;
				f[k+j] |= 1;
			}
		}
		cnt += size[v];
		for(j = 0; j <= cnt; j++) dp[u][j] = f[j], f[j] = 0;
	}
	for(i = 0; i < dw[u]; i++) dp[u][i] = false;
	for(i = up[u]+1; i <= cnt; i++) dp[u][i] = false;
}

inline bool check(int cnt) {
	int i;
	for(i = 1; i <= n; i++) {
		up[i] = cnt-b[i];
		if(up[i] < 0) return false;
	}
	DP(1, 0);
	/*for(i = 1; i <= n; i++)
		printf("%d %d\n", dw[i], up[i]);
	printf("\n");
	for(i = 1; i <= n; i++) {
		for(int j = 0; j <= n; j++)
			printf("%d ", dp[i][j]);
		printf("\n");
	}*/
	return dp[1][cnt];
}

int main() {
	freopen("rbtree.in", "r", stdin);
	freopen("rbtree.out", "w", stdout);

	int T = read(), i;
	while(T--) {
		n = read();
		e = 0, memset(st, 0, sizeof(st));
		for(i = 1; i < n; i++) {
			int u = read(), v = read();
			Add(u, v), Add(v, u);
		}
		dfs(1, 0);
		memset(dw, 0, sizeof(dw));
		memset(b, 0, sizeof(b));
		an = read();
		for(i = 1; i <= an; i++) {
			int r = read();
			chkmax(dw[r], read());
		}
		bn = read();
		if(bn == 0) {
			Plan1::solve();
			continue;
		}
		for(i = 1; i <= bn; i++) {
			int r = read();
			b[r] = read();
		}
		if(!check(n)) {
			printf("-1\n");
			continue;
		}
		//return 0;
		int L = 0, R = n;
		while(L < R) {
			int mid = (L+R)>>1;
			if(check(mid)) R = mid;
			else L = mid+1;
		}
		printf("%d\n", L);
	}
	return 0;
}
