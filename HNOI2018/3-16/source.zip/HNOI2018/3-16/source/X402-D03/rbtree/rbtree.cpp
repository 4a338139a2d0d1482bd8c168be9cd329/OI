#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmax(int &cur, int val) {
	if(val > cur) cur = val;
}

int n, size[MAXN], dw[MAXN];
int up[MAXN], b[MAXN], an, bn;
int st[MAXN], to[MAXN<<1];
int nxt[MAXN<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

void dfs(int u, int fa) {
	int i;
	size[u] = 1;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		dfs(v, u), size[u] += size[v];
	}
}

int l[MAXN], r[MAXN];
inline void DP(int u, int fa) {
	int i;
	l[u] = 0, r[u] = 1;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		DP(v, u);
		l[u] = l[u]+l[v];
		r[u] = r[u]+r[v];
	}
	l[u] = max(l[u], dw[u]);
	r[u] = min(r[u], up[u]);
}

inline bool check(int cnt) {
	int i;
	for(i = 1; i <= n; i++) {
		up[i] = cnt-b[i];
		if(up[i] < 0) return false;
		if(up[i] < dw[i]) return false;
	}
	DP(1, 0);
	for(i = 1; i <= n; i++) if(l[i] > r[i]) return false;
	return l[1] <= cnt && r[1] >= cnt;
}

int main() {
	freopen("rbtree.in", "r", stdin);
	freopen("rbtree.out", "w", stdout);

	int T = read(), i;
	while(T--) {
		n = read();
		e = 0, memset(st, 0, sizeof(st));
		for(i = 1; i < n; i++) {
			int u = read(), v = read();
			Add(u, v), Add(v, u);
		}
		dfs(1, 0);
		memset(dw, 0, sizeof(dw));
		memset(b, 0, sizeof(b));
		an = read();
		for(i = 1; i <= an; i++) {
			int R = read();
			chkmax(dw[R], read());
		}
		bn = read();
		for(i = 1; i <= bn; i++) {
			int R = read();
			b[R] = read();
		}
		if(!check(n)) {
			printf("-1\n");
			continue;
		}
		int L = 0, R = n;
		while(L < R) {
			int mid = (L+R)>>1;
			if(check(mid)) R = mid;
			else L = mid+1;
		}
		printf("%d\n", L);
	}
	return 0;
}
