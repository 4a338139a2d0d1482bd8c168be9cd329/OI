#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 240;
const ll MOD = 998244353;

inline ll read() {
	ll x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

ll dp[MAXN][256][8];
ll pc[6];
ll res[MAXN];
int cnt[MAXN], c, K;
int cost[256][256];

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int main() {
	freopen("aruba.in", "r", stdin);
	freopen("aruba.out", "w", stdout);

	int i, k, s, ns;
	c = read(), K = read();
	if(c == 1) {
		int Q = read();
		while(Q--) {
			read();
			if(K >= 4) printf("1\n");
			else printf("0\n");
		}
		return 0;
	}
	if(c == 2 && K == 0) {
		int Q = read();
		while(Q--) {
			ll h = read();
			printf("%lld\n", h*2%MOD);
		}
		return 0;
	}
	pc[0] = 1;
	for(i = 1; i <= 5; i++) pc[i] = pc[i-1]*c%MOD;
	for(i = 0; i < pc[4]; i++) {
		if(i % c == (i / pc[1]) % c) cnt[i]++;
		if((i/pc[1])%c == (i/pc[2])%c) cnt[i]++;
		if((i/pc[2])%c == (i/pc[3])%c) cnt[i]++;
		if((i/pc[3])%c == i % c) cnt[i]++;
	}
	for(s = 0; s < pc[4]; s++)
		for(ns = 0; ns < pc[4]; ns++) {
			cost[s][ns] = cnt[ns];
			if(ns % c == s % c) cost[s][ns]++;
			if((ns/pc[1])%c == (s/pc[1])%c) cost[s][ns]++;
			if((ns/pc[2])%c == (s/pc[2])%c) cost[s][ns]++;
			if((ns/pc[3])%c == (s/pc[3])%c) cost[s][ns]++;
		}
	for(s = 0; s < pc[4]; s++) 
		dp[1][s][cnt[s]] = 1;
	for(i = 1; i < 200; i++) {
		for(s = 0; s < pc[4]; s++) {
			for(k = 0; k <= K; k++) {
				if(!dp[i][s][k]) continue;
				for(ns = 0; ns < pc[4]; ns++) {
					int cn = cost[s][ns]+k;
					if(cn > K) continue;
					update(dp[i+1][ns][cn], dp[i][s][k]);
				}
			}
		}
	}
	res[0] = 0;
	for(i = 1; i <= 200; i++) {
		res[i] = 0;
		for(s = 0; s < pc[4]; s++) 
			for(k = 0; k <= K; k++) 
				update(res[i], dp[i][s][k]);
		update(res[i], res[i-1]);
	}
	int Q = read();
	while(Q--) {
		int h = read();
		printf("%lld\n", res[h]);
	}
	return 0;
}
