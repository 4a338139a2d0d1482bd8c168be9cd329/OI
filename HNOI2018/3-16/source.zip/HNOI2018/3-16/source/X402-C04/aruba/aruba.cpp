#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline ll read()
{
	ll x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const ll md=998244353;
const ll N=209;

ll mh,c,k,q,ans;
int col[N][2][2];

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}

inline void dfs(ll h,int x,int y,ll k)
{
	if(k<0)return;
	if(h>=2 && x==1 && y==1){ans++;if(ans>=md)ans-=md;}
	if(h==mh+1)return;

	ll nxth=h;
	int nxtx=x,nxty=y+1;
	if(nxty>2)nxtx+=1,nxty=1;
	if(nxtx>2)nxth+=1,nxtx=1;
	for(int i=1,nxtk;i<=c;i++)
	{
		col[h][x-1][y-1]=i;
		nxtk=k;
		if(y==2 && col[h][x-1][y-2]==i)
			nxtk--;
		if(x==2 && col[h][x-2][y-1]==i)
			nxtk--;
		if(h>=2 && col[h-1][x-1][y-1]==i)
			nxtk--;
		if(nxtk>=0)
			dfs(nxth,nxtx,nxty,nxtk);
	}
}

namespace trys
{
	const int K=1<<8;

	ll f[2][K];
	vector<int> states;
	vector<vector<int> >nxt;
	vector<int> empty;

	inline int getstate(int s,int x,int y)
	{
		return (s>>(((x-1)*2+y-1)*2))&3;
	}

	int main()
	{
		while(q--)
		{
			mh=read();
			states.clear();
			nxt.clear();
			for(int k=0;k<K;k++)
			{
				for(int i=1;i<=2;i++)
					for(int j=1;j<=2;j++)
						if(getstate(k,i,j)>c)
							goto nxts;
				if(getstate(k,1,1)==getstate(k,1,2))continue;
				if(getstate(k,1,1)==getstate(k,2,1))continue;
				if(getstate(k,2,2)==getstate(k,1,2))continue;
				if(getstate(k,2,2)==getstate(k,2,1))continue;
				states.push_back(k);
				nxts:;
			}
			nxt.resize(states.size());

			for(int i=0;i<states.size();i++)
				for(int j=0;j<states.size();j++)
				{
					if(i==j)continue;
					int a=states[i],b=states[j];
					for(int k=1;k<=2;k++)
						for(int l=1;l<=2;l++)
							if(getstate(a,k,l)==getstate(b,k,l))
								goto nxtss;
					nxt[i].push_back(j);
					nxtss:;
				}
			
			memset(f,0,sizeof(f));
			for(int i=0;i<states.size();i++)
				f[1][i]=1;

			for(int i=2;i<=mh;i++)
			{
				memset(f[i&1],0,sizeof(f[i&1]));
				for(int j=0;j<states.size();j++)
					if(f[i&1^1][j])
						for(int k=0;k<nxt[j].size();k++)
							(f[i&1][nxt[j][k]]+=f[i&1^1][j])%=md;
			}
			ll ans=0;
			for(int i=0;i<states.size();i++)
				(ans+=f[mh&1][i])%=md;
			printf("%lld\n",ans);
		}
	}
}

int main()
{
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);

	c=read(),k=read(),q=read();

	if(c==2 && k==0)
	{
		while(q--)
		{
			mh=read();
			printf("%lld\n",2ll*mh%md);
		}
		return 0;
	}


	while(q--)
	{
		mh=read();
		ans=0;
		dfs(1,1,1,k);
		printf("%lld\n",ans);
	}

	return 0;
}
