#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=1e5+9;

int n,ca,cb,ans;
int to[N<<1],nxt[N<<1],beg[N],tot;
int id[N],ed[N],seg[N],dfn;
int a[N],b[N],sum[N];

inline void chkmin(int &a,int b){if(a>b)a=b;}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void dfs1(int u,int fa)
{
	seg[id[u]=++dfn]=u;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa)
			dfs1(to[i],u);
	ed[u]=dfn;
}

bool flag;
inline void dfs2(int u)
{
	if(u==n+1)
	{
		for(int i=1;i<=n;i++)
		{
			if(sum[ed[i]]-sum[id[i]-1]<a[i])
				return;
			if(sum[n]-(sum[ed[i]]-sum[id[i]-1])<b[i])
				return;
		}
		chkmin(ans,sum[n]);
		return;
	}

	sum[u]=sum[u-1];
	dfs2(u+1);
	sum[u]=sum[u-1]+1;
	dfs2(u+1);
	return;
}

namespace plan
{
	int f[N],g[N],fl=0;

	inline int dfs(int u,int fa)
	{	
		int siz=1;f[u]=g[u]=0;
		for(int i=beg[u];i;i=nxt[i])
			if(to[i]!=fa)
			{
				siz+=dfs(to[i],u);
				g[u]+=f[to[i]];
			}
		f[u]=max(a[u],g[u]);
		if(f[u]>siz)
			fl=-1;
		return siz;
	}

	int minaa()
	{
		fl=0;
		dfs(1,0);
		if(fl==0)
			printf("%d\n",f[1]);
		else
			puts("-1");
		return 0;
	}

	int minab1()
	{
		fl=0;
		dfs(1,0);
		if(fl==0)
		{
			for(int i=1;i<=n;i++)
				if(f[1]-f[i]<b[i])
				{
					if(f[1]!=n && i!=1)
						return printf("%d\n",f[1]+1),0;
					else
						return puts("-1"),0;
				}
			printf("%d\n",f[1]);
		}
		
		else
			puts("-1");
		return 0;
	}
}

inline int mina()
{
	n=read();
	memset(beg,tot=dfn=0,sizeof(beg));
	memset(a,-1,sizeof(a));
	memset(b,-1,sizeof(b));
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
	}
	ca=read();
	int fla=0,flb=0,flb1=0;
	for(int i=1,r,s;i<=ca;i++)
	{
		r=read();s=read();
		a[r]=s;if(a[r]!=0)fla=1;
	}
	cb=read();
	for(int i=1,r,s;i<=cb;i++)
	{
		r=read();s=read();
		b[r]=s;
		if(b[r]!=0)flb=1;
		if(b[r]>1)flb1=1;
	}
	if(!flb)return plan::minaa();
	if(!flb1)return plan::minab1();

	
	dfs1(1,0);
	ans=1e9;
	dfs2(1);

	if(ans!=1e9)
		printf("%d\n",ans);
	else
		puts("-1");
	return 0;
}

int main()
{
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);

	for(int T=read();T;T--)
		mina();
	return 0;
}
