#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=1000;
const int M=10000;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

const int P=1e7;
int a[P];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("rbtree.in","w",stdout);

	int t=2;
	printf("%d\n",t);
	while(t--)
	{
		int n=20,a=5,b=5;
		printf("%d\n",n);
		for(int i=2;i<=n;i++)
			printf("%d %d\n",rand()%(i-1)+1,i);

		printf("%d\n",a);
		for(int i=1;i<=a;i++)
			printf("%d %d\n",rand()%n+1,rand()%3);
		printf("%d\n",b);
		for(int i=1;i<=b;i++)
			printf("%d %d\n",rand()%n+1,rand()%2);
	}
	return 0;
}
