#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

typedef long long ll;
typedef pair<int,int> pr;
const int N=100009;
const int M=50009;

int n,m,l,np,mp;
vector<pr> a,b;
int vis[N];

inline void chkmax(int &a,int b){if(a<b)a=b;}
inline void chkmin(int &a,int b){if(a>b)a=b;}

int mina()
{
	a.clear();b.clear();l=0;

	n=read();np=0;mp=0;
	for(int i=1,p=0,v,ta;i<=n;i++)
	{
		v=read();l+=(ta=read());
		a.push_back(pr(v,ta));
		np=max(np,p+=(v*ta));
	}
	m=read();
	for(int i=1,p=0,w,tb;i<=m;i++)
	{
		w=read();tb=read();
		b.push_back(pr(w,tb));
		mp=max(mp,p+=(w*tb));
	}
	for(int i=-l;i<=l;i++)
		vis[i+M]=0;
	
	int posa=0,posb=0;
	int dira=0,dirb=0;
	int resa=0,resb=0;
	int topa=0,topb=0;
	int mx=-1e9,mn=1e9;
	vis[0+M]++;
	for(int i=1;i<=l;i++)
	{
		if(resa==0)
		{
			dira=a[topa].first;
			resa=a[topa].second;
			topa++;
		}
		if(resb==0)
		{
			dirb=b[topb].first;
			resb=b[topb].second;
			topb++;
		}

		posa+=dira;resa--;
		posb+=dirb;resb--;
		//printf("%d %d %d %d\n",posa,posb,(posa-posb)&1,(posa-posb-((posa-posb)&1))/2);
		vis[posa-posb+M]++;
		chkmax(mx,posa-posb);
		chkmin(mn,posa-posb);
	}

	int ans=0;
	for(int i=mn;i<=mx;i++)
		ans=max(ans,vis[i+M]);
	printf("%d\n",ans);
	return 0;
}

int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);

	for(int T=read();T;T--)
		mina();
	return 0;
}
