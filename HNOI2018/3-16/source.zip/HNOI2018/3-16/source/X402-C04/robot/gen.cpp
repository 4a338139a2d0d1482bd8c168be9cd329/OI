#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=1000;
const int M=10000;

inline int urand()
{
	return (long long)(rand()<<15|rand())&2147483647;
}

const int P=1e7;
int a[P];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand()*clock());

	freopen("robot.in","w",stdout);

	int t=10;
	printf("%d\n",t);
	while(t--)
	{
		int n=1000,m=1000;
		for(int i=1;i<=n;i++)
			a[i]=rand()%50+1;

		printf("%d\n",n);
		random_shuffle(a+1,a+n+1);
		for(int i=1;i<=n;i++)
			printf("%d %d\n",rand()%3-1,a[i]);

		printf("%d\n",m);
		random_shuffle(a+1,a+m+1);
		for(int i=1;i<=m;i++)
			printf("%d %d\n",rand()%3-1,a[i]);
	}
	return 0;
}
