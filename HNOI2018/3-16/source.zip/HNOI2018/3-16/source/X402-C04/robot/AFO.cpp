#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<ll,ll> pr;

void procstatus() 
{
	FILE* f=fopen("/proc/self/status","r");
	for(char c=fgetc(f);~c;c=fgetc(f))
		fprintf(stderr,"%c",c);
}

const ll N=2e18+9;
const ll M=1e18+5;

int n,m,rodd,reven;
vector<pr> a,b;
vector<ll> tim;

inline ll read()
{
	ll x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

inline void chkmax(ll &a,ll b){if(a<b)a=b;}
inline void chkmin(ll &a,ll b){if(a>b)a=b;}
inline ll maxx(ll a,ll b){return a>b?a:b;}
inline ll minn(ll a,ll b){return a<b?a:b;}

namespace segt
{
	const int P=2e7; 
	int t[P],tag[P],ls[P],rs[P],tot;ll muse;

	inline void init(){tot=rodd=reven=0;}
	inline int newnode()
	{
		int ret=++tot;
		t[ret]=ls[ret]=rs[ret]=tag[ret]=0;
		return ret;
	}

	inline void mark(int x,int v)
	{
		t[x]+=v;tag[x]+=v;
	}

	inline void push(int x)
	{
		if(tag[x])
		{
			if(!ls[x])ls[x]=newnode();
			if(!rs[x])rs[x]=newnode();
			mark(ls[x],tag[x]);
			mark(rs[x],tag[x]);
			tag[x]=0;
		}
	}

	inline void update(int x){t[x]=maxx(t[ls[x]],t[rs[x]]);}

	inline void modify(int &x,ll l,ll r,ll dl,ll dr,int v)
	{
		if(!x)x=newnode();
		if(dl==l && r==dr){mark(x,v);return;}
		ll mid=l+r>>1;push(x);
		if(dr<=mid)modify(ls[x],l,mid,dl,dr,v);
		else if(mid<dl)modify(rs[x],mid+1,r,dl,dr,v);
		else modify(ls[x],l,mid,dl,mid,v),modify(rs[x],mid+1,r,mid+1,dr,v);
		update(x);
	}
}

inline void modify(int ty,ll l,ll r,ll v)
{
	//printf("%d mod %lld %lld %lld\n",ty,(l-1)/2,(r-1)/2,v);
	if(l>r)return;
	if(ty)
		segt::modify(rodd,0,N,(l-1)/2+M,(r-1)/2+M,v);
	else
		segt::modify(reven,0,N,l/2+M,r/2+M,v);
}

int mina()
{
	a.clear();
	b.clear();
	tim.clear();

	n=read();
	ll ta=0,tb=0;
	for(int i=1,v;i<=n;i++)
	{
		v=read();
		a.push_back(pr(v,ta));
		tim.push_back(ta);
		ta+=read();
	}
	tim.push_back(ta);
	m=read();
	for(int i=1,w;i<=m;i++)
	{
		w=read();
		b.push_back(pr(w,tb));
		tim.push_back(tb);
		tb+=read();
	}

	sort(tim.begin(),tim.end());
	int top=unique(tim.begin(),tim.end())-tim.begin();
	
	segt::init();
	modify(0,0,0,1);

	int topa=0,topb=0;
	ll dira=0,dirb=0;
	ll posa=0,posb=0;
	for(int i=0;i<top;i++)
	{
	//	printf("tim %d\n",tim[i]);
		if(i)
		{
			ll nxta=dira*(tim[i]-tim[i-1])+posa;
			ll nxtb=dirb*(tim[i]-tim[i-1])+posb;
			posa+=dira,posb+=dirb;
			ll lb=minn(posa-posb,nxta-nxtb);
			ll rb=maxx(posa-posb,nxta-nxtb);
			if(dira==0 || dirb==0)
			{
				if(dira==0 && dirb==0)
					modify((posa-posb)&1,lb,rb,tim[i]-tim[i-1]);
				else
				{
	//				printf("get %lld %lld\n",lb,rb);
					if(!(lb==rb && lb&1))
						modify(0,(lb&1?lb+1:lb),(rb&1?rb-1:rb),1);
					if(!(lb==rb && !(lb&1)))
						modify(1,(lb&1?lb:lb+1),(rb&1?rb:rb-1),1);
				}
			}
			else
			{
				if(lb!=rb)
					modify((posa-posb)&1,lb,rb,1);
				else
					modify((posa-posb)&1,lb,rb,tim[i]-tim[i-1]);
			}
			posa=nxta;posb=nxtb;
	//		printf("pos %lld %lld\n",posa,posb);
		}
		if(a[topa].second==tim[i])
			dira=a[topa++].first;
		if(b[topb].second==tim[i])
			dirb=b[topb++].first;
	}

	printf("%lld\n",maxx(segt::t[rodd],segt::t[reven]));
	return 0;
}

int main()
{
	freopen("robot.in","r",stdin);
	freopen("robots.out","w",stdout);

	for(int T=read();T;T--)
		mina();
	return 0;
}
