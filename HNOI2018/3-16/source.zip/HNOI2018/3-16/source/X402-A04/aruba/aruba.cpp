#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
inline ll readl()
{
    char ch=getchar();int g=1;ll re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef pair<int,int> pii;

const int mod=998244353;
const int MAXH=200;
int c,K;
int f[MAXH+5][9][257];
int val[257],pw[10],crash[257][257],Ans[MAXH+5],tot=0;

int C[271][271];
void mul(int **A,int **B)
{
	for(int i=1;i<=tot;++i) for(int j=1;j<=tot;++j) C[i][j]=0;
	for(int i=1;i<=tot;++i) for(int j=1;j<=tot;++j) for(int k=1;k<=tot;++k)
		C[i][j]=(C[i][j]+1ll*A[i][k]*B[k][j])%mod;
	for(int i=1;i<=tot;++i) for(int j=1;j<=tot;++j) A[i][j]=C[i][j];
}

int mat[271][271],id[271][271],pwm[67][271][271];

ll ask[205];
void wj()
{
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
}
int main()
{
	wj();
	c=read(); K=read();
	if(c==1)
	{
		int Q=read();
		for(int i=1;i<=Q;++i) 
		{
			if(K>=4) puts("1");
			else puts("0");
		}
		return 0;
	}
	if(c==2&&K==0)
	{
		int Q=read();
		for(int i=1;i<=Q;++i)
		{
			ll h=readl();
			printf("%lld\n",2*h%mod);
		}
		return 0;
	}
	int Q=read(); ll maxh=0;
	for(int i=1;i<=Q;++i) ask[i]=readl(),maxh=max(maxh,ask[i]);
	pw[0]=1;
	for(int i=1;i<=4;++i) pw[i]=pw[i-1]*c;
	for(int s=0;s<pw[4];++s)
	{
		for(int i=0;i<4;++i) if(s/pw[i]%c==s/pw[(i+1)%4]%c) val[s]++;
	}
	for(int s1=0;s1<pw[4];++s1) for(int s2=0;s2<pw[4];++s2)
	{
		for(int i=0;i<4;++i) if(s1/pw[i]%c==s2/pw[i]%c) crash[s1][s2]++;
	}

	for(int s=0;s<pw[4];++s) if(val[s]<=K) f[1][val[s]][s]=1;
	if(maxh>200)
	{
		for(int j=0;j<=K;++j) for(int s=0;s<pw[4];++s) id[j][s]=++tot;
		++tot;
		for(int i=1;i<=tot;++i) mat[tot][i]=1;
		for(int j=0;j<=K;++j) for(int s=0;s<pw[4];++s)
		{
			if(j-val[s]<0) continue;
			for(int s0=0;s0<pw[4];++s0)
			{
				int x=j-val[s]-crash[s][s0];
				if(x>=0) 
					mat[id[j][s]][id[x][s0]]=1;
			}
		}
		for(int i=1;i<=tot;++i) for(int j=1;j<=tot;++j) pwm[0][i][j]=mat[i][j];
		/*for(int k=1;k<=63;++k)
		{
			for(int i=1;i<=tot;++i) for(int j=1;j<=tot;++j) 
				pwm[k][i][j]=pwm[k-1][i][j];
			mul(pwm[k],pwm[k-1]);
		}*/
		return 0;
	}

	for(int i=2;i<=MAXH;++i) for(int j=0;j<=K;++j) for(int s=0;s<pw[4];++s)
	{
		if(j-val[s]<0) continue;
		for(int s0=0;s0<pw[4];++s0)
		{
			int x=j-val[s]-crash[s][s0];
			if(x>=0) 
				f[i][j][s]=(f[i][j][s]+f[i-1][x][s0])%mod;
		}
	}
	for(int i=1;i<=MAXH;++i) 
	{
		Ans[i]=Ans[i-1];
		for(int j=0;j<=K;++j) for(int s=0;s<pw[4];++s)
			Ans[i]=(Ans[i]+f[i][j][s])%mod;
	}
	for(int i=1;i<=Q;++i) 
		printf("%d\n",Ans[ask[i]]);
	return 0;
}
