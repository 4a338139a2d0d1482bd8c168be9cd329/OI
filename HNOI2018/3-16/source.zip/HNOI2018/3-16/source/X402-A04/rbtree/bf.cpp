#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=35;
const int inf=0x3f3f3f3f;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int n,an,bn,dfn[N],efn[N],clk=0;
pii A[N],B[N];
void dfs(int u,int fa)
{
	dfn[u]=++clk;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,u);
	}
	efn[u]=clk;
}
int black[N],sum[N];

void wj()
{
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
}
int main()
{
	wj();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		n=read();
		cnt=0; clk=0;
		for(int i=1;i<=n;++i) head[i]=0;

		for(int i=1;i<n;++i)
		{
			int x=read(),y=read();
			add(x,y);
		}
		an=read();
		for(int i=1;i<=an;++i) A[i].fi=read(),A[i].se=read();
		bn=read();
		for(int i=1;i<=bn;++i) B[i].fi=read(),B[i].se=read();
		dfs(1,0);
		int tot=1<<n,ans=inf;
		for(int s=0;s<tot;++s)
		{
			for(int i=1;i<=n;++i)
				if(s&(1<<i-1)) black[i]=1;
				else black[i]=0;
			for(int i=1;i<=n;++i) sum[i]=sum[i-1]+black[i];
			bool can=1;
			for(int i=1;i<=an;++i)
			{
				int v=A[i].fi,s=A[i].se;
				if(sum[efn[v]]-sum[dfn[v]-1]<s) {can=0;break;}
			}
			if(!can) continue;
			for(int i=1;i<=bn;++i)
			{
				int v=B[i].fi,s=B[i].se;
				if(sum[n]-(sum[efn[v]]-sum[dfn[v]-1])<s) {can=0;break;}
			}
			if(!can) continue;
			ans=min(ans,__builtin_popcount(s));
		}
		printf("%d\n",ans==inf?-1:ans);
	}
	return 0;
}
