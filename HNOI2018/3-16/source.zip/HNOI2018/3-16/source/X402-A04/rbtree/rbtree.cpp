#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<deque>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int inf=0x3f3f3f3f;

int n;
namespace dsa
{
	int head[N],cnt=0;
	struct node
	{
		int to,next,w;
	}e[N*4];
	inline void add(int x,int y,int w)
	{
		e[++cnt]=(node){y,head[x],w};head[x]=cnt;
	}
	void init()
	{
		cnt=0;
		for(int i=0;i<=n;++i) head[i]=0;
	}
	bool vis[N];
	int dis[N],num[N];
	void clr()
	{
		for(int i=0;i<=n;++i) vis[i]=0,dis[i]=inf;
		dis[0]=0;
	}

	inline int dfs(int u)
	{
		vis[u]=1;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(dis[v]>dis[u]+e[i].w)
			{
				dis[v]=dis[u]+e[i].w;
				if(vis[v]) return 0;
				if(!dfs(v)) return 0;
			}
		}
		vis[u]=0;
		return 1;
	}
	/*deque<int>q;
	int dfs(int S)
	{
		q.push_back(0); dis[0]=0;
		while(!q.empty())
		{
			int u=q.front(); q.pop_front();
			vis[u]=0;
			for(int i=head[u];i;i=e[i].next)
			{
				int v=e[i].to;
				if(dis[v]>dis[u]+e[i].w)
				{
					dis[v]=dis[u]+e[i].w;
					if(!vis[v])
					{
						if(++num[v]>n) return 0;
						vis[v]=1;
						if(dis[v]<dis[q.front()]) q.push_front(v);
						else q.push_back(v);
					}
				}
			}
		}
		return 1;
	}*/
}

int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int dfn[N],efn[N],clk=0;
void dfs(int u,int fa)
{
	dfn[u]=++clk;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,u);
	}
	efn[u]=clk;
}

int an,bn,ds;
pii A[N],B[N];
int check(int sumn)
{
	dsa::init();
	for(int i=1;i<n;++i) dsa::add(i,i-1,0),dsa::add(i-1,i,1);
	dsa::add(0,n-1,sumn); dsa::add(n-1,0,1-sumn);
	for(int i=1;i<=an;++i)
	{
		int v=A[i].fi,s=A[i].se;
		if(efn[v]==n) dsa::add(0,dfn[v]-1,-s+sumn);
		else dsa::add(efn[v],dfn[v]-1,-s);
	}
	for(int i=1;i<=bn;++i)
	{
		int v=B[i].fi,s=B[i].se;
		if(efn[v]==n) dsa::add(dfn[v]-1,0,-s);
		else dsa::add(dfn[v]-1,efn[v],-s+sumn);
	}
	dsa::clr();
	return dsa::dfs(0);
}

void wj()
{
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		n=read();
		for(int i=1;i<=n;++i) head[i]=0;
		cnt=0; clk=0;

		for(int i=1;i<n;++i)
		{
			int x=read(),y=read();
			add(x,y);
		}
		dfs(1,0);

		an=read();
		for(int i=1;i<=an;++i)
		{
			int v=read(),s=read();
			A[i]=pii(v,s);
		}
		bn=read();
		for(int i=1;i<=bn;++i)
		{
			int v=read(),s=read();
			B[i]=pii(v,s);
		}
		int l=0,r=n;
		while(l<r)
		{
			int mid=l+r>>1;
			if(check(mid)) r=mid;
			else l=mid+1;
		}
		if(check(l)) printf("%d\n",l);
		else puts("-1");
	}
	//for(int i=0;i<=n;++i) printf("%d ",dsa::dis[i]);
	clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
