#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=200050;
int A[N],B[N],cnt[N*4];

void wj()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
}
int main()
{
	wj();
	int T=read();
	for(int cas=1;cas<=T;++cas)
	{
		int now=0,L=0;
		int n=read();
		for(int i=1;i<=n;++i)
		{
			int v=read(),a=read(); L+=a;
			for(int j=1;j<=a;++j) A[now+j]=v;
			now+=a;
		}
		now=0;
		int m=read();
		for(int i=1;i<=m;++i)
		{
			int w=read(),b=read();
			for(int j=1;j<=b;++j) B[now+j]=w;
			now+=b;
		}
		for(int i=1;i<=L;++i) A[i]+=A[i-1],B[i]+=B[i-1];
		/*int mm=-123123123;
		for(int i=0;i<=L;++i) mm=max(mm,A[i]-B[i]);
		cerr<<now<<' '<<mm<<' '<<L<<endl;*/
		for(int i=0;i<=L;++i) cnt[A[i]-B[i]+L*2]++;
		int ans=0;
		for(int i=0;i<=L;++i) ans=max(ans,cnt[A[i]-B[i]+L*2]);
		for(int i=0;i<=L;++i) cnt[A[i]-B[i]+L*2]=0;
		for(int i=0;i<=L;++i) A[i]=B[i]=0;
		printf("%d\n",ans);
	/*	if(cas==1)
		{
			for(int i=0;i<=L;++i) cerr<<A[i]<<' '; cerr<<endl;
			for(int i=0;i<=L;++i) cerr<<B[i]<<' '; cerr<<endl;
		}*/
	}
	return 0;
}
