#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}
const int mod=998244353;
typedef long long LL;

int c,k,q;

LL x;

int main()
{
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	read(c),read(k),read(q);
	if(c==1){
		for(int i=1;i<=q;i++){
			read(x);
			if(x>1) puts("0");
			else if(x==1&&k>=4) puts("1");
			else puts("0");
		}
	}
	for(int i=1;i<=q;i++){
		read(x);x%=mod;
		printf("%lld\n",2*x%mod);
	}
    return 0;
}
