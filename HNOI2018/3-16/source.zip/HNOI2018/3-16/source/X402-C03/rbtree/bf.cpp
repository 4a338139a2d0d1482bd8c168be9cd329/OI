#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+10;
int t,n,q,a[maxn],b[maxn],size[maxn],dfn,id[maxn],sum[maxn],ans;
vector<int> g[maxn];

void dfs1(int pos,int fa){
	size[pos]=1;
	id[pos]=++dfn;
	for(int i=0,v;i<g[pos].size();++i)
		if((v=g[pos][i])!=fa){
			dfs1(v,pos);
			size[pos]+=size[v];
		}
}
void dfs2(int pos,int tot){
	if(tot>=ans)
		return;
	if(pos>n){
		for(int i=1;i<=n;++i){
			int x=sum[id[i]+size[i]-1]-sum[id[i]-1];
			if(x<a[i])
				return;
			if((tot-x)<b[i])
				return;
		}
		ans=tot;
		return;
	}
	sum[pos]=sum[pos-1];
	dfs2(pos+1,tot);
	sum[pos]=sum[pos-1]+1;
	dfs2(pos+1,tot+1);
}

int main(){
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.txt","w",stdout);
	scanf("%d",&t);
	while(t--){
		ans=1e9;
		scanf("%d",&n);
		for(int i=1;i<=n;++i){
			g[i].clear();
			a[i]=b[i]=0;
		}
		for(int i=1,u,v;i<n;++i){
			scanf("%d%d",&u,&v);
			g[u].push_back(v);
			g[v].push_back(u);
		}
		dfn=0;
		dfs1(1,0);
		scanf("%d",&q);
		while(q--){
			int pos,val;
			scanf("%d%d",&pos,&val);
			a[pos]=val;
		}
		scanf("%d",&q);
		while(q--){
			int pos,val;
			scanf("%d%d",&pos,&val);
			b[pos]=val;
		}
		dfs2(1,0);
		printf("%d\n",ans==1e9?-1:ans);
	}
	return 0;
}
