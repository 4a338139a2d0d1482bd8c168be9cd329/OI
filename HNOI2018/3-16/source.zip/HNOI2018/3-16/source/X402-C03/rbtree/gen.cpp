#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
int f(int x,int y){
	return rand()%(y-x+1)+x;
}

int main(){
	init();
	freopen("rbtree.in","w",stdout);
	int t=10;
	printf("%d\n",t);
	while(t--){
		int n=f(1,20);
		printf("%d\n",n);
		for(int i=2;i<=n;++i)
			printf("%d %d\n",i,f(1,i-1));
		int a=f(0,n),b=f(0,n);
		if(f(0,1))
			b=0;
		set<int> s;
		while(a--)
			while(s.insert(f(1,n)).second==false);
		printf("%d\n",(int)s.size());
		for(set<int>::iterator i=s.begin();i!=s.end();++i)
			printf("%d %d\n",*i,f(0,f(0,f(0,n))));
		s.clear();
		while(b--)
			while(s.insert(f(1,n)).second==false);
		printf("%d\n",(int)s.size());
		for(set<int>::iterator i=s.begin();i!=s.end();++i)
			printf("%d %d\n",*i,f(0,f(0,f(0,n))));
	}
	return 0;
}
