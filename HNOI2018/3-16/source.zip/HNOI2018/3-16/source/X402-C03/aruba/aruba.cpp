#include<bits/stdc++.h>
using namespace std;

const int maxh=200+40,mod=998244353;
int c,cc,ccc,cccc,k,q;
long long h;
int dp[maxh][256][8],sum[maxh];

int calc(int x){
	return (x%c==x/c%c)+(x/c%c==x/cc%c)+(x/cc%c==x/ccc)+(x/ccc==x%c);
}
int calc(int x,int y){
	return (x%c==y%c)+(x/c%c==y/c%c)+(x/cc%c==y/cc%c)+(x/ccc==y/ccc);
}

int main(){
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	scanf("%d%d%d",&c,&k,&q);
	if(c==2&&k==0){
		while(q--){
			scanf("%lld",&h);
			printf("%lld\n",2*h%mod);
		}
		return 0;
	}
	if(c==1){
		while(q--){
			scanf("%lld",&h);
			puts(k>=4?"1":"0");
		}
		return 0;
	}
	cc=c*c;ccc=cc*c;cccc=ccc*c;
	for(int i=0;i<cccc;++i)
		dp[1][i][calc(i)]=1;
	for(int i=2;i<maxh;++i)
		for(int j=0;j<cccc;++j)
			for(int x=0;x<cccc;++x){
				int v=calc(j)+calc(x,j);
				for(int y=v;y<=k;++y)
					(dp[i][j][y]+=dp[i-1][x][y-v])%=mod;
			}
	for(int i=1;i<maxh;++i){
		sum[i]=sum[i-1];
		for(int j=0;j<cccc;++j)
			for(int x=0;x<=k;++x)
				(sum[i]+=dp[i][j][x])%=mod;
	}
	while(q--){
		scanf("%lld",&h);
		printf("%d\n",sum[h]);
	}
	return 0;
}
