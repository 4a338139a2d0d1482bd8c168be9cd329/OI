#include<bits/stdc++.h>

template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
typedef long long ll;

inline ll read(){
	ll x;bool o=0;char c;
	while(!isdigit(c=getchar()))if(c=='-')o=1;
	x=c-48;
	while(isdigit(c=getchar()))x=x*10+c-48;
	return o?-x:x;
}

const int maxn=1e5+10;
int t,n,m,v[maxn],w[maxn];
ll a[maxn],b[maxn];

namespace segtree{
	const int size=maxn*120;
	int cnt;
	int ls[size],rs[size],tago[size],tage[size];
	ll maxo[size],maxe[size];

	inline int newnode(){
		return ++cnt;
	}
	inline void push_up(int rt,bool type){
		if(type){
			maxo[rt]=max_(maxo[ls[rt]],maxo[rs[rt]]);
			maxe[rt]=max_(maxe[ls[rt]],maxe[rs[rt]]);
		}
		else{
			maxo[rt]=max_(maxo[ls[rt]],maxe[rs[rt]]);
			maxe[rt]=max_(maxe[ls[rt]],maxo[rs[rt]]);
		}
	}
	inline void push_down(int rt,ll lsize,ll rsize){
		if(!ls[rt])
			ls[rt]=newnode();
		if(!rs[rt])
			rs[rt]=newnode();
		if(tago[rt]){
			tago[ls[rt]]+=tago[rt];
			maxo[ls[rt]]+=tago[rt];
			if(lsize&1^1)
				tago[rs[rt]]+=tago[rt],maxo[rs[rt]]+=tago[rt];
			else if(rsize>1)
				tage[rs[rt]]+=tago[rt],maxe[rs[rt]]+=tago[rt];
			tago[rt]=0;
		}
		if(tage[rt]){
			if(lsize>1)
				tage[ls[rt]]+=tage[rt],maxe[ls[rt]]+=tage[rt];
			if(lsize&1)
				tago[rs[rt]]+=tage[rt],maxo[rs[rt]]+=tage[rt];
			else if(rsize>1)
				tage[rs[rt]]+=tage[rt],maxe[rs[rt]]+=tage[rt];
			tage[rt]=0;
		}
	}
	inline void build(){
		memset(ls+1,0,4*cnt);
		memset(rs+1,0,4*cnt);
		memset(tago+1,0,4*cnt);
		memset(tage+1,0,4*cnt);
		memset(maxo+1,0,8*cnt);
		memset(maxe+1,0,8*cnt);
		cnt=0;
		newnode();
	}
	void add0(int rt,ll l,ll r,ll pos,ll val){
		if(l==r){
			maxo[rt]+=val;
			return;
		}
		ll mid=l+r>>1;
		push_down(rt,mid-l+1,r-mid);
		if(pos<=mid){
			add0(ls[rt],l,mid,pos,val);
			if(maxo[ls[rt]]>maxo[rt])
				maxo[rt]=maxo[ls[rt]];
			if(maxe[ls[rt]]>maxe[rt])
				maxe[rt]=maxe[ls[rt]];
		}
		else{
			add0(rs[rt],mid+1,r,pos,val);
			if((l^mid)&1){
				if(maxo[rs[rt]]>maxo[rt])
					maxo[rt]=maxo[rs[rt]];
				if(maxe[rs[rt]]>maxe[rt])
					maxe[rt]=maxe[rs[rt]];
			}
			else{
				if(maxe[rs[rt]]>maxo[rt])
					maxo[rt]=maxe[rs[rt]];
				if(maxo[rs[rt]]>maxe[rt])
					maxe[rt]=maxo[rs[rt]];
			}
		}
	}
	inline void add0(ll pos,ll val){
		add0(1,-2e18,2e18,pos,val);
	}
	void add1(int rt,ll l,ll r,ll x,ll y){
		if(l==x&&r==y){
			++maxo[rt],++tago[rt];
			if(l<r)
				++maxe[rt],++tage[rt];
			return;
		}
		ll mid=l+r>>1;
		push_down(rt,mid-l+1,r-mid);
		if(y<=mid){
			add1(ls[rt],l,mid,x,y);
			if(maxo[ls[rt]]>maxo[rt])
				maxo[rt]=maxo[ls[rt]];
			if(maxe[ls[rt]]>maxe[rt])
				maxe[rt]=maxe[ls[rt]];
		}
		else if(x>mid){
			add1(rs[rt],mid+1,r,x,y);
			if((l^mid)&1){
				if(maxo[rs[rt]]>maxo[rt])
					maxo[rt]=maxo[rs[rt]];
				if(maxe[rs[rt]]>maxe[rt])
					maxe[rt]=maxe[rs[rt]];
			}
			else{
				if(maxe[rs[rt]]>maxo[rt])
					maxo[rt]=maxe[rs[rt]];
				if(maxo[rs[rt]]>maxe[rt])
					maxe[rt]=maxo[rs[rt]];
			}
		}
		else{
			add1(ls[rt],l,mid,x,mid);
			add1(rs[rt],mid+1,r,mid+1,y);
			push_up(rt,(l^mid)&1);
		}
	}
	inline void add1(ll x,ll y){
		add1(1,-2e18,2e18,x,y);
	}
	void add2(int rt,ll l,ll r,ll x,ll y,bool odd){
		if(l==x&&r==y){
			if(odd)
				++maxo[rt],++tago[rt];
			else if(l<r)
				++maxe[rt],++tage[rt];
			return;
		}
		ll mid=l+r>>1;
		push_down(rt,mid-l+1,r-mid);
		if(y<=mid){
			add2(ls[rt],l,mid,x,y,odd);
			if(maxo[ls[rt]]>maxo[rt])
				maxo[rt]=maxo[ls[rt]];
			if(maxe[ls[rt]]>maxe[rt])
				maxe[rt]=maxe[ls[rt]];
		}
		else if(x>mid){
			add2(rs[rt],mid+1,r,x,y,odd^(mid^l^1)&1);
			if((l^mid)&1){
				if(maxo[rs[rt]]>maxo[rt])
					maxo[rt]=maxo[rs[rt]];
				if(maxe[rs[rt]]>maxe[rt])
					maxe[rt]=maxe[rs[rt]];
			}
			else{
				if(maxe[rs[rt]]>maxo[rt])
					maxo[rt]=maxe[rs[rt]];
				if(maxo[rs[rt]]>maxe[rt])
					maxe[rt]=maxo[rs[rt]];
			}
		}
		else{
			add2(ls[rt],l,mid,x,mid,odd);
			add2(rs[rt],mid+1,r,mid+1,y,odd^(mid^l^1)&1);
			push_up(rt,(l^mid)&1);
		}
	}
	inline void add2(ll x,ll y){
		add2(1,-2e18,2e18,x,y,x&1^1);
	}
	inline ll query(){
		return max_(maxo[1],maxe[1]);
	}
}

int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.txt","w",stdout);
	t=read();
	while(t--){
		n=read();
		for(int i=1;i<=n;++i)
			v[i]=read(),a[i]=read();
		m=read();
		for(int i=1;i<=m;++i)
			w[i]=read(),b[i]=read();
		segtree::build();
		ll pos=0;
		segtree::add0(pos,1);
		for(int p=1,q=1;p<=n;){
			ll cnt=min_(a[p],b[q]);
			int delta=v[p]-w[q];
			switch(delta){
				case -2:
					segtree::add2(pos-2*cnt,pos-2);
					break;
				case -1:
					segtree::add1(pos-cnt,pos-1);
					break;
				case 0:
					segtree::add0(pos,cnt);
					break;
				case 1:
					segtree::add1(pos+1,pos+cnt);
					break;
				case 2:
					segtree::add2(pos+2,pos+2*cnt);
					break;
			}
			pos+=delta*cnt;
			a[p]-=cnt;
			if(!a[p])++p;
			b[q]-=cnt;
			if(!b[q])++q;
		}
		printf("%lld\n",segtree::query());
	}
//FILE*f=fopen("/proc/self/status","r");char c;while(c=fgetc(f),~c)std::cerr<<c;
	return 0;
}
