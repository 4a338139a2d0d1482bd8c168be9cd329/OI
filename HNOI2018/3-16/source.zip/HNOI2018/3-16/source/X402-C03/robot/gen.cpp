#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE*f;int seed;
	f=fopen("seed","r");
	if(f==NULL)
		seed=time(NULL);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	srand(seed);
	f=fopen("seed","w");
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}
typedef long long ll;
ll f(ll x,ll y){
	return ((ll)rand()<<31|rand())%(y-x+1)+x;
}

int main(){
	init();
	freopen("robot.in","w",stdout);
	int t=10,n=5e3;ll len=2e5;
	n=1e4;len=1e18;
//	n=10;len=20;
	printf("%d\n",t);
	while(t--){
		int nn=f(1,n),mm=f(1,n);
	//	nn=mm=n;
		printf("%d\n",nn);
		for(ll i=1,x=len;i<=nn;++i){
			ll a=f(1,2*x/(nn-i+1));
			if(i==nn)a=x;
			else if(a>x+i-nn)a=x+i-nn;
			printf("%lld %lld\n",f(-1,1),a);
			x-=a;
		}
		printf("%d\n",mm);
		for(ll i=1,x=len;i<=mm;++i){
			ll a=f(1,2*len/(mm-i+1));
			if(i==mm)a=x;
			else if(a>x+i-mm)a=x+i-mm;
			printf("%lld %lld\n",f(-1,1),a);
			x-=a;
		}
	}
	return 0;
}
