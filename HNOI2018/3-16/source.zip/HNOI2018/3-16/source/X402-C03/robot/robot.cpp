#include<bits/stdc++.h>

template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}
typedef long long ll;

inline ll read(){
	ll x;bool o=0;char c;
	while(!isdigit(c=getchar()))if(c=='-')o=1;
	x=c-48;
	while(isdigit(c=getchar()))x=x*10+c-48;
	return o?-x:x;
}

const int maxn=1e5+10;
int t,n,m,v[maxn],w[maxn];
ll a[maxn],b[maxn],c[maxn],d[maxn];

namespace plan{
	int cnt;
	ll place[maxn<<2];
	ll tag1[maxn<<2],tago[maxn<<2],tage[maxn<<2];
	
	inline void init(){
		memset(tag1,0,8*cnt);
		memset(tago,0,8*cnt);
		memset(tage,0,8*cnt);
		cnt=0;
		place[cnt++]=3e18;
	}
	inline void insert(ll pos){
		place[cnt++]=pos;
	}
	inline void getplace(){
		std::sort(place,place+cnt);
		cnt=std::unique(place,place+cnt)-place;
	}
	inline int getid(ll pos){
		return std::lower_bound(place,place+cnt,pos)-place;
	}
	inline void add0(ll pos,ll val){
		tag1[getid(pos)]+=val;
	}
	inline void add1(ll x,ll y){
		x=getid(x);y=getid(y);
		++tago[x];--tago[y];
		++tage[x];--tage[y];
	}
	inline void add2(ll x,ll y){
		bool fuck=x&1;
		x=getid(x);y=getid(y);
		if(fuck)
			++tago[x],--tago[y];
		else
			++tage[x],--tage[y];
	}
	inline ll query(){
		ll res=0;
		for(int i=0;i+1<cnt;++i){
			if(i)
				tago[i]+=tago[i-1],tage[i]+=tage[i-1];
			if(place[i]&1){
				chkmax(res,tag1[i]+tago[i]);
				if(place[i]+1<place[i+1])
					chkmax(res,tage[i]);
			}
			else{
				chkmax(res,tag1[i]+tage[i]);
				if(place[i]+1<place[i+1])
					chkmax(res,tago[i]);
			}
		}
		return res;
	}
}

int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	t=read();
	while(t--){
		n=read();
		for(int i=1;i<=n;++i)
			v[i]=read(),a[i]=c[i]=read();
		m=read();
		for(int i=1;i<=m;++i)
			w[i]=read(),b[i]=d[i]=read();
		plan::init();
		ll pos=0;
		plan::insert(pos);
		for(int p=1,q=1;p<=n;){
			ll cnt=min_(a[p],b[q]);
			int delta=v[p]-w[q];
			switch(delta){
				case -2:
					plan::insert(pos-2*cnt);
					plan::insert(pos);
					break;
				case -1:
					plan::insert(pos-cnt);
					plan::insert(pos);
					break;
				case 0:
					plan::insert(pos);
					break;
				case 1:
					plan::insert(pos+1);
					plan::insert(pos+cnt+1);
					break;
				case 2:
					plan::insert(pos+2);
					plan::insert(pos+2*cnt+2);
					break;
			}
			pos+=delta*cnt;
			a[p]-=cnt;
			if(!a[p])++p;
			b[q]-=cnt;
			if(!b[q])++q;
		}
		plan::getplace();
		pos=0;
		plan::add0(pos,1);
		for(int p=1,q=1;p<=n;){
			ll cnt=min_(c[p],d[q]);
			int delta=v[p]-w[q];
			switch(delta){
				case -2:
					plan::add2(pos-2*cnt,pos);
					break;
				case -1:
					plan::add1(pos-cnt,pos);
					break;
				case 0:
					plan::add0(pos,cnt);
					break;
				case 1:
					plan::add1(pos+1,pos+cnt+1);
					break;
				case 2:
					plan::add2(pos+2,pos+2*cnt+2);
					break;
			}
			pos+=delta*cnt;
			c[p]-=cnt;
			if(!c[p])++p;
			d[q]-=cnt;
			if(!d[q])++q;
		}
		printf("%lld\n",plan::query());
	}
	return 0;
}
