//2018-3-16
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (200000 + 5)

int OP; char chr;
inline void Read(int &x){
	chr = getchar(); OP = 1;
	while(chr < '0' || chr > '9'){
		if(chr == '-') OP = -1; chr = getchar();
	}
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
	x *= OP;
}

int a[N], v[N], b[N], w[N];
int pa[N], pb[N];
map<int, int> ms;

int main(){
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);
	
	int T, n, m, cnt;
	Read(T);

	while(T --){
		Read(n); cnt = 0;
		For(i, 1, n){
			Read(v[i]), Read(a[i]);
			
			For(j, cnt + 1, cnt + a[i]) pa[j] = pa[j - 1] + v[i];
			cnt += a[i];
		}

		Read(m); cnt = 0;
		For(i, 1, m){
			Read(w[i]), Read(b[i]);
			
			For(j, cnt + 1, cnt + b[i]) pb[j] = pb[j - 1] + w[i];
			cnt += b[i];
		}

		int ans = 0;

		ms.clear();
		For(i, 0, cnt){
			int now = pa[i] - pb[i];
			if(!ms.count(now)) ms[now] = 1;
			else ms[now] += 1;

			ans = max(ans, ms[now]);
		}
		printf("%d\n", ans);
	}

	return 0;
}
