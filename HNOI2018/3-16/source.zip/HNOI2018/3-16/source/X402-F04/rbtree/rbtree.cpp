//2018-3-16
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)
const int oo = 0x3f3f3f3f;

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x << 1) + (x << 3) + (chr ^ '0');
		chr = getchar();
	}
}

int n, m, fl[N], fr[N], a[N], b[N], cl[N], cr[N], siz[N];
vector<int> G[N];

void Init(){
	For(i, 1, n){
		a[i] = b[i] = 0;
		G[i].clear();
	}
}

#define v G[now][i]
bool Dfs(int now, int F){
	fl[now] = fr[now] = 0; siz[now] = 1;
	For(i, 0, G[now].size() - 1) if(v != F){
		if(!Dfs(v, now)) return false;
		fl[now] += fl[v]; fr[now] += fr[v];
		siz[now] += siz[v];
	}

	fl[now] = max(fl[now], max(cl[now], m - (n - siz[now])));
	fr[now] = min(fr[now] + 1, min(siz[now], cr[now]));
	
	if(fl[now] > siz[now] || fl[now] > fr[now]) return false;

	return true;
}
#undef v

bool Check(int all){
	m = all;
	For(i, 1, n) cl[i] = a[i], cr[i] = m - b[i];
	return Dfs(1, 0);
}

int Solve(){
	int L = 0, R = n, mid;
	if(!Check(n)) return -1;
	
	while(L < R){
		mid = (L + R) >> 1;

		if(Check(mid)) R = mid;
		else L = mid + 1;
	}
	return L;
}

int main(){
	freopen("rbtree.in", "r", stdin);
	freopen("rbtree.out", "w", stdout);
	
	int T, u, v, an, bn;
	Read(T);

	while(T --){
		Read(n); Init();
		For(i, 1, n - 1){
			Read(u), Read(v);
			G[u].pb(v); G[v].pb(u);
		}

		Read(an);
		For(i, 1, an){
			Read(u), Read(v);
			a[u] = v;
		}
		Read(bn);
		For(i, 1, bn){
			Read(u), Read(v);
			b[u] = v;
		}

		printf("%d\n", Solve());
	}

	return 0;
}
