//2018-3-16
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)

int n, m, a[N], b[N], f[N], col[N];
vector<int> G[N];

void Init(){
	For(i, 1, n){
		a[i] = b[i] = 0;
		G[i].clear();
	}
}

#define v G[now][i]
bool Dfs(int now, int F){
	f[now] = col[now];
	For(i, 0, G[now].size() - 1) if(v != F){
		if(!Dfs(v, now)) return false;
		f[now] += f[v];
	}

	if(f[now] < a[now] || (m - f[now]) < b[now]) return false;
	return true;
}
#undef v

int main(){
	freopen("rbtree.in", "r", stdin);
	freopen("rbtree2.out", "w", stdout);

	int T, u, v, an, bn;
	scanf("%d", &T);

	while(T --){
		scanf("%d", &n); Init();
		
		For(i, 1, n - 1){
			scanf("%d%d", &u, &v);
			G[u].pb(v); G[v].pb(u);
		}

		scanf("%d", &an);
		For(i, 1, an){
			scanf("%d%d", &u, &v);
			a[u] = v;
		}
		scanf("%d", &bn);
		For(i, 1, bn){
			scanf("%d%d", &u, &v);
			b[u] = v;
		}

		int ans = n + 1;
		For(i, 0, (1 << n) - 1){
			m = 0;
			For(j, 1, n) col[j] = (i & (1 << (j - 1)))? 1: 0, m += col[j];
			if(Dfs(1, 0)) ans = min(ans, m);
		}
		printf("%d\n", ans > n? -1: ans);
	}

	return 0;
}
