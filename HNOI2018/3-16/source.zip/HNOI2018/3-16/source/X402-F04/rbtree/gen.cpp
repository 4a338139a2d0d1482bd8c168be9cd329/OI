//2018-3-16
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (100000 + 5)

int id[N];

int main(){
	freopen("rbtree.in", "w", stdout);

	srand(time(NULL));
	int n, an, bn, T = 10;

	printf("%d\n", T);
	while(T --){
		n = rand() % 17 + 2;
		
		printf("%d\n", n);
		For(i, 1, n) id[i] = i;
		For(i, 1, n * 2) swap(id[rand() % n + 1], id[rand() % n + 1]);
		For(i, 2, n) printf("%d %d\n", id[i], id[rand() % (i - 1) + 1]);
		
		if(n > 2) an = rand() % (n/3) + 1, bn = rand() % (n/3) + 1;
		else an = rand() % 2, bn = rand() % 2;

		printf("%d\n", an);
		For(i, 1, an) swap(id[rand() % n + 1], id[rand() % n + 1]);
		For(i, 1, an){
			if(rand() % 10) printf("%d %d\n", id[i], rand() % (n/2) + 1);
			else printf("%d %d\n", id[i], rand() % n + 1);
		}

		printf("%d\n", bn);
		For(i, 1, bn) swap(id[rand() % n + 1], id[rand() % n + 1]);
		For(i, 1, bn){
			if(rand() % 10) printf("%d %d\n", id[i], rand() % (n/2) + 1);
			else printf("%d %d\n", id[i], rand() % n + 1);
		}
	}

	return 0;
}
