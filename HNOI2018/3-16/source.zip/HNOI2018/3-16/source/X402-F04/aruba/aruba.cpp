//2018-3-16
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (200 + 5)
const int P = 998244353;

int cn, m, Q, zt[4][4], f[N][4], sum[N];

void Init(int n){
	if(cn == 2) zt[3][3] = 1;
	else if(cn == 3){
		zt[1][1] = 2; zt[1][2] = 2; zt[1][3] = 2;
		zt[2][1] = 2; zt[2][2] = 2; zt[2][3] = 2;
		zt[3][1] = 4; zt[3][2] = 4; zt[3][3] = 3;
	}
	
	f[1][0] = 0; f[1][1] = f[1][2] = 6; f[1][3] = 6;
	For(i, 2, n) For(j, 0, 3){
		For(k, 0, 3){
			f[i][j] += (long long)zt[k][j] * f[i - 1][k] % P;
			if(f[i][j] >= P) f[i][j] -= P;
		}
	}

	For(i, 1, n){
		sum[i] = sum[i - 1];
		For(j, 0, 3){
			sum[i] += f[i][j]; if(sum[i] >= P) sum[i] -= P;
		}
	}
}

int main(){
	freopen("aruba.in", "r", stdin);
	freopen("aruba.out", "w", stdout);
	
	scanf("%d%d%d", &cn, &m, &Q);
	if(cn == 2 && !m){
		while(Q--){
			int rt; scanf("%d", &rt);
			printf("%lld\n", 2ll * rt % P);
		}
		return 0;
	}

	Init(200);
	while(Q --){
		int rt; scanf("%d", &rt);
		printf("%d\n", sum[rt]);
	}

	return 0;
}
