#include<bits/stdc++.h>

using namespace std;

string procStatus()
{
    ifstream t("/proc/self/status");
    return string(istreambuf_iterator<char>(t), istreambuf_iterator<char>());
}

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;

const int maxn=1e5+10;
const LL lim=2e18;

int n,m;

struct data{
    int v;
    LL t;
} a[maxn],b[maxn];

namespace SGT{
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    struct node{
        int ls,rs;
        LL w[2],tag[2];

        node():ls(0),rs(0){
            w[0]=w[1]=0;
            tag[0]=tag[1]=0;
        }
    } T[maxn*125];

    int rt,cur;

    void init(){ rt=cur=0; }

    int New(){
        T[++cur]=node();
        return cur;
    }

    void pushdown(int h){
        if(!T[h].ls) T[h].ls=New();
        if(!T[h].rs) T[h].rs=New();
        if(T[h].tag[0]){
            T[T[h].ls].w[0]+=T[h].tag[0];
            T[T[h].rs].w[0]+=T[h].tag[0];
            T[T[h].ls].tag[0]+=T[h].tag[0];
            T[T[h].rs].tag[0]+=T[h].tag[0];
            T[h].tag[0]=0;
        }
        if(T[h].tag[1]){
            T[T[h].ls].w[1]+=T[h].tag[1];
            T[T[h].rs].w[1]+=T[h].tag[1];
            T[T[h].ls].tag[1]+=T[h].tag[1];
            T[T[h].rs].tag[1]+=T[h].tag[1];
            T[h].tag[1]=0;
        }
    }

    void pushup(int h){
        T[h].w[0]=max(T[T[h].ls].w[0],T[T[h].rs].w[0]);
        T[h].w[1]=max(T[T[h].ls].w[1],T[T[h].rs].w[1]);
    }

    void modify(int& h,LL l,LL r,LL p,LL x){
        if(!h) h=New();
        if(l==r) return void(T[h].w[p&1]+=x);
        pushdown(h);
        if(p<=mid) modify(T[h].ls,lc,p,x);
        else modify(T[h].rs,rc,p,x);
        pushup(h);
    }

    void update(int& h,LL l,LL r,LL L,LL R,int op){
        if(!h) h=New();
        if(L<=l&&r<=R){
            if(op!=1) T[h].w[0]++,T[h].tag[0]++;
            if(op!=0) T[h].w[1]++,T[h].tag[1]++;
            return;
        }
        pushdown(h);
        if(L<=mid) update(T[h].ls,lc,L,R,op);
        if(R>mid) update(T[h].rs,rc,L,R,op);
        pushup(h);
    }
}

using namespace SGT;

int main(){
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);

    int _; read(_);
    while(_--){
        a[0].t=b[0].t=0;

        read(n);
        for(int i=1;i<=n;i++) read(a[i].v),read(a[i].t)+=a[i-1].t;
        a[n+1].t=LLONG_MAX;
        read(m);
        for(int i=1;i<=m;i++) read(b[i].v),read(b[i].t)+=b[i-1].t;
        b[m+1].t=LLONG_MAX;

        init();
        modify(rt,-lim,lim,0,1);

        int cura=1,curb=1;
        LL pa=0,pb=0,p=1;

        while(p<=a[n].t){
            pa+=a[cura].v; pb+=b[curb].v;
            LL ed=min(a[cura].t,b[curb].t);
            LL pos=pa-pb;
            int v=a[cura].v-b[curb].v;

            if(abs(v)==0) modify(rt,-lim,lim,pos,ed-p+1);

            else if(abs(v)==1){
                LL L=pos,R=pos+(ed-p)*v;
                if(L>R) swap(L,R);
                update(rt,-lim,lim,L,R,2);
            }

            else{
                LL L=pos,R=pos+(ed-p)*v;
                if(L>R) swap(L,R);
                update(rt,-lim,lim,L,R,abs(pos)&1);
            }

            pa+=(ed-p)*a[cura].v;
            pb+=(ed-p)*b[curb].v;
            if(a[cura].t==ed) ++cura;
            if(b[curb].t==ed) ++curb;
            p=ed+1;
        }

        printf("%lld\n",max(T[rt].w[0],T[rt].w[1]));
    }

    return 0;
}
