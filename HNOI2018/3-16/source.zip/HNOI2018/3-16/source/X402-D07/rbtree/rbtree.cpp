#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxn=100010,INF=0x3f3f3f3f;

int n,m;
int a[maxn],b[maxn],lim[maxn][2];
int f[maxn][2];

int head[maxn],nxt[maxn<<1],to[maxn<<1],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}

void init(){
    for(int i=1;i<=n;i++) a[i]=b[i]=-1;
    for(int i=1;i<=n;i++) head[i]=0;
    e=0;
}

void DP_init(int t){
    for(int i=1;i<=n;i++){
        lim[i][0]=(~a[i])?a[i]:0;
        lim[i][1]=(~b[i])?t-b[i]:INF;
    }
}

bool DP(int u,int fa){
    int l=0,r=0;
    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(v==fa) continue;
        if(!DP(v,u)) return 0;
        l+=f[v][0]; r+=f[v][1];
    }
    chkmax(l,lim[u][0]);
    r++; chkmin(r,lim[u][1]);
    f[u][0]=l; f[u][1]=r;
    return l<=r;
}

int main(){
    freopen("rbtree.in","r",stdin);
    freopen("rbtree.out","w",stdout);

    int _; read(_);
    while(_--){
        read(n);
        init();
        for(int i=1;i<n;i++){
            int u,v;
            read(u); read(v);
            ae(u,v); ae(v,u);
        }

        read(m);
        for(int i=1;i<=m;i++){
            int r,s;
            a[read(r)]=read(s);
        }

        read(m);
        for(int i=1;i<=m;i++){
            int r,s;
            b[read(r)]=read(s);
        }

        int L=0,R=n+1;
        while(L<R){
            int mid=(L+R)>>1;
            DP_init(mid);
            if(DP(1,0)&&f[1][0]<=mid&&f[1][1]>=mid) R=mid;
            else L=mid+1;
        }

        printf("%d\n",L==n+1?-1:L);
    }

    return 0;
}
