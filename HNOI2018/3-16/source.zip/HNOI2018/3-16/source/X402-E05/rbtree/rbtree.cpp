#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
}
int T,n,A,B,sz[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
struct node
{
	int r,s;
	node(){}
	node(int r,int s):r(r),s(s){}
}a[N],b[N];
namespace BF
{
int sum[N],vis[N],ans;
inline void dfs(int u,int f)
{
	sum[u]=vis[u];
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
		sum[u]+=sum[v];
	}
}
inline bool check(int cnt)
{
	For(i,1,n)sum[i]=0;
	dfs(1,0);
	For(i,1,A)if(sum[a[i].r]<a[i].s)return 0;
	For(i,1,B)if(cnt-sum[a[i].r]<a[i].s)return 0;
	return 1;
}
inline void dfs_bf(int u,int cnt)
{
	if(cnt>=ans)return;
	if(u==n+1){if(check(cnt))chkmin(ans,cnt);return;}
	vis[u]=1;dfs_bf(u+1,cnt+1);
	vis[u]=0;dfs_bf(u+1,cnt);
}
inline void Solve()
{
	ans=n;
	dfs_bf(1,0);
	printf("%d\n",ans);
}
}
namespace Situ
{
	int dp[N];
	inline void dfs(int u,int f)
	{
		int x=0;
		for(int v,i=bgn[u];i;i=nxt[i])
		{
			if((v=to[i])==f)continue;
			dfs(v,u);x+=dp[v];
		}
		chkmax(dp[u],x);
	}
	inline void Solve()
	{
		mem(dp,0);
		For(i,1,A)dp[a[i].r]=a[i].s;
		dfs(1,0);
		printf("%d\n",dp[1]);
	}
}
namespace Cheat
{
	int f[N],g[N],tot,flag;
	inline void dfs(int u,int fa)
	{
		int x=0;
		for(int v,i=bgn[u];i;i=nxt[i])
		{
			if((v=to[i])==fa)continue;
			dfs(v,u);
			x+=f[v];
		}
		chkmax(f[u],x);
		if(tot-f[u]<g[u])flag=0;
	}
	inline bool check(int x)
	{
		tot=x;flag=1;
		For(i,1,n)f[i]=g[i]=0;
		For(i,1,A)f[a[i].r]=a[i].s;
		For(i,1,B)g[b[i].r]=b[i].s;
		dfs(1,0);
		return flag;
	}
	inline void Solve()
	{
		int l=1,r=n,ans=0;
		while(l<=r)
		{
			int mid=(l+r)>>1;
			if(check(mid))ans=mid,r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",ans);
	}
}
inline void init(){mem(bgn,0);E=0;}
inline void dfs(int u,int f)
{
	sz[u]=1;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
		sz[u]+=sz[v];
	}
}
inline bool Impossible()
{
	For(i,1,A)if(sz[a[i].r]<a[i].s)return 1;
	For(i,1,B)if(n-sz[b[i].r]<b[i].s)return 1;
	return 0;
}
int main()
{
	int x,y;
	file();
	read(T);
	while(T--)
	{
		read(n);
		init();
		For(i,2,n)
		{
			read(x),read(y);
			add_edge(x,y),add_edge(y,x);
		}
		read(A);For(i,1,A)read(x),read(y),a[i]=node(x,y);
		read(B);For(i,1,B)read(x),read(y),b[i]=node(x,y);
		dfs(1,0);
		if(Impossible()){puts("-1");continue;}
		if(n<=17)BF::Solve();
		else if(B==0)Situ::Solve();
		else Cheat::Solve();
	}
	return 0;
}
