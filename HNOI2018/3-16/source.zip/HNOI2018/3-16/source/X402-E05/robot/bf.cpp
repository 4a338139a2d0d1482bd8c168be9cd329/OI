#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int M=1000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("robot.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int T,n,m,p[M];
LL L;
struct node
{
	int v,x;
	node(){}
	node(int v,int x):v(v),x(x){}
}a[N],b[N];
int main()
{
	int x,y;
	file();
	read(T);
	while(T--)
	{
		mem(p,0);L=0;
		read(n);For(i,1,n)read(x),read(y),a[i]=node(x,y),L+=y;
		read(m);For(i,1,m)read(x),read(y),b[i]=node(x,y);
		int nowA=1,nowB=1,posx=0,posy=0;
		For(i,0,L)
		{
			p[posx-posy+L*2]++;
			if(!a[nowA].x)nowA++;
			if(!b[nowB].x)nowB++;
			a[nowA].x--,posx+=a[nowA].v;
			b[nowB].x--,posy+=b[nowB].v;
		}
		int ans=0;
		For(i,0,L*4)chkmax(ans,p[i]);
		printf("%d\n",ans);
	}
	return 0;
}
