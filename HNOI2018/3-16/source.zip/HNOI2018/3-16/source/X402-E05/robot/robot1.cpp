#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ALL -(L<<2ll),(L<<2ll),rt
#define ls l,mid
#define rs mid+1,r
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=200010;
const int M=10000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
}
int T,n,m;
LL L,da[M],tot;
struct node
{
	LL v,x;
	node(){}
	node(LL v,LL x):v(v),x(x){}
}a[N],b[N];
namespace PT
{
int cnt,rt,lc[M],rc[M];
LL Max[M][2],Add[M][2];
inline void init()
{
	rt=0;
	For(i,0,cnt)
	{
		lc[i]=rc[i]=0;
		Max[i][0]=Max[i][1]=0;
		Add[i][0]=Add[i][1]=0;
	}
	cnt=0;
}
inline void pushup(int p)
{
	Max[p][0]=max(Max[lc[p]][0]+Add[lc[p]][0],Max[rc[p]][0]+Add[rc[p]][0]);
	Max[p][1]=max(Max[lc[p]][1]+Add[lc[p]][1],Max[rc[p]][1]+Add[rc[p]][1]);
}
inline void Add_tree(LL l,LL r,int &p,LL x,LL y,LL z,int f)
{
	if(!p)p=++cnt;
	if(x<=l&&r<=y){Add[p][f]+=z;return;}
	LL mid=(l+r)>>1ll;
	if(x<=mid)Add_tree(ls,lc[p],x,y,z,f);
	if(y> mid)Add_tree(rs,rc[p],x,y,z,f);
	pushup(p);
}
}
using namespace PT;
int main()
{
	LL x,y;
	file();
	read(T);
	while(T--)
	{
		PT::init();
		L=0;
		read(n);
		tot=0;
		For(i,1,n)
		{
			read(x),read(y);
			a[i]=node(x,y);
			a[i].x+=a[i-1].x;
			da[++tot]=a[i].x;
		}
		L=a[n].x;
		read(m);
		For(i,1,m)
		{
			read(x),read(y);
			b[i]=node(x,y);
			b[i].x+=b[i-1].x;
			da[++tot]=b[i].x;
		}
		sort(da+1,da+tot+1);
		tot=unique(da+1,da+tot+1)-da-1;
		LL posx=0,posy=0,nowA=1,nowB=1;
		For(i,1,tot)
		{
			LL l=posx-posy,r=posx-posy+(da[i]-da[i-1]-1)*(a[nowA].v-b[nowB].v);
			if(l>r)swap(l,r);
			if(a[nowA].v==b[nowB].v)Add_tree(ALL,l,r,da[i]-da[i-1],l&1);
			else if(a[nowA].v*b[nowB].v==-1)Add_tree(ALL,l,r,1,l&1);
			else if(l==r)Add_tree(ALL,l,r,1,l&1);
			else Add_tree(ALL,l,r,1,0),Add_tree(ALL,l,r,1,1);
			posx+=(da[i]-da[i-1])*a[nowA].v;
			posy+=(da[i]-da[i-1])*b[nowB].v;
			if(da[i]>=a[nowA].x)nowA++;
			if(da[i]>=b[nowB].x)nowB++;
		}
		Add_tree(ALL,posx-posy,posx-posy,1,(posx-posy)&1);
		printf("%lld\n",max(Max[rt][0]+Add[rt][0],Max[rt][1]+Add[rt][1]));
		//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	}
	//cerr<<((sizeof(lc)+sizeof(rc)+sizeof(Add)+sizeof(Max))>>20ll)<<endl;
	return 0;
}
