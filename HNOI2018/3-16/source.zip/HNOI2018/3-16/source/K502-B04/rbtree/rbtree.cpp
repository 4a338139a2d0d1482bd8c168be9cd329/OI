#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int N=1e5+5;
struct node{
	int nxt,to;
}e[N*2];
int head[N],cnt;
void init(int u,int v){
	e[++cnt].to=v;
	e[cnt].nxt=head[u];
	head[u]=cnt;	
}
int a[N],b[N],sa,sb,n,ans;
int sz[N],f[N],g[N],p[N];
int flag;
void dfs1(int x,int fa){
	if (!flag) return;
	f[x]=a[x];
	sz[x]=1;
	int res=0;
	for (int i=head[x];i;i=e[i].nxt){
		int y=e[i].to;
		if (y==fa) continue;
		dfs1(y,x);
		sz[x]+=sz[y];
		res+=f[y];
	}
	f[x]=max(f[x],res);
	if (f[x]>sz[x] || (n-sz[x])<b[x]) flag=0;
}
void dfs2(int x,int fa){
	g[x]+=g[fa];
	if (fa) g[x]+=f[fa]-f[x]; 	
	//g[x]=max(g[x],b[x]);
	for (int i=head[x];i;i=e[i].nxt){
		int y=e[i].to;
		if (y==fa) continue;
		dfs2(y,x);
	}	
}	
void chk(){
	for (int i=1;i<=n;++i)
		if (f[i]<a[i] || f[1]-f[i]<b[i]) return;
	ans=min(ans,f[1]);
}
void dfs(int x,int fa){
	f[x]=p[x];
	for (int i=head[x];i;i=e[i].nxt){
		int y=e[i].to;
		if (y==fa) continue;
		dfs(y,x);
		f[x]+=f[y];	
	}
}
void solve(int x){
	if (x>n){
		memset(f,0,sizeof(f));
		dfs(1,0);
		chk();
		return;
	}	
	p[x]=1;
	solve(x+1);
	p[x]=0;
	solve(x+1);
}
void down(int x,int fa){
	int res=0;
	for (int i=head[x];i;i=e[i].nxt){
		int y=e[i].to;
		if (y!=fa) res+=f[y];	
	}
	if (f[x]>res){
		for (int i=head[x];i;i=e[i].nxt){
			int y=e[i].to;
			if (y==fa) continue;
			while (f[y]<sz[y] && res<f[x]){
				++f[y];
				++res;
			}
		}	
	}
	for (int i=head[x];i;i=e[i].nxt){
		int y=e[i].to;
		if (y!=fa) down(y,x);	
	}
}
int main(){
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	int T=read();
	while (T--){
		n=read();
		memset(head,0,sizeof(head));
		cnt=0;
		for (int i=1;i<n;++i){
			int u=read(),v=read();
			init(u,v);init(v,u);
		}
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		sa=read();
		for (int i=1;i<=sa;++i){
			int r=read(),s=read();
			a[r]=max(a[r],s);	
		}
		sb=read();
		for (int i=1;i<=sb;++i){
			int r=read(),s=read();
			b[r]=max(b[r],s);	
		}
		if (n<=17){
			ans=1e9;
			solve(1);
			if (ans==1e9) ans=-1;
			printf("%d\n",ans);
			continue;
		}
		flag=1;
		dfs1(1,0);
		down(1,0);
		if (sb==0){
			printf("%d\n",f[1]);
			continue;	
		}
		if (!flag){
			printf("-1\n");
			continue;	
		}
		memset(g,0,sizeof(g));
		dfs2(1,0);
		for (int i=1;i<=n;++i) g[i]=max(g[i],b[i]);
		ans=0;
		for (int i=1;i<=n;++i)
			ans=max(ans,f[i]+g[i]);
		printf("%d\n",ans);
	}
	return 0;
}

