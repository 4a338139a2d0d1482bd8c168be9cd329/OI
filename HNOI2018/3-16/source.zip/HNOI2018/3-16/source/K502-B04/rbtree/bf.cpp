#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int N=1e5+5;
struct node{
	int next,to;
}e[N*2];
int head[N],cnt;
void init(int u,int v){
	e[++cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;	
}
int a[N],b[N],f[N];
int n,sa,sb,ans,p[N];
void chk(){
	for (int i=1;i<=n;++i)
		if (f[i]<a[i] || f[1]-f[i]<b[i]) return;
	ans=min(ans,f[1]);
}
void dfs(int x,int fa){
	f[x]=p[x];
	for (int i=head[x];i;i=e[i].next){
		int y=e[i].to;
		if (y==fa) continue;
		dfs(y,x);
		f[x]+=f[y];	
	}
}
void solve(int x){
	if (x>n){
		memset(f,0,sizeof(f));
		dfs(1,0);
		chk();
		return;
	}	
	p[x]=1;
	solve(x+1);
	p[x]=0;
	solve(x+1);
}
int main(){
	freopen("rbtree.in","r",stdin);
	//freopen("rbtrre.out","w",stdout);
	int T=read();
	while (T--){
		n=read();
		memset(head,0,sizeof(head));
		cnt=0;
		ans=1e9;
		for (int i=1;i<n;++i){
			int u=read(),v=read();
			init(u,v);init(v,u);
		}
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		sa=read();
		for (int i=1;i<=sa;++i){
			int r=read(),s=read();
			a[r]=max(a[r],s);	
		}
		sb=read();
		for (int i=1;i<=sa;++i){
			int r=read(),s=read();
			b[r]=max(b[r],s);	
		}
		solve(1);
		if (ans==1e9) ans=-1;
		printf("%d\n",ans);
	}	
	return 0;
}

