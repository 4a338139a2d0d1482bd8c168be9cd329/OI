#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<time.h>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int N=1e5+5;
struct node{
	int next,to;
}e[N*2];
int head[N],cnt;
void init(int u,int v){
	e[++cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;	
}
int sz[N];
void dfs(int x,int fa){
	sz[x]=1;
	for (int i=head[x];i;i=e[i].next){
		int y=e[i].to;
		if (y==fa) continue;
		dfs(y,x);
		sz[x]+=sz[y];	
	}
}
int main(){
	freopen("rbtree.in","w",stdout);
	srand((unsigned)time(NULL));
	int T=5;
	printf("%d\n",T);
	while (T--){
		int n=5,sa=5,sb=5;
		printf("%d\n",n);
		memset(head,0,sizeof(head));
		cnt=0;
		for (int i=2;i<=n;++i){
			int k=i-1;
			int u=rand()%k+1;
			printf("%d %d\n",u,i);
			init(u,i);
		}
		dfs(1,0);
		printf("%d\n",sa);
		for (int i=1;i<=sa;++i){
			int u=rand()%n+1;
			int v=rand()%sz[u]+1;
			printf("%d %d\n",u,v);
		}
		printf("%d\n",sb);
		for (int i=1;i<=sb;++i){
			int u=rand()%n+1;
			int v;
			if (n-sz[u]==0) v=0;
			else v=rand()%(n-sz[u])+1;
			printf("%d %d\n",u,v);
		}
		
	}
	return 0;
}

