#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
long long read(){
	long long x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const long long Mod=998244353;
long long n,m,k;
int main(){
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	n=read();k=read();
	m=read();
	if (n==2 && k==0){
		for (long long i=1;i<=m;++i){
			long long x=read();
			x%=Mod;
			x=(x*2)%Mod;
			printf("%lld\n",x);
		}
	}
	return 0;
}

