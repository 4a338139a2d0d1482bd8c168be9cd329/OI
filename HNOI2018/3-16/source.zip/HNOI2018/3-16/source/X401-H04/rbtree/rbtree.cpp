#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
const int MAXN = 100010;
using namespace std;

inline void read(int &x) {
    char ch; while((ch = getchar()), (ch < '0' || ch > '9'));
    x = ch - '0'; while((ch = getchar()), (ch >= '0' && ch <= '9')) x = x * 10 + (ch - '0');
}

vector<int> G[MAXN];
int N, A[MAXN], B[MAXN];
namespace Tree {
    int Val, size[MAXN], L[MAXN], R[MAXN];
    bool Fail;
    inline void dfs(int u, int f) {
        int i, v;
        size[u] = 1;
        for(i = 0; i < G[u].size(); i++) if((v = G[u][i]) != f) {
            dfs(v, u);
            size[u] += size[v];
        }
        //Proceed L, R
        L[u] = max(L[u], A[u]);
        R[u] = min(R[u], min(size[u], Val - B[u]));
        //Subtree Intersection
        int subL = 0, subR = 1;
        for(i = 0; i < G[u].size(); i++) if((v = G[u][i]) != f) {
            subL += L[v];
            subR += R[v];
        }
        L[u] = max(L[u], subL);
        R[u] = min(R[u], subR);
        //Chk Fail
        if(L[u] > R[u]) Fail = 1;
    }
    inline bool ok(int x) {
        Fail = 0, Val = x;
        for(int i = 1; i <= N; i++) L[i] = 0, R[i] = Val;
        dfs(1, 0);
        return (!Fail) && (Val >= L[1] && Val <= R[1]);
    }
}

int T, NA, NB;

int main() {
    freopen("rbtree.in", "rt", stdin);
    freopen("rbtree.out", "wt", stdout);

    int i, u, v, s;
    read(T);
    while(T--) {
        read(N);
        //Clear Tree
        for(i = 1; i <= N; i++) G[i].clear();
        //Read Tree
        for(i = 1; i < N; i++) {
            read(u), read(v);
            G[u].push_back(v), G[v].push_back(u);
        }

        //Init Limitations
        for(i = 1; i <= N; i++) A[i] = 0, B[i] = 0;

        read(NA);
        for(i = 1; i <= NA; i++) read(u), read(s), A[u] = max(A[u], s);
        read(NB);
        for(i = 1; i <= NB; i++) read(u), read(s), B[u] = max(B[u], s);

        //Binary Search
        int l = -1, r = N, m; //(L, R]
        while(r - l > 1) {
            m = (l + r) >> 1;
            if(Tree::ok(m)) r = m; else l = m;
        }

        int Ans = Tree::ok(r) ? r : -1;
        printf("%d\n", Ans);
    }
}
