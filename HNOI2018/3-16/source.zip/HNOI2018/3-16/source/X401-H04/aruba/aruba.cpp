#include <cstring>
#include <cstdio>
#include <algorithm>
#define ll long long
const int MAXLOG = 59;
const int MOD = 998244353;
inline int mul(int x, int y) { return (ll)x * (ll)y % MOD; }
inline int add(int x, int y) { int r = x + y; if(r >= MOD) r -= MOD; return r; }
using namespace std;

const int MAXM = 1400;
struct matrix {
    int d[MAXM][MAXM], r, c;
    inline matrix operator*(matrix rhs) {
        matrix ret; ret.r = r, ret.c = rhs.c;
        for(int i = 0; i < r; i++) for(int j = 0; j < rhs.c; j++) {
            ret.d[i][j] = 0;
            for(int k = 0; k < c; k++) ret.d[i][j] = add(ret.d[i][j], mul(d[i][k], rhs.d[k][j]));
        }
        return ret;
    }
};

int NC, NS;
matrix A, G[MAXLOG + 1];
int main() {
    freopen("aruba.in", "rt", stdin);
    freopen("aruba.out", "wt", stdout);

    scanf("%d%d", &NC, &NS);
    int MatSz = NC * NC * NC * NC * (NS + 1) * 2;
    //Initialize G0
    G[0].r = G[0].c = MatSz;
    for(int a = 0; a < NC; a++) for(int b = 0; b < NC; b++) for(int c = 0; c < NC; c++) for(int d = 0; d < NC; d++) for(int orgconf = 0; orgconf <= NS; orgconf++) {
        int idA = a * NC * NC * NC + b * NC * NC + c * NC + d;
        for(int x = 0; x < NC; x++) for(int y = 0; y < NC; y++) for(int z = 0; z < NC; z++) for(int w = 0; w < NC; w++) {
            int idB = x * NC * NC * NC + y * NC * NC + z * NC + w;
            int conf = ((x == y) + (x == z) + (z == w) + (y == w)) + ((a == x) + (b == y) + (c == z) + (d == w));
            if(conf + orgconf <= NS) G[0].d[ (idB * (NS + 1) + conf + orgconf) * 2 ][ (idA * (NS + 1) + orgconf) * 2 ]++;
        }
    }
    for(int i = 0; i < MatSz; i++) {
        if((i & 1) == 0) G[0].d[ i | 1 ][ i ]++;
        if((i & 1) == 1) G[0].d[ i ][ i ]++;
    }
    //Getpow
    for(int i = 1; i <= MAXLOG; i++) G[i] = G[i - 1] * G[i - 1];
    //Initialize A
    A.r = MatSz, A.c = 1;
    for(int a = 0; a < NC; a++) for(int b = 0; b < NC; b++) for(int c = 0; c < NC; c++) for(int d = 0; d < NC; d++) {
        int id = a * NC * NC * NC + b * NC * NC + c * NC + d;
        int conf = (a == b) + (a == c) + (c == d) + (b == d);
        if(conf <= NS) A.d[ (id * (NS + 1) + conf) * 2 ][0]++;
    }
    //Queries
    int Q;
	ll H;
    scanf("%d", &Q);
    while(Q--) {
        scanf("%lld", &H); H--;

        matrix M = A;
        for(int i = MAXLOG; i >= 0; i--) if((H >> (ll)i) & 1LL)
            M = G[i] * M;

        int Ans = 0;
        for(int i = 0; i < M.r; i++) Ans = add(Ans, M.d[i][0]);
        printf("%d\n", Ans);
    }
}
