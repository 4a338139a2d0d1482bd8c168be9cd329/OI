#include <cstring>
#include <cstdio>
#include <algorithm>
#define ll long long
const int MAXN = 200010;
const ll INFLL = 0x7f7f7f7f7f7f7f7fLL;
using namespace std;

template<typename T>
inline void read(T &x) {
    char ch; bool f = 0; while((ch = getchar()), (ch < '0' || ch > '9')) f |= (ch == '-');
    x = ch - '0'; while((ch = getchar()), (ch >= '0' && ch <= '9')) x = x * 10 + (ch - '0');
    if(f) x = -x;
}

/********* Seg ***********/
struct seg {
    ll t; ll d;
    inline bool operator<(seg rhs) { return t < rhs.t; }
} S[2][4*MAXN];
int Scnt[2];

inline ll Div2Ceil(ll x) { return (x < 0) ? (x / 2) : ((x / 2) + (x % 2)); }
inline ll Div2Floor(ll x) { return (x > 0) ? (x / 2) : ((x / 2) + (x % 2)); }
inline void add(int par, ll l, ll r, ll d) {
	//printf("[%d] %lld %lld +%lld\n", par, l, r, d);
    if(par == 0) l = Div2Ceil(l), r = Div2Floor(r); else l = Div2Ceil(l - 1), r = Div2Floor(r - 1);
    //printf("-> [%d] %lld %lld\n", par, l, r);
    if(l > r) return;

    S[ par ][ ++Scnt[par] ] = (seg){ l, d };
    S[ par ][ ++Scnt[par] ] = (seg){ r + 1, -d };
}

int T, N, M;
struct item {
    ll t; ll d; int type;
    inline bool operator<(item rhs) const { return t < rhs.t; }
} A[2*MAXN];
int NA;

inline void work(ll len, ll curp, ll d) {
    if(d == 0) add(abs(curp) % 2, curp, curp, len);
    else if(d == 2) add(abs(curp) % 2, curp, curp + 2 * (len - 1), 1);
    else if(d == -2) add(abs(curp) % 2, curp - 2 * (len - 1), curp, 1);
    else if(d == 1) {
        add(0, curp, curp + len - 1, 1);
        add(1, curp, curp + len - 1, 1);
    }
    else if(d == -1) {
        add(0, curp - len + 1, curp, 1);
        add(1, curp - len + 1, curp, 1);
    }
}

ll TotL;
int main() {
    freopen("robot.in", "rt", stdin);
    freopen("robot.out", "wt", stdout);

    int i, v; ll x, t;

    read(T);
    while(T--) {
        NA = 0; Scnt[0] = Scnt[1] = 0;

        //Read Speed
        read(N); t = 0;
        for(i = 1; i <= N; i++) read(v), read(x), A[++NA] = (item){t, v, 0}, t += x;
        read(M); t = 0;
        for(i = 1; i <= M; i++) read(v), read(x), A[++NA] = (item){t, v, 1}, t += x;
        TotL = t;

        //Discrete
        sort(A + 1, A + NA + 1);

        int va = 0, vb = 0;
        ll begin = 0, nxt, curp = 0;
        for(i = 1; i <= NA; i++) {
            if(A[i].type == 0) va = A[i].d; else vb = A[i].d;
            if(i == NA || A[i].t != A[i + 1].t) { //Segment end
                nxt = (i == NA) ? TotL : A[i + 1].t;
                //segment [begin, nxt), pos = p, d = vb - va
                //printf("[%lld, %lld] = %d, point = %lld\n", begin, nxt - 1, vb - va, curp + (ll)(vb - va));
                
                work(nxt - begin, curp + (ll)(vb - va), vb - va);
                curp += (ll)(nxt - begin) * (vb - va);

                begin = nxt;
            }
        }

        ll maxv = 0, zerocnt = 0;
        for(int par = 0; par <= 1; par++) {
            S[ par ][ ++Scnt[par] ] = (seg){ -INFLL, 0 };
            sort(S[par] + 1, S[par] + Scnt[par] + 1);

            ll curval = 0, begin = S[par][1].t, nxt;
            for(i = 1; i <= Scnt[par]; i++) {
                curval += S[par][i].d;
                if(i == Scnt[par] || S[par][i].t != S[par][i + 1].t) {
                    nxt = (i == Scnt[par]) ? INFLL : S[par][i + 1].t;
                    //Segment [begin, nxt)
                    maxv = max(maxv, curval);
                    //printf(">> [%d] %lld, %lld = %lld\n", par, begin, nxt - 1, curval);
                    //If include Zero
                    if(par == 0 && begin <= 0 && (nxt - 1) >= 0) zerocnt = curval;

                    begin = nxt;
                }
            }
        }
        printf("%lld\n", max(maxv, zerocnt + 1));
    }
}
