#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
#define Chkmax(a,b) a=a>b?a:b
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
#endif
}
static int n;
const int MAXN=1e5+7;
static struct edge
{
	int w,v,nxt;
}p[MAXN<<2],q[MAXN<<2];
static int head[MAXN],e,a,b,hed[MAXN],cur[MAXN];
inline void add(edge P[],int H[],int u,int v,int w=0)
{
	P[++e]=(edge){w,v,H[u]},H[u]=e;
}
static int dfn[MAXN],sz[MAXN];
void dfs(int u,int fa)
{
	dfn[u]=++e;sz[u]=1;
	for(register int v=head[u];v;v=p[v].nxt)if(p[v].v^fa)
		dfs(p[v].v,u),sz[u]+=sz[p[v].v];
}
static int l,r,E;
static int B[MAXN][2];
inline void init()
{
	read(n);e=0;
	l=0;r=n;
	static int u,v;
	memset(head,0,sizeof head);
	memset(hed,0,sizeof hed);
	Rep(i,1,n-1)read(u),read(v),add(p,head,u,v),add(p,head,v,u);
	e=0;dfs(1,0);
	e=0;read(a);
	Rep(i,1,n)add(q,hed,n+1,i);
	Rep(i,1,n-1)add(q,hed,i,i+1,1);
	Rep(i,1,a)
	{
		read(u);read(v);
		Chkmax(l,v);
		if(u^1)add(q,hed,dfn[u]+sz[u]-1,dfn[u]-1,-v);
	}
	E=e;memcpy(cur,hed,sizeof hed);
	read(b);
	Rep(i,1,b)read(B[i][0]),read(B[i][1]),Chkmax(l,B[i][1]);
}
int vis[MAXN],dis[MAXN],vv[MAXN],tt;
static deque<int>G;
inline bool spfa(int s)
{
	memset(dis,0x3f,sizeof dis);
	memset(vv,0,sizeof vv);
	G.clear();G.push_back(s);vis[s]=true;dis[s]=0;
	while(!G.empty())
	{
		static int u;u=G.front();G.pop_front();
		for(register int v=hed[u];v;v=q[v].nxt)
			if(dis[q[v].v]>dis[u]+q[v].w)
			{
				dis[q[v].v]=dis[u]+q[v].w;
				if(vis[q[v].v]^tt)
				{
					vis[q[v].v]=tt;++vv[q[v].v];
					if(vv[q[v].v]>n+1)return true;
					if(G.empty()||dis[q[v].v]<dis[G.front()])
						G.push_front(q[v].v);
					else G.push_back(q[v].v);
				}
			}
		vis[u]=false;
	}
	return false;
}
inline bool Judge(int lim)
{
	e=E;++tt;memcpy(hed,cur,sizeof cur);
	Rep(i,1,b)add(q,hed,dfn[B[i][0]]-1,dfn[B[i][0]]+sz[B[i][0]]-1,lim-B[i][1]);
	if(spfa(n+1))return false;
	return true;

}
inline void solve()
{
	static int mid;
	while(l<=r)
	{
		mid=(l+r)>>1;
		if(Judge(mid))r=mid-1;
		else l=mid+1;
	}
	printf("%d\n",l>n?-1:l);
}
int main()
{
	file();
	static int _;
	read(_);
	while(_--)init(),solve();
	return 0;
}

