#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("rbtree.in","w",stdout);
#endif
}
static int t=10,n=1e4;
const int MAXN=1e5+7;
static int p[MAXN];
static vector<int>K[2];
int main()
{
	file();
	cout<<t<<endl;
	Rep(i,1,n)p[i]=i;
	static int u,v;
	Rep(i,1,t)
	{
		random_shuffle(p+1,p+n+1);
		cout<<n<<endl;
		Rep(i,1,n-1)
		{
			u=1ll*rand()*rand()%i+1;
			printf("%d %d\n",p[u],p[i+1]);
		}
		Rep(i,2,n)K[rand()&1].push_back(i);
		cout<<K[0].size()<<endl;
		Rep(i,0,K[0].size()-1)printf("%d %d\n",K[0][i],1);
		cout<<K[1].size()<<endl;
		Rep(i,0,K[1].size()-1)printf("%d %d\n",K[1][i],1);
	}
	return 0;
}

