#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
#endif
}
const int MAXN=6e5;
static int pos[MAXN],qs[MAXN],n,m;
static int tii[MAXN],cnt;
inline void init()
{
	static int d,p;
	memset(tii,0,sizeof tii);
	memset(pos,0,sizeof pos);
	memset(qs,0,sizeof qs);
	read(n);cnt=0;
	Rep(i,1,n)
	{
		read(d);read(p);
		Rep(j,1,p){pos[cnt+1]=pos[cnt]+d;++cnt;}
	}
	read(m);
	cnt=0;
	Rep(i,1,m)
	{
		read(d);read(p);
		Rep(j,1,p){qs[cnt+1]=qs[cnt]+d;++cnt;}
	}
}
#define Chkmax(a,b) a=a>b?a:b
inline void solve()
{
	Rep(i,0,cnt)++tii[200000+pos[i]-qs[i]];
	static int ans;ans=0;
	Rep(i,0,4e5)Chkmax(ans,tii[i]);
	printf("%d\n",ans);
}
int main()
{
	file();
	static int _;
	read(_);
	while(_--)init(),solve();
	return 0;
}

