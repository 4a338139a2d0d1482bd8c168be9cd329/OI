#include <bits/stdc++.h>

#define SZ(x) ((int)(x).size())

typedef long long LL;

LL read(LL x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

template <typename T> bool chkmax(T &a, T b) { return a < b? a = b, true : false; }
template <typename T> bool chkmin(T &a, T b) { return a > b? a = b, true : false; }

const int MAXN = 1e5 + 5;

int N, M;
LL A[MAXN], V[MAXN];
LL B[MAXN], W[MAXN];

namespace SubTask1
{
	int sumA[MAXN];
	int sumB[MAXN];

	int exec(int *sum, LL *A, LL *V, int len)
	{
		int times = 0;
		for (int i = 1; i <= len; ++i) {
			for (int j = 1; j <= A[i]; ++j) {
				times ++;
				sum[times] = sum[times-1] + V[i];
			}
		}
		return times;
	}

	int occur[(MAXN << 1) + 5];

	void main(int L = 0)
	{
		memset(occur, 0, sizeof occur);

		L = exec(sumA, A, V, N);
		L = exec(sumB, B, W, M);
//		fprintf(stderr, "%d\n", sumA[N]);

		int ans = 0;
		for (int i = 0; i <= L; ++i) {
			int delta = sumA[i] - sumB[i];
			occur[delta + MAXN] ++;
			chkmax(ans, occur[delta + MAXN]);
		}

		printf("%d\n", ans);
	}
}

namespace SubTask2
{
	using std :: vector;
	using std :: pair;

	typedef pair<int, int> pii;

	LL pos[MAXN << 3];

	vector<pii> q[MAXN << 3];

	struct Info
	{
		LL l, r, addv; int ty;
		Info(LL l = 0, LL r = 0, LL addv = 0, int ty = 0) : l(l), r(r), addv(addv), ty(ty) {}
	}P[MAXN];

	void main()
	{
		int pos_cnt = 0, tot = 0;

		for (int i = 1; i <= N; ++i) A[i] += A[i-1];
		for (int i = 1; i <= M; ++i) B[i] += B[i-1];

		pos[++pos_cnt] = 0;
		pos[++pos_cnt] = 1;
		P[++tot] = Info(0, 1, 1, 0);

		int i = 1; LL suma = 0;
		int j = 1; LL sumb = 0;
		for (LL curt = 0; curt < A[N];) {
//			fprintf(stderr, "%d %d\n", i, j);
//			assert(i <= N && j <= M);
			LL deltaT = 0;

			if (A[i] < B[j]) {
				deltaT = A[i] - curt;

				//add
				if (deltaT != 0) {
					int inc = V[i] - W[j];
					if (abs(inc) == 0) {
						LL l = suma - sumb, r = l + 1;
						pos[++pos_cnt] = l;
						pos[++pos_cnt] = r;
						P[++tot] = Info(l, r, deltaT, 0);
					}
					else if (abs(inc) == 1) {
						LL l = suma - sumb + inc, r = l + (deltaT-1) * inc;
						if (l > r) std :: swap(l, r); 
						r ++;
						pos[++pos_cnt] = l;
						pos[++pos_cnt] = r;
						P[++tot] = Info(l, r, 1, 0);
					}
					else {
						LL l = suma - sumb + inc, r = l + (deltaT-1) * inc;
						if (l > r) std :: swap(l, r); 
						r ++;
						pos[++pos_cnt] = l;
						pos[++pos_cnt] = r;
						P[++tot] = Info(l, r, 1, 1);
					}
				}
				suma = suma + deltaT * V[i];
				sumb = sumb + deltaT * W[j];

				curt = A[i]; i ++;
			}
			else {
				deltaT = B[j] - curt;
//				fprintf(stderr, "%lld\n", deltaT);

				//same
				if (deltaT != 0) {
					int inc = V[i] - W[j];
					if (abs(inc) == 0) {
						LL l = suma - sumb, r = l + 1;
						pos[++pos_cnt] = l;
						pos[++pos_cnt] = r;
						P[++tot] = Info(l, r, deltaT, 0);
					}
					else if (abs(inc) == 1) {
						LL l = suma - sumb + inc, r = l + (deltaT-1) * inc;
						if (l > r) std :: swap(l, r); 
						r ++;
						//					fprintf(stderr, "%lld %lld\n", l, r);
						pos[++pos_cnt] = l;
						pos[++pos_cnt] = r;
						P[++tot] = Info(l, r, 1, 0);
					}
					else {
						LL l = suma - sumb + inc, r = l + (deltaT-1) * inc;
						if (l > r) std :: swap(l, r); 
						r ++;
						//					fprintf(stderr, "%lld %lld %lld\n", l, r, suma - sumb + inc);
						pos[++pos_cnt] = l;
						pos[++pos_cnt] = r;
						P[++tot] = Info(l, r, 1, 1);
					}
				}
				suma = suma + deltaT * V[i];
				sumb = sumb + deltaT * W[j];

				curt = B[j]; j ++; 
			}
//			fprintf(stderr, "%lld %lld\n", suma, sumb);
		}

		std :: sort(pos + 1, pos + pos_cnt + 1);
		pos_cnt = std :: unique(pos + 1, pos + pos_cnt + 1) - pos;

		for (int i = 1; i <= tot; ++i) {
//			printf("[%lld, %lld) + %lld, type = %d\n", P[i].l, P[i].r, P[i].addv, P[i].ty);
			P[i].l = std::lower_bound(pos + 1, pos + pos_cnt + 1, P[i].l) - pos;
			P[i].r = std::lower_bound(pos + 1, pos + pos_cnt + 1, P[i].r) - pos;

			q[P[i].l].push_back(pii(i, +1));
			q[P[i].r].push_back(pii(i, -1));
		}
//		puts("------------------------------------");

		LL ans = 0;
		LL addv[2] = {0, 0};

		for (int i = 1; i <= pos_cnt; ++i) {
			for (int j = 0; j < SZ(q[i]); ++j) {
				int o = q[i][j].first;
				if (P[o].ty) {
					addv[pos[P[o].l] & 1LL] += q[i][j].second * P[o].addv;
				}
				else {
					for (int ty = 0; ty < 2; ++ty) {
						if (pos[P[o].r] - pos[P[o].l] == 1
								&& (pos[P[o].l] & 1LL) != ty) continue;
						addv[ty] += q[i][j].second * P[o].addv;
					}
				}
			}

			for (int ty = 0; ty < 2; ++ty) chkmax(ans, addv[ty]);

			q[i].clear();
		}

		printf("%lld\n", ans);
	}
}

int main()
{
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);

	int T = read();

	while (T--) {
		LL MaxLen = 0;

		N = read();
		for (int i = 1; i <= N; ++i) V[i] = read(), A[i] = read();
		M = read();
		for (int i = 1; i <= M; ++i) W[i] = read(), B[i] = read();

		for (int i = 1; i <= N; ++i) MaxLen += A[i];
		if (MaxLen <= 200000)
			SubTask1 :: main();
		else
			SubTask2 :: main();
	}

	return 0;
}
//F@ck
//wocaonimadebi 
//buzaogeidayangli
