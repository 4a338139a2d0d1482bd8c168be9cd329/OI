#include <bits/stdc++.h>

using std :: pair;

int read(int x = 0, int _f = 0)
{
	char c = getchar();
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

template <typename T> bool chkmax(T &a, T b) { return a < b? a = b, true : false; }
template <typename T> bool chkmin(T &a, T b) { return a > b? a = b, true : false; }

typedef pair<int, int> pii;

const int MAXN = 1e5 + 5;

int N, al, bl;
pii A[MAXN], B[MAXN];

int e, Begin[MAXN];
struct Edge
{
	int to, next;
	Edge(int to = 0, int next = 0) : to(to), next(next) {}
}E[MAXN << 1];

void AddEdge(int u, int v)
{
	E[++e] = Edge(v, Begin[u]); Begin[u] = e;
}

namespace SubTask1
{
	int size[MAXN];

	void DFS_check(int u, int fa, int status)
	{
		size[u] = (status>>(u-1)) & 1;
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa) continue;
			DFS_check(v, u, status);
			size[u] += size[v];
		}
	}

	void main()
	{
		for (int s = 0; s < (1 << N); ++s) {
			int tot = __builtin_popcount(s), flag = 1;

			DFS_check(1, 0, s);

			for (int i = 1; i <= al; ++i) {
				if (size[A[i].first] < A[i].second) {
					flag = 0;
					break;
				}
			}
			for (int i = 1; i <= bl; ++i) {
				if (tot - size[B[i].first] < B[i].second) {
					flag = 0;
					break;
				}
			}

			if (flag) {
				printf("%d\n", tot);
				return ;
			}
		}
		puts("-1");
	}
}

namespace SubTask2
{
	int f[MAXN];
	int g[MAXN];
	int size[MAXN];

	int DFS(int u, int fa = -1)
	{
		int ret = 1;
		size[u] = 1, f[u] = 0;
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa) continue;
			ret &= DFS(v, u);
			size[u] += size[v];
			f[u] += f[v];
		}
		chkmax(f[u], g[u]);
		if (size[u] < g[u]) return false;
		return ret;
	}

	void main()
	{
		memset(g, 0, sizeof g);
		for (int i = 1; i <= al; ++i)
			g[A[i].first] = A[i].second;

		if (DFS(1))
			printf("%d\n", f[1]);
		else 
			puts("-1");
	}
}

namespace SubTask3
{
	bool vis[MAXN];
	int f[MAXN];
	int g[MAXN];
	int size[MAXN], fa[MAXN];

	int DFS(int u)
	{
		int ret = 1;
		size[u] = 1, f[u] = 0;
		for (int i = Begin[u]; i; i = E[i].next) {
			int v = E[i].to;
			if (v == fa[u] || vis[v]) continue;
			fa[v] = u;
			ret &= DFS(v);
			size[u] += size[v];
			f[u] += f[v];
		}
		if (u != 1) chkmax(f[u], g[u]);
		if (size[u] < g[u]) return false;
		return ret;
	}

	void main()
	{
		memset(g, 0, sizeof g);
		for (int i = 1; i <= al; ++i)
			g[A[i].first] = A[i].second;

		if (!DFS(1)) {
			puts("-1");
			return ;
		}

		int ban = B[1].first;
		if (N - size[ban] < B[1].second) {
			puts("-1"); 
			return ;
		}

		DFS(ban);

		vis[ban] = true;
		DFS(1);
		chkmax(f[1], B[1].second);

		f[1] += f[ban];
		chkmax(f[1], g[1]);
		printf("%d\n", f[1]);
	}

}

int main()
{
	freopen("rbtree.in", "r", stdin);
	freopen("rbtree.out", "w", stdout);

	int T = read();
	while (T--) {
		e = 0;
		memset(Begin, 0, sizeof Begin);

		N = read();
		for (int i = 1; i < N; ++i) {
			int u = read(), v = read();
			AddEdge(u, v);
			AddEdge(v, u);
		}

		al = read();
		for (int i = 1; i <= al; ++i) {
			A[i].first = read();
			A[i].second = read();
		}

		bl = read();
		for (int i = 1; i <= bl; ++i) {
			B[i].first = read();
			B[i].second = read();
		}

		if (N > 20)
			SubTask1 :: main();
		else if (!bl)
			SubTask2 :: main();
		else 
			SubTask3 :: main();
	}

	return 0;
}

