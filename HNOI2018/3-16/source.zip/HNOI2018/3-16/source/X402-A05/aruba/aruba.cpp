#include <bits/stdc++.h>

const int mod = 998244353;

int main()
{
	freopen("aruba.in", "r", stdin);
	freopen("aruba.out", "w", stdout);

	int T, C, K;
	scanf("%d%d%d", &C, &K, &T);
	while (T--) {
		int h; scanf("%d", &h);
		printf("%lld\n", 2ll * h % mod);
	}

	return 0;
}
