#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1e5+5, inf = 0x3f3f3f3f ;
int n, m, e, Begin[maxn], Next[maxn*2], To[maxn*2], fa[maxn] ;
int dis[maxn], son[maxn], size[maxn], lim1[maxn], lim2[maxn] ;
bool vis[maxn] ;
void init() {
	e = 0 ;
	memset (Begin, 0, sizeof Begin) ;
	memset (Next, 0, sizeof Next) ;
	memset (To, 0, sizeof To) ;
	memset (lim1, 0, sizeof lim1) ;
	memset (lim2, 0, sizeof lim2) ;
}
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
void dfs ( int x, int F ) {
	int i, u ;
	fa[x] = F ;
	son[x] = 1 ;
	size[x] += vis[x] ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (u ^ F) dfs(u, x), son[x] += son[u] ;
	}
	size[F] += size[x] ;
}
int calc ( int x ) {
	int i ;
	memset (size, 0, sizeof size) ;
	for ( i = 1 ; i <= n ; i ++, x >>= 1 )
		vis[i] = x&1 ;
	dfs(1, 0) ;
	for ( i = 1 ; i <= n ; i ++ )
		if (size[i] < lim1[i] || size[1]-size[i] < lim2[i])
			return inf ;
	return size[1] ;
}
void force() {
	int i, x = 1<<n, ans = inf ;
	for ( i = 0 ; i ^ x ; i ++ )
		ans = min(ans, calc(i)) ;
	if (ans ^ inf) printf ( "%d\n", ans ) ;
	else puts("-1") ;
}
void FKU ( int x, int F ) {
	int i, u ;
	size[x] = 1 ;
	son[x] = 0 ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (u ^ F) {
			FKU(u, x) ;
			size[x] += size[u] ;
			son[x] += son[u] ;
		}
	}
	son[x] = max(son[x], lim1[x]) ;
}
void solve7_9() {
	FKU(1, 1) ;
	for ( int i = 1 ; i <= n ; i ++ )
		if (son[i] > size[i]) {
			puts("-1") ;
			return ;
		}
	printf ( "%d\n", son[1] ) ;
}
void solve() {
	Read(n) ;
	int i, x, u, ta, tb ;
	init() ;
	for ( i = 1 ; i ^ n ; i ++ ) {
		Read(x), Read(u) ;
		add(x, u), add(u, x) ;
	}
	Read(ta) ;
	while (ta--) {
		Read(x), Read(u) ;
		lim1[x] = max(lim1[x], u) ;
	}
	Read(tb) ;
	while (tb--) {
		Read(x), Read(u) ;
		lim2[x] = max(lim2[x], u) ;
	}
	if (n <= 17) force() ;
	else if (tb == 0)
		solve7_9() ;
}
int main() {
	freopen ( "rbtree.in", "r", stdin ) ;
	freopen ( "rbtree.out", "w", stdout ) ;
	int _ ;
	Read(_) ;
	while(_--) solve() ;
	return 0 ;
}
