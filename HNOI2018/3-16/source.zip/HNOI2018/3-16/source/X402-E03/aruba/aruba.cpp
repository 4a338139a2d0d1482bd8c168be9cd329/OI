#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL Mod = 998244353 ;
LL n, m, dfn[300], fc[300][300], c, k, Len ;
struct Matrix  {
	LL N, M, s[300][300] ;
	friend Matrix operator + ( Matrix A, Matrix B ) {
		Matrix C ;
		C.N = A.N, C.M = B.M ;
		int i, j ;
		for ( i = 1 ; i <= C.N ; i ++ )
			for ( j = 1 ; j <= C.M ; j ++ )
				C.s[i][j] = (A.s[i][j] + B.s[i][j])%Mod ;
		return C ;
	}
	friend Matrix operator * ( Matrix A, Matrix B ) {
		Matrix C ;
		C.N = A.N, C.M = B.M ;
		int i, j, t ;
		for ( i = 1 ; i <= C.N ; i ++ )
			for ( j = 1 ; j <= C.M ; j ++ ) {
				C.s[i][j] = 0 ;
				for ( t = 1 ; t <= A.M ; t ++ )
					(C.s[i][j] += A.s[i][t]*B.s[t][j]%Mod) %= Mod ;
			}
		return C ;
	}
	void init() {
		for ( int i = 1 ; i <= N ; i ++ )
			for ( int j = 1 ; j <= M ; j ++ )
				s[i][j] = i==j ;
	}
	void check() {
		for ( int i = 1 ; i <= N ; i ++, puts("") )
			for ( int j = 1 ; j <= M ; j ++ )
				printf ( "%lld ", s[i][j] ) ;
	}
	LL count() {
		LL cnt = 0 ;
		for ( int i = 1 ; i <= N ; i ++ )
			for ( int j = 1 ; j <= M ; j ++ )
				(cnt += s[i][j]) %= Mod ;
		return cnt ;
	}
} U, G[61], S, Unit ;
Matrix Qpow ( Matrix A, LL b ) {
	Matrix C ;
	C.N = A.N, C.M = A.M ;
	C.init() ;
	for ( ; b ; b >>= 1, A = A*A )
		if (b&1) C = C*A ;
	return C ;
}
int a[5] ;
void dfs ( int stp, int sum ) {
	int i ;
	if (stp > 4) {
		dfn[++m] = sum ;
		if (a[1]==a[2]) ++ fc[m][0] ;
		if (a[2]==a[3]) ++ fc[m][0] ;
		if (a[3]==a[4]) ++ fc[m][0] ;
		if (a[1]==a[4]) ++ fc[m][0] ;
		return ;
	}
	for ( i = 1 ; i <= c ; i ++ ) {
		a[stp] = i ;
		dfs(stp+1, sum*10+i) ;
	}
}
int main() {
	freopen ( "aruba.in", "r", stdin ) ;
	freopen ( "aruba.out", "w", stdout ) ;
	LL i, j, t, u, v, _ ;
	Read(c), Read(k) ;
	m = 0 ;
	a[0] = 1 ;
	dfs(1, 0) ;
	n = m ;
	m = 0 ;
	for ( i = 1 ; i <= n ; i ++ )
		if (fc[i][0] <= k) {
			dfn[++m] = dfn[i] ;
			fc[m][0] = fc[i][0] ;
		}
	for ( i = 1 ; i <= m ; i ++ )
		for ( j = 1 ; j <= m ; j ++ ) {
			u = dfn[i], v = dfn[j] ;
			while (u && v) {
				if (u%10==v%10) ++ fc[i][j] ;
				u /= 10, v /= 10 ;
			}
		}
	G[1].N = G[1].M = Len = m*(k+1)+1 ;
	for ( i = 1 ; i <= m ; i ++ )
		for ( t = 0 ; t <= k ; t ++ )
			for ( j = 1 ; j <= m ; j ++ )
				if (fc[i][j]+t <= k)
					G[1].s[i+t*m][j+(fc[i][j]+t)*m] = 1 ;
	Read(_) ;
	for ( i = 1 ; i <= Len ; i ++ )
		G[1].s[i][Len] = 1 ;
	G[0].N = G[0].M = Len ;
	G[0].init() ;
	t = 30 ;
	for ( i = 2 ; i <= 60 ; i ++ )
		G[i] = G[i - 1]*G[i - 1] ;
	U.N = 1, U.M = Len ;
	for ( i = 1 ; i <= m ; i ++ )
		if (fc[i][0] <= k)
			U.s[1][i+fc[i][0]*m] = 1 ;
	//U.check(), puts("") ;
	while (_--) {
		Read(n) ;
		-- n ;
		S = U ;
		for ( i = 1 ; n ; i ++, n >>= 1 )
			if (n&1) S = S*G[i] ;
		printf ( "%lld\n", S.count() ) ;
	}
	cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
