#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=2e5+10;
const ll lim=2e18+10;
ll a[maxn],b[maxn],dira[maxn],dirb[maxn],Hash[maxn<<2];
struct M{
	ll l,r,val;
}Modify[maxn];
inline ll read(){
	ll x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
struct Seg_T{
	ll Seg[maxn<<4],Tag[maxn<<4];
	inline void Push_Down(int h){
		if(Tag[h]){
			Seg[h<<1]+=Tag[h],Tag[h<<1]+=Tag[h];
			Seg[h<<1|1]+=Tag[h],Tag[h<<1|1]+=Tag[h];
			Tag[h]=0;
		}
	}
	void Modify(int h,int l,int r,int L,int R,ll val){
		if(L<=l && r<=R){
			Seg[h]+=val,Tag[h]+=val;
			return;
		}
		Push_Down(h);
		int mid=(l+r)>>1;
		if(L<=mid)Modify(h<<1,l,mid,L,R,val);
		if(R>mid)Modify(h<<1|1,mid+1,r,L,R,val);
		Seg[h]=max(Seg[h<<1],Seg[h<<1|1]);
	}
	ll Query(int h,int l,int r,int L,int R){
		if(L<=l && r<=R)return Seg[h];
		Push_Down(h);
		int mid=(l+r)>>1;ll ans=0;
		if(L<=mid)ans=max(ans,Query(h<<1,l,mid,L,R));
		if(R>mid)ans=max(ans,Query(h<<1|1,mid+1,r,L,R));
		return ans;
	}
}T;
int main(){
	ll i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
#endif
	ll Case=read();
	ll rt=1;
	while(Case--){
		ll cnt=0,mcnt=0;
		n=read();
		for(i=1;i<=n;i++)dira[i]=read(),a[i]=read()+a[i-1],Hash[++cnt]=a[i];
		m=read();
		for(i=1;i<=m;i++)dirb[i]=read(),b[i]=read()+b[i-1],Hash[++cnt]=b[i];
		sort(Hash+1,Hash+cnt+1);
		cnt=unique(Hash+1,Hash+cnt+1)-Hash-1;
		ll l=1,r=1,pl,pr;pl=pr=0;
		for(i=1;i<=cnt;i++){
			if(a[l]<Hash[i])l++;
			if(b[r]<Hash[i])r++;
			ll tpl=pl+(Hash[i]-Hash[i-1])*dira[l];
			ll tpr=pr+(Hash[i]-Hash[i-1])*dirb[r];
			ll L=pr-pl,R=tpr-tpl;
			if(L>R)L--;if(L<R)L++;
			ll ql=min(L,R),qr=max(L,R);
			if(ql!=qr)Modify[++mcnt]=(M){ql,qr,1};
			else Modify[++mcnt]=(M){ql,qr,Hash[i]-Hash[i-1]};
			pl=tpl,pr=tpr;
		}
		cnt=0;
		for(i=1;i<=mcnt;i++)Hash[++cnt]=Modify[i].l,Hash[++cnt]=Modify[i].r;
		Hash[++cnt]=0;
		sort(Hash+1,Hash+cnt+1);
		cnt=unique(Hash+1,Hash+cnt+1)-Hash-1;
		for(i=1;i<=mcnt;i++){
			Modify[i].l=lower_bound(Hash+1,Hash+cnt+1,Modify[i].l)-Hash;
			Modify[i].r=lower_bound(Hash+1,Hash+cnt+1,Modify[i].r)-Hash;
		}
		ll Pos=lower_bound(Hash+1,Hash+cnt+1,0)-Hash;
		for(i=1;i<=mcnt;i++)T.Modify(1,1,cnt,Modify[i].l,Modify[i].r,Modify[i].val);
		ll ans=0;
		if(Pos>1)ans=max(ans,T.Query(1,1,cnt,1,Pos-1));
		if(Pos<cnt)ans=max(ans,T.Query(1,1,cnt,Pos+1,cnt));
		ans=max(ans,T.Query(1,1,cnt,Pos,Pos)+1);
		printf("%lld\n",ans);
		for(i=1;i<=(cnt<<2);i++)T.Seg[i]=T.Tag[i]=0;
	}
	return 0;
}

