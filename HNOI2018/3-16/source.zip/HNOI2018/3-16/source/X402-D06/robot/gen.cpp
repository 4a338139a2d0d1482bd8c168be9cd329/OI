#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	ll i,j,k,m,n;
	freopen("gen.in","r",stdin);
	int rand_num=read();
	srand(time(0)+rand_num);
	freopen("robot.in","w",stdout);
	ll T=10;printf("%lld\n",T);
	ll sum=1e18;
	while(T--){
		sum=1e18;
		n=90000ll+rand()%10000ll;
		printf("%lld\n",n);
		for(i=1;i<n;i++){
			ll range=(sum*2)/(n-i+1),val=(rand()<<31ll|rand())%range;
			printf("%lld %lld\n",rand()%3-1,val),sum-=val;
		}
		printf("%lld %lld\n",rand()%3-1,sum);
		sum=1e18;
		n=90000ll+rand()%10000ll;
		printf("%lld\n",n);
		for(i=1;i<n;i++){
			ll range=sum*2/(n-i+1),val=(rand()<<31ll|rand())%range;
			printf("%lld %lld\n",rand()%3-1,val),sum-=val;
		}
		printf("%lld %lld\n",rand()%3-1,sum);
	}
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	return 0;
}
