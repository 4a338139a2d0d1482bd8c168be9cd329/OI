#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e5+10;
int to[maxn<<1],nex[maxn<<1],beg[maxn],a[maxn],b[maxn];
int size[maxn],Min[maxn],Max[maxn],vis[maxn],dp1[maxn],dp2[maxn];
int e,n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
void dfs(int x,int fa){
	int i;size[x]=1;
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		dfs(to[i],x);
		size[x]+=size[to[i]];
	}
}
inline void initialize(int val){
	int i;
	for(i=1;i<=n;i++)Min[i]=a[i];
	for(i=1;i<=n;i++){
		if(vis[i])Max[i]=val-b[i];
		else Max[i]=INF;
		Max[i]=min(Max[i],size[i]);
	}
}
int chk(int x,int fa,int val){
	int i,sum1=0,sum2=0;
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		if(!chk(to[i],x,val))return 0;
		sum1+=dp1[to[i]];sum2+=dp2[to[i]];
	}
	if(Min[x]>Max[x] || sum1>Max[x] || size[x]<Min[x])return 0;
	dp1[x]=max(sum1,Min[x]);dp2[x]=min(sum2+1,Max[x]);
	if(dp1[x]>dp2[x] || (x==1 && (dp1[1]>val || dp2[1]<val)))return 0;
	return 1;
}
int main(){
	int i,j,k,m,T;
#ifndef ONLINE_JUDGE
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
#endif
	T=read();
	while(T--){
		n=read();e=0;
		for(i=1;i<n;i++){
			int x=read(),y=read();
			add(x,y),add(y,x);
		}
		dfs(1,0);
		int flag=0;
		int cnt1=read();
		for(i=1;i<=cnt1;i++){
			int pos=read(),val=read();
			if(size[pos]<val)flag=1;
			a[pos]=val;
		}
		int cnt2=read();
		for(i=1;i<=cnt2;i++){
			int pos=read(),val=read();
			if(size[1]-size[pos]<val)flag=1;
			b[pos]=val;vis[pos]=1;
		}
		if(flag){
			puts("-1");
			for(i=1;i<=n;i++)a[i]=b[i]=beg[i]=size[i]=vis[i]=0;
			continue;
		}
		int l=0,r=n;
		while(l<r){
			int mid=(l+r)>>1;
			initialize(mid);
			if(chk(1,0,mid))r=mid;
			else l=mid+1;
			for(i=1;i<=n;i++)dp1[i]=dp2[i]=0;
		}
		printf("%d\n",l);
		for(i=1;i<=n;i++)a[i]=b[i]=beg[i]=size[i]=vis[i]=0;
	}
	return 0;
}

