#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=20+10;
int to[maxn<<1],nex[maxn<<1],beg[maxn],a[maxn],b[maxn],q[maxn],sum[maxn];
int e,n,ans=INF;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
void Dfs(int x,int fa){
	int i;
	sum[x]=q[x];
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		Dfs(to[i],x);
		sum[x]+=sum[to[i]];
	}
}
inline int chk(){
	memset(sum,0,sizeof(sum));
	Dfs(1,0);int i;
	for(i=1;i<=n;i++)if(a[i]>sum[i])return 0;
	for(i=1;i<=n;i++)if(b[i]>sum[1]-sum[i])return 0;
	return 1;
}
void dfs(int cur,int tot){
	if(cur>tot){
		if(chk()){
			int csum=0,i;
			for(i=1;i<=tot;i++)if(q[i])csum++;
			ans=min(ans,csum);
		}
		return;
	}
	q[cur]=1;
	dfs(cur+1,tot);
	q[cur]=0;
	dfs(cur+1,tot);
}
int main(){
	int i,j,k,m,T;
#ifndef ONLINE_JUDGE
	freopen("rbtree.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	T=read();
	while(T--){
		memset(a,0,sizeof(a)),memset(b,0,sizeof(b));
		memset(beg,0,sizeof(beg));
		ans=INF;e=0;
		n=read();
		for(i=1;i<n;i++){
			int x=read(),y=read();
			add(x,y),add(y,x);
		}
		int cnt1=read();
		for(i=1;i<=cnt1;i++){
			int pos=read(),val=read();
			a[pos]=val;
		}
		int cnt2=read();
		for(i=1;i<=cnt2;i++){
			int pos=read(),val=read();
			b[pos]=val;
		}
		dfs(1,n);
		printf("%d\n",ans==INF?-1:ans);
	}
	return 0;
}

