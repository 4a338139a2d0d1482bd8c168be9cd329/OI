#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,q;
#ifndef ONLINE_JUDGE
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
#endif
	n=read(),m=read(),q=read();
	while(q--)printf("%d\n",read()*2%998244353);
	return 0;
}

