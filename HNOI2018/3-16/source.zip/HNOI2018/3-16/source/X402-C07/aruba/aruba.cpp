#include<cstdio>
#include<algorithm>
using namespace std;

#define rgint register int
int c,w,m,a[12][12],b[12][12],num[1012],cnt[1012][1012];
int dp[203][260][10],ans[203];
long long h[100012],n=0;
const int mod=998244353;
int main(){
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	scanf("%d%d",&c,&w);
	scanf("%d",&m);
	for (rgint i=1;i<=m;i++)
	{
	  scanf("%lld",&h[i]);
	  n=max(n,h[i]);
	}
	if (c==2&&w==0)
	{
	  for (int i=1;i<=m;i++)
	    printf("%lld\n",h[i]*2%mod);
	  return 0;
	}
	if (c==1)
	{
	  if (w<4)
	    for (int i=1;i<=m;i++)
	      printf("%d\n",0);
	  if (w>=4)
	    for (int i=1;i<=m;i++)
	      printf("%d\n",1);
	  return 0;
	}
	int c4=c*c*c*c;
	for (rgint i=0;i<c4;i++)
	{
	  a[1][1]=i%c;
	  a[1][2]=(i/c)%c;
	  a[2][1]=(i/c/c)%c;
	  a[2][2]=(i/c/c/c)%c;
	  num[i]+=(a[1][1]==a[1][2]);
	  num[i]+=(a[1][2]==a[2][2]);
	  num[i]+=(a[2][2]==a[2][1]);
	  num[i]+=(a[2][1]==a[1][1]);
	}
	for (rgint i=0;i<c4;i++)
	  for (rgint j=0;j<c4;j++)
	  {
	    a[1][1]=i%c;
	    a[1][2]=(i/c)%c;
	    a[2][1]=(i/c/c)%c;
	    a[2][2]=(i/c/c/c)%c;
	    b[1][1]=j%c;
	    b[1][2]=(j/c)%c;
	    b[2][1]=(j/c/c)%c;
	    b[2][2]=(j/c/c/c)%c;
	    cnt[i][j]+=(a[1][1]==b[1][1]);
	    cnt[i][j]+=(a[1][2]==b[1][2]);
	    cnt[i][j]+=(a[2][1]==b[2][1]);
	    cnt[i][j]+=(a[2][2]==b[2][2]);
	  }
	//printf("%d %d\n",c4,c4);
	for (rgint i=0;i<c4;i++)
	  dp[1][i][num[i]]=1;
	for (rgint i=2;i<=n;i++)
	  for (rgint j=0;j<c4;j++)
	    for (rgint k=0;k<=w;k++)
		{
		  for (rgint l=0;l<c4;l++)
			if (k-cnt[j][l]-num[j]>=0)
			  dp[i][j][k]=(dp[i][j][k]+dp[i-1][l][k-cnt[j][l]-num[j]])%mod;
		  ans[i]=(ans[i]+dp[i][j][k])%mod;
		}
	for (rgint i=1;i<=1;i++)
	  for (rgint j=0;j<c4;j++)
	    for (rgint k=0;k<=w;k++)
		  ans[i]=(ans[i]+dp[i][j][k])%mod;
	for (rgint i=1;i<=n;i++)
	  ans[i]=(ans[i]+ans[i-1])%mod;
	for (rgint i=1;i<=m;i++)
	  printf("%d\n",ans[h[i]]);
	return 0;
}
