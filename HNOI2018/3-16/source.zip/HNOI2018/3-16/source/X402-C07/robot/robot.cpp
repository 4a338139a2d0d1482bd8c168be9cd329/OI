#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,vn[100012],an[100012],vm[100012],am[100012];
int t,ans,dn[100012],dm[100012];
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
	  ans=0;
	  scanf("%d",&n);
	  for (int i=1;i<=n;i++)
	  	scanf("%d%d",&vn[i],&an[i]);
	  scanf("%d",&m);
	  for (int i=1;i<=m;i++)
	    scanf("%d%d",&vm[i],&am[i]);
	  int xn=0,ln=0,rn=0;
	  for (int i=1;i<=n;i++)
	  {
	  	xn+=vn[i]*an[i];
	  	ln=min(ln,xn);
	  	rn=max(rn,xn);
	  }
	  int xm=0,lm=0,rm=0;
	  for (int i=1;i<=m;i++)
	  {
	  	xm+=vm[i]*am[i];
	  	lm=min(lm,xm);
	  	rm=max(rm,xm);
	  }
	  int sum=0;
	  for (int i=1;i<=n;i++)
	  {
	    for (int j=sum;j<=sum+an[i]-1;j++)
	      dn[j]=vn[i];
	    sum+=an[i];
	  }
	  sum=0;
	  for (int i=1;i<=m;i++)
	  {
	    for (int j=sum;j<=sum+am[i]-1;j++)
	      dm[j]=vm[i];
	    sum+=am[i];
	  }
	  //printf("%d %d %d %d\n",ln,rn,lm,rm);
	  for (int i=ln-rm;i<=rn-lm;i++)
	  {
	  	int a=0,b=i,tot=0;
		if (a==b)
	  	  tot++;//,printf("0\n");
		for (int j=0;j<=sum-1;j++)
	  	{
		  a+=dn[j];
		  b+=dm[j];
		  if (a==b)
		    tot++;//,printf("%d\n",j+1);
		}
		ans=max(ans,tot);
	  }
	  printf("%d\n",ans);
	}
	return 0;
}
