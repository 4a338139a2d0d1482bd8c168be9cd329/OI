#include<cstdio>
#include<algorithm>
#include<vector>
#include<queue>
using namespace std;
vector<int> son[100012];
int q[100012],tot[100012];
int n,ans,a,b,ra[100012],rb[100012],sa[100012],sb[100012];

bool cmp(int a,int b){
	return a>b;
}

void dfs(int x,int fa){
	if (q[x]==1)
	  tot[x]=1;
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (s==fa)
	    continue;
	  dfs(s,x);
	  tot[x]+=tot[s];
	}
}

int check(int num){
	for (int i=1;i<=n;i++)
	  tot[i]=0;
	dfs(1,0);
	for (int i=1;i<=a;i++)
	  if (tot[ra[i]]<sa[ra[i]])
	    return false;
	for (int i=1;i<=b;i++)
	  if (num-tot[rb[i]]<sb[rb[i]])
	    return false;
	return true;
}

void doing(int x,int num){
	if (x==n+1)
	{
	  if (check(num))
	  {
	    ans=min(ans,num);
		/*if (num==ans)
		{
		  printf(" %d    ",ans);
		  for (int i=1;i<=n;i++)
		    printf("%d ",q[i]);printf("\n");
		}*/
	  }
	  //,printf("ok\n");
	  //printf("\n");
	  //for (int i=1;i<=n;i++)
	  //  printf("%d %d\n",q[i],tot[i]);
	  //printf("\n");
	  return ;
	}
	q[x]=1;
	doing(x+1,num+1);
	q[x]=0;
	doing(x+1,num);
}

long long read(){
	long long x=0,f=1;
	char ch=getchar();
	while (ch>'9'||ch<'0')
	{
	  if (ch=='-')
	    f=-1;
	  ch=getchar();
	}
	while (ch>='0'&&ch<='9')
	{
	  x=(x<<1)+(x<<3)+(ch^'0');
	  ch=getchar();
	}
	return x*f;
}

int main(){
	freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	int t;
	t=read();
	while (t--)
	{
	  ans=1e8;
	  n=read();
	  for (int i=1;i<=n;i++)
	    son[i].clear(),q[i]=0;
	  int ok=1;
	  for (int i=1;i<=n-1;i++)
	  {
	  	int a,b; 
	    a=read(),b=read();
	    if (abs(a-b)!=1)
	      ok=0;
		son[a].push_back(b);
	    son[b].push_back(a);
	  }
	  scanf("%d",&a);
	  for (int i=1;i<=a;i++)
	  {
	    scanf("%d",&ra[i]);
		scanf("%d",&sa[ra[i]]);
	  }	
	  scanf("%d",&b);
	  for (int i=1;i<=b;i++)
	  {
	    scanf("%d",&rb[i]);
		scanf("%d",&sb[rb[i]]);
	  }
	  if (ok==1)
	  {
	    sort(ra+1,ra+1+a,cmp);
	    sort(rb+1,rb+1+b);
	  	int ok1=0,l=0,r=0,num=0;
		priority_queue<int,vector<int>,greater<int> > h1;
		for (int i=1;i<=n;i++)
		  q[i]=0;
		for (int i=ra[1];i<=n;i++)
		  h1.push(i);
		for (int i=1;i<=a;i++)
	  	{
		  if (n-ra[i]+1<sa[ra[i]])
		  {
		    ok1=1;
		    break;
		  }
		  if (i!=1)
		    for (int j=ra[i];j<=ra[i-1];j++)
		      h1.push(j);
		  for (int j=1;j<=sa[ra[i]]-r;j++)
		  {
		  	int x=h1.top();
		  	h1.pop();
		  	q[x]=1;
		  	num++;
		  }
		  r=num;
		  //r=max(r,sa[i]);
		}
		//for (int i=1;i<=n;i++)
		//  printf("%d ",q[i]);printf("\n");
		if (ok1==0)
		{
		  priority_queue<int> h2;
		  for (int i=1;i<rb[1];i++)
		    if (!q[i])
			  h2.push(i);
			else
			  l++;
		  for (int i=1;i<=b;i++)
		  {
		  	//printf("l is %d %d\n",l,sb[rb[i]]);
		  	if (rb[i]-1<sb[rb[i]])
		  	{
		  	  ok1=1;
		  	  break;
		    }
		    if (i!=1)
		      for (int j=rb[i-1];j<rb[i];j++)
		        if (!q[j])
				  h2.push(j);
				else
				  l++;
			int nw=0;
			for (int j=1;j<=sb[rb[i]]-l;j++)
			{
			  int x=h2.top();
			  h2.pop();
			  nw++;
			  num++;
			}
			l+=nw;
		    //l=max(l,sb[i]);
		  }
		}
		if (ok1==1)
		  printf("%d\n",-1);
		else
		  printf("%d\n",num);
		continue;
	  }
	  doing(1,0);
	  if (ans==1e8)
	    ans=-1;
	  printf("%d\n",ans);
	}
	return 0;
}
