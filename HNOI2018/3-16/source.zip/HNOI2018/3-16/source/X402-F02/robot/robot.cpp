#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("robot.in","r",stdin);
      freopen("robot.out","w",stdout);
  #endif
}
int n,m;
ll v[N],w[N];
ll a[N],b[N];
void input()
{
	n=read<int>();
	For(i,1,n)v[i]=read<ll>(),a[i]=read<ll>();
	m=read<int>();
	For(i,1,m)w[i]=read<ll>(),b[i]=read<ll>();
}
const ll maxn=1e18+5;
const int M=6e6+5;
#define lson ls[h],l,mid
#define rson rs[h],mid+1,r
struct Tree
{
	int ls[M],rs[M],rt,sz;
	ll lazy[M],maxn[M];
	void init()
	{
		if(sz<=1000000)For(i,1,sz)ls[i]=rs[i]=maxn[i]=lazy[i]=0;
		else memset(ls,0,sizeof ls),memset(rs,0,sizeof rs),memset(lazy,0,sizeof lazy),memset(maxn,0,sizeof maxn);
		rt=sz=0;
	}
	void update(int &h,ll l,ll r,ll s,ll t,ll v)
	{
		if(!h)h=++sz;
		if(s<=l&&r<=t)
		{
			maxn[h]+=v;lazy[h]+=v;
			return;
		}
		ll mid=(l+r)>>1;
		if(s<=mid)update(lson,s,t,v);
		if(mid<t)update(rson,s,t,v);
		maxn[h]=max(maxn[ls[h]],maxn[rs[h]])+lazy[h];
	}
}s1,s2;
ll id(ll pos,int x,int y)
{
	if((pos%2)!=x)return pos+y;
	else return pos;
}
void init()
{
	s1.init();
	s2.init();
	For(i,1,n)a[i]+=a[i-1];
	a[n+1]=a[n]+1;++n;
	For(i,1,m)b[i]+=b[i-1];
	b[m+1]=b[m]+1;++m;
}
void work()
{
	ll pre1=0,pre2=0,now1,now2,pre_tim=0,now_tim,tim,pre_dis=0,now_dis,k1,k2;
	int p1=1,p2=1;
	while(p1<=n&&p2<=m)
	{
		now_tim=min(a[p1],b[p2]);
		tim=now_tim-pre_tim-1;
		now1=pre1+tim*v[p1];
		now2=pre2+tim*w[p2];
		now_dis=now1-now2;
		k1=pre_dis,k2=now_dis;
		if(k1>k2)swap(k1,k2);
		static ll l,r;
		if(v[p1]==w[p2])
		{
			if(now_dis&1)s1.update(s1.rt,-maxn,maxn,now_dis,now_dis,tim+1);
			else s2.update(s2.rt,-maxn,maxn,now_dis,now_dis,tim+1);
		}
		else if(v[p1]*w[p2]==-1)
		{
			if(pre_dis&1)
			{
				l=id(k1,1,1),r=id(k2,1,-1);
				if(l<=r)s1.update(s1.rt,-maxn,maxn,l,r,1);
			}
			else
			{
				l=id(k1,0,1),r=id(k2,0,-1);
				if(l<=r)s2.update(s2.rt,-maxn,maxn,l,r,1);
			}
		}
		else 
		{
			l=id(k1,1,1),r=id(k2,1,-1);
			if(l<=r)s1.update(s1.rt,-maxn,maxn,l,r,1);
			l=id(k1,0,1),r=id(k2,0,-1);
			if(l<=r)s2.update(s2.rt,-maxn,maxn,l,r,1);
		}
		//cout<<pre1<<' '<<pre2<<' '<<pre_dis;
		//cout<<endl;
		pre1=now1+v[p1],pre2=now2+w[p2],pre_tim=now_tim,pre_dis=pre1-pre2;
		//cout<<pre1<<' '<<pre2<<endl<<endl;
		if(now_tim==a[p1])++p1;
		if(now_tim==b[p2])++p2;
	}
	//cout<<p1<<' '<<p2<<endl;
	write(max(s1.maxn[s1.rt],s2.maxn[s2.rt]),'\n');
}
int main()
{
	file();
	int T=read<int>();
	while(T--)
	{
		input();
		//cerr<<1<<endl;
		init();
		//cerr<<2<<endl;
		work();
		//cerr<<3<<endl;
	}
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
