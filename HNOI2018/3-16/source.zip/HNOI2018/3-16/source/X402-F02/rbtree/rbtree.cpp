#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("rbtree.in","r",stdin);
      freopen("rbtree.out","w",stdout);
  #endif
}
int n,A,B;
int head[N],tt,to[N<<1],nex[N<<1];
void add(int x,int y)
{
	++tt;to[tt]=y;nex[tt]=head[x];head[x]=tt;
}
struct node
{
	int x,y;
}a[N],b[N];
void input()
{
	int x,y;
	n=read<int>();
	For(i,2,n)
	{
		x=read<int>(),y=read<int>();
		add(x,y),add(y,x);
	}
	A=read<int>();
	For(i,1,A)
	{
		x=read<int>(),y=read<int>();
		a[i]=(node){x,y};
	}
	B=read<int>();
	For(i,1,B)
	{
		x=read<int>(),y=read<int>();
		b[i]=(node){x,y};
	}
}
int size[N];
void dfs_check(int u,int pre)
{
	size[u]=1;
	for(register int i=head[u];i;i=nex[i])
	{
		if(to[i]^pre)
		{
			dfs_check(to[i],u);
			size[u]+=size[to[i]];
		}
	}
}
int check()
{
	dfs_check(1,0);
	For(i,1,A)if(size[a[i].x]<a[i].y)return 0;
	For(i,1,B)if(n-size[b[i].x]<b[i].y)return 0;
	return 1;
}
namespace sub1
{
	const int M=1e3+5;
	int id[M],dfs_clock;
	int lazy[M<<2],num[M<<2],maxn[M<<2];
	void dfs(int u,int pre)
	{
		id[u]=++dfs_clock;
		for(register int i=head[u];i;i=nex[i])
		{
			if(to[i]^pre)dfs(to[i],u);
		}
	}
	#define lson h<<1,l,mid
	#define rson h<<1|1,mid+1,r
	void push_up(int h)
	{
		int ls=h<<1,rs=ls|1;
		if(maxn[ls]>=maxn[rs])maxn[h]=maxn[ls],num[h]=num[ls];
		else maxn[h]=maxn[rs],num[h]=num[rs];
		maxn[h]+=lazy[h];
	}
	void build(int h,int l,int r)
	{
		maxn[h]=lazy[h]=0;num[h]=l;
		if(l==r)return;
		int mid=(l+r)>>1;
		build(lson),build(rson);
	}
	/*void push_down(int h,int l,int r,int mid)
	{
		if(!lazy[h])return;
		int ls=h<<1,rs=ls|1;
		lazy[ls]+=lazy[h],sum[ls]+=(mid-l+1)*lazy[h];
		lazy[rs]+=lazy[h],sum[rs]+=(r-mid)*lazy[h];
		lazy[h]=0;
	}*/
	void update(int h,int l,int r,int s,int t,int v)
	{
		if(s<=l&&r<=t)
		{
			lazy[h]+=v;maxn[h]+=v;
			return;
		}
		int mid=(l+r)>>1;
		if(s<=mid)update(lson,s,t,v);
		if(mid<t)update(rson,s,t,v);
		push_up(h);
	}
	void init()
	{
		memset(id,0,sizeof id);
		dfs_clock=0;
		dfs(1,0);
		build(1,1,n);
	}
	void solve()
	{
		init();
		int tot=0;
		For(i,1,A)update(1,1,n,id[a[i].x],id[a[i].x]+size[a[i].x]-1,a[i].y),tot+=size[a[i].x]*a[i].y;
		For(i,1,B)update(1,1,n,1,n,b[i].y),update(1,1,n,id[b[i].x],id[b[i].x]+size[b[i].x]-1,-b[i].y),tot+=(n-size[b[i].x])*b[i].y;
		int ans=0,pos,l,r;
		while(tot)
		{
			++ans,pos=num[1];
			//cout<<pos<<' '<<tot<<endl;
			For(i,1,A)
			{
				if(!a[i].y)continue;
				l=id[a[i].x],r=id[a[i].x]+size[a[i].x]-1;
				if(l<=pos&&pos<=r)--a[i].y,update(1,1,n,l,r,-1),tot-=size[a[i].x];
			}
			For(i,1,B)
			{
				if(!b[i].y)continue;
				l=id[b[i].x],r=id[b[i].x]+size[b[i].x]-1;
				if(pos<l||r<pos)--b[i].y,update(1,1,n,l,r,1),update(1,1,n,1,n,-1),tot-=(n-size[b[i].x]);
			}
		}
		write(ans,'\n');
	}
}
namespace sub2
{
	int dp[N],need[N];
	void init()
	{
		memset(need,0,sizeof need);
		memset(dp,0,sizeof dp);
		For(i,1,A)need[a[i].x]=a[i].y;
	}
	void DP(int u,int pre)
	{
		for(register int i=head[u];i;i=nex[i])
		{
			if(to[i]==pre)continue;
			DP(to[i],u);
			dp[u]+=dp[to[i]];
		}
		cmax(dp[u],need[u]);
	}
	void solve()
	{
		init();
		DP(1,0);
		if(!B)write(dp[1],'\n');
		else
		{
			int num=dp[1]-dp[b[1].x];
			if(num>=b[1].y)write(dp[1],'\n');
			else write(dp[1]+b[1].y-num,'\n');
		}
	}
}
void init()
{
	memset(head,0,sizeof head);
	tt=0;
}
void work()
{
	if(!check()){puts("-1");return;}
	if(n<=1000)sub1::solve();
	else if(B<=1)sub2::solve();
}
int main()
{
	file();
	int T=read<int>();
	while(T--)
	{
		init();
		input();
		work();
	}
	return 0;
}
