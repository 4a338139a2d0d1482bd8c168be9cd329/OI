#include <bits/stdc++.h>
using namespace std;
const int maxn = 100000  + 10;
int T,pos1[maxn],pos2[maxn],c[maxn][2],w[maxn][2];
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	scanf("%d",&T);
	while (T--) {
		int n,m,l = 0,ans = -9999999;
		scanf("%d",&n);
		for (int i = 1;i <= n;i++) scanf("%d%d",&c[i][0],&c[i][1]),l += c[i][1];
		scanf("%d",&m);
		for (int i = 1;i <= m;i++) scanf("%d%d",&w[i][0],&w[i][1]);
		int pos = 1,sum = 0,now = 0;
		for (int i = 0;i <= l;i++) {
			pos1[i] = now;
			now += c[pos][0];
			if (++sum == c[pos][1]) pos++,sum = 0;
		}
		pos = 1,sum = 0,now = 0;
		for (int i = 0;i <= l;i++) {
			pos2[i] = now;
			now += w[pos][0];
			if (++sum == w[pos][1]) pos++,sum = 0;
		}
		for (int start = -1000;start <= 1000;start++) {
			int cnt = 0;
			for (int i = 0;i <= l;i++)
				if (pos1[i]+start == pos2[i]) cnt++;
			ans = max(ans,cnt);
		}
		printf("%d\n",ans);
	}
	return 0;
}
