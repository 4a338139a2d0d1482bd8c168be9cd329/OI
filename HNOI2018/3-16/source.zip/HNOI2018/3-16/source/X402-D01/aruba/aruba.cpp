#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("aruba.in","r",stdin);
	freopen("aruba.out","w",stdout);
	long long c,k,q,ans;
	scanf("%lld%lld%lld",&c,&k,&q);
	ans = (c-1)*c*c/2;
	while (q--) {
		long long x;
		scanf("%lld",&x);
		printf("%lld\n",ans*x);
	}
	return 0;
}
