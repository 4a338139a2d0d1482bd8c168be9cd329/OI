#include <bits/stdc++.h>
using namespace std;
const int maxn = 100000 + 10;
int T,n,k,size[maxn],cnt1[maxn],cnt2[maxn];
vector<int> edges[maxn];
inline void dfs(int now,int fa) {
	size[now] = 1;
	for (size_t i = 0;i < edges[now].size();i++)
		if (edges[now][i] != fa) {
			dfs(edges[now][i],now);
			size[now] += size[edges[now][i]];
		}
}
inline void init(int now,int fa) {
	for (size_t i = 0;i < edges[now].size();i++)
		if (edges[now][i] != fa) {
			dfs(edges[now][i],now);
			if (cnt1[now] && cnt1[edges[now][i]] && cnt2[edges[now][i]] >= 0) cnt2[edges[now][i]] += cnt1[now]-cnt1[edges[now][i]];
		}
}
int main() {
    freopen("rbtree.in","r",stdin);
	freopen("rbtree.out","w",stdout);
	scanf("%d",&T);
	while (T--) {
		memset(cnt1,0,sizeof(cnt1));
		memset(cnt2,0,sizeof(cnt2));
		memset(size,0,sizeof(size));
		bool flag = true;
		scanf("%d",&n);
		for (int i = 1;i <= n;i++) edges[i].clear();
		for (int i = 1,x,y;i < n;i++) {
			scanf("%d%d",&x,&y);
			edges[x].push_back(y);
			edges[y].push_back(x);
		}
		dfs(1,0);
		int a,b;
		scanf("%d",&a);
		for (int i = 1,r,s;i <= a;i++) scanf("%d%d",&r,&s),cnt1[r] = s;
		scanf("%d",&b);
		for (int i = 1,r,s;i <= b;i++) scanf("%d%d",&r,&s),cnt2[r] = -s;
		for (int i = 1;i <= n;i++) if (cnt1[i] && abs(cnt2[i]) && cnt1[i]+abs(cnt2[i]) > n) { flag = false; break; }
		for (int i = 1;i <= n;i++) if ((cnt1[i] && cnt1[i] > size[i]) || (abs(cnt2[i]) && abs(cnt2[i]) > n-size[i])) { flag = false; break;}
		init(1,0);
		if (!flag) {
			printf("-1\n");
			continue;
		}
		int ans = 0;
		for (int i = 1;i <= n;i++) {
		    cnt2[i] = abs(cnt2[i]);
			if (cnt1[i] && cnt2[i]) ans = max(cnt1[i]+cnt2[i],ans);
		}
		printf("%d\n",ans);
	}
	return 0;
}
