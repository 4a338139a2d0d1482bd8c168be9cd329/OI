#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=998244353;

int C,K,Q;
ll fpm(ll a,ll b){
	a%=mod;
	ll ret=1ll;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
void work1(){
	ll ans=1ll*C*(C-1),q=ans-2*C+3;
	for(int h;Q--;){
		ans=1ll*C*(C-1)%mod;
		scanf("%d",&h);
		if(q==1)ans=1ll*h*2%mod;
		else ans=(fpm(q,h)-1+mod)%mod*fpm(q-1,mod-2)%mod*ans%mod;
		printf("%d\n",ans);
	}
}

void solve(){
	scanf("%d%d%d",&C,&K,&Q);
	if(!K)work1();
//	for(;Q--;){
//		scanf("%d",&)
//	}
}
int main(){
	freopen("aruba.in","r",stdin);freopen("aruba.out","w",stdout);
	solve();
	fclose(stdin);fclose(stdout);
	return 0;
}
