#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;

int T,n;
int A,B,a[maxn],b[maxn];
vector<int> G[maxn];
namespace Work1{
	int mn[maxn],sz[maxn],flag;
	void dfs(int u,int fa){
		mn[u]=max(mn[u],a[u]);
		sz[u]=1;
		int tmp=0;
		for(int i=0,v;i<G[u].size();++i){
			if((v=G[u][i])!=fa){
				dfs(v,u);
				sz[u]+=sz[v];
				tmp+=mn[v];
			}
		}
		if(mn[u]>sz[u]){
			flag=1;
		}
		mn[u]=max(mn[u],tmp);
	}
	void work1(){
		flag=0;
		dfs(1,0);
		if(!flag){
			printf("%d\n",mn[1]);
		}
		else{
			puts("-1");
		}
	}
}
namespace Work2{
	int mn[maxn],sz[maxn],flag;
	void dfs(int u,int fa){
		mn[u]=max(mn[u],a[u]);
		sz[u]=1;
		int tmp=0;
		for(int i=0,v;i<G[u].size();++i){
			if((v=G[u][i])!=fa){
				dfs(v,u);
				sz[u]+=sz[v];
				tmp+=mn[v];
			}
		}
		if(mn[u]>sz[u]){
			flag=1;
		}
		mn[u]=max(mn[u],tmp);
	}
	void work2(){
		flag=0;
		dfs(1,0);
		if(flag){
			puts("-1");
			return;
		}
		int ans=mn[1];
		for(int i=1;i<=n;++i){
			if(b[i]){
				if(b[i]>n-sz[i]){
					puts("-1");
					return;
				}
				if(b[i]>(mn[1]-mn[i])){
					ans=b[i]+mn[i];
				}
				break;
			}
		}
		printf("%d\n",ans);
	}
}
namespace Work3{
	int vis[maxn],cnt[maxn];
	void work3(){
		memset(vis,0,sizeof vis);
		memset(cnt,0,sizeof cnt);
		
		for(int i=n,col;i;--i){
			if(col){
				vis[i]=1;
				--col;
			}
			if(b[i]){
				if(col>0){
					puts("-1");
					return;
				}
				col=b[i];
			}
		}
		for(int i=n;i;--i){
			cnt[i]=cnt[i+1]+vis[i];
		}
		vector<int> va;
		va.clear();
		for(int i=1;i<=n;++i){
			if(a[i]){
				va.push_back(i);
			}
		}
		for(int i=1,ip=0,col=0;i<=n;++i){
			if(col>=va[ip+1]){
				//puts("-1");
				//exit(0);
			}
			if(a[i]){
				if(col>=0){
					
				}
				++ip;
				col=a[i];
			}
		}
	}
}
void solve(){
	scanf("%d",&T);
	for(int flag;T--;){
		scanf("%d",&n);
		for(int i=1;i<=n;++i)G[i].clear(),a[i]=b[i]=0;
		flag=0;
		for(int i=1,u,v;i<n;++i){
			scanf("%d%d",&u,&v);
			G[u].push_back(v);
			G[v].push_back(u);
			if(u!=v+1&&v!=u+1)flag=1;
		}
		scanf("%d",&A);
		for(int i=1,u,v;i<=A;++i){
			scanf("%d%d",&u,&v);
			a[u]=v;
		}
		scanf("%d",&B);
		for(int i=1,u,v;i<=B;++i){
			scanf("%d%d",&u,&v);
			b[u]=v;
		}
		if(!B){
			Work1::work1();
			continue;
		}
		if(B==1){
			Work2::work2();
			continue;
		}
////		if(!flag){
////			Work3::work3();
////			continue;
////		}
	}
}
int main(){
	freopen("rbtree.in","r",stdin);freopen("rbtree.out","w",stdout);
	solve();
	fclose(stdin);fclose(stdout);
	return 0;
} 
