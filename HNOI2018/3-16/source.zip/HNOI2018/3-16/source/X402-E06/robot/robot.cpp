#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 200000;
const ll RNG = ll(1e18);

int rt;
namespace SEG {

#define mid ((l + r) >> 1ll)

    const int SZ = N * 45;

    int cnt;
    int lc[SZ + 5], rc[SZ + 5];
    ll mx[2][SZ + 5], ad[2][SZ + 5];

    void clear() { rt = cnt = 0; }

    inline int newnode() {
        ++ cnt;
        lc[cnt] = rc[cnt] = 0;
        ad[0][cnt] = ad[1][cnt] = 0;
        mx[0][cnt] = mx[1][cnt] = 0;
        return cnt;
    }

    inline void push_down(int u) {
        if(!lc[u]) lc[u] = newnode();
        if(!rc[u]) rc[u] = newnode();

        if(ad[0][u]) {
            ad[0][lc[u]] += ad[0][u], mx[0][lc[u]] += ad[0][u]; 
            ad[0][rc[u]] += ad[0][u], mx[0][rc[u]] += ad[0][u]; 
        } ad[0][u] = 0;
        if(ad[1][u]) {
            ad[1][lc[u]] += ad[1][u], mx[1][lc[u]] += ad[1][u]; 
            ad[1][rc[u]] += ad[1][u], mx[1][rc[u]] += ad[1][u]; 
        } ad[1][u] = 0;
    }

    void modify(int& u, ll l, ll r, ll x, ll y, ll z, bool o) {
        if(!u) u = newnode();
        if(x <= l && r <= y) {
            if(l < r || ((l&1ll) == o)) {
                ad[o][u] += z; 
                mx[o][u] += z;
            } return;
        }
        push_down(u);

        if(x <= mid)
            modify(lc[u], l, mid, x, y, z, o);
        if(mid < y)
            modify(rc[u], mid+1, r, x, y, z, o);

        mx[0][u] = std::max(mx[0][lc[u]], mx[0][rc[u]]);
        mx[1][u] = std::max(mx[1][lc[u]], mx[1][rc[u]]);
    }
}

int T, n, m;
pair<int, ll> a[N + 5], b[N + 5];

int main() {
    freopen("robot.in", "r", stdin);
    freopen("robot.out", "w", stdout);

    read(T);
    while(T--) {
        read(n);
        for(int i = 1; i <= n; ++i) read(a[i].fst), read(a[i].snd), a[i].snd += a[i-1].snd;
        read(m);
        for(int i = 1; i <= m; ++i) read(b[i].fst), read(b[i].snd), b[i].snd += b[i-1].snd;

        ll cur = 0, t = 0;
        int t0 = 1, t1 = 1;

        SEG::clear();
        SEG::modify(rt, -RNG, RNG, 0, 0, 1, 0);

        while(t0 <= n && t1 <= m) {

            int d = a[t0].fst - b[t1].fst;
            ll mn = std::min(a[t0].snd, b[t1].snd);

            ll L = cur + d, R = (cur + (mn-t) * d);
            if(L > R) std::swap(L, R);

            bool o = (cur+d) & 1ll;
            if(d == 1 || d == -1) {
                SEG::modify(rt, -RNG, RNG, L, R, 1, 0);
                SEG::modify(rt, -RNG, RNG, L, R, 1, 1);
            } else if(d != 0) {
                SEG::modify(rt, -RNG, RNG, L, R, 1, o);
            } else {
                SEG::modify(rt, -RNG, RNG, L, R, (mn-t), o);
            }

            cur += (mn-t) * d, t = mn;

            if(a[t0].snd == mn) ++ t0;
            if(b[t1].snd == mn) ++ t1;
        }

        printf("%lld\n", std::max(SEG::mx[0][rt], SEG::mx[1][rt]));
    }

    // std::cout << procStatus() << std::endl;

    return 0;
}
