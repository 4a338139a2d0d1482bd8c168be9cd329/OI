#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;

int T, n, m;
vector<int> G[N + 5];
int a[N + 5], b[N + 5], sz[N + 5];

int all;
bool flag;

void dfs(int u, int f = 0) {
    for(int i = 0; i < (int) G[u].size(); ++i) {
        int v = G[u][i];
        if(v == f) continue;

        dfs(v, u);
        sz[u] += sz[v];
    }

    if(sz[u] < a[u]) flag = false;
    if(all - sz[u] < b[u]) flag = false;
}

bool chk() {
    flag = true;
    dfs(1);
    return flag;
}

void solve() {
    int ans = oo;
    for(int i = 0; i < (1 << n); ++i) {
        all = __builtin_popcount(i);
        for(int j = 0; j < n; ++j) sz[j+1] = (i >> j & 1);
        if(chk()) chkmin(ans, all);
    }
    printf("%d\n", ans == oo ? -1 : ans);
}

void init() {
    read(n);
    memset(a, 0, sizeof a);
    memset(b, 0, sizeof b);
    for(int i = 1; i <= n; ++i) G[i].clear();
    for(int i = 1; i < n; ++i) {
        static int x, y;
        read(x), read(y);
        G[x].pb(y), G[y].pb(x);
    }

    read(m);
    for(int i = 1; i <= m; ++i) {
        static int x;
        read(x), read(a[x]);
    }
    read(m);
    for(int i = 1; i <= m; ++i) {
        static int x;
        read(x), read(b[x]);
    }
}

int main() {
    freopen("rbtree.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(T);
    while(T--) {
        init();
        solve();
    }

    return 0;
}
