#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;

int T, n, m;
vector<int> G[N + 5];
int a[N + 5], b[N + 5];
int sz[N + 5], dp[N + 5], dfn[N + 5], dfs_clock;

namespace SSSP {

    int st[N + 5], to[(N << 2) + 5], nxt[(N << 2) + 5], w[(N << 2) + 5], e;

    inline void addedge(int x, int y, int z) {
        to[++ e] = y; nxt[e] = st[x]; st[x] = e; w[e] = z;
    }

    void clear() {
        e = 1;
        memset(st, 0, sizeof (int) * (n + 3));
    }

    void build(int all) {
        for(int i = 0; i <= n; ++i) {
            if(i < n) {
                addedge(i, i+1, 0);
                addedge(i+1, i, -1);
            }
            if(i > 0) {
                addedge(dfn[i] - 1, dfn[i] + sz[i] - 1, a[i]);
                addedge(dfn[i] + sz[i] - 1, dfn[i] - 1, b[i] - all);
            }
        }
    }

    bool inq[N + 5];
    int dis[N + 5], cnt[N + 5];

    void spfa() {
        std::queue<int> q;
        memset(inq, 0, sizeof (bool) * (n + 3));
        memset(cnt, 0, sizeof (int) * (n + 3));
        memset(dis, ~oo, sizeof (int) * (n + 3));

        q.push(0);
        dis[0] = 0;

        while(!q.empty()) {
            int x = q.front(); q.pop();
            if(++ cnt[x] >= n) { dis[n] = oo; return; } 

            inq[x] = false;
            for(int i = st[x]; i; i = nxt[i]) {
                int y = to[i];
                if(chkmax(dis[y], dis[x] + w[i])) {
                    if(!inq[y]) {
                        inq[y] = true;
                        q.push(y);
                    }
                }
            }
        }
    }

    bool chk(int all) {
        clear(); 
        build(all);
        spfa();
        return dis[n] <= all;
    }
}

int lim;
bool flag;
void dfs(int u, int f = 0) {
    sz[u] = 1;
    dp[u] = 0;
    dfn[u] = ++ dfs_clock;
    for(int i = 0; i < (int) G[u].size(); ++i) {
        int v = G[u][i];
        if(v == f) continue;

        dfs(v, u);
        dp[u] += dp[v];
        sz[u] += sz[v];
    }
    chkmax(dp[u], a[u]);
    chkmax(lim, dp[u] + b[u]);

    if(a[u] > sz[u] || b[u] > (n - sz[u])) {
        flag = false;
    }
}

void solve() {

    lim = 0;
    dfs_clock = 0;
    flag = true;

    dfs(1);

    if(!flag) {
        puts("-1");
    } else {
        int l = lim, r = n;

        while(l < r) {
            int mid = (l+r) >> 1;
            if(SSSP::chk(mid)) r = mid; else l = mid + 1;
        }

        printf("%d\n", r);
    }
}

void init() {
    read(n);
    memset(a, 0, sizeof (int) * (n + 3));
    memset(b, 0, sizeof (int) * (n + 3));
    for(int i = 1; i <= n; ++i) G[i].clear();
    for(int i = 1; i < n; ++i) {
        static int x, y;
        read(x), read(y);
        G[x].pb(y), G[y].pb(x);
    }

    read(m);
    for(int i = 1; i <= m; ++i) {
        static int x;
        read(x), read(a[x]);
    }
    read(m);
    for(int i = 1; i <= m; ++i) {
        static int x;
        read(x), read(b[x]);
    }
}

int main() {
    freopen("rbtree.in", "r", stdin);
    freopen("rbtree.out", "w", stdout);

    read(T);
    while(T--) {
        init();
        solve();
    }

    // std::cout << procStatus() << std::endl;
    return 0;
}
