#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 650;
const int mo = 998244353;

int all;
struct Matrix {
    int ret[N + 5][N + 5];

    void clear() { 
        memset(ret, 0, sizeof ret);
    }
};

Matrix K, B;

Matrix operator * (const Matrix& a, const Matrix& b) {
    static Matrix c; c.clear();
    for(int i = 0; i <= all; ++i) 
        for(int j = 0; j <= all; ++j) 
            for(int k = 0; k <= all; ++k) 
                c.ret[i][k] = (c.ret[i][k] + 1ll * a.ret[i][j] * b.ret[j][k]) % mo;
    return c;
}

Matrix operator ^ (const Matrix& a, ll b) {
    static Matrix c, x;
    c.clear(), x = a;
    for(int i = 0; i <= all; ++i) c.ret[i][i] = 1;
    for(; b > 0; b >>= 1) {
        if(b & 1)
            c = c * x;
        x = x * x;
    }
    return c;
}

int c, k, q;
inline int idx(int a, int b) { return a * (k + 1) + b; }
inline int get_cnt(int code) {
    int w = code % c; code /= c;
    int z = code % c; code /= c;
    int y = code % c; code /= c;
    int x = code % c; code /= c;
    return (x == y) + (y == w) + (w == z) + (x == z);
}
inline int get_cnt(int c0, int c1) {
    int res = 0;
    res += (c0 % c) == (c1 % c); c0 /= c, c1 /= c;
    res += (c0 % c) == (c1 % c); c0 /= c, c1 /= c;
    res += (c0 % c) == (c1 % c); c0 /= c, c1 /= c;
    res += (c0 % c) == (c1 % c); c0 /= c, c1 /= c;
    return res;
}

int main() {
    freopen("aruba.in", "r", stdin);
    freopen("aruba.out", "w", stdout);

    read(c), read(k), read(q);

    if(k == 0) {
        ll ans = 1ll * c * (c - 1) * ((c - 1) + (c - 2) * (c - 2)) % mo;
        while(q--) {
            static ll h; read(h);
            printf("%lld\n", ans * (h % mo) % mo);
        }
    } else if(c <= 3) {

        all = c * c * c * c * (k + 1);

        for(int x = 0; x < c; ++x)
        for(int y = 0; y < c; ++y)
        for(int z = 0; z < c; ++z)
        for(int w = 0; w < c; ++w) {
            int code = ((x * c + y) * c + z) * c + w;
            int cnt = (x == y) + (y == w) + (w == z) + (x == z);

            if(cnt <= k) {
                K.ret[all][idx(code, cnt)] = 1;
            }
        }

        int temp = c * c * c * c;
        for(int i = 0; i < temp; ++i) {
            for(int x = 0; x <= k; ++x) {
                B.ret[idx(i, x)][all] = 1;
            }

            for(int j = 0; j < temp; ++j) {
                int tot = get_cnt(i, j) + get_cnt(j);
                for(int x = 0; x <= k - tot; ++x) {
                    B.ret[idx(i, x)][idx(j, x + tot)] = 1;
                }
            }
        }

        Matrix res;
        while(q--) {
            static ll h; read(h);
            res = K * (B ^ h);
            printf("%d\n", res.ret[all][all]);
        }
    }

    return 0;
}
