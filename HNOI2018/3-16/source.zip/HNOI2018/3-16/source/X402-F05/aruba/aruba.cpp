#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int Mod = 998244353;

int Pow(int x, int e) {
	int ret = 1;
	while (e) {
		if (e & 1) ret = 1ll * ret * x % Mod;
		x = 1ll * x * x % Mod;
		e >>= 1;
	}
	return ret;
}

int sz;

struct Matrix {

	const static int N = 125;

	int A[N][N];

	int* operator [] (int idx) { return A[idx]; }

	Matrix operator * (Matrix& B) {
		static Matrix C;
		For(i, 0, sz) For(j, 0, sz) C[i][j] = 0;
		For(i, 0, sz) For(j, 0, sz) For(k, 0, sz)
			C[i][k] = (C[i][k] + 1ll * A[i][j] * B[j][k]) % Mod;
		return C;
	}
}A;

const int N = 20;

int c, k, n;
int col[10];
int id[5][5][5][5], pre[N], inism[N];

void DFS_init(int i, int mx = 0, int coe = 1) {
	if (i == 5) {
		id[col[1]][col[2]][col[3]][col[4]] = n++;
		pre[n - 1] = coe;
		inism[n - 1] = (col[1] == col[2]) + (col[2] == col[4]) + (col[1] == col[3]) + (col[3] == col[4]);
		return;
	}
	For(j, 1, min(c, mx + 1)) {
		col[i] = j;
		DFS_init(i + 1, max(mx, j), 1ll * coe * (j == mx + 1 ? c - mx : 1) % Mod);
	}
}

int G[N][N][N];

void DFS_trans(int x, int mx = 0) {
	if (x == 9) {

		int u = id[col[1]][col[2]][col[3]][col[4]], val[9] = {0};
		val[5] = 1;
		int nmx = 1;
		For(i, 6, 8) {
			val[i] = nmx + 1;
			For(j, 5, i - 1) if (col[i] == col[j]) {
				val[i] = val[j]; break;
			}
			if (val[i] > nmx) nmx = val[i];
		}
		int v = id[val[5]][val[6]][val[7]][val[8]];
		
		int diff = 0, same = (col[5] == col[6]) + (col[5] == col[7]) + (col[7] == col[8]) + (col[6] == col[8]);
		For(i, 5, 8) {
			++diff;
			same += col[i] == col[i - 4];
			For(j, 1, i - 1) if (col[i] == col[j]) { --diff; break; }
		}
	
		int ava = c - max(col[2], max(col[3], col[4])), coe = 1;
		For(i, 0, diff - 1) coe = 1ll * coe * (ava - i) % Mod;

		(G[u][v][same] += coe) %= Mod;

		return;
	}
	For(j, 1, min(c, mx + 1)) {
		col[x] = j;
		DFS_trans(x + 1, max(mx, j));
	}
}

Matrix pwr[62];

int main() {

	freopen("aruba.in", "r", stdin);
	freopen("aruba.out", "w", stdout);

	scanf("%d%d", &c, &k);
	DFS_init(1);
	DFS_trans(1);

	sz = (k + 1) * n;
	For(i, 0, n - 1) For(j, 0, n - 1) For(d, 0, k)
		For(s, 0, k - d) {
			int u = s * n + i, v = (s + d) * n + j;
			(A[u][v] += G[i][j][d]) %= Mod;
			(A[u][sz] += G[i][j][d]) %= Mod;
		}
	A[sz][sz] = 1;

	pwr[0] = A;
	For(i, 1, 60) pwr[i] = pwr[i - 1] * pwr[i - 1]; 

	int q;
	scanf("%d", &q);
	while (q--) {

		int vec[125] = {0};
		For(i, 0, n - 1) {
			int u = inism[i] * n + i;
			if (u < sz)
				vec[u] = pre[i], vec[sz] = (vec[sz] + vec[u]) % Mod;
		}

		long long h;
		scanf("%lld", &h);
		--h;
		For(i, 0, 60) if (h & (1ll << i)) {
			int nxt[125] = {0};
			For(u, 0, sz) For(v, 0, sz)
				nxt[v] = (nxt[v] + 1ll * vec[u] * pwr[i][u][v]) % Mod;
			For(u, 0, sz) vec[u] = nxt[u];
		}
		printf("%d\n", vec[sz]);

	}

	return 0;
}
