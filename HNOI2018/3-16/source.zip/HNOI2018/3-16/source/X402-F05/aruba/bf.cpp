#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int H = 2010;
const int Mod = 998244353;

void add(int &x, int y) {
	x += y;
	if (x >= Mod) x -= Mod;
}

int col[5], now[5];
int dp[H][4][1010][10];
int f[H];

int main() {

	freopen("aruba.in", "r", stdin);
	freopen("aruba.ans", "w", stdout);

	int c, k;
	scanf("%d%d", &c, &k);
	int mx = c * c * c * c - 1;

	dp[1][0][0][0] = 1;
	For(i, 1, 2000) {
		For(j, 0, 3) {
#define nxt (j == 3 ? dp[i + 1][0] : dp[i][j + 1])
			For(C, 0, mx) For(s, 0, k) {
				if (i > 1 && j == 0) add(f[i - 1], dp[i][j][C][s]);
				int val = C;
				For(u, 0, c - 1) col[u] = val % c, val /= c;
				For(u, 0, c - 1) {
					swap(col[j], u);
					int ns = s, nc = 0;
					Forr(v, 3, 0) nc = nc * c + col[v];
					if (i != 1) ns += col[j] == u;
					if (j == 1 || j == 2) ns += col[j] == col[0];
					else if (j == 3) ns += (col[j] == col[1]) + (col[j] == col[2]);
					if (ns <= k) add(nxt[nc][ns], dp[i][j][C][s]);
					
					swap(col[j], u);
				}
			}
		}
	}
	For(i, 1, 2000) add(f[i], f[i - 1]);

	int q;
	scanf("%d", &q);
	while (q--) {
		int h;
		scanf("%d", &h);
		printf("%d\n", f[h]);
	}

	return 0;
}
