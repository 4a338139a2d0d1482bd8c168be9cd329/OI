#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1.2e6 + 10;

typedef long long LL;

int ta[N], tb[N];
int va[N], vb[N];
int cnt[N];
int n, m;

int main() {

	freopen("robot.in", "r", stdin);
	freopen("robot.ans", "w", stdout);

	int Case;
	scanf("%d", &Case);
	
	while (Case--) {
		
		int T = 0;
		scanf("%d", &n);
		For(i, 1, n) scanf("%d%d", &va[i], &ta[i]), T += ta[i];
		scanf("%d", &m);
		For(i, 1, m) scanf("%d%d", &vb[i], &tb[i]);
	
		++ta[n], ++tb[m];
		memset(cnt, 0, sizeof cnt);
		int idx = 600000;

		int p = 1, q = 1;
		For(i, 0, T) {
			cnt[idx]++;
			idx += va[p] - vb[q];
			--ta[p], --tb[q];
			if (!ta[p]) ++p;
			if (!tb[q]) ++q;
		}

		int ans = 0;
		For(i, 1, 1200000) ans = max(ans, cnt[i]);
		printf("%d\n", ans);

	}

	return 0;
}
