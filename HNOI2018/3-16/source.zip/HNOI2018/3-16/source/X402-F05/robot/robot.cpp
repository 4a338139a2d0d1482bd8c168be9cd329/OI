#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 2e5 + 10;

typedef long long LL;

LL ta[N], tb[N];
int va[N], vb[N];
int n, m, c;

struct addv {
	LL x, w;
	int ty;

	bool operator < (const addv &A) const {
		return x < A.x;
	}

}A[N << 1];

int main() {

	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);

	int Case;
	scanf("%d", &Case);
	
	while (Case--) {
		
		scanf("%d", &n);
		For(i, 1, n) scanf("%d%lld", &va[i], &ta[i]);
		scanf("%d", &m);
		For(i, 1, m) scanf("%d%lld", &vb[i], &tb[i]);
	
		++ta[n], ++tb[m];
		c = 0;
		int p = 1, q = 1;
		LL dis = 0;
		while (p <= n && q <= m) {
			LL T = min(ta[p], tb[q]);
			int dv = va[p] - vb[q];

			LL now = dis, len = T - 1;
			int ty = dv;
			if (ty < 0) {
				ty = -ty;
				now += dv * len;
			}

			if (ty == 0) A[++c] = (addv){now, T, 0}, A[++c] = (addv){now + 1, -T, 0};
			else if (ty == 1) A[++c] = (addv){now, 1, 0}, A[++c] = (addv){now + T, -1, 0};
			else A[++c] = (addv){now, 1, 1}, A[++c] = (addv){now + T * 2, -1, 1};
			
			dis += T * dv;
			ta[p] -= T, tb[q] -= T;
			if (!ta[p]) ++p;
			if (!tb[q]) ++q;
		}

		sort(A + 1, A + c + 1);
		LL ans = 0;
		LL odd = 0, even = 0, all = 0;
		For(i, 1, c) {
			int r = i + 1;
			LL x = A[i].x;
			while (r <= c && A[r].x == x) ++r;
			For(j, i, r - 1) {
				if (A[j].ty == 0) all += A[j].w;
				else if (x % 2) odd += A[j].w;
				else even += A[j].w;
			}
			ans = max(ans, (x % 2 ? odd : even) + all);
			if (x + 1 != A[r].x) ans = max(ans, (x % 2 ? even : odd) + all);
			i = r - 1;
		}
		printf("%lld\n", ans);

	}

	return 0;
}
