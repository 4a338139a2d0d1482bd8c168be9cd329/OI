#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("robot.in", "w", stdout);

	int T = 300;
	printf("%d\n", T);
	srand(time(0));

	while (T--) {
		
		int n = rand() % 10 ? 100 : 100000;
		int tm = n * 2.5, sm = 0;

		printf("%d\n", n);
		For(i, 1, n) {
			int t = randint(1, 3);
			printf("%d %d\n", randint(-1, 1), i == n ? tm - sm : t);
			sm += t;
		}

		printf("%d\n", n);
		sm = 0;
		For(i, 1, n) {
			int t = randint(1, 3);
			printf("%d %d\n", randint(-1, 1), i == n ? tm - sm : t);
			sm += t;
		}
	
	}

	return 0;
}
