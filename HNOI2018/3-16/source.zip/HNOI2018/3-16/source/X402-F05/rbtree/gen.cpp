#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int main() {

	freopen("rbtree.in", "w", stdout);

	int T = 100000, n = 10;

	srand(time(0));
	printf("%d\n", T);

	while (T--) {
		printf("%d\n", n);
		For(i, 2, n) printf("%d %d\n", rand() % (i - 1) + 1, i);

		printf("%d\n", n);
		For(i, 1, n) 
			if (rand() % (i / 2 + 1) == 0) 
				printf("%d %d\n", i, rand() % (n - i + 2)); 
			else printf("%d 0\n", i);
		printf("%d\n", n);
		For(i, 1, n) 
			if (rand() % ((n - i) / 2 + 1) == 0) 
				printf("%d %d\n", i, rand() % i); 
			else printf("%d 0\n", i);
	}

	return 0;
}
