#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;

int Begin[N], Next[N << 1], to[N << 1], e;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n, tot;
int in[N], out[N];
int sz[N];
bool mark[N];

bool DFS(int o, int f = 0) {
	sz[o] = mark[o];
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f) continue;
		if (!DFS(u, o)) return false;
		sz[o] += sz[u];
	}
	if (sz[o] < in[o]) return false;
	if (tot - sz[o] < out[o]) return false;
	return true;
}

int main() {

	freopen("rbtree.in", "r", stdin);
	freopen("rbtree.ans", "w", stdout);

	int Case;
	scanf("%d", &Case);

	while (Case--) {
		
		scanf("%d", &n);
		e = 1;
		For(i, 1, n) Begin[i] = 0;
		For(i, 2, n) {
			int u, v;
			scanf("%d%d", &u, &v);
			add(u, v), add(v, u);
		}
		For(i, 1, n) in[i] = out[i] = 0;

		int a, b;
		scanf("%d", &a);
		For(i, 1, a) {
			int o, lim;
			scanf("%d%d", &o, &lim);
			in[o] = lim;
		}
		scanf("%d", &b);
		For(i, 1, b) {
			int o, lim;
			scanf("%d%d", &o, &lim);
			out[o] = lim;
		}

		int ans = n + 1;
		For(i, 0, (1 << n) - 1) {
			tot = __builtin_popcount(i);
			if (tot >= ans) continue;
			For(j, 0, n - 1) mark[j + 1] = i & (1 << j);
			if (DFS(1)) ans = tot;
		}
		printf("%d\n", ans > n ? -1 : ans);

	}

	return 0;
}
