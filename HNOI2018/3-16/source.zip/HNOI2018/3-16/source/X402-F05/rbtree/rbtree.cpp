#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;

int Begin[N], Next[N << 1], to[N << 1], e;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n;
int in[N], out[N];
int L[N], R[N];

bool DFS(int o, int f) {
	int suml = 0, sumr = 1;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f) continue;
		if (!DFS(u, o)) return false;
		suml += L[u], sumr += R[u];
	}
	L[o] = max(L[o], suml), R[o] = min(R[o], sumr);
	return L[o] <= R[o];
}

bool check(int x) {
	For(i, 1, n) L[i] = in[i], R[i] = x - out[i];	
	if (!DFS(1, 0)) return false;
	return L[1] <= x && x <= R[1];
}

int main() {

	freopen("rbtree.in", "r", stdin);
	freopen("rbtree.out", "w", stdout);

	int Case;
	scanf("%d", &Case);

	while (Case--) {
		
		scanf("%d", &n);
		e = 1;
		For(i, 1, n) Begin[i] = 0;
		For(i, 2, n) {
			int u, v;
			scanf("%d%d", &u, &v);
			add(u, v), add(v, u);
		}
		For(i, 1, n) in[i] = out[i] = 0;

		int a, b;
		scanf("%d", &a);
		For(i, 1, a) {
			int o, lim;
			scanf("%d%d", &o, &lim);
			in[o] = lim;
		}
		scanf("%d", &b);
		For(i, 1, b) {
			int o, lim;
			scanf("%d%d", &o, &lim);
			out[o] = lim;
		}

		if (!check(n)) {
			puts("-1");
		} else {
			int l = 0, r = n;
			while (l < r) {
				int mid = (l + r) >> 1;
				if (check(mid)) r = mid;
				else l = mid + 1;
			}
			printf("%d\n", l);
		}

	}

	return 0;
}
