#include<bits/stdc++.h>
#define N 1000100
using namespace std;
inline void read(long long &x)
{
	x=0ll;
	static long long p;p=1ll;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1ll)+(x<<3ll)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
long long n,k;
long long fac[N],inv[N],mic[N];
long long ksm(long long x,long long mc)
{
	long long tmp=x%mod;
	long long res=1ll;
	while(mc)
	{
		if(mc&1ll)res=res*tmp%mod;
		tmp=tmp*tmp%mod;
		mc/=2;
	}
	return res;
}
long long C(long long i,long long j)
{
	return fac[i]*inv[j]%mod*inv[i-j]%mod;
}
long long ster[6000][6000];
void Sterling()
{
	ster[1][1]=1ll;
	for(long long i=2;i<=k;i++)
		for(long long j=1;j<=i;j++)
			ster[i][j]=(ster[i-1][j-1]%mod+j*ster[i-1][j]%mod)%mod;
	return ;
}
int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	read(n);read(k);
	if(n<=1000000)
	{
		fac[0]=fac[1]=1ll;
		mic[0]=0;mic[1]=1ll;
		for(long long i=2ll;i<=n;i++)
			fac[i]=fac[i-1ll]*i%mod,mic[i]=ksm(i,k);
		inv[n]=ksm(fac[n],mod-2ll);
		inv[1]=inv[0]=1ll;
		for(long long i=n-1;i>=2ll;i--)inv[i]=inv[i+1ll]*(i+1ll)%mod;
		long long ans=0ll;
		for(long long i=1ll;i<=n;i++)
			(ans+=C(n,i)*mic[i]%mod)%=mod;
		printf("%lld\n",ans);
	}
	else if(k==0)printf("%lld\n",((ksm(2ll,n)-1ll)%mod+mod)%mod);
	else if(k==1)printf("%lld\n",n*ksm(2ll,n-1)%mod);
	else 
	{
		long long ans=0,now=1;
		Sterling();
		for(long long i=0;i<=k;i++)
		{
			(ans+=1ll*ster[k][i]*ksm(2,n-i)%mod*now%mod)%=mod;
			(now*=(n-i))%=mod;
		}
		printf("%lld\n",ans%mod);
	}
	return 0;
}
