#include<bits/stdc++.h>
#define N 100100
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
const long long mod=998244353;
string s;
long long n,ans;
long long ksm(long long x,long long mc)
{
	long long tmp=x%mod;
	long long res=1ll;
	while(mc)
	{
		if(mc&1)res=res*tmp%mod;
		tmp=tmp*tmp%mod;
		mc>>=1;
	}
	return res;
}
void dfs(long long l,long long r,long long k)
{
	long long mid=(l+r)>>1;
	if(l>=r)
	{
		if(k&1)return ;
		else ans++;
		return ;
	}
	for(long long i=l;i<=mid;i++)
	{
		static string x;x=s.substr(l-1,i-l+1);
		static string y;y=s.substr(r-i+l-1,i-l+1);
		if(x==y)dfs(i+1,r-i+l-1,k+2);
	}
}
int main()
{
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	cin>>s;
	n=s.size();
	if(n&1)return cout<<0<<endl,0;
	long long pd=1;
	for(long long i=0;i<n;i++)if(s[i]!='a'){pd=0;break;}
	if(pd)return printf("%lld\n",ksm(2,n/2-1)),0;
	dfs(1,n,0);
	printf("%lld\n",ans);
	return 0;
}
