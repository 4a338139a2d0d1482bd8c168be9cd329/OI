#include<bits/stdc++.h>
#define N 200100
using namespace std;
inline void read(long long &x)
{
	x=0;
	static long long p;p=1;
	static char c;c=getchar();
	while(!isdigit(c)){if(c=='-')p=-1;c=getchar();}
	while(isdigit(c)) {x=(x<<1)+(x<<3)+(c-48);c=getchar();}
	x*=p;
}
long long n,e;
long long A[N],B[N];
long long to[N],beg[N],nex[N];
void add(long long x,long long y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
long long ans;
vector<long long>vec[N];
void dfs1(long long x,long long fa)
{
	vec[x].push_back(x);
	for(long long i=beg[x];i;i=nex[i])
	{
		long long y=to[i];
		if(y==fa)continue;
		dfs1(y,x);
		long long len=vec[y].size();
		for(long long j=0;j<len;j++)vec[x].push_back(vec[y][j]);
	}
}
void dfs2(long long x,long long sum)
{
	long long len=vec[x].size();
	if(sum>ans)return ;
	if(len==1){ans=min(ans,sum);return ;}
	for(long long i=0;i<len;i++)
		if(vec[x][i]!=x)
		dfs2(vec[x][i],sum+A[x]*B[vec[x][i]]);
}
long long dp[N],Ans[N];
void dfss(long long x,long long fa)
{
	long long ans=0x7f7f7f7f;
	dp[x]=A[fa];
	for(long long i=beg[x];i;i=nex[i])
	{
		long long y=to[i];
		if(y==fa)continue;
		dfss(y,x);
		ans=min(ans,dp[y]);
		if(dp[y]<0)dp[x]+=dp[y];
	}
	if(ans==0x7f7f7f7f)ans=0;
	Ans[x]=ans;
}
int main()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	read(n);
	long long pd=1;
	for(long long i=1;i<=n;i++)read(A[i]);
	for(long long i=1;i<=n;i++)
	{
		read(B[i]);
		if(B[i]!=1)pd=0;
	}
	for(long long i=1;i<=n-1;i++)
	{
		static long long x,y;
		read(x);read(y);
		add(x,y);
		add(y,x);
	}
	if(pd)
	{
		dfss(1,0);
		for(long long i=1;i<=n;i++)
			printf("%lld\n",Ans[i]);
		return 0;
	}
	else
	{
		dfs1(1,0);
		for(long long i=1;i<=n;i++)
		{
			ans=0x7f7f7f7f;
			dfs2(i,0);
			printf("%lld\n",ans);
		}
	}
	return 0;
}
