#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn=1e5+10;
int n,m;
vector<int> zero,G[maxn];
int flag0,flag1;
ll f[maxn],mn[maxn];
int a[maxn],b[maxn];
void dfs(int u,vector<int> fa){
	fa.push_back(u);
	for(int i=0;i<G[u].size();++i)
		if(G[u][i]!=fa[fa.size()-2])dfs(G[u][i],fa);
	if(G[u].size()==1&&u!=1)f[u]=0;
	for(int i=0;i<fa.size()-1;++i)
		f[fa[i]]=min(f[fa[i]],f[u]+1ll*a[fa[i]]*b[u]);
}
void dfs1(int u,vector<int> fa){
	fa.push_back(u);
	for(int i=0;i<G[u].size();++i){
		if(G[u][i]!=fa[fa.size()-2]){
			dfs1(G[u][i],fa);
			mn[u]=min(mn[u],mn[G[u][i]]);
		}
	}
	if(G[u].size()==1&&u!=1)mn[u]=f[u]=0;
	else f[u]=mn[u]+a[u],mn[u]=min(f[u],mn[u]);
}
void solve(){
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",a+i);
	}
	for(int i=1;i<=n;++i){
		scanf("%d",b+i);
		if(b[i]!=1){
			flag0=1;
		}
		f[i]=1e16;
	}
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	if(!flag0){
		for(int i=1;i<=n;++i){
			mn[i]=f[i]=1e16;
		}
		dfs1(1,zero);
		for(int i=1;i<=n;++i){
			printf("%d\n",f[i]);
		}
		exit(0);
	}
	dfs(1,zero);
	for(int i=1;i<=n;++i){
		printf("%d\n",f[i]);
	}
	exit(0);
}
int main(){
	freopen("ct.in","r",stdin);freopen("ct.out","w",stdout);
	
	solve();
	
	return 0;
}
/*
6
2 10 -1 -2 6 4
1 1 1 1 1 1
2 3
2 1
4 3
4 5
6 3
*/
