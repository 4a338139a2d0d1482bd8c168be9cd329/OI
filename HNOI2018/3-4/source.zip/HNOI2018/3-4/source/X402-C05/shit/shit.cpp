#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=1e5+10,mod=998244353,X=233;
ll fpm(ll a,ll b){
	ll res=1ll;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
char s[maxn];
int f[maxn];
int n,hn;
ll x[maxn],suf[maxn];
bool same(int ed,int st){
	int St=n-ed+1,Ed=n-st+1;
	--St,--st;
	int a=1ll*(suf[ed]-suf[st]*x[ed-st]%mod+mod)%mod;
	int b=1ll*(suf[Ed]-suf[St]*x[Ed-St]%mod+mod)%mod;
	return a==b;
}
void init(){
	f[0]=1;
	x[0]=1;
	for(int i=1;i<=n;++i){
		x[i]=x[i-1]*X%mod;
		suf[i]=(suf[i-1]*X%mod+s[i])%mod;
	}
}
void solve(){
	scanf("%s",s+1);
	n=strlen(s+1);
	hn=n/2;
	for(int i=1;i<=n;++i){
		if(s[i]!='a')goto G;
	}
	cout<<fpm(2,hn-1)<<endl;
	exit(0);
	G:;
	init();
	for(int i=1;i<=hn;++i)
		for(int j=1;j<=i;++j)
			if(same(i,j)){
				(f[i]+=f[j-1])%=mod;
			}
	cout<<f[hn]<<endl;
}
int main(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	solve();
	
	return 0;
}
