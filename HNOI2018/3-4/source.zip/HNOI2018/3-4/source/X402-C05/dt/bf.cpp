#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=998244353,maxn=5010;

int S[maxn][maxn],C[maxn][maxn];

void init(){
	for(int i=0;i<maxn;++i)S[i][0]=0;
	for(int i=0;i<maxn;++i)S[i][i]=1;
	for(int i=1;i<maxn;++i){
		for(int j=1;j<i;++j){
			S[i][j]=(S[i-1][j-1]+1ll*i*S[i-1][j]%mod)%mod;
		}
	}
//	for(int i=0;i<10;++i,cerr<<endl){
//		for(int j=0;j<=i;++j){
//			cerr<<S[i][j]<<" ";
//		}
//	}
	for(int i=0;i<maxn;++i)C[i][0]=C[i][i]=1;
	for(int i=1;i<maxn;++i){
		for(int j=1;j<i;++j){
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
		}
	}
}
int n,k,ans;
ll fpm(ll a,ll b){
	ll res=1ll;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
void solve(){
	//scanf("%d%d",&n,&k);
	init();
//	for(int pwr=0;pwr<=5;++pwr){
//	for(int p=1,ans=0;p<=10;++p){
//		ans=0;
//		for(int i=0,sgn=1;i<=pwr;sgn=-sgn,++i){
//			ans+=C[pwr][i]*sgn*S[pwr][i]*fpm(p,pwr);
//		}
//		cout<<ans<<" ";
//	}
//	cout<<endl;
//	}
	while(~scanf("%d%d",&n,&k)){
	ans=0;
	for(int i=1;i<=n;++i){
		(ans+=C[n][i]*fpm(i,k)%mod)%=mod;
	}
	cout<<ans<<endl;
	}
}
int main(){
	//freopen("dt.in","r",stdin);freopen("dt.out","w",stdout);
	solve();
	
	return 0;
}
