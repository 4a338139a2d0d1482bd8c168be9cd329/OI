//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//const int mod=998244353,maxn=5010;
//
//int S[maxn][maxn],C[maxn][maxn];
//
//void init(){
//	for(int i=0;i<maxn;++i)S[i][0]=0;
//	for(int i=0;i<maxn;++i)S[i][i]=1;
//	for(int i=1;i<maxn;++i){
//		for(int j=1;j<i;++j){
//			S[i][j]=(S[i-1][j-1]+1ll*j*S[i-1][j]%mod)%mod;
//		}
//	}
//	for(int i=0;i<10;++i,cerr<<endl){
//		for(int j=0;j<=i;++j){
//			cerr<<S[i][j]<<" ";
//		}
//	}
//	for(int i=0;i<maxn;++i)C[i][0]=C[i][i]=1;
//	for(int i=1;i<maxn;++i){
//		for(int j=1;j<i;++j){
//			C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
//		}
//	}
//}
//ll fpm(ll a,ll b){
//	ll res=1ll;
//	for(;b;b>>=1,a=a*a%mod)
//		if(b&1)res=res*a%mod;
//	return res;
//}
//void solve(){
//	//scanf("%d%d",&n,&k);
//	init();
//	for(int pwr=0;pwr<=5;++pwr){
//	for(int p=1,ans=0;p<=10;++p){
//		ans=0;
//		for(int i=0,sgn=pwr&1?-1:1;i<=pwr;sgn=-sgn,++i){
//			ans+=C[pwr][i]*sgn*S[pwr][i]*fpm(p,pwr);
//		}
//		cout<<ans<<" ";
//	}
//	cout<<endl;
//	}
//}
//int main(){
//	//freopen("dt.in","r",stdin);freopen("dt.out","w",stdout);
//	solve();
//	
//	return 0;
//}
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=998244353;
ll fac[1000010],inv[1000010];
ll fpm(ll a,ll b){
	ll res=1ll;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
void init(int n){
	fac[0]=1;
	for(int i=1;i<=n;++i)fac[i]=fac[i-1]*i%mod;
	inv[n]=fpm(fac[n],mod-2);
	for(int i=n;i;--i)inv[i-1]=inv[i]*i%mod;
}
ll C(ll n,ll m){
	return fac[n]*inv[m]%mod*inv[n-m]%mod;
}
int n,m,ans;
void solve(){
	scanf("%d%d",&n,&m);
	if(m==0){
		cout<<(fpm(2,n)-1+mod)%mod<<endl;
		exit(0);
	}
	if(m==1){
		cout<<(fpm(2,n)*n%mod*fpm(2,mod-2)%mod)<<endl;
		exit(0);
	}
	init(n);
	for(int i=1;i<=n;++i){
		(ans+=1ll*C(n,i)*fpm(i,m)%mod)%=mod;
	}
	cout<<ans<<endl;
}
int main(){
	freopen("dt.in","r",stdin);freopen("dt.out","w",stdout);
	solve();
	
	return 0;
}
