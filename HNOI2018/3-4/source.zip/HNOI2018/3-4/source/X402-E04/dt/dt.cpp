#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 5010, INF = 0x3f3f3f3f, Mod = 998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
#endif 
}
ll qpow(ll a, ll b){
	ll ret = 1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
int S[N][N];

int n, k;
void init(){
	read(n), read(k);
	S[0][0] = 1;
	For(i, 1, k)
		For(j, 1, i)
			S[i][j] = (1ll * j * S[i-1][j] + S[i-1][j-1]) % Mod;
}
void solve(){
	int t = 1, ans = 0;
	For(j, 0, min(n, k)){
		ans = (ans + 1ll * S[k][j] * t % Mod * qpow(2, n - j) % Mod) % Mod;
		t = 1ll * t * (n - j) % Mod;
	}
	printf("%d\n", ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
