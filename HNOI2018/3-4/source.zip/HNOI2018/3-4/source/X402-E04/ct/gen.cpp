#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
int M = 100000;

int main(){
	freopen("ct.in","w",stdout);
	int n = 100000;
	srand(time(0));
	printf("%d\n",n);
	For(i, 1, n)printf("%d ", rand()%(M/2) - rand()%(M/2));
	For(i, 1, n)printf("%d ", rand()%(M/2) - rand()%(M/2));
	For(i,2, n){
		printf("%d %d\n",i, rand()%(i-1)+1);
	}
	return 0;
}
