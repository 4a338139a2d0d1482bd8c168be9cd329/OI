#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N = 1e5 + 10, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();int f = 0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x = f?-x:x;
}
inline void file(){
	freopen("ct.in","r",stdin);
	freopen("BF.out","w",stdout);
}
struct seg{
	#define mid ((l+r)>>1)
	#define lc h<<1
	#define rc h<<1|1
	#define Lc lc,l,mid
	#define Rc rc,mid+1,r
	ll Min[N<<2];
	inline void Pushup(int h){
		Min[h] = min(Min[lc], Min[rc]);
	}
	void Modify(int h, int l, int r, int p, ll v){
		if(l == r)return void(Min[h] = v);
		if(p <= mid)Modify(Lc, p, v);
		else Modify(Rc, p, v);
		Pushup(h);
	}
	ll Query(int h, int l, int r, int L, int R){
		if(L<=l && r<=R)return Min[h];
		ll ret = 1e18;
		if(L <= mid)ret = min(ret, Query(Lc, L, R));
		if(R >  mid)ret = min(ret, Query(Rc, L, R));
		return ret;
	}
}T;

int n;
ll A[N], B[N], dp[N];
int to[N<<1], Next[N<<1], e, Begin[N], fa[N];
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
void init(){
	read(n);
	For(i, 1, n)read(A[i]);
	For(i, 1, n)read(B[i]);
	For(i, 1, n - 1){
		int x, y;
		read(x), read(y);
		add(x, y), add(y, x);
	}
}
int In[N], Out[N], dfs_cnt, ver[N];
void dfs(int u, int f){
	In[u] = ++dfs_cnt; ver[dfs_cnt] = u;
	int ok = 1;
	Rep(i, u)if(v^f)dfs(v, u), ok = 0;
	Out[u] = dfs_cnt;
	ll ret = 1e18;
	if(ok)ret = 0;
	if(n <= 5000){
		For(i, In[u] + 1, Out[u]) ret = min(ret, dp[ver[i]] + A[u] * B[ver[i]]);
		dp[u] = ret;
	}else {
		dp[u] = ok ? 0 : A[u] + T.Query(1, 1, n, In[u] + 1, Out[u]); 
		if(!ok)T.Modify(1, 1, n, In[u], dp[u]);
	}
}
void solve(){
	dfs(1, 0);
	For(i, 1, n)
		printf("%lld\n",dp[i]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
