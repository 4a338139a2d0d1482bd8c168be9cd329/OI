#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
#define x first
#define y second
#define pii pair<ll,ll> 
#define pb push_back
#define SZ(x) ((int)x.size())
#define All(x) x.begin(),x.end()
const int N = 400010, INF = 0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(!isdigit(c))f|=(c=='-'),c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
	x=f?-x:x;
}
inline void file(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
}
ll Dot(pii A,pii B){
	return 1ll*A.x*B.x+1ll*A.y*B.y;
}
int done[N*2],lst[20];
struct Segt{
	#define Mid ((l+r)>>1)
	#define lc h<<1
	#define rc h<<1|1
	#define Lc h<<1,l,Mid
	#define Rc h<<1|1,Mid+1,r
	vector<pii >t[N*2];
	void Rebuild(int h){
		done[h]=1;
		t[h].clear();
		t[h].resize(SZ(t[lc])+SZ(t[rc]));
		merge(All(t[lc]),All(t[rc]),t[h].begin());
		vector<pii>q;
		For(i,0,SZ(t[h])-1){
			int top=SZ(q)-1;
			while(top>=1&&1ll*(t[h][i].y-q[top-1].y)*(q[top].x-q[top-1].x)>=1ll*(q[top].y-q[top-1].y)*(t[h][i].x-q[top-1].x))q.pop_back(),top--;
			q.pb(t[h][i]);
		}
		t[h]=q;
	}
	void add(int h,int l,int r,int pos,pii v){
		if(l==r){
			t[h].pb(v);
			done[h] = 1;
			return ;
		}
		if(pos<=Mid)add(Lc,pos,v);
		else add(Rc,pos,v);
		if(done[lc] && done[rc] && !done[h])Rebuild(h);
	}
	ll Get(int h,pii v){
		int ans=0,L=1,R=SZ(t[h])-1;
		while(L<=R){
			int mid=(L+R)>>1;
			if(Dot(v,t[h][mid])>=Dot(v,t[h][mid-1]))ans=mid,L=mid+1;
			else R=mid-1;
		}
		return Dot(v,t[h][ans]);
	}
	ll Query(int h,int l,int r,int L,int R,pii v){
		if(L<=l&&r<=R&&done[h])return Get(h,v);
		ll ret=-1e18;
		if(L<=Mid)ret=max(ret,Query(Lc,L,R,v));
		if(R> Mid)ret=max(ret,Query(Rc,L,R,v));
		return ret;
	}
}T;
int n, Begin[N], Next[N<<1], to[N<<1], e, In[N], Out[N], dfs_cnt;
ll A[N], B[N], dp[N];
inline void add(int x, int y){
	to[++e] = y, Next[e] = Begin[x], Begin[x] = e;
}
void init(){
	read(n);
	For(i, 1, n)read(A[i]);
	For(i, 1, n)read(B[i]);
	For(i, 1, n - 1){
		int x, y;
		read(x), read(y);
		add(x, y), add(y, x);
	}
}
void dfs(int u, int f){
	In[u] = ++dfs_cnt;
	Rep(i, u)
		if(v^f)dfs(v, u);
	Out[u] = dfs_cnt;
	if(In[u]^Out[u])dp[u] = -T.Query(1, 1, n, In[u] + 1, Out[u], pii(A[u], 1ll));
	T.add(1, 1, n, In[u], pii(-B[u], -dp[u]));
}
void solve(){
	dfs(1, 0);
	For(i, 1, n)printf("%lld\n", dp[i]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
