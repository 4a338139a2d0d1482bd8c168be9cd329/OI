#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N = 2010, INF = 0x3f3f3f3f, Mod = 998244353;
const ll x = 233, x1 = 179;
template<class T>void read(T &x){
	x = 0;char c = getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
}
int n;
char s[N];
int dp[N];
ll h[N], h1[N], pw[N], pw1[N];
inline int H(int l, int r){
	return (h[l] + Mod - pw[r - l + 1] * h[r + 1] % Mod) % Mod;
}
inline int H1(int l, int r){
	return (h1[l] + Mod - pw1[r - l + 1] * h1[r + 1] % Mod) % Mod;
}
void init(){
	scanf("%s", s + 1);
	n = strlen(s + 1);
	pw[0] = pw1[0] = 1;
	For(i, 1, n)	
		pw[i] = pw[i-1] * x % Mod, pw1[i] = pw1[i-1] * x1 % Mod;
	Forr(i, n, 1){
		h[i] = (h[i + 1] * x + s[i]-'a') % Mod;
		h1[i] = (h1[i + 1] * x1 + s[i]-'a') % Mod;
	}
	if(n & 1)puts("0"), exit(0);
}


bool check(int x, int y){
	int l = n - y + 1, r = n - x + 1;
	if(H1(l, r) == H1(x, y) && H(l, r) == H(x, y))return 1;
	return 0;
}
ll qpow(ll a, ll b){
	ll ret = 1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
inline bool check(){
	For(i, 1, n)if(s[i] != 'a')return 0;
	return 1;
}
void solve(){
	if(check())
		return void(printf("%lld\n", qpow(2, n/2 - 1)));
	dp[n / 2] = 1;
	For(i, n / 2 + 1, n)
		For(j, n / 2 + 1, i)
			if(check(j, i))
				dp[i] = (dp[i] + dp[j - 1]) % Mod;
	printf("%d\n", dp[n]);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
 
