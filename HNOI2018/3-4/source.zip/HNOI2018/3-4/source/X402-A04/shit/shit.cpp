#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef unsigned long long ul;

const int N=100050;
const int mod=998244353;
const ul bas=1e9+7;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int f[N],n;
char s[N];
ul Hash[N],pw[N];

inline ul gethash(int l,int r) {return Hash[r]-Hash[l-1]*pw[r-l+1];}

void wj()
{
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
}
int main()
{
	wj();
	clock_t sta=clock();
	scanf("%s",s+1); n=strlen(s+1);
	bool allsame=1;
	for(int i=1;i<n;++i) if(s[i]!=s[i+1]) {allsame=0;break;}
	if(allsame) {printf("%lld\n",qpow(2,n/2-1));return 0;}

	f[n/2+1]=1;
	for(int i=1;i<=n;++i) Hash[i]=Hash[i-1]*bas+s[i];
	pw[0]=1;
	for(int i=1;i<=n;++i) pw[i]=pw[i-1]*bas;
	if(n>10000)
	{
		for(int i=n/2+1;i>=2;--i) if(f[i])
		{
			for(int k=1;i-k>=1;++k)
				//if(gethash(i-k,i-1)==gethash(n-i+1+1,n-i+1+k)) f[i-k]=(f[i-k]+f[i])%mod;
				if((Hash[n-i+1]-Hash[i-k-1])*pw[k]==Hash[n-i+1+k]-Hash[i-1])
					f[i-k]=(f[i-k]+f[i])%mod;
		}
		printf("%d\n",f[1]);
		clock_t fin=clock();
		//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
		return 0;
	}
	for(int i=n>>1;i;--i)
	{
		for(int k=0,lim=(n-2*i)/2;k<=lim;++k)
			if(gethash(i,i+k)==gethash(n-i+1-k,n-i+1)) f[i]=(f[i]+f[i+k+1])%mod;
	}
	printf("%d\n",f[1]);
	return 0;
}
