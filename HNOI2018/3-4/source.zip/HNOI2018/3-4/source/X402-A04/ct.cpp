#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const ll inf=1e18;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}

struct point
{
	ll x,y;
	point(ll x=0,ll y=0):x(x),y(y) { }
};
inline point operator + (point a,point b) {return point(a.x+b.x,a.y+b.y);}
inline point operator - (point a,point b) {return point(a.x-b.x,a.y-b.y);}
inline ll dot(point a,point b) {return a.x*b.x+a.y*b.y;}
inline ll cross(point a,point b) {return a.x*b.y-b.x*a.y;}
inline bool operator < (point a,point b) {return a.x<b.x||(a.x==b.x&&a.y<b.y);}

vector<point>ls;
point stk[N]; int top=0;
vector<point> merge(const vector<point> &a,const vector<point> &b)
{
	ls.clear();
	int i=0,j=0,siza=a.size(),sizb=b.size();
	while(i<siza&&j<sizb)
	{
		if(a[i]<b[j]) ls.pb(a[i]),i++;
		else ls.pb(b[j]),j++;
	}
	while(i<siza) ls.pb(a[i]),i++;
	while(j<sizb) ls.pb(b[j]),j++;

	int siz=ls.size();
	top=0;
	for(int i=0;i<siz;++i)
	{
		while(top>1&&cross(stk[top-1]-stk[top-2],ls[i]-stk[top-1])<=0) top--;
		stk[top++]=ls[i];
	}
	ls.clear();
	for(int i=0;i<top;++i) ls.pb(stk[i]);
	return ls;
}
ll ask(const vector<point> &a,point p)
{
	if(a.size()==0) return inf;
	if(a.size()==1) return dot(a[0],p);
	int l=0,r=a.size()-2;
	while(l<r)
	{
		int mid=l+r>>1;
		if(dot(a[mid],p)>dot(a[mid+1],p)) l=mid+1;
		else r=mid;
	}
	return min(dot(a[l],p),dot(a[l+1],p));
}

vector<point>ch[N<<2];
void insert(int o,int l,int r,int x,point p)
{
	if(l==r) {ch[o].pb(p);return ;}
	int mid=l+r>>1;
	if(x<=mid) insert(o<<1,l,mid,x,p);
	else insert(o<<1|1,mid+1,r,x,p);
	if(x==r) ch[o]=merge(ch[o<<1],ch[o<<1|1]);
}
ll query(int o,int l,int r,int x,int y,point p)
{
	if(x<=l&&r<=y) return ask(ch[o],p); //&&ch[o].size()
	int mid=l+r>>1; ll ans=inf;
	if(x<=mid) ans=query(o<<1,l,mid,x,y,p);
	if(y>mid) ans=min(ans,query(o<<1|1,mid+1,r,x,y,p));
	return ans;
}

int n,A[N],B[N],clk,dfn[N],efn[N];
ll f[N];
void dfs1(int u,int fa)
{
	dfn[u]=clk+1;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs1(v,u);
	}
	efn[u]=clk; clk++;
}
void dfs2(int u,int fa)
{
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs2(v,u);
	}
	if(dfn[u]<=efn[u]) f[u]=query(1,1,n,dfn[u],efn[u],point(A[u],1));
	insert(1,1,n,efn[u]+1,point(B[u],f[u]));
}

void wj()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) A[i]=read();
	for(int i=1;i<=n;++i) B[i]=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read();
		add(x,y);
	}
	dfs1(1,0);
	dfs2(1,0);
	for(int i=1;i<=n;++i) printf("%lld\n",f[i]);
	return 0;
}
