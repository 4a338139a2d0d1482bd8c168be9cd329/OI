#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define shmem(x) cerr<<sizeof(x)/(1024*1024.0)<<"MB"
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=5050;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}

int n,A[N],B[N];
ll f[N];
void calc(int id,int u,int fa)
{
	if(id!=u) f[id]=min(f[id],1ll*A[id]*B[u]+f[u]);
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		calc(id,v,u);
	}
}
void dfs(int u,int fa)
{
	bool leaf=1;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		leaf=0;
		dfs(v,u);
	}
	if(leaf) f[u]=0;
	else f[u]=1e18,calc(u,u,fa);
}
void wj()
{
	freopen("ct.in","r",stdin);
	freopen("ct.ans","w",stdout);
}
int main()
{
	wj();
	n=read();
	for(int i=1;i<=n;++i) A[i]=read();
	for(int i=1;i<=n;++i) B[i]=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read();
		add(x,y);
	}
	dfs(1,0);
	for(int i=1;i<=n;++i) printf("%lld\n",f[i]);
	return 0;
}
