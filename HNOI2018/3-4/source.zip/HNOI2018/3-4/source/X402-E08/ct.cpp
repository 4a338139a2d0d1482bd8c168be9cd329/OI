#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("ct.in", "r", stdin);
	freopen ("ct.out", "w", stdout);
}

int n;
const int N = 1e5 + 1e3, M = N << 1;
int a[N], b[N];

int Head[N], Next[M], to[M], e = 0;
void add_edge (int u, int v) { to[++e] = v; Next[e] = Head[u]; Head[u] = e; }
void Add(int u, int v) { add_edge (u, v); add_edge (v, u); }

typedef long long ll;
ll dp[N];

int dfn[N], sz[N], no[N];

void Dp1(int u, int fa) {
	static int clk = 0;
	dfn[u] = (++clk); no[clk] = u;
	sz[u] = 1; dp[u] = (ll)1e18;
	for (register int i = Head[u]; i; i = Next[i]) {
		register int v = to[i];
		if (v == fa) continue ;
		Dp1(v, u); sz[u] += sz[v]; 
	}
	if (sz[u] == 1) dp[u] = 0;
	For (i, dfn[u] + 1, dfn[u] + sz[u] - 1) {
		register int v = no[i];
		dp[u] = min(dp[u], dp[v] + 1ll * a[u] * b[v]);
	}
}

void Solve1() {
	Dp1(1, 0); For (i, 1, n) printf ("%lld\n", dp[i]);
}

ll Dp2(int u, int fa) {
	ll res; dp[u] = res = (ll)1e18; bool son = false;
	for (register int i = Head[u]; i; i = Next[i]) {
		register int v = to[i];
		if (v == fa) continue ;
		son = true;
		res = min(res, Dp2(v, u));
	}
	dp[u] = son ? (res + a[u]) : 0;
	return min(dp[u], res);
}

void Solve2() {
	Dp2(1, 0); For (i, 1, n) printf ("%lld\n", dp[i]);
}

int main () {
	File();
	n = read();
	For (i, 1, n) a[i] = read();
	bool flag = true;
	For (i, 1, n) { b[i] = read(); if (b[i] ^ 1) flag = false; }
	For (i, 1, n - 1) { int u = read(), v = read(); Add(u, v); }
	if (n <= (int)5e3) Solve1(); 
	else if (flag) Solve2();
    return 0;
}
