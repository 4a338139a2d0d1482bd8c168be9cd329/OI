#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("shit.in", "r", stdin);
	freopen ("shit.out", "w", stdout);
}

const int N = 1e5 + 1e3;
char str[N];
int len;

int ans = 0;

bool Cmp(int be1, int en1, int be2, int en2) {
	For (i, 0, en1 - be1) if (str[be1 + i] != str[be2 + i]) return false; return true;
}

void Dfs(int cur1, int cur2, int lst1, int lst2) {
	if (cur1 >= cur2) return ;
	if (Cmp(lst1, cur1, cur2, lst2)) {
		if (cur1 + 1 > cur2 - 1) { ++ ans; return ; }
		Dfs(cur1 + 1, cur2 - 1, cur1 + 1, cur2 - 1);
	}
	Dfs(cur1 + 1, cur2 - 1, lst1, lst2);
}

void Work1() {
	Dfs(1, len, 1, len);
	printf ("%d\n", ans);
}

typedef long long ll;
const ll Mod = 998244353;
ll fpm(ll x, ll power) {
	ll res = 1;
	for (; power; power >>= 1, (x *= x) %= Mod)
		if (power & 1) (res *= x) %= Mod;
	return res;
}

void Work2() {
	printf ("%lld\n", fpm(2, len / 2 - 1));
}

typedef unsigned long long ull;
const ull base = 37;
ull Hash[N], Pow[N];

const int N_ = 2e3 + 1e2;
int dp[N_][N_];

inline void Add(int &a, int b) { if ((a += b) >= Mod) a -= Mod; }

void Work3() {
	Pow[0] = 1;
	For (i, 1, len) {
		Pow[i] = Pow[i - 1] * base;
		Hash[i] = Hash[i - 1] * base + (str[i] - 'a');
	}
	dp[0][len + 1] = 1;
	For(cur1, 1, len >> 1) {
		register int cur2 = len - cur1 + 1;
		For (lst1, 1, cur1) {
			register int lst2 = cur2 + (cur1 - lst1), nowlen = (cur1 - lst1 + 1);
			if (Hash[cur1] - Hash[lst1 - 1] * Pow[nowlen] == Hash[lst2] - Hash[cur2 - 1] * Pow[nowlen]) {
				Add(dp[cur1][cur2], dp[lst1 - 1][lst2 + 1]);
			}
		}
	}
	printf ("%d\n", dp[len >> 1][(len >> 1) + 1]);
}

int main () {
	File();
	scanf ("%s", str + 1);
	len = strlen(str + 1);
	bool flag = true;
	For (i, 1, len) if (str[i] ^ 'a') flag = false;
	
	//if (len <= 20) Work1(); else 
	if (flag) Work2(); else Work3();
    return 0;
}
