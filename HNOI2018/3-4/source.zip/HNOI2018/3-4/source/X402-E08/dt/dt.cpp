#include <bits/stdc++.h>
#define For(i, l, r) for(register int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define Fordown(i, r, l) for(register int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
    int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}

void File() {
	freopen ("dt.in", "r", stdin);
	freopen ("dt.out", "w", stdout);
}

int n, k;

typedef long long ll;
const ll Mod = 998244353;

ll fpm(ll x, ll power) {
	ll res = 1;
	for (; power; power >>= 1, (x *= x) %= Mod) 
		if (power & 1) (res *= x) %= Mod;
	return res;
}

const int N = 5e3 + 1e1;
int S[N][N], C[N][N];
void Init(int maxn) {
	C[0][0] = S[0][0] = 1;
	For (i, 1, maxn) {
		C[i][0] = 1; S[i][0] = 0;
		For (j, 1, i) {
			(S[i][j] = 1ll* S[i - 1][j - 1] + 1ll * j * S[i - 1][j] % Mod) %= Mod;
			(C[i][j] = 1ll* C[i - 1][j - 1] + 1ll * C[i - 1][j]) %= Mod;
		}
	}
}

ll ans = 0;
ll now, fac = 1;

int main () {
	File();
	Init(N - 5);
	cin >> n >> k;

	now = n;
	For (i, 1, k) {
		(fac *= (now --)) %= Mod;
		(ans += S[k][i] * fac % Mod * fpm(2, n - i) % Mod) %= Mod;
	}
	printf ("%lld\n", ans);
    return 0;
}
