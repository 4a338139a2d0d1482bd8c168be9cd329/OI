#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=100005;
typedef long long ll;
int head[N],to[N<<1],nex[N<<1],e;
void add(int x,int y){
	to[++e]=y; nex[e]=head[x]; head[x]=e;
}
int siz[N],cnt,p[N],q[N],a[N],b[N]; ll w[N];
void dfs(int x,int f){
	p[x]=(++cnt); q[cnt]=x; siz[x]=1;
	for(int i=head[x];i;i=nex[i])
		if (to[i]!=f) dfs(to[i],x),siz[x]+=siz[to[i]];
	if (siz[x]==1) {w[x]=0; return;}
	For(i,p[x]+1,p[x]+siz[x]-1) w[x]=min(w[x],w[q[i]]+(ll)a[x]*b[q[i]]);
}
ll dfs2(int x,int f){
	ll s=0; int fl=0;
	for(int i=head[x];i;i=nex[i])
		if (to[i]!=f) s=min(s,dfs2(to[i],x)),fl=1;
	if (!fl) {w[x]=0; return 0;}
	w[x]=s+a[x]; return a[x]<0?s+a[x]:s;
}
int c[N];
int main(){
	freopen("ct.in","r",stdin); freopen("ct.out","w",stdout);
	int n=read(),x,y,fl=0,l,r;
	For(i,1,n) a[i]=read();
	For(i,1,n){
		b[i]=read(); if (b[i]!=1) fl=1;
	}
	For(i,1,n-1) x=read(),y=read(),add(x,y),add(y,x);
	if (n<=5000) memset(w,127,sizeof(w)),dfs(1,0);
	else if (!fl) dfs2(1,0);
	else{
		memset(w,127,sizeof(w));
		l=r=1; w[n]=0; p[1]=q[1]=n;
		for(int i=n-1;i>=1;--i){
			if (a[i]>=0)
				For(j,1,l) w[i]=min(w[i],w[p[j]]+(ll)a[i]*b[p[j]]);
			else
				For(j,1,r) w[i]=min(w[i],w[q[j]]+(ll)a[i]*b[q[j]]);
			x=0,y=0;
			For(j,1,l) if (b[p[j]]<=b[i]&&w[p[j]]<=w[i]) {y=1; break;}
			if (!y){
				memcpy(c,p,(1+l)<<2);
				For(j,1,l) if (!(b[c[j]]>=b[i]&&w[c[j]]>=w[i])) p[++x]=c[j];
				p[++x]=i,l=x;
			}
			x=0,y=0;
			For(j,1,r) if (b[q[j]]>=b[i]&&w[q[j]]<=w[i]) {y=1; break;}
			if (!y){
				memcpy(c,q,(1+r)<<2);
				For(j,1,r) if (!(b[c[j]]<=b[i]&&w[c[j]]>=w[i])) q[++x]=c[j];
				q[++x]=i,r=x;
			}
		}
	}
	For(i,1,n) printf("%lld\n",w[i]); cerr<<clock()<<endl;
	return 0;
}
