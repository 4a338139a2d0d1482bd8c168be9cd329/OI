#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=998244353;
typedef long long ll;
ll ksm(ll x,int f){
	ll an=1; int y=1;
	while(f){
		if (f&y) an=an*x%mo,f^=y;
		y<<=1; x=x*x%mo;
	}
	return (int)an;
}
int main(){
	freopen("dt.in","r",stdin); freopen("dt.out","w",stdout);
	int n=read(),m=read(),ans=n; ll x=n;
	if (m==1) printf("%lld\n",ksm(2,n-1)*n%mo),exit(0);
	if (!m) printf("%lld\n",ksm(2,n)-1),exit(0);
	For(i,2,n){
		x=x*(n-i+1)%mo*ksm(i,mo-2)%mo;
		ans+=x*ksm(i,m)%mo; if (ans>=mo) ans-=mo;
	}
	printf("%d\n",ans);
	return 0;
}
