#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
char s[100005]; int n,q[11],l,ans;
int ksm(long long x,int y){
	int f=1,mo=998244353; long long an=1;
	while(y){
		if (y&f) y^=f,an=an*x%mo;
		f<<=1; x=x*x%mo;
	}
	return an;
}
void dfs(int x){
	if (x==n){
		q[++l]=n;
		For(i,1,l)
			For(j,q[i-1]+1,q[i]) if (s[j]!=s[n*2-q[i]-q[i-1]+j]) {--l; return;}
		++ans; --l; return ;
	}
	dfs(x+1); q[++l]=x,dfs(x+1),--l;
}
int main(){
	freopen("shit.in","r",stdin); freopen("shit.out","w",stdout);
	scanf("%s",s+1); n=strlen(s+1); n>>=1;
	if (n<=10) dfs(1),printf("%d\n",ans),exit(0);
	printf("%d\n",ksm(2,n-1));
	return 0;
}
