#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef unsigned long long llu;
typedef double lf;
const int maxn=100005,mod=998244353;
int n,dp[maxn];
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
	if(x<0)x+=mod;
}
char s[maxn];
llu hs[maxn],pw[maxn];
llu idx[maxn];
int idx_cnt;
llu hash_val(int l,int r){
	return hs[r]-hs[l-1]*pw[r-l+1];
}
vector<llu>ve;
int main(){
#ifndef ONLINE_JUDGE
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
#endif
	bool flag=1;
	scanf("%s",s+1),n=strlen(s+1);
	REP(i,1,n)flag&=s[1]==s[i];
	pw[0]=1;
	REP(i,1,n){
		hs[i]=hs[i-1]*1004535809+s[i];
		pw[i]=pw[i-1]*1004535809;
	}
	flag=1;
	if(n<=2000){
		dp[0]=1;
		REP(i,1,n/2)
			REP(j,0,i-1)
				if(hash_val(j+1,i)==hash_val(n-i+1,n-j))add(dp[i],dp[j]);
		write(dp[n/2],'\n');
	}else if(flag){
		int ans=1;
		REP(i,1,n/2-1)ans=2*ans%mod;
		write(ans,'\n');
	}else{
		REP(i,1,n/2){
			int j=i;
			while((j<=n/2)&&(hash_val(i,j)!=hash_val(n-j+1,n-i+1)))++j;
			if(j>n/2)return puts("0"),0;
			ve.pb(hash_val(i,j)),i=j;
		}
		REP(i,0,ve.size()-1)idx[++idx_cnt]=ve[i];
		sort(idx+1,idx+1+idx_cnt);
		idx_cnt=unique(idx+1,idx+1+idx_cnt)-idx-1;
		REP(i,0,ve.size()-1)ve[i]=lower_bound(idx+1,idx+1+idx_cnt,ve[i])-idx-1;
		dp[0]=1;
		REP(i,1,ve.size()){
			int curl,curr;
			curl=i-1,curr=i-1;
			while((curl>=0)&&(curr<=ve.size()-1)){
				if(ve[curl]!=ve[curr])break;
				add(dp[curr+1],dp[curl]);
				--curl,++curr;
			}
			curl=i-1,curr=i;
			while((curl>=0)&&(curr<=ve.size()-1)){
				if(ve[curl]!=ve[curr])break;
				add(dp[curr+1],dp[curl]);
				--curl,++curr;
			}
		}
		write(dp[ve.size()],'\n');
	}
	return 0;
}
