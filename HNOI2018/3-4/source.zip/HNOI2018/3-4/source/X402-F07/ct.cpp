#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
int n,pre[maxn];
int A[maxn],B[maxn];
ll dp[maxn];
vector<int>E[maxn];
void DFS(int u){
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(v==pre[u])continue;
		pre[v]=u,DFS(v);
	}
	if((pre[u])&&(E[u].size()==1))dp[u]=0;
}
int vis[maxn];
int sz[maxn];
void getsz(int u,int fa){
	sz[u]=1;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa)||(vis[v]))continue;
		getsz(v,u),sz[u]+=sz[v];
	}
}
int getroot(int u,int fa,int tot){
	int maxsz=tot-sz[u],res=0;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa)||(vis[v]))continue;
		res=getroot(v,u,tot);
		if(res)return res;
		chkmax(maxsz,sz[v]);
	}return maxsz<=tot/2?u:0;
}
struct data{
	ll k,b;
	bool operator < (const data &A) const {
		return b<A.b;
	}
};
vector<data>ve;
struct data2{
	int x,id;
	bool operator < (const data2 &A) const {
		return x<A.x;
	}
};
vector<data2>ve2;
void dfs(int u,int fa,int dep){
	ve.pb((data){B[u],dp[u]});
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa)||((vis[v])&&(vis[v]<dep)))continue;
		dfs(v,u,dep);
	}
}
lf cross(const data &p,const data &q){
	return 1.0*(q.b-p.b)/(p.k-q.k);
}
void solve(int u,int dep){
	getsz(u,0);
	u=getroot(u,0,sz[u]);
	vis[u]=dep;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v!=pre[u])&&(!vis[v]))solve(v,dep+1);
	}
//	cout<<"root="<<u<<' '<<dep<<endl;
	ve.clear();
	ve2.clear();
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v!=pre[u])&&((!vis[v])||(vis[v]>=dep)))dfs(v,u,dep);
	}
	if(ve.size()){
		for(int t=u;(t)&&((!vis[t])||(vis[t]>=dep));t=pre[t])ve2.pb((data2){A[t],t});
		sort(ve2.begin(),ve2.end());
		int tmp=ve2[0].x;
		REP(i,0,ve.size()-1)ve[i].b+=tmp*ve[i].k;
		sort(ve.begin(),ve.end());
		REP(i,0,ve2.size()-1)ve2[i].x-=tmp;
/*
		cout<<"Ve"<<endl;
		REP(i,0,ve.size()-1)
			cout<<ve[i].k<<' '<<ve[i].b<<endl;
		cout<<"Ve2"<<endl;
		REP(i,0,ve2.size()-1)
			cout<<ve2[i].x<<' '<<ve2[i].id<<endl;
*/
		static int q[maxn],head,tail;
		q[head=tail=1]=0;
		REP(i,1,ve.size()-1){
			if(ve[i].k>=ve[q[tail]].k)continue;
			while((head<tail)&&(cross(ve[i],ve[q[tail]])<=cross(ve[q[tail]],ve[q[tail-1]])))--tail;
			q[++tail]=i;
		}
		REP(i,0,ve2.size()-1){
			while((head<tail)&&(cross(ve[q[head]],ve[q[head+1]])<ve2[i].x))++head;
			chkmin(dp[ve2[i].id],ve[q[head]].b+ve[q[head]].k*ve2[i].x);
		}
	}
	for(int t=pre[u];(t)&&(!vis[t]);t=pre[t])chkmin(dp[t],dp[u]+1ll*A[t]*B[u]);
	if((pre[u])&&(!vis[pre[u]]))solve(pre[u],dep+1);
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
#endif
	n=read();
	REP(i,1,n)A[i]=read();
	REP(i,1,n)B[i]=read();
	REP(i,1,n-1){
		int u=read(),v=read();
		E[u].pb(v),E[v].pb(u);
	}
	memset(dp,0x3f,sizeof(dp));
	DFS(1);
	solve(1,1);
	REP(i,1,n)write(dp[i],'\n');
	return 0;
}
