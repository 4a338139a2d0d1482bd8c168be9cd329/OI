//2018-3-4
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000 + 5)

int n, a[N], b[N];
LL f[N], Mn[N];

vector<int> G[N];

#define v G[now][i]

void Get(int o, int now, int F){
	For(i, 0, G[now].size() - 1) if(v != F) Get(o, v, now);
	f[o] = min(f[o], f[now] + (LL)a[o] * b[now]);
}

void Dfs(int now, int F){
	f[now] = 0;
	For(i, 0, G[now].size() - 1) if(v != F){
		Dfs(v, now); f[now] = f[v] + (LL)b[v] * a[now];
	}
	For(i, 0, G[now].size() - 1) if(v != F) Get(now, v, now);
}

void Cheat(int now, int F){
	f[now] = 0;
	For(i, 0, G[now].size() - 1) if(v != F){
		Cheat(v, now); f[now] = f[v] + a[now];
	}
	
	Mn[now] = f[now];
	For(i, 0, G[now].size() - 1) if(v != F){
		Mn[now] = min(Mn[now], Mn[v]);
		f[now] = min(f[now], Mn[v] + a[now]);
	}
	Mn[now] = min(Mn[now], f[now]);
}

#undef v

void Bf(){
	Dfs(1, 0);
	For(i, 1, n) printf("%lld\n", f[i]);
}

int main(){
	freopen("ct.in", "r", stdin);
	freopen("ct.out", "w", stdout);
	
	int u, v;

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &a[i]);
	For(i, 1, n) scanf("%d", &b[i]);
	For(i, 1, n - 1){
		scanf("%d%d", &u, &v);
		G[u].pb(v); G[v].pb(u);
	}
	
	if(n <= 5000){
		Bf(); return 0;
	}else{
		Cheat(1, 0);
		For(i, 1, n) printf("%lld\n", f[i]);
	}

	return 0;
}
