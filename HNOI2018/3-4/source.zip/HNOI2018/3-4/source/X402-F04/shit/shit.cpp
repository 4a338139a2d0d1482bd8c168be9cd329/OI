//2018-3-4
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (2000 + 5)
#define N (100000 + 5)
const int A = 31, P = 998244353;

inline int Mod(int a){
	if(a < 0) return a + P;
	return a >= P? a - P: a;
}
inline int Mul(int a, int b){
	return (long long)a * b % P;
}

inline int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = Mul(ret, a);
		a = Mul(a, a); anum >>= 1;
	}
	return ret;
}

int n, f[N], num[M][M];
char s[N];

int main(){
	freopen("shit.in", "r", stdin);
	freopen("shit.out", "w", stdout);
	
	scanf("%s", s + 1);

	n = strlen(s + 1);
	For(l, 1, n) For(r, l, n) num[l][r] = num[l][r - 1] * A + s[r];
	
	if(n > 2000){
		printf("%d\n", Pow(2, (n >> 1) - 1)); return 0;
	}

	f[0] = 1;
	For(i, 0, n >> 1) if(f[i]) For(j, i + 1, n >> 1){
		if(num[i + 1][j] != num[n - j + 1][n - (i + 1) + 1]) continue;
		f[j] = Mod(f[j] + f[i]);
	}

	printf("%d\n", f[n >> 1]);

	return 0;
}
