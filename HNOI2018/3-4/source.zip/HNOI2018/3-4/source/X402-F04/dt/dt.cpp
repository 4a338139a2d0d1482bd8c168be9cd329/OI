//2018-3-4
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (5000 + 5)
#define N (1000000 + 5)
const int P = 998244353;

inline int Mod(int a){
	if(a < 0) return a + P;
	return a >= P? a - P: a;
}
inline int Mul(int a, int b){
	return (long long)a * b % P;
}

inline int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = Mul(ret, a);
		a = Mul(a, a); anum >>= 1;
	}
	return ret;
}

int n, k, fac[N], rfac[N], f[M][M];

int C(int a, int b){
	return Mul(fac[a], Mul(rfac[b], rfac[a - b]));
}

void Bf(){
	fac[0] = rfac[0] = 1;
	For(i, 1, n) fac[i] = Mul(fac[i - 1], i), rfac[i] = Pow(fac[i], P - 2);

	int ans = 0;
	For(i, 1, n) ans = Mod(ans + Mul(Pow(i, k), C(n, i)));
	printf("%d\n", ans);
}

void Solve(){
	f[0][0] = Pow(2, n);

	int inv = Pow(2, P - 2);
	For(i, 1, k) f[0][i] = Mul(inv, f[0][i - 1]);
	For(i, 1, k) For(j, 0, k)
		f[i][j] = Mod(Mul(j, f[i - 1][j]) + Mul(n - j, f[i - 1][j + 1]));
	
	printf("%d\n", f[k][0]);
}

int main(){
	freopen("dt.in", "r", stdin);
	freopen("dt.out", "w", stdout);

	scanf("%d%d", &n, &k);

//	Solve();
	if(n <= 1000000) Bf();
	else{
		if(k == 0) printf("%d\n", Mod(Pow(2, n) - 1));
		else if(k == 1) printf("%d\n", Mul(n, Pow(2, n - 1)));
		else Solve();
	}

	return 0;
}
