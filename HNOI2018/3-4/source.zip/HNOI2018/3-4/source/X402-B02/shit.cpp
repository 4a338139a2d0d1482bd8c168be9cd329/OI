#include<bits/stdc++.h>
#define pb push_back
#define sz size
const int N=1e5+10;
#define ll long long
const int z=19;
const int mod=998244353;
using namespace std;
int n,k,n1,k1;
char str[N];
int v[N];
ll ans;
ll fac[N],hs[N],f[N];
namespace buf{
	bool judge(int x,int y,int l,int r){
		ll ret1=hs[y]-hs[x-1];ret1=(ret1%mod+mod)%mod;
		ret1=ret1*fac[l-x]%mod;
		ll ret2=hs[r]-hs[l-1];ret2=(ret2%mod+mod)%mod;
		return (bool)(ret1==ret2);	
	}
	void run(){
		fac[0]=1;
		for(int i=1; i<=n; ++i) fac[i]=fac[i-1]*z%mod;
		for(int i=1; i<=n; ++i) (hs[i]=hs[i-1]+fac[i]*(int)str[i]%mod)%mod;
		int n1=n>>1;
		f[0]=1ll;
		for(int r=1; r<=n1; ++r)
			for(int l=0; l<r; ++l){
				int al=l+1,ar=r,bl=n-ar+1,br=n-al+1;	
				if(judge(al,ar,bl,br)) {
					f[r]+=f[l];	
					f[r]%=mod;
				}
			}
		for(int i=0; i<n1; ++i){
			int p=i+1;
			int al=p,ar=n1,bl=n1+1,br=n-p+1;
			if(judge(al,ar,bl,br)) ans+=f[i];
		}
		printf("%lld\n",ans);
	}
	inline ll fpm(ll x,ll y){
		ll s=1;
		while(y){
			if(y&1)s=s*x%mod;
			y>>=1; x=x*x%mod;
		}
		return s;
	}
	void solve(){
		freopen("shit.in","r",stdin);
		freopen("shit.out","w",stdout);
		scanf("%s",str+1);
		n=strlen(str+1);
		int flag=1;
		for(int i=1; i<=n; ++i) if(str[i]!='a') flag=0;
		if(flag){
			int o=n/2-1;
			printf("%lld\n",fpm(2,o));
			return;
		}
		run();
	}
}
int main(){
	buf::solve();	
}
