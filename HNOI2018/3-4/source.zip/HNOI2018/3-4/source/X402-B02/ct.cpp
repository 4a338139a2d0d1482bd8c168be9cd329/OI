#include<bits/stdc++.h>
#define dp g
#define ll long long
const int N=1e5+10;
const ll inf=1e14;
using namespace std;
int n,fa[N],bgn[N],to[N<<1],nxt[N<<1];
ll a[N],b[N],g[N],e;
vector<int> v;
namespace solver{
	void add(int x,int y){
		to[++e]=y; nxt[e]=bgn[x], bgn[x]=e;
	}
	void dfs(int x,int f=0){
		bool o=0;
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(y==f) continue;
			dfs(y,x);
			o=1;
		}
		g[x]=inf*o;
	}
	void find(int x,int f=0){
		v.push_back(x);
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(y==f) continue;
			find(y,x);
		}
	}
	void work(int x,int f=0){
		v.clear();
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i]; if(y==f) continue;
			work(y,x);
		}
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i]; if(y==f) continue;
			find(y,x);	
		}
		for(int i=0; i<(int)v.size(); ++i){
			int o=v[i];
			dp[x]=min(dp[x],dp[o]+a[x]*b[o]);
		}
	}
	ll work1(int x,int f=0){
		ll all=inf;
		int s=0;
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(y==f) continue;
			all=min(all,work1(y,x));
			s=1;
		}
		if(s==0) dp[x]=0; else dp[x]=(a[x]+all);
		if((a[x]<0)&&(s==1)) all+=a[x];
		if(s==0) return 0; else return all;
	}
	void gt1(){
		dfs(1);
		work1(1);
		for(int i=1; i<=n; ++i) printf("%lld\n",dp[i]);
	}
	void solve(){
		scanf("%d",&n);
		for(int i=1; i<=n; ++i) scanf("%lld",&a[i]);
		int flag=1;
		for(int i=1; i<=n; ++i) scanf("%lld",&b[i]);	
		int x(0),y(0);
		for(int i=1; i<n; ++i){
			scanf("%d%d",&x,&y);
			add(x,y);add(y,x);
		}
		for(int i=1; i<=n; ++i) if(b[i]!=1) flag=0;
		if(flag){
			gt1();
			return;
		}
		dfs(1);
		work(1);
		for(int i=1; i<=n; ++i){
			printf("%lld\n",dp[i]);
		}
	}	
}
int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	solver::solve();
}
