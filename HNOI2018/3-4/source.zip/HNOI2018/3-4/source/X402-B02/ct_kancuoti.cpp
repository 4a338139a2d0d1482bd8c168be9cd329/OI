#include<bits/stdc++.h>
#define ll long long
const int N=1e5+10;
const ll inf=2e16;
using namespace std;

int e;
int bgn[N],to[N<<1],nxt[N<<1],n;
ll dep[N],a[N],b[N],ans[N];
int deg[N],id[N],in[N],ot[N],tot;

namespace SegT{
	ll mn[N],addv[N];
	#define l(x) (x<<1)
	#define r(x) ((x<<1)|1)
	void init(int x,int l,int r){
		if(l==r){
			if(deg[id[x]]!=1) mn[x]=dep[id[x]]; else mn[x]=inf;
		}
		mn[x]=min(mn[l(x)],mn[r(x)]);
	}
	void pd(int x){
		if(addv[x]) addv[l(x)]+=addv[x],addv[r(x)]+=addv[x],addv[x]=0;
	}
	void upd(int x,int l,int r,int ql,int qr,ll v){
		if(ql<=l&&r<=qr) addv[x]+=v,mn[x]+=v; else{
			pd(x);
			int mm=(l+r)>>1;
			if(ql<=mm) upd(l(x),l,mm,ql,qr,v);
			 if(mm<qr) upd(r(x),mm+1,r,ql,qr,v);
			mn[x]=min(mn[l(x)],mn[r(x)]);
		}
	}
	ll qury(int x,int l,int r,int ql,int qr){
		if(ql<=l&&r<=qr) return mn[x]; else{
			pd(x);
			ll ret=inf;
			int mm=(l+r)>>1;
			if(ql<=mm) ret=min(ret,qury(l(x),l,mm,ql,qr));
			 if(mm<qr) ret=min(ret,qury(r(x),mm+1,r,ql,qr));
			return ret;
		}
	}
}
using namespace SegT;

namespace solver{
	inline void add(int x,int y){
		to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e;
	}
	void dfs(int x,int f=0){
		in[x]=++tot; id[tot]=x;
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(y==f)continue;
			dep[y]=dep[x]+a[x]*b[y];
			dfs(y,x);
		}
		ot[x]=tot;
	}
	void work(int x,int f=0){
		ans[x]=qury(1,1,n,1,n);	
		for(int i=bgn[x]; i; i=nxt[i]){
			int y=to[i];
			if(y==f) continue;		
			ll fav=a[x]*b[y],snv=a[y]*b[x];
			int op1=in[x]-1,op2=ot[x]+1;
			if(1<=op1) upd(1,1,n,1,op1,snv); 
			if(op2<=n) upd(1,1,n,op2,n,snv);
			upd(1,1,n,op1+1,op2-1,-fav);
		}
	}
	void solve(){
		scanf("%d",&n);
		int x=0,y=0;
		for(int i=1; i<=n; ++i) scanf("%lld",&a[i]);
		for(int i=1; i<=n; ++i) scanf("%lld",&b[i]);
		for(int i=1; i<n; ++i){
			scanf("%d%d",&x,&y);
			add(x,y);deg[x]++;deg[y]++;add(y,x);
		}
		dfs(1);	
		for(int i=1; i<=n; ++i) printf("_%lld",dep[i]);
		//init(1,1,n);
	    //work(1);	
		for(int i=1; i<=n; ++i) printf("%lld\n",ans[i]);
	}
}


int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	solver::solve();
}
