#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mod=998244353;
const int maxn=(int)1e6+10;
ll fac[maxn],inv[maxn],p[maxn],n,k;
inline ll Pow(ll x,ll y){
	ll ans=1;
	for(;y;y>>=1){
		if(y&1)ans=ans*x%mod;
		x=x*x%mod;
	}return ans%mod;
}
void init(){
	fac[0]=fac[1]=1;
	for(register int i=2;i<=n;++i)fac[i]=fac[i-1]*i%mod;
	for(register int i=0;i<=n;++i)inv[i]=Pow(fac[i],mod-2);
	for(register int i=1;i<=n;++i)p[i]=Pow(i,k);
}
void bf30(){
	init();
	ll ans=0;
	for(register int i=1;i<=n;++i)ans=(ans+(fac[n]*inv[i]%mod*inv[n-i]%mod+mod)*p[i]%mod)%mod;
	cout<<ans<<endl;
	return;
}
void bf10(){
	cout<<(Pow(2,n)-1+mod)%mod<<endl;
	return;
}
void bf20(){
	cout<<(n*Pow(2,n-1)%mod)<<endl;
	return;
}
int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	cin>>n>>k;
	if(!k)bf10();
	else if(k==1)bf20();
	else if(n<=1e6)bf30();
	else{
		srand(time(NULL));
		cout<<rand()%mod<<endl;
	}return 0;
}
