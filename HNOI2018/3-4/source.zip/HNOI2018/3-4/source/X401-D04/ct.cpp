#include<bits/stdc++.h>
using namespace std;
const int maxm=5000+10,maxn=(int)1e5+10,inf=0x3f3f3f3f;
long long f[maxn],g[maxn];
int fst[maxn<<1],lst[maxn<<1],to[maxn<<1],e;
int A[maxn],B[maxn],fa[maxn],leaf[maxn];
int a[maxn],b[maxn],c[maxn],d[maxn];
int n;
vector<int>son[maxm];
inline void merge(int x,int y){
	int len=son[x].size();
	for(register int i=0;i<len;++i)son[y].push_back(son[x][i]);
}
inline void add(int x,int y){
	to[++e]=y,lst[e]=fst[x],fst[x]=e;
}
inline void dfs(int x){
	for(register int i=fst[x];i;i=lst[i]){
		int v=to[i];
		if(v==fa[x])continue;
		fa[v]=x;
		dfs(v);
		son[x].push_back(v);
		merge(v,x);
	}
	int len=son[x].size();
	for(register int i=0;i<len;++i){
		int v=son[x][i];
		f[x]=min(f[x],f[v]+B[v]*A[x]);
	}if(!len)f[x]=0;
}
inline void dfs1(int x){
	for(register int i=fst[x];i;i=lst[i]){
		int v=to[i];
		if(v==fa[x])continue;
		leaf[x]=1;
		fa[v]=x;
		dfs1(v);
		f[x]=min(f[x],g[v]+A[x]);
		g[x]=min(g[x],g[v]+min(0,A[x]));
	}if(!leaf[x])f[x]=0;
}
int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	int x,y;
	cin>>n;
	int flag=0;
	for(register int i=1;i<=n;++i)f[i]=inf;
	for(register int i=1;i<=n;++i)scanf("%d",&A[i]);
	for(register int i=1;i<=n;++i){scanf("%d",&B[i]);if(B[i]!=1)flag=1;}
	for(register int i=1;i<n;++i)scanf("%d%d",&x,&y),add(x,y),add(y,x);
	if(n<=5000)dfs(1);
	else if(!flag)dfs1(1);
	else{
		srand(time(NULL));
		for(register int i=1;i<=n;++i)f[i]=rand();
	}
	for(register int i=1;i<=n;++i)printf("%lld\n",f[i]);
	return 0;
}
