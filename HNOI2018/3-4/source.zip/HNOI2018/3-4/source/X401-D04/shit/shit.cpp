#include<bits/stdc++.h>
using namespace std;
const int maxn=(int)1e5+10,mod=998244353;
typedef long long ll;
int d[maxn];
string str;
int len,n;
int ans;
inline int pd(int i,int j){
	for(register int k=0;k<=j-i;++k){
		if(str[i+k]!=str[n-j-1+k]){
			return 0;
		}
	}return 1;
}
inline int judge(){
	int u,v;
	u=v=0;
	for(register int i=1;i<len;++i){
		if(d[i]==1){
			u=i-1;
			if(!pd(v,u))return 0;
			v=u+1;
		}
	}if(!pd(v,len-1))return 0;
	return 1;
}
inline void dfs(int x){
	if(x==len){
		ans+=judge();
		return;
	}
	d[x]=0,dfs(x+1);
	d[x]=1,dfs(x+1);
}
inline ll pow(ll x,ll y){
	ll ans=1;
	for(;y;y>>=1){
		if(y&1)ans=(ans*x)%mod;
		x=x*x%mod;
	}return ans%mod;
}
int main(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	cin>>str;
	n=len=str.length();
	len/=2;
	if(len<=10){
		dfs(1);
		cout<<ans%mod<<endl;
	}else{
		ans=pow(2,(ll)(len-1));
		cout<<ans<<endl;
	}return 0;
}

