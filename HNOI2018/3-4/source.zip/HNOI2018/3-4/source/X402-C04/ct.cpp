#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

template<typename guo> inline void chkmin(guo &a,guo b){if(a>b)a=b;}

typedef long long ll;
typedef __int128 lll;
const int N=1e5+9;

int n;
int to[N<<1],nxt[N<<1],beg[N],tot;
int id[N],ed[N],seg[N],dfn;
ll f[N],mv[N],a[N],b[N];

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void dfs_sp(int u,int fa)
{
	seg[id[u]=++dfn]=u;mv[u]=1e18;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa)
		{
			dfs_sp(to[i],u);
			chkmin(mv[u],mv[to[i]]);
		}
	ed[u]=dfn;
	if(id[u]!=ed[u])f[u]=mv[u]+a[u];
	chkmin(mv[u],f[u]);
}

inline void dfs(int u,int fa)
{
	seg[id[u]=++dfn]=u;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa)
			dfs(to[i],u);
	ed[u]=dfn;
	if(id[u]!=ed[u])f[u]=1e18;
	for(int i=id[u]+1;i<=dfn;i++)
		chkmin(f[u],f[seg[i]]+(ll)a[u]*b[seg[i]]);
}

namespace chain
{
	int p[N],stk[N],top;

	struct node
	{
		int p;
		ll b;
		bool operator < (node o)const
		{
			if(b==o.b)return f[p]>f[o.p];
			return b<o.b;
		}

		bool operator == (node o)const
		{
			return p==o.p && b==o.b;
		}
	}s[N],tmp[N];

	inline bool judge(int x,int y,int z)
	{
		return (lll)(f[z]-f[y])*(b[y]-b[x])<(lll)(f[y]-f[x])*(b[z]-b[y]);
	}

	inline void insert(node x)
	{
		int pos=x.p;
		while(top>=2 && judge(stk[top-1],stk[top],pos))
			top--;
		while(top && b[stk[top]]==b[pos])top--;
		stk[++top]=pos;
	}

	inline int query(int slope)
	{
		int l=2,r=top,ans=1,mid;
		while(l<=r)
		{
			mid=l+r>>1;
			if((lll)f[stk[mid]]-f[stk[mid-1]]<(lll)slope*(b[stk[mid]]-b[stk[mid-1]]))
				l=mid+1,ans=mid;
			else
				r=mid-1;
		}
		return stk[ans];
	}

	inline void work(int l,int r)
	{
		if(l==r)return;
		int mid=l+r>>1;
		work(l,mid);
		
		for(int i=l;i<=r;i++)
			tmp[i]=s[i];

		sort(tmp+l,tmp+mid+1);
		top=0;
		for(int i=l;i<=mid;i++)
			insert(tmp[i]);

		for(int i=mid+1;i<=r;i++)
		{
			int p=query(-a[tmp[i].p]);
			chkmin(f[tmp[i].p],f[p]+a[tmp[i].p]*b[p]);
		}

		work(mid+1,r);
	}
	
	int main()
	{
		reverse(a+1,a+n+1);
		reverse(b+1,b+n+1);
		for(int i=1;i<=n;i++)
		{
			s[i]=(node){i,b[i]};
			f[i]=1e18;
		}
		f[1]=0;
		work(1,n);
		reverse(f+1,f+n+1);
		for(int i=1;i<=n;i++)
			printf("%lld\n",f[i]);
		return 0;
	}
}

int main()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);

	n=read();int b1=0,line=0;
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1;i<=n;i++)
		if((b[i]=read())!=1)
			b1=1;
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
		if(abs(u-v)>1)line=1;
	}

	if(n<=5000)
		dfs(1,0);
	else if(!line)return chain::main();
	else dfs_sp(1,0);
	for(int i=1;i<=n;i++)
		printf("%lld\n",f[i]);
	return 0;
}


