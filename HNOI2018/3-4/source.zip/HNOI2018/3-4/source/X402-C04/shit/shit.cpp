#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=1e5+9;
const int md=998244353;
const ll ha=12960817,seed=2333;

int n;
char s[N];
ll f[N],has[N],pows[N],fac[N],inv[N];

inline bool cmp(int s1,int t1,int s2,int t2)
{
	for(int i=s1;i<=t1;i++)
		if(s[i]!=s[s2+i-s1])
			return false;
	return true;
}

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}

inline ll gethash(int s,int t)
{
	return (has[t]-has[s-1]*pows[t-s+1]%ha+ha)%ha;
}

inline bool cmps(int s1,int t1,int s2,int t2)
{
	return gethash(s1,t1)==gethash(s2,t2);
}

inline ll c(int a,int b)
{
	return fac[a]*inv[b]%md*inv[a-b]%md;
}

int main()
{
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);

	scanf("%s",s+1);
	n=strlen(s+1);

	if(n<=2000)
	{
		pows[0]=1ll;
		for(int i=1;i<=n;i++)
		{
			has[i]=(has[i-1]*seed%ha+s[i])%ha;
			pows[i]=pows[i-1]*seed%ha;
		}

		f[0]=1;
		for(int i=1;i<=n/2;i++)
			for(int j=0;j<i;j++)
				if(f[j] && cmps(j+1,i,n-i+1,n-j))
					f[i]=(f[i]+f[j])%md;

		printf("%lld\n",f[n/2]);
		return 0;
	}
	else
	{
		fac[0]=1ll;
		for(int i=1;i<N;i++)
			fac[i]=fac[i-1]*(ll)i%md;
		inv[N-1]=qpow(fac[N-1],md-2);
		for(int i=N-1;i>=1;i--)
			inv[i-1]=inv[i]*(ll)i%md;
		ll ans=0;
		for(int i=0;i<n/2;i++)
			(ans+=c(n/2-1,i))%=md;
		printf("%lld\n",ans);
	}
	return 0;
}
