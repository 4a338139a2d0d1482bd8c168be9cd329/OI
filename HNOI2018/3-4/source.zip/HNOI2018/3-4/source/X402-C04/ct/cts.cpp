#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

template<typename guo> inline void chkmin(guo &a,guo b){if(a>b)a=b;}

typedef long long ll;
typedef double db;
const int N=1e5+9;

int n;
int to[N<<1],nxt[N<<1],beg[N],tot;
int a[N],b[N],id[N],ed[N],seg[N],dfn;
ll f[N];

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void dfs(int u,int fa)
{
	seg[id[u]=++dfn]=u;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa)
			dfs(to[i],u);
	ed[u]=dfn;
	if(id[u]!=ed[u])f[u]=1e9+7;
	for(int i=id[u]+1;i<=dfn;i++)
		chkmin(f[u],f[seg[i]]+(ll)a[u]*b[seg[i]]);
}

struct ds
{
	int ch[N][2],fa[N],p[N],rt,tot;
	int lm[N],rm[N],size;

	inline void update(int x)
	{
		lm[x]=rm[x]=x;
		if(ch[x][0])lm[x]=lm[ch[x][0]];
		if(ch[x][1])rm[x]=rm[ch[x][1]];
	}

	inline void rotate(int x)
	{
		int y=fa[x],z=fa[y];
		int l=(ch[y][1]==x);
		if(z)ch[z][ch[z][1]==y]=x;
		fa[x]=z;fa[y]=x;fa[ch[x][l^1]]=y;
		ch[y][l]=ch[x][l^1];ch[x][l^1]=y;
		update(y);update(x);
		if(rt==y)rt=x;
	}

	inline void splay(int x)
	{
		for(int y=fa[x],z=fa[y];fa[x];rotate(x),y=fa[x],z=fa[y])
			if(fa[y])
			{
				if(ch[z][1]^ch[y][1])rotate(y);
				else rotate(x);
			}
		update(x);
	}
	
	inline int pre(int x)
	{
		int now=ch[x][0];
		if(!now)return -1;
		return rm[now];
	}

	inline int nxt(int x)
	{
		int now=ch[x][1];
		if(!now)return -1;
		return lm[now];
	}

	inline void del(int x)
	{
		splay(x);size--;
		int ls=ch[x][0],rs=ch[x][1];
		fa[ls]=fa[rs]=0;
		rt=rs;int now=lm[rt];
		ch[now][0]=ls;fa[ls]=now;
		splay(ls);
	}

	inline db calc(int x,int y)
	{
		return ((db)f[y]-f[x])/((db)b[y]-b[x]);
	}

	inline bool judge(int x,int y,int z)
	{
		int pa=p[x],pb=p[y],pc=p[z];
		if(calc(pa,pb)<calc(pb,pc))
			return true;
		return false;
	}

	inline void pops(int x)
	{
		while(1)
		{
			int pt=pre(x),pts=-1;
			if(~pt)pts=pre(pt);
			if((~pts) && judge(pts,pt,x))
				del(pt);
			else break;
		}
		while(1)
		{
			int pt=nxt(x),pts=-1;
			if(~pt)pts=nxt(pt);
			if((~pts) && judge(x,pt,pts))
				del(pt);
			else break;
		}
		int pr=pre(x),nx=nxt(x);
		if((~pr) && (~nx) && calc(p[pr],p[nx])>calc(p[pr],p[x]))
			del(x);
	}

	inline void insert(int x)
	{
		size++;
		int now=rt,son,fat;
		while(now)
		{
			fat=now;
			if(b[x]<b[p[now]])
				now=ch[now][son=0];
			else
				now=ch[now][son=1];
		}
		int cur=++tot;
		fa[cur]=fat;
		ch[fat][son]=cur;
		p[cur]=x;
		if(!rt)rt=cur;
		else
		{
			splay(cur);
			pops(cur);
		}
	}

	inline int find(db slope)
	{
		int now=rt,lans=now;
		while(now)
		{
			if(calc(p[pre(now)],p[now])>slope)
				lans=now,now=ch[now][1];
			else
				now=ch[now][0];
		}
		return p[lans];
	}
}t;

namespace chain
{
	typedef double db;

	int mian()
	{
		t.insert(n);
		f[n]=0;
		for(int i=n-1,p;i>=1;i--)
		{
			if(t.size==1)
				chkmin(f[i],f[t.p[t.rt]]+(ll)a[i]*b[t.p[t.rt]]);
			else
			{
				p=t.find(-a[i]);
				chkmin(f[i],f[p]+(ll)a[i]*b[p]);
			}
			t.insert(i);
		}

		for(int i=1;i<=n;i++)
			printf("%d\n",f[i]);
		return 0;
	}
}

int main()
{
	freopen("ct.in","r",stdin);
	freopen("cts.out","w",stdout);

	n=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1;i<=n;i++)
		b[i]=read();
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
	}

	return chain::mian();
	dfs(1,0);
	for(int i=1;i<=n;i++)
		printf("%d\n",f[i]);
	return 0;
}
