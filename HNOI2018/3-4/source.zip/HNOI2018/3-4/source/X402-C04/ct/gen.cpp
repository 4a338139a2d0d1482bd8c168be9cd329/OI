#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=10;
const int M=1000;

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("ct.in","w",stdout);

	int n=1000;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%N*2-N);
	puts("");
	for(int i=1;i<=n;i++)
		printf("%d ",1);
	puts("");
	
/*	for(int i=1;i<n;i++)
		printf("%d %d\n",i,i+1);*/
	for(int i=2;i<=n;i++)
		printf("%d %d\n",rand()%(i-1)+1,i);
	return 0;
}
