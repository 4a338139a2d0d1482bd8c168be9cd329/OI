#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

template<typename guo> inline bool chkmin(guo &a,guo b){if(a>b){a=b;return 1;}return 0;}

typedef long long ll;
const int N=1e5+9;

int n;
int to[N<<1],nxt[N<<1],beg[N],tot;
int a[N],b[N],id[N],ed[N],seg[N],dfn;
ll f[N],mv[N];


inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void dfs_sp(int u,int fa)
{
	seg[id[u]=++dfn]=u;mv[u]=1e18;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa)
		{
			dfs_sp(to[i],u);
			chkmin(mv[u],mv[to[i]]);
		}
	ed[u]=dfn;
	if(id[u]!=ed[u])f[u]=mv[u]+a[u];
	chkmin(mv[u],f[u]);
}

inline void dfs(int u,int fa)
{
	seg[id[u]=++dfn]=u;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa)
			dfs(to[i],u);
	ed[u]=dfn;
	if(id[u]!=ed[u])f[u]=1e18;
	for(int i=id[u]+1;i<=dfn;i++)
		if(chkmin(f[u],f[seg[i]]+(ll)a[u]*b[seg[i]]));
}

int main()
{
	freopen("ct.in","r",stdin);
	freopen("cts.out","w",stdout);

	n=read();int b1=0;
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1;i<=n;i++)
		if((b[i]=read())!=1)
			b1=1;
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
	}

	//if(!b1)dfs_sp(1,0);
	dfs(1,0);
	for(int i=1;i<=n;i++)
		printf("%d\n",f[i]);
	return 0;
}
