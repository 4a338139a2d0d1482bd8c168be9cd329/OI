#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=1e6+9;
const ll md=998244353;

ll n,k;
ll fac[N],inv[N],mem[5009];

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%md;
		a=a*a%md;b>>=1;
	}
	return ret;
}

inline ll c(ll a,ll b)
{
	if(a<b)return 0;
	return fac[a]*inv[b]%md*inv[a-b]%md;
}

inline ll s(ll n,ll m)
{
	ll ret=0;
	for(int k=0;k<=m;k++)
		(ret+=((k&1)?(md-1):1)*c(m,k)%md*mem[m-k]%md)%=md;
	ret=(ret*inv[m])%md;
	return ret;
}

int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);

	scanf("%lld%lld",&n,&k);
	if(k==0)
		return printf("%lld\n",qpow(2,n)-1),0;

	fac[0]=1ll;
	for(int i=1;i<N;i++)
		fac[i]=fac[i-1]*(ll)i%md;
	inv[N-1]=qpow(fac[N-1],md-2);
	for(int i=N-1;i>=1;i--)
		inv[i-1]=inv[i]*(ll)i%md;

	for(ll i=0;i<=k;i++)
		mem[i]=qpow(i,k);

	ll ans=0,cc=n;
	for(int j=1;j<=k;j++)
	{
		(ans+=s(k,j)*fac[j]%md*cc%md*qpow(2,n-j)%md)%=md;
		cc=cc*(n-j)%md*qpow(j+1,md-2)%md;
	}
	printf("%lld\n",ans);
	return 0;
}
