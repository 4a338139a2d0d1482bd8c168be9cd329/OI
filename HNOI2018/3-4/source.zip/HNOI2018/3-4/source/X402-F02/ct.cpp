#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(ll &a,ll b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("ct.in","r",stdin);
      freopen("ct.out","w",stdout);
  #endif
}
int head[N],tt,n;
struct edge
{
	int v,nex;
}e[N<<1];
ll a[N],b[N];
void add(int x,int y)
{
	e[++tt]=(edge){y,head[x]};head[x]=tt;
}
void input()
{
	int x,y;
	n=read<int>();
	For(i,1,n)a[i]=read<int>();
	For(i,1,n)b[i]=read<int>();
	For(i,2,n)
	{
		x=read<int>(),y=read<int>();
		add(x,y),add(y,x);
	}
}
namespace sub1
{
	ll dp[N],res,flag;
	const ll inf=1e18;
	void find(int u,int pre,int from)
	{
		cmin(res,a[from]*b[u]+dp[u]);
		for(register int i=head[u];i;i=e[i].nex)
		{
			if(e[i].v==pre)continue;
			find(e[i].v,u,from);
		}
	}
	void DP(int u,int pre)
	{
		for(register int i=head[u];i;i=e[i].nex)if(e[i].v^pre)DP(e[i].v,u);
		res=inf;flag=0;
		for(register int i=head[u];i;i=e[i].nex)if(e[i].v^pre)find(e[i].v,u,u),flag=1;
		dp[u]=flag?res:0;
	}
	void solve()
	{
		DP(1,0);
		For(i,1,n)write(dp[i],'\n');
	}
}
namespace sub2
{
	#define lson ls[h],l,mid
	#define rson ls[h],mid+1,r
	const int maxn=1e5;
	ll dp[N];
	int flag,size[N],lef[N*40],rig[N*40],ls[N*40],rs[N*40],rt[N],sz,t[N*40],ans;
	ll cal(int x,int pos)
	{
		return b[x]*pos+dp[x];
	}
	int best(int x,int y,int pos)
	{
		if(!x)return 0;
		if(!y)return 1;
		return cal(x,pos)<=cal(y,pos);
	}
	void insert(int &h,int l,int r,int k)
	{
		if(!h)h=++sz;
		if(!t[h]){t[h]=k;return;}
		if(l==r)
		{
			if(best(k,t[h],l))t[h]=k;
			return;
		}
		int mid=(l+r)>>1;
		if(b[t[h]]<b[k])
		{
			if(best(k,t[h],mid))swap(k,t[h]),insert(rson,k);
			else insert(lson,k);
		}
		else if(b[k]<b[t[h]])
		{
			if(best(k,t[h],mid))swap(k,t[h]),insert(lson,k);
			else insert(rson,k);
		}
		else 
		{
			if(best(k,t[h],mid))t[h]=k;
		}
	}
	void query(int h,int l,int r,int pos)
	{
		if(!t[h])return;
		if(best(t[h],ans,pos))ans=t[h];
		if(l==r)return;
		int mid=(l+r)>>1;
		if(pos<=mid)query(lson,pos);
		else query(rson,pos);
	}
	void merge(int h,int from)
	{
		//cerr<<t[h]<<endl;
		if(!t[h])return;
		insert(rt[from],-maxn,maxn,t[h]);
		if(ls[h])merge(ls[h],from);
		if(rs[h])merge(rs[h],from);
	}
	void DP(int u,int pre)
	{
		for(register int i=head[u];i;i=e[i].nex)if(e[i].v^pre)DP(e[i].v,u);
		int v;flag=0;rt[u]=++sz;
		//cerr<<endl<<u<<endl;
		for(register int i=head[u];i;i=e[i].nex)
		{
			v=e[i].v;
			if(pre==v)continue;
			if(size[u]>=size[v])
			{
			//	cerr<<u<<' '<<v<<' '<<t[rt[u]]<<' '<<1<<endl;
				merge(rt[v],u);
			//	cerr<<u<<' '<<v<<' '<<t[rt[u]]<<' '<<1<<endl;
			}
			else
			{
			//	cerr<<u<<' '<<v<<' '<<t[rt[u]]<<endl;
				merge(rt[u],v);
				rt[u]=rt[v];
			//	cerr<<u<<' '<<v<<' '<<t[rt[u]]<<endl;
			}
			size[u]+=size[v],flag=1;
		}
		ans=0;++size[u];
		if(flag)
		{
			query(rt[u],-maxn,maxn,a[u]);
			dp[u]=cal(ans,a[u]);
			//if(u==1)cerr<<ans<<endl;
		}
		insert(rt[u],-maxn,maxn,u);
	}
	void solve()
	{
		DP(1,0);
		For(i,1,n)write(dp[i],'\n');
	}
}
void work()
{
	if(n<=5000)sub1::solve();
	else sub2::solve();
}
int main()
{
	file();
	input();
	work();
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
