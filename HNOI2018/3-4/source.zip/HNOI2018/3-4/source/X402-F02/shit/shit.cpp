#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
  T ans=0,f=1;
  char ch=getchar();
  while(!isdigit(ch)&&ch!='-')ch=getchar();
  if(ch=='-')f=-1,ch=getchar();
  while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
  return ans*f;
}
template<typename T>void write(T x,char y)
{
  if(x==0)
  {
      putchar('0');putchar(y);
      return;
  }
  if(x<0)
  {
      putchar('-');
      x=-x;
  }
  static char wr[20];
  int top=0;
  for(;x;x/=10)wr[++top]=x%10+'0';
  while(top)putchar(wr[top--]);
  putchar(y);
}
void file()
{
  #ifndef ONLINE_JUDGE
      freopen("shit.in","r",stdin);
      freopen("shit.out","w",stdout);
  #endif
}
int len,n;
char s[N];
void input()
{
	scanf("%s",s+1);
	len=strlen(s+1);
	n=len>>1;
}
int check(int l,int r)
{
	int j=len-r+1;
	//cout<<l<<' '<<r<<' '<<j<<endl;
	For(i,l,r)
	{
		if(s[i]!=s[j])return 0;
		++j;
	}
	return 1;
}
namespace sub1
{
	int ans;
	void dfs(int pre)
	{
		if(pre==n+1){++ans;return;}
		For(i,pre,n)
		{
			if(check(pre,i))dfs(i+1);
		}
	}
	void solve()
	{
		dfs(1);
		write(ans,'\n');
	}
}
const int mo=998244353;
void add(int &a,int b)
{
	a+=b;if(a>=mo)a-=mo;
}
namespace sub2
{
	int dp[N];
	void solve()
	{
		dp[0]=1;
		For(i,1,n)For(j,1,i)
		{	
			if(check(j,i))add(dp[i],dp[j-1]);
		}
		write(dp[n],'\n');
	}
}
ll power(ll x,int y)
{
	ll res=1;
	for(;y;x=x*x%mo,y>>=1)if(y&1)res=res*x%mo;
	return res;
}
namespace sub3
{
	void solve()
	{
		write(power(2,n-1),'\n');
	}
}
void work()
{
	if(len<=20)sub1::solve();
	else if(len<=2000)sub2::solve();
	else sub3::solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
