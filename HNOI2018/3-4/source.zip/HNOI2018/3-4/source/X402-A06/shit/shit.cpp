#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){ if(c == '-') fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();
	
	return sum * fg;
}

const int maxn = 100010;

char s[maxn];

int len;

void Get () {
	scanf("%s", s + 1);
	len = strlen(s + 1);
}

bool pd(int st,int en,int st2) {
	int pos = st2;
	For(i, st, en) {
		if(s[i] != s[pos]) return 0;
		++ pos;
	}

	return 1;
}

void solve_bf () {
	int cnt = len / 2 - 1, Ans = 0;
	int tmp = (1 << cnt) - 1;

	For(i, 0, tmp) {
		int st = 1;
		bool flag = 0;
		For(j, 1, cnt) {
			if(i & (1 << j-1) ) {
				int Len = j - st + 1;
				int en = st + Len - 1;
				int st2 = len - en + 1;
				if(!pd(st, en, st2) ) {
					flag = 1;
					break;
				}
				st = j+1;
			}
		}

		int Len = len / 2 - st + 1;
		int en = st + Len - 1;
		int st2 = len - en + 1;
		if(!pd(st, en, st2) ) flag = 1;

		if(flag) continue;
		++ Ans;
	}

	printf("%d\n", Ans);
}

const int mod = 998244353;

int ksm(int x,int k) {
	int s = 1;
	while(k) {
		if(k & 1) s = 1ll * s * x % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}
	return s;
}

int main() {

	freopen("shit.in", "r", stdin);
	freopen("shit.out", "w", stdout);
	
	Get();
	if(len & 1) { puts("0"); return 0; }

	if(len <= 20) solve_bf();
	else printf("%d\n", ksm(2, len / 2 - 1) );

	return 0;
}
