#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )

#define For(i, a, b) for(ll i = (a);i <= (b); ++i)
#define rep(i, a, b) for(ll i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

ll read() {
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){ if(c == '-') fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();
	
	return sum * fg;
}

const ll maxn = 400010;

const ll inf = 1e18;

bool flag = 0;

ll A[maxn], B[maxn], n, Begin[maxn], e, Next[maxn], to[maxn], dfn[maxn], dfs_clock, Size[maxn];

void add(ll x, ll y) {
	to[++ e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void dfs(ll h,ll father) {
	Size[h] = 1;
	dfn[++ dfs_clock] = h;

	for(ll i = Begin[h]; i; i = Next[i] ) {
		ll v = to[i];
		if(v == father) continue;

		dfs(v, h);
		Size[h] += Size[v];
	}
}

void Get() {
	n = read();
	For(i, 1, n) A[i] = read();
	For(i, 1, n) {
		B[i] = read();
		if(B[i] != 1) flag = 1;
	}

	For(i, 2, n) {
		ll x = read(), y = read();
		add(x, y), add(y, x);
	}

	dfs(1, -1);
}

ll Ans[maxn];

void solve_bf() {
	For(i, 1, n) Ans[i] = inf;
	rep(i, n, 1) {
		if(Size[dfn[i]] == 1) {
			Ans[dfn[i]] = 0;
		}
		else {
			For(j, i + 1, i + Size[dfn[i]] - 1) {
				Ans[dfn[i]] = min(Ans[dfn[i]], Ans[dfn[j]] + 1ll * A[dfn[i]] * B[dfn[j]]);
			}
		}
	}

	For(i, 1, n) printf("%lld\n", Ans[i]);
}

ll tree[maxn];

void insert(ll h,ll l,ll r,ll pos,ll val) {
	if(l == r) {
		tree[h] = val;
		return;
	}

	ll mid = l+r >> 1;
	if(pos <= mid) insert(h<<1, l, mid, pos, val);
	else insert(h<<1|1, mid+1, r, pos, val);

	tree[h] = min(tree[h<<1], tree[h<<1|1]);
}

ll query(ll h,ll l,ll r,ll s,ll e) {
	if(l == s && r == e) return tree[h];

	ll mid = l+r >> 1;
	if(e <= mid) return query(h<<1, l, mid, s, e);
	else if(s > mid) return query(h<<1|1, mid+1, r, s, e);
	else return min(query(h<<1, l, mid, s, mid), query(h<<1|1, mid+1, r, mid+1, e) );
}

void solve_spe() {
	For(i, 1, n) Ans[i] = inf;
	For(i, 1, n * 4) tree[i] = inf;

	rep(i, n, 1) {
		if(Size[dfn[i]] == 1) {
			Ans[dfn[i]] = 0;
		}
		else {
			Ans[dfn[i]] = query(1, 1, n, i+1, i+Size[dfn[i]]-1) + 1ll * A[dfn[i]];
		}
		insert(1, 1, n, i, Ans[dfn[i]]);
	}

	For(i, 1, n) printf("%lld\n", Ans[i]);
}

//华丽的分割线

struct node {
	ll x, y;
};

vector <node> t[maxn], ls;

ll stx, sty, top;

node a[maxn], b[maxn], st[maxn];

bool vis[maxn];

void merge(ll h,ll ta,ll tb) {
	ls.clear();
	ll tot1 = t[ta].size(), tot2 = t[tb].size();
	ll cnt1 = 0, u = 1, v = 1, cnt2 = 0;

	For(i, 0, tot1 - 1) a[++cnt1] = t[ta][i];
	For(i, 0, tot2 - 1) b[++cnt2] = t[tb][i];

	while(u <= cnt1 && v <= cnt2) {
		if(a[u].x == b[v].x) {
			if(a[u].y <= b[v].y) {
				ls.push_back(a[u]);
				++ u;
			}
			else {
				ls.push_back(b[v]);
				++ v;
			}
		}
		else if(a[u].x < b[v].x) {
			ls.push_back(a[u]);
			++ u;
		}
		else {
			ls.push_back(b[v]);
			++ v;
		}
	}

	For(i, u, cnt1) ls.push_back(a[i]);
	For(i, v, cnt2) ls.push_back(b[i]);

	ll nowsize = ls.size(); top = 0;
	For(i, 0, nowsize - 1) {
		while(top > 1 && (ls[i].y - st[top].y) * (st[top].x - st[top-1].x) >= 
			(ls[i].x - st[top].x) * (st[top].y - st[top-1].y) ) -- top;
		st[++top] = ls[i];
	}

	For(i, 1, top) t[h].push_back(st[i]);
}

void Insert(ll h,ll l,ll r,ll pos,ll x,ll y) {
	if(l == r) {
		vis[h] = 1;
		node T;
		T.x = x, T.y = y;
		t[h].push_back(T);
		return;
	}

	ll mid = l+r >> 1;
	if(pos <= mid) Insert(h<<1, l, mid, pos, x, y);
	else Insert(h<<1|1, mid+1, r, pos, x, y);

	if(vis[h<<1] && vis[h<<1|1]){
		merge(h, h<<1, h<<1|1);
		vis[h] = 1;
	}
}

ll operator * (node C, node D) {
	return C.x * D.y - C.y * D.x;
}

ll ans;

void calc(ll h) {
	node T;
	T.x = stx, T.y = sty;
	ll tot = t[h].size() - 1;
	ans = min(ans, T * t[h][tot]);
	ll l = 0, r = tot-1;
	while(l <= r) {
		ll mid = l+r >> 1;
		if(T * t[h][mid] < T * t[h][mid+1]) {
			ans = min(ans, T * t[h][mid]);
			r = mid-1;
		}
		else {
			ans = min(ans, T * t[h][mid+1]);
			l = mid+1;
		}
	}
}

void query_ans(ll h,ll l,ll r,ll s,ll e) {
	if(l == s && r == e) {
		calc(h);
		return;
	}

	ll mid = l+r >> 1;
	if(e <= mid) query_ans(h<<1, l, mid, s, e);
	else if(s > mid) query_ans(h<<1|1, mid+1, r, s, e);
	else query_ans(h<<1, l, mid, s, mid), query_ans(h<<1|1, mid+1, r, mid+1, e);
}

void solve() {
	For(i, 1, n) Ans[i] = inf;
	rep(i, n, 1) {
		ans = inf;
		if(Size[dfn[i]] == 1) {
			ans = 0;
		}
		else{
			stx = A[dfn[i]], sty = -1;
			query_ans(1, 1, n, i+1, i+Size[dfn[i]]-1);
		}
		Ans[dfn[i]] = ans;
		Insert(1, 1, n, i, Ans[dfn[i]], B[dfn[i]]);
	}

	For(i, 1, n) printf("%lld\n", Ans[i]);
}

int main() {

	freopen("ct.in", "r", stdin);
	freopen("ct.out", "w", stdout);

	Get();
	if(flag) solve_bf();
	else if(n <= 5000) solve_spe();
	else solve();

	return 0;
}
