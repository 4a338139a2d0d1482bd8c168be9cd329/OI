#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int main() {
	
	//freopen("ct.in", "w", stdout);
	srand(time(NULL));

	int n = 10;
	printf("%d\n", n);

	For(i, 1, n) {
		int x = rand() % 10 - rand() % 10;
		printf("%d ", x);
	}puts("");

	For(i, 1, n) {
		int x = rand() % 10 - rand() % 10;
		printf("%d ", x);
	}puts("");

	For(i, 2, n) {
		printf("%d %d\n", i-1, i);
	}

	return 0;
}
