#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a) )
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN" << endl;

using namespace std;

int read() {
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){ if(c == '-') fg = -1; c = getchar();}
	while(c >='0' && c <='9') sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();
	
	return sum * fg;
}

const int maxn = 2000010;

const int mod = 998244353;

int nijie[maxn], jie[maxn], n, K;

int ksm(int x,int k) {
	int s = 1;
	while(k) {
		if(k&1) s = 1ll * s * x % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}
	return s;
}

void Get() {
	n = read(), K = read();
}

void pre_work() {
	jie[0] = 1;
	nijie[0] = ksm(1, mod-2);

	For(i, 1, n){
		jie[i] = 1ll * jie[i-1] * i % mod;
		nijie[i] = ksm(jie[i], mod-2);
	}
}

int C(int x,int y) {
	return 1ll * jie[x] * nijie[y] % mod * nijie[x - y] % mod;
}

void solve_bf() {
	pre_work();
	int Ans = 0;
	For(i, 1, n) {
		(Ans += 1ll * C(n, i) * ksm(i, K) % mod) %= mod;
	}

	printf("%d\n", Ans);
}

int main() {

	freopen("dt.in", "r", stdin);
	freopen("dt.out", "w", stdout);

	Get();
	if(K != 0) solve_bf();
	else printf("%d\n", ( (ksm(2, n) - 1) % mod + mod) % mod);

	return 0;
}
