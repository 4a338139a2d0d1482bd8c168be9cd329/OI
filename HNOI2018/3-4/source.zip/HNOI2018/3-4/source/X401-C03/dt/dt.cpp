#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define mod 998244353
int x = 0,y = 0;

void exgcd(int a,int b){
	if( b == 0 ){
		x = 1;
		y = 0;
		return ;
	}
	exgcd(b,a % b);
	int k = x;
	x = y;
	y = k - (a/b) * y;
}

LL f_pow( LL A, LL B ){
	LL ans = 1;
	while(B){
		if( B & 1 )(ans *= A)%= mod;
		(A *= A) %= mod;
		B >>= 1;
	}
	return ans;
}

int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	LL n,k;cin >> n >> k;
	if( k == 0 ){
		cout << (f_pow(2,n) - 1 + mod) % mod;
		return 0;
	}else{
		LL now = 1;
		LL ans = 0;
		for(int i = 1;i <= n;i ++){
			(now *= (n - i + 1) ) %= mod;
			exgcd(i,mod);
			(now *= ((x % mod + mod) % mod) ) % mod;
			(ans += now * f_pow(i,k) % mod) %= mod;
		}
		cout << ans;
	}
	return 0;
}
