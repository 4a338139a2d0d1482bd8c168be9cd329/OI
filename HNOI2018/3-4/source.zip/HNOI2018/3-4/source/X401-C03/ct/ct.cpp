#include<bits/stdc++.h>
using namespace std;
#define LL long long

LL v  [100005][2];
LL dp [100005];
vector<int> to[100005];

void dfs(int now,int last){
	LL mi = 4611686018427387904;
	bool first = false;
	for(int i = 0;i ^ to[now].size();i ++){
		int next = to[now][i];
		if( next == last )continue;
		dfs( next, now );
		if( ! first )mi = dp[next] + v[now][0] * v[next][1];first = true;
		mi = min( dp[next] + v[now][0] * v[next][1], mi );
	}
	dp[now] = mi;
}

int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	int n;cin >> n;
	for(int i = 1;i <= n;i ++)scanf("%d",&v[i][0]);
	for(int i = 1;i <= n;i ++)scanf("%d",&v[i][1]);
	for(int i = 2;i <= n;i ++){
		int a,b;scanf("%d%d",&a,&b);
		to[a].push_back(b);
		to[b].push_back(a);
	}
	dfs(1,1);
	for(int i = 1;i <= n;i ++){
		printf("%d\n",dp[i]);
	}
	return 0;
}
