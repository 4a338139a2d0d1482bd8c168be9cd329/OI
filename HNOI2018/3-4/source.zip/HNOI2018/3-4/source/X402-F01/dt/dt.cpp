#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
const long long mod = 998244353;
long long n,k;
long long s[5005][5005];
long long inv=1;
long long qpow(long long x,long long y){
     long long res=1;
	  while(y){
	     if(y&1)res=res*x%mod;
		 x=x*x%mod;
		 y>>=1;
	  }
	  return res;
}
int main () {
freopen("dt.in","r",stdin);
freopen("dt.out","w",stdout);
	n=read();
	k=read();
	s[0][0]=1;
	F(i,1,k){
	  F(j,1,i){
	     s[i][j]=(s[i-1][j-1]+j*s[i-1][j])%mod;
	  }
	}
	long long ans=0;
	F(i,0,k){
	   ans=(ans+1ll*s[k][i]*qpow(2,n-i)%mod*inv%mod)%mod;
	   inv=(inv*(n-i))%mod;
	}
	printf("%lld\n",ans);
    return 0;
}
