#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(long long &a, long long b) {return b < a ? a = b, 1 : 0;}
bool chkmax(long long &a,long long b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
int n;
int a[100005],b[100005];
int he[200005],to[200005],ne[200005],e;
int sz[100005],top[100005],son[100005],dfn[100005],pos[100005];
long long dp[100005];
void add(int x,int y){
    to[++e]=y;
	ne[e]=he[x];
	he[x]=e;
}
void dfs(int x,int fa){
   for(int i=he[x];i;i=ne[i]){
       int v=to[i];
       if(v==fa)continue;
	   dfs(v,x);
	   if(son[x]==0||sz[son[x]]<sz[v])son[x]=v;
	   sz[x]+=sz[v];
   }
   sz[x]++;
}
void dfs2(int x,int fa){
   dfn[x]=++e;
    pos[e]=x;
    if(son[x]){
        top[son[x]]=top[x];
        dfs2(son[x],x);
    }
    else return;
    for(int i=he[x];i;i=ne[i]){
       int v=to[i];
       if(v!=fa&&v!=son[x]){
            top[v]=v;
            dfs2(v,x);
       }
    }
}
long long tree[400005];
#define mid ((l+r)/2)
void built1(int rt,int l,int r){
       if(l==r){
	      tree[rt]=dp[pos[l]];
		  return ;
	   }
	   built1(rt<<1,l,mid);
	   built1(rt<<1|1,mid+1,r);
}
long long query(int rt,int l,int r,int L,int R){
      if(L<=l&&r<=R)return tree[rt];
	  long long res=0;
	  if(L<=mid)chkmin(res,query(rt<<1,l,mid,L,R));
	  if(R>mid)chkmin(res,query(rt<<1|1,mid+1,r,L,R));
	  return res;
}
void insert(int rt,int l,int r,int pos,long long val){
    if(l==r){
		tree[l]=val;
		return ;
	}
    if(pos<=mid)insert(rt<<1,l,mid,pos,val);
	else insert(rt<<1|1,mid+1,r,pos,val);
}
void DFS(int x,int fa){
     for(int i=he[x];i;i=ne[i]){
	      int v=to[i];
		 if(v==fa)continue;
		 DFS(v,x);
	 }
	 if(sz[x]==1)return ;
	 dp[x]=query(1,1,n,dfn[x],dfn[x]+sz[x]-1)+a[x];
	 insert(1,1,n,dfn[x],dp[x]);
}
void solve1(){
	built1(1,1,n);
	DFS(1,0);
   F(i,1,n){
      printf("%lld\n",dp[i]);
   }
}
void solve(int po,int x,int ff){
		for(int i=he[x];i;i=ne[i]){
			if(to[i]==ff) continue;
			chkmin(dp[po],dp[to[i]]+1ll*a[po]*b[to[i]]);
			solve(po,to[i],x);
		}
	}
void dfs1(int x,int ff){
	int size=0;
	for(int i=he[x];i;i=ne[i]){
		if(to[i]==ff) continue;
		size++;
		dfs1(to[i],x);
	}
		if(!size) dp[x]=0;
		else dp[x]=1e17,solve(x,x,ff);
}
int main () {
freopen("ct.in","r",stdin);
freopen("ct.out","w",stdout);
    n=read();
	bool flag=1;
	F(i,1,n){
	a[i]=read();
	}
	F(i,1,n){
	  b[i]=read();
	  if(b[i]!=1)flag=0;
	}
	F(i,1,n-1){
	  int x=read(),y=read();
	  add(x,y);
	  add(y,x);
	}
	dfs(1,0);
	e=0;
	dfs2(1,0);
	if(flag==1){
	   F(i,1,n)if(sz[i]!=1)dp[i]=1e17;
		solve1();
		return 0;
	}
	else{
	dfs1(1,0);
	F(i,1,n){
	  printf("%lld\n",dp[i]);
	}
	}
	return 0;
}
