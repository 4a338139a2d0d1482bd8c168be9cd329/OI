#include <bits/stdc++.h>
#define F(i, l, r) for(int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for(int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
using namespace std;

bool chkmin(int &a, int b) {return b < a ? a = b, 1 : 0;}
bool chkmax(int &a, int b) {return b > a ? a = b, 1 : 0;}

inline int read() {
 int x = 0, fh = 1; char ch = getchar();
    for (; !isdigit(ch); ch = getchar() ) if (ch == '-') fh = -1;
    for (; isdigit(ch); ch = getchar() ) x = (x<<1) + (x<<3) + (ch ^ '0');
    return x * fh;
}
const long long mod = 998244353;
long long qpow(long long x,long long y){
     long long res=1;
	 while(y){
	     if(y&1)res=res*x%mod;
		 x=x*x%mod;
		 y>>=1;
	 }
	 return res;
}
int n;
char s[1000005];
int ans=0;
int cnt;
string st[100005];
bool check(){
	if(cnt%2==1)return 0;
    F(i,1,cnt/2){
	   if(st[i]!=st[cnt-i+1])return 0;
	}
	return 1;
}
void dfs(int step,string l){
     if(step==1+n&&cnt!=0){
	   ans=(ans+check())%mod;
		return ;
	 }
	 if(step==n/2){
	     cnt++;
		 st[cnt]=l+s[step];
		 dfs(step+1,"\0");
		 cnt--;
		 return ;
	 }
	if(step==n){
		cnt++;
		st[cnt]=l+s[step];
	    dfs(step+1,"\0");
		cnt--;
		return ;
	}
	if(l=="\0"){
		dfs(step+1,l+s[step]);
		return ;
	}
	 dfs(step+1,l+s[step]);
	 cnt++;
	 st[cnt]=l+s[step];
	 dfs(step+1,"\0");
	 cnt--;
}
int main () {
freopen("shit.in","r",stdin);
freopen("shit.out","w",stdout);
    scanf("%s",s+1);
	n=strlen(s+1);
	bool flag=1;
	F(i,1,n){
	  if(s[i]!='a')flag=0;
	}
	if(n<=20&&flag!=1){
		dfs(1,"\0");
	    printf("%d\n",ans);
		return 0;
	}
	else printf("%lld\n",qpow(2,n/2-1));
    return 0;
}
