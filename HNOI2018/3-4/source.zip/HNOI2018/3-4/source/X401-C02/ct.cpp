#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Dor(i,j,k) for(int i=j;i>=k;--i)
using namespace std;
const int N=1e5+10;
int a[N],b[N];
struct edge{
	int to,nxt;
}e[N<<1];
int tot,head[N];
inline void add(int x,int y){
	e[++tot]=(edge){y,head[x]},head[x]=tot;
	e[++tot]=(edge){x,head[y]},head[y]=tot;
}
int dp[N],f[N],oo;
void dfs1(int x){
	for(int i=head[x];i;i=e[i].nxt){
		int to=e[i].to;
		if(to==f[x])continue;
		f[to]=x;
		dfs1(to);
	}
	if(oo==dp[x])dp[x]=0;
	int z=f[x];
	while(z){
		dp[z]=min(dp[x]+a[z]*b[x],dp[z]);
		z=f[z];
	}
}
int ans[N];
void dfs2(int x){
	for(int i=head[x];i;i=e[i].nxt){
		int to=e[i].to;
		if(to==f[x])continue;
		f[to]=x;
		dfs2(to);
	}
	if(oo==dp[x]){
		dp[x]=0;
		return ;
	}
	dp[x]=ans[x]+a[x];
	ans[f[x]]=min(ans[f[x]],min(ans[x],dp[x]));
	return ;
}
int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	memset(dp,127,sizeof(dp));
	oo=dp[0];
	int n,x,y;
	scanf("%d",&n);
	For(i,1,n)scanf("%d",&a[i]);
	For(i,1,n)scanf("%d",&b[i]);
	For(i,1,n-1){
		scanf("%d%d",&x,&y);
		add(x,y);
	}
	if(n<=N)dfs1(1);
	else dfs2(1);
	for(int i=1;i<=n;++i)
		printf("%d\n",dp[i]);
	return 0;
}

