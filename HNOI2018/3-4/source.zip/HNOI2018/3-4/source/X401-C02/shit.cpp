#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<vector>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Dor(i,j,k) for(int i=j;i>=k;--i)
#define ll long long
using namespace std;
const int N=1e5+10;
const int mod=998244353;
ll ksm(ll x,ll k){
	ll ans=1;
	while(k){
		if(k&1)ans=(x*ans%mod);
		x=(x*x%mod);
		k=(k>>1);
	}
	return ans%mod;
}
char c[1000000];
int ans,a[50],l=0,len;
bool judge(){
	int z=1,j=1,k,zl=0,q;
	for(int i=1;i<=l;++i)
		printf("%d ",a[i]);
	puts("");
	for(int i=1;i<=l;++i){
		zl+=a[i];
		for(k=len-zl+1,q=1;q<=a[i];++j,++q,++k)
			if(c[k]!=c[j])return false;
	}

	return true;
}
void dfs(int r,int pre){
	++r;
	if(r==len/2){
		a[++l]=r-pre+1;
		if(judge())ans=(ans+1)%mod;
		return ;
	}
	dfs(r,pre);
	a[++l]=r-pre+1;
	dfs(r,r+1);
	a[l--]=0;
}
int pian20(){
	dfs(1,1);
	return ans%mod;
}
int main(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	scanf("%s",c+1);
	len=strlen(c+1);
	if(len<=2e3+10)
		printf("%d\n",pian20()%mod);
	else
		printf("%lld\n",ksm(2,len/2-1));
	return 0;
}

