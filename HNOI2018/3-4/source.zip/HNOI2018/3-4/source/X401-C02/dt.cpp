#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Dor(i,j,k) for(int i=j;i>=k;--i)
#define ll long long
using namespace std;
const ll mod=998244353;
const int N=1e7+10;
int dp[N];
ll que(ll x,ll p,ll mod){
    x%=mod;
    ll ans=1;
    while(p){
        if(p&1)ans=(ans*x)%mod;
        x=(x*x)%mod;
        p=(p>>1);
    }	
    return ans%mod;
}
ll ksm(ll x,ll k){
	ll ans=1;
	while(k){
		if(k&1)ans=(x*ans%mod);
		x=(x*x%mod);
		k=(k>>1);
	}
	return ans%mod;
}
int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	ll ans,n,k;
	scanf("%lld%lld",&n,&k);
	if(!k){
		ans=(((1<<n)%mod)-1)%mod;
		printf("%lld\n",ans);
		return 0;
	}else if(k==1){
		ans=((1<<(n-1))%mod*n)%mod;
		printf("%lld\n",ans);
		return 0;
	}
	ans=dp[1]=n;
	for(ll i=2ll;i<=n;++i){
		dp[i]=dp[i-1]%mod*(n-i+1)%mod*que(i,mod-2,mod)%mod;
		ans+=(ksm(i,k)*dp[i])%mod;
	}
	printf("%lld\n",ans%mod);
	return 0;
}

