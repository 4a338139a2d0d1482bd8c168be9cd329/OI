#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<vector>
using namespace std;
void File(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=n;--i)
#define MREP(i,x) for(register int i=beg[x];i;i=E[i].last)
#define ll long long
template<typename T>void chckmax(T &_,T __){_=__>_ ? __ : _;}
template<typename T>void chckmin(T &_,T __){_=__<_ ? __ : _;}
const int maxn=1e5+10;
const ll inf=0x3f3f3f3f3f3f3f3f;
int n,m,beg[maxn],len;
ll a[maxn],b[maxn],f[maxn],Minx[maxn];
struct edge{
	int to;
	int last;
}E[maxn*2];
void add(int u,int v){
	++len;
	E[len].to=v;
	E[len].last=beg[u];
	beg[u]=len;
}
vector<int>G[maxn];
void dfs(int u,int fa){
	bool flag=1;
	MREP(i,u){
		int v=E[i].to;
		if(v==fa)continue;
		flag=0;
		dfs(v,u);
		int siz=G[v].size()-1;
		REP(j,0,siz){
			G[u].push_back(G[v][j]);
			chckmin(f[u],f[G[v][j]]+a[u]*b[G[v][j]]);
		}
		G[u].push_back(v);
		chckmin(f[u],f[v]+a[u]*b[v]);
	}
	if(flag)f[u]=0ll;
}
void dfs1(int u,int fa){
	bool flag=1;
	MREP(i,u){
		int v=E[i].to;
		if(v==fa)continue;
		flag=0;
		dfs1(v,u);
		chckmin(Minx[u],Minx[v]);
	}
	chckmin(f[u],Minx[u]+a[u]);
	chckmin(Minx[u],f[u]);
	if(flag)Minx[u]=f[u]=0ll;
}
int main(){
	File();
	bool sub1=1;
	scanf("%d",&n);
	REP(i,1,n)scanf("%lld",&a[i]);
	REP(i,1,n){
		scanf("%lld",&b[i]);
		if(b[i]!=1)sub1=0;
	}
	REP(i,1,n-1){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	REP(i,1,n)f[i]=inf;
	if(sub1){
		REP(i,1,n)Minx[i]=inf;
		dfs1(1,0);
		REP(i,1,n)printf("%lld\n",f[i]);
		return 0;
	}
	if(n<=5e3){
		dfs(1,0);
		REP(i,1,n)printf("%lld\n",f[i]);
		return 0;
	}
	return 0;
}
