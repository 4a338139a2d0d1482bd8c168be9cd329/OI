#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
void File(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
#define inv(x) qpow(x,mod-2)
#define c(a,b) c[a]%mod*f[b]%mod*f[a-b]%mod
const ll mod=998244353;
const int maxn=1e7+10;
ll n,k;
ll qpow(ll a,ll b){
	if(a==0)return 0ll;
	ll base=a,r=1ll;
	while(b){
		if(b&1)r=r*base%mod;
		base=base*base%mod;
		b>>=1;
	}
	return r%mod;
}
ll c[maxn],f[maxn],ans=0;
int main(){
	File();
	scanf("%lld%lld",&n,&k);	
	if(k==0){
		printf("%lld\n",((qpow(2,n)-1)%mod+mod)%mod);
		return 0;
	}
	else if(k==1){
		printf("%lld\n",(qpow(2,n-1)*n)%mod);
		return 0;
	}
	if(n<=10000000){
		c[0]=1;
		REP(i,1,n)c[i]=i*c[i-1]%mod;
		f[n]=inv(c[n]);
		DREP(i,n-1,0)f[i]=f[i+1]*(i+1)%mod;
		REP(i,1,n)ans=(ans+c(n,i)*qpow(i,k))%mod;
		printf("%lld\n",ans);
		return 0;
	}	
	return 0;
}
