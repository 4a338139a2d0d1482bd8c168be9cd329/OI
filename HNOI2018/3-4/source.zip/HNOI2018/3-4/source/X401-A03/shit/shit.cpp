#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
void File(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
}
#define REP(i,a,b) for(register int i=a;i<=b;++i)
#define DREP(i,a,b) for(register int i=a;i>=b;--i)
#define ll long long
const int maxn=2e3+10;
const ll mod=998244353;
int n,ans,dp[maxn];
char s[maxn];
bool d[maxn][maxn];
bool pd(int x,int y){
	int xx=n-y+1;
	REP(i,0,y-x)if(s[x+i]!=s[xx+i])return false;
	return true;
}
void dfs(int pos){
	if(pos==n/2+1){
		++ans;
		return;
	}
	REP(i,pos,n/2){
		if(d[pos][i])
			dfs(i+1);
	}
}
int qpow(int a,int b){
	ll base=a,r=1ll;
	while(b){
		if(b&1)r=r*base%mod;
		base=base*base%mod;
		b>>=1;
	}
	return (int)(r%mod);
}
int main(){
	File();
	bool sub1=1;
	scanf("%s",s+1);
	n=strlen(s+1);
	REP(i,1,n)if(s[i]!=s[1])sub1=0;
	if(sub1){
		printf("%d\n",qpow(2,n/2-1));
		return 0;
	}
	REP(i,1,n/2)REP(j,i,n/2)
		if(pd(i,j))d[i][j]=1;
	if(n<=20){
		dfs(1);
		printf("%d\n",ans);
		return 0;
	}
	DREP(i,n/2,1){
		REP(j,i,n/2-1)
			if(d[i][j])dp[i]=(dp[i]+dp[j+1])%mod;
		if(d[i][n/2])dp[i]=(dp[i]+1)%mod;
	}
	printf("%lld\n",dp[1]%mod);
	return 0;
}
