#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e5+100;
int n;
int to[maxn*2],ne[maxn*2],po[maxn],id1,X,Y,id[maxn],dfs_time;
int sz[maxn];
ll a[maxn],b[maxn],ans[maxn];
void add(int x,int y)
{
	id1++;
	to[id1]=y;ne[id1]=po[x];po[x]=id1;
}
int Map[maxn];
void dfs1(int x)
{
	if (id[x]) return;
	sz[x]=1;
	id[x]=++dfs_time;Map[dfs_time]=x;
	int y;
	for (int i=po[x];i;i=ne[i])
	{
		if (!id[to[i]])
		{
			y=to[i];
			dfs1(y);
			sz[x]+=sz[y];
		}
	}
}
ll dfs(int x,int fa)
{
	if (sz[x]==1)
	{
		ans[x]=0;
		return 0;
	}
	ll ss=20000000000000000;
	for (int i=po[x];i;i=ne[i])
	{
		if (to[i]!=fa)
		{
			ss=min(ss,dfs(to[i],x));
		}
	}
	ans[x]=ss+a[x];
	if (a[x]<0) return ss+a[x]; 
	return ss;
}
int main()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	n=read();
	bool f2=true;
	for (int i=1;i<=n;i++) a[i]=read();
	for (int i=1;i<=n;i++) 
	{
		b[i]=read();
		if (b[i]!=1) f2=false;
	}
	for (int i=1;i<n;i++)
	{
		X=read();Y=read();
		add(X,Y);add(Y,X);
	}
	if (f2) 
	{
		memset(ans,0x3f3f3f3f,sizeof(ans));
		dfs1(1);
		dfs(1,0);
		for (int i=1;i<=n;i++)
		{
			printf("%lld\n",ans[i]);
		}
		return 0;
	}
	dfs1(1);
	memset(ans,0x3f3f3f3f,sizeof(ans));
	for (int i=n;i>=1;i--)
	{
		if (sz[Map[i]]==1) {ans[Map[i]]=0;continue;}
		int Max=i+sz[Map[i]]-1;
		for (int j=i+1;j<=Max;j++)
		{
			ans[Map[i]]=min(ans[Map[i]],a[Map[i]]*b[Map[j]]+ans[Map[j]]);
		}
	}
	for (int i=1;i<=n;i++)
	{
		printf("%lld\n",ans[i]);
	}
	return 0;
}
