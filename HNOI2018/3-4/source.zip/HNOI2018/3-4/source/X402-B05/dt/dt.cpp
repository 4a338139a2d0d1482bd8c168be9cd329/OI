#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const ll mod=998244353;
ll s[5100][5100];  
ll c[5100];
ll n,k;
ll ans,jie[5100];
ll ksm(ll x,int y)
{
	ll sum=1;
	while (y)
	{
		if (y&1) sum=sum*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return sum;
}
ll C;
int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	s[0][0]=1;
	n=read();k=read();
	for (ll i=1;i<=k;i++)
		for (ll j=1;j<=i;j++)
		{
			s[i][j]=s[i-1][j-1]+(ll)j*s[i-1][j]%mod;
			if (s[i][j]>=mod) s[i][j]-=mod;
		}
	jie[0]=1;
	for (ll i=1;i<=k;i++)
	{
		jie[i]=jie[i-1]*i%mod;
	}
	C=1;
	for (ll i=0;i<=min(n,k);i++)
	{
		ans=ans+s[k][i]*C%mod*ksm(2,n-i)%mod;
		if (ans>=mod) ans-=mod;
		ans=(ans%mod+mod)%mod;
		C=C*(n-i)%mod;
	}
	ans%=mod;
	if (k==0)
	{
		ans--;
		ans=(ans%mod+mod)%mod;
	}
	cout<<ans;
	return 0;
} 
