#include<bits/stdc++.h>
#define ll long long
using namespace std;
void qmax(int &x,int y) {if (x<y) x=y;}
void qmin(int &x,int y) {if (x>y) x=y;}
inline int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);
	if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
inline void write(int x)
{
	static char cnt,num[15];cnt=0;
	if (!x)
	{
		putchar('0');
		return;
	}
	for (;x;x/=10) num[++cnt]=x%10;
	for (;cnt;putchar(num[cnt--]+48));
}
const int maxn=1e5+100;
char ch[maxn];
int n;
int b[maxn],ans;
bool check()
{
	int last=1;
	for (int i=1;i<=(n/2)+1;i++)
	{
		if (b[i])
		{
			for (int j=last,r=n-i+1;j<=i;j++,r++)
			if (ch[j]!=ch[r]) return false;
			last=i+1;
		}
	}
	return true;
}
void dfs(int x)
{
	if (x==(n/2)+1)
	{
		if (!b[n/2]) return;
		if (check()) ans++;
		return;
	}
	b[x]=0;
	dfs(x+1);
	b[x]=1;
	dfs(x+1);
}
const ll mod=998244353;
int main()
{
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	scanf("%s",ch+1);
	n=strlen(ch+1);
	bool f2=true;
	for (int i=1;i<=n;i++)
	{
		if (ch[i]!='a')
		{
			f2=false;
			break;
		}
	}

	if (f2)
	{
		ll sum=1;
		for (int i=1;i<=(n/2)-1;i++)
		{
			sum=sum*2%mod;
		}
		printf("%lld\n",sum);
		return 0;
	}

	dfs(1);
	printf("%d\n",ans);	
	return 0;
}
