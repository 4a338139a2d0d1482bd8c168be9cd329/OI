#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 1e5 + 10;

int Begin[N], Next[N << 1], to[N << 1], e = 1;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int fa[N];
LL dp[N];

void DFS_init(int o) {
	bool ch = false;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == fa[o]) continue;
		fa[u] = o;
		DFS_init(u);
		ch = true;
	}
	dp[o] = ch ? 1ll << 60 : 0;
}

int n;
int A[N], B[N];
int sz[N], vis[N];
int nowsz, minsz, cen;

void DFS_Centroid(int o, int f) {
	sz[o] = 1;
	int mx = 0;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f || vis[u]) continue;
		DFS_Centroid(u, o);
		sz[o] += sz[u];
		mx = max(mx, sz[u]);
	}
	mx = max(mx, nowsz - sz[o]);
	if (mx < minsz) minsz = mx, cen = o;
}

int ida[N], a;
int idb[N], b;

void DFS_info(int o, int lim) {
	idb[++b] = o;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == fa[o]) continue;
		assert(vis[u] && vis[u] != lim);
		if (vis[u] < lim) continue;
		DFS_info(u, lim);
	}
}

bool cmpa(int x, int y) { return A[x] < A[y]; }
bool cmpb(int x, int y) { return B[x] ^ B[y] ? B[x] > B[y] : dp[x] < dp[y]; }

int st[N];

double Slope(int x, int y) {
	return 1.0 * (dp[y] - dp[x]) / (B[x] - B[y]);
}

void Divide_Conquer(int rt, int nsz, int dep) {
	nowsz = minsz = nsz;
	DFS_Centroid(rt, fa[rt]);
	int o = cen;
	//printf("%d %d %d\n", rt, o, nsz);
	vis[o] = dep;
	if (nsz == 1) return;

	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == fa[o] || vis[u]) continue;
		Divide_Conquer(u, sz[u], dep + 1);
	}

	a = b = 0;
	DFS_info(o, dep);
	int now = o;
	while (now != rt) now = fa[now], ida[++a] = now;

	assert(idb[1] == o);
	For(i, 2, b) dp[o] = min(dp[o], dp[idb[i]] + 1ll * A[o] * B[idb[i]]);
	sort(ida + 1, ida + a + 1, cmpa), sort(idb + 1, idb + b + 1, cmpb);

	int l = 1, r = 1;
	st[r] = idb[1];
	For(i, 2, b) {
		int j = idb[i];
		if (B[j] == B[idb[i - 1]]) continue;
		while (r > 1 && Slope(st[r - 1], st[r]) >= Slope(st[r], j)) --r;
		st[++r] = j;
	}

	For(i, 1, a) {
		int j = ida[i];
		while (l < r && A[j] >= Slope(st[l], st[l + 1])) ++l;
		dp[j] = min(dp[j], dp[st[l]] + 1ll * A[j] * B[st[l]]);
	}

	if (rt != o) Divide_Conquer(rt, sz[rt] - sz[o], dep + 1);
}

int main() {

	freopen("ct.in", "r", stdin);
	freopen("ct.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &A[i]);
	For(i, 1, n) scanf("%d", &B[i]);
	For(i, 2, n) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}

	DFS_init(1);
	Divide_Conquer(1, n, 1);
	For(i, 1, n) printf("%lld\n", dp[i]);

	return 0;
}
