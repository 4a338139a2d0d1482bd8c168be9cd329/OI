#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

int mx = 1e5;

int randint(int l, int r) {
	return rand() % (r - l + 1) + l;
}

int main() {

	freopen("ct.in", "w", stdout);

	int n = 100000;
	printf("%d\n", n);
	srand(time(0));
	For(i, 1, n) printf("%d%c", randint(-mx, mx), i == n ? '\n' : ' ');
	For(i, 1, n) printf("%d%c", randint(-mx, mx), i == n ? '\n' : ' ');
	For(i, 2, n) printf("%d %d\n", i, randint(max(1, i - 1000), i - 1));

	return 0;
}
