#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 1e5 + 10;

int Begin[N], Next[N << 1], to[N << 1], e = 1;

void add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

LL dp[N];
int n, A[N], B[N];

void DFS_calc(int s, int o, int f) {
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f) continue;
		DFS_calc(s, u, o);
		dp[s] = min(dp[s], dp[u] + 1ll * A[s] * B[u]);
	}
}

void DFS_work(int o, int f) {
	bool ch = false;
	for (int i = Begin[o]; i; i = Next[i]) {
		int u = to[i];
		if (u == f) continue;
		ch = true;
		DFS_work(u, o);
	}
	if (!ch) dp[o] = 0;
	else dp[o] = 1ll << 60, DFS_calc(o, o, f);
}

int main() {

	freopen("ct.in", "r", stdin);
	freopen("ct.ans", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &A[i]);
	For(i, 1, n) scanf("%d", &B[i]);
	For(i, 2, n) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}

	DFS_work(1, 0);
	For(i, 1, n) printf("%lld\n", dp[i]);

	return 0;
}
