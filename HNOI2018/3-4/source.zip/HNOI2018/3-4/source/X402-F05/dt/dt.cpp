#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)

using namespace std;

const int N = 5010;
const int Mod = 998244353;

int Pow(int x, int e) {
	int ret = 1;
	while (e) {
		if (e & 1) ret = 1ll * ret * x % Mod;
		x = 1ll * x * x % Mod;
		e >>= 1;
	}
	return ret;
}

int S[N][N];
int n, k;

int main() {

	freopen("dt.in", "r", stdin);
	freopen("dt.out", "w", stdout);
	
	scanf("%d%d", &n, &k);

	S[0][0] = 1;
	For(i, 1, k) For(j, 1, i) S[i][j] = (S[i - 1][j - 1] + 1ll * j * S[i - 1][j]) % Mod;

	int ans = 0, coe = Pow(2, n), inv = (Mod + 1) / 2;
	For(i, 1, k) {
		coe = 1ll * coe * (n - i + 1) % Mod * inv % Mod, 
		ans = (ans + 1ll * S[k][i] * coe) % Mod;
	}
	printf("%d\n", ans);

	return 0;
}
