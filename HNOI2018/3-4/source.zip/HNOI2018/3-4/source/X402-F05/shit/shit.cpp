#include <bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

using namespace std;

const int N = 1e5 + 10;
const int Mod = 998244353;

int n;
char S[N];

void add(int &x, int y) {
	x += y;
	if (x >= Mod) x -= Mod;
}

namespace BF {

	int dp[N];
	int lcp[2510][2510];

	void main() {
		Forr(i, n, 1) Forr(j, n, 1) 
			lcp[i][j] = S[i] == S[j] ? lcp[i + 1][j + 1] + 1 : 0;
		dp[0] = 1;
		For(i, 1, n / 2) For(j, 0, i - 1) if(lcp[j + 1][n - i + 1] >= i - j) add(dp[i], dp[j]);
		printf("%d\n", dp[n / 2]);
	}

};

namespace Subtask2 {

	void main() {
		int ret = 1;
		For(i, 1, n) ret = 2 * ret % Mod;
		printf("%d\n", ret);
	}

};

int main() {

	freopen("shit.in", "r", stdin);
	freopen("shit.out", "w", stdout);

	scanf("%s", S + 1);
	n = strlen(S + 1);

	if (n <= 2500) {
		BF::main();
		return 0;
	}

	bool same = true;
	For(i, 2, n) same &= S[i] == S[1];
	if (same) {
		Subtask2::main();
		return 0;
	}

	puts("0");

	return 0;
}
