#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
const int maxn=100010;
int head[maxn],tot,n,A[maxn],B[maxn],dfn[maxn],num[maxn],siz[maxn],vis[maxn],clk;
struct edge{
    int to,next;
}e[maxn<<1];
inline void add(int u,int v){
	e[++tot].to=v;
	e[tot].next=head[u];
    head[u]=tot;
}
long long ans[maxn];
inline void dfs(int x,int fa){
	dfn[x]=++clk;num[clk]=x;siz[x]=1;ans[x]=LONG_LONG_MAX;
	for(register int i=head[x];i;i=e[i].next){
        int v=e[i].to;
        if(v!=fa){
            dfs(v,x);
            siz[x]+=siz[v];
        }
    }
	if(siz[x]==1)ans[x]=0;
	for(register int i=dfn[x]+1;i<=dfn[x]+siz[x]-1;++i){
		ans[x]=min(ans[x],ans[num[i]]+1ll*A[x]*B[num[i]]);
    }
}
int main(){
    freopen("ct.in","r",stdin);
    freopen("ct.out","w",stdout);
	read(n);
	for(register int i=1;i<=n;++i){
        read(A[i]);
    }
	for(register int i=1;i<=n;++i){
        read(B[i]);
    }
	for(register int i=1;i<=n-1;++i){
		int x,y;
		read(x);read(y);
		add(x,y);
        add(y,x);
	}
	clk=0;
    dfs(1,0);
	for(register int i=1;i<=n;++i){
        printf("%lld\n",ans[i]);
    }
	return 0;
}
