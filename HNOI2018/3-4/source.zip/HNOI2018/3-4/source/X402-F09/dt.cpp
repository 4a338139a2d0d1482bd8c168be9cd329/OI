#include<bits/stdc++.h>
//#include<iostream>
//#include<cstdio>
//#include<algorithm>
using namespace std;
long long mod=998244353;
const int mxk=5010;
long long s[mxk][mxk];
inline void read(int &x){
    char c=getchar();
    int p=1;
    x=0;
    while(!isdigit(c)){
        if(c=='-')p=-1;
        c=getchar();
    }
    while(isdigit(c)){
        x=(x<<1)+(x<<3)+(c^'0');
        c=getchar();
    }
    x*=p;
}
int n,k;
long long ans;
inline void pre_operation(){
    s[0][0]=1;
    for(register int i=1;i<=k+1;++i){
        for(register int j=1;j<=i;++j){
			s[i][j]=(s[i-1][j-1]+s[i-1][j]*(long long)j)%mod;
        }
    }
}
inline long long qpow(long long a,long long b){
    long long ret=1;
    while(b){
        if(b&1)(ret*=a)%=mod;
        b>>=1;
        (a*=a)%=mod;
    }
    return ret;
}
int main(){
    freopen("dt.in","r",stdin);
    freopen("dt.out","w",stdout);
    read(n);read(k);
    if(k==0){
        printf("%lld\n",qpow(2,n)-1);
        return 0;
    }
    pre_operation();
    long long now=1;
    for(register int j=0;j<=k;++j){
        (ans+=((long long)s[k][j]*qpow(2,n-j))%mod*now)%=mod;
        (now*=n-j)%=mod;
    }
    printf("%lld\n",ans%mod);
    return 0;
}
