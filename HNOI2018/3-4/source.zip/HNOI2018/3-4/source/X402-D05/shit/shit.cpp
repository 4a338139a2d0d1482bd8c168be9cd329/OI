#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
const long long md=998244353;
const long long md1=1e9+7,md2=1e9+9;
char str[maxn];
bool ok[2010][2010];
long long dp[maxn];
struct node{
	long long v1,v2;
}a[maxn];
long long powd(long long x,long long y,long long p){
	long long res=1;
	while(y){
		if(y&1) res=res*x%p;
		x=x*x%p;
		y>>=1;
	}
	return res;
}
int main(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	int n;
	scanf("%s",str+1);
	n=strlen(str+1);
	if(n>3000){
		printf("%lld\n",powd(2,n/2-1,md));
		return 0;
	}
	a[0]=(node){1,1};
	for(int i=1;i<=n;i++){
		a[i].v1=(a[i-1].v1*29+str[i]-'a'+1)%md1;
		a[i].v2=(a[i-1].v2*29+str[i]-'a'+1)%md2;
	}
	node x,y;
	for(int i=0;i<n/2;i++){
		for(int j=i+1;j<=n/2;j++){
			x.v1=(a[j].v1-a[i].v1*powd(29,j-i,md1)%md1+md1)%md1;
			x.v2=(a[j].v2-a[i].v2*powd(29,j-i,md2)%md2+md2)%md2;

			y.v1=(a[n-i].v1-a[n-j].v1*powd(29,j-i,md1)%md1+md1)%md1;
			y.v2=(a[n-i].v2-a[n-j].v2*powd(29,j-i,md2)%md2+md2)%md2;
			
			if(x.v1==y.v1&&x.v2==y.v2)
				ok[i][j]=1;
		}
	}
	dp[0]=1;
	for(int i=0;i<=n/2;i++)
		for(int j=i+1;j<=n/2;j++)
			if(ok[i][j])
				dp[j]=(dp[j]+dp[i])%md;
	printf("%lld\n",dp[n/2]);
	return 0;
}
