#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=100100;
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
long long dp[maxn];
long long fac[maxn],inv[maxn];
long long C(int x,int y){
	return fac[x]*inv[y]%md*inv[x-y]%md;
}
int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	if(k==0){
		printf("%lld\n",(powd(2,n)-1+md)%md);
		return 0;
	}
	fac[0]=1;
	for(int i=1;i<=k;i++)
		fac[i]=fac[i-1]*i%md;
	inv[k]=powd(fac[k],md-2);
	for(int i=k;i>=1;i--)
		inv[i-1]=inv[i]*i%md;

	for(int i=1;i<=k;i++)
		dp[i]=powd(i,k);
	for(int i=1;i<=k;i++)
		for(int j=1;j<i;j++)
			dp[i]=(dp[i]-dp[j]*C(i,j)%md+md)%md;
	long long c=1,res=0;
	for(int i=1;i<=k&&i<=n;i++){
		c=c*(n-i+1)%md;
		c=c*powd(i,md-2)%md;
		res=(res+c*powd(2,n-i)%md*dp[i])%md;
	}
	printf("%lld\n",res);
	return 0;
}
