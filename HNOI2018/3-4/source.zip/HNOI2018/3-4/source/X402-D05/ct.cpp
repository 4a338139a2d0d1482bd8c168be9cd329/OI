#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
#define mid ((l+r)>>1)
long long Min(long long x,long long y){
	return x<y?x:y;
}
int n;
int a[maxn],b[maxn];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
struct node{
	long long k,b;
}val[maxn];
bool cmp(const node &A,const node &B){
	return A.k>B.k;
}
struct Tree{
	vector<node> vec;
	vector<int> ti;
	void Insert(const node &A){
		while(!vec.empty()&&vec.back().k*ti.back()+vec.back().b>=A.k*ti.back()+A.b){
			vec.pop_back();
			ti.pop_back();
		}
		if(vec.empty()){
			vec.push_back(A);
			ti.push_back(-maxn);
		}
		else if(vec.back().k*maxn+vec.back().b<=A.k*maxn+A.b)
			return;
		else{
			node st=vec.back();
			long long x=(A.b-st.b)/(st.k-A.k);
			while(st.k*x+st.b>=A.k*x+A.b)
				x--;
			while(st.k*x+st.b<A.k*x+A.b)
				x++;
			vec.push_back(A);
			ti.push_back(x);
		}
	}
	long long Query(int x){
		if(ti.back()<=x)
			return vec.back().k*x+vec.back().b;
		int l=0,r=vec.size()-1;
		while(r-l>1){
			if(ti[mid]<=x) l=mid;
			else r=mid;
		}
		return Min(vec[l].k*x+vec[l].b,vec[r].k*x+vec[r].b);
	}
}d[maxn<<2];
void Merge(int h,int l,int r){
	static node c[maxn];
	int top=0;
	for(int i=l;i<=r;i++)
		c[++top]=val[i];
	sort(c+1,c+top+1,cmp);
	for(int i=1;i<=top;i++)
		d[h].Insert(c[i]);
}
int tr[maxn<<2];
void updata(int h,int l,int r,int p){
	if(l==r){
		Merge(h,l,r);
		return;
	}
	tr[h]++;
	if(p<=mid) updata(h<<1,l,mid,p);
	else updata(h<<1|1,mid+1,r,p);
	if(tr[h]==r-l+1)
		Merge(h,l,r);
}
long long Query(int h,int l,int r,int s,int t,int x){
	if(s<=l&&r<=t)
		return d[h].Query(x);
	if(t<=mid) return Query(h<<1,l,mid,s,t,x);
	else if(s>mid) return Query(h<<1|1,mid+1,r,s,t,x);
	else
		return Min(Query(h<<1,l,mid,s,mid,x),Query(h<<1|1,mid+1,r,mid+1,t,x));
}
int pre[maxn],mp[maxn],dfs_time;
void dfs_solve(int u,int fa){
	bool isleaf=1;
	pre[u]=++dfs_time,mp[dfs_time]=u;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		isleaf=0;
		dfs_solve(tto[i],u);
	}
	if(isleaf){
		val[pre[u]]=(node){b[u],0};
		updata(1,1,n,pre[u]);
		return;
	}
	long long ans=Query(1,1,n,pre[u]+1,dfs_time,a[u]);
	val[pre[u]]=(node){b[u],ans};
	updata(1,1,n,pre[u]);
}
int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	int s,t;
	for(int i=1;i<n;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	dfs_solve(1,-1);
	for(int i=1;i<=n;i++)
		printf("%lld\n",val[pre[i]].b);
	return 0;
}
