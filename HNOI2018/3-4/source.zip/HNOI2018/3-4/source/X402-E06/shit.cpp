#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;
const int mo = 998244353;
const int b0 = 233, b1 = 666;

int fpm(int x, int y) {
    int res = 1;
    for(; y > 0; y >>= 1) {
        if(y & 1)
            res = 1ll * res * x % mo;
        x = 1ll * x * x % mo;
    }
    return res;
}

char s[N + 5];
int n, dp[N + 5];
int pw0[N + 5], pw1[N + 5];
int hs0[N + 5], hs1[N + 5];

inline int get_sh0(int x, int y) {
    return (hs0[y] - 1ll * hs0[x-1] * pw0[y - x + 1] % mo + mo) % mo;
}
inline int get_sh1(int x, int y) {
    return (hs1[y] - 1ll * hs1[x-1] * pw1[y - x + 1] % mo + mo) % mo;
}
inline bool chk(int a, int b, int c, int d) {
    return (get_sh0(a, b) == get_sh0(c, d)) && (get_sh1(a, b) == get_sh1(c, d));
}

void input() {
    scanf("%s", s + 1);
    n = strlen(s + 1);

    bool tag = 1;
    for(int i = 1; i <= n; ++i) tag &= (s[i] == 'a');

    if(tag) {
        int ans = 1;
        for(int i = 1; i <= n/2 - 1; ++i) ans = ans * 2 % mo;
        printf("%d\n", ans), exit(0);
    }
}

void init() {

    pw0[0] = pw1[0] = 1; 
    for(int i = 1; i <= N; ++i) {
        pw0[i] = 1ll * pw0[i-1] * b0 % mo;
        pw1[i] = 1ll * pw1[i-1] * b1 % mo;
    }

    for(int i = 1; i <= n; ++i) {
        hs0[i] = (1ll * hs0[i-1] * b0 + s[i] - 'a') % mo;
        hs1[i] = (1ll * hs1[i-1] * b1 + s[i] - 'a') % mo;
    }
}

int main() {
    freopen("shit.in", "r", stdin);
    freopen("shit.out", "w", stdout);

    input();
    init();

    dp[0] = 1;
    for(int i = 1; i <= n / 2; ++i) {
        for(int j = 0; j < i; ++j) if(chk(j + 1, i, n + 1 - i, n - j)) {
            dp[i] = (dp[i] + dp[j]) % mo;
        }
    }
    printf("%d\n", dp[n / 2]);

    return 0;
}
