#include <bits/stdc++.h>

using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;

#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template <typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48;
    return x *= f;
}

const int N = 100000;

struct Point { 
    ll x, y; 
    Point(ll _x = 0, ll _y = 0): x(_x), y(_y) { }

    bool operator < (const Point& rhs) const { 
        return x < rhs.x || (x == rhs.x && y < rhs.y);
    }
};

Point operator + (const Point& a, const Point& b) { return Point(a.x + b.x, a.y + b.y); }
Point operator - (const Point& a, const Point& b) { return Point(a.x - b.x, a.y - b.y); }
ll cross(const Point& a, const Point& b) { return a.x * b.y - a.y * b.x; }

namespace SEG {
    const int SZ = N << 2;

#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)

    int sum[SZ + 5];
    vector<Point> conv[SZ + 5];

    void build(int u) {
        static vector<Point> temp;

        temp.resize(conv[lc].size() + conv[rc].size());
        std::merge(conv[lc].begin(), conv[lc].end(), conv[rc].begin(), conv[rc].end(), temp.begin());

        for(auto p : temp) {
            while(conv[u].size() > 1 && cross(p - conv[u][conv[u].size() - 2], 
                                 conv[u].back() - conv[u][conv[u].size() - 2]) >= 0) conv[u].pop_back();
            conv[u].pb(p);
        }
    }

    void modify(int u, int l, int r, int p, const Point& v) {
        if(l == r) {
            sum[u] = 1;
            conv[u].pb(v);
            return;
        }

        if(p <= mid)
            modify(lc, l, mid, p, v);
        else 
            modify(rc, mid+1, r, p, v);

        if((sum[u] = sum[lc] + sum[rc]) == r - l + 1) build(u);
    }

    ll query(int u, int l, int r, int x, int y, ll a) {
        if(x <= l && r <= y) {
            assert(sum[u] == r - l + 1);
            int _l = 0, _r = conv[u].size() - 1;

            while(_l < _r) {
                int _m = (_l + _r + 1) >> 1;
                if((conv[u][_m].y - conv[u][_m-1].y) <= -a * (conv[u][_m].x - conv[u][_m-1].x)) _l = _m; else _r = _m - 1;
            }

            return conv[u][_l].x * a + conv[u][_l].y;
        }

        ll ans = LLONG_MAX;
        if(x <= mid) chkmin(ans, query(lc, l, mid, x, y, a));
        if(mid < y) chkmin(ans, query(rc, mid+1, r, x, y, a));

        return ans;
    }
}

int n;
vector<int> G[N + 5];
ll a[N + 5], b[N + 5], dp[N + 5];
int dfnL[N + 5], dfnR[N + 5], dfs_clock;

void pre_dfs(int u, int f = 0) {
    dfnL[u] = ++ dfs_clock;

    for(int i = 0; i < (int) G[u].size(); ++i) {
        int v = G[u][i];
        if(v == f) continue;

        pre_dfs(v, u);
    }

    dfnR[u] = dfs_clock;
}

void dfs(int u, int f = 0) {

    for(int i = 0; i < (int) G[u].size(); ++i) {
        int v = G[u][i];
        if(v == f) continue;
        
        dfs(v, u);
    }

    if(dfnL[u] == dfnR[u]) {
        dp[u] = 0;
    } else {
        dp[u] = SEG::query(1, 1, n, dfnL[u] + 1, dfnR[u], a[u]);
    }
    SEG::modify(1, 1, n, dfnL[u], Point(b[u], dp[u]));
}

int main() {
    freopen("ct.in", "r", stdin);
    freopen("ct.out", "w", stdout);

    read(n);
    for(int i = 1; i <= n; ++i) read(a[i]);
    for(int i = 1; i <= n; ++i) read(b[i]);
    for(int i = 1; i < n; ++i) {
        static int u, v;
        read(u), read(v);
        G[u].pb(v), G[v].pb(u);
    }

    pre_dfs(1);
    dfs(1);

    for(int i = 1; i <= n; ++i) printf("%lld\n", dp[i]);

    return 0;
}
