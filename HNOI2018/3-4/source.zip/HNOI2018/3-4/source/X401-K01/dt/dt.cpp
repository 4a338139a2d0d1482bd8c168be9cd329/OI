#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int ans;
int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	int i,j,k,m,n;m=1;
	scanf("%d%d",&n,&k);
	if(k==0){
		for(i=1;i<=n;++i)ans=(ans*2)%mod;
		printf("%d",ans-1);
		return 0;
	}
	return 0;
}
