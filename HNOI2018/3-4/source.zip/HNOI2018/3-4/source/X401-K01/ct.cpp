#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
int a[maxn],b[maxn],ans;
int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	int i,j,k,m,n;
	scanf("%d",&n);
	for(i=1;i<=n;++i)scanf("%d",&a[i]);
	for(i=1;i<=n;++i)scanf("%d",&b[i]),ans+=a[i-1]*b[i];
	for(i=1;i<n;++i)
		scanf("%d%d",&j,&k);
	for(i=1;i<=n;++i){printf("%d\n",ans);ans-=a[i]*b[i+1];}
	return 0;
}
