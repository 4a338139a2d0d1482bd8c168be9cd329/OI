#include<bits/stdc++.h>
using namespace std;

char s[100010];
bool d[100010];
int ans, n;

void dfs(int u) {
	if(u == n>>1) {
		int i = 1, j, k;
		while(i <= (n>>1)) {
			for(j = i; j <= n>>1; j++) 
				if(d[j]) break;
			int len = j-i;
			for(k = i; k <= j; k++) 
				if(s[k] != s[n-len+k-(i<<1)+1]) return;
			i = j+1;
		}
		ans++;
		return;
	}
	d[u] = true;
	dfs(u+1);
	d[u] = false;
	dfs(u+1);
}

int main() {
	freopen("shit.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	scanf("%s", s+1);
	n = strlen(s+1);
	//printf("%d\n", n);
	d[n>>1] = true;
	dfs(1);
	printf("%d\n", ans);
	return 0;
}
