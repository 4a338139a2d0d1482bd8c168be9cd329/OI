#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;

char s[100010], t[100010];
int ans, n;
bool legal[2010][2010];
ll dp[2010];

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int main() {
	freopen("shit.in", "r", stdin);
	freopen("shit.out", "w", stdout);

	int i, j, d;
	scanf("%s", s+1);
	n = strlen(s+1);
	if(n > 2000) {
		n >>= 1;
		printf("%lld\n", qpow(2, n-1));
		return 0;
	}
	n >>= 1;
	strcpy(t+1, s+n+1);
	reverse(t+1, t+n+1);
	/*for(i = 1; i <= n; i++) printf("%c", s[i]);
	printf("\n");
	for(i = 1; i <= n; i++) printf("%c", t[i]);
	printf("\n");*/
	for(i = 1; i <= n; i++) if(s[i] == t[i]) legal[i][i] = true;
	for(i = 1; i < n; i++) if(s[i] == t[i+1] && s[i+1] == t[i]) legal[i][i+1] = true;
	for(d = 3; d <= n; d++) 
		for(i = 1; i+d-1 <= n; i++) {
			j = i+d-1;
			if(s[i] == t[j] && s[j] == t[i]) legal[i][j] = legal[i+1][j-1];
		}
	dp[0] = 1;
	for(i = 1; i <= n; i++) 
		for(j = 0; j < i; j++) 
			if(legal[j+1][i]) update(dp[i], dp[j]);
	printf("%lld\n", dp[n]);
	return 0;
}
