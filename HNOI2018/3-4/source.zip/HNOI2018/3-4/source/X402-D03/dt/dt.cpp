#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;
const int MAXK = 5010;

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int n, K;
ll S[MAXK][MAXK], ans;

int main() {
	freopen("dt.in", "r", stdin);
	freopen("dt.out", "w", stdout);

	scanf("%d%d", &n, &K);
	int i, j;
	S[0][0] = 1;
	for(i = 1; i <= K; i++) {
		S[i][0] = 0;
		for(j = 1; j <= i; j++) 
			S[i][j] = (S[i-1][j-1]+S[i-1][j]*j%MOD)%MOD;
	}
	ll cur = n%MOD;
	for(i = 1; i <= min(n, K); i++) {
		ll res = S[K][i];
		update(ans, res*cur%MOD*qpow(2, n-i)%MOD);
		cur = cur * (n-i)%MOD;
	}
	update(ans, S[K][0]*(qpow(2, n)-1)%MOD);
	printf("%lld\n", ans);
	return 0;
}
