#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;
const int MAXN = 1000010;

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int n, K;
ll fac[MAXN], ifac[MAXN], ans;

inline ll binom(ll x, ll y) {
	return fac[x]*ifac[y]%MOD*ifac[x-y]%MOD;
}

int main() {
	freopen("dt.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	scanf("%d%d", &n, &K);
	int i;
	fac[0] = 1;
	for(i = 1; i <= n; i++) fac[i] = fac[i-1]*i%MOD;
	ifac[n] = qpow(fac[n], MOD-2);
	for(i = n; i >= 1; i--) ifac[i-1] = ifac[i]*i%MOD;
	for(i = 1; i <= n; i++) {
		update(ans, binom(n, i)*qpow(i, K)%MOD);
		//printf(":: %lld %lld\n", ans, binom(n, i));
	}
	printf("%lld\n", ans);
	return 0;
}
