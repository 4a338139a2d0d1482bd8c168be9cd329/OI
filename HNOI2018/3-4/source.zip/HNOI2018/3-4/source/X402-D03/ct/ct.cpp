#include<bits/stdc++.h>
using namespace std;

#define mkp make_pair
typedef long long ll;
typedef long double ld;
const int MAXN = 100010;
const ll INF = 1LL<<61;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmin(ll &cur, ll val) {
	if(val < cur) cur = val;
}

struct Point{
	ll x, y;
	Point(ll x0 = -INF, ll y0 = -INF): x(x0), y(y0) {}
	bool operator < (const Point &rhs) const {
		return x < rhs.x || (x == rhs.x && y < rhs.y);
	}
	bool operator == (const Point &rhs) const {
		return x == rhs.x && y == rhs.y;
	}
};

class Convex_Hull {
private:
	set<Point> s;
	set<pair<ld, Point> > k;
	set<Point>::iterator it, p, q;
	set<pair<ld, Point> >::iterator j;
	inline ld slope(const Point &a, const Point &b) {
		return (ld)(a.y-b.y)/(a.x-b.x);
	}
public:
	inline void insert(const Point &x) {
		it = s.lower_bound(x);
		if(it != s.end() && (*it == x)) return;
		if(it != s.begin() && it != s.end()) {
			p = prev(it);
			if(slope(x, *p) <= slope(*it, *p)) return;
			k.erase(mkp(slope(*it, *p), *it));
		}
		s.insert(x), it = s.lower_bound(x);
		if(it != s.begin()) {
			p = prev(it);
			while(p != s.begin() && slope(*p, *prev(p)) <= slope(*it, *p)) {
				k.erase(mkp(slope(*p, *prev(p)), *p));
				q = prev(p), s.erase(p), p = q;
			}
		}
		if(next(it) != s.end()) {
			p = next(it);
			while(next(p) != s.end() && slope(*p, *it) <= slope(*next(p), *p)) {
				k.erase(mkp(slope(*next(p), *p), *next(p)));
				q = next(p), s.erase(p), p = q;
			}
		}
		if(it != s.begin()) 
			k.insert(mkp(slope(*it, *prev(it)), *it));
		if(next(it) != s.end())
			k.insert(mkp(slope(*next(it), *it), *next(it)));
	}
	inline ll Query(ll x) {
		if(s.size() == 1) return x*(s.begin()->x)-(s.begin()->y);
		j = k.lower_bound(mkp(x, Point()));
		if(j == k.end()) return x * (s.begin()->x)-(s.begin()->y);
		return x * (j->second).x-(j->second).y;
	}
	inline void output() {
		for(p = s.begin(); p != s.end(); p++) 
			printf("(%lld %lld), ", p->x, p->y);
		printf("\n");
		for(j = k.begin(); j != k.end(); j++)
			printf("(%.4LF, (%lld, %lld)), ", j->first, (j->second).x, (j->second).y);
		printf("\n");
	}
};

Convex_Hull *c[MAXN];

int st[MAXN], to[MAXN<<1];
int nxt[MAXN<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
	to[++e] = u, nxt[e] = st[v];
	st[v] = e;
}

int n;
ll a[MAXN], b[MAXN];
int size[MAXN], son[MAXN];
ll dp[MAXN];

void merge(int u, int fa, int r) {
	int i;
	c[r]->insert(Point(b[u], -dp[u]));
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		merge(v, u, r);
	}
}

void dfs(int u, int fa) {
	//printf("dfs(%d, %d)\n", u, fa);
	int i;
	size[u] = 1;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		dfs(v, u), size[u] += size[v];
		if(size[v] > size[son[u]]) son[u] = v;
	}
	if(size[u] == 1) {
		c[u] = new Convex_Hull();
		c[u]->insert(Point(b[u], 0));
		return;
	}
	c[u] = c[son[u]];
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa || v == son[u]) continue;
		merge(v, u, u);
	}
	dp[u] = c[u]->Query(a[u]);
	c[u]->insert(Point(b[u], -dp[u]));
}

int main() {
	freopen("ct.in", "r", stdin);
	freopen("ct.out", "w", stdout);

	int i;
	n = read();
	generate(a+1, a+n+1, read);
	generate(b+1, b+n+1, read);
	for(i = 1; i < n; i++) Add(read(), read());
	dfs(1, 0);
	for(i = 1; i <= n; i++) printf("%lld\n", dp[i]);
	//cerr << clock() << endl;
	return 0;
}
