#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 5010;
const ll INF = 1LL<<50;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline void chkmin(ll &cur, ll val) {
	if(val < cur) cur = val;
}

int st[MAXN], to[MAXN<<1];
int nxt[MAXN<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
	to[++e] = u, nxt[e] = st[v];
	st[v] = e;
}

int n, a[MAXN], b[MAXN];
ll dp[MAXN];
int D[MAXN], cnt;

void dfs(int u, int fa) {
	D[++cnt] = u;
	int i, B = cnt;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		dfs(v, u);
	}
	if(B != cnt) {
		dp[u] = INF;
		for(i = B+1; i <= cnt; i++) 
			chkmin(dp[u], dp[D[i]]+(ll)b[D[i]]*a[u]);
	}
}

int main() {
	freopen("ct.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i;
	n = read();
	generate(a+1, a+n+1, read);
	generate(b+1, b+n+1, read);
	for(i = 1; i < n; i++) Add(read(), read());
	dfs(1, 0);
	for(i = 1; i <= n; i++) printf("%lld\n", dp[i]);
	return 0;
}
