#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10,maxk=2e3+10,mod=998244353;
int dp[maxn];
char s[maxn],c[maxn];
int p[maxk][maxk];
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
#endif
	scanf("%s",s+1);
	int n=strlen(s+1);
	REP(i,1,n/2) c[i*2-1]=s[i],c[i*2]=s[n-i+1];
	dp[0]=1;
	if(n<maxk){
		for(int l=2;l<=n;l+=2)
			REP(j,1,n-l+1){
				if(l==2) p[j][j+l-1]=(c[j]==c[j+1]);
				else p[j][j+l-1]=(c[j]==c[j+l-1])&p[j+1][j+l-2];
			}
		for(int i=2;i<=n;i+=2)
			for(int j=0;j<i;j+=2)
				if(p[j+1][i])
					add(dp[i],dp[j]);
	}
	else{
		int sum=1;
		for(int i=2;i<=n;i+=2){
			dp[i]=sum;
			add(sum,dp[i]);
		}
	}
	printf("%d\n",dp[n]);
	return 0;
}
