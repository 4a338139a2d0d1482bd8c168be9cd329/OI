#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmin(ll &x,ll y){return (y<x)?(x=y,1):0;}
const int maxn=1e5+10,inf=0x3f3f3f3f;
int n,Begin[maxn],Next[maxn<<1],to[maxn<<1],e;
int a[maxn],b[maxn];
ll dp[maxn];
void add_edge(int x,int y){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
}
namespace bf{
	void solve(int pos,int x,int ff){
		for(int i=Begin[x];i;i=Next[i]){
			if(to[i]==ff) continue;
			chkmin(dp[pos],dp[to[i]]+1ll*a[pos]*b[to[i]]);
			solve(pos,to[i],x);
		}
	}
	void dfs(int x,int ff){
		int sz=0;
		for(int i=Begin[x];i;i=Next[i]){
			if(to[i]==ff) continue;
			sz++;
			dfs(to[i],x);
		}
		if(!sz) dp[x]=0;
		else dp[x]=inf,solve(x,x,ff);
	}
}
namespace b1{
	ll g[maxn];
	void dfs(int x,int ff){
		int sz=0;
		dp[x]=0,g[x]=0;
		for(int i=Begin[x];i;i=Next[i]){
			if(to[i]==ff) continue;
			dfs(to[i],x);
			++sz;
			chkmin(dp[x],g[to[i]]);
			chkmin(g[x],g[to[i]]);
		}
		if(sz){
			dp[x]+=a[x];
			chkmin(g[x],dp[x]);
		}
	}
}
namespace std{
	int g[maxn],fa[maxn];
	void bfs(int x,int c){
		int S=20;
		if(chkmin(dp[x],dp[c]+1ll*a[x]*b[c]))g[x]=c;
		queue<int> q;
		q.push(g[c]);
		int d=1,tmp=1;
		while(!q.empty() && d<=S){
			++d;int res=0;
			while(tmp--){
				int u=q.front();
				q.pop();
				if(chkmin(dp[x],dp[u]+1ll*a[x]*b[u])) g[x]=u;
				for(int i=Begin[u];i;i=Next[i]){
					if(to[i]==fa[u]) continue;
					q.push(to[i]),res++;
				}
			}
			tmp=res;
		}
	}
	void dfs(int x,int ff){
		int sz=0;
		dp[x]=inf;
		for(int i=Begin[x];i;i=Next[i]){
			if(to[i]==ff) continue;
			fa[to[i]]=x;
			dfs(to[i],x);
			sz++;
			bfs(x,to[i]);
		}
		if(!sz){
			dp[x]=0;g[x]=x;
		}
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
#endif
	n=read();
	int flag1=1;
	REP(i,1,n) a[i]=read();
	REP(i,1,n) b[i]=read(),flag1&=(b[i]==1);
	REP(i,1,n-1){
		int x=read(),y=read();
		add_edge(x,y),add_edge(y,x);
	}
	if(n<=5e3) bf::dfs(1,0);
	else if(flag1) b1::dfs(1,0);
	else std::dfs(1,0);
	REP(i,1,n) printf("%lld\n",dp[i]);
	return 0;
}
