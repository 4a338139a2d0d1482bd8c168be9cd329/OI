#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=5e3+10,mod=998244353;
int S[maxn][maxn],fac[maxn],C[maxn];
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return res;
}
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
#endif
	int n=read(),k=read();
	S[0][0]=1;
	REP(i,1,k){
		S[i][0]=0;
		S[i][i]=1;
		REP(j,1,i-1)
			S[i][j]=(S[i-1][j-1]+1ll*S[i-1][j]*j%mod)%mod;
	}
	fac[0]=C[0]=1;
	REP(i,1,k) fac[i]=1ll*fac[i-1]*i%mod;
	REP(i,1,min(n,k)) C[i]=1ll*C[i-1]*(n-i+1)%mod*ksm(i,mod-2)%mod;
	int ans=0;
	REP(i,0,min(n,k)) add(ans,1ll*S[k][i]*C[i]%mod*fac[i]%mod*ksm(2,n-i)%mod);
	if(k==0) add(ans,mod-1);
	printf("%d\n",ans);
	return 0;
}
