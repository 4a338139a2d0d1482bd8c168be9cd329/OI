#include<bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define pp pop_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(),(x).end()

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

typedef long long LL;
typedef pair<int,LL> PIL;

const int maxn=100010;
const LL INF=0x3f3f3f3f3f3f3f3fll;

int n,A[maxn],B[maxn];

int head[maxn],nxt[maxn<<1],to[maxn<<1],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}

int dfn[maxn],rdfn[maxn],ed[maxn],cur;
void dfs(int u,int fa){
    dfn[u]=++cur; rdfn[cur]=u;
    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(v!=fa) dfs(v,u);
    }
    ed[u]=cur;
}

LL f[maxn];

LL cross(PIL a,PIL b){
    return b.second*a.first-a.second*b.first;
}

namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r

    vector<PIL> T[maxn<<2];

    void build(int h){
        static vector<PIL> t;
        t.resize(SZ(T[ls])+SZ(T[rs]));
        merge(ALL(T[ls]),ALL(T[rs]),t.begin());
        for(int i=0;i<SZ(t);i++){
            while(SZ(T[h])>1){
                PIL a=mp(t[i].first-T[h][SZ(T[h])-2].first,t[i].second-T[h][SZ(T[h])-2].second);
                PIL b=mp(T[h][SZ(T[h])-1].first-T[h][SZ(T[h])-2].first,T[h][SZ(T[h])-1].second-T[h][SZ(T[h])-2].second);
                if(cross(a,b)>=0) T[h].pp();
                else break;
            }
            T[h].pb(t[i]);
        }
    }

    void update(int h,int l,int r,int p,PIL x){
        if(l==r) return void(T[h].pb(x));
        if(p<=mid) update(ls,lc,p,x);
        else update(rs,rc,p,x);
        if(p==l) build(h);
    }

    LL query(int h,int l,int r,int L,int R,int w){
        if(L<=l&&r<=R){
            int qL=0,qR=SZ(T[h])-1;
            while(qL<qR){
                int m=(qL+qR+1)>>1;
                if(!m||1ll*(T[h][m].second-T[h][m-1].second)<=1ll*w*(T[h][m].first-T[h][m-1].first)) qL=m;
                else qR=m-1;
            }
            return -1ll*w*T[h][qL].first+T[h][qL].second;
        }
        
        LL ret=INF;
        if(L<=mid) chkmin(ret,query(ls,lc,L,R,w));
        if(R>mid) chkmin(ret,query(rs,rc,L,R,w));
        return ret;
    }
}

using namespace SGT;

int main(){
    freopen("ct.in","r",stdin);
    freopen("ct.out","w",stdout);

    read(n);
    for(int i=1;i<=n;i++) read(A[i]);
    for(int i=1;i<=n;i++) read(B[i]);
    for(int i=1;i<n;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ae(v,u);
    }

    dfs(1,0);

    for(int i=n;i;i--){
        int u=rdfn[i];
        if(dfn[u]==ed[u]) f[u]=0;
        else f[u]=query(1,1,n,dfn[u]+1,ed[u],-A[u]);
        update(1,1,n,dfn[u],mp(B[u],f[u]));
    }

    for(int i=1;i<=n;i++) printf("%lld\n",f[i]);

    return 0;
}
