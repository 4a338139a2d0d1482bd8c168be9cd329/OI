#include<bits/stdc++.h>

using namespace std;

template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }

template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}

const int maxk=5010,mo=998244353;

int S[maxk][maxk];
int n,k;

void init(){
    for(int i=0;i<=maxk-10;i++){
        S[i][0]=0; S[i][i]=1;
        for(int j=1;j<i;j++) S[i][j]=(S[i-1][j-1]+1ll*S[i-1][j]*j%mo)%mo;
    }
}

void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}

int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}

int ans;

int main(){
    freopen("dt.in","r",stdin);
    freopen("dt.out","w",stdout);

    init();
    read(n); read(k);

    int coe=1;
    for(int i=0;i<=k&&i<=n;i++){
        Add(ans,1ll*S[k][i]*fpm(2,n-i)%mo*coe%mo);
        coe=1ll*coe*(n-i)%mo;
    }

    printf("%d\n",((ans-(k==0))%mo+mo)%mo);

    return 0;
}
