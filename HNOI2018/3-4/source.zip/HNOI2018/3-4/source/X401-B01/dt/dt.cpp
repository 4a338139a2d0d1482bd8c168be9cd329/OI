#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=1000000+10,mod=998244353;
inline void read(int &x)
{
	x=0;   int p=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') p=-1; ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		x=(x<<3)+(x<<1)+(ch^'0'); ch=getchar();
	}
	x=x*p;
}
int n,k;
int f[2][maxn];

long long ksm(long long a,long long b)
{
	long long base=a%mod,ans=1;
	while(b>0){
		if(b&1) ans=(ans*base)%mod;
		base=(base*base)%mod;
		b=b>>1;
	}
	return ans%mod;
}

int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	read(n); read(k);
	if(k==0){
		long long ans=ksm(2,n)%mod-1;
		cout<<ans<<endl;
		return 0;
	}
	if(k==1){
		long long ans=( ( (4*ksm(2,n-3) ) %mod) * n )%mod;
		cout<<ans<<endl;
		return 0;
	}
	if(n<=1000000){
		bool flag=0;
		f[flag][0]=1; f[flag^1][0]=1; f[flag^1][1]=1;
		for(register int i=2;i<=n;i++){
			f[flag][0]=1;
			for(register int j=1;j<=i;j++) f[flag][j]=(f[flag^1][j-1]+f[flag^1][j])%mod;
			flag=flag^1;
		}
		int o=n%2;
		long long ans=0;
		for(register int i=1;i<=n;i++){
			ans+=( f[o][i]*ksm(i,k) )%mod; ans=(ans+mod)%mod;
		}
		cout<<ans<<endl;
	}
	return 0;
}
