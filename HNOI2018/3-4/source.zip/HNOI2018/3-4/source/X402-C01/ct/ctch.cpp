/************************************************
 * Au: Hany01
 * Prob: ct chain
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (1000000000000000000ll)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia
#define N (100000)

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("ct.in", "r", stdin);
    freopen("ct.out", "w", stdout);
}

const int maxn = 100005, maxm = 200005;

int tr[maxn << 3];
int nex[maxm], v[maxm], beg[maxn], n;
LL A[maxn], B[maxn], dp[maxn];

#define lc (t << 1)
#define rc (lc | 1)
#define mid ((l + r) >> 1)
int query(int t, int l, int r, int x)
{
	if (tr[t] != -1) return tr[t];
	if (x <= mid) return query(lc, l, mid, x);
	return query(rc, mid + 1, r, x);
}

void update(int t, int l, int r, int x, int y, int dt)
{
	if (x <= l && r <= y) { tr[t] = dt; return ; }
	if (tr[t] != -1) tr[lc] = tr[rc] = tr[t];
	if (x <= mid) update(lc, l, mid, x, y, dt);
	if (y > mid) update(rc, mid + 1, r, x, y, dt);
	if (tr[lc] == tr[rc]) tr[t] = tr[lc];
	else tr[t] = -1;
}

void modify(int t, int l, int r, int j)
{
	if (tr[t] == -1) {
		modify(lc, l, mid, j), modify(rc, mid + 1, r, j);
		return;
	}
	register int k = tr[t];
	if (B[j] == B[k]) {
		if (dp[k] - dp[j] > 0) tr[t] = j;
		return;
	}
	if (B[j] > B[k]) {
		int t = ceil((dp[k] - dp[j]) * 1. / (B[j] - B[k])) - 1;
		if (l <= t) update(1, -N, N, l, t, j);
	}
	if (B[j] < B[k]) {
		int t = ceil((dp[k] - dp[j]) * 1. / (B[j] - B[k])) + 1;
		if (t <= r) update(1, -N, N, t, r, j);
	}
}

int main()
{
    File();

	int flag = 1, uu, vv;
	n = read();
	For(i, 1, n) A[i] = read();
	For(i, 1, n) B[i] = read();
	For(i, 2, n) {
		uu = read(), vv = read();
		if (abs(uu - vv) != 1) flag = 0;
	}

	if (flag) {
		dp[n] = 0;
		tr[1] = n;
		Fordown(i, n - 1, 1) {
			register int id = query(1, -N, N, A[i]);
			dp[i] = dp[id] + A[i] * B[id];
			modify(1, -N, N, i);
		}
		For(i, 1, n) printf("%lld\n", dp[i]);
		return 0;
	}

    return 0;
}
