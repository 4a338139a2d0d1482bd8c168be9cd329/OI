/************************************************
 * Au: Hany01
 * Prob: ct bf
 * Email: hany01@foxmail.com
************************************************/

#include<bits/stdc++.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
#define rep(i, j) for (register int i = 0, i##_end_ = (j); i < i##_end_; ++ i)
#define For(i, j, k) for (register int i = (j), i##_end_ = (k); i <= i##_end_; ++ i)
#define Fordown(i, j, k) for (register int i = (j), i##_end_ = (k); i >= i##_end_; -- i)
#define Set(a, b) memset(a, b, sizeof(a))
#define Cpy(a, b) memcpy(a, b, sizeof(a))
#define fir first
#define sec second
#define pb(a) push_back(a)
#define mp(a, b) make_pair(a, b)
#define ALL(a) (a).begin(), (a).end()
#define SZ(a) ((int)(a).size())
#define INF (0x3f3f3f3f)
#define INF1 (2139062143)
#define Mod (1000000007)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define y1 wozenmezhemecaia

template <typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, 1 : 0; }

inline int read()
{
	register int _, __; register char c_;
    for (_ = 0, __ = 1, c_ = getchar(); c_ < '0' || c_ > '9'; c_ = getchar()) if (c_ == '-') __ = -1;
    for ( ; c_ >= '0' && c_ <= '9'; c_ = getchar()) _ = (_ << 1) + (_ << 3) + (c_ ^ 48);
    return _ * __;
}

inline void File()
{
    freopen("ct.in", "r", stdin);
    freopen("ct.out", "w", stdout);
}

const int maxn = 100005, maxm = 200005;

int n, v[maxm], e, nex[maxm], beg[maxn], cnt, dfn[maxn], id[maxn], sz[maxn];
LL A[maxn], B[maxn], dp[maxn], mindp[maxn];

inline void add(int uu, int vv) { v[++ e] = vv, nex[e] = beg[uu], beg[uu] = e; }

void dfs(int u, int fa)
{
	dfn[u] = ++ cnt, sz[u] = 1, id[cnt] = u;
	for (register int i = beg[u]; i; i = nex[i]) if (fa != v[i]) dfs(v[i], u), sz[u] += sz[v[i]];
	if (sz[u] == 1) { dp[u] = 0; return ; }
	For(i, dfn[u] + 1, dfn[u] + sz[u] - 1) chkmin(dp[u], dp[id[i]] + A[u] * B[id[i]]);
}

void cheat(int u, int fa)
{
	for (register int i = beg[u]; i; i = nex[i]) if (fa != v[i]) cheat(v[i], u), chkmin(mindp[u], mindp[v[i]]);
	if (mindp[u] == 1000000000000000000ll) dp[u] = 0;
	else dp[u] = mindp[u] + A[u];
	chkmin(mindp[u], dp[u]);
}

int main()
{
    File();
	register int uu, vv, mark = 1;
	n = read();
	For(i, 1, n) A[i] = read();
	For(i, 1, n) {
		B[i] = read();
		if (B[i] != 1) mark = 0;
	}
	For(i, 2, n) uu = read(), vv = read(), add(uu, vv), add(vv, uu);
	For(i, 1, n) dp[i] = 1000000000000000000ll;

	if (mark) {
		For(i, 1, n) mindp[i] = 1000000000000000000ll;
		cheat(1, 1);
		For(i, 1, n) printf("%lld\n", dp[i]);
		return 0;
	}
	For(i, 1, n) dp[i] = 1000000000000000000ll;
	dfs(1, 1);
	For(i, 1, n) printf("%lld\n", dp[i]);

    return 0;
}
