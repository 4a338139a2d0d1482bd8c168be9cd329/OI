#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const LL maxn = 5e3+5, Mod = 998244353 ;
LL n, m, S[maxn][maxn] ;
void init() {
	LL i, j ;
	S[0][0] = 1 ;
	for ( i = 1 ; i <= 5e3 ; i ++ ) {
		S[i][0] = 0 ;
		for ( j = 1 ; j <= i ; j ++ )
			S[i][j] = (S[i - 1][j - 1] + j*S[i - 1][j]%Mod)%Mod ;
	}
}
LL Qpow ( LL a, LL b, LL rec = 1 ) {
	for ( ; b ; b >>= 1, (a *= a) %= Mod )
		if (b&1) (rec *= a) %= Mod ;
	return rec ;
}
int main() {
	freopen ( "dt.in", "r", stdin ) ;
	freopen ( "dt.out", "w", stdout ) ;
	cin >> n >> m ;
	init() ;
	LL i, fac = 1, com = 1, ans = 0, lim = min(n, m), inv2 = Qpow(2LL, Mod-2), Pow = Qpow(2LL, n) ;
	for ( i = 1 ; i <= lim ; i ++ ) {
		(com *= (n-i+1)*Qpow(i, Mod-2)%Mod) %= Mod ;
		(Pow *= inv2) %= Mod ;
		(fac *= i) %= Mod ;
		(ans += S[m][i]*com%Mod*Pow%Mod*fac%Mod) %= Mod ;
	}
	cout << ans << endl ;
	return 0 ;
}
