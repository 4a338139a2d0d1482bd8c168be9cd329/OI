#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const int maxn = 2e5+5, Mod = 998244353 ;
int rnk[maxn], n, m, sa[maxn], height[maxn], c[maxn] ;
int f[maxn][20], dp[maxn] ;
int a1[maxn], a2[maxn] ;
char s[maxn] ;
void create() {
	int i, j ;
	for ( i = 2 ; i <= n ; i ++ )
		f[i][0] = height[i] ;
	for ( j = 1 ; j < 20 ; j ++ )
		for ( i = 2 ; i+(1<<j)-1 <= n ; i ++ )
			f[i][j] = min(f[i][j - 1], f[i+(1<<(j-1))][j - 1]) ;
}
int Query ( int l, int r ) {
	if (l > r) swap(l, r) ;
	++ l ;
	int len = log(r-l+1)/log(2) ;
	return min(f[l][len], f[r-(1<<len)+1][len]) ;
}
void get_sa() {
    int i, p, len ;
    int *x = a1, *y = a2 ;
    memset ( c, 0, sizeof c ) ;
	m = 30 ;
    for ( i = 1 ; i <= n ; i ++ ) c[x[i] = s[i]-'a'+1] ++ ;
    for ( i = 1 ; i <= m ; i ++ ) c[i] += c[i - 1] ;
    for ( i = n ; i ; i -- ) sa[c[x[i]]--] = i ;

    for ( len = 1 ; len < n ; len <<= 1, m = p ) {
        p = 0 ;
        for ( i = n-len+1 ; i <= n ; i ++ ) y[++p] = i ;
        for ( i = 1 ; i <= n ; i ++ )
            if (sa[i] > len) y[++p] = sa[i]-len ;

        memset ( c, 0, sizeof c ) ;
        for ( i = 1 ; i <= n ; i ++ ) c[x[y[i]]] ++ ;
        for ( i = 1 ; i <= m ; i ++ ) c[i] += c[i - 1] ;
        for ( i = n ; i ; i -- ) sa[c[x[y[i]]]--] = y[i] ;

        swap(x, y) ;
        p = 1 ;
        x[sa[1]] = 1 ;
        for ( i = 2 ; i <= n ; i ++ )
            if (y[sa[i]]==y[sa[i-1]] && y[sa[i]+len]==y[sa[i-1]+len])
                x[sa[i]] = p ;
            else x[sa[i]] = ++p ;
        if (p >= n) break ;
    }
}
void solve() {
	int i, j ;
	n >>= 1 ;
	dp[0] = 1 ;
	for ( i = 2*n ; i > n ; i -- )
		for ( j = 0 ; j < 2*n-i+1 ; j ++ )
			if (Query(rnk[j+1],rnk[i])+j >= 2*n-i+1)
				(dp[2*n-i+1] += dp[j]) %= Mod ;
	cout << dp[n] << endl ;
}
int Qpow ( int a, int b, int rec = 1 ) {
	for ( ; b ; b >>= 1, a = (LL)a*a%Mod )
		if (b&1) rec = (LL)rec*a%Mod ;
	return rec ;
}
void get_height() {
    int i, j, k = 0 ;
    for ( i = 1 ; i <= n ; i ++ ) rnk[sa[i]] = i ;
    for ( i = 1 ; i <= n ; i ++ ) {
        if (k) -- k ;
        j = sa[rnk[i]-1] ;
        while (s[i+k] == s[j+k]) ++ k ;
        height[rnk[i]] = k ;
    }
}
bool diff() {
	for ( int i = 1 ; i ^ n ; i ++ )
		if (s[i] != s[i+1]) return 1 ;
	return 0 ;
}
int main() {
	freopen ( "shit.in", "r", stdin ) ;
	freopen ( "shit.out", "w", stdout ) ;
	scanf ( "%s", s+1 ) ;
	n = strlen(s+1) ;
	if (diff()) {
		get_sa() ;
		get_height() ;
		create() ;
		solve() ;
	} else cout << Qpow(2, n/2-1) << endl ;
    return 0 ;
}
