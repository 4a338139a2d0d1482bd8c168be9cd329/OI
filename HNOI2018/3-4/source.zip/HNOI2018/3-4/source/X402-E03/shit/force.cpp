#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const int maxn = 1e5+5, Mod = 998244353 ;
char s[maxn], s1[maxn], s2[maxn] ;
int n, m, f[maxn] ;
int Qpow ( int a, int b, int rec = 1 ) {
	for ( ; b ; b >>= 1, a = (LL)a*a%Mod )
		if (b&1) rec = (LL)rec*a%Mod ;
	return rec ;
}
bool judge ( int l, int r ) {
	for ( int i = l, j = r ; i <= r ; i ++, j -- )
		if (s1[i] != s2[j]) return 0 ;
	return 1 ;
}
void Force() {
	int i, j ;
	for ( i = 1 ; i <= n ; i ++ )
		s1[i] = s[i], s2[i] = s[2*n-i+1] ;
	f[0] = 1 ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 0 ; j < i ; j ++ )
			if (judge(j+1,i)) (f[i] += f[j]) %= Mod ;
	cout << f[n] << endl ;
}
int main() {
	freopen ( "shit.in", "r", stdin ) ;
	freopen ( "shit.out", "w", stdout ) ;
	scanf ( "%s", s+1 ) ;
	n = strlen(s+1)>>1 ;
	if (n <= 2000) Force() ;
	else cout << Qpow(2, n-1) << endl ;
	return 0 ;
}
