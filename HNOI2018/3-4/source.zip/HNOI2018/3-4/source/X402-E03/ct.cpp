#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1e5+5 ;
const LL inf = 1e15 ;
int clk, n, m, dep[maxn], A[maxn], B[maxn], size[maxn], rdn[maxn], dfn[maxn] ;
int e = 1, Begin[maxn], Next[maxn*2], To[maxn*2] ;
LL f[maxn] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
struct Segment_Tree {
	LL tree[maxn*3] ;
	int L, R ;
	void create ( int h, int l, int r ) {
		tree[h] = inf ;
		if (l == r) return ;
		int mid = (l+r)>>1 ;
		create(h<<1, l, mid), create(h<<1|1, mid+1, r) ;
	}
	void push_up ( int h ) { tree[h] = min(tree[h<<1], tree[h<<1|1]) ; }
	void Update ( int h, int l, int r, int x, LL v ) {
		if (l == r) {
			tree[h] = v ;
			return ;
		}
		int mid = (l+r)>>1 ;
		if (x <= mid) Update(h<<1, l, mid, x, v) ;
		else Update(h<<1|1, mid+1, r, x, v) ;
		push_up(h) ;
	}
	LL Query ( int h, int l, int r, int x, int y ) {
		if (x <= l && r <= y) return tree[h] ;
		int mid = (l+r)>>1 ;
		if (y <= mid) return Query(h<<1, l, mid, x, y) ;
		else if (x > mid) return Query(h<<1|1, mid+1, r, x, y) ;
		return min(Query(h<<1, l, mid, x, mid),Query(h<<1|1, mid+1, r, mid+1, y)) ;
	}
	void Update ( int x, LL v ) { Update(1, L, R, x, v) ; }
	LL Query ( int l, int r ) { return Query(1, L, R, l, r) ; }
	void create ( int l, int r ) { create(1, L = l, R = r) ; }
} SGT ;
void dfs ( int x ) {
	dfn[x] = ++clk ;
	rdn[clk] = x ;
	LL i, u ;
	size[x] = 1 ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (!dfn[u]) {
			dfs(u) ;
			size[x] += size[u] ;
		}
	}
	if (n <= 5000) {
		if (size[x] == 1) f[x] = 0 ;
		else f[x] = inf ;
		for ( i = dfn[x]+size[x]-1 ; i > dfn[x] ; i -- )
			f[x] = min(f[x], i[rdn][f] + i[rdn][B]*A[x]) ;
	} else {
		if (size[x] == 1) f[x] = 0 ;
		else f[x] = A[x] + SGT.Query(dfn[x]+1, dfn[x]+size[x]-1) ;
		SGT.Update(dfn[x], f[x]) ;
	}
}
int main() {
	freopen ( "ct.in", "r", stdin ) ;
	freopen ( "ct.out", "w", stdout ) ;
	int i, x, u ;
	Read(n) ;
	SGT.create(1, n) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(A[i]) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(B[i]) ;
	for ( i = 1 ; i ^ n ; i ++ ) {
		Read(x), Read(u) ;
		add(x, u), add(u, x) ;
	}
	dfs(1) ;
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%lld\n", f[i] ) ;
	return 0 ;
}
