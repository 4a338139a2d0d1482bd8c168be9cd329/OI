#include<bits/stdc++.h>
#define ll long long
using namespace std;


const int maxn=1e6+10,mod=998244353;
ll jc[maxn],inv[maxn];
inline ll qpow(ll a,ll x){
	ll ret=1;
	while(x){
		if(x&1)
			ret=ret*a%mod;
		x>>=1;
		a=a*a%mod;
	}
	return ret;
}

int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	jc[1]=jc[0]=1;
	for(int i=2;i<=1000000;++i)
		jc[i]=jc[i-1]*i%mod;
	inv[1000000]=qpow(jc[1000000],mod-2);
	for(int i=1000000;i>=1;--i)
		inv[i-1]=inv[i]*i%mod;
	ll ans=0;
	int n,k;
	scanf("%d%d",&n,&k);
	if(k==0){
		printf("%lld\n",qpow(2,n)-1);
		return 0;	
	}
	if(k==1){
		printf("%lld\n",n*qpow(2,n-1)%mod);
		return 0;
	}
	for(int i=1;i<=n;++i)
		(ans+=jc[n]*inv[i]%mod*inv[n-i]%mod*qpow(i,k)%mod)%=mod;
	printf("%lld\n",ans);
	ans=0;
	return 0;
}

