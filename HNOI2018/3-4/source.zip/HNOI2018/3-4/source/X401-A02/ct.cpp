#include<bits/stdc++.h>
#define next Next
using namespace std;

const int maxn=1e5+10;

int n,e,to[maxn<<1],head[maxn],next[maxn<<1];
int fa[maxn][18],a[maxn],b[maxn],size[maxn];
vector<int> t;

inline void add(int x,int y){
	to[++e]=y;
	next[e]=head[x];	
	head[x]=e;
}

inline void dfs(int x){
	size[x]=1;
	for(int i=head[x];i;i=next[i])
		if(!size[to[i]]){
			dfs(to[i]);	
			size[x]+=size[to[i]];
			fa[to[i]][0]=x;
		}
}

inline void ycl(){
	for(int j=1;j<=17;++j)
		for(int i=1;i<=n;++i)
			fa[i][j]=fa[fa[i][j-1]][j-1];
			
}

int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	int x,y;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)
		scanf("%d",&b[i]);
	for(int i=1;i<n;++i){
		scanf("%d%d",&y,&x);	
		add(x,y);add(y,x);		
	}
	dfs(1);
	for(int i=1;i<=n;++i)
		if(size[i]==1)
			t.push_back(i);
	
	return 0;
}	

