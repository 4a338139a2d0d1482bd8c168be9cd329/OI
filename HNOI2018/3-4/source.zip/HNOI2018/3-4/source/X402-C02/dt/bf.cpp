#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXK=5000+10,Mod=998244353;
ll f[MAXK][MAXK],n,k,ans;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	read(n);read(k);
	if(k==0)
	{
		write((qexp(2,n)-1+Mod)%Mod,'\n');
		return 0;
	}
	f[0][0]=1;
	for(register int i=1;i<=k;++i)
		for(register int j=1;j<=k;++j)f[i][j]=(f[i-1][j-1]*(n-j+1)%Mod+f[i-1][j]*j%Mod)%Mod;
	for(register int i=1;i<=min(n,k);++i)(ans+=f[k][i]*qexp(2,n-i)%Mod)%=Mod;
	write(ans,'\n');
	return 0;
}
