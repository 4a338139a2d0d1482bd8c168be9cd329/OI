#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int Mod=5001;
int main()
{
	freopen("dt.in","w",stdout);
	srand(time(0));
	int n=rand()%1000000+1,k=0;
	printf("%d %d\n",n,k);
	return 0;
}
