#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int Mod=998244353,MAXN=1000000+10;
ll fac[MAXN],inv[MAXN],n,k,ans;
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
inline void init()
{
	fac[0]=1;
	for(register int i=1;i<=n;++i)fac[i]=(fac[i-1]*i)%Mod;
	inv[n]=qexp(fac[n],Mod-2);;
	for(register int i=n-1;i>=0;--i)inv[i]=(inv[i+1]*(i+1))%Mod;
}
inline ll C(ll n,ll m)
{
	return fac[n]*inv[m]%Mod*inv[n-m]%Mod;
}
int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.txt","w",stdout);
	read(n);read(k);
	if(k==0)
	{
		write((qexp(2,n)-1+Mod)%Mod,'\n');
		return 0;
	}
	init();
	for(register int i=1;i<=n;++i)(ans+=C(n,i)*qexp(i,k)%Mod)%=Mod;
	write(ans,'\n');
	return 0;
}
