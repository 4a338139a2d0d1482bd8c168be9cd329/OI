#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=100000+10,inf=0x3f3f3f3f;
int n,e,f[MAXN],A[MAXN],B[MAXN],to[MAXN<<1],nex[MAXN<<1],beg[MAXN],up[MAXN],g[MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline void insert(int x,int y)
{
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
inline void dfs(int x,int fa)
{
	int ch=0;
	up[x]=fa;
	for(register int i=beg[x];i;i=nex[i])
		if(to[i]==fa)continue;
		else
		{
			ch++;
			dfs(to[i],x);
			for(register int j=1;j<=n;++j)
				if(up[j]==to[i])
				{
					chkmin(f[x],A[x]*B[j]+f[j]);
					up[j]=x;
				}
			chkmin(f[x],f[to[i]]+A[x]*B[to[i]]);
		}
	if(!ch)f[x]=0;
}
inline void subt1()
{
	memset(f,inf,sizeof(f));
	dfs(1,0);
	for(register int i=1;i<=n;++i)write(f[i],'\n');
}
inline void dfs2(int x,int fa)
{
	int ch=0;
	for(register int i=beg[x];i;i=nex[i])
		if(to[i]==fa)continue;
		else
		{
			ch++;
			dfs2(to[i],x);
			chkmin(f[x],g[to[i]]+A[x]);
			chkmin(g[x],g[to[i]]);
		}
	chkmin(g[x],f[x]);
	if(ch==0)f[x]=g[x]=0;
}
inline void subt2()
{
	memset(f,inf,sizeof(f));
	memset(g,inf,sizeof(g));
	dfs2(1,0);
	for(register int i=1;i<=n;++i)write(f[i],'\n');
}
int main()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	read(n);
	int mark1=1;
	for(register int i=1;i<=n;++i)read(A[i]);
	for(register int i=1;i<=n;++i)
	{
		read(B[i]);
		if(B[i]!=1)mark1=0;
	}
	for(register int i=1;i<n;++i)
	{
		int u,v;
		read(u);read(v);
		insert(u,v);
		insert(v,u);
	}
	if(n<=5000)subt1();
	else if(mark1)subt2();
	return 0;
}
