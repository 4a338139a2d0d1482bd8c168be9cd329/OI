#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXN=100000+10,Mod=998244353;
ll n,cnt,ans;
char s[MAXN],str[MAXN];
template<typename T> inline void read(T &x)
{
	T data=0,w=1;
	char ch=0;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0'&&ch<='9')data=((T)data<<3)+((T)data<<1)+(ch^'0'),ch=getchar();
	x=data*w;
}
template<typename T> inline void write(T x,char c='\0')
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+'0');
	if(c!='\0')putchar(c);
}
template<typename T> inline void chkmin(T &x,T y){x=(y<x?y:x);}
template<typename T> inline void chkmax(T &x,T y){x=(y>x?y:x);}
inline ll qexp(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
inline void init()
{
	for(register int i=1;i<=n/2;++i)str[++cnt]=s[i],str[++cnt]=s[n-i-1];
	str[cnt+1]='\0';
}
inline bool check(char p[],int l,int r)
{
	int j=n-r+1;
	for(register int i=l;i<=r;++i,++j)
		if(p[i]!=p[j])return false;
	return true;
}
inline void dfs(int x)
{
	if(x>(n>>1))
	{
		ans=(ans+1)%Mod;
		return ;
	}
	for(register int i=x;i<=(n>>1);++i)
		if(check(s,x,i))dfs(i+1);
}
inline void subt1()
{
	dfs(1);
	write(ans,'\n');
}
int main()
{
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	scanf("%s",s+1);
	int marka=1;
	n=strlen(s+1);
	for(register int i=1;i<=n;++i)
		if(s[i]!='a')marka=0;
	if(n<=20)subt1();
	else if(marka)
	{
		if(n&1)write(0,'\n');
		else write(qexp(2ll,(ll)n/2-1),'\n');
		return 0;
	}
	return 0;
}
