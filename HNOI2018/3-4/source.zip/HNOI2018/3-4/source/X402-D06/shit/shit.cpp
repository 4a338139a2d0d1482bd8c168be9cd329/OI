#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=5e3+10;
const int mod=998244353;
int dp[maxn];
char str[maxn];
unsigned long long Hash[maxn],Pow[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int fpm(int a,int b){
	int ans=1;
	while(b){
		if(b & 1)ans=1ll*ans*a%mod;
		a=1ll*a*a%mod;b/=2;
	}
	return ans;
}
inline int Mod(int x,int y){
	int val=x+y;
	if(val>=mod)val-=mod;
	return val;
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
#endif
	scanf("%s",str+1);
	n=strlen(str+1);
	if(n>2000)return printf("%d\n",fpm(2,n/2-1)),0;
	Pow[0]=1;
	for(i=1;i<=n;i++){
		Hash[i]=Hash[i-1]*26+str[i]-'a';
		Pow[i]=Pow[i-1]*26;
	}
	dp[0]=1;
	for(i=1;i<=n/2;i++)
		for(j=0;j<i;j++){
			unsigned long long resl=Hash[i]-Hash[j]*Pow[i-j];
			unsigned long long resr=Hash[n-j]-Hash[n-i]*Pow[i-j];
			if(resl==resr)dp[i]=Mod(dp[i],dp[j]);
		}
	printf("%d\n",dp[n/2]);
	return 0;
}

