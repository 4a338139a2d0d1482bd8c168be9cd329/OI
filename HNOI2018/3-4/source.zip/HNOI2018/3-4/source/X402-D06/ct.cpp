#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const ll INF=1e18;
const long double eps=1e-9;
const int maxn=1e5+10;
int a[maxn],b[maxn],to[maxn<<1],nex[maxn<<1],beg[maxn],sz[maxn],dfn[maxn],id[maxn];
ll dp[maxn];
int dfs_time=0,e,n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
struct Seg_T{
	ll Seg[maxn<<2];
	void Modify(int h,int l,int r,int pos,int val){
		if(l==r){
			Seg[h]=val;
			return;
		}
		int mid=(l+r)>>1;
		if(pos<=mid)Modify(h<<1,l,mid,pos,val);
		else Modify(h<<1|1,mid+1,r,pos,val);
		Seg[h]=min(Seg[h<<1],Seg[h<<1|1]);
	}
	ll Query(int h,int l,int r,int L,int R){
		if(L<=l && r<=R)return Seg[h];
		int mid=(l+r)>>1;ll res=INF;
		if(L<=mid)res=min(res,Query(h<<1,l,mid,L,R));
		if(R>mid)res=min(res,Query(h<<1|1,mid+1,r,L,R));
		return res;
	}
}T;
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
void dfs(int x,int fa){
	int i;
	dfn[x]=++dfs_time;id[dfs_time]=x;sz[x]=1;
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		dfs(to[i],x);
		sz[x]+=sz[to[i]];
	}
}
void Dfs(int x,int fa){
	int i,flag=0;
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		flag=1;Dfs(to[i],x);
	}
	if(!flag)return;
	ll Min=INF;
	for(i=dfn[x]+1;i<=dfn[x]+sz[x]-1;i++)
		Min=min(Min,dp[i]+1ll*a[x]*b[id[i]]);
	dp[dfn[x]]=Min;
}
void DFS(int x,int fa){
	int i,flag=0;
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		flag=1;DFS(to[i],x);
	}
	if(!flag){
		T.Modify(1,1,n,dfn[x],0);
		return;
	}
	dp[dfn[x]]=T.Query(1,1,n,dfn[x]+1,dfn[x]+sz[x]-1)+a[x];
	T.Modify(1,1,n,dfn[x],dp[dfn[x]]);
}
int main(){
	int i,j,k,m;
#ifndef ONLINE_JUDGE
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
#endif
	n=read();
	for(i=1;i<=n;i++)a[i]=read();
	for(i=1;i<=n;i++)b[i]=read();
	for(i=1;i<n;i++){
		int x=read(),y=read();
		add(x,y);add(y,x);
	}
	if(n<=5000){
		dfs(1,0);
		Dfs(1,0);
	}
	else{
		memset(T.Seg,63,sizeof(T.Seg));
		dfs(1,0);
		DFS(1,0);
	}
	for(i=1;i<=n;i++)printf("%lld\n",dp[dfn[i]]);
	return 0;
}

