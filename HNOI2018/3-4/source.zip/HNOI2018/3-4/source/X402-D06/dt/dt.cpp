#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=998244353;
const int maxk=5e3+10;
int S[maxk][maxk];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int fpm(int a,int b){
	int ans=1;
	while(b){
		if(b & 1)ans=1ll*ans*a%mod;
		b/=2;a=1ll*a*a%mod;
	}
	return ans;
}
inline void initialize(int n){
	int i,j;
	S[0][0]=1;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			S[i][j]=(S[i-1][j-1]+1ll*j*S[i-1][j])%mod;
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
#endif
	n=read();k=read();
	initialize(k);
	int prod=1,ans=0;
	for(i=0;i<=k;i++){
		ans=(ans+1ll*S[k][i]*prod%mod*fpm(2,n-i)%mod)%mod;
		prod=1ll*prod*(n-i)%mod;
	}
	printf("%d\n",ans);
	return 0;
}

