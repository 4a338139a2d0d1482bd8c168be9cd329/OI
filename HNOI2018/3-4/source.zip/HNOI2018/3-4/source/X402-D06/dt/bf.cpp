#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=998244353;
const int maxn=1e6+10;
int fac[maxn],inv[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int fpm(int a,int b){
	int ans=1;
	while(b){
		if(b & 1)ans=1ll*ans*a%mod;
		b/=2;a=1ll*a*a%mod;
	}
	return ans;
}
inline int C(int n,int m){
	return 1ll*fac[n]*inv[m]%mod*inv[n-m]%mod;
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("dt.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	n=read();k=read();
	fac[0]=1;
	for(i=1;i<=n;i++)fac[i]=1ll*fac[i-1]*i%mod;
	inv[n]=fpm(fac[n],mod-2);
	for(i=n-1;i>=0;i--)inv[i]=1ll*inv[i+1]*(i+1)%mod;
	int ans=0;
	for(i=1;i<=n;i++)ans=(ans+1ll*C(n,i)*fpm(i,k))%mod;
	printf("%d\n",ans);
	cerr<<"Ans : "<<ans<<endl;
	return 0;
}

