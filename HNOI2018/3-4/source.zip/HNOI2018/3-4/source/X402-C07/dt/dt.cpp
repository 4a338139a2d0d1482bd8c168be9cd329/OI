#include<cstdio>
#include<algorithm>
using namespace std;
const int mod=998244353;
long long n,k,ans=0,fac[1000012],dac[1000012];
#define rint register int


long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	if (k==0)
	{
	  long long ans=mi(2,n);
	  ans=(ans-1+mod)%mod;
	  printf("%lld\n",ans);
	  return 0;
	}
	if (k==1)
	{
	  long long ans=mi(2,n-1);
	  ans=ans*n%mod;
	  printf("%lld\n",ans);
	  return 0;
	}
	fac[0]=1;
	fac[1]=1;
	for (rint i=2;i<=n;++i)
	  fac[i]=fac[i-1]*i%mod;
	dac[n]=mi(fac[n],mod-2);
	for (rint i=n-1;i>=1;i--)
	  dac[i]=dac[i+1]*(i+1)%mod;
	dac[0]=1;
	for (rint i=1;i<=n;++i)
	  ans=(ans+fac[n]*dac[i]%mod*dac[n-i]%mod*mi(i,k)%mod)%mod;
	printf("%lld\n",ans);
	return 0;
}
