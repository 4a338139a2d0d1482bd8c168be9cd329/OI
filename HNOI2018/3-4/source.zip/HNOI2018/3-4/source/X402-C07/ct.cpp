#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
vector<int> son[100012];
long long n,dp[100012],a[100012],b[100012],dfn[100012],cnt=0,num[100012];

void doing(int x,int fa){
	cnt++;
	dfn[x]=cnt;
	num[cnt]=x;
	if (son[x].size()==1&&x!=fa)
	{
	  dp[x]=0;
	  return ;
	}
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (s==fa)
	    continue;
	  doing(s,x);
	}
	for (int i=dfn[x]+1;i<=cnt;i++)
	  dp[x]=min(dp[x],dp[num[i]]+a[x]*b[num[i]]);
}

void doi(int x,int fa){
	cnt++;
	dfn[x]=cnt;
	num[cnt]=x;
	if (son[x].size()==1&&x!=fa)
	{
	  dp[x]=0;
	  return ;
	}
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (s==fa)
	    continue;
	  doi(s,x);
	}
	for (int i=dfn[x]+1;i<=min(cnt,dfn[x]+100);i++)
	  dp[x]=min(dp[x],dp[num[i]]+a[x]*b[num[i]]);
}

void dfs(int x,int fa){
	if (son[x].size()==1&&x!=fa)
	{
	  dp[x]=0;
	  return ;
	}
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (s==fa)
	    continue;
	  dfs(s,x);
	}
	for (int i=0;i<son[x].size();i++)
	{
	  int s=son[x][i];
	  if (s==fa)
	    continue;
	  if (dp[s]==0)
	    dp[x]=min(dp[x],a[x]+dp[s]);
	  else
	  {
	  	if (a[s]>0)
	  	  dp[x]=min(dp[x],a[x]+dp[s]-a[s]);
	  	else
	  	  dp[x]=min(dp[x],a[x]+dp[s]);
	  }
	}
}

int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	int ok1=1,okl=1;
	scanf("%lld",&n);
	for (int i=1;i<=n;i++)
	  scanf("%lld",&a[i]);
	for (int i=1;i<=n;i++)
	{
	  scanf("%lld",&b[i]);
	  if (b[i]!=1)
	    ok1=0;
	}
	for (int i=1;i<=n-1;i++)
	{
	  int u,v;
	  scanf("%d%d",&u,&v);
	  son[u].push_back(v);
	  son[v].push_back(u);
	  if (abs(u-v)!=1)
	    okl=0;
	}
	if (ok1==1)
	{
	  for (int i=1;i<=n;i++)
	    dp[i]=1e16;
	  dfs(1,1);
	  for (int i=1;i<=n;i++)
	    printf("%lld\n",dp[i]);
	  return 0;
	}
	if (okl==1)
	{
	  for (int i=1;i<=n;i++)
	    dp[i]=1e16;
	  doi(1,1);
	  for (int i=1;i<=n;i++)
	    printf("%lld\n",dp[i]);
	  return 0;
	}
	for (int i=1;i<=n;i++)
	  dp[i]=1e16;
	doing(1,1);
	for (int i=1;i<=n;i++)
	  printf("%lld\n",dp[i]);
	return 0;
}
