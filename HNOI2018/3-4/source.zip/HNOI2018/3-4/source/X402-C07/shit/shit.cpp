#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int mod=998244353;
int n,en[100012],beg[100012],ans=0;
char s[100012];

int check(int k){
	//for (int i=1;i<=k;i++)
	//  printf("%d %d\n",beg[i],en[i]);
	//printf("\n");
	for (int i=1;i<=k;i++)
	{
	  int len=en[i]-beg[i]+1;
	  int pos=n-(beg[i]-1)-len+1;
	  for (int j=1;j<=en[i]-beg[i]+1;j++)
	    if (s[beg[i]+j-1]!=s[pos+j-1])
	      return false;
	}
	return true;
}

void doing(int pos,int k){
	if (pos==n/2+1)
	{
	  ans++;
	  return ;
	}
	beg[k]=pos;
	for (int i=pos;i<=n/2;i++)
	{
	  en[k]=i;
	  int len=en[k]-beg[k]+1;
	  int pos=n-(beg[k]-1)-len+1;
	  int ok=1;
	  for (int j=1;j<=len;j++)
	    if (s[beg[k]+j-1]!=s[pos+j-1])
	    {
		  ok=0;
		  break;
		}
	  if (ok==1)
	    doing(i+1,k+1);
	}
}

long long mi(long long a,long long b){
	long long ans=1;
	while (b>0)
	{
	  if (b%2==1)
	    ans=ans*a%mod;
	  a=a*a%mod;
	  b/=2;
	}
	return ans;
}

int main(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	scanf("%s",s+1);
	n=strlen(s+1);
	int oka=1;
	for (int i=1;i<=n;i++)
	  if (s[i]!='a')
	    oka=0;
	if (oka==1)
	{
	  printf("%lld\n",mi(2,n/2-1));
	  return 0;
	}
	doing(1,1);
	printf("%d\n",ans);
	return 0;
}
