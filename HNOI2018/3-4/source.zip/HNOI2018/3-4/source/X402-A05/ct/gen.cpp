#include <bits/stdc++.h>

int RandInt(int l, int r)
{
	return 1ll * rand() * rand() % (r - l + 1) + l;
}

int main()
{
	freopen("ct.in", "w", stdout);

	srand(time(NULL));

	int n = 100000; printf("%d\n", n);
	for (int i = 1; i <= n; ++i){
		printf("%d%c", RandInt(-1e5, 1e5), i != n? ' ':'\n');
	}
	for (int i = 1; i <= n; ++i){
		printf("1%c", i != n? ' ':'\n');
	}
	for (int i = 2; i <= n; ++i){
		printf("%d %d\n", RandInt(1, i-1), i);
	}

	return 0;
}
