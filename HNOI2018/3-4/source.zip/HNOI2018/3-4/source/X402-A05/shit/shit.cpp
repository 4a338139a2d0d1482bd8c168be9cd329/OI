#include <bits/stdc++.h>

const int N = 1e5;
const int mod = 998244353;

void add(int &a, int b)
{
	a += b;
	if (a >= mod) a -= mod;
}

char s[N + 5];
int n;

namespace Bfer
{
	using std :: string;

	string str[N + 5];
	int ans;

	void DFS_calc(int p, int k)
	{
		if (p == n){
			if (k & 1) return ;
			for (int i = 1; i <= k/2; ++i){
				if(str[i] != str[k-i+1]) return ;
			}
//			for (int i = 1; i <= k; ++i){
//				std::cout << str[i] << " ";
//			}
//			puts("");
			ans ++;
			return ;
		}
		string tmp = "";
		for (int i = p + 1; i <= n; ++i){
			tmp.push_back(s[i]);
			str[k + 1] = tmp;
			DFS_calc(i, k + 1);
		}
	}

	void main()
	{
		DFS_calc(0, 0);
		printf("%d\n", ans);
	}
}

namespace Dper
{
	const int M = 2e3;

	int dp[M + 5][M + 5];
	bool can[M + 5][M + 5];

	void main()
	{
		for (int i = 1; i <= n>>1; ++i){
			for (int j = i; j <= n>>1; ++j){
				int i0 = i, i1 = n - j + 1;
				while (s[i0] == s[i1] && i0 <= j)
					i0 ++, i1 ++;
				if (i0 > j) can[i][j] = true;
			}
		}

		dp[0][0] = 1;
		for (int i = 1; i <= n>>1; ++i){
			for (int j = 0; j < i; ++j){
				if (!can[j + 1][i]) continue;
				for (int k = 1; k-1 <= j; ++k){
					add(dp[i][k], dp[j][k-1]);
				}
			}
		}

		int ans = 0;
		for (int i = 1; i <= n>>1; ++i){
			add(ans, dp[n>>1][i]);
		}
		printf("%d\n", ans);
	}
}

int main()
{
	freopen("shit.in", "r", stdin);
	freopen("shit.out", "w", stdout);

	scanf("%s", s + 1);
	n = strlen(s + 1);

	bool IsSame = true;
	for (int i = 2; i <= n; ++i){
		IsSame &= (s[i] == s[1]);
	}

	if (n <= 20){
		Bfer :: main();
	}
	else if (IsSame){
		int ans = 1;
		for (int i = 1; i <= (n>>1)-1; ++i){
			ans = 2ll * ans % mod;
		}
		printf("%d\n", ans);
	}
	else {
		Dper :: main();
	}

	return 0;
}
