#include <bits/stdc++.h>

const int N = 1e6;
const int mod = 998244353;

int fpm(int x, int e)
{
	int ret = 1;
	for (; e; e >>= 1){
		if (e & 1)
			ret = 1ll * ret * x % mod;
		x = 1ll * x * x % mod;
	}
	return ret;
}

int fac[N + 5], ifac[N + 5];
int n, k;

void FacInit()
{
	fac[0] = 1;
	for (int i = 1; i <= N; ++i){
		fac[i] = 1ll * fac[i-1] * i % mod;
	}
	ifac[N] = fpm(fac[N], mod - 2);
	for (int i = N; i >= 1; --i){
		ifac[i-1] = 1ll * ifac[i] * i % mod;
	}
}

int C(int n, int m)
{
	if (m > n) return 0;
	return 1ll * fac[n] * ifac[n-m] % mod * ifac[m] % mod;
}

int main()
{
	freopen("dt.in", "r", stdin);
	freopen("dt.out", "w", stdout);

	FacInit();

	scanf("%d%d", &n, &k);
	if (n <= N){
		int ans = 0;
		for (int i = 1; i <= n; ++i){
			ans = (ans + 1ll*C(n, i)*fpm(i, k)%mod) % mod;
		}
//		for (int i = 0; i <= n; ++i){
//			ans = (ans + 1ll*C(n, i)*(fpm(i+1, k)-fpm(i, k))%mod) % mod;
//		}
		printf("%d\n", ans);
	}
	else if (k == 0){
		printf("%d\n", fpm(2, n) - 1);
	}
	else {
		printf("%lld\n", 1ll * fpm(2, n-1) * n % mod);
	}

	return 0;
}
