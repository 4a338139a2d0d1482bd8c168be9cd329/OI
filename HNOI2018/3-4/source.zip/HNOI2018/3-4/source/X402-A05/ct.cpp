#include <bits/stdc++.h>

int read(int x = 0, int _f = 0)
{
	char c = getchar(); 
	for (; !isdigit(c); c = getchar()) _f |= (c == '-');
	for (;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return _f? -x : x;
}

typedef long long LL;

const int N = 1e5;
const LL inf = 1e18;

int n;
int A[N + 5], B[N + 5];

int e, Begin[N + 5];
struct Edge
{
	int to, next;
	Edge(int _to = 0, int _next = 0) : to(_to), next(_next) {}
}E[(N << 1) + 5];

void AddEdge(int u, int v)
{
	E[++e] = Edge(v, Begin[u]); Begin[u] = e;
}

int fa[N + 5];
LL dp[N + 5];

namespace Bfer
{
	void DFS_calc(int u)
	{
		bool IsLeaf = true;
		for (int i = Begin[u]; i; i = E[i].next){
			int v = E[i].to;
			if (v == fa[u]) continue;

			fa[v] = u;
			DFS_calc(v);
			IsLeaf = false;
		}

		if (IsLeaf){
			dp[u] = 0;
		}
		for (int i = fa[u]; i; i = fa[i]){
			dp[i] = std::min(dp[i], dp[u] + 1ll*A[i]*B[u]);
		}
	}

	void main()
	{
		for (int i = 1; i <= n; ++i) dp[i] = inf;
		DFS_calc(1);
		for (int i = 1; i <= n; ++i){
			printf("%lld\n", dp[i]);
		}
	}
}

namespace All1
{
	bool IsLeaf[N + 5];
	LL g[N + 5];

	void DFS_calc(int u)
	{
		IsLeaf[u] = true;
		dp[u] = inf;
		for (int i = Begin[u]; i; i = E[i].next){
			int v = E[i].to;
			if (v == fa[u]) continue;

			fa[v] = u;
			DFS_calc(v);
			g[u] = std::min(g[v], g[u]);
			IsLeaf[u] = false;
		}
		if (IsLeaf[u]){
			dp[u] = 0;
		}
		else {
			dp[u] = g[u] + A[u];
			if (A[u] < 0)
				g[u] += A[u];
		}
	}

	void main()
	{
		DFS_calc(1);
		for (int i = 1; i <= n; ++i){
			printf("%lld\n", dp[i]);
		}
	}
}

int main()
{
	freopen("ct.in", "r", stdin);
	freopen("ct.out", "w", stdout);

	n = read();
	for (int i = 1; i <= n; ++i){
		A[i] = read();
	}
	bool BAll1 = true;
	for (int i = 1; i <= n; ++i){
		B[i] = read();
		BAll1 &= (B[i] == 1);
	}
	for (int i = 1; i < n; ++i){
		int u = read(), v = read();
		AddEdge(u, v);
		AddEdge(v, u);
	}

	if (BAll1){
		All1 :: main();
	}
	else {
		Bfer :: main();
	}

	return 0;
}
//
