#include<bits/stdc++.h>
using namespace std;
int root,m,n;
int __read(){
	int Value=0,Base=1;char Ch=getchar();
	for(;!isdigit(Ch);Ch=getchar())if(Ch=='-')Base=-1;
	for(;isdigit(Ch);Ch=getchar())Value=Value*10+(Ch^'0');
	return Value*Base;
}

const int maxn=100010;
int beg[maxn],nex[maxn<<1],to[maxn<<1],e,tot;
int val[maxn],dep[maxn],in[maxn],out[maxn],size[maxn];
int son[maxn],fa[maxn],top[maxn],id[maxn],p[maxn];

namespace Segement{
	int /*min*/Tr[maxn<<2],/*max*/tr[maxn<<2];
	void Build(int rt,int l,int r){
		if(l==r){
			if(size[p[l]]!=1){
				tr[rt]=-1e9;
				Tr[rt]=1e9;
			}
			else tr[rt]=Tr[rt]=val[p[l]];
			return ;
		}
		int mid=(l+r)>>1;
		Build(rt<<1,l,mid);Build(rt<<1|1,mid+1,r);
		tr[rt]=max(tr[rt<<1],tr[rt<<1|1]);
		Tr[rt]=min(Tr[rt<<1],Tr[rt<<1|1]);
	}
	
	int Query_max(int rt,int l,int r,int L,int R){
		if(L<=l && r<=R)
			return tr[rt];
		int ans=-1e9,mid=(l+r)>>1;
		if(L<=mid)ans=max(ans,Query_max(rt<<1,l,mid,L,R));
		if(R>mid)ans=max(ans,Query_max(rt<<1|1,mid+1,r,L,R));
		tr[rt]=max(tr[rt<<1],tr[rt<<1|1]);
		return ans;
	}

	int Query_min(int rt,int l,int r,int L,int R){
		if(L<=l && r<=R)
			return Tr[rt];
		int ans=1e9,mid=(l+r)>>1;
		if(L<=mid)ans=min(ans,Query_min(rt<<1,l,mid,L,R));
		if(R>mid)ans=min(ans,Query_min(rt<<1|1,mid+1,r,L,R));
		Tr[rt]=min(Tr[rt<<1],Tr[rt<<1|1]);
		return ans;
	}
}

using namespace Segement;

void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}

void dfs(int x,int f){
	fa[x]=f;size[x]=1;
	for(int i=beg[x];i;i=nex[i]){
		int y=to[i];
		if(y!=f){
			dep[y]=dep[x]+1,dfs(y,x);
			if(size[son[x]]<size[y])
				son[x]=y;
			size[x]+=size[y];
		}
	}
}

void Dfs(int x,int f){
	top[x]=f;
	id[x]=++tot;
	p[tot]=x;
	if(son[x]==0)return ;
	Dfs(son[x],f);
	for(int i=beg[x];i;i=nex[i]){
		int y=to[i];
		if(y!=fa[x] && y!=son[x])
			Dfs(y,y);
	}
}

int a[maxn],b[maxn];

void Query_tree(int x){
	if(size[x]!=1){
		if(a[x]>0)printf("%d\n",a[x]*Query_min(1,1,n,id[x],id[x]+size[x]-1));
		if(a[x]<0)printf("%d\n",a[x]*Query_max(1,1,n,id[x],id[x]+size[x]-1));
	}
	else printf("0\n");
}


int main( ){
	int j,k,i;
#ifndef ONLINE_JDUGE
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
#endif
	n=__read();
	for(i=1;i<=n;i++)a[i]=__read();
	for(i=1;i<=n;i++)val[i]=b[i]=__read();
	for(i=1;i<n;i++){
		int x=__read(),y=__read();
		add(x,y);add(y,x);
	}
	root=1;
	dep[root]=1;size[0]=-1e9;
	dfs(root,0);
	Dfs(root,root);
	Build(1,1,n);
	for(i=1;i<=n;i++)
		Query_tree(i);
	return 0;
}
