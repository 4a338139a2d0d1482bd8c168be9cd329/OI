#include<bits/stdc++.h>
#define inv(a) (!a?1:Quick_pow(a,mod-2))
using namespace std;
typedef long long ll;
const ll mod=998244353;
const ll maxn=1e6+10;
ll sum[maxn];

ll Quick_pow(ll x,ll p){
	ll ans=1;
	for(;p;(x*=x)%=mod,p>>=1)
		if(p&1)(ans*=x)%=mod;
	return ans;
}

void Init(){
	sum[1]=1;
	for(int i=2;i<=1e6+10;i++)
		sum[i]=(sum[i-1]*i);
}

ll C(ll a,ll b){
	return (sum[a]*inv(sum[b])%mod)*inv(sum[a-b])%mod;
}

int main( ){
	ll m,n,j,k,i,ans=0;
#ifndef ONLINE_JUDGE
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
#endif
	scanf("%lld%lld",&n,&k);
	if(n<=1e6){
		Init();
		for(i=1;i<=n;i++){
			(ans+=C(n,i)*Quick_pow(i,k))%=mod;
		}
		printf("%lld\n",ans);
	}
	else if(k==0){
		printf("%lld\n",Quick_pow(2,n)-1);	
	}
	else if(k==1){
		printf("%lld\n",Quick_pow(2,n-1)*n%mod);
	}
	return 0;
}
