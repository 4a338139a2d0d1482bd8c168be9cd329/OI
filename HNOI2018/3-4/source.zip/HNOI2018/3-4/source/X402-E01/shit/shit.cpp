#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn=1200010;
const ll mod=998244353;
ll n=0,top,Res;
ll stk[maxn];
char s[maxn];

ll __read(){
	ll Value=0,Base=1;char Ch=getchar();
	for(;!isdigit(Ch);Ch=getchar())if(Ch=='-')Base=-1;
	for(;isdigit(Ch);Ch=getchar())Value=Value*10+(Ch^'0');
	return Value*Base;
}

ll Quick_pow(ll x,ll p){
	ll ans=1;
	for(;p;(x*=x)%=mod,p>>=1)
		if(p&1)(ans*=x)%=mod;
	return ans;
}

bool Check(){
	if(top%2==0)return false;
	stk[top+1]=n;
	for(int i=1;i<=top/2+1;i++){
		if(stk[i]+stk[top-i+1]!=n)return false;
	}
	for(int i=0;i<=top/2;i++){
		for(int j=1;j<=stk[i+1]-stk[i];j++){
			if(s[stk[i]+j]!=s[stk[top-i]+j])return false;
		}
	}
/*	cout<<top<<endl;
	for(int i=1;i<=top;i++)
		cout<<stk[i]<<" ";
	cout<<endl;*/
	return true;
}

void Dfs(ll x){
	if(x==n){
		(Res+=Check())%=mod;
		return ;
	}
	stk[++top]=x;Dfs(x+1);
	top--;Dfs(x+1);
}

int GetCh(){
	char Ch=getchar();
	for(;!isalpha(Ch);Ch=getchar())
		if(Ch==EOF)return -1;
	return Ch;
}

int main(){
	ll m,j,k=1,i;
#ifndef ONLINE_JDUGE
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
#endif
	while((s[++n]=GetCh())!=-1){
		if(s[n]!=s[1])k=0;
		//cout<<n<<" "<<s[n]<<endl;
	}
	n--;
	//cout<<n<<endl;
	if(k)
		printf("%d\n",Quick_pow(2,n/2-1));
	else Dfs(1),printf("%d\n",Res);
	return 0;
}
