#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define pll pair<LL,LL>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define lc p<<1
#define rc p<<1|1
#define ft first
#define sd second
#define ALL(x) x.begin(),x.end()
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const LL inf=1e16;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("ct.in","r",stdin);
	freopen("bf.out","w",stdout);
}
int n;
LL A[N],B[N],ans[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
int ln[N],rn[N],dfq[N],cnt,len;
vector<pll>t[N<<3];
pll q[N];
inline double slope(pll A,pll B)
{
	return A.ft==B.ft?(B.sd>A.sd?inf:-inf):(double)(A.sd-B.sd)/(double)(B.ft-A.ft);
}
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void dfs(int u,int f)
{
	dfq[++cnt]=u;
	ln[u]=cnt+1;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
	}
	rn[u]=cnt;
}
int main()
{
	int x,y;
	file();
	read(n);
	For(i,1,n)read(A[i]);
	For(i,1,n)read(B[i]);
	For(i,2,n)read(x),read(y),add_edge(x,y),add_edge(y,x);
	int pos=n;
	dfs(1,0);
	rFor(i,n,1)
	{
		int u=dfq[i];
		ans[u]=inf;
		if(ln[u]<=rn[u])
			For(j,ln[u],rn[u])chkmin(ans[u],A[u]*q[j].ft+q[j].sd);
		else
			ans[u]=0;
		q[pos--]=pll(B[u],ans[u]);
	}
	For(i,1,n)printf("%lld\n",ans[i]);
	return 0;
}
