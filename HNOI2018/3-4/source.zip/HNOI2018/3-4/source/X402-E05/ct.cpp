#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define pll pair<LL,LL>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define lc p<<1
#define rc p<<1|1
#define ft first
#define sd second
#define ALL(x) x.begin(),x.end()
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const LL inf=1e16;
const double eps=1e-6;
const double INF=1e20;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
}
int n;
LL A[N],B[N],ans[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
int ln[N],rn[N],dfq[N],cnt,len;
vector<pll>t[N<<3];
pll q[N];
inline double slope(pll A,pll B)
{
	return A.ft==B.ft?(B.sd>A.sd?INF:-INF):(double)(A.sd-B.sd)/(double)(B.ft-A.ft);
}
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void dfs(int u,int f)
{
	dfq[++cnt]=u;
	ln[u]=cnt+1;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
	}
	rn[u]=cnt;
}
inline LL Get_ans(vector<pll>&A,LL x)
{
	int l=1,r=SZ(A)-1,ans=0;
	while(l<=r)
	{
		int mid=(l+r)>>1;
		if(slope(A[mid-1],A[mid])>(double)x+eps)ans=mid,l=mid+1;
		else r=mid-1;
	}
	return A[ans].ft*x+A[ans].sd;
}
inline pll operator-(pll A,pll B){return pll(A.ft-B.ft,A.sd-B.sd);}
inline LL dots(pll A,pll B){return A.ft*B.sd-A.sd*B.ft;}
inline void Build(vector<pll>&A,vector<pll>&L,vector<pll>&R)
{
	A.resize(SZ(L)+SZ(R));
	merge(ALL(L),ALL(R),A.begin());
	int top=0;
	For(i,0,SZ(A)-1)
	{
		pll now=A[i];
		while(top>1&&dots(q[top-1]-now,q[top]-now)<=0)
			top--;
		q[++top]=now;
	}
	A.clear();
	For(i,1,top)A.pb(q[i]);
}
inline LL Query_tree(int l,int r,int p,int x,int y,int z)
{
	if(x<=l&&r<=y)return Get_ans(t[p],z);
	int mid=(l+r)>>1;LL ret=inf;
	if(x<=mid)chkmin(ret,Query_tree(ls,lc,x,y,z));
	if(y> mid)chkmin(ret,Query_tree(rs,rc,x,y,z));
	return ret;
}
inline void Insert(int l,int r,int p,int x,pll y)
{
	if(l==r){t[p].pb(y);return;}
	int mid=(l+r)>>1;
	if(x<=mid)Insert(ls,lc,x,y);
	else Insert(rs,rc,x,y);
	if(x==l)Build(t[p],t[lc],t[rc]);
}
int main()
{
	int x,y;
	file();
	read(n);
	For(i,1,n)read(A[i]);
	For(i,1,n)read(B[i]);
	For(i,2,n)read(x),read(y),add_edge(x,y),add_edge(y,x);
	int pos=n;
	dfs(1,0);
	rFor(i,n,1)
	{
		int u=dfq[i];
		if(ln[u]<=rn[u])ans[u]=Query_tree(1,n,1,ln[u],rn[u],A[u]);
		Insert(1,n,1,pos--,pll(B[u],ans[u]));
	}
	For(i,1,n)printf("%lld\n",ans[i]);
	return 0;
}
