#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const LL mod=998244353;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("dt.in","r",stdin);
	freopen("bf.out","w",stdout);
}
LL n,k,ans;
LL fac[N],ifac[N];
inline void Add(LL&x,LL y){x=x+y<mod?x+y:x+y-mod;}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void init(int n)
{
	fac[0]=ifac[0]=1;
	For(i,1,n)fac[i]=fac[i-1]*i%mod;
	ifac[n]=qpow(fac[n],mod-2);
	rFor(i,n,2)ifac[i-1]=ifac[i]*i%mod;
}
int main()
{
	file();
	read(n),read(k);
	init(n);
	LL ret=1,ans1=0;
	For(i,1,n)
	{
		ret=ret*(n-i+1)%mod;
		Add(ans,ret*ifac[i]%mod*qpow(i,k)%mod);
		Add(ans1,ret*ifac[i]%mod*qpow(i+1,k)%mod);
	}
	printf("%lld\n",ans);
	return 0;
}
