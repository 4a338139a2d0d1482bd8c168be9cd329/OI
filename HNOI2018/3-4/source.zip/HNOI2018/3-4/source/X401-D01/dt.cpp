#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#define Rint register int
#define Temp template<typename T>
#define mem(a,b) memset(a,(b),sizeof(a))
typedef long long LL;
using namespace std;
Temp inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}

const LL mod=998244353;
const int maxn=1e6+10;
LL n,k;
LL inv[maxn],fac[maxn];

inline LL qpow(LL a,LL p){
	LL ans=1;
	while(p>0){
//		cout<<ans<<' '<<a<<' '<<p<<endl;
		if(p&1)ans=(ans*a)%mod;
		a=(a*a)%mod;
		p>>=1;
	}
	return ans%=mod;
}
inline LL C(LL n,LL i){
	if(n==i||i==0)return 1;
	return (((fac[n]*inv[i])%mod)*inv[n-i])%mod;
}

int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	read(n);read(k);
	if(k==0){
		printf("%lld\n",(qpow(2,n)-1+mod)%mod);
	}
	else if(k==1){
		printf("%lld\n",((qpow(2,n-1)-1)*n)%mod);
	}
	else{
		LL ans=0LL;
		fac[0]=1;
		for(Rint i=1;i<=n;i++)fac[i]=(fac[i-1]*i)%mod;
		inv[n]=qpow(fac[n],mod-2);
		for(Rint i=n-1;i>=1;i--)inv[i]=(inv[i+1]*(i+1))%mod;
		for(Rint i=1;i<=n;i++){
			ans+=(C(n,i)*qpow(i,k))%mod;
			ans%=mod;
		}
		printf("%lld\n",ans);
	}
    return 0;
}
