#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

const int maxn=1e5+1e2;
const ll modd=998244353;
int n,N,cnt,ans;
char s[maxn];
string S[maxn];

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

inline void file() {
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

ll quick(ll a,ll b) {
	ll s=1;
	a%=modd;
	while (b) {
		if (b%2) s=s*a%modd;
		a=a*a%modd; b/=2;
	}
	return s%modd;
}

int main() {
	file();
	scanf("%s",s);
	n=strlen(s);
	int f=1;
	For (i,0,n-1) if (s[i]!='a') { f=0; break; }
	if (f) {
		printf("%lld\n",quick((ll)2,(ll)(n/2-1))%modd);
		return 0;
	}
	N=(1<<(n-1));
	For (i,0,N-1) {
		cnt=0;
		string ss=""; ss=ss+s[0];
		For (j,0,n-2) {
			if (i&(1<<j)) {
				S[++cnt]=ss;
				ss=""; ss=ss+s[j+1];
			}
			else ss=ss+s[j+1];
		}
		S[++cnt]=ss;
		if (cnt%2) continue;
		int flag=1;
		For (j,1,cnt/2) if (S[j]!=S[cnt-j+1]) { flag=0; break; }
		if (flag) ++ans;
	}
	printf("%d\n",ans);
	return 0;
}
