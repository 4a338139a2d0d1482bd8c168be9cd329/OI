#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (int i=j;i<=k;++i)
#define Forr(i,j,k) for (int i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const int maxn=100000+100;
const ll inf=1e15;
struct node {
	int to,next;
}e[maxn<<1];
int n,tot,dfs_cnt,flag=1;
int head[maxn],A[maxn],B[maxn],cnt[maxn],id[maxn],p[maxn];
ll f[maxn];

inline void file() {
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
}

inline void read(int &x) {
	x=0;
	int p=1;
	char c=getchar();
	while (!isdigit(c)) {if (c=='-') p=-1; c=getchar();}
	while (isdigit(c)) {x=(x<<1)+(x<<3)+(c-'0'); c=getchar();}
	x*=p;
}

inline void add(int from,int to) {
	tot++;
	e[tot].to=to; e[tot].next=head[from]; head[from]=tot; cnt[to]++;
}

ll dfs(int u,int fa) {
	id[u]=++dfs_cnt; p[id[u]]=u;
	if (cnt[u]==1 && fa) {
		f[id[u]]=0;
		return 0;
	}
	ll minx=inf;
	for (int i=head[u];i!=0;i=e[i].next) {
		int v=e[i].to;
		if (v==fa) continue;
		chkmin(minx,dfs(v,u));
	}
	if (!flag) {
		For (i,id[u]+1,dfs_cnt)
			chkmin(f[id[u]],f[i]+1ll*A[u]*B[p[i]]);
		return f[id[u]];
	}
	else {
		f[id[u]]=minx+A[u];
		chkmin(minx,f[id[u]]);
		return minx;
	}
}

int main() {
	file();
	read(n);
	For (i,1,n) read(A[i]);
	For (i,1,n) {
		read(B[i]);
		if (B[i]!=1) flag=0;
	}
	For (i,1,n) f[i]=inf;
	For (i,1,n-1) {
		int x,y; read(x); read(y);
		add(x,y); add(y,x);
	}
	dfs(1,0);
	For (i,1,n) printf("%lld\n",f[id[i]]);
	return 0;
}
