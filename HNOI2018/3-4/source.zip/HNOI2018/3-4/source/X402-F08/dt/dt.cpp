#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
typedef long long ll;
typedef double dd;
#define For(i,j,k) for (ll i=j;i<=k;++i)
#define Forr(i,j,k) for (ll i=j;i>=k;--i)
#define Set(a,p) memset(a,p,sizeof(a))
using namespace std;

template<typename T>bool chkmax(T &a,T b) { return a<b?a=b,1:0; }
template<typename T>bool chkmin(T &a,T b) { return a>b?a=b,1:0; }

const ll maxn=1e7+1e2;
const ll modd=998244353;
ll n,k,ans;
ll f[maxn],g[maxn];

inline void file() {
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
}

ll quick(ll a,ll b) {
	ll s=1;
	a%=modd;
	while (b) {
		if (b%2) s=s*a%modd;
		a=a*a%modd; b/=2;
	}
	return s%modd;
}

int main() {
	file();
	scanf("%lld%lld",&n,&k);
	if (k==0) {
		printf("%lld\n",(quick(2,n)-1+modd)%modd);
		return 0;
	}
	if (n%2==1 && k==1) {
		printf("%lld\n",quick(2,n-1)*n%modd);
		return 0;
	}
	f[0]=1;
	For (i,0,n-1) f[i+1]=f[i]*((n-i)*quick(i+1,modd-2)%modd)%modd;
	For (i,1,n) g[i]=quick(i,k);
	For (i,1,n) ans=(ans+f[i]*g[i]%modd)%modd;
	printf("%lld\n",ans);
	return 0;
}
