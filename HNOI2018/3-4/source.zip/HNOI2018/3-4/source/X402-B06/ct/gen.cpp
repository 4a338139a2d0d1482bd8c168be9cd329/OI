#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("ct.in","w",stdout);
#endif
}
static int n=1e5;
int main()
{
	file();
	srand(time(NULL));
	cout<<n<<endl;
	Rep(i,1,n)cout<<1ll*rand()*rand()%200000-100000+1<<' ';cout<<endl;
	Rep(i,1,n)cout<<1ll*rand()*rand()%200000-100000+1<<' ';cout<<endl;
	Rep(i,2,n)cout<<i<<' '<<i/2<<endl;
	return 0;
}

