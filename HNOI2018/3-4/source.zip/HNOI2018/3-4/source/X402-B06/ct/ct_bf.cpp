#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
#define For(i,a,b) for(i=(a),i<=(b);++i)
#define Forward(i,a,b) for(i=(a),i>=(b);--i)
#define Chkmin(a,b) a=a<b?a:b
template<typename T>inline void read(T &x)
{
	T f=1;x=0;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c^48);
	x*=f;
}
using namespace std;
void file()
{
#ifndef ONLINE_JUDGE
	freopen("ct.in","r",stdin);
	freopen("ct_bf.out","w",stdout);
#endif
}
const int MAXN=1e5+7;
static int n;
static long long a[MAXN],b[MAXN],c[MAXN];
static struct edge
{
	int v,nxt;
}p[MAXN<<1];
static int head[MAXN],e;
inline void add(int u,int v){p[++e].v=v;p[e].nxt=head[u];head[u]=e;}
inline void init()
{
	read(n);
	Rep(i,1,n)read(a[i]);
	Rep(i,1,n)read(b[i]);
	memset(c,0x3f,sizeof c);
	static int u,v;
	Rep(i,1,n-1)read(u),read(v),add(u,v),add(v,u);
}
static struct line
{
	long long k,b;
}Q;
static struct node
{
	int l,r,has;
	line x;
}q[MAXN*400];
static int he[MAXN];
static stack<int>Node;
inline long long cal(line x,long long pos){return x.k*pos+x.b;}
inline long long touch(line x,line y){return (x.b-y.b)/(x.k-y.k);}
void recal(int &h,int l,int r,line z)
{
	if(!h)h=Node.top(),Node.pop();
	if(!q[h].has){q[h].has=true;q[h].x=z;return;}
	int mid=(l+r)>>1;
	if(cal(q[h].x,mid)>cal(z,mid))
	{
		if(l!=r&&q[h].x.k!=z.k)
			recal(q[h].l,l,mid,q[h].x)
			,recal(q[h].r,mid+1,r,q[h].x);
		q[h].x=z;
	}
	else if(l^r)
	{
		if(q[h].x.k==z.k)return;
		int pos=touch(q[h].x,z);
		if(pos<l||pos>r)return;
		if(pos<=mid)recal(q[h].l,l,mid,z);
		else recal(q[h].r,mid+1,r,z);
	}
}
inline int combine(int u,int v,int l,int r)
{
	if(!u||!v)return u|v;
	int mid=(l+r)>>1;
	q[u].l=combine(q[u].l,q[v].l,l,mid);
	q[u].r=combine(q[u].r,q[v].r,mid+1,r);
	recal(u,l,r,q[v].x);
	q[v].l=q[v].r=q[v].has=q[v].x.k=q[v].x.b=0;
	Node.push(v);
	return u;
}
long long lag;
void query(int h,int l,int r,int pos)
{
	if(!h)return;
	Chkmin(lag,cal(q[h].x,pos));
	if(l==r)return;
	static int mid;mid=(l+r)>>1;
	if(pos<=mid)query(q[h].l,l,mid,pos);
	else query(q[h].r,mid+1,r,pos);
}
void dfs(int u,int fa)
{
	for(register int v=head[u];v;v=p[v].nxt)if(p[v].v^fa)
	{
		dfs(p[v].v,u);
		he[u]=combine(he[u],he[p[v].v],-1e5,1e5);
	}
	lag=1ll<<60;
	if(he[u])query(he[u],-1e5,1e5,a[u]),c[u]=lag;
	else c[u]=0;
	recal(he[u],-1e5,1e5,(line){b[u],c[u]});
	//if(++e%10000==0)cerr<<e<<endl;
}
inline void solve()
{
	Rep(i,1,n*400)Node.push(i);e=0;
	dfs(1,0);
	Rep(i,1,n)printf("%lld\n",c[i]);
	//cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
}
int main()
{
	file();
	init();
	solve();
	return 0;
}

