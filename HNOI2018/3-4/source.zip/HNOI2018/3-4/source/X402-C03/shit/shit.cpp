#include<bits/stdc++.h>

typedef long long ll;
using namespace std;

const int maxn=1e5+10,mod=998244353;
int n,dp[maxn];
char s[maxn];

inline ll fpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a%mod)
		if(n&1ll)
			res=res*a%mod;
	return res;
}
namespace hasher{
	const int base=233;
	ll f[maxn];
	ll pow[maxn],inv[maxn];
	inline int init(){
		pow[0]=1;
		for(int i=1;i<=2*n;++i)
			pow[i]=pow[i-1]*base%mod;
		inv[0]=1;inv[1]=fpow(base,mod-2);
		for(int i=2;i<=2*n;++i)
			inv[i]=inv[i-1]*inv[1]%mod;
		for(int i=0;i<2*n;++i)
			f[i+1]=(f[i]+s[i]*pow[i])%mod;
	}
	inline int get(int a,int b){
		return (f[a+b]-f[a]+mod)%mod*inv[a]%mod;
	}
}
namespace full_of_a{
	int main(){
		for(int i=0;s[i];++i)
			if(s[i]!='a')
				return 0;
		printf("%lld\n",fpow(2,n-1));
		exit(0);
	}
}

int main(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	scanf("%s",s);
	n=strlen(s)/2;
	full_of_a::main();
	hasher::init();
	dp[0]=1;
	for(int i=1;i<=n;++i)
		for(int j=0;j<i;++j)
			if(hasher::get(j,i-j)==hasher::get(2*n-i,i-j))
				(dp[i]+=dp[j])%=mod;
	printf("%d\n",dp[n]);
	return 0;
}
