#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE* f=fopen("seed","r");
	int seed;
	if(f==NULL)
		seed=time(NULL)+(clock()*clock()*clock()^123456789);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}

char s[10000];

int main(){
	init();
	freopen("shit.in","w",stdout);
	int n=rand()%8+1,k=rand()%2+2;
	for(int i=0;i<n;++i)
		s[i]=rand()%k+'a';
	printf("%s",s);
	random_shuffle(s,s+n);
	printf("%s\n",s);
	return 0;
}
