#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE* f=fopen("seed","r");
	int seed;
	if(f==NULL)
		seed=time(NULL)+(clock()*clock()*clock()^123456789);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}

int main(){
	init();
	freopen("ct.in","w",stdout);
	int n=5e3,k=1e5;
	n=1e4;
	n-=rand()%n;
//	n=1e5;
	printf("%d\n",n);
	for(int i=1;i<=n;++i)
		printf("%d ",(rand()&1?1:-1)*rand()%k);
	puts("");
	for(int i=1;i<=n;++i)
		printf("%d ",(rand()&1?1:-1)*rand()%k);
	puts("");
	for(int i=2;i<=n;++i)
		printf("%d %d\n",rand()%(i-1)+1,i);
	return 0;
}
