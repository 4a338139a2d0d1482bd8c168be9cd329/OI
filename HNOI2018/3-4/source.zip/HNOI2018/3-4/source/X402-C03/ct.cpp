#include<bits/stdc++.h>

typedef long long ll;
template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}
inline int rui(){int x;char c;while(!isdigit(c=getchar()));x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return x;}
inline int rsi(){int x;bool f=false;char c;while(!isdigit(c=getchar()))if(c=='-')f=true;x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return f?-x:x;}
inline ll rul(){ll x;char c;while(!isdigit(c=getchar()));x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return x;}
inline ll rsl(){ll x;bool f=false;char c;while(!isdigit(c=getchar()))if(c=='-')f=true;x=c-48;while(isdigit(c=getchar()))x=x*10+c-48;return f?-x:x;}
template<typename t>void write_(t x){if(x>9)write_(x/10);putchar(x%10+48);}
template<typename t>inline void wu(t x){write_(x);}	   
template<typename t>inline void ws(t x){if(x<0)putchar('-'),write_(-x);else write_(x);}
template<typename t>inline void wu(t x,char c){write_(x);putchar(c);}
template<typename t>inline void ws(t x,char c){if(x<0)putchar('-'),write_(-x);else write_(x);putchar(c);}
inline void wstr(const char*s){while(*s)putchar(*s++);}
inline void wstr(const char*s,char c){while(*s)putchar(*s++);putchar(c);}
//inline void chkt(){fprintf(stderr,"Time:\t%f s\n",(double)clock()/CLOCKS_PER_SEC);}
//inline void chkm(){FILE*f=fopen("/proc/self/status","r");char c;for(int t=12;t;)if(fgetc(f)==' ')--t;fprintf(stderr,"VmPeak:\t");while((c=fgetc(f))!=' ')fputc(c,stderr);fprintf(stderr," kB\n");fclose(f);}
//#define err(...) fprintf(stderr,__VA_ARGS__)
using namespace std;

const int maxn=1e5+10;
int n,a[maxn],b[maxn],size[maxn],son[maxn];
ll dp[maxn];
vector<int> g[maxn];

void dfs0(int pos,int fa){
	size[pos]=1;
	for(int i=0,v;i<g[pos].size();++i)
		if((v=g[pos][i])!=fa){
			dfs0(v,pos);
			size[pos]+=size[v];
			if(size[v]>size[son[pos]])
				son[pos]=v;
		}
}
inline bool cmp(int x,int y){
	return b[x]==b[y]?dp[x]<dp[y]:b[x]<b[y];
}
inline bool check(int x,int y,int z){
	return (__int128)(b[y]-b[x])*(dp[z]-dp[y])>(__int128)(dp[y]-dp[x])*(b[z]-b[y]);
}
namespace splay{
	int fa[maxn],ch[maxn][2];
	int root[maxn];

	inline void rotate(int pos){
		int f=fa[pos],ff=fa[f];
		if(ff)
			ch[ff][ch[ff][1]==f]=pos;
		bool tmp=ch[f][1]==pos;
		ch[f][tmp]=ch[pos][tmp^1];
		fa[ch[f][tmp]]=f;
		ch[pos][tmp^1]=f;
		fa[f]=pos;
		fa[pos]=ff;
	}
	inline void splay(int pos,int&rt){
		while(fa[pos]){
			int f=fa[pos],ff=fa[f];
			if(ff)
				if((ch[ff][1]==f)==(ch[f][1]==pos))
					rotate(f);
				else
					rotate(pos);
			rotate(pos);
		}
		rt=pos;
	}
	inline int findleft(int pos){
		if(ch[pos][0]){
			pos=ch[pos][0];
			while(ch[pos][1])
				pos=ch[pos][1];
			return pos;
		}
		else{
			while(fa[pos]&&ch[fa[pos]][0]==pos)
				pos=fa[pos];
			return fa[pos];
		}
	}
	inline int findright(int pos){
		if(ch[pos][1]){
			pos=ch[pos][1];
			while(ch[pos][0])
				pos=ch[pos][0];
			return pos;
		}
		else{
			while(fa[pos]&&ch[fa[pos]][1]==pos)
				pos=fa[pos];
			return fa[pos];
		}
	}
	inline void insert(int pos,int&rt){
		int p=rt;
		while(true)
			if(cmp(pos,p))
				if(ch[p][0])
					p=ch[p][0];
				else{
					fa[pos]=p;
					ch[p][0]=pos;
					break;
				}
			else
				if(ch[p][1])
					p=ch[p][1];
				else{
					fa[pos]=p;
					ch[p][1]=pos;
					break;
				}
		splay(pos,rt);
	}
	inline void del(int pos,int&rt){
		splay(pos,rt);
		if(ch[pos][0])
			if(ch[pos][1]){
				int l=ch[pos][0],r=ch[pos][1];
				fa[l]=fa[r]=ch[pos][0]=ch[pos][1]=0;
				rt=r;
				while(ch[r][0])
					r=ch[r][0];
				fa[l]=r;ch[r][0]=l;
				splay(l,rt);
			}
			else{
				rt=ch[pos][0];
				fa[rt]=0;
				ch[pos][0]=0;
			}
		else
			if(ch[pos][1]){
				rt=ch[pos][1];
				fa[rt]=0;
				ch[pos][1]=0;
			}
			else
				rt=0;
	}
	void merge(int&rt,int pos){
		if(ch[pos][0]){
			fa[ch[pos][0]]=0;
			merge(rt,ch[pos][0]);
			ch[pos][0]=0;
		}
		if(ch[pos][1]){
			fa[ch[pos][1]]=0;
			merge(rt,ch[pos][1]);
			ch[pos][1]=0;
		}
		insert(pos,rt);
		{
			int l=findleft(pos),r=findright(pos);
			if(l&&r&&!check(l,pos,r)){
				del(pos,rt);
				return;
			}
		}
		while(true){
			int l1=findleft(pos);
			if(!l1)
				break;
			int l2=findleft(l1);
			if(!l2||check(l2,l1,pos))
				break;
			else
				del(l1,rt);
		}
		while(true){
			int r1=findright(pos);
			if(!r1)
				break;
			int r2=findright(r1);
			if(!r2||check(pos,r1,r2))
				break;
			else
				del(r1,rt);
		}
	}
	void update(int now,int pos){
		chkmin(dp[now],dp[pos]+(ll)a[now]*b[pos]);
		int l=findleft(pos);
		if(ch[pos][0]&&dp[l]+(ll)a[now]*b[l]<=dp[pos]+(ll)a[now]*b[pos])
			update(now,ch[pos][0]);
		else if(ch[pos][1])
			update(now,ch[pos][1]);
	}
}
void dfs(int pos,int fa){
	if(size[pos]==1){
		splay::root[pos]=pos;
		return;
	}
	dfs(son[pos],pos);
	splay::root[pos]=splay::root[son[pos]];
	for(int i=0,v;i<g[pos].size();++i)
		if((v=g[pos][i])!=fa&&v!=son[pos]){
			dfs(v,pos);
			splay::merge(splay::root[pos],splay::root[v]);
		}
	dp[pos]=1e18;
	splay::update(pos,splay::root[pos]);
	splay::merge(splay::root[pos],pos);
}

int main(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	n=rui();
	for(int i=1;i<=n;++i)
		a[i]=rsi();
	for(int i=1;i<=n;++i)
		b[i]=rsi();
	for(int i=1,u,v;i<n;++i){
		u=rui();v=rui();
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs0(1,0);
	dfs(1,0);
	for(int i=1;i<=n;++i)
		ws(dp[i],'\n');
	return 0;
}
