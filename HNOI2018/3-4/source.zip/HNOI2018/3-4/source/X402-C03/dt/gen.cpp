#include<bits/stdc++.h>
using namespace std;

inline void init(){
	FILE* f=fopen("seed","r");
	int seed;
	if(f==NULL)
		seed=time(NULL)+(clock()*clock()*clock()^123456789);
	else{
		fscanf(f,"%d",&seed);
		fclose(f);
	}
	f=fopen("seed","w");
	srand(seed);
	fprintf(f,"%d",rand());
	fclose(f);
	cerr<<seed<<endl;
}

int main(){
	init();
	freopen("dt.in","w",stdout);
	int n=1e6;
	n-=rand()%n;
	if(rand()%3==0)
		printf("%d %d\n",n,rand()%5000);
	else if(rand()%2==0)
		printf("%d 1\n",n);
	else
		printf("%d 0\n",n);
	return 0;
}
