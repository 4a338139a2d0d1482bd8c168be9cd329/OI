#include<bits/stdc++.h>

typedef long long ll;
template<typename t>inline t min_(t a,t b){return a<=b?a:b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}
using namespace std;

const int maxn=1e6+10,mod=998244353;
int n,k;
ll fac[maxn],inv[maxn],ans;

inline ll qpow(ll a,ll n){
	ll res=1;
	for(;n;n>>=1,a=a*a%mod)
		if(n&1ll)
			res=res*a%mod;
	return res;
}

int main(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(k==0){
		printf("%lld\n",(qpow(2,n)+mod-1)%mod);
		return 0;
	}
	if(k==1){
		printf("%lld\n",qpow(2,n-1)*n%mod);
		return 0;
	}
	fac[0]=1;
	for(int i=1;i<maxn;++i)
		fac[i]=fac[i-1]*i%mod;
	inv[maxn-1]=qpow(fac[maxn-1],mod-2);
	for(int i=maxn-1;i;--i)
		inv[i-1]=inv[i]*i%mod;
	for(int i=1;i<=n;++i)
		(ans+=inv[i]*inv[n-i]%mod*qpow(i,k))%=mod;
	printf("%lld\n",ans*fac[n]%mod);
	return 0;
}
