#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
const int maxn=100010;
const int mod=998244353;
const int base=23;
char s[maxn];
int n;
int dp[maxn];
ull a[maxn], pw[maxn];
ll b[maxn], pw1[maxn];

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

bool check(int l1,int r1,int l2,int r2){
	// printf("%d-%d | %d-%d\n", l1, r1, l2, r2);
	int len=r1-l1+1;
	return a[r1]-a[l1-1]*pw[len]==a[r2]-a[l2-1]*pw[len] &&
		   (b[r1]-b[l1-1]*pw1[len]%mod+mod)%mod==(b[r2]-b[l2-1]*pw1[len]%mod+mod)%mod;
	for(int i=0;i<len;i++) if(s[l1+i]!=s[l2+i]) return false;
	return true;
}

int main(){
	freopen("shit.in","r",stdin),freopen("shit.out","w",stdout);

	scanf("%s", s+1); n=strlen(s+1);
	for(int i=1;i<=n;i++) a[i]=a[i-1]*base+s[i]-'0';
	for(int i=1;i<=n;i++) b[i]=(b[i-1]*base%mod+s[i]-'0')%mod;
	pw[0]=1; pw1[0]=1;
	for(int i=1;i<=n;i++) pw[i]=pw[i-1]*base, pw1[i]=pw1[i-1]*base%mod;
	/*
	 printf("n = %d\n", n);
	printf("check = %d\n", check(1,1,14,14));
	*/
	int f=1;
	for(int i=1;i<=n;i++) f &= (s[i]=='a');
	//if(f){ printf("%lld\n", Pow(2,(n/2)-1)); return 0; }
	dp[0]=1;
	for(int i=1;i<=n/2;i++){
		for(int k=1;k<=i;k++) if(check(k,i,n-i+1,n-k+1)){
			// printf("%d %d\n", k, i);
			(dp[i]+=dp[k-1])%=mod;
		}
	}
	// printf("%d\n", dp[2][1]);
	ll ans=0;
	// for(int i=1;i<=n/2;i++) (ans+=dp[n/2][i])%=mod;
	ans=dp[n/2];
	printf("%lld\n", ans);
	return 0;
}
