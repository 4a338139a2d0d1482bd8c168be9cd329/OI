#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1010;
const int mod=998244353;
char s[maxn];
int n;
int dp[maxn];

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

bool check(int l1,int r1,int l2,int r2){
	// printf("%d-%d | %d-%d\n", l1, r1, l2, r2);
	int len=r1-l1+1;
	for(int i=0;i<len;i++) if(s[l1+i]!=s[l2+i]) return false;
	return true;
}

int main(){
	freopen("shit.in","r",stdin),freopen("shit.out","w",stdout);

	scanf("%s", s+1); n=strlen(s+1);
	int f=1;
	for(int i=1;i<=n;i++) f &= (s[i]=='a');
	if(f){ printf("%lld\n", Pow(2,(n/2)-1)); return 0; }
	// printf("n = %d\n", n);
	dp[0]=1;
	for(int i=1;i<=n/2;i++){
		for(int k=1;k<=i;k++) if(check(k,i,n-i+1,n-k+1)){
			(dp[i]+=dp[k-1])%=mod;
		}
	}
	// printf("%d\n", dp[2][1]);
	ll ans=0;
	// for(int i=1;i<=n/2;i++) (ans+=dp[n/2][i])%=mod;
	ans=dp[n/2];
	printf("%lld\n", ans);
	return 0;
}
