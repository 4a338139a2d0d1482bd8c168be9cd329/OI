#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const ll inf=1e18;
int n;
int a[maxn], b[maxn];
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar(); int f=1;
	while(c<'0' || c>'9'){ if(c=='-') f=-1; c=getchar(); }
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	x*=f;
}
void chkmin(ll& x,ll y){ if(x>y) x=y; }

ll dp[maxn];

int st[maxn], ed[maxn], dfn, fa[maxn], id[maxn];
void dfs(int x){
	st[x]=++dfn; id[dfn]=x; dp[x]=inf;
	int isleaf=1;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x]) continue;
		fa[v]=x; isleaf=0; dfs(v);
	}
	if(isleaf){ dp[x]=0; return; }
	ed[x]=dfn;
	for(int i=st[x]+1;i<=ed[x];i++){
		int v=id[i];
		chkmin(dp[x],dp[v]+1ll*a[x]*b[v]);
	}
}

ll Min[maxn];
void DFS(int x){
	Min[x]=inf;
	int isleaf=1;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x]) continue;
		fa[v]=x; DFS(v); Min[x]=min(Min[x],Min[v]);
		isleaf=0;
	}
	dp[x]=Min[x]+a[x];
	Min[x]=min(Min[x],dp[x]);
	if(isleaf) dp[x]=Min[x]=0;
}
void solve(){
	DFS(1);
	for(int i=1;i<=n;i++) printf("%lld\n", dp[i]);
}

int main(){
	freopen("ct.in","r",stdin),freopen("ct.out","w",stdout);

	read(n);
	for(int i=1;i<=n;i++) read(a[i]);
	for(int i=1;i<=n;i++) read(b[i]);
	int u, v;
	for(int i=1;i<n;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
	}
	//solve(); return 0;
	if(n>10000){ solve(); return 0; }
	dfs(1);
	for(int i=1;i<=n;i++) printf("%lld\n", dp[i]);
	return 0;
}
