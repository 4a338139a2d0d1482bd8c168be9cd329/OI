#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=5010;
const int maxm=1000010;
const int N=1000000;
const int mod=998244353;
int n, k;
ll inv[maxm];
ll dp[maxn][maxn];

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

void init(){
	for(int i=2;i<=N;i++) inv[i]=Pow(i,mod-2);
}

ll ans;

ll c[maxn];

ll sum[maxn], S[maxn][maxn], fac[maxn];
void solve(){
	S[0][0]=1;
	fac[0]=1;
	for(int i=1;i<=k;i++) fac[i]=fac[i-1]*i%mod;
	for(int i=1;i<=k;i++){
		for(int j=1;j<=i;j++) S[i][j]=(S[i-1][j]*j%mod+S[i-1][j-1])%mod;
	}
	// for(int i=0;i<=k;i++,puts("")) for(int j=0;j<=i;j++) printf("%lld ", S[i][j]);
	// printf("%lld\n", S[2][1]);
	ll tot=1;
	for(int i=0;i<=min(k,n);i++){
		ans=(ans+S[k][i]*tot%mod*Pow(2,n-i)%mod)%mod;
		tot=tot*(n-i)%mod;
	}
	//printf("%lld %lld\n", ans, tot);
	printf("%lld\n", ans);
}

int main(){
	freopen("dt.in","r",stdin),freopen("dt.out","w",stdout);

	scanf("%d%d", &n, &k);
	if(k==0){ printf("%lld\n", Pow(2,n)-1); return 0; }
	if(k==1){ printf("%lld\n", 1ll*n*Pow(2,n-1)%mod); return 0; }
	if(n>1e6){ solve(); return 0; }
	if(!n){ puts("0"); return 0; }
	init();
	ll c=n;
	for(int i=1;i<=n;i++){
		(ans+=c*Pow(i,k)%mod)%=mod;
		c=c*(n-i)%mod*inv[i+1]%mod;
	}
	printf("%lld\n", ans);
	// cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
