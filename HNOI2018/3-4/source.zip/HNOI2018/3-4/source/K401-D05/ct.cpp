#include<bits/stdc++.h>
using namespace std;
#define N 100010
int n;
int A[N],B[N];
struct node
{
	int to,last;
}E[N<<1];
int beg[N],e;
void add(int u,int v)
{
	E[++e].to=v;
	E[e].last=beg[u];
	beg[u]=e;
}
bool vis[N];
int dp[N],son[N];
void luangao(int u)
{
	vis[u]=1;	
	for(int i=beg[u];i;i=E[i].last)
	{
		int v=E[i].to;
		if(!vis[v]) 
		{
			vis[v]=1;
			luangao(v);
			if(son[u]!=1 || !son[v]) {
				dp[u]=min(dp[u],dp[v]+(A[u]<0?A[u]:0));
			}
			else if(son[u]==1) dp[u]+=dp[v];
			vis[v]=0;
		}
	}
}
int main()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	scanf("%d",&n);
	bool flag=1;
	for(int i=1;i<=n;++i) scanf("%d",&A[i]);
	for(int i=1;i<=n;++i) {scanf("%d",&B[i]);if(B[i]!=1)flag=0;}
	for(int i=1;i<n;++i) 
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
		son[u]++;
	}
	if(flag) {luangao(1);printf("%d\n",A[1]+dp[1]);}

	return 0;
}
