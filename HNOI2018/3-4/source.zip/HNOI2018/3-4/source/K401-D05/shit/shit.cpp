#include<bits/stdc++.h>
using namespace std;
#define N 100010
#define Mod 998244353
char s[N];
long long ksm(int x,int k)
{
	long long temp=x;long long res=1;
	while(k) 
	{
		if(k&1) (res*=temp)%=Mod;
		(temp*=temp)%=Mod;
		k>>=1;
	}
	return res;
}
int main()
{
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
	scanf("%s",s);
	int len=strlen(s);
	bool flag=1;
	for(int i=1;i<len;++i) if(s[i]!=s[i-1]) flag=0;
	if(flag) {printf("%lld\n",ksm(2,len/2-1)%Mod);return 0;}
	return 0;
}
