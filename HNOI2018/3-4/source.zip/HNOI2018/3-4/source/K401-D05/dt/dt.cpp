#include<bits/stdc++.h>
using namespace std;
#define N 1000010
#define Mod 998244353
int n,k;
long long c[N],pl[N];
long long ksm(int x,int k)
{
	long long temp=x;long long res=1;
	while(k) 
	{
		if(k&1) (res*=temp)%=Mod;
		(temp*=temp)%=Mod;
		k>>=1;
	}
	return res;
}
int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(k==0) 
	{
		pl[1]=1;
		for(int i=2;i<=n;++i)
			pl[i]=pl[i-1]+ksm(2,i-1);
		printf("%lld\n",pl[n]%Mod);
		return 0;
	}
	if(k==1) 
	{
		printf("%lld\n",n*ksm(2,n-1)%Mod);
		return 0;
	}
	c[0]=1;
	for(int i=0;i<n;++i) 
	{
		c[i+1]=c[i]*(n-i)%Mod*ksm(i+1,Mod-2)%Mod;
	}
	long long ans=0;
	for(int i=1;i<=n;++i) 
	{
		(ans+=c[i]*ksm(i,k)%Mod)%=Mod;
	}
	printf("%lld\n",ans%Mod);	
	return 0;
}
