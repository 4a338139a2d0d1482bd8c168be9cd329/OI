#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("shit.in","r",stdin);
	freopen("shit.out","w",stdout);
}

typedef long long ll;
const int N=1e5+10;
const ll mod=998244353; 
char s[N];
int len,ans=0;

ll ksm(ll a,ll b){
	ll res=1;
	while(b>0){
		if(b&1) (res*=a)%=mod;
		(a*=a)%=mod;
		b>>=1;
	}
	return res;
}

bool check(int x,int y){
	int x1=len+1-y;
	For(i,0,y-x) if(s[x+i]!=s[x1+i])
		return 0;
	return 1;
}

inline void dfs(int x){
	if(x==(len>>1)+1){
		ans+=1;return;
	}
	For(i,x,(len>>1)) if(check(x,i)) dfs(i+1);
}

int main(){
	file();
	scanf("%s",s+1);
	len=strlen(s+1);
	int flag=1;
	For(i,1,len) if(s[i]!='a') flag=0;
	if(flag){
		printf("%lld\n",ksm(2,((1ll*len)>>1)-1));
		return 0;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}

