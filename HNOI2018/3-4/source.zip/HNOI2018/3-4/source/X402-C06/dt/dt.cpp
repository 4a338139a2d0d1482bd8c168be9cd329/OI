#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
}

typedef long long ll;
const ll mod=998244353;
const int N=1e6+10,K=5e3+10;
ll tmp,n,k,ans,S[K][K],fac=1;

ll ksm(ll a,ll b){
	ll res=1;
	while(b>0){
		if(b&1) (res*=a)%=mod;
		(a*=a)%=mod;
		b>>=1;
	}
	return res;
}

int main(){
	file();
	read(n),read(k);
	if(k==0){
		printf("%lld\n",ksm(2,n)-1);
		return 0;
	}
	S[0][0]=1;
	For(i,1,k) For(j,1,i)
		S[i][j]=(S[i-1][j-1]+((ll)j*S[i-1][j])%mod)%mod;
	For(i,0,k){
		tmp=S[k][i]%mod*ksm(2,n-i)%mod*fac%mod;
		(ans+=tmp)%=mod;
		(fac*=((n-i)%mod))%mod;
	}	
	printf("%lld\n",ans);
	return 0;
}

