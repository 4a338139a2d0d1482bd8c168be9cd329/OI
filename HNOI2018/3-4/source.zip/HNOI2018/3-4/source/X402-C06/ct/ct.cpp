#include<bits/stdc++.h>
#define Travel(i,s) for(register int i=beg[s];i;i=nex[i])
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
}

typedef long long ll;
const int N=1e5+10;
int e,beg[N<<1],nex[N<<1],to[N<<1];
int n,A[N],B[N],dfn[N],num[N],siz[N],vis[N],clk;
ll ans[N];

inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}

inline void dfs(int x,int fa){
	dfn[x]=++clk,num[clk]=x,siz[x]=1,ans[x]=LONG_MAX;
	Travel(i,x) if(to[i]!=fa) dfs(to[i],x),siz[x]+=siz[to[i]];		
	if(siz[x]==1) ans[x]=0;
	For(i,dfn[x]+1,dfn[x]+siz[x]-1)
		ans[x]=min(ans[x],ans[num[i]]+1ll*A[x]*B[num[i]]);
}

int main(){
	file();
	read(n);
	For(i,1,n) read(A[i]);
	For(i,1,n) read(B[i]);
	For(i,1,n-1){
		int x,y;
		read(x),read(y);
		add(x,y),add(y,x);
	}
	clk=0,dfs(1,0);
	For(i,1,n) printf("%lld\n",ans[i]);
	return 0;
}

