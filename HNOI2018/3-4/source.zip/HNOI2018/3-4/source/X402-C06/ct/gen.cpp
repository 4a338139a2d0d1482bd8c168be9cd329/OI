#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=(j);i<=(k);++i)
#define Forr(i,j,k) for(register int i=(j);i>=(k);--i)
using namespace std;

template<typename T>
inline void read(T &x){
	T p=1,c=getchar();
	x=0;
	while(!isdigit(c)){
		if(c=='-') p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	x*=p;
}

inline void file(){
	freopen("ct1.in","w",stdout);
}

int main(){
	file();
	srand(time(0));
	printf("5000\n");
	For(i,1,5000) printf("%d ",rand()%1000);puts("");
	For(i,1,5000) printf("%d ",rand()%1000);puts("");
	For(i,1,4999){
		printf("%d %d\n",i,i+1);
	}
	return 0;
}

