./gen >ct15.in
./ct <ct15.in >ct15.out
./gen >ct16.in
./ct <ct16.in >ct16.out
./gen >ct17.in
./ct <ct17.in >ct17.out
./gen >ct18.in
./ct <ct18.in >ct18.out
./gen >ct19.in
./ct <ct19.in >ct19.out
./gen >ct20.in
./ct <ct20.in >ct20.out
