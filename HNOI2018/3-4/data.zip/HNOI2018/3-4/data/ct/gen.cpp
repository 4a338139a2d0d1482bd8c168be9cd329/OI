#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

const int N=101000;

int s[N];

int lim=200000,fk=lim/2;
int rd()
{
	int ret=rand()%lim+1-fk;
	if(ret<0 && rand()%23)ret*=-1;
	if(!ret)ret++;
	return ret;
}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	int n=100000,rg=2333;
	n-=rand()%rg;

	for(int i=1;i<=n;i++)
		s[i]=i,std::swap(s[i],s[rand()%i+1]);

	printf("%d\n",n);
	
	for(int i=1;i<=n;i++)
		printf("%d ",rd());
	printf("\n");
	for(int i=1;i<=n;i++)
		printf("%d ",rd());
	printf("\n");

	int k=rand()%(n/5);
	for(int i=2;i<=k;i++)
		printf("%d %d\n",s[i-1],s[i]);
	for(int i=k+1;i<=k*2;i++)
		printf("%d %d\n",s[k],s[i]);
	for(int i=k*2+1;i<=n;i++)
		printf("%d %d\n",s[rand()%(i-1)+1],s[i]);

//	for(int i=2;i<=n;i++)
//		printf("%d %d\n",i-1,i);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
