#include<iostream>
#include<cstdio>
#include<cstring>

const int N=5010,MOD=998244353;
inline void inc(int a,int &b){b=(a+b)%MOD;}

bool isp[N][N];
int f[N];

char s[N],t[N];
int n;

int main()
{
//	freopen("shit.in","r",stdin);
//	freopen("shit.out","w",stdout);

	scanf("%s",s+1);
	n=strlen(s+1); 
	for(int i=1;i<=n/2;i++)
		t[i*2-1]=s[i];
	for(int i=1;i<=n/2;i++)
		t[i*2]=s[n-i+1];

	for(int i=1;i<=n;i++)isp[i][i]=1;
	for(int i=1;i<n;i++)isp[i+1][i]=1;
	for(int len=2;len<=n;len++)
		for(int i=1,j;(j=i+len-1)<=n;i++)
			isp[i][j]=(t[i]==t[j] && isp[i+1][j-1]);
	f[0]=1;
	for(int i=2;i<=n;i+=2)
		for(int j=1;j<=i;j++)
			if(isp[j][i])inc(f[j-1],f[i]);
	printf("%d\n",f[n]);
	return 0;
}
