./gen >shit17.in
./shit <shit17.in >shit17.out
./gen >shit18.in
./shit <shit18.in >shit18.out
./gen >shit19.in
./shit <shit19.in >shit19.out
./gen >shit20.in
./shit <shit20.in >shit20.out
