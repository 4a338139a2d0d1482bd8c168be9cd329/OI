#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

const int N=100100;

int fuck(int x)
{
	static int d[N],tot;
	tot=0;
	for(int i=2;i<=x;i+=2)
		if(i%2==0 && x%i==0 && i<=1000)d[++tot]=x;
	return d[rand()%tot+1];
}
char rd()
{
	return rand()%26+'a';
}

char s[N],*t;

int main()
{
//	freopen("shit.in","w",stdout);

	srand(time(0)+clock()*clock());

	int len=100000;

	int n=len-2*(rand()%(len/10)),lst=0;
	
	while(lst<n)
	{
		int m=(rand()%(std::min((n-lst)/2,10))+1)*2,d=fuck(m);

		t=s+lst,lst+=m;
		for(int i=1;i<=d/2;i++)t[i]=t[d-i+1]=rd();
		for(int i=d+1;i<=m;i++)t[i]=t[i-d];
	}

	for(int i=1;i<=n/2;i++)
		printf("%c",s[i*2-1]);
	for(int i=n/2+1;i<=n;i++)
		printf("%c",s[(n-i+1)*2]);
	printf("\n");

//	fprintf(stderr,"%s\n",s+1);

	return 0;
}
