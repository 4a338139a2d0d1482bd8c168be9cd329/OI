./gen >dt13.in
./dt <dt13.in >dt13.out
./gen >dt14.in
./dt <dt14.in >dt14.out
./gen >dt15.in
./dt <dt15.in >dt15.out
./gen >dt16.in
./dt <dt16.in >dt16.out
./gen >dt17.in
./dt <dt17.in >dt17.out
./gen >dt18.in
./dt <dt18.in >dt18.out
./gen >dt19.in
./dt <dt19.in >dt19.out
./gen >dt20.in
./dt <dt20.in >dt20.out
