#include<iostream>
#include<cstdio>
#include<cstring>

typedef long long ll;
const int N=5050,MOD=998244353;

ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

int str[N][N];

void initialize()
{
	str[0][0]=1;
	for(int i=1;i<N;i++)
		for(int j=1;j<N;j++)
			str[i][j]=(str[i-1][j-1]+(ll)str[i-1][j]*j)%MOD;
}

int main()
{
	freopen("dt.in","r",stdin);
	freopen("dt.out","w",stdout);
	initialize();
	int n,k,pi,ans=0;

	scanf("%d%d",&n,&k);
	pi=1;

	for(int i=0;i<=k && i<=n;i++)
	{
		ans=(ans+(ll)pi*str[k][i]%MOD*qpow(2,n-i)%MOD)%MOD;
		pi=(ll)pi*(n-i)%MOD;
	}
	if(!k)ans--;
	ans=(ans+MOD)%MOD;
	printf("%d\n",ans);
	return 0;
}
