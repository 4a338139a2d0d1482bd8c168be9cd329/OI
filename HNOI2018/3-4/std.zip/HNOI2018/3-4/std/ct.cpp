#include<iostream>
#include<cstdio>
#include<cstring>
#include<set>
#define x first
#define y second

namespace NanXie
{
	typedef long long ll;
	typedef std::pair<ll,ll> pii;
	typedef std::multiset<pii>::iterator sit;
	const int N=101000,M=101000;
	const ll INF=9223372035854775807ll;

	double cross(pii A,pii B){return (double)A.x*B.y-(double)A.y*B.x;}
	pii operator - (pii A,pii B){return pii(A.x-B.x,A.y-B.y);}
	inline bool check(pii A,pii B,pii C){return cross(B-A,C-A)>0;}

	std::multiset<pii> H[N];

	inline sit get_pre(sit A){return --A;}
	inline sit get_suc(sit A){return ++A;}

	void insert(std::multiset<pii> &S,pii A)
	{
		sit it=S.insert(A),pre,suc=get_suc(it);

		if(it!=S.begin() && suc!=S.end())
		{
			pre=get_pre(it);
			if(!check(*pre,*it,*suc))
			{
				S.erase(it);
				return ;
			}
		}

		sit tmp;

		if(it!=S.begin())
		{
			pre=get_pre(it);
			while(pre!=S.begin())
			{
				tmp=get_pre(pre);
				if(check(*tmp,*pre,*it))break;
				S.erase(pre);
				pre=get_pre(it);
			}
		}

		if(suc!=S.end())
		{
			tmp=get_suc(suc);
			while(tmp!=S.end())
			{
				if(check(*it,*suc,*tmp))break;
				S.erase(suc);
				suc=get_suc(it);
				tmp=get_suc(suc);
			}
		}


		suc=get_suc(it);
		if(suc!=S.end())
		{
			if(suc->x==it->x)S.erase(suc);
		}
		if(it!=S.begin())
		{
			pre=get_pre(it);
			if(pre->x==it->x)S.erase(it);
		}
	}

	inline bool judge(sit it,int k)
	{
		static pii A;
		A=(*it-*get_pre(it));
//		A.y/A.x<=k
		if(A.x>0)return A.y<=k*A.x;
		else return A.y>=k*A.x;
	}

	ll query(std::multiset<pii> &S,ll k)
	{
		int u=M,d=-M,mid;
		sit it;
		while(u>d)
		{
			mid=(u+d+1)>>1;
			it=S.lower_bound(pii(mid,-INF));
			if(it!=S.end() && (it==S.begin() || judge(it,k)))d=mid;
			else u=mid-1;
		}

		it=S.lower_bound(pii(d,-INF));

		return it->y-k*it->x;
	}

	int begin[N],next[N*2],to[N*2];
	int A[N],B[N];
	int n,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}

	void initialize()
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",A+i);
		for(int i=1;i<=n;i++)scanf("%d",B+i);
		for(int i=1,u,v;i<n;i++)scanf("%d%d",&u,&v),add(u,v);
	}

	ll f[N];

	void dfs(int p=1,int h=0)
	{
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h)
			{
				dfs(q,p);
				if(H[p].size()<H[q].size())std::swap(H[p],H[q]);
				for(auto X:H[q])insert(H[p],X);
			}

		if(H[p].empty())f[p]=0;
		else f[p]=query(H[p],A[p]);

		insert(H[p],pii(-B[p],f[p]));
	}

	void solve()
	{
		initialize();
		dfs();
		for(int i=1;i<=n;i++)
			printf("%lld\n",f[i]);
	}

}

int main()
{
	freopen("ct.in","r",stdin);
	freopen("ct.out","w",stdout);
	NanXie::solve();
	return 0;
}
